# Visual tour captures

The visual-tour harness walks through the real extension side panel and captures each significant state at narrow, standard, and wide widths. It covers the adapter manager, Semantic Library manager (including individual LOV results, a pinned term preview, vocabulary search, the paged vocabulary browser, a connected package preview, and a selected local pattern when one exists), disposable manual adapter workflow, semantic graph, compact custom-relationship editor, advanced form editor, and the deterministic variant recovery journey from Attention through the evidence resolver and exact-shape fallback acceptance. It also captures recurrence when a changed classification shape invalidates that acceptance.

Planned, not yet implemented: once the V2 source-linked Review surface has an editor UI (the derivation engine exists in `extension/ir/v2-review-surface.js`, but no UI constructs overlay corrections yet — see roadmap.md), the harness should also capture the state transitions that prove alignment between:

- page source previews and S2J markup node highlights,
- overlay-corrective decisions and derived semantic output,
- ranked uncertainty review ordering,
- and explicit `Thing` fallback handling.

Additional tiles cover vertically long pages and horizontally overflowing controls. Catalog capture failures are reported but do not prevent the local/manual tour from continuing.

## Run it

Start Chrome with remote debugging, load the development extension, open the Site2JSON side panel beside a supported rendered page, and run:

```bash
npm run visual-tour -- --page-match guru.com --item-selector '.jobRecord'
```

Force a reproducible appearance for a light or dark tour with `--theme`. The harness restores the previously saved appearance when the run finishes:

```bash
npm run visual-tour -- --theme light --page-match guru.com --item-selector '.jobRecord' --output docs/visual-tour/light
npm run visual-tour -- --theme dark --page-match guru.com --item-selector '.jobRecord' --output docs/visual-tour/dark
```

The default width matrix is `320,480,800` with a 900px viewport height. Override it when reviewing a breakpoint:

```bash
npm run visual-tour -- --widths 319,320,479,480,800 --page-match guru.com --item-selector '.jobRecord'
```

The harness creates a fresh draft, uses the page-side visual picker, walks Structure through Finish as far as the discovered data permits, and discards that draft. It never publishes. Pass `--keep-draft` only when debugging the generated state.

### V2 review surface route coverage (planned)

None of this section is implemented yet — `tests/visual-tour.test.js` does not capture any of these states today. Once the review overlay has an editor UI to drive it, the tour should capture a complete interaction chain through it so the source-linked paths are reproducible:

1. `Review · discovered fields` and the unresolved field table
2. `Automatic Run · stopped for review` with ranked uncertainty context
3. `Review · reuse correction preview` and `Review · map discovered field`
4. `Review · choose canonical identity`
5. `Review · ready to finish`

The interaction capture should treat all of these as review support-only states: source highlighting, semantic edits, and output serialization remain explicit and reversible until finish is confirmed.

Outputs are written under `tmp/visual-tour/<timestamp>/`:

- `index.html` is a contact sheet with one row per UI state and one column per width.
- `README.md` is a repository-friendly overview with representative screenshots, links to the complete screen galleries, and a Mermaid graph of the recorded navigation provenance.
- `screens/*.md` groups the complete responsive screenshot catalog into smaller documents by application route.
- `manifest.json` records the page, dimensions, scroll offsets, completion state, and every image.
- PNG files include vertical and horizontal tile suffixes when the complete UI does not fit in one viewport.

Run `npm run visual-tour -- --help` for all options. The script intentionally attaches to an already configured Chrome session instead of launching a sterile browser, so it exercises the installed extension, page-side picker, and real side-panel transport together.
