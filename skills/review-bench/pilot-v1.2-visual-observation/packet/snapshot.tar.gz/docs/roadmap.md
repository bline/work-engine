# Site2JSON roadmap

The current product direction is to finish the human-authored semantic workflow before automating it. The automated workflow must use the same inference, graph, discovery, validation, and review machinery as the manual editor.

The pre-release v2 architecture is specified in [S2J Markup and Semantic DOM architecture](artificial-semantic-dom.md). It introduces one normalized collection/entity/value format for DOM-backed, rendered-layout, and future screenshot-assisted grouping. The isolated executable scaffold lives in `extension/ir/`; it is intended to replace, not permanently coexist with, the original scope/field execution path once its fixture and real-page proving set passes.

The transition is an explicit architecture decision: [ADR 0001](adr/0001-semantic-dom-v2-transition.md). V1 is frozen except for defects that prevent a fair V1/V2 comparison. Additional V1-only polish and production Run work wait until the V2 proving slice is evaluated. The visual input axis is specified in [Screenshot, Rust, WASM, and OCR analysis](screenshot-semantic-dom.md).

## 0. Prove the S2J Markup V2 pipeline

Foundation implemented: wrapped cards and flat sibling sequences now enter one neutral-observation pipeline and materialize values into S2J Markup. A bounded joint semantic assignment stage ranks property and entity-type hypotheses together, retains competing mappings and margins, leaves ambiguous type-dependent properties unresolved, and serializes self-contained JSON-LD plus provenance. Its authoring-time profile compiler now resolves packaged Schema.org domains, ranges, relationship targets, selected semantic-composition paths, and installed local-vocabulary records into a compact versioned input; the runtime scorer has no catalog or storage dependency. Multiple fields coalesce under one related entity, deep authored paths serialize recursively, and custom relationships use the same runtime representation. `Product.offers -> Offer.price` restores Product classification in the flat heterogeneous fixture without inventing a direct Product price field. Bounded grouping inference proposes repeated sibling roots, heading-led flat sequences, and singleton landmarks, then ranks them by structural usefulness, repetition consistency, entity independence, and semantic coherence. Bounded field observation supplies neutral heading, canonical identity, prose, date, employment, author, price, and salary values without fixture-provided field selectors. With neither item nor field selectors supplied, V2 selects the wrapped cards, reconstructs the flat heterogeneous sequence, and accepts the reviewed WDC detail `main` as one `JobPosting` while rejecting duplicate fragment/SEO roots.

The semantic graph editor now exposes the first browser V2 action: **Preview live data** compiles the unsaved working graph, lazily injects the catalog-free V2 runtime into the current page, and renders its JSON-LD result without applying or mutating the adapter. Next, evolve that preview into the split graph/live-data correction surface and connect the accepted result to Automatic Run.

### V2 source-linked Review surface (first editor correction loop implemented)

`extension/ir/v2-review-surface.js` implements the source-linked, evidence-first derivation engine this review surface runs on. The semantic graph's V2 live preview now exposes its inferred entity types and field mappings as review cards keyed by stable Semantic DOM IDs. A user can select a ranked or searched term, explicitly leave a decision unresolved, and see the preview re-derived from an in-memory overlay without mutating either the observed evidence or the authored composition. The bridge returns a format-independent review index so markup, compact JSON, and JSON-LD remain views of the same decision state. Review decisions remain session-only, survive format changes and re-derivation, are visibly distinguished from inference, become stale when the authored graph changes, and clear when the preview closes.

Review-card selection now synchronizes the active markup, compact JSON, or JSON-LD path with the corresponding rendered-page source while preserving a distinct review focus from authored graph selection. These session-only decisions remain an inspection mechanism, not an accepted-result persistence workflow. Before connecting review to Automatic Run, migrate the applicable V2 detection work into the shared Visual Evidence workflow described below and route each correction according to whether it changes a type, page evidence, or the semantic graph.

### Shared Visual Evidence workflow

[Visual Evidence Authoring in the Detection-First Workflow](Visual-Evidence-Authoring-and-Detection-First-Semantic-Workflow.md) defines one reusable **full-panel workspace with a Back action**, not a centered dialog. It has two callers:

- The initial Detection surface invokes it when whole-page discovery found missing or incorrect page evidence for a discovered type or field. Accepted detections still seed the graph.
- The semantic graph invokes the same workspace when a newly added or changed Schema.org, custom, or imported type/field cannot be resolved automatically.

Automatic detection remains the first attempt in both places. Visual Evidence transfers ownership only for the field correspondence the user explicitly authors. V2 live-preview review stays separate: it may route an evidence-location problem into this workspace, a classification problem to the type selector, or a model problem to the graph, but its temporary overlay is not itself a durable visual hint.

The shared full-panel route now has Detection and Graph entry points using one structured, field-granular decision contract. Picking preserves automatic inference as the default, distinguishes authored and unresolved evidence, asks for an interpretation only when a rendered element is ambiguous, and restores the calling surface. These authoring decisions remain separate from the session-only V2 live-review overlay. The dedicated [Visual Evidence Architecture](visual-evidence-architecture.md) slice defines the authored observation, generalized visual binding, and scoring-input boundaries. Strict validators keep authoring observations separate from inert portable bindings. Detection and Graph now project canonical semantic targets from their actual model owners, and the picker plus current Page Analysis context normalize each click or explicit unresolved choice into a validated, session-only authored observation without parsing labels or promoting run-local IDs. The current UI remains inspection-only until the binding compiler, drift resolver, scoring tests, and persistence integration pass; only then should Automatic Run consume the decisions.

What the engine itself does today:

- Evidence snapshots are immutable: `buildEvidence` freezes the tree, findings, reports, output, and validation as a provenance bundle before any decision is applied.
- Review edits are overlay-only corrections: `derive` accepts structured `finding`/`type` decisions keyed by stable node IDs and computes an effective view without mutating the evidence bundle.
- Source and output remain synchronized through explicit IDs: page source previews are driven from source references tied to tree node IDs, markup-to-semantic assignment is rewritten in the derived overlay tree, and serialized JSON-LD and compact output are regenerated from the same effective decision state — including a rejected/unresolved decision, which must not leak its previously-attempted type into the serialized output.
- Corrections are rank-gated by uncertainty: the system surfaces ranked alternatives and margin-sensitive candidates for review before promotion, preserving unresolved ambiguity paths.
- `Thing` is a deliberate unresolved fallback, not a confident classification; accepted type claims require explicit evidence and rank support.

- Normalize Guru or Upwork wrapped cards into collection/entity/value nodes.
- Normalize a validated WDC singleton JobPosting detail page through the same representation.
- Normalize a structurally flat, heterogeneous search-results fixture without inventing DOM wrappers.
- Assign schema properties and relationships after segmentation rather than baking Schema.org claims into visual observations.
- Classify heterogeneous variants from S2J Markup shape, explicit evidence, and relationship coherence; retain winner, runner-up, margin, fallback, provenance, and Attention behavior.
- Serialize a self-contained direct extraction without requiring selectors or reusable bindings.
- Compare V1 and V2 output, explanations, confidence stops, and failure behavior.
- Remove obsolete V1 execution machinery after the fixture gate and representative real-page checks pass.

### Screenshot analysis spike

- Package a Rust/WASM worker-side analyzer behind one coarse request/response boundary.
- Evaluate `ocrs` for OCR text regions, reading order, confidence, model size, cold start, memory, latency, language coverage, zoom, and device-pixel-ratio behavior.
- Group flat visual title/URL/description observations into singular entities and a repeated collection.
- Emit materialized S2J Markup values with capture-region provenance; DOM correlation remains optional enrichment.
- Feed screenshot proposals through the same schema assignment, variant classifier, validator, and serializer as DOM proposals.

## 1. Polish the semantic graph editor

- Make type insertion and relationship creation predictable for Schema.org and custom vocabulary.
- Finish connection validation, ambiguous relationship selection, pending/cancel states, subtree deletion, keyboard controls, centering, and undo/redo.
- Keep the graph usable in the extension side panel at narrow and wide widths.
- Cover drag, connect, cancel, delete, pattern insertion, and invalid-graph behavior with interaction tests.

## 2. Complete the local semantic toolkit

- Build the Semantic Library manager against the storage-neutral service contract; do not expose IndexedDB, SQLite, or API transport details to its UI.
- Require every storage backend to pass the shared Semantic Library contract suite, including cursor paging, batching, capabilities, stable errors, and optimistic revisions.
- Store production library records in record-oriented IndexedDB stores and atomically migrate the legacy `chrome.storage.local` toolbox on first use. Record each catalog import under a UUID and provide revision-safe, atomic rollback from the Semantic Library's import history.
- Keep imports package-isolated: overlapping terms retain separate library-instance IDs and visible bundle provenance, while adapter materialization alone deduplicates equivalent canonical definitions.
- Save and reuse individual custom types and properties.
- Save a selected partial graph or a complete hierarchy as a named bundle.
- Insert a whole bundle or an individual type from it.
- Connect an inserted bundle to existing Schema.org or custom nodes using the normal relationship workflow.
- Search Schema.org types, custom types, saved patterns, and bundles through one interface, while clearly labeling their source.
- Keep imported source categories, mutable user tags, and curated collections distinct; support indexed filters and facet counts for all three.
- Provide a simple manager to preview, rename, duplicate, update, and delete toolkit content.
- Preserve required custom vocabulary, relationships, expectations, and provenance when copying or inserting a bundle.
- Remap graph aliases safely and reject namespace conflicts atomically.
- Share selected records, collections, graph bundles, or complete imported packages as validated `.site2json.json.gz` files. Keep the decompressed JSON contract versioned with a published JSON Schema; assign a fresh owning UUID on every import and never export database identity or revision metadata.

### Linked Open Vocabularies browser/importer

The first import paths are now working: individual class/property import and bounded vocabulary-subset import. Vocabulary/category metadata is cached locally from LovPortal; indexed term search and remote graph access are bounded explicit operations. Vocabulary selections persist across pages, resolve against a pinned LovPortal submission, optionally include in-vocabulary ancestors and direct properties, preview collisions without mutation, and commit locally through the atomic Semantic Library import boundary. Whole-vocabulary import, property-first browsing inside a package, saved update checks, and locally managed package records remain follow-up work.

- Treat LOV as a catalog of 900+ vocabulary packages, each containing its own classes, properties, relationships, namespace, and version/provenance metadata.
- Provide two complementary entry points: browse/search vocabulary packages, and full-text search for classes or properties across the entire catalog.
- Let users open a vocabulary to inspect its description, namespace, types, properties, relationships, and useful connected subsets before importing anything.
- Use LovPortal's public SPARQL mirror for explicit catalog metadata, category browsing, indexed term search, and graph enrichment; retain LOV as upstream curator provenance without requiring its slow live API. LovPortal's authenticated REST API remains an optional future provider rather than a required client dependency.
- Present LOV results alongside the other type-search results with their vocabulary, namespace, description, provenance, and import status visible.
- Let users copy an entire vocabulary package, an individual class/property, or a selected connected hierarchy into their local toolkit.
- Import the minimum required relationships and referenced terms for a usable subgraph, with a preview before saving.
- Preserve canonical identifiers and provenance while allowing an adapter-local alias or label.
- Detect collisions with existing Schema.org and custom terms before changing the toolkit.
- Keep imported content local and portable; published adapters must not require a live LOV connection.
- Treat mirror refresh and differences between imported and newer vocabulary versions as an explicit update operation, never a silent rewrite.
- Keep catalog providers behind one normalized client contract so a future local mirror/index can replace LOV discovery or LovPortal enrichment without changing the library manager.

## 3. Finish and test the manual authoring path

- Exercise Structure → Semantics → Discover → Review → Finish entirely in the extension side panel.
- Start a shared **Page Analysis** pass as soon as a blank draft opens: render Structure immediately, rank likely collection boundaries, analyze the leading boundary's semantic model and item variants, and cache the report by tab/frame/URL/document revision. Manual authoring may use the progressive leading result while bounded alternatives finish during idle time. Automatic Run must await the complete decision, validate the winning selector against the current page, and stop in Structure when the configured structural confidence or margin is not met.
- Run bounded initial item-type inference automatically when a block is created or reopened. The current pass samples up to 24 items evenly across the rendered population, scans at most 160 descendants per item, scores the de-duplicated page evidence against the catalog once, and performs bounded per-item classification. Stable invisible hooks such as `data-type`, `itemtype`, and semantic classes count as evidence without becoming extracted fields; an alternate type is only declared when the page supplies a deterministic distinguishing rule. The Semantics action is a refresh, not the first analysis.
- Use **Infer remaining steps** as the non-publishing test path for automatic authoring. It reuses completed Page Analysis, preserves existing manual decisions, infers confident semantic models and deterministic variants, discovers only fields allowed by the selected local semantic graph, and stops at Structure, Semantics, or Discover when evidence is insufficient. A completed pass opens Review with inferred decisions explicitly unreviewed; it does not build, extract, export, or publish.
- Corroborate every automatically mapped field with at least two independent evidence families and a safe runner-up margin. Stable DOM vocabulary, rendered value shape, semantic HTML structure, and cross-item population/cardinality may support a mapping; the selected ontology graph limits the candidates but does not count as proof by itself. Preserve the compact evidence report in the editable draft so Review and automatic confidence thresholds consume the same decision. Portable adapters may carry that report in the validated, inert top-level `authoring` envelope; extraction never reads it.
- Ensure every state has a clear next action and every failure returns to the relevant evidence and editor.
- Validate mixed variants, singleton pages, optional markup, generated classes, iframes, and reusable custom vocabulary.
- Expand the automated visual tour and end-to-end coverage across the supported panel widths and advanced graph modes.

## 4. Make Run the automatic workflow

The earlier **Automatic Run** concept becomes the final **Run** action. It applies top-ranked inference anywhere manual authoring requires a human selection:

1. Infer the extraction scope and collection/single-item behavior.
2. Infer the variant types likely present on the page.
3. Classify sampled items into those variants.
4. Discover fields allowed by the selected schemas and custom vocabulary.
5. Infer selectors, attributes, transforms, and semantic mappings.
6. Validate sample coverage and produce the adapter.

Every inference decision should expose:

- A confidence score.
- The margin between the first- and second-ranked candidates.
- A configurable failure threshold, initially grouped by decision category and optionally made decision-specific later.
- The evidence and ranked alternatives used to reach the decision.

Run must stop rather than guess when a threshold fails. It should open the side-panel editor at the unresolved step with its evidence, tentative work, ranked choices, and page highlights intact. Field discovery remains constrained to the inferred/selected semantic graph; it must not silently invent unrestricted fields or publish unexplained holes.

Run and review handoff follows rank gates and source-linked corrections:

- Run opens review only when configured margin and confidence gates fail, or when ranked alternatives keep a decision in uncertainty.
- unresolved `Thing` states remain explicit, replayable review inputs.
- user corrections stay on the review overlay; source highlights, markup nodes, and output rows all reflect the same effective choices.

Scope inference compares credible repeated collections with singleton-detail candidates rather than assuming any repetition is primary. Detail candidates include `main`, `article`, stable detail containers, and the smallest common parent joining an entity-like `<header>` to substantial sibling content. Repeated items inside related, recommended, or complementary regions are penalized; a detail wins when its heading and substantial non-repeated content remain after subtracting the candidate list, while a true results page wins when the repeated items dominate its meaningful content. A singleton is accepted only when both its structural boundary and inferred semantic model clear their configured thresholds, then represented by the same collection-shaped runtime block with one item. Manual single-item selection uses the same candidate scorer but may explicitly accept a lower-confidence boundary.

Scope confidence should remain decomposed into explainable axes rather than becoming one opaque score:

1. **Structural usefulness** — the boundary contains extractable evidence and avoids unstable or ineligible wrappers.
2. **Repetition consistency** — the candidate roots repeat a coherent evidence shape across the population.
3. **Entity independence** — each match is a distinct, sufficiently complete observation rather than a nested match, duplicate/SEO representation, or fragment of one detail entity. This axis gates high-confidence collection inference; a large repeated-family margin cannot override its failure. The initial implementation measures containment topology, per-root completeness, normalized identity distinctness, and severe size imbalance.
4. **Visual grouping and coherence** — use bounded rendered geometry and a small computed-style vocabulary (background, border, radius, shadow, spacing, alignment, and typography contrast) to support boundaries that visibly behave like repeated cards or grouped detail regions. Visual evidence is supportive, never required: themes, transparent layouts, missing CSS, and accessible plain documents must remain structurally inferable. Prefer computed style and geometry over image transfer; evaluate cropped screenshot analysis later only as an optional bounded fallback for visually ambiguous cases.

Bounded machine learning may later calibrate or combine these axes, but it must preserve their component evidence and must not override a failed hard-validity gate such as entity independence.

## 5. Build a reusable extraction knowledge loop

This work applies the useful parts of ontology-guided wrapper induction, OntoHuman, ConTrOn, and ODKE+ without putting an LLM or a live catalog service in the extraction path.

1. **Reusable property extraction profiles**
   - Extend Semantic Library properties with portable authoring metadata: alternate and negative aliases, expected units and value shapes, normalization hints, cardinality, semantic directness, salience, examples, and provenance.
   - Combine packaged Schema.org knowledge, imported vocabulary metadata, and user-local profiles through the existing bounded type-extraction profile.
   - Keep inference-only hints out of the production adapter DSL unless the runtime actually needs them.
   - Foundation implemented: local Semantic Library properties now carry validated, portable inference profiles with positive and negative aliases, expected shapes and units, editable cardinality and salience, examples, provenance, and pipelines restricted to packaged transforms. The shared scorer consumes these hints. Materially changed automatic decisions stop for review; an accepted decision snapshots the exact profile and counterfactual in the adapter's inert authoring receipt rather than making runtime behavior depend on the local library.

2. **Reviewed correction promotion**
   - Implemented: after a user corrects a semantic mapping, Review offers an explicit sanitized diff that can add an alias to the chosen local property and/or an exclusion to the rejected local property. Selectors and rendered text are excluded, writes are revision-checked, profile-influenced corrections are warned, and bounded provenance links the update to its originating adapter decision.
   - Keep selectors and site-specific structure in the adapter; promote only reusable terminology, value-shape, unit, or normalization knowledge.
   - Never silently mutate Schema.org, an imported package, or a shared profile. Record source and review provenance for every promoted cue.

3. **Global candidate arbitration**
   - Reconcile field candidates after independent scoring and before automatic acceptance.
   - Detect one evidence node claimed by incompatible properties, duplicate semantic fields, conflicting values for singular properties, unsupported nested mappings, and mappings that cross variant populations.
   - Consolidate equivalent candidates, retain ranked alternatives, and send unresolved conflicts to Review instead of guessing.
   - Foundation implemented: bounded whole-entity assignment now arbitrates duplicate property claims, rewards related nested paths and selected-composition relationships, preserves per-field counterfactual margins, and leaves unsupported choices unresolved.

4. **Information-directed Review**
   - Rank review work by evidence-family disagreement, winner/runner-up margin, semantic salience, number of affected items, and likely reusability of the correction.
   - Offer a focused **Review next** path while preserving the complete mapped and unresolved tables.
   - Treat review ordering as assistance only; it must not alter inference results or silently accept a decision.

5. **Semantic health baselines**
   - Complement structural fingerprints with bounded field coverage, value shape, cardinality, element/attribute kind, variant population, and candidate-margin baselines.
   - Detect selectors that still match after a redesign but now capture semantically different content.
   - Store no rendered page text in the baseline; expose drift evidence and require review before replacing an accepted baseline.

6. **Stage-aware confidence policy**
   - Separate candidate-generation, review-suggestion, one-time Run, and automatic-publication thresholds.
   - Calibrate Structure, Semantics, field mapping, and conflict arbitration independently behind one simple user-facing confidence preference initially.
   - Preserve raw component scores, winning margins, evidence families, applicable thresholds, and ranked alternatives so every stop is explainable.

Recommended sequence: property profiles and scoring first; correction promotion second; candidate arbitration third; information-directed Review fourth; semantic health baselines fifth. Stage-aware confidence is introduced with the scoring work and calibrated throughout the later slices.

## Later boundaries

- Remote adapter sources, directory watching, signing, and update channels remain separate distribution work.
- Shadow DOM traversal remains blocked on explicit DSL/runtime support for boundary crossing.
