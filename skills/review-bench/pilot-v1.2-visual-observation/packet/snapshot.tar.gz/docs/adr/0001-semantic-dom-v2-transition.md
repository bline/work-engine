# ADR 0001: Make S2J Markup the V2 extraction boundary

- Status: accepted
- Date: 2026-08-15
- Scope: pre-release architecture

## Decision

Site2JSON V2 will normalize page evidence into **S2J Markup** before assigning Schema.org or custom-vocabulary meaning. S2J Markup is the portable, versioned intermediate format; it is not inherently a reusable adapter or DSL. The **Semantic DOM** is the live in-memory tree/API materialized from that markup and may retain ephemeral browser references that the serialized format cannot.

The target pipeline is:

```text
page evidence
  -> segmentation and observation
  -> S2J Markup
  -> schema assignment and variant classification
  -> validation
  -> JSON or JSON-LD
```

DOM containment, rendered geometry, computed presentation, accessibility data, screenshots, and OCR may all create observations. An S2J Markup value may contain the extracted value directly. A live DOM reference or reusable source binding is optional enrichment used when it adds information or when the user explicitly builds a reusable adapter.

V1 is frozen except for defects that prevent a fair V1/V2 comparison. Production Run polish and additional V1-only variant UX are deferred while V2 is proved.

## Why

The V1 scope/field executor assumes that meaningful entities already exist as useful DOM boundaries. Real pages violate that assumption: one entity may be fragmented across containers, repeated markup may be duplicate SEO output, and visually obvious result groups may be structurally flat.

Normalizing all evidence into one collection/entity/value representation separates three decisions that were previously entangled:

1. Which observations form an entity?
2. Which schema properties and relationships explain its values?
3. Which candidate type best explains the complete entity shape?

The separation also lets DOM and screenshot analysis feed the same downstream mapper.

## Typeless observation precedes type inference

Both product entry points use the same ordering. Automatic Run and the manual wizard first infer groupings and materialize typeless S2J Markup. They do not narrow discovery to fields belonging to a type guessed in advance.

Property and entity-type assignment happens only after the available values, value shapes, repetition patterns, and nested relationships have been observed. The assignment stage jointly considers candidate field mappings, vocabulary domain/range compatibility, relationship coherence, distinguishing fields, declared metadata, page context, and locally installed vocabulary terms. A low-confidence decision remains unresolved or falls back to `Thing`; it does not erase the neutral observations.

The executable V2 pipeline implements this as a bounded set of whole-entity hypotheses. Each candidate type carries its best compatible property mapping for every neutral observation; type support and property compatibility are ranked together. Generic mappings can survive an unresolved type, while a type-dependent mapping remains unresolved when competing whole-entity hypotheses tie.

Vocabulary expansion is an authoring-time concern. A compiler resolves Schema.org domains, ranges, and relationship targets together with installed local-vocabulary records into a bounded, versioned profile. Runtime semantic assignment receives that compact profile; it does not load the generated Schema.org catalog, query IndexedDB, or depend on the semantic-library UI. This preserves identical decisions across installs when the same compiled profile is supplied and keeps the runtime payload bounded.

The profile may also contain reviewed relationship-materialization rules compiled from a selected semantic composition's typed edges and target-node priority fields. These let neutral observations support and coalesce into nested shapes such as `Product.offers -> Offer.price` without pretending that `price` is a direct Product property. Paths may contain multiple edges and may reference installed custom vocabulary, but they are bounded in composition count, edge count, depth, and materialization count. Arbitrary ontology reachability is insufficient: only explicit compiled rules may invent a nested entity at runtime.

This ordering avoids a circular dependency in which a tentative type controls which fields can be discovered and those restricted fields then appear to confirm the tentative type. It also lets heterogeneous collections emerge from per-entity evidence instead of requiring every possible result type to be known before discovery.

- **Automatic Run** accepts each grouping and semantic decision that clears its configured threshold, stopping for review at the first unresolved decision.
- **Manual authoring** exposes the same decisions so a person can correct a grouping, observation, property, relationship, or type.

Schema-specific transformations are delayed until semantic assignment. The typeless stage retains neutral materialized values, value-shape metadata, and optional source references so both paths remain explainable and reconstructable.

## Variant classification remains a distinct decision

Shared arbitration does not eliminate variants. After segmentation produces semantic entities and property assignment provides candidate shapes, variant classification chooses among types such as `Article`, `JobPosting`, and `Product`.

V2 retains these concepts:

- shape and explicit-evidence support;
- semantic relationship coherence;
- winner, runner-up, and margin;
- deterministic fallback behavior;
- nested alternatives such as `ListItem.item -> Article | JobPosting | Product`;
- explainable Attention and evidence-resolution workflows;
- explicit acceptance receipts for knowingly unresolved ambiguity.

V2 does not port V1's variant data structures verbatim. Classification consumes S2J Markup entities and observations rather than selectors, block indexes, or root/nested execution branches.

## Existing work disposition

### Carry forward conceptually

- joint and counterfactual scoring;
- confidence components and margins;
- hard validity gates;
- Attention and resolver interaction patterns;
- provenance and explanations;
- nested variant semantics;
- acceptance receipts and drift awareness.

### Redesign around S2J Markup

- variant-classifier inputs and reports;
- observation/shape fingerprints;
- receipt identity and invalidation;
- navigation destinations;
- schema assignment and relationship arbitration.

A V2 ambiguity receipt should identify the normalized observation pattern, S2J Markup shape, candidate-type set, applicable thresholds, and analyzer versions. It should not identify a V1 selector or sampled root index.

### Retire with V1

- selectors used as semantic evidence;
- DOM-bound structural fingerprints whose only consumer is the V1 executor;
- block/root indexes as semantic identities;
- separate root and nested variant execution plumbing;
- mandatory compilation into a reusable extraction DSL.

Some small algorithms and tests may be extracted from V1, but V2 must not inherit its accidental data-model boundaries merely to reuse code.

## Proof gate

V2 must work end to end on all of the following before V1 is removed:

1. Guru or Upwork wrapped result cards.
2. A validated WDC singleton JobPosting detail page.
3. A structurally flat search-results fixture with heterogeneous result types.

The proof includes segmentation, schema-property assignment, relationships, variant classification, explanations, and serialized output. V1 and V2 outputs and failure behavior should be compared during this period. Once V2 covers the required fixtures and real-page checks, obsolete V1 execution code and development DSLs may be deleted without compatibility support.

## Consequences

- New V1 polish requires a concrete comparison-blocking justification.
- V2 variant work starts early; it is not postponed until after segmentation.
- Direct extraction does not require selectors or durable bindings.
- Reusable adapter authoring becomes an optional compilation product built from observations that can be reconstructed reliably.
- Screenshot/OCR analysis produces the same S2J Markup as DOM analysis rather than creating a parallel product architecture.
