# Visual Evidence Architecture

**Status:** Authored-observation normalization and the observation/portable-binding
contracts are implemented and intentionally not wired to inference. Compilation,
resolution, scoring, persistence, and runtime integration remain proposed.

This document defines the boundary between the current Visual Evidence
workspace and the inference/runtime systems. The workspace may continue to be
used for inspection and authoring, but its decisions must not affect detection,
field ranking, Automatic Run, or adapter extraction until the contracts and
focused tests in this document exist.

## Decision summary

Visual evidence has three different representations:

1. **Authored observation** records the literal human action and its context.
   It is draft/authoring data and may refer to the current page only through
   bounded, serialized provenance. It never contains a live DOM node.
2. **Generalized visual binding** is the validated, portable description
   compiled from one or more observations. It contains reusable structural and
   rendered features, not a DOM reference, screen coordinate, or raw page
   text.
3. **Scoring input** is a bounded set of explainable support/conflict features
   produced when a binding is resolved against a page. It participates in the
   existing candidate ranking, margins, arbitration, and unresolved states.

The normal path is:

```text
human click
  -> authored observation
  -> binding compilation and same-page round trip
  -> page resolution / drift assessment
  -> visual scoring features
  -> ordinary candidate ranking and arbitration
  -> accepted, unresolved, or attention-required decision
```

The semantic assertion in a click is strong authored evidence: the user is
saying that this rendered thing means the selected semantic property. It still
enters ordinary candidate competition rather than becoming an unconditional
override, because contradictory page evidence and competing assignments remain
meaningful. The uncertainty that increases over time is primarily different:
whether the generalized binding still identifies that same intended thing on a
changed page.

This slice covers authored page hints produced by the picker. Screenshot/OCR
analysis is a separate visual observation producer: it may contribute neutral
page observations directly to S2J Markup, but it does not create an authored
observation unless a person explicitly confirms a page relationship through
this workflow.

## 1. Authored observation

An observation answers: **what did the person do, for which semantic target,
and in what repeated-group context?** It is not a selector and it is not yet a
runtime rule.

The proposed draft shape is:

```json
{
  "version": 1,
  "observationId": "vo-…",
  "status": "authored",
  "target": {
    "typeTerm": "https://schema.org/Article",
    "propertyTerm": "https://schema.org/headline",
    "path": "Article.headline",
    "variantKey": "Article"
  },
  "action": {
    "kind": "rendered-page-click",
    "frameUrl": "https://example.test/results",
    "element": {
      "tag": "h2",
      "role": "heading",
      "candidateFingerprints": ["…"]
    },
    "interpretation": {
      "kind": "text",
      "reader": "text"
    }
  },
  "repeatedGroup": {
    "mode": "many",
    "groupObservationId": "group-…",
    "selectedItemOrdinal": 3,
    "itemCountAtAuthoring": 20,
    "scopeFingerprint": "s2j1:…"
  },
  "provenance": {
    "source": "human-rendered-page-click",
    "authoredAt": "2026-08-17T12:00:00.000Z",
    "pickerVersion": 6,
    "pageRevision": "…"
  }
}
```

The exact target identity must be a semantic graph/property identity, not a
detection-run ID such as `group-1:0:title`. A detection-run ID may remain in
provenance for source highlighting, but it cannot be the durable owner of the
decision.

### Observation storage rules

Draft authoring metadata may retain:

- the selected semantic target and field path;
- the selected interpretation (`text`, URL, image source, or supported
  attribute) and its packaged reader;
- bounded page/frame provenance;
- the inferred repeated-group proposal, selected item context, and sample
  ordinals;
- bounded selector-candidate fingerprints and the original page-analysis
  revision;
- an unresolved reason, cancellation state, or compiler diagnostic; and
- a short display-only snapshot needed to explain the choice in the editor.

The display snapshot is not semantic knowledge. Raw text, opening tags,
attribute values, page coordinates, and live nodes are session evidence only;
if a draft retains any of them for explanation, they must be bounded and must
be excluded from the portable adapter. The current picker payload therefore
remains an input to this layer, not an adapter format.

One observation can describe a singleton or one member of a repeated group. A
group-level claim is stronger when observations from more than one item agree,
but one click must never be expanded into an unrecorded claim that every item
is identical. The observation retains the sample context so that the compiler
can distinguish “one example of a group pattern” from “validated across the
group.”

`status` belongs to the observation lifecycle only:

- `authored` — the user selected an interpretation;
- `unresolved` — the user intentionally left the target open, or the selection
  could not be interpreted; and
- `cancelled` — the workspace ended without changing the prior decision.

`stale`, `degraded`, and `active` are binding-resolution states, not authored
intent. A page changing must not rewrite what the person originally clicked.

## 2. Generalized visual binding

A binding answers: **what portable page relationship should be tried again?**
It is compiled only after a same-page round trip proves that it resolves the
intended source and reads the selected interpretation correctly.

The runtime binding should be a named source binding in the portable plan, in
the same family as the existing `selector`, `sequence`, and `literal`
bindings. A field references the binding by ID; authoring metadata does not
become a runtime dependency.

The existing `visual` branch in `extension/ir/source-bindings.js` is only a
placeholder that returns a literal value and requires a `profile` string. It
must not be treated as this contract or wired into inference. The contract
slice should replace or version that behavior after validator tests exist;
`profile` must not become an overloaded reference to the semantic assignment
profile.

The proposed conceptual shape is:

```json
{
  "kind": "visual",
  "version": 1,
  "scope": {
    "mode": "many",
    "rootCandidates": [
      { "kind": "stable-selector", "selector": ".result-card" },
      { "kind": "relative-structure", "tags": ["main", "article"] }
    ],
    "itemRelation": "descendant"
  },
  "target": {
    "relation": "descendant",
    "locatorCandidates": [
      { "kind": "stable-relative-selector", "selector": "h2" },
      { "kind": "relative-path", "tags": ["a", "h2"], "childIndexes": [0, 0] }
    ],
    "renderedRole": "heading",
    "tag": "h2",
    "reader": "text",
    "attribute": null
  },
  "layout": {
    "normalizedRect": { "x": 0.04, "y": 0.08, "width": 0.82, "height": 0.12 },
    "order": { "axis": "block", "rank": 1 }
  },
  "validation": {
    "uniqueness": "exactly-one-per-item",
    "minimumCoverage": 0.6,
    "maximumMultiplicity": 1,
    "shape": "text",
    "allowedRoleDrift": ["heading", "text"]
  },
  "baseline": {
    "scope": { "typical": 20, "minimum": 1 },
    "coverage": 1,
    "matchesPerItem": [1, 1],
    "shapeFingerprint": "s2j1:…"
  },
  "provenance": {
    "observationIds": ["vo-…"],
    "compiler": "visual-binding-compiler@1"
  }
}
```

This is a contract shape, not a commitment to persist CSS selectors exactly as
shown. The compiler should reuse the existing stable selector candidates,
scope inference, structural fingerprints, and packaged readers where they are
appropriate. It should emit several bounded locator/features when available,
rather than treating an `exactSelector` or coordinate as the binding.

### What may survive into the binding

- stable, validated selector or relative-structure candidates;
- relationship to a repeated item or singleton scope;
- element/tag/ARIA rendered role and the packaged value reader;
- normalized position and size relative to the item, as supportive evidence;
- reading order, multiplicity, and bounded geometry tolerances;
- text/value shape, not the observed text itself;
- bounded same-page coverage and cardinality baselines;
- a structural fingerprint that excludes page text, generated tokens, and
  executable content; and
- compiler and observation provenance sufficient to explain the binding.

### What must not survive into the binding

- live DOM nodes, `ownerDocument`, or extension/page object identities;
- raw page text, URLs used as field values, opening tags, or screenshots;
- viewport coordinates as the sole locator;
- a detection-run ID as the page identity;
- arbitrary JavaScript, page callbacks, or unbounded selector alternatives;
- semantic-library catalogs, IndexedDB IDs, or authoring-only dependencies; and
- a claim that the target is definitely the selected Schema.org property.

The binding is portable in the sense that another page load can validate it
from inert data. It is not required to succeed on every page revision. A
binding that cannot be compiled with a validated round trip remains a valid
one-shot authoring observation and is reported as `cannot-compile`; it is not
silently turned into a fragile runtime rule.

## 3. Scoring input

The resolver converts a binding plus the current page into a structured visual
evidence report. The scorer consumes features from that report; it does not
consume the authored observation directly. The report must keep two axes
separate:

1. **Semantic assertion** — strong, user-authored support for the selected
   semantic target.
2. **Binding applicability** — how reliably the generalized binding currently
   identifies the intended rendered source.

Binding applicability gates delivery of the semantic assertion to the current
page. It is not itself semantic proof. A stale binding does not weaken or
rewrite what the user meant; it means that the strong assertion cannot safely
be attached to a current candidate until the user re-authors or repairs the
binding.

```json
{
  "family": "authored-visual",
  "bindingId": "visual-binding-…",
  "observationIds": ["vo-…"],
  "status": "active",
  "semanticAssertion": {
    "target": "https://schema.org/headline",
    "source": "human-authored",
    "strength": "strong"
  },
  "bindingApplicability": {
    "status": "active",
    "confidence": "strong",
    "coverage": 0.9
  },
  "candidateId": "entity:3:value:7",
  "features": [
    {
      "kind": "authored-semantic-assertion",
      "outcome": "support",
      "strength": "strong",
      "delta": "calibrated",
      "reason": "The user identified this rendered source as Article.headline."
    },
    {
      "kind": "group-coverage",
      "outcome": "support",
      "strength": "moderate",
      "delta": 3,
      "reason": "The target resolves in 18 of 20 current items."
    }
  ],
  "contribution": {
    "raw": "scorer-calculated",
    "bounded": "scorer-calculated",
    "cap": "calibrated"
  },
  "provenance": {
    "resolutionMethod": "stable-relative-selector",
    "matchedCount": 18,
    "baselineCoverage": 1,
    "currentCoverage": 0.9
  }
}
```

The initial feature vocabulary should be small and mechanism-level. It should
distinguish semantic support from applicability diagnostics:

Semantic support:

- the strong human-authored assertion for the selected semantic target; and
- optional visual corroboration from rendered role/tag, value shape, and
  repeated-group relation.

Applicability diagnostics:

- unique target resolution and source identity;
- scope and repeated-item/group relation;
- reader compatibility and value-shape/multiplicity checks;
- coverage and population agreement;
- normalized layout/order compatibility; and
- ambiguity, missing target, scope mismatch, reader mismatch, or conflicting
  target as explicit applicability failures or degradations.

Geometry and style are supportive. A transparent or restyled page must remain
inferable through non-visual evidence, and a visually polished but structurally
ambiguous page must remain unresolved.

### Scoring rules

- Visual evidence is one provenance-preserving evidence family. Features from
  one binding are capped so selector, role, geometry, and coverage do not
  masquerade as independent human confirmations. The human semantic assertion
  is strong, but still remains a scored feature rather than an override.
- Score caps and deltas are calibration outputs, not part of this architecture
  contract. Do not make provisional values such as `+8` or `-6` sacred or
  hard-code them before measuring them against the existing scorer. The
  calibration harness should compare candidate ranking, margins, arbitration,
  and unresolved rates, then record the chosen policy and its version.
- Current candidate ranking, runner-up margins, global arbitration, and
  unresolved/Attention outcomes remain authoritative. Visual evidence can
  change the ranking; it cannot waive a failed margin or minimum score.
- If no automatic candidate represents the clicked location, the visual
  resolver may materialize a bounded neutral candidate for the scorer. It must
  be tagged as visual-origin evidence and still compete with all other
  candidates.
- An active binding allows the strong semantic assertion to contribute to the
  selected target. A degraded binding may allow an attenuated assertion and
  only the applicability features that still pass validation; it emits a
  visible finding. A stale or unresolved binding contributes no positive
  current-page score.
- Repeated items are not independent confirmations merely because the same
  binding resolves in many items. Group-level aggregation uses bounded,
  diminishing coverage features.

## Candidate generation versus hard constraints

The default policy is **bounded candidate generation plus scoring**, not
restriction.

The repeated-group context can limit where the visual resolver looks while
generating candidates. That is a search boundary, not a statement that other
automatically discovered candidates do not exist. The semantic target chosen
in the workspace adds context to the score for that target; it does not erase
competing property assignments or variant hypotheses.

A hard constraint is a different authored act. If the product later adds one,
it must be explicit (for example, a separately labelled **Pin this source**
operation), separately represented in ownership/provenance, validated against
the page, and subject to stale attention. A normal click and interpretation
choice do not create a hard constraint.

This preserves the distinction between:

- “the user supplied evidence that this location corresponds to `headline`”; and
- “the user explicitly took ownership of this source as a pinned rule.”

The latter is outside this slice.

## Ownership and representation boundaries

| Concern | Draft authoring metadata | Portable runtime adapter |
| --- | --- | --- |
| User action | click, interpretation, target, cancellation | not copied |
| Page context | bounded provenance, revision, group sample context | only data needed to validate the binding |
| Raw display details | optional bounded explanation snapshot | never |
| Live DOM references | session-only source-reference map | never |
| Generalized location | compiler input and diagnostics | validated named `visual` binding |
| Semantic intent | graph/property target and authored provenance | field reference to binding; no certainty claim |
| Drift | current resolution report and attention state | inert baseline/tolerances used to detect it |
| Scoring | authoring report and ranked alternatives | not executed by the extraction runtime unless a future inference plan explicitly requires it |

The adapter should not import the Semantic Library or authoring catalog merely
because a visual observation was created. A binding can carry a stable term
reference for provenance, but runtime resolution must depend only on its
validated inert plan.

## Binding lifecycle and drift

### Compilation on the authoring page

The compiler must:

1. validate the observation shape and semantic target;
2. reconstruct the selected source from stable candidates and repeated-group
   context;
3. verify exact source identity/order for the observed sample;
4. verify that the packaged reader reproduces the selected interpretation;
5. build a bounded text-free baseline for group population, coverage,
   multiplicity, role/tag, shape, and structural/layout features; and
6. return either a portable binding or a structured `cannot-compile` result.

The compiler must not mutate the observation into a selector or silently
discard an unresolved decision.

### Resolution on a later page

Resolution is side-effect-free and returns one of these states per binding:

- **active** — unique target(s), reader, scope, and required validation pass;
- **degraded** — the target remains uniquely identifiable, but optional
  coverage, layout, style, or population features drifted; reduced evidence and
  a review finding are emitted;
- **stale** — the durable scope/target no longer round-trips, required
  coverage/cardinality fails, the reader no longer matches, or the structural
  identity has changed; no positive evidence is emitted; and
- **unresolved** — multiple plausible targets or group interpretations remain;
  no positive evidence is emitted and the alternatives are retained for
  Review.

Examples of actionable findings include:

- “The visual target is unique in 18/20 items; two items have no matching
  heading.”
- “The stored item scope now matches one region instead of approximately 20.”
- “The selected source still matches, but now yields two values per item.”
- “Two heading-like descendants satisfy the visual binding; the evidence is
  unresolved.”
- “The target's value shape changed from URL to free text.”

This follows the existing structural-baseline policy: a legitimate redesign
requires explicit re-authoring or baseline refresh. A successful extraction or
successful selector match does not prove that the visual binding remains
correct.

## Proposed implementation slices

The following slices should be accepted in order. The existing UI may remain
available for inspection throughout, but inference wiring starts only after the
contract and resolver gates pass.

1. **Contract and boundary tests — implemented.**
   `extension/ir/visual-evidence-contract.js` separately validates draft
   observations and inert portable bindings. It rejects live objects,
   raw/unbounded data, unknown fields, unsafe readers, and invalid
   repeated-group state. Focused tests prove that an authoring observation is
   not accepted as a portable binding. Observation normalization now consumes
   the authoring validator; the portable-binding validator remains intentionally
   unwired until compilation and persistence integration.
2. **Observation normalization — implemented.** Detection projects targets from
   the effective Semantic DOM tree, findings, and type reports; Graph projects
   them from the authored nodes, relationships, root, and property reference.
   The picker contributes only the selected interpretation and inert element
   evidence, while current Page Analysis supplies document revision. The shared
   normalizer validates the resulting authored or explicitly unresolved
   observation, keeps detection-run IDs in provenance, and never derives
   semantic identity from display labels or graph aliases. Ambiguous graph
   routes remain unresolved.
3. **Binding compiler** — build the generalized binding from stable selector
   candidates, scope inference, relative structure, packaged readers, and
   text-free baselines. Reuse the durable round-trip reconstruction contract.
4. **Visual resolver and drift report** — resolve bindings against a new page,
   classify active/degraded/stale/unresolved, and return bounded findings and
   matched candidates without mutating the adapter or draft.
5. **Scoring adapter** — turn resolver reports into capped visual features;
   test candidate generation, conflicts, margins, arbitration, and unresolved
   behavior against lexical, structural, value-shape, population, and profile
   evidence.
6. **Draft and adapter persistence** — store observations in the authoring
   envelope and named bindings in the portable source-binding plan. Define
   export/import and revision behavior, including stale binding attention.
7. **Inference integration** — only now let Visual Evidence decisions create
   visual candidates/evidence in detection and Automatic Run. Keep the UI
   completion callback separate from inference application until the scoring
   report is available.
8. **Runtime extraction and review UI** — consume active portable bindings,
   expose drift findings near the affected field, and verify the real
   extension in both themes, panel widths, repeated groups, keyboard paths,
   cancellation, and unresolved states.

## Acceptance tests for this architecture slice

Before implementation proceeds beyond the UI boundary, the test suite should
cover at least:

- a click records the semantic target, interpretation, provenance, and
  repeated-item context without serializing a DOM node;
- a generalized binding contains no raw page text, coordinates-only locator,
  live object, catalog dependency, or executable code;
- the same page round-trips exactly, including reader and source identity;
- reordered repeated items still resolve by item-relative structure rather than
  selected ordinal;
- a vanished target, duplicate target, wrong reader, changed multiplicity, and
  changed group population produce distinct drift states;
- generated CSS tokens do not create false drift, while a semantically changed
  target does;
- stale/unresolved visual evidence contributes zero positive score;
- visual evidence changes ranking but preserves competing candidates and their
  margins;
- one click cannot automatically accept a candidate when the ordinary score
  or margin policy still fails;
- repeated matches do not multiply one authored observation into unbounded
  confidence; and
- draft observations are retained for review while the portable adapter
  contains only the validated generalized binding.

## Design-principle check

**Truth:** authored action, inferred binding, current resolution, drift, score,
and final decision remain separate. The system never treats a successful match
as proof of semantic correctness.

**Maintainability:** ownership transfers only for the field evidence the user
authored. Untouched fields and competing candidates remain automatically
maintainable, and stale bindings require focused attention rather than global
repair.

**Explainability:** every visual score feature has a resolution method,
coverage, reason, and source provenance. Drift reports say what changed, where,
and what the author can do next.

**Aesthetics:** the data model, UI state language, runtime boundaries, and
review surface use one coherent vocabulary. Visual emphasis remains a truthful
representation of recorded evidence and drift rather than a confidence
animation.
