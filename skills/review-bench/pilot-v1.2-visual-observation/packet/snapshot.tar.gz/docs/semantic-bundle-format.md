# Semantic bundle file format

Site2JSON Semantic Library bundles are portable, versioned JSON documents transported as gzip files. Their conventional filename suffix is `.site2json.json.gz`.

The normative schema for the decompressed version 1 payload is [semantic-bundle-v1.schema.json](../schemas/semantic-bundle-v1.schema.json). The schema uses JSON Schema draft 2020-12 and the stable identifier `https://site2json.dev/schemas/semantic-bundle-v1.schema.json`.

## Portable and local identities

The file contains semantic identities (`termId`, `patternId`, and canonical HTTP(S) URIs), definitions, graph relationships, and source provenance. It never contains IndexedDB keys, Semantic Library record IDs, import UUIDs, revision counters, or local timestamps.

Each import creates a new local package UUID. Importing the same file twice therefore creates two independently owned packages. Shared canonical types are deduplicated only when a package is materialized into an adapter draft.

## Payload shape

```json
{
  "$schema": "https://site2json.dev/schemas/semantic-bundle-v1.schema.json",
  "format": "site2json-semantic-bundle",
  "version": 1,
  "bundle": {
    "name": "Marketplace people",
    "description": "Reusable people and employer semantics.",
    "createdAt": "2026-08-13T16:00:00.000Z"
  },
  "records": {
    "types": [],
    "properties": [],
    "patterns": []
  }
}
```

Type and property definitions use Site2JSON's semantic DSL extension vocabulary. A property may also carry a versioned `authoringProfile` with portable inference-only hints; transform recommendations must name packaged Site2JSON transforms and are never executable code. Patterns contain the saved semantic graph (`root`, `nodes`, `edges`, and adapter-local `terms`). Source provenance may be retained at both bundle and record level, but local package bookkeeping is removed during export.

## Safety limits

The extension validates a file before writing anything to the Semantic Library. Version 1 accepts at most 16 MiB of compressed input, 64 MiB after decompression, 25,000 total records, and 40 levels of nested JSON. Unknown version-1 envelope and record fields, unsafe object keys, invalid graph references, and malformed gzip or UTF-8 JSON are rejected. The import preview is non-mutating.

Plain decompressed JSON is accepted by the core decoder for development and recovery, but the user interface exports gzip and treats direct JSON inspection as an advanced workflow.
