# Screenshot, Rust, WASM, and OCR analysis

Status: V2 design; implementation spike pending.

Screenshot analysis is an independent observation and segmentation axis that emits the same S2J Markup as DOM-backed analysis. It is especially valuable when the rendered page communicates entity boundaries visually but provides weak or flat DOM containment.

It is not required to recover DOM nodes or selectors. For direct extraction, OCR and visual analysis may materialize values directly in S2J Markup nodes.

## Pipeline

```text
captured page pixels + viewport metadata
                    |
                    v
          Rust/WASM visual analyzer
          - image preparation
          - OCR and text layout
          - visual region detection
          - entity grouping
          - observation provenance
                    |
                    v
            S2J Markup proposal
                    |
                    v
       shared schema assignment, variant
       classification, and arbitration
```

The visual analyzer determines what appears to belong together. The downstream semantic layer determines what those groups mean.

## Why Rust and WASM

Image analysis is a good bounded-compute boundary:

- Rust provides predictable memory ownership and access to image-processing libraries.
- WebAssembly keeps the analyzer packaged locally in the extension.
- The boundary can be crossed once per analysis with one binary request and one serialized response.
- CPU-heavy work can run away from the side-panel UI thread.
- The same core can be tested against static screenshot fixtures outside Chrome.

The first spike should use one coarse interface rather than many chatty calls:

```rust
pub fn analyze(request: &[u8]) -> Vec<u8>;
```

The request contains image bytes plus bounded capture metadata. The response contains a versioned S2J Markup proposal or a compact observation graph encoded as UTF-8 JSON bytes. A binary response format can be considered only after measurement shows JSON to be material overhead.

## OCR with `ocrs`

`ocrs` is a native Rust OCR engine with portable/WASM-oriented usage and structured text-layout output. It is a strong candidate for the spike because it is not a Tesseract wrapper and can live inside the Rust analysis pipeline.

OCR is one signal, not the complete visual analyzer. The pipeline also needs:

- text and non-text region geometry;
- reading order;
- alignment and repeated spacing;
- typography contrast and prominence;
- background, border, radius, shadow, and whitespace grouping;
- repeated group detection;
- confidence and alternative segmentations.

The spike must measure model and WASM size, cold start, peak memory, inference time, accuracy on normal web typography, supported scripts/languages, and behavior across zoom and device-pixel ratios. `ocrs` is currently an early project with limited language coverage, so it must remain replaceable behind the analyzer boundary.

## Semantic-DOM output

A visual value can be complete without a DOM binding:

```json
{
  "kind": "value",
  "propertyCandidate": "title",
  "value": "Senior Rust Engineer",
  "source": {
    "kind": "visual",
    "captureId": "capture-7",
    "region": [120, 240, 360, 32],
    "ocrConfidence": 0.96
  }
}
```

The visual analyzer should initially emit neutral roles such as heading, body text, price-like value, image, or repeated label rather than prematurely claiming a Schema.org property. Schema assignment then maps those observations to `title`, `description`, `price`, and other properties.

Images can be represented by a capture region, a derived crop, or packaged bytes according to the requested output policy. Pixel coordinates are evidence and provenance, not selectors.

## Optional browser enrichment

Pixels cannot reveal every value. A screenshot may display link text without its destination, an abbreviated date without its machine-readable value, or an image without its source URL. The browser may optionally enrich visual observations with:

- link destinations;
- `datetime`, `src`, `srcset`, `alt`, and ARIA values;
- browser text that avoids OCR errors;
- accessibility roles;
- ephemeral references for highlighting.

This enrichment is optional for the visual architecture. It does not make DOM correlation a prerequisite, and direct OCR extraction remains valid when no correlation is available.

If the user asks to create a reusable adapter, reliably correlated observations may additionally compile into bindings. Failure to create such bindings means only that the result is a one-shot extraction; it does not invalidate the S2J Markup already produced.

## Execution location and MV3 constraints

The analyzer should run in a dedicated worker owned by an extension page or an offscreen extension document. It should not block the service worker or page content script. The extension must bundle its WASM and model assets locally and declare the narrow extension-page content-security policy required to instantiate packaged WebAssembly.

The implementation must remain compatible with MV3 lifecycle constraints: the UI may disappear, the service worker may suspend, and analysis requests therefore need explicit ownership, cancellation, progress, timeout, and result persistence behavior.

## Shared arbitration

Visual proposals compete with DOM, accessibility, and semantic-attribute proposals through the same arbitration layer. Evidence families retain their provenance so that one analyzer cannot corroborate itself after normalization.

Visual analysis may:

- propose an entity boundary absent from the DOM;
- corroborate a DOM boundary;
- split a structurally broad container into visible entities;
- join structurally separate fragments into one visible entity.

It must not override hard contradictions such as duplicated identities, containment showing nested copies, or a candidate that cannot represent independent entities. The report retains alternatives and explains why a grouping won.

## First spike

The bounded proving slice is:

1. Capture a static screenshot fixture and its viewport metadata.
2. Run OCR and return text regions with confidence and reading order.
3. Group a flat title/URL/description result into one entity.
4. Detect repetition and emit a collection of equivalent entities.
5. Feed the proposal through the existing V2 S2J Markup validator.
6. Map observations to a simple result schema and serialize JSON.
7. Compare the output with DOM-backed normalization for the same fixture.

Success means the screenshot path produces valid, self-contained S2J Markup and useful grouping provenance. DOM correlation, adapter compilation, generalized computer vision, and production performance tuning are later slices.

## References

- [`ocrs` repository and WASM example](https://github.com/robertknight/ocrs)
- [Chrome extension Content Security Policy](https://developer.chrome.com/docs/extensions/reference/manifest/content-security-policy)
- [Chrome MV3 guidance for remotely hosted code and packaged WebAssembly](https://developer.chrome.com/docs/extensions/develop/migrate/remote-hosted-code)
