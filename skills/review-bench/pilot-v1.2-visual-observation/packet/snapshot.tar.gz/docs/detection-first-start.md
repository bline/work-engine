# Detection-First Start

The application begins by immediately running full detection and extracting the page.

The results are rendered as cards in the right panel. The goal is to let the user inspect, accept, reject, retype, and configure detection directly from the extracted result rather than beginning with a staged wizard.

## Implementation Status

The first implemented slice runs V2 page detection for a fresh draft and renders
the inferred groups as a responsive card grid. Every group remains explicitly
undecided until the author accepts or rejects it. Those review decisions retain
the detected type set and review time, and hovering a group, entity, or field
focuses its recorded source evidence on the currently open page. The screen also
offers an explicit manual-structure fallback and can rerun detection.

This slice samples only the page currently open in the side panel. It does not
yet implement the spatial layout, reverse page-to-card highlighting, type
correction, or wand-based evidence configuration. Accepted detections now seed
the semantic graph as initial adapter blocks so user-reviewed types begin the
semantics workflow.

## Result Cards

Each detected extraction is rendered as a card.

Cards have a consistent width and height. Each card shows:

* The detected Schema.org type and its icon.
* Extracted fields and their values.
* An acceptance state.
* A control for changing the detected type.
* A wand control for configuring detection.

Field values that do not fit within the card are truncated with an ellipsis. Hovering the truncated value reveals the complete value.

## Layout Modes

The result panel supports multiple layouts.

### Grid

Cards are arranged in an evenly spaced responsive grid.

This is the primary inspection layout and emphasizes the extracted semantic result.

### Spatial

Cards are placed according to the relative positions of their corresponding content on the source page.

Cards retain a consistent size rather than reproducing the dimensions of the source elements.

This layout emphasizes the relationship between the semantic extraction and the visual structure of the page.

## Two-Way Highlighting

The result panel and rendered page are linked.

Hovering a card's type icon highlights the complete corresponding visual object on the page.

Hovering a field within a card highlights the source element that produced that field.

The relationship also works in reverse.

Hovering content on the rendered page highlights the most specific corresponding extraction in the result panel. If necessary, the relevant card expands or otherwise reveals the matching field.

The result panel therefore acts as a semantic view of the rendered page rather than as a separate output surface.

## Acceptance State

Each detected type begins in an undecided state.

A question-mark icon represents this state.

Hovering the control reveals two additional actions:

* Green checkmark — accept the detected extraction.
* Red trashcan — reject the detected extraction.

Selecting an action replaces the question mark with the selected state.

The user can move freely between undecided, accepted, and rejected states.

Small animations may be used to make state changes visually clear.

## Repeating Structures

Instances belonging to the same detected repeating structure are treated as one logical group.

The cards are placed inside a shared visual container, using a subtle color or other restrained treatment to make the relationship apparent.

The group container includes:

* A repeating-structure icon.
* A visible label or tooltip identifying the structure as repeating.
* A single tri-state acceptance control for the entire group.

The group is atomic for acceptance purposes. Individual instances do not need separate acceptance overrides.

Content that is outside the detected repeating structure is treated as a separate extraction rather than forcing the interface to accommodate arbitrary exceptions within the group.

## Changing the Detected Type

Clicking the type icon opens the type selector.

The selector becomes a full-panel modal or equivalent full-width interface when space is limited.

Because Schema.org contains more than 900 types, the selector uses autocomplete rather than requiring the user to browse the complete hierarchy.

Selecting a type immediately applies it.

There is no additional confirmation step.

A Cancel action closes the selector without changing the type.

If the type has been changed from the detector's original choice, a subdued, partially transparent Undo control appears over or near the type icon.

Undo restores the detected type.

## Configure Detection

Each card or repeating group includes a wand control.

The wand opens a workflow for providing visual hints that improve detection.

The purpose of this workflow is not merely to edit the current extracted value. It configures how the detector should recognize the semantic structure and its fields.

### Workflow

1. Select the type to configure, or leave the detected type unchanged.
2. Select the fields to configure, or choose all fields.
3. The first selected field is highlighted in the result panel.
4. The interface asks the user to click the corresponding visual content in the rendered page.
5. The user clicks the source element.
6. If the visual selection is ambiguous, a contextual menu appears near the pointer with the available interpretations.
7. Once resolved, the selected visual evidence is associated with the schema field.
8. The field visually transitions into a resolved state, such as its label animating toward the schema field and the field becoming a green checkmark.
9. The next selected field becomes active.
10. The process continues until all selected fields have visual hints.

## Graph Initialization

The accepted detection results become the initial semantic graph.

When the user proceeds to the graph editor, all accepted Schema.org types are already present as nodes. Repeating structures produce the appropriate type representation rather than one graph node per extracted instance.

Any type corrections made during detection are reflected in the graph, so the graph editor begins from the user's reviewed semantic interpretation of the page rather than from an empty canvas.

This changes the role of the graph editor. The user does not begin by recreating types that have already been discovered. Instead, the graph step focuses on relationships, composition, cardinality, and other semantic structure that cannot be reliably inferred from the individual detections alone.

That last part is the big win to me.

The new progression becomes:

**Detect the things → decide which things matter → graph how those things relate.**

That's much more natural than opening an empty graph and asking the user to construct ontology nodes before the system has shown them what it actually sees on the page.

And because type changes happen during the first screen, when you enter Semantics you're not preloading **the detector's schemas**—you're preloading **the user's reviewed schemas**. That's an important distinction.


A lightweight completion state may be shown when all selected fields have been configured.

The user then returns to the main result view.

## Incremental Re-Detection

Changing detection hints should not require rediscovering the entire page when the affected scope is known.

After a configuration change, detection is rerun only for the structures or fields affected by that change.

Unaffected cards and groups remain stable.

This preserves visual continuity and lets the user immediately see the consequence of the new detection hint.

## Interaction Model

The opening workflow becomes:

**Detect → inspect → accept/reject → correct type → configure detection where necessary.**

The system performs the broad discovery work first.

The user supplies judgment and additional visual evidence only where the automatic result needs correction or refinement.
