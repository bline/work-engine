# WDC Page Analysis Corpus

> Research proposal for using Web Data Commons declarations and corresponding Common Crawl HTML to improve Site2JSON's initial scope-and-type inference.

**Status:** proposed. This document defines a bounded validation project, not a production dependency or a commitment to a particular machine-learning architecture.

## 1. Thesis

The highest-leverage hypothesis for using the Web Data Commons Schema.org corpus is to improve Site2JSON's first automatic decision:

> Which rendered boundary represents the relevant item population—one item or many—and which semantic type best describes it?

This is the hardest inference in the authoring chain because it runs before an author has supplied a scope, type, or composition. A wrong decision contaminates every later stage. A correct decision gives field discovery a bounded population, gives semantic mapping a relevant property graph, and makes variant classification, selector selection, and review substantially easier.

WDC provides a weak but unusually large supervision signal:

```text
publisher-declared Schema.org type
                 +
corresponding page HTML from the same crawl
                 =
one observed presentation environment for that type
```

The declaration does not prove that the type is correct, primary, visible, or represented by a particular DOM boundary. It says only that the publisher declared an entity of that type on that page. At sufficient scale, and after aggressive filtering and value-to-DOM alignment, those noisy type-page pairs can support:

- a cross-domain benchmark for the current Page Analysis heuristics;
- confidence and margin calibration;
- learned ranking of existing scope/type candidates;
- structural archetypes for synthetic training data; and
- later comparison with consented telemetry from genuinely rendered pages.

The immediate deliverable should be a high-precision evaluation corpus for the current inference system. ML is a later consumer of the same data pipeline. This document does not assume that highest leverage implies fastest or lowest-risk return: exact crawl recovery and DOM alignment are feasibility gates, and cheaper WDC uses should be compared against the corpus before it becomes a large investment.

## 2. Why this decision has the highest leverage

The automatic authoring chain is conditional:

```text
page
  -> candidate scope shape and boundary
  -> semantic type or composition
  -> accepted block
       -> bounded observations
            +-> field discovery, property paths, transforms, and selectors
            +-> optional item-variant authoring from per-item observations
  -> reviewed adapter
```

The initial scope-and-type decision narrows the search space for the work that follows; the complete authoring system is not a strictly linear narrowing pipeline. If Page Analysis selects the correct `JobPosting` card population, field discovery sees peer observations, the property catalog is bounded, and the global mapping arbitrator can compare plausible paths. If Page Analysis selects a recommendation carousel or labels the main article as `Product`, downstream confidence is misleading even when every later component behaves correctly.

Site2JSON's output model remains a collection even when a page exposes only one item. The editor's `single` and `collection` modes are structural search paths and observed page cardinalities, not competing output data models. Within a session, a later detail-page extraction can enrich the identified item already present in the collection. The first corpus evaluates page-local boundary and type inference; session-level item identity and enrichment are a later extension.

Item-variant classification is a sibling concern, not part of the scope/type target proposed here. Its authoring path consumes per-item observations, and its runtime path extracts candidate semantic shapes before classifying them. The WDC corpus may later supply useful mixed-type pages, but the first benchmark does not claim to label or evaluate item variants.

WDC property frequencies and graph co-occurrences could also improve authoring priors, but those are incremental improvements. A WDC-derived Page Analysis corpus targets the decision with the largest downstream error multiplier and creates a reusable asset for testing, heuristic tuning, ML, and synthetic generation.

That establishes the potential impact, not the expected return on engineering effort. The Page Analysis corpus has higher join and labeling risk than statistics derived directly from WDC tables. Its priority should be earned through a bounded feasibility comparison, not inferred from leverage alone.

## 3. Current implementation seam

The proposed corpus aligns with existing modules rather than requiring a parallel inference system.

### 3.1 Structural candidate generation

[`extension/editor/evidence-scope.js`](../extension/editor/evidence-scope.js) implements the page-wide structural scan used by automatic authoring.

`Site2JsonEvidenceScope.find(document, options)` currently:

- scans bounded evidence nodes for URLs, headings, dates, money, images, percentages, and useful text;
- ranks repeated entity boundaries through `findRepeating()`;
- ranks one-item/detail roots through `findSingleton()`;
- penalizes navigation, related, recommended, complementary, and selector-fragility signals;
- compares a strong repeated population with plausible primary detail content; and
- returns a repeated-population or one-item/detail boundary winner, alternatives, structural confidence, margin, and arbitration evidence.

Those result modes retain their current code names, `collection` and `single`, in captured reports. They do not imply that Site2JSON emits a non-collection result for a one-item page.

The production bridge calls it with a candidate limit of eight in [`extension/editor/sidebar-page-bridge.js`](../extension/editor/sidebar-page-bridge.js):

```js
Site2JsonEvidenceScope.find(document, { candidateLimit: 8 })
```

This is the first benchmark boundary. For a labeled page, did the correct entity boundary appear anywhere in the bounded candidate set?

### 3.2 Page Analysis orchestration

[`extension/authoring/page-analysis.js`](../extension/authoring/page-analysis.js) separates page scanning from per-candidate semantic analysis. It:

- caches work by tab, frame, URL, and document revision;
- analyzes the leading structural candidate progressively;
- analyzes a bounded set of alternatives when the leader is uncertain;
- retains the structural confidence and winner margin; and
- applies a separate semantic-confidence requirement to the `single` structural path.

The editor currently configures Page Analysis in [`extension/editor/sidebar.mjs`](../extension/editor/sidebar.mjs) with:

```js
candidateLimit: 3
minConfidence: "high"
minMargin: 10
```

The `single` structural path also requires high semantic confidence. The `collection` structural path's Page Analysis boundary decision is structural; its semantic recommendation is analyzed and carried forward, while the later automatic-run gate evaluates semantic confidence separately. These are explicit calibration policies and internal path names, not different output models or facts about the web. A WDC benchmark can measure structural and semantic risk-coverage separately and jointly across unseen domains.

### 3.3 Semantic ranking

For each scope candidate, the editor discovers bounded observations and calls [`extension/editor/semantic-ranking.js`](../extension/editor/semantic-ranking.js). That module scores Schema.org types and packaged or local compositions using:

- stable DOM tokens;
- explicit element and attribute structure;
- value shapes;
- property compatibility;
- composition expectations; and
- evidence for related nodes.

The editor currently treats a recommendation as high confidence when the winner explains at least three observations, scores at least 24, and has a margin of at least six points or 12 percent of its score. The search is already bounded to a type shortlist. WDC type labels can evaluate ranking recall and calibration without changing this evidence model.

### 3.4 Downstream behavior

[`extension/authoring/automatic-conversion.js`](../extension/authoring/automatic-conversion.js) currently evaluates scope, scope margin, semantic model, optional variant classification, field mapping, and extraction as separate run and publication signals. The proposed corpus concerns the scope and semantic-model signals. A learned Page Analysis score may eventually supplement those signals, but it must not turn a weak WDC label into reviewed adapter meaning or bypass the later variant, field, and extraction gates.

Existing fixture tests already exercise important Page Analysis behavior in [`tests/page-analysis.test.js`](../tests/page-analysis.test.js), [`tests/scope-inference.test.js`](../tests/scope-inference.test.js), and [`tests/editor-sidebar.test.js`](../tests/editor-sidebar.test.js). The corpus harness should call the same modules and return the same report shapes so research results correspond to product behavior.

### 3.5 Boundary with item variants

The editor currently performs an initial variant preview while analyzing a Page Analysis candidate in [`extension/editor/sidebar.mjs`](../extension/editor/sidebar.mjs). That preview is useful UI context, but `PageAnalysis` itself accepts an injected `analyzeScope()` function and does not use variant results in its structural decision or `single`-path semantic-confidence gate.

Runtime variant classification is implemented separately in [`extension/core/dsl.js`](../extension/core/dsl.js) and [`extension/core/variant-classifier.js`](../extension/core/variant-classifier.js). For every candidate type, the DSL first extracts the candidate entity and its semantic-shape signals, then asks the bounded classifier to select a winner or retain the declared fallback.

The first WDC corpus therefore measures the two outputs and their joint correctness:

```text
page -> scope candidates -> selected scope boundary
                         -> semantic type recommendation for each analyzed boundary
                         -> downstream structural and semantic gates
```

It does not measure:

```text
accepted mixed population -> per-item candidate type classification
```

Phase 0 and Phase 1 can proceed while variant authoring evolves because they depend on crawl recovery, declarations, DOM alignment, and structural scope candidates. Before Phase 2 records a product baseline, the experiment must pin the exact Page Analysis, evidence-scope, semantic-ranking, and report-contract revisions. Variant preview output may be recorded as auxiliary data, but it is neither a label target nor a benchmark eligibility requirement in the initial corpus.

## 4. What WDC supplies—and what it does not

The WDC Schema.org corpus described in [`docs/WDC.md`](WDC.md) retains publisher declarations and the source page URL. Class-specific subsets include the selected entity and other entities declared on the same page.

Potentially available supervision includes:

- one or more declared Schema.org types;
- declared property values and linked entity structure;
- the source URL;
- crawl/release provenance; and
- corresponding raw HTML when the source URL can be resolved to the correct Common Crawl snapshot.

WDC does **not** directly supply:

- a verified primary page type;
- a DOM scope for the declared entity;
- a verified page role, observed item cardinality, or session-enrichment target;
- rendered browser state after client-side execution;
- assurance that declared values are visible;
- assurance that the declaration is correct; or
- reviewed Site2JSON output.

The project must therefore call these **weak labels**, never ground truth. Human-reviewed records are the only gold labels.

### 4.1 Raw class subsets versus the Table Corpus

The Schema.org Table Corpus is useful for low-cost property prevalence, nested-value realization, and value-shape analysis, but it is not an interchangeable source for the Page Analysis benchmark. Its construction deliberately removes listing pages and sparse entities to retain attribute-rich detail entities. A single-entity page survives only when the entity has at least three attributes. On a page with several relevant entities, the builder retains entities only when their concatenated value length is greater than the page median plus three mean absolute deviations and they have at least three attributes; if there is no such positive outlier, it discards the page's relevant entities. Final tables also omit columns below a 25 percent density threshold.

Consequences:

- Table Corpus distributions describe a filtered attribute-rich population, not deployed Schema.org usage generally.
- They may provide useful priors for one-item/detail pages and for semantic-ranking ties.
- They are unsuitable for estimating collection-page frequency, repeated-card structure, or `findRepeating()` performance.
- The Page Analysis collection benchmark must sample the raw WDC class-specific data or another source that has not removed listing populations.
- Any generated prior artifact must record this selection policy and must not count as observed page evidence.

### 4.2 PAVE boundary

WDC PAVE provides human-reviewed product attribute-value pairs from product titles, descriptions, and, for a minority of its source corpus, extracted specification-table content. Its attributes are category-specific product characteristics rather than DOM scopes or Schema.org property paths, and its position metadata identifies title/description occurrence rather than DOM location.

PAVE can support value normalization, text-attribute experiments, realistic product values, and possibly a narrow linkage study through its offer identifiers. It is not a substitute gold set for Site2JSON scope detection or DOM-to-Schema.org field mapping. Before pursuing its much larger source HTML corpus, a bounded check must establish whether PAVE identifiers join to selectively retrievable offer records and whether its position annotations add value beyond the supplied title and description.

## 5. Corpus construction

### 5.1 Recover the matching crawl document

The first feasibility question is whether a WDC source URL can be joined reliably to the corresponding HTML response from the Common Crawl release that WDC processed.

The corpus builder should record:

- WDC release and source artifact;
- Common Crawl collection identifier;
- requested and final URL when known;
- WARC locator or equivalent immutable snapshot identity;
- HTTP status and content type;
- byte digest of the recovered response;
- declared entity digest; and
- every filtering or rejection reason.

Fetching the current live URL is not an acceptable substitute: the page may have changed, disappeared, or acquired unrelated declarations. If the exact or defensibly corresponding crawl document cannot be identified, the example should be excluded from aligned evaluation.

### 5.2 Parse without executing the page

Initial experiments should load recovered HTML into the same DOM implementation used by repository tests and run the packaged Site2JSON modules without executing page scripts or issuing subresource requests.

This differs from the browser product, which sees a rendered document. The corpus must record the observation mode:

```text
common-crawl-static-html
site2json-rendered-fixture
consented-rendered-telemetry
```

Results from these modes must not be pooled without reporting their separate performance. Common Crawl data is expected to overrepresent server-rendered sites and underrepresent client-rendered applications.

### 5.3 Normalize declared entities conservatively

Normalization may canonicalize mechanical representation differences, but it must preserve the original declaration. Each entity should retain:

```text
declared     publisher data as extracted by WDC
normalized   mechanically canonicalized representation
verified     optional human-reviewed interpretation
```

Mechanical normalization may resolve namespace spelling, scalar-versus-array packaging, and safe identifier forms when the operation is fully recorded. It must not silently repair semantic type or property claims.

Declaration quality and DOM alignment quality are independent assessments. A clean declaration may have no visible representation in static HTML, while a questionable declaration may correspond to an obvious rendered entity. The corpus must preserve that distinction rather than reducing both phenomena to one `usable` flag.

Declaration assessment should classify at least:

- whether the extracted declaration can be parsed and retained;
- whether only mechanical normalization is required;
- whether terms, datatypes, or graph structure conflict with vocabulary expectations;
- whether a possible repair would require semantic judgment; and
- which, if any, normalizations were actually applied.

`Repairable` must not be used as an undifferentiated category. A namespace spelling or equivalent scalar packaging may be mechanically normalizable; moving a property, introducing an intermediate entity, or choosing a different type may change meaning and requires review. Schema.org domain and range declarations guide this assessment but are not treated as closed-world validation rules.

A diagnostic finding may use a shape such as:

```json
{
  "code": "range.literalInsteadOfEntity",
  "path": "offers",
  "severity": "warning",
  "repairability": "requires-review",
  "suggestedInterpretations": ["Text", "Offer"],
  "applied": false
}
```

Useful initial compatibility classes are:

```text
clean
mechanically-normalizable
vocabulary-conflict
graph-structure-issue
semantic-ambiguity
unparseable
```

These classes are diagnostic. They do not themselves decide whether the declared base type is a usable weak label.

This assessment belongs to the offline corpus builder. Site2JSON does not currently ship a general validator or repair engine for arbitrary publisher-declared Schema.org markup. The pilot should implement only the diagnostics needed to characterize label quality; it must not create such a product subsystem as incidental scope.

### 5.4 Align declared values to DOM evidence

Declared values can weakly locate an entity within the page. Useful alignment families include:

- canonical or entity URLs;
- identifiers;
- titles and names;
- image URLs and alternative text;
- organization names;
- dates and times;
- prices and currencies;
- addresses and locations; and
- distinctive short literal values.

One exact text match is insufficient. Alignment confidence should reward independent evidence families and penalize values repeated throughout the page.

A possible alignment report is:

```json
{
  "entityType": "JobPosting",
  "candidateId": "scope-4",
  "matchedProperties": [
    { "path": "title", "family": "text", "quality": "exact" },
    { "path": "url", "family": "url", "quality": "canonical" },
    { "path": "hiringOrganization.name", "family": "text", "quality": "normalized" }
  ],
  "independentFamilies": ["text", "url"],
  "competingCandidates": 1,
  "confidence": "silver-high"
}
```

Dates and currency require particular care: many unrelated values can share the same normalized shape. Shape compatibility helps locate candidates but does not establish semantic identity.

### 5.5 Label a scope/type pair

The primary learning object is not a whole-page type. It is a joint candidate:

```text
(scope boundary, Schema.org type, page shape, optional role)
```

The corpus builder should run `Site2JsonEvidenceScope.find()` first and align declared entities against every returned candidate. This directly distinguishes two failure modes:

- **candidate-generation failure:** no returned boundary contains the aligned entity;
- **ranking failure:** the correct boundary exists but is not selected.

Where no candidate can be labeled confidently, the page may still be retained as a page-level positive bag for later multiple-instance learning:

> At least one region on this page expresses the declared type, but the region is unknown.

### 5.6 Estimate page role: primary detail, listing population, related, or unknown

A declaration means “present on the page,” not “the page is about this entity.” Role labels require additional evidence.

Signals supporting a primary entity include:

- entity `url` or `@id` agreement with the canonical page URL;
- `mainEntity` or `mainEntityOfPage` linkage;
- agreement with the document title, primary heading, or OpenGraph subject;
- aligned values concentrated in a dominant main/article region;
- substantial meaningful content outside competing repeated regions; and
- no related, recommended, sidebar, or complementary context around the boundary.

Signals supporting a listing or repeated population include:

- several declared entities of the same type;
- alignment to repeated sibling scopes;
- distinct entity identities within those scopes;
- a repeated region that dominates meaningful page content; and
- entity URLs distinct from the collection page URL.

When the evidence does not distinguish primary from related content, role must remain `unknown`. Type-and-scope training should not require a role label for every example.

## 6. Label tiers

### Gold

Human-reviewed type, scope, shape, and role. Gold records are expensive and should be reserved for evaluation, calibration, and adjudicating silver-label policy.

### Silver

Automatically aligned records that satisfy a versioned high-precision policy. Silver labels should require several independent facts, such as canonical identity agreement plus multiple values concentrated in one candidate with no close competitor.

Silver records form the main heuristic-tuning and supervised-training population. Every record carries its evidence so the policy can be rerun when alignment improves.

### Bronze

The page reliably declares the type, but the scope or role is uncertain. Bronze examples can support page representation learning, type-occurrence prediction, clustering, and multiple-instance learning. They must not be scored as exact scope labels.

### Rejected

Examples should be rejected when the snapshot is uncertain, the response is not useful HTML, the declaration cannot be associated with visible evidence, the page is only a client-rendering shell, candidates are irreducibly ambiguous, or the markup is malformed beyond conservative normalization.

WDC's scale makes aggressive rejection a feature. A smaller diverse corpus with precise labels is preferable to millions of confident-looking errors.

Rejection is task-specific. An example rejected from exact scope/type supervision may remain useful in a diagnostic partition for declaration-quality measurement, static-versus-rendered analysis, page-level representation learning, or adversarial fixture generation. The corpus should retain a versioned eligibility decision per task instead of treating rejection as deletion.

## 7. Orthogonal quality assessments

Every retained example should record declaration assessment, DOM-alignment assessment, and derived label eligibility separately.

| Declaration assessment | DOM alignment | Likely use |
|---|---|---|
| Clean or mechanically normalizable | Strong | Best silver-label candidate |
| Clean or mechanically normalizable | Weak or absent | Invisible declaration, client-rendering gap, or alignment failure analysis |
| Questionable | Strong | Declaration-quality research and possible reviewed label |
| Questionable | Weak or absent | Diagnostic or rejected population |

This separation prevents four different phenomena from being hidden behind one confidence value:

- whether WDC recovered a structurally usable declaration;
- whether its vocabulary and graph claims are compatible;
- whether its values have a visible representation in the recovered HTML; and
- whether a particular scope, type, shape, or role label is precise enough for a benchmark.

The derived eligibility policy should name the task explicitly. A record might be eligible for page-level type-occurrence pretraining but ineligible for exact scope evaluation or primary-role evaluation.

## 8. Proposed record contract

The research representation should be versioned independently of adapter DSL and semantic bundle formats.

```json
{
  "format": "site2json-wdc-page-analysis-example",
  "version": 1,
  "exampleId": "sha256:...",
  "source": {
    "wdcRelease": "2024",
    "commonCrawlCollection": "...",
    "snapshotId": "...",
    "responseSha256": "sha256:...",
    "observationMode": "common-crawl-static-html"
  },
  "partition": {
    "hostKey": "sha256:...",
    "templateCluster": null
  },
  "declarations": {
    "types": ["JobPosting", "Organization"],
    "entityDigest": "sha256:...",
    "assessment": {
      "parseStatus": "usable",
      "vocabularyCompatibility": "mechanically-normalizable",
      "findings": [],
      "normalizationsApplied": [],
      "semanticRepairApplied": false
    }
  },
  "pageAnalysis": {
    "implementationVersion": 1,
    "report": {},
    "candidates": []
  },
  "alignmentAssessment": {
    "status": "aligned",
    "tier": "silver-high",
    "visible": true,
    "scopeCandidateId": "scope-4",
    "independentFamilies": ["text", "url"],
    "competingCandidates": 0
  },
  "labels": [
    {
      "type": "JobPosting",
      "scopeCandidateId": "scope-4",
      "observedItemCount": 1,
      "pageRole": "primary-detail",
      "tier": "silver",
      "alignment": {}
    }
  ],
  "eligibility": {
    "scopeTypeBenchmark": true,
    "cardinalityBenchmark": true,
    "pageRoleBenchmark": true,
    "sessionEnrichmentBenchmark": false,
    "pageTypePretraining": true,
    "reason": "high-precision-primary-alignment"
  },
  "review": null,
  "rejections": []
}
```

Research records may refer to separately controlled raw inputs. Portable benchmark fixtures should be scrubbed and minimized under the same principles used by the existing fixture preprocessor. Raw URLs, page text, and HTML should not be assumed safe to redistribute.

## 9. Evaluation

### 9.1 Decompose the first inference

End-to-end accuracy alone cannot identify what to improve. The harness should report:

| Result | Interpretation |
|---|---|
| Correct scope absent | Candidate-generation failure |
| Correct scope present but ranked low | Structural-ranking failure |
| Correct type absent from shortlist | Semantic candidate-generation failure |
| Correct scope/type pair present but ranked low | Joint-ranking failure |
| Correct winner below threshold | Calibration or evidence-strength failure |
| Wrong winner above automatic threshold | Dangerous false acceptance |

### 9.2 Primary metrics

- scope candidate recall at 1, 3, and 8;
- scope winner accuracy;
- semantic type recall at 1, 3, and 12;
- joint scope/type accuracy;
- boundary accuracy and observed item cardinality where labeled;
- primary-detail, listing-population, and related-content accuracy where labeled;
- correct session-item enrichment where a future navigation-linked label exists;
- false automatic-acceptance rate;
- review/abstention rate;
- risk-coverage curve across confidence thresholds;
- calibration error and confidence-margin distributions; and
- runtime per page and per candidate.

Corpus-construction reporting should separately include:

- declaration parse and compatibility distributions by type;
- mechanically normalized, review-required, and unusable rates;
- DOM visibility and alignment rates by declaration class;
- benchmark eligibility rates by task; and
- the interaction between declaration compatibility and alignment quality.

These are useful empirical results and essential label-bias diagnostics. They must not be presented as general measurements of all Schema.org markup without accounting for WDC extraction, crawl recovery, sampling, and filtering.

The governing metric is not maximum coverage. It is the error rate among decisions that Site2JSON would accept automatically.

### 9.3 Reporting denominators

Every prevalence, error, alignment, and eligibility statistic must name its denominator. At minimum, report separately by:

- entity;
- source page;
- host and pay-level domain; and
- structural template or generator cluster when a defensible cluster can be derived.

These views answer different questions. Entity-weighted rates describe the records a downstream consumer encounters, page-weighted rates prevent pages containing many declarations from dominating, and domain-weighted rates describe how widely a behavior is deployed. A single high-volume publisher or faulty generator can dominate entity counts while affecting few domains; a shared platform can produce the opposite pattern by deploying one generator across many customer domains.

No unqualified percentage should appear in reports. A metric record should carry its counting unit, population, filters, type stratum, crawl, and weighting policy, for example:

```json
{
  "metric": "declaration.vocabularyConflictRate",
  "numerator": 412,
  "denominator": 10124,
  "unit": "payLevelDomain",
  "weighting": "one-per-domain",
  "schemaType": "Product",
  "crawl": "...",
  "filters": ["exact-snapshot", "usable-html"]
}
```

Headline results should normally show entity-, page-, and domain-weighted estimates together. Sampling and train/test grouping should continue to operate at the pay-level-domain level even when other denominators are reported.

### 9.4 Domain and temporal splits

Pages from one host share templates, class names, labels, and structured-data generators. Random page-level splits would measure template memorization.

All evaluation splits must be grouped by pay-level domain or a stricter host family. The corpus should also reserve:

- an unseen-domain validation split;
- an untouched unseen-domain test split;
- a later-crawl temporal test;
- small-site and long-tail strata;
- a low-semantic-token stratum;
- a client-rendering-shell stratum;
- a malformed-declaration stratum; and
- a related-content trap stratum.

Pages per host must be capped or weighted so a few large publishers cannot dominate either training or metrics.

## 10. Heuristic tuning before ML

The first experiment should evaluate and tune the current code. Candidate generation and its findings remain interpretable; the corpus can show whether failures come from missing features, incorrect weights, or thresholds.

Parameters and policies suitable for calibration include:

- evidence-kind weights in `evidence-scope.js`;
- repeated-boundary identity and consistency contributions;
- one-item/detail content, landmark, heading, and boilerplate weights;
- repeated-content-versus-primary-detail boundary arbitration;
- Page Analysis minimum structural confidence and margin;
- semantic-ranking evidence weights;
- semantic winner score, explained-observation count, and margin; and
- the number of structural and semantic alternatives analyzed.

Tuning must optimize held-out domain performance and preserve explanations. It must not make the WDC-declared type an input feature when evaluating whether current page evidence predicts that type.

## 11. ML handoff

If correct candidates are generated reliably but ordering remains weak, the natural ML task is ranking joint candidates:

```text
features(page, scope candidate, semantic type)
    -> compatibility score
```

The model should initially supplement or replace weights, not candidate generation, review, or deterministic adapter execution. Candidate features can reuse the evidence already collected by Site2JSON:

- repeated-population or one-item/detail structural score components;
- tag, landmark, stable-hook, and selector-quality features;
- evidence kinds and their population coverage;
- identity diversity;
- text and element density summaries;
- primary-versus-secondary context;
- semantic property evidence;
- type hierarchy and catalog compatibility;
- winner/runner-up relationships; and
- optional WDC prevalence priors, kept separate from page evidence.

The model output must remain confidence-calibrated and abstainable. A learned score does not change the design rule that automatic publication requires stronger evidence than a review suggestion or one-time extraction.

WDC-derived synthetic pages can later expand sparse structural families and generate controlled counterexamples. They should complement the naturally occurring corpus, not serve as its evaluation set.

## 12. Relationship to future telemetry

WDC can bootstrap Page Analysis before Site2JSON has an installed population. It cannot reproduce the distribution of live rendered DOM, authenticated applications, virtualized lists, or user corrections.

Future consented telemetry can measure that distribution and supply reviewed outcomes:

```text
page-derived bounded features
initial scope/type proposal and alternatives
author correction or acceptance
final reviewed decision
session item identity and whether a detail-page run enriched the intended collection item
```

The WDC corpus and telemetry should share an inference-report and evaluation contract while retaining distinct provenance. WDC supplies scale, domain diversity, and a historical public-web baseline. Telemetry supplies product-aligned rendered evidence and correction labels. Explicit fixture donation remains the path for high-value complete examples.

## 13. Pilot

### ROI preflight

Before treating the Page Analysis corpus as the first large WDC investment, run three small comparisons:

1. **Table Corpus:** inspect samples and statistics for the target classes; measure property prevalence, nested value realization, and value shapes against one-item/detail fixtures only. Do not use this filtered corpus to draw conclusions about repeated-population boundaries.
2. **Raw WDC crawl join:** attempt exact snapshot recovery and DOM alignment for a small, host-diverse URL sample. This is Phase 0 and the load-bearing feasibility test for the Page Analysis corpus.
3. **PAVE linkage:** inspect its JSONL identifiers and `pid` title/description anchoring, then determine whether individual offers can be joined to selectively retrievable source records before considering the large product HTML corpus.

Compare the spikes by engineering effort, usable examples, label precision, domain diversity, current subsystem exercised, and plausible product improvement. Table statistics may deliver the fastest small benefit while the crawl-join spike determines whether the higher-leverage Page Analysis investment has acceptable expected ROI.

### Phase 0 — Join feasibility

1. Select a small WDC release sample for `JobPosting`, `Product`, `Event`, and `Recipe` or another strongly structured creative-work type.
2. Attempt to recover the corresponding immutable Common Crawl response.
3. Measure exact recovery, useful-HTML, and static-content rates by type and domain.
4. Inspect redistribution, retention, and attribution requirements before storing a corpus.

**Exit:** a documented join method with reproducible snapshot identity, or a decision that exact page recovery is not reliable enough for aligned use.

### Phase 1 — Alignment feasibility

1. Normalize declared entities conservatively.
2. Record parse status, compatibility findings, and mechanical normalizations without applying semantic repairs.
3. Implement bounded value-to-DOM matching for URLs, names, images, dates, prices, and locations.
4. Run the current evidence-scope candidate generator.
5. Produce separate declaration and alignment assessments plus task-specific eligibility.
6. Human-review a stratified sample across types, hosts, declaration classes, alignment levels, and failure reasons.

**Exit:** a silver-label policy with measured precision, a catalog of systematic noise, and evidence that declaration compatibility can be measured without turning semantic repair into a prerequisite for the benchmark.

### Phase 2 — Current-system benchmark

1. Freeze host-grouped train, validation, and test partitions.
2. Pin the exact Page Analysis, evidence-scope, semantic-ranking, and report-contract revisions used by the experiment.
3. Run the existing scope/type pipeline unchanged; exclude item-variant output from the initial target and acceptance metrics.
4. Measure candidate recall, ranking, type recall, joint accuracy, risk-coverage, and runtime.
5. Store failure classifications rather than only aggregate scores.

**Exit:** evidence that the corpus exposes actionable Page Analysis failures and does not merely restate declarations.

### Phase 3 — Heuristic calibration

1. Tune only on training domains.
2. Select policies on unseen validation domains.
3. Evaluate once on the untouched test split.
4. Add representative minimized examples to repository regression tests.

**Exit:** a measurable reduction in high-confidence errors or review burden without loss of candidate recall.

### Phase 4 — Learned ranking experiment

1. Train a small interpretable ranking baseline over existing evidence features.
2. Compare it with the unchanged and tuned heuristic systems.
3. Evaluate a no-WDC-prior counterfactual and an unseen-crawl temporal split.
4. Retain the model only if it improves risk-coverage on unseen domains and its runtime is compatible with the authoring workflow.

## 14. Provisional go/no-go criteria

The pilot should establish thresholds before a large download or training effort. Reasonable initial targets to test are:

- enough exact, useful snapshots to retain thousands of examples after aggressive filtering;
- approximately 95 percent human-confirmed precision for the highest silver tier;
- at least 90 percent correct-boundary recall within the eight candidates already generated by the product;
- meaningful diversity after per-host caps and template clustering; and
- identifiable ranking or calibration failures that can be improved without using the declared answer as an inference feature.

Failure of one criterion does not make WDC useless. It changes the best use:

- poor snapshot recovery favors semantic statistics and graph mining;
- poor scope alignment favors page-level representation learning;
- low candidate recall calls for structural candidate-generation work before ML ranking;
- high candidate recall with weak ranking is the strongest case for learned Page Analysis scoring; and
- strong existing performance favors calibration, adversarial suites, and long-tail sampling over a new model.

## 15. Non-goals

- Treating publisher declarations as verified semantic truth.
- Training the runtime extraction interpreter; adapters remain deterministic inert data.
- Learning or publishing site-specific selectors from corpus pages.
- Replacing real rendered fixtures with static Common Crawl HTML.
- Using WDC examples from the same domains in both training and evaluation.
- Maximizing corpus size at the expense of label precision or structural diversity.
- Allowing WDC popularity to count as observed page evidence.
- Making comprehensive Schema.org repair analysis a prerequisite for the Page Analysis pilot.
- Applying property-placement, entity-boundary, relationship, or type repairs without human semantic judgment.
- Claiming that scope/type labels evaluate or stabilize the separate item-variant subsystem.

## 16. Open questions

- Can WDC source URLs be joined to exact Common Crawl response records at an acceptable rate?
- How much useful DOM remains in static HTML for each target type?
- Which declared properties yield sufficiently precise DOM alignment without site-specific rules?
- Which declaration findings are safely mechanical, and which only admit reviewable interpretations?
- Can declaration compatibility and DOM alignment be sampled well enough to publish meaningful joint distributions?
- Should one page produce several labeled scope/type pairs when it contains primary and related entities?
- How should equivalent selector candidates be mapped to one structural boundary identity?
- Which corpus artifacts may be redistributed, and which must remain locally reproducible from upstream sources?
- What human-review interface provides fast scope/type adjudication without exposing reviewers to unnecessary personal data?
- At what point does a learned joint ranker outperform calibrated heuristics on unseen domains?
- Which Page Analysis revision and report contract should be frozen for the first baseline while adjacent authoring subsystems continue to evolve?

## 17. Decision

Pursue WDC first as a bounded Page Analysis corpus experiment.

The first implementation should recover a small exact-crawl sample, align declared entities to the candidates returned by the current code, and evaluate the unchanged pipeline. Do not begin with a broad WDC mirror, a production ML model, or corpus-derived automatic acceptance. The pilot earns further investment by demonstrating high-precision labels, high structural candidate recall, cross-domain diversity, and actionable ranking or calibration failures.
