# Visual Evidence Authoring in the Detection-First Workflow

**Status:** Design direction

## Decision

Visual Evidence is one reusable authoring workflow with two entry points:

1. the initial Detection surface, where the user reviews whole-page discovery; and
2. the semantic graph editor, where the user may add or change types and fields after discovery, including custom and imported vocabulary.

The workflow opens as a **full-panel workspace with a Back action**. In this document, that is the project's focused-workspace pattern; it is not a centered dialog layered over the panel. The rendered page remains visible and becomes the evidence-picking surface.

Initial Detection is the first consumer of Visual Evidence, not its owner. The graph editor is the second consumer because it can introduce semantic targets that did not exist during initial discovery.

## Why both entry points are required

Site2JSON starts with automatic whole-page discovery. On the initial surface, the user decides which discovered entities belong in the adapter, corrects their types, and supplies page-location evidence when discovery found the wrong field or could not assemble an entity.

The graph is seeded from those accepted detections, but it is not limited to them. A user can later add Schema.org types, custom types and properties, or imported LOV terms. Those additions may need page evidence even though no corresponding target existed during initial discovery. The graph editor must therefore invoke the same Visual Evidence workspace rather than provide a second mapping interaction.

This preserves one learned workflow:

> choose a semantic field → point to its rendered evidence → resolve a local interpretation if necessary → continue

## Surface responsibilities

### Initial Detection

The initial surface runs whole-page discovery before asking for hints. It presents detected entities and repeated groups as semantic cards and lets the user:

- accept or reject an entity or repeated group;
- correct its semantic type;
- inspect detected fields and their rendered sources;
- invoke Visual Evidence for missing or incorrect page correspondence; and
- pass accepted entities, corrected types, and applicable evidence into the graph.

Repeated instances are one authoring unit when they share a detected pattern. Acceptance and evidence should apply at the group level unless real variant evidence requires a narrower decision.

### Semantic graph editor

The graph editor owns the semantic model: types, properties, custom vocabulary, and relationships. It begins with accepted detection results but may extend or replace them.

After a graph change, Site2JSON should first attempt the smallest relevant automatic detection pass. If the new or changed target cannot be resolved, the type or field can open Visual Evidence with that semantic target already selected.

Using Visual Evidence for one field does not make the user responsible for the rest of the type or graph.

### Visual Evidence workspace

Visual Evidence owns focused page-to-field authoring. It receives a semantic target and caller context, replaces the current panel view, and returns to that caller through Back.

For each selected or unresolved field, it:

1. names the active target, such as `Article.headline`;
2. highlights eligible rendered elements as the pointer moves;
3. records the clicked page evidence;
4. asks near the pointer only when the element has multiple useful interpretations, such as visible text, URL, image source, or a supported attribute;
5. shows the field as resolved and advances; and
6. triggers the smallest affected re-detection so the consequence is visible on return.

The workspace must allow a field to remain unresolved. It must explain incompatible evidence rather than forcing a plausible-looking mapping.

### V2 live-preview review

Live-preview review is a different workflow. It inspects how the current graph and inference machinery interpreted the page. Its stable-ID overlay can compare a ranked alternative, preserve an unresolved decision, and synchronize source with output without mutating observed evidence or the authored graph.

Those preview decisions are not, by themselves, authored page-location hints and should not acquire an “accepted-result” persistence model merely to make them durable. When review reveals that the underlying problem is missing or incorrect page evidence, it may route the user into Visual Evidence with the relevant semantic target. When it reveals a wrong type or model, it should route to type correction or graph authoring instead.

## Correction routing

Use the mechanism that matches the actual problem:

| Problem | Destination |
| --- | --- |
| Correct entity and fields, wrong semantic type | Type selector |
| Correct semantic target, missing or wrong rendered-page evidence | Visual Evidence |
| Missing type, property, custom vocabulary, or relationship | Graph editor, then automatic detection |
| Need to inspect or compare a temporary V2 interpretation | Live-preview review |
| Decide whether a discovered entity belongs in the adapter | Detection accept/reject |

Avoid generic labels such as **Fix**, **Correction**, or **Accept result** when the destination or ownership transfer is unclear.

## State and ownership contract

The implementation must keep these states distinguishable:

- automatically inferred correspondence;
- explicit user-authored visual evidence;
- unresolved or incompatible evidence;
- stale evidence after relevant page or model changes;
- preview-only review decisions; and
- accepted or rejected detected entities.

Authorship is field-granular. Providing evidence for one field must not pin inferred fields, accept the entity, approve the graph, or promote site-specific evidence into shared semantic knowledge.

The workspace returns a structured evidence decision; it does not choose the storage layer. Runtime-required location behavior belongs in the portable adapter representation. Authoring-only evidence belongs in inert authoring metadata or draft state. Transient inference and preview overlays remain transient. The representation must preserve stable semantic identity, provenance, and staleness without storing rendered page text as reusable knowledge.

For repeated structures, one selected instance should become evidence for a proposed group pattern, not an unverified claim that every instance is identical. Differences remain visible as variant or unresolved evidence.

## Shared interaction requirements

- Panel-to-page and page-to-panel selection should use shared stable identities rather than screen-specific correspondence systems.
- Highlights must represent real evidence or selection state and work in light/dark themes and narrow/wide panels.
- The page should receive immediate, restrained hover feedback while picking.
- Contextual interpretation choices should appear near the selected evidence to minimize pointer travel.
- Back must restore the calling surface and its working context.
- Automatic inference remains the default; Visual Evidence is a fallback and refinement tool, not a mandatory field-mapping wizard.
- The primary interaction must not expose raw selectors or turn the workspace into a generic DOM inspector.

## Implementation sequence

1. Verify the current V2 detection and graph paths for added and changed types/fields, including custom and imported terms.
2. Define the shared invocation and return contract: caller, semantic target, current evidence, repeated-pattern context, completion, cancellation, and staleness.
3. Implement the full-panel workspace and Back behavior as one reusable route.
4. Wire the initial Detection surface to it for missing or incorrect page evidence.
5. Wire graph types and fields to the same route after an automatic resolution attempt.
6. Add live-preview routing only where a review finding is specifically an evidence-location problem.
7. Validate the real extension in both themes and relevant panel widths, including keyboard use, repeated groups, unresolved fields, cancellation, and caller-state restoration.

## Open implementation questions

The first shared workspace implementation answers the routing questions as follows: Detection and Graph use the same invocation/return contract; the existing page picker supplies restrained hover feedback and ambiguity-only interpretation choice; and completion returns JSON-serializable field decisions with explicit rendered-click provenance. Detection currently reruns its full supported detection pass and Graph refreshes its full supported inference preview because no narrower engine API exists. The decisions do not select a durable storage layer.

These require repository evidence before their slices are accepted:

- Which graph edits already trigger V2 detection, and what evidence do they consume?
- Which visual decisions are runtime-required bindings versus authoring-only evidence?
- How is a click generalized and validated across a repeated group?
- Do relationship targets require direct visual authoring, or can scalar evidence plus graph structure resolve them?
- Which shared selection/highlight primitives can serve Detection, Visual Evidence, graph selection, and live review?

These questions refine the mechanism; they do not reopen the two-entry-point or full-panel-workspace decision.

## Non-goals

Visual Evidence does not:

- replace automatic inference, type correction, graph authoring, Review, or detection acceptance;
- require manual mapping of every field;
- merge the graph editor and page picker into one screen;
- make every click a permanent runtime rule;
- silently promote site-specific evidence into a Semantic Library profile; or
- serve as the acceptance mechanism for live-preview results.

## Design-principle check

**Truth:** inferred, authored, unresolved, stale, accepted, and preview-only states remain distinct, and highlights correspond to actual evidence.

**Maintainability:** one shared workspace serves both callers, automatic detection remains responsible for untouched fields, and ownership transfers only for the evidence the user authors.

**Explainability:** each problem routes to the surface that can resolve it, while semantic targets remain visibly connected to rendered evidence.

**Aesthetics:** the full-panel workspace gives page-based authoring enough room, uses a coherent Back pattern, and makes the source/model relationship direct without stacking dialogs inside a constrained side panel.
