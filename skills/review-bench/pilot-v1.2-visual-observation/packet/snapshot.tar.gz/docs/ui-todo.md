# UI TODO

* graph editor screen
  1. reduce the “boxed tile” treatment. Right now each favorite is very individually framed. With stronger icons, you could afford to make the container quieter—icon + short label, softer hover/selection treatment, less button chrome. Then the strip reads more like a palette than a toolbar.

