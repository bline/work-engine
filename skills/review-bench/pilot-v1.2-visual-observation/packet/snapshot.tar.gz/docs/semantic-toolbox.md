# Semantic toolbox

The normalized compatibility format is version 6. Reusable custom types are records with a stable library-instance `id`, a semantic `termId`, display metadata, and an inert DSL type definition. For user-authored local records those identifiers normally match. Imported records use a package-qualified `id` while retaining the vocabulary's original `termId` and canonical URI. Saved `pattern` records have the same separation between local `id` and portable `patternId`; they are presented to users as graph bundles because they preserve an entire selected subgraph—nodes, relationships, and custom terms—rather than a visual style or template.

The semantic toolbox is user-local authoring configuration. It is separate from adapter drafts, published adapters, and extracted data.

The graph editor accesses this data through the storage-neutral [Semantic Library service](semantic-library-service.md). Production data now lives in record-oriented IndexedDB stores. The former `site2json.semanticToolbox` object is retained only as a normalized compatibility format and one-time migration source; graph-editor callers are unchanged.

## Interaction model

- The graph canvas has a favorites dock on its right edge when space permits.
- In a narrow side panel, the dock becomes one horizontal row across the bottom of the canvas.
- Search results use the same draggable tiles as favorites, and now also surface saved patterns alongside Schema.org types.
- A type tile can be dropped on empty canvas to create a disconnected semantic node, or dropped on the dock to become a favorite.
- Dropping a type tile directly onto an existing node treats the existing node as the parent and checks for a structurally specific Schema.org relationship to the dropped child. Universal `Thing` domain/range fallbacks do not count as graph-authoring connections. The target highlights green for one relationship, amber when a choice is required, and red when none exists. A successful drop places the child in a nearby free position instead of beneath the pointer. Holding on a red target for 650ms reveals an amber "+ relationship" cue; releasing then opens the custom-relationship editor pre-filled for that pair.
- Favorites can be reordered and removed without changing the current adapter.
- Draggable tiles expose a subtle dotted grip. Dragging a favorite reveals a temporary trash target; Delete also removes a focused favorite.
- A newly dropped node may remain disconnected while editing, but the graph cannot be applied until it validates.
- Hovering a graph node reveals a connector handle. Compatible Schema.org targets are emphasized while incompatible nodes recede.
- Dropping on a target immediately adds a unique valid relationship. When several properties fit, the inspector is reduced to those choices and the target stays fixed.
- Holding an incompatible target for 650ms changes it from red to amber. Releasing then opens a compact editor for an adapter-local relationship with its domain and range inferred from the two nodes.
- The selected-node inspector exposes the same custom-relationship editor without requiring a pointer gesture.
- The pinned "+ Custom type" tile (drag or click) opens a form to name and describe a new adapter-local type. Dropped on empty canvas it adds a disconnected node; dropped on an existing node it also opens the same custom-relationship setup, pre-filled, so the type and its connecting relationship are defined together. Custom-type nodes render with a dashed violet border and a "· custom" label suffix.
- Ctrl/Cmd-click or Shift-click nodes on the canvas to build a pattern selection (highlighted violet); "Save selection as pattern…" saves the induced subgraph — every selected node, every edge with both ends selected, and the vocabulary terms they use — to the toolbox under a name you choose.
- C starts the same connection flow from the selected node; Tab or the arrow keys choose a target and Enter either confirms a Schema.org relationship or opens the custom editor for an incompatible pair.
- Delete removes the selected non-root node or relationship, Escape cancels connection mode or clears selection, and F or Home fits and centers the graph.

## IndexedDB storage

The `site2json.semanticLibrary` database separates `customTypes`, `properties`, `patterns`, `tags`, `tagAssignments`, `collections`, `toolkits`, and `imports` object stores. Favorites and migration/generation metadata live in a small `meta` store. Each committed catalog import writes its UUID, pinned source snapshot, exact created-record references, skipped records, warnings, and timestamps to `imports` in the same transaction as its semantic records. Imported instances are owned exclusively by that package: overlapping terms in two imports are stored twice under different library IDs and are shown separately with their bundle names.

The previous `site2json.semanticToolbox` value used this versioned compatibility shape, which is still accepted during migration and by tests:

```json
{
  "version": 6,
  "favorites": [
    { "kind": "schemaType", "id": "Person" },
    { "kind": "pattern", "id": "pattern:marketplace-buyer-m1a2b3c4" }
  ],
  "customTypes": {},
  "patterns": {
    "pattern:marketplace-buyer-m1a2b3c4": {
      "id": "pattern:marketplace-buyer-m1a2b3c4",
      "patternId": "pattern:marketplace-buyer-m1a2b3c4",
      "label": "Marketplace buyer",
      "description": "A buyer with an aggregate rating.",
      "root": "buyer",
      "nodes": { "buyer": { "types": ["Organization"], "expectation": "core" } },
      "edges": [],
      "terms": {}
    }
  },
  "tags": {
    "tag:employment": { "id": "tag:employment", "label": "Employment", "revision": 1 }
  },
  "tagAssignments": {
    "pattern\u001fpattern:marketplace-buyer-m1a2b3c4": ["tag:employment"]
  },
  "collections": {
    "collection:marketplaces": {
      "id": "collection:marketplaces",
      "label": "Marketplaces",
      "members": [{ "kind": "pattern", "id": "pattern:marketplace-buyer-m1a2b3c4" }],
      "revision": 1
    }
  },
  "toolkits": {}
}
```

`favorites`, custom types and properties, patterns, user tags, collections, and import history are implemented through the service. A pattern is a saved, named subgraph (root alias, its nodes, the edges fully contained within the selection, and any adapter-local vocabulary terms those nodes/edges depend on), addressable by search, pinnable to favorites, and insertable as one unit. Import rollback deletes only records still owned by that import UUID at their original revision; user-edited records are retained and identified in the completed rollback manifest. Canonically equivalent records are deduplicated only when materialized into an adapter. Equivalent definitions share one adapter-local term; conflicting definitions block the second insertion and require an explicit choice.

## Custom vocabulary and patterns

- A custom type created via the toolbox tool is adapter-local: it's added to the current draft's vocabulary as a `kind: "type"` term, with a placeholder `valueType`/`cardinality`/`example` the same way custom relationships already work.
- A connected selection is saved as a pattern and dragged (or clicked) into a graph as one unit: node and edge aliases are remapped to avoid collisions with the current draft, and the pattern's own root loses its `core` expectation once merged (only the host composition's root may be core).
- Dropping a pattern onto an existing node runs the same parent-to-child structural relationship check as a single type tile, chaining into the picker or the custom-relationship editor as appropriate; dropping on empty canvas leaves it disconnected, same as any other new node.
- Vocabulary terms a pattern depends on are merged into the draft on insertion. A term whose name is already defined with a different meaning blocks the whole insertion with a clear error — nothing is partially applied.
- A toolkit groups custom types, custom relationships, and patterns under one searchable unit. This layer is not built yet; patterns alone cover the "save a piece of a graph for reuse" need for now.
- The external vocabulary browser searches LovPortal's mirror of Linked Open Vocabularies only on explicit request, resolves the selected term or hierarchy from a pinned graph, and copies the approved records into this same user-local toolkit. Vocabulary/category metadata is cached locally; imported terms retain canonical identifiers and source/retrieval provenance. Adapters and normal graph search never depend on a live catalog service. See [the roadmap](roadmap.md#linked-open-vocabularies-browserimporter).

Direct edge dragging — connecting two nodes by dragging one onto the other without the explicit connector handle or toolbox-tile gesture — remains a future addition.
