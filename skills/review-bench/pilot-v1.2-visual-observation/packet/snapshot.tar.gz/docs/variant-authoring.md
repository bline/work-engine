# Authoring result variants

Site2JSON variants describe a bounded choice between semantic types. A search result can, for example, remain a `ListItem` while its `item` relationship emits an `Article`, `JobPosting`, or `Product`, with `Thing` as the safe fallback.

## How classification works

Classification happens after field discovery. Site2JSON first extracts the union of fields declared by the candidate types, then scores each candidate from two sources:

- **Semantic shape** is the set of candidate fields and relationships that were actually extracted. Dotted fields such as `item.author.name` contribute relationship-aware evidence, not just a matching label.
- **Explicit evidence** is an author-selected rendered element or extracted field that distinguishes otherwise similar candidates. It supplements semantic shape; it does not replace it.

A candidate must clear both the configured minimum score and the winning margin over the runner-up. If it does not, runtime extraction emits the declared fallback and reports the unresolved classification. It never guesses merely because one candidate ranked first.

The authoring UI labels `Core`, `Common`, and `Optional` as **Scoring** because these values are scoring priors, not Schema.org cardinality rules. Adapter data stores them as `expectation` so the established model and DSL do not gain a duplicate concept:

- **Core** strongly influences confidence and review because the relationship is fundamental to the model.
- **Common** is expected and contributes normal support, but its absence is allowed.
- **Optional** contributes weak support and its absence should not count against the candidate.

## Representative samples are part of authoring

Each classification run samples only the single page currently open beside the side panel. Collection sessions are not pooled into variant classification today. Every expected type should therefore be present on the current page when possible while the adapter is authored. Declaring a type does not prove that the adapter can recognize it, and a homogeneous page does not prove that future pages will be homogeneous.

When two candidates produce the same extracted shape, add distinguishing evidence from a page where the intended type is represented. Evidence should identify a stable semantic clue such as a type-specific attribute, icon, label, or field. Avoid generated class names and position-only selectors.

Nested variants may produce dotted candidate field paths. For a slot whose relationship path is the plain value `item`, fields belonging to its nested candidate are authored as `item.url`, `item.name`, or `item.author.name`. The slot path says where the classified entity is written; the dotted field paths describe values below it. Classification still evaluates evidence within the repeated result scope.

## Accepting an unresolved fallback

Sometimes the observed page genuinely provides no safe distinction. **Accept this shape as fallback** records a privacy-safe receipt containing:

- the matched/not-matched semantic and explicit-evidence shape;
- the candidate set and classification thresholds; and
- the declared fallback entity.

The receipt does not contain rendered text, attribute values, or URLs. It suppresses Attention only for that exact observed shape and configuration. If the page structure, matched evidence, candidate set, or thresholds change, the unresolved classification appears in Attention again. This is intentional: accepting one ambiguity must not silently approve a new one after a redesign.

## Authoring checklist

1. Declare a small, realistic candidate set (one to five alternate types).
2. Discover the union of candidate fields, including useful dotted relationship fields.
3. Review the per-candidate shape, evidence, score, runner-up, and margin.
4. Add stable explicit evidence when candidate shapes collide.
5. Include representative pages for every expected type when possible.
6. Accept fallback only when retaining the generic type is correct for that exact unresolved shape.
7. Revisit Attention after changing fields, relationships, candidates, thresholds, or structural baselines.
