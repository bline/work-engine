# Semantic Library service boundary

The Semantic Library UI and graph editor depend on an asynchronous, storage-neutral service rather than IndexedDB, SQLite, or `chrome.storage` directly. The same contract is intended to support a local worker transport, an HTTP API, or a hybrid cached service.

## Contract rules

- Requests and responses must be structured-clone and JSON serializable.
- Continuation cursors are opaque to callers; storage offsets and database cursors never cross the boundary.
- Detail and batch methods prevent remote transports from requiring N+1 requests.
- User-owned records carry revisions for optimistic concurrency.
- Unsupported features and failures use stable error codes rather than backend-specific exceptions.
- Graph expansion and future vocabulary imports must be explicitly bounded.
- Capability discovery lets the UI hide workflows that a backend does not implement.

The production implementation, `createIndexedDbToolboxService`, stores library records in IndexedDB while preserving this contract. Types, properties, saved graph bundles, tags, tag assignments, collections, toolkits, and import manifests have separate object stores. Mutations write only changed records inside one IndexedDB transaction; callers never receive database keys or cursors.

`createLegacyToolboxService` remains the shared contract implementation and testable compatibility layer. The IndexedDB service supplies it with a record-oriented storage adapter. On first use, that adapter validates and atomically copies the versioned `site2json.semanticToolbox` value from `chrome.storage.local`, records a completed migration marker, and only then removes the legacy key. A completed marker prevents stale legacy data from ever being replayed.

## Organization model

The service deliberately separates three kinds of organization:

- **Source categories** are read-only provenance metadata supplied by LOV or another catalog. Search results expose them as structured category records and `sourceCategoryIds` can filter by them, but the local user never edits them in place.
- **Tags** are mutable user-owned labels. The service supports revisioned tag CRUD, batch add/remove/replace assignment, assignment counts, and `tagIds` search filters.
- **Collections** are revisioned user-owned groups of heterogeneous library references. A collection may include types, properties, patterns, vocabulary packages, or terms; collections cannot recursively contain collections. Membership supports atomic add/remove/replace operations and `collectionIds` search filters.

Search returns facet counts for kinds, sources, source categories, tags, and collections. Multiple identifiers within one filter are intersected. Facets are calculated from the text/kind-matched pool before organizational filters, so the manager can show useful available refinements without loading the entire result set.

## Current manager

The extension side panel now exposes **Semantic Library** beside **Adapters**. The manager searches reusable custom types and saved graph bundles through the service, pages results instead of loading the whole collection, and displays bounded kind, tag, collection, and imported-source-category facets. A selected item can be previewed, renamed, described, duplicated, deleted, tagged, and added to user collections without the UI reaching into extension storage directly.

Creating an adapter-local type in the graph stores its inert type definition in the Semantic Library. It then appears in the same graph search as Schema.org types and graph bundles and can be inserted again without losing its definition. A graph bundle remains the unit for saving multiple types plus their relationships and required custom terms.

The manager deliberately treats a facet response as `{ items, total }`. Only the most useful facet values are rendered, while `total` preserves the fact that additional values exist. This keeps the interface and payload bounded when local vocabularies eventually contain thousands of terms and organization values.

Selected local records and complete imported packages can be exported through the same portable semantic bundle boundary. The manager has an explicit selection mode whose checked records persist across searches and result pages; bulk export includes exactly those records, while the detail-pane action on an imported record exports its complete owning package. The manager downloads `.site2json.json.gz`; importing one first performs bounded decompression, version and structure validation, and a non-mutating preview. Confirmation creates a fresh package UUID, so importing the same shared file twice produces two visibly owned package copies that can be exported or undone independently. The decompressed JSON contract and safety limits are documented in [semantic-bundle-format.md](semantic-bundle-format.md).

Properties may carry a versioned `authoringProfile` containing reusable aliases and exclusions, expected value shapes and units, an editable cardinality default, semantic salience, examples, and a recommended pipeline made only from packaged transforms. These profiles are local inference guidance and never become executable vocabulary. If a profile materially changes an automatic mapping, authoring stops for review; acceptance stores a frozen copy plus provenance and a no-profile counterfactual in the adapter's inert `authoring` receipt. Site-specific selectors and arbitrary code are never accepted by this record.

After an author corrects a reviewed mapping, Review may offer an explicit **Reuse this correction** preview. The proposal is limited to sanitized lexical aliases or exclusions derived from stable DOM labels; it never stores selectors, rendered page text, URLs, or examples automatically. Confirmation performs a revision-checked property update, records the originating adapter decision and exact change in bounded profile provenance, and invalidates inference caches. Dismissing the proposal changes nothing. A correction to a decision that was itself profile-influenced carries an additional warning to prevent accidental feedback loops.

## Behavioral compatibility

`tests/contracts/semantic-library-service.contract.js` is the backend-independent behavioral suite. Both the legacy in-memory/storage adapter and production IndexedDB implementation run that same suite. This includes paging, optimistic revisions, tag assignment, collection membership, organization filters, and facet counts. Backend-specific tests additionally cover IndexedDB durability, store layout, and one-time migration without changing the UI-facing behavior.

## Import boundary

Vocabulary import is deliberately a two-step service operation:

1. `planImport` resolves the selected package/subgraph, dependencies, provenance, collisions, and expected size without mutation.
2. `startImport` atomically commits an approved plan and a durable import manifest under one UUID.

Native bundle sharing uses the parallel `planBundleImport` preview and the same `startImport` commit boundary. `exportBundle` accepts one or more library targets, a heterogeneous collection, or an owning import UUID. Its result contains portable term/pattern identities and provenance but never local record IDs, revisions, import UUIDs, or database details.

The manager exposes that manifest history locally. `listImports` returns bounded summaries without returning a potentially very large record list; `getImportJob` retrieves one full manifest. Every imported record has a package-qualified library `id`, its original semantic `termId`, and canonical URI. Separate imports never share record ownership—even overlapping terms are independent instances and appear as separate, bundle-labelled search results. `undoImport` atomically removes records created by the selected batch plus their tag, favorite, and collection references. A record whose revision or import ownership changed after the import is retained and reported instead of being destroyed. Already-deleted records are also reported, making rollback safe after partial manual cleanup. Completed and undone manifests remain in history as an audit trail.

This keeps LOV and other external catalogs outside the editor's storage concerns and allows a remote implementation without changing the manager UI.

The first catalog provider uses LovPortal's public SPARQL endpoint for all explicit remote discovery. The extension no longer grants access to or calls the slower `lov.linkeddata.es` API. LOV remains the upstream curator recorded in provenance, while LovPortal is the retrieval transport.

Vocabulary, latest-submission, namespace, category, and group metadata are normalized into a provider-neutral index and cached in `chrome.storage.local` for 24 hours. Category-filtered browsing and vocabulary text search run against that local index. Class and property searches use Virtuoso's bounded full-text index, discard stale submission graphs, prefer terms owned by the vocabulary namespace, and deduplicate canonical URIs before paging results.

A user may search for one class/property or browse vocabulary packages by cached category. Opening a vocabulary uses its catalog-owned latest submission, then pages and filters its classes without loading the complete ontology into the side panel. Class selections persist across pages and are bounded to 25 explicit choices per import.

An individual-class preview resolves its labels, description, parent classes, and directly declared domain/range properties. A vocabulary-subset preview can additionally walk in-vocabulary parent links so the imported hierarchy remains connected and can include the direct properties declared for every resolved class. Both flows remain non-mutating until the existing atomic `startImport` boundary. LovPortal graphs that merely reuse another vocabulary's prefix are rejected; the provider will not silently present a foreign ontology as the requested package. LovPortal's REST search is not used as an anonymous fallback because it currently requires an account API key.

An import record distinguishes the upstream curator (`source: lov`) from the retrieval/enrichment transport (`retrievedThrough: lovportal-sparql`). It also retains the canonical term URI, vocabulary prefix/acronym, named graph, submission id, source categories, retrieval time, and owning bundle. Repeating or overlapping an import creates another isolated package instance. Duplicates inside one proposed package are skipped, but existing local or imported records never become cross-package dependencies.

Remote lookup never participates in graph search or adapter execution. Only committed local records appear in the editor. When an imported class is inserted into a draft, it is materialized under the adapter's own namespace with `canonicalUri` retained as inert vocabulary metadata. That materialization boundary deduplicates equivalent canonical definitions already present in the draft; a differing definition for the same canonical URI is surfaced as a conflict rather than silently merged.

## Inference catalog

The eager page-model pass and the per-item variant pass both use every committed local type and graph bundle in addition to the packaged Schema.org catalog. Loading follows the paged service contract rather than assuming a small toolbox. An in-memory token index narrows each page observation to a bounded candidate set, so a library containing thousands of records does not cause every item to be scored against every installed term.

Separate package-owned records remain separate in the manager. For inference only, records with the same canonical URI are scored once and retain a list of their contributing package sources; this prevents duplicate imports from manufacturing a confidence tie. If a local model wins, its required definitions are copied into the adapter namespace and retain `canonicalUri`, leaving the published adapter independent of both IndexedDB and the remote catalog.

Field discovery follows the same boundary. Properties explicitly installed for the inferred type are documented candidates and may be used by automatic conversion. Ad-hoc, non-Schema extension-field invention remains disabled in automatic mode.
