### Web Data Commons Schema.org Corpus

**Web Data Commons (WDC)** is a research project at the University of Mannheim that extracts structured data embedded in pages from **Common Crawl**. It has produced yearly Schema.org datasets since **2013**, making it both a very large corpus and a longitudinal record of how Schema.org is actually used on the public web. ([Web Data Commons][1])

The latest published Schema.org release is based on the **October 2024 Common Crawl**. That crawl contained about **2.39 billion parsed HTML pages across 37.4 million pay-level domains**. Structured data of some kind was found on roughly **1.25 billion pages (51.25%) from 16.5 million domains**. JSON-LD alone appeared on about **834 million pages from 11.56 million domains**. ([Web Data Commons][2])

For the Schema.org-specific dataset series, the 2024 release contains approximately **136.8 billion RDF quads**, originates from **12.27 million domains**, and occupies about **1.7 TB compressed**. The corpus has grown enormously: the 2013 release came from about 400,000 domains and contained 10.4 billion quads. ([Web Data Commons][1])

### How it is created

WDC runs extractors over Common Crawl HTML and collects structured markup expressed as **embedded JSON-LD and Microdata** for the Schema.org series. The class-specific datasets merge these sources. If a page contains an entity of a selected type, WDC keeps that entity along with other entities occurring on the same page. Thus, a `Product` page can also contribute its associated `Offer`, `Review`, `Organization`, etc. ([Web Data Commons][1])

The original webpage URL is preserved as the **fourth component of each RDF quad**. This is important because the structured record retains provenance back to the page from which it was extracted. ([Web Data Commons][1])

The corpus is therefore fundamentally an observation of **structured data as publishers deployed it on the real web**. It is not a manually corrected or human-verified knowledge base.

### Format

The primary corpus is distributed as a variation of **N-Quads**, compressed with gzip. A record is effectively:

```text
subject   predicate   object   source-page-URL
```

WDC also provides conversion software for turning the data into **JSON and CSV**. ([Web Data Commons][3])

There is also a separate **Schema.org Table Corpus** derived from the main extraction. The 2023 edition converts Schema.org entities into approximately **5 million JSON relational tables covering 42 Schema.org classes**. Each table represents one Schema.org class from one host, and every row retains its `page_url`. These JSON files can be loaded directly with Pandas. ([Web Data Commons][4])

For example, the 2023 table corpus contains approximately:

* **288 million Product records** across 2.67 million host tables
* **25 million CreativeWork records** across 443,000 tables
* **14.8 million Event records** across 368,000 tables
* **3.45 million JobPosting records** across 58,000 tables
* **3.0 million Book records** across 14,500 tables ([Web Data Commons][4])

### Is it easy to download?

**Technically yes; practically, the complete dataset is huge.**

WDC publishes ordinary HTTP download lists. For the October 2024 raw structured-data extraction, one command is enough:

```bash
wget -i <WDC file list>
```

The complete structured-data extraction consists of **13,396 gzip files totaling about 1.4 TB**. The JSON-LD portion alone is **7,462 files / ~751 GB**, while Microdata is another **~529 GB**. Individual compressed chunks are roughly 100 MB, so downloading only portions is straightforward. ([Web Data Commons][3])

More conveniently, WDC publishes **class-specific Schema.org subsets**, so someone interested only in `Product`, `JobPosting`, `Event`, etc. does not have to ingest the entire corpus. ([Web Data Commons][3])

The Table Corpus is even easier for smaller experiments because classes are available separately, split into the largest 100 tables, tables with at least three rows, and smaller tables. Samples are also provided. ([Web Data Commons][4])

### Published research and statistics

WDC has been studied extensively. The project itself publishes detailed statistics for every release, including adoption by markup format, domain, Schema.org class, number of entities and properties, and changes over time. ([Web Data Commons][2])

One particularly relevant historical study examined **errors in deployed Schema.org markup**. In the 2013 corpus, WDC found undefined types on **6.16% of Schema.org-using domains** and undefined properties on **8.02%**. More than half of domains using object properties had at least one instance where a literal datatype was supplied where an object/entity was expected. The researchers also catalogued common namespace, capitalization, spelling, domain/range and missing-intermediate-entity errors and created a heuristically repaired version of that corpus. ([Web Data Commons][5])

The main longitudinal dataset was formally described in **“The Web Data Commons Schema.org Data Set Series”** at The Web Conference 2023. Its purpose includes studying Schema.org adoption over time and providing training data for tasks such as information extraction, product matching, classification and question answering. ([Web Data Commons][1])

WDC has also produced multiple curated derivatives and benchmarks. For example, **WDC PAVE** contains **1,420 human-annotated product offers from 87 websites and 24,582 annotated attribute-value pairs**. The much larger WDC product-matching corpus contains over **26 million product offers from roughly 79,000 websites**, grouped into about 16 million product clusters. ([Web Data Commons][6])

### The short version

This is not a small academic benchmark. It is a **web-scale extraction of Schema.org usage from billions of real HTML pages**, preserved yearly for more than a decade.

For the 2024 Schema.org release alone:

**12.27 million domains → 136.8 billion quads → ~1.7 TB compressed.** ([Web Data Commons][1])

It is openly downloadable, provenance back to the source webpage is retained, smaller type-specific subsets are available, and there is a substantial body of published statistics and academic work examining both the corpus itself and the quality of Schema.org markup found within it.

For the proposed Site2JSON research use, see [WDC Page Analysis Corpus](wdc-page-analysis-corpus.md).

[1]: https://webdatacommons.org/structureddata/schemaorg/ "The Web Data Commons Schema.org data set series"
[2]: https://webdatacommons.org/structureddata/2024-12/stats/stats.html "Web Data Commons Extraction Report - October 2024 Corpus"
[3]: https://webdatacommons.org/structureddata/2024-12/stats/how_to_get_the_data.html "Web Data Commons - October 2024 Corpus - Download Instructions"
[4]: https://webdatacommons.org/structureddata/schemaorgtables/2023/index.html "WDC Schema.org Table Corpus 2023"
[5]: https://webdatacommons.org/structureddata/2013-11/stats/fixing_common_errors.html "Fixing Common Errors in Deployed Schema.org Microdata"
[6]: https://webdatacommons.org/structureddata/wdc-pave/ "Web Data Commons Product Attribute-Value Extraction Benchmark (WDC PAVE)"
