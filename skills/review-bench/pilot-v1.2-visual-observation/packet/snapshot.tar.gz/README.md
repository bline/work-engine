# site2json

site2json is a local-first Chromium extension that turns the page the user is intentionally viewing into structured data. Browsing remains manual; extraction occurs only when the user opens the extension or invokes one of its commands.

The implementation establishes the generic extraction envelope, block model, strict declarative interpreter, fidelity-aware session merging, compact JSON export, and JSON-LD export described in [DESIGN.md](DESIGN.md). A matching full detail observation upgrades an existing search-summary entity without adding a duplicate. The popup runs only enabled definitions from the local adapter registry; it contains no hardcoded adapter selection.

Upwork and Guru adapters are private reference and test artifacts under `reference-adapters/`. They are deliberately outside the distributable `extension/` directory and are never bundled with the extension. Sites suitable for public distribution may later be supplied separately through adapter sources.

Guru search metadata includes the decoded search route, its ordered skill terms, employer minimum-spend filter, maximum quote count, and logical page. Ordered skill terms are retained as observed query structure: the adapter does not claim that every term has identical boolean semantics.

Project and adapter-specific JSON-LD terms are documented in [VOCABULARY.md](VOCABULARY.md).

Project concepts and coined terms—including S2J Markup, Semantic DOM, semantic composition, structural fingerprint, OCR, and OSR (Optical Structure Recognition)—are collected in [LEXICON.md](LEXICON.md).

The point-and-click browser side-panel environment for creating and refining declarative adapters is described in [EDITOR.md](EDITOR.md).

Mixed result types, nested variant slots, evidence resolution, and exact-shape fallback acceptance are documented in [Authoring result variants](docs/variant-authoring.md).

Phases 1, 2, 4, and the Guru reference work in phase 5 of the design are implemented. Phase 3 is partially implemented: fixture-backed extraction tests and scheduled CI are present, including two privacy-scrubbed Upwork search fixtures reduced from captured pages. The reducer clones every rendered job card, prunes each clone to extraction-relevant DOM branches, and replaces identifying content and attributes with deterministic placeholders. There is not yet an in-extension capture action, a general-purpose scrubbing toolchain, or multiple messy fixtures per page type. Raw captures and editor swap files at the repository root are ignored and must not be committed.

## Develop

```sh
npm install
npm test
npm run check
```

The editor vocabulary catalog is generated from a pinned official Schema.org release. `npm run build:schemaorg` regenerates it from the committed verified snapshot; `npm run update:schemaorg` is the deliberate maintainer workflow for changing the pinned release. See [third_party/schemaorg/README.md](third_party/schemaorg/README.md).

## Third-party assets

The interface uses a deliberately small vendored subset of [Font Awesome Free](https://fontawesome.com/) icons by Fonticons, Inc. Icon artwork is licensed under CC BY 4.0; the complete bundled attribution and license notice is in [extension/vendor/FONTAWESOME-LICENSE.txt](extension/vendor/FONTAWESOME-LICENSE.txt). Other vendored-component notices are kept alongside their assets in `extension/vendor/`.

To load the extension, open `chrome://extensions`, enable Developer mode, choose **Load unpacked**, and select the `extension/` directory.

Open the extension popup beside the page being authored and choose **Open adapter editor**. YAML is the public authoring format; the importer also accepts normalized JSON reference definitions during development because JSON is a YAML subset. The side panel validates and summarizes a selected file before asking for confirmation. Imported copies can be enabled, disabled, replaced, exported, or deleted from the same interface used to create and repair drafts.

The popup's **Export format** control selects Compact JSON or canonical JSON-LD and remembers the choice in the browser profile. The same choice applies to extraction and session copies, downloads, and keyboard shortcuts. JSON-LD session exports contain the merged entity graph plus snapshot provenance, warnings, and observation history. Compact JSON excludes rendered-card raw text by default; **Include raw card text** is a separate remembered opt-in.

## Compact JSON projection

Compact projection contains no marketplace branches. Common job fields have stable names such as `id`, `url`, `title`, `description_excerpt`, and `skills`. Namespaced adapter fields flatten by their vocabulary-local name and convert camelCase to snake_case: for example, any adapter's `prefix:postedText` becomes `posted_text`. Missing top-level values are omitted. If multiple vocabularies on one entity use the same local name—or a local name conflicts with a common field—the qualified properties are retained under `extension_fields` rather than overwritten. Programmatic consumers may also request an explicit subset of projected entity fields.

Every compact export declares `format_version`, `adapter_version`, and extractor
version metadata. `format_version` versions the stable export envelope and
projection rules; `adapter_version` identifies the locally imported definition
that interpreted the site. A session refuses snapshots from different versions
of the same adapter, preventing one export from silently mixing extraction
contracts. Older pre-versioning compact exports are implicitly format version 1
for downstream migration compatibility.

## Current structure

- `extension/core/` — site-independent model, session, utilities, and exporters.
- `extension/options.*` — automatic-inference, appearance, and local-storage settings.
- `extension/extract.js` — compilation and extraction entry point for imported definitions.
- `extension/editor/schema-catalog.generated.js` — compact browser catalog generated from the pinned official Schema.org vocabulary.
- `reference-adapters/` — private Upwork and Guru definitions plus imperative parity oracles; excluded from the extension package.
- `lib/yaml-parser.js` — Node test entry point for the same YAML policy used by the browser.
- `tests/fixtures/` — scrubbed rendered-page fixtures.
- `scripts/scrub-upwork-search-fixture.js` — clones the actual card population from an Upwork search capture, prunes it to extraction-relevant structure, scrubs identifying values, and emits a deterministic size-bounded fixture.
- `.github/workflows/ci.yml` — checks on pushes, pull requests, manual runs, and a weekly schedule.

The original Upwork extension remains a separate project and is not modified by this repository.

## Declarative adapter work

Phase 6 currently has complete observation equivalence between declarative and imperative adapters for all available Upwork and Guru fixtures. That includes two committed, reduced real-page Upwork search fixtures preserving the captured populations of 7 and 10 rendered cards. CI checks their exact card counts, imperative/declarative parity, extraction-quality thresholds, privacy constraints, and deterministic regeneration. Coverage also includes Upwork's current `JobsList`/slugged-link card shape, fixed and hourly jobs, standalone detail, routed and retained-URL panels, three Guru encoded search routes, and Guru detail exclusion of similar-job content. The strict normalized interpreter covers constrained literal path matching, fixed URL-match pipelines, CSS and scoped XPath selector fallbacks, attribute selection, multiple-value bindings and fixed aggregation, safe dotted fields for nested records, block-level field projection, canonical-identity deduplication, page precedence, canonical identity and page metadata derived through packaged transforms, and visible failure when a known route lacks its expected component. Site-specific labels are isolated by selectors and normalized with generic operations. The reviewed `parseProjectBudgetV1` transform is shared and tested against both Upwork and Guru presentations; encoded Guru search metadata uses generic base64 and keyed-path transforms. The DSL contains no adapter-supplied parsing patterns. The temporary JSON definitions are normalized grammar-development fixtures; YAML remains the authoring and distribution format.

The popup now compiles and runs enabled locally imported definitions. The committed real-page regression gate passes without placing the private definitions or imperative adapters in the extension package.

The initial phase-7 local registry is implemented. It hashes the exact selected bytes separately from the canonical validated definition, stores an internal source copy in `chrome.storage.local`, and revalidates definitions when compiling them for extraction. Its packaged YAML policy rejects custom tags, aliases, anchors, merge keys, duplicate keys, multiple documents, unsafe mapping keys, and values outside the normalized data model. Remote sources, directory watching, signing, and update channels remain deferred. A declarative collection whose definition cannot produce collection identity still emits `dsl.collectionIdentityUnavailable` instead of silently claiming pages can merge safely.

The browser side-panel editor supports multiple typed repeating blocks, synchronized extraction tables and page highlights, editable selector suggestions and canonical identity, full release-derived Schema.org type search, range-valid nested property recommendations, and inline documentation of adapter-prefixed extension terms. Its in-page visual picker supplies scope and field evidence without requiring DevTools. Navigation and disconnects clear stale actionable data. Transform pipelines are ordered tokens backed by reviewed runtime metadata, grouped keyword-searchable autocomplete, and dynamic recommendations. **Discover fields** scans bounded item samples, promotes a strong heading link to canonical identity, maps credible Schema.org properties, and can include structurally useful unknown values as visible `_unmapped_*` fields. Re-running discovery reconciles by source identity and never overwrites reviewed edits. Selections inside Shadow DOM remain explicitly unsupported until the DSL and production interpreter share a structured boundary-crossing selector model.
