# Adapter Editor

> A point-and-click editing environment for the site2json extraction DSL.

## Summary

A site2json browser side panel turns adapter creation from hand-written selector work into teaching the extractor by example. The author selects rendered page evidence, assigns its meaning, and sees a valid adapter definition and extraction preview update immediately.

The editor has two synchronized views of the same extraction model:

- the rendered page and Site2JSON overlays show source evidence;
- site2json shows repeating blocks as tables, with one extracted entity per row and one mapped field per column.

Selection works in both directions. The in-page visual picker captures a rendered element and its frame without exposing a DOM tree. Hovering a block, field, item, or cell in Site2JSON highlights its source nodes on the rendered page; clicking pins that highlight, and double-clicking scrolls its representative source into view. These review interactions never change draft data by themselves.

This is an on-ramp to the declarative DSL, not a replacement for it. The visual editor and source editor operate on the same adapter model:

```text
pick DOM nodes -> update adapter -> update source and preview
edit source    -> validate adapter -> update highlights and preview
```

The tool is site-independent. It understands DOM structure, selector quality, the site2json DSL, and Schema.org vocabulary; it does not contain an Upwork-specific adapter-creation workflow. An Upwork adapter is simply one artifact it can produce.

The current one-type field recommender is the first slice of a broader semantic authoring model. [`SEMANTIC_COMPOSITIONS.md`](SEMANTIC_COMPOSITIONS.md) specifies the proposed separation between DOM observations and semantic interpretation, including reusable compositions made from explicit Schema.org nodes and relationships. Until that model is implemented, recommendations remain conveniences to review rather than claims about a field's meaning.

The expanded **Semantics** workspace can now analyze the accepted repeating scope before fields are added. It ranks the packaged compositions and a short list of Schema.org types from generic recurring evidence (links, headings, dates, money, multiplicity, stable DOM tokens, and compatible property ranges). The result explains which observed selectors each model can represent and never changes the selected model until the author clicks one. Ranking summaries deliberately omit sampled page text, remain authoring metadata, and do not enter exported adapter YAML.

## Why a browser side panel

The side panel leaves the rendered page visible while providing a focused extraction workspace. Site2JSON supplies its own fast visual picker, page overlays, stable selector generation, frame routing, and source previews without asking an author to navigate a native DOM tree.

The author should only need to point at rendered evidence. Context-sensitive actions remain in the editor or the picker's page-side affordances, where Site2JSON can keep the interaction consistent across ordinary documents and accessible frames.

The author should not need to understand CSS or XPath to begin. Selecting an element gives the tool several candidate identities:

- stable IDs;
- `data-*` attributes;
- semantic elements and ARIA roles;
- stable class combinations;
- relationships to a repeating parent;
- element attributes and text patterns.

site2json ranks those candidates, chooses a strong default, and leaves the selector editable.

## Core Workflow

For a search-results page, the primary flow is:

1. Open the extension popup beside the target page and choose **Open adapter editor**.
2. In **Structure**, either infer the remaining steps on a new draft or select representative rendered items with the visual picker, reviewing each proposed scope boundary and match count against page highlights.
3. In **Semantics**, choose a Schema.org type or reusable composition for each referenced entity. Use **Expand** to build related nodes and relationships in the browser side panel when useful.
4. Choose **Done with model**. The editor discovers fields when needed, or reconciles existing untouched observations against the graph.
5. In **Discover**, review the per-block inventory and resulting columns.
6. In **Review**, map or remove anything marked **Unmapped**, repair selectors with the visual picker, and inspect the extraction table.
7. Mark canonical identity and review transforms, values, coverage, and warnings.
8. In **Finish**, validate and then publish locally or export into the fixture-first authoring pipeline.

Discovery may still run before graph composition. In that order, **Done with model** semantically re-evaluates untouched observations rather than rescanning or duplicating them.

The editor never requires the author to start with terms such as "example A," `$0`, or "ancestor inference." Those remain implementation concepts. The visible workflow is selecting an item, creating a scope, selecting a value, and adding a field.

Each field action should offer common Schema.org properties first, terms from the adapter's namespace registry second, and the option to search the full known vocabulary. The author is still responsible for semantic choices: the tool can identify text and attributes, but it cannot decide whether a value genuinely means `datePosted`, `validThrough`, or something site-specific.

The schema-aware editor uses a compact catalog generated from the pinned official Schema.org v30.0 JSON-LD release. The type combobox searches the complete generated class set, while field recommendations follow class inheritance and property domains and can include one-level nested paths such as `hiringOrganization.name`. Recommendations expose every declared range and the property's Schema.org status. Schema.org does not define ordinary property cardinality, so the editor labels `one`/`many` as an editable site2json default rather than vocabulary metadata.

DOM tag, class, ID, ancestor context, link, and text evidence ranks likely properties. **Discover fields** adds those guesses directly to the draft because deleting or correcting a populated table is faster than manually locating every candidate. Guesses remain visibly distinguished from reviewed mappings, and unresolved names block publication. Extension suggestions are derived without site or marketplace rules: stable DOM tokens propose a local name, the current adapter supplies its prefix, value-shape recognition proposes a packaged transform, and the suggestion is emitted only when Schema.org has no credible match. Thus `jobRecord__budget` plus `Fixed Price | $10k-$25k` may yield `guru:budget`, but `guru` comes from the current adapter and the same evidence under another adapter or entity type produces that adapter's prefix. Explicit salary or wage evidence remains eligible for `baseSalary`.

## Adapter Library and Draft Lifecycle

The Site2JSON browser side panel is the single home for local adapter management and editing. Its adapter library imports, enables, disables, exports, replaces, and deletes published adapters. The extension options page does not duplicate the registry UI.

Published adapters and drafts use separate `chrome.storage.local` keys. Extraction reads only published, enabled definitions. Starting an edit clones the complete published definition into a draft and records the published definition digest; incomplete autosaves therefore cannot affect extraction or erase valid DSL features the visual editor does not yet expose. Publishing takes an extension-wide Web Lock, re-reads both registries inside the lock, validates the complete working definition, checks that the published base digest has not changed, atomically replaces the published entry, and removes the draft. Concurrent side panels therefore cannot overwrite one another from stale UI state. YAML export is available without publishing and is the bridge to future remote adapter sources.

The future popup **Auto-extract this page** action writes into this same draft lifecycle rather than maintaining a second builder. Automatically created drafts carry editor-only adapter provenance (`origin`, generator version, generation time, review status, and confidence summary), extending the existing suggested/manual provenance used by fields. A manual draft is never overwritten; a resumable automatic draft remains visible in the library as **Auto · unreviewed**. Medium-confidence runs may produce a one-time extraction without publishing, while only a separate higher aggregate threshold can make an automatic definition the enabled local adapter.

## Editor Model

The editor state mirrors the runtime model instead of holding one global scope:

```text
Adapter
└── Page
    ├── Block: Search results
    │   ├── scope and selector fallbacks
    │   ├── identity
    │   └── fields
    ├── Block: Featured results
    │   ├── scope and selector fallbacks
    │   ├── identity
    │   └── fields
    └── Block: Related jobs
        ├── scope and selector fallbacks
        ├── identity
        └── fields
```

Multiple blocks and multiple selector fallbacks are different concepts. A block is a logical source of entities with its own arity, role, and fidelity. Selector fallbacks describe alternate markup for that same block. The UI must not blur the two.

Each repeating block owns an extraction table. Fields are rows and matched scope items are columns, keeping most fields visible while every rendered match remains available through horizontal scrolling. The left field-name column is sticky and contains coverage plus edit and remove controls. Clicking it highlights the field across every scope; clicking an example header targets the whole item; clicking a value targets that exact occurrence. Double-clicking scrolls its representative source into view. A final **+ Add selected field** row opens the visual picker. Unmapped field rows remain visibly amber until reviewed.

Block creation currently confirms one entity type before field mapping begins. Under the proposed semantic-composition model, that remains the simple case and the reusable entity definition referenced by a block may instead own a graph of typed, related nodes. The active block supplies the repeating-scope observations used to author and test that model. Draft fields retain editor-only provenance (`manual` or `suggested`) and a locked state so future autofill can add recommendations without overwriting reviewed work. This authoring metadata is not required by the runtime adapter.

Site2JSON is one responsive browser side-panel application, as specified in [`SEMANTIC_COMPOSITIONS.md` §8](SEMANTIC_COMPOSITIONS.md#8-composition-selection-ux). It uses real Structure, Semantics, Discover, Review, and Finish routes rather than scroll targets, and a newly created block must pass through visible semantic review before discovery.

The sidebar is being split incrementally without introducing a framework or a second state owner. `sidebar.mjs` remains the mutable editor-state and command coordinator. `sidebar-workflow.js` owns route/status rendering and navigation binding; `sidebar-structure.js` owns scope-proposal rendering and refinement controls; `sidebar-semantics.js` owns semantic-model controls and rendering; `sidebar-review.js` owns the block picker and extraction-review table; `sidebar-workspace.js` owns the adapter-library and draft-picker views; and `sidebar-page-bridge.js` contains the self-contained functions serialized into the inspected page. Feature modules receive state through arguments, getters, or snapshots and submit explicit callbacks. They do not own editor state or mutate storage.

The correction-promotion runtime path is the first native-ESM vertical slice. `sidebar.mjs` imports named correction-promotion operations from `correction-promotion.mjs`, which imports the canonical `property-profile.mjs` API. The remaining classic semantic-toolbox consumer receives that API through generated `property-profile.js`; `scripts/build-property-profile-compat.mjs` is the sole owner of this temporary, one-way bridge and its freshness check. The generated artifact must be removed when semantic-toolbox migrates rather than becoming a second authored implementation.

The side panel owns draft mutations, selection state, discovery, validation, and autosave. Page-side scripts receive only packaged operations through the browser bridge and return inert observations. Automatic inference runs the same evidence, semantic, field-mapping, production-validation, and extraction-preview checks as the one-click popup path. It stores automatic provenance on the draft; only an exceptionally strong aggregate result may publish locally, while weaker results remain explicitly unreviewed drafts.

The first expanded Semantics route is also implemented as an exact relationship outline over normalized editor-only composition state. A block's already chosen Schema.org type becomes the valid one-node baseline. Authors can replace it with a packaged composition, search the complete type catalog, add range-compatible related nodes, add or remove intentional type pills, and review graph validation before continuing. The experimental freelance composition contains no site selectors or phrases. Composition state is retained beside locally published registry entries so reopening an adapter restores it, while source export remains clean runtime YAML. Compositions do not yet compile into runtime nodes; until that Stage E boundary is designed, published adapter output continues using the block's primary `schemaType` and explicit field mappings only.

Both hosts share one active block selection and use a compact block switcher whose options include type, match count, and unresolved issue count. This avoids an ever-growing horizontal tab strip as adapters gain more blocks. A semantic composition is owned by the entity definition referenced by the block, so two blocks bound to the same entity share one graph while retaining separate scope observations and coverage.

## Inferring Repeated Items

Structure supports two entrances into the same candidate review. **Infer from selection** walks upward from one representative node. **Find repeating data** first identifies bounded generic evidence such as links, headings, dates, money, images, and stable semantic DOM hooks; records their ancestor paths; and finds sibling roots containing a consistent bundle across items. The latter is also the scope-location primitive intended for automatic conversion.

The evidence-first scan does not use site names, captured phrases, or remotely supplied logic. It prefers a repeated sibling group with diverse recurring evidence, distinct per-item identity links, one collection parent, and a narrow boundary that still contains the evidence bundle. Nested repetitions such as skill tags lose to their containing cards because they do not independently contain the complete cross-kind bundle. Plain navigation links do not qualify as a rich entity collection.

For either entrance, the tool scores likely repeating boundaries. Useful evidence includes:

- structurally similar siblings;
- a stable selector matching multiple peer elements;
- repeated descendant shapes;
- consistent links, headings, or labeled values within each candidate;
- containment by an obvious list, feed, table, or results region.

The proposal must remain explicit. The UI highlights every matched scope, reports the count, and lets the author move the boundary up or down before accepting it.

After a scope is accepted, its already-collected field observations pass through the same semantic ranking used by the future automatic-conversion path. A high-confidence result prefills the root Schema.org type and, when applicable, its packaged composition, but the Semantics step remains unreviewed until the author confirms it. Low-confidence evidence leaves the type as `Thing`. Raw sampled text is not retained in the ranking explanation or draft metadata.

The Structure interface exposes this movement directly as **Narrower child** and **Wider parent** around a previewed candidate. Moving the boundary updates the rendered-page highlight and match count without changing draft state; **Use previewed scope** is the commit point. The complete candidate list remains visible for non-linear jumps and selector-quality comparison. Future keyboard bindings may invoke the same commands, but must not capture ordinary typing in form controls.

Scope candidates include explainable structural findings, not only a selector and global match count. For example:

```text
ul.module_list.cozy > li                         79 matches
✓ all matches share one stable parent
✓ 79 sibling peers have a similar structure

div > div > ul > li:nth-of-type(1)               8 matches
⚠ matches are scattered across 8 unrelated parents
⚠ positional selector
```

A global match count alone is insufficient. Scoring must consider parent clustering, sibling density, subtree similarity, and whether the proposed item boundary contains useful repeated fields. A positional selector that collects unrelated first children across the document is not a valid repeating scope merely because it matches more than one node.

### Optional second-example refinement

When one selection is ambiguous, the editor offers **Select another item like this**. The first selection remains marked while the author selects a second item; the editor then constrains candidate generation to boundaries that explain both examples. The UI does not expose "example A" and "example B" as unexplained primary actions.

Two-example inference should:

1. find candidate ancestors for both selections;
2. compare normalized subtree structure rather than exact text;
3. identify a shared selector whose matches include both candidates;
4. prefer the narrowest stable boundary that contains the fields common to both;
5. show all proposed matches for confirmation.

Inference creates a draft `scope`; it never silently changes block arity, role, or fidelity.

## Field Mapping

After a repeating scope is established, field selectors are generated relative to that scope. A selected title link might produce:

```yaml
entities:
  JobPosting:
    schemaType: JobPosting
    identity:
      field: url
    fields:
      url:
        selectors: ["h2 a[href*='/jobs/']@href"]
        transform: [absoluteUrl, stripQuery]
      title:
        selectors: ["h2 a"]
        transform: [text, trim]
      description:
        selectors: ["[data-test='job-description-text']"]
        transform: [text, collapseWhitespace]

pages:
  - id: search-results
    blocks:
      - entity: JobPosting
        scope: "[data-test='job-tile-list'] > [data-test='JobTile']"
        arity: many
        role: collection
        fidelity: summary
```

Identity is a role assigned to one real semantic field, normally `url` or
`identifier`; it is not a second internal field. Extraction evaluates that
binding once and uses the value both for the named field and JSON-LD `@id`.
The loader still accepts the older `identity.canonicalUrl` shape so saved and
published adapters can be migrated without losing their selector.

The complete generated file must also include the adapter metadata and page match conditions required by the DSL. The panel should manipulate a parsed adapter model and serialize it, rather than editing source text through string concatenation.

For each selected node, the author can choose:

- rendered text;
- a specific attribute;
- a link URL;
- one value or multiple values;
- required, monitored, or optional coverage;
- a named transform pipeline;
- a nested object, where supported by the DSL.

Transform suggestions can follow the observed value shape, but only transforms bundled with site2json may be emitted. The authoring tool must not introduce executable expressions or adapter-defined code.

Field discovery is one pipeline, not separate “schema autofill” and “scrape everything” modes. It samples a bounded number of repeating scopes, identifies structurally recurring visible text and useful attributes, and then attempts semantic mapping for every candidate. **Include values without a Schema.org match** controls only whether unmatched candidates are added. Recognized and unrecognized values otherwise pass through identical source-identity reconciliation.

Unrecognized candidates receive unique, numbered editor-only names such as `_unmapped_field_1` and a visible **Unmapped** state. They are useful columns in the live table but cannot be built into a valid adapter until the author maps them to Schema.org, accepts and documents an adapter-prefixed extension term, or removes them. This avoids inventing vocabulary while preserving the fast “show me everything and let me clean it up” workflow.

Discovery scans every matched item when a block has at most 100 items and uses that explicit bound for larger result sets. A strong, single-valued heading link is promoted directly to canonical identity. Discovery is idempotent: a field's source identity consists of its block, selector, selected attribute, and value kind. Running discovery again updates an unresolved suggestion when stronger semantic evidence becomes available, replaces a narrow automatic selector with a stronger recurring selector, adds genuinely new sources, and does not create duplicate columns. Manual edits lock a field against automatic replacement; a later discovery may report a recommendation but cannot overwrite an explicit author decision. Each discovery run is one undoable batch.

The transform pipeline is visible as ordered tokens and editable from the packaged capability list. Every runtime transform carries reviewed, inert editor metadata: category, label, description, input/output shape, typed argument definitions, bounds, and search keywords. Autocomplete groups permanent categories and adds a dynamic **Recommended** section from the current field evidence and schema range. Argument-bearing transforms open a compact structured form generated from that packaged metadata: strings, bounded integers, one-value-per-line string lists, and inert JSON lookup objects are validated by the same packaged transform contract before changing the pipeline. Configured tokens can be reopened and edited, while an imported step without compatible packaged metadata remains locked and round-trips unchanged. Selecting a known property chooses a conservative compatible default, and the editor must not name a transform that the runtime does not actually package. `parseEnglishDateV1` finds a valid absolute English or ISO calendar date inside a rendered label and emits `YYYY-MM-DD`; relative date phrases remain a separate future capability. Low-level `textSlice` supports bounded fixed-position formats, while literal delimiter transforms remain preferable when the rendered copy supplies a stable boundary.

Field names use a compact editor-owned combobox rather than relying on the browser's native `datalist`. Focusing opens the ranked vocabulary, typing filters it, and each option identifies its Schema.org or adapter-extension source, allowed ranges, vocabulary status, editor cardinality default, and meaning.

If a field name is not known for the selected Schema.org type, the editor does not silently bless it as a standard property. It asks for an adapter-prefixed term and captures its meaning, value type, cardinality, and example inline. The generated adapter stores these declarations under `vocabulary.terms`; nested fields share the declaration for their namespaced root.

## Selector Generation and Quality

Selector generation is an optimization problem, not merely a shortest-path calculation. Candidate selectors should be evaluated against both uniqueness within the chosen scope and likely stability across deployments.

Prefer, roughly in this order:

1. stable, meaningful IDs;
2. stable `data-*` attributes;
3. semantic elements and ARIA roles;
4. short combinations of meaningful classes;
5. stable relationships to labeled or otherwise identifiable elements;
6. text-anchored XPath where CSS cannot express the relationship.

Penalize:

- `:nth-child()` and other positional selectors;
- generated or hash-like class names;
- deep descendant chains;
- selectors dependent on the page outside the declared block scope;
- text selectors tied to one example's extracted value;
- selectors that unexpectedly include nested recommendations or promoted regions.

The panel reports selector quality as explainable findings, not a mysterious score. For example:

> Fragile: this selector depends on `div:nth-child(7)`. `[data-test='job-description-text']` matches the same 37 items and is likely more stable.

The author can accept the recommendation, edit the selector, or keep the original with the warning visible.

### Shadow DOM boundaries

The visual picker can encounter nodes inside a component's shadow root, but an ordinary CSS selector evaluated from `document` cannot cross that boundary. The current DSL has no syntax for a boundary crossing, so the editor detects both open and closed shadow roots and blocks scope or field creation with an explicit explanation. It must never preview a selector inside a root and then emit a document-level selector that matches zero nodes at runtime.

Slotted content is still owned by the light DOM and can be selected normally. Open roots may be supported later with a structured path made of a host selector, an explicit shadow-boundary step, and a selector within that root. Both the production interpreter and preview must consume that same structure. Closed roots are inaccessible to page JavaScript and remain unsupported.

## Live Feedback

The rendered page and extraction tables are linked:

- hovering a proposed scope highlights every proposed match;
- selecting a block header highlights all of its scopes;
- selecting an example column header scrolls to and highlights that entity's scope;
- selecting a sticky field-name row highlights every source node used for that field;
- selecting a cell highlights the exact node or nodes that produced its value;
- selecting a DOM node focuses the owning block, row, and field where that mapping is unambiguous.

Highlights are temporary pointer-transparent overlays; they do not add classes or inline styles to the target elements. Each block receives a stable color. The active field uses a secondary treatment within that block's color, while orange and red are reserved for suspicious overlap and extraction errors. Inactive blocks remain faint enough that several scopes can be viewed together without turning the page into visual noise.

Hover and click have separate highlight channels. Hover shows a temporary green preview and never destroys the current selection. Clicking a block, field row, example header, or value cell pins a blue highlight that survives scrolling and remains until another target is pinned, the author chooses **Clear highlight**, or presses Escape. When a hover preview ends, the pinned highlight remains visible.

The side panel is bound to an explicit browser tab ID. Page navigation clears stale observations and highlights immediately, while autosaved drafts remain available for recovery. All page access goes through `chrome.scripting` or picker messages scoped to that tab and frame.

The panel also shows:

- match count;
- which selector fallback matched;
- values before and after transforms;
- missing required and monitored fields;
- conflicting or ambiguous matches;
- a compact extraction preview for every matched entity;
- validation and selector-quality warnings.

Selecting an entity in the preview highlights its scope on the page. Selecting a field highlights the exact source nodes used for that value.

Source edits are parsed and validated after a short debounce. When valid, they refresh page highlights and the extraction preview. When invalid, the last valid model remains active and the editor displays a precise error path and suggested correction.

## Context-sensitive Selection Actions

The visual picker may provide page-side contextual actions, but they must remain small, reversible, and derived from the current authoring step.

For a node outside every accepted block it may offer:

```text
Selected: <li data-id="…">
No block contains this element.
[Create repeating scope]
```

For a node inside an accepted block it may offer:

```text
Selected: <h2 class="jobRecord__title">
Inside: Search results
[Add as field] [Highlight element]
```

The active block wins when nested or overlapping blocks both contain the node; selecting a different block tab changes that context. Existing mappings are recognized: selecting a node already used by `title` focuses its exact item cell rather than offering to add an unexplained duplicate. Selecting a container spanning multiple mapped fields focuses each corresponding value cell in that item. Only selecting the repeating-scope root focuses the numbered item header. An unmapped leaf reports its owning item but does not paint that item header as though the whole scope had been selected.

While a field editor is open, choosing new page evidence generates a non-destructive selector repair proposal. The editor shows the proposed selector, attribute, per-item match counts, and sampled coverage. **Use selected element** copies that proposal into the unsaved form; it never saves the field automatically.

## Suggested Panel Layout

```text
+---------------------------+     +--------------------------------------+
| Rendered page + picker    |     | Browser side-panel editor             |
| Site2JSON       [Expand ↗] |     | Site2JSON · Results       [Return]   |
| 1 2 3 4 5                 |     | 1 Structure ... 5 Finish             |
|                           |     |                                      |
| Selected DOM context      |     | graph / table / field editor /       |
| Current step summary      | <-> | validation / adapter library         |
| Block tabs                |     |                                      |
| Compact editor controls   |     | responsive full workspace            |
+---------------------------+     +--------------------------------------+
```

The rendered page remains the visual evidence canvas while the side panel owns all editable forms.

## Validation and Ground Truth

Visual editing makes selector and mapping creation faster, but it does not change the project's ground-truth rule: generated adapters and expected fixture output must not share an authoring pass.

The proposed fixture and live-page drift model is specified in [STRUCTURAL_FINGERPRINTS.md](./STRUCTURAL_FINGERPRINTS.md). It separates full scrubbed fixture integrity from compact per-block and per-variant structural baselines embedded in the DSL.

Before an adapter is considered complete, the panel should support exporting:

- the adapter definition;
- a scrubbed fixture capture;
- the current extraction as a draft for independent review;
- selector-quality and coverage findings.

An independently reviewed expected output and multiple fixtures remain necessary. A selector matching every visible card today may still fail on promoted results, missing fields, localization, or a future deployment.

## Safety and Scope

The authoring panel inherits site2json's existing constraints:

- it operates on the currently rendered document;
- it makes no background requests and performs no navigation;
- it emits inert adapter data, never executable site code;
- host permissions remain the security boundary;
- saving or exporting is an explicit user action;
- inferred structure is always presented for confirmation.

The panel may inspect the live DOM more broadly while proposing selectors, but the extraction preview must execute through the same DSL interpreter used by normal extraction. This prevents the authoring environment from accepting behavior the runtime cannot reproduce.

Schema.org lookup is likewise local. The browser ships only the generated compact catalog and performs no runtime vocabulary fetch. Maintainers update the pinned upstream snapshot explicitly, verify its recorded digest, regenerate the catalog, and review the resulting diff.

## MVP

The first useful version should stay narrow:

1. context-sensitive actions driven by the current visual selection;
2. creation, naming, selection, and removal of multiple repeating blocks;
3. explicit scope-candidate review with structural findings and page highlights;
4. text, attribute, link, and multiple-value field mappings;
5. one extraction table per block with coverage and missing-value feedback;
6. bidirectional block, row, column, cell, and DOM highlighting;
7. stable CSS selector generation relative to each scope;
8. extraction preview and DSL validation through the production interpreter;
9. local install/replace and YAML export.

Optional second-example refinement, XPath relationship generation, deeper nested-object assistance, synchronized source editing, more sophisticated discovery ranking, explicit open-shadow-root paths, and fixture capture can follow once this basic round trip is reliable.

## Success Criteria

The editor succeeds when a developer unfamiliar with selector syntax can create a valid first adapter draft by selecting examples, while an experienced adapter author can immediately refine the same artifact in source form.

More concretely:

- every visual operation produces a schema-valid intermediate adapter or a clear incomplete-state message;
- visual picks and source edits round-trip without losing unsupported-but-valid DSL fields;
- preview results are produced by the production DSL interpreter;
- every selector exposes its match count and quality findings;
- false-positive scopes are visible through both page highlights and extracted table rows;
- compact mode can inspect, recover, navigate, and open every dense operation in the expanded workspace;
- expanding and resuming never duplicate state, lose an unsaved edit, or leave two editable hosts;
- the saved result is an ordinary portable site2json adapter with no editor-host metadata required at runtime.

## Open Questions

- Should editor metadata such as chosen example nodes live only in panel state, or in a separate sidecar file?
- How should a selector be tested across multiple open pages or stored fixtures without making the panel a full test runner?
- What is the smallest useful vocabulary picker for custom namespace terms?
- Should fallback selector chains be proposed automatically from multiple good candidates or added explicitly by the author?
- How should ignored regions affect selector inference without becoming runtime DSL behavior?
- Can source-to-page synchronization reliably preserve comments and formatting, or should the canonical editor initially use JSON and format on save?
- Which future dense interfaces need specialized expanded layouts beyond the shared responsive component set?
