# Site2JSON Design Principles

**Status: Draft**

Site2JSON should be designed around four principles:

* Truth
* Maintainability
* Explainability
* Aesthetics

These are not independent concerns. They should reinforce one another and guide both product design and implementation decisions.

## Truth

The UI should stay as close as practical to the actual underlying process.

Do not present a simplified fiction when the real system can be represented clearly.

If the system contains:

* uncertainty
* competing assignments
* provenance
* confidence
* nested relationships
* variant resolution
* drift
* fallbacks
* arbitration
* unresolved states

then those concepts should remain visible in the product where they are relevant.

The goal is not to expose implementation details for their own sake. The goal is to make the system's real behavior legible.

A user should be able to understand:

* what the system observed
* what it inferred
* why it made a decision
* what alternatives existed
* where the resulting data came from
* what remains uncertain

Visualizations should therefore reflect real internal state and real events whenever possible. Animation should not simulate a process that did not occur.

The UI is a representation of the machinery, not a decorative layer placed over it.

## Maintainability

Nothing the user did not touch should become the user's responsibility to maintain.

Responsibility should be granular.

A user modifying one field, relationship, transform, override, or other decision does not mean they have assumed responsibility for the entire extractor.

The system should distinguish between:

* automatically inferred decisions
* user-reviewed decisions
* user-modified decisions
* explicitly pinned decisions
* automatically maintainable state
* state that requires user approval before changing

The smallest meaningful authored decision should be the unit of ownership.

The system should maintain everything else automatically whenever it can do so safely.

Users should not become janitors for automation.

Internally, the same principle applies to the software itself.

Code should be:

* clear
* modular
* understandable
* maintainable
* refactorable
* tested

Documentation must align with the code and describe the system rigorously.

Documentation that no longer describes the implementation is a defect.

Complexity should be carried by the system wherever possible rather than transferred to users, future developers, or documentation readers.

## Explainability

The product should explain itself through use.

A user should not need to read a manual before they can begin understanding the system.

Interfaces should expose relationships directly through:

* spatial arrangement
* labels
* synchronized highlighting
* motion
* interaction
* progressive disclosure
* contextual explanations
* visible provenance
* meaningful states and icons

When possible, explanation should arise from correspondence.

For example, a user should be able to see the relationship between:

* the source page
* the semantic model
* the extracted output

without mentally reconstructing that relationship from separate screens.

Errors and uncertainty should also be explanatory.

Do not merely tell the user that something is wrong. Show:

* what happened
* where it happened
* why it happened
* what part of the user's model contributed to it
* what can be done next

Repeated interaction should gradually teach the user the underlying concepts.

A well-designed interface should make its users more capable over time.

Documentation should deepen understanding, provide rigor, and serve as reference. It should not compensate for an interface that cannot explain itself.

## Aesthetics

Aesthetics are a first-class design principle.

They apply to the entire project, inside and out.

Aesthetics include the user interface, but they also include:

* internal architecture
* code structure and style
* documentation
* terminology
* project organization
* developer experience
* distribution and public presentation
* demonstrations and screencasts
* motion, visual design, and interaction
* the coherence of these parts as a whole

Some of these surfaces are user-facing, some are developer-facing, and some are market-facing. All of them are part of the work.

The project should be something worth caring for.

A well-designed system should create a sense of coherence, beauty, curiosity, and even wonder in the people who encounter it. That includes the people who build and maintain it.

This has practical consequences.

Beautiful internal design invites understanding and stewardship. Clean architecture is more pleasant to extend. Rigorous documentation is more satisfying to maintain. A coherent project attracts developers who want to participate in it and encourages them to preserve its integrity.

Aesthetics therefore contribute directly to long-term project health.

They can also reduce the impulse to abandon a mature system simply because creating something new feels more rewarding. Refinement, maintenance, documentation, presentation, and evolution should themselves remain creatively satisfying.

The goal is not to avoid change or rewrites when they are necessary. The goal is to build something whose continued care remains desirable.

Externally, visual hierarchy, spacing, movement, timing, weight, restraint, contrast, and composition should make the underlying system easier to perceive and more satisfying to use.

Motion should communicate state or process.

Color should communicate meaning.

Layout should reveal relationships.

Visual emphasis should direct attention toward what matters.

Beauty must not conceal complexity or uncertainty. It should make truth easier to see.

Aesthetics are experienced largely through feel, but their effects on comprehension, care, participation, and stewardship are concrete. They remain accountable to the other principles just as the other principles remain accountable to aesthetics.

If something looks impressive but misrepresents the process, it violates Truth.

If something is technically maintainable but unpleasant to understand, extend, or inhabit, its Maintainability is incomplete.

If something explains itself accurately but does so in a needlessly confusing or graceless form, Explainability alone has not finished the design.

The goal is not prettiness.

The goal is to create a system whose internal structure, external expression, and continued evolution inspire care through their coherence and beauty.

## Combined Principle

These four ideas should be treated as one design system:

They are equal principles, not a hierarchy. Each guards a different dimension of the product, and none should be sacrificed to satisfy another.

When the principles appear to conflict, treat that conflict as a design problem. Creativity should find a form that preserves what each principle protects.

**Truth determines what must be represented.**

**Explainability determines how it reveals itself.**

**Maintainability determines who carries the burden over time.**

**Aesthetics determine what experiencing the system feels like.**

When a design decision is unclear, evaluate it against all four.

Prefer solutions that satisfy several principles at once.

The strongest Site2JSON designs should not merely work. They should reveal how they work, teach the user while they are being used, remain maintainable without unnecessary user intervention, and feel coherent enough that the interface itself becomes part of the explanation.
