# site2json vocabulary

site2json uses Schema.org wherever an existing term fits. The terms below cover extraction provenance and marketplace fields that do not have an appropriate Schema.org equivalent.

Namespace prefixes:

- `site2json` — `https://site2json.dev/ns/`
- `upwork` — `https://site2json.dev/ns/upwork#`
- `guru` — `https://site2json.dev/ns/guru#`

## Core terms

### `site2json:rawText`

- Meaning: normalized rendered text from the DOM region used to produce an entity observation.
- Datatype: string.
- Cardinality: zero or one per observed entity.
- Example: `"site2json:rawText": "Posted yesterday Fixed-price ..."`

### `site2json:observations`

- Meaning: extraction observations that contributed to a session-merged entity.
- Datatype: array of objects containing `extractionId`, `fidelity`, and `extractedAt`.
- Cardinality: one array per session-merged entity; one or more entries.
- Example: `"site2json:observations": [{"extractionId":"r_123","fidelity":"summary","extractedAt":"2026-08-08T12:00:00Z"}]`

## Upwork terms

All Upwork terms have cardinality zero or one per `JobPosting` unless stated otherwise.

| Term | Meaning | Datatype | Example |
|---|---|---|---|
| `upwork:postedText` | Rendered relative posting time | string | `"Posted 2 hours ago"` |
| `upwork:budget` | Parsed hourly or fixed-price budget | object | `{"type":"hourly","minimum":30,"maximum":50,"currency":"USD"}` |
| `upwork:experienceLevel` | Requested marketplace experience tier | string | `"Intermediate"` |
| `upwork:duration` | Rendered project-duration range | string | `"1 to 3 months"` |
| `upwork:weeklyHours` | Rendered weekly-hours range | string | `"Less than 30 hrs/week"` |
| `upwork:client` | Marketplace client signals | object | `{"payment_verified":true,"location":"United States"}` |
| `upwork:activity` | Proposal and interviewing activity | object | `{"proposal_count_text":"5 to 10","interviewing":2}` |
| `upwork:connectCost` | Connects required to submit a proposal | integer | `8` |

The nested keys inside `upwork:client`, `upwork:activity`, and `upwork:budget` are compact records rather than independent RDF properties. Their shapes are maintained by the bundled Upwork adapter and compact exporter until the canonical modeling of these marketplace-specific records is revisited.

## Guru terms

All Guru terms have cardinality zero or one per `JobPosting` unless stated otherwise.

| Term | Meaning | Datatype | Example |
|---|---|---|---|
| `guru:postedText` | Rendered relative posting time | string | `"2 hrs ago"` |
| `guru:budget` | Parsed fixed, hourly, or open-choice project budget | object | `{"type":"fixed","minimum":500,"maximum":1000,"currency":"USD"}` |
| `guru:quoteCount` | Number of quotes shown for the job | integer | `8` |
| `guru:category` | Rendered top-level job category | string | `"Programming & Development"` |
| `guru:subcategory` | Rendered job subcategory | string | `"Data Science & Analytics"` |
| `guru:locationRequirement` | Rendered preferred or required worker location | string | `"Example Country"` |
| `guru:employer` | Employer identity and marketplace-history signals | object | `{"location":"Example Country","totalSpend":2500,"feedbackPercent":98}` |

`guru:employer.totalSpend` is the employer's historical marketplace spend, not the project budget. The nested keys inside `guru:budget` and `guru:employer` are compact records rather than independent RDF properties. Their shapes are maintained by the bundled Guru adapter and compact exporter until canonical modeling is revisited.
