"use strict";

const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const METADATA = path.join(ROOT, "third_party/schemaorg/source.json");
const OUTPUT = path.join(ROOT, "extension/editor/schema-catalog.generated.js");

function array(value) {
  return value === undefined ? [] : Array.isArray(value) ? value : [value];
}

function schemaName(value) {
  const id = typeof value === "string" ? value : value?.["@id"];
  if (typeof id !== "string") return null;
  if (id.startsWith("schema:")) return id.slice("schema:".length);
  if (id.startsWith("https://schema.org/")) return id.slice("https://schema.org/".length);
  return null;
}

function literal(value) {
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return literal(value.find((item) => typeof item === "string" || item?.["@language"] === "en") || value[0]);
  if (value && typeof value === "object") return typeof value["@value"] === "string" ? value["@value"] : "";
  return "";
}

function statusOf(node) {
  const section = array(node["schema:isPartOf"]).map((value) => value?.["@id"] || value).find(Boolean) || "";
  if (section.includes("pending.schema.org")) return "pending";
  if (section.includes("health-lifesci.schema.org")) return "health-lifesci";
  if (section.includes("bib.schema.org")) return "bibliographic";
  if (section.includes("auto.schema.org")) return "automotive";
  if (section.includes("meta.schema.org")) return "meta";
  return "core";
}

function hasType(node, type) {
  return array(node["@type"]).includes(type);
}

function sortedRecord(entries) {
  return Object.fromEntries(entries.sort(([left], [right]) => left.localeCompare(right)));
}

function buildCatalog(document, metadata) {
  if (!document || !Array.isArray(document["@graph"])) throw new Error("Schema.org snapshot requires an @graph array.");
  const classes = [];
  const properties = [];
  for (const node of document["@graph"]) {
    const name = schemaName(node["@id"]);
    if (!name) continue;
    if (hasType(node, "rdfs:Class")) {
      classes.push([name, {
        supers: array(node["rdfs:subClassOf"]).map(schemaName).filter(Boolean).sort(),
        description: literal(node["rdfs:comment"]).replace(/\s+/g, " ").trim(),
        status: statusOf(node),
        ...(schemaName(node["schema:supersededBy"]) ? { supersededBy: schemaName(node["schema:supersededBy"]) } : {})
      }]);
    } else if (hasType(node, "rdf:Property")) {
      const domains = array(node["schema:domainIncludes"]).map(schemaName).filter(Boolean).sort();
      const ranges = array(node["schema:rangeIncludes"]).map(schemaName).filter(Boolean).sort();
      if (!domains.length || !ranges.length) continue;
      properties.push([name, {
        domains,
        ranges,
        description: literal(node["rdfs:comment"]).replace(/\s+/g, " ").trim(),
        status: statusOf(node),
        ...(schemaName(node["schema:supersededBy"]) ? { supersededBy: schemaName(node["schema:supersededBy"]) } : {})
      }]);
    }
  }
  return {
    version: metadata.version,
    source: metadata.source,
    sourceSha256: metadata.sourceSha256,
    classes: sortedRecord(classes),
    properties: sortedRecord(properties)
  };
}

function moduleSource(catalog) {
  return `/* Generated from Schema.org ${catalog.version}; do not edit by hand.\n * Source: ${catalog.source}\n * Licensed under Apache-2.0; see third_party/schemaorg/LICENSE.\n */\n(function initializeSchemaCatalog(root, factory) {\n  \"use strict\";\n  const catalog = factory();\n  root.Site2JsonSchemaCatalog = catalog;\n  if (typeof module === \"object\" && module.exports) module.exports = catalog;\n})(typeof globalThis === \"object\" ? globalThis : this, function schemaCatalogFactory() {\n  \"use strict\";\n  return Object.freeze(${JSON.stringify(catalog)});\n});\n`;
}

function readMetadata() {
  return JSON.parse(fs.readFileSync(METADATA, "utf8"));
}

function generate() {
  const metadata = readMetadata();
  const snapshot = path.join(ROOT, `third_party/schemaorg/schemaorg-v${metadata.version}.jsonld`);
  const document = JSON.parse(fs.readFileSync(snapshot, "utf8"));
  return moduleSource(buildCatalog(document, metadata));
}

function main() {
  const source = generate();
  if (process.argv.includes("--check")) {
    if (!fs.existsSync(OUTPUT) || fs.readFileSync(OUTPUT, "utf8") !== source) {
      throw new Error("Generated Schema.org catalog is stale. Run npm run build:schemaorg.");
    }
    return;
  }
  fs.writeFileSync(OUTPUT, source);
}

if (require.main === module) main();

module.exports = { buildCatalog, generate, moduleSource, statusOf };
