import { build } from "esbuild";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const compatibilityPath = path.join(root, "extension/core/property-profile.js");
const check = process.argv.includes("--check");
const result = await build({
  entryPoints: [path.join(root, "extension/core/property-profile.mjs")],
  outfile: compatibilityPath,
  bundle: true,
  format: "iife",
  globalName: "Site2JsonPropertyProfile",
  platform: "browser",
  target: ["chrome120"],
  legalComments: "none",
  banner: { js: "// Generated compatibility bridge from property-profile.mjs. Remove after the final classic consumer migrates." },
  footer: { js: "globalThis.Site2JsonPropertyProfile = Site2JsonPropertyProfile; if (typeof module === \"object\" && module.exports) { globalThis.Site2JsonTransforms ||= require(\"./transforms\"); module.exports = Site2JsonPropertyProfile; }" },
  write: false
});
const generated = result.outputFiles[0].text;

if (check) {
  const current = await readFile(compatibilityPath, "utf8").catch(() => "");
  if (current !== generated) {
    console.error("Property-profile compatibility bridge is stale. Run npm run build:property-profile-compat.");
    process.exit(1);
  }
} else {
  await writeFile(compatibilityPath, generated);
  console.log("Generated the temporary property-profile classic compatibility bridge.");
}
