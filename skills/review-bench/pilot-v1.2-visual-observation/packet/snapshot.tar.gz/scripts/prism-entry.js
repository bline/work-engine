"use strict";

const Prism = require("prismjs/components/prism-core");
require("prismjs/components/prism-json");

globalThis.Site2JsonPrism = Prism;
