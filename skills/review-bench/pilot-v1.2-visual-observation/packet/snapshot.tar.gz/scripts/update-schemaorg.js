"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const ROOT = path.resolve(__dirname, "..");
const VERSION = "30.0";
const SOURCE_URL = `https://schema.org/version/${VERSION}/schemaorg-current-https.jsonld`;
const SOURCE_SHA256 = "0f0c97a4f666b2f8563573fe48453782fd51b87a504523cf0c9aff6a71c3eec4";
const LICENSE_URL = `https://raw.githubusercontent.com/schemaorg/schemaorg/v${VERSION}/LICENSE`;
const LICENSE_SHA256 = "cb5e8e7e5f4a3988e1063c142c60dc2df75605f4c46515e776e3aca6df976e14";
const DESTINATION = path.join(ROOT, "third_party/schemaorg");

function digest(bytes) {
  return crypto.createHash("sha256").update(bytes).digest("hex");
}

async function download(url, expectedDigest) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Could not download ${url}: HTTP ${response.status}`);
  const bytes = Buffer.from(await response.arrayBuffer());
  const actual = digest(bytes);
  if (actual !== expectedDigest) throw new Error(`Digest mismatch for ${url}: expected ${expectedDigest}, received ${actual}`);
  return bytes;
}

async function main() {
  const [snapshot, license] = await Promise.all([
    download(SOURCE_URL, SOURCE_SHA256),
    download(LICENSE_URL, LICENSE_SHA256)
  ]);
  fs.mkdirSync(DESTINATION, { recursive: true });
  fs.writeFileSync(path.join(DESTINATION, `schemaorg-v${VERSION}.jsonld`), snapshot);
  fs.writeFileSync(path.join(DESTINATION, "LICENSE"), license);
  fs.writeFileSync(path.join(DESTINATION, "source.json"), `${JSON.stringify({
    version: VERSION,
    source: SOURCE_URL,
    sourceSha256: `sha256:${SOURCE_SHA256}`,
    license: "Apache-2.0",
    licenseSource: LICENSE_URL,
    licenseSha256: `sha256:${LICENSE_SHA256}`
  }, null, 2)}\n`);
  execFileSync(process.execPath, [path.join(ROOT, "scripts/build-schemaorg-catalog.js")], { stdio: "inherit" });
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});
