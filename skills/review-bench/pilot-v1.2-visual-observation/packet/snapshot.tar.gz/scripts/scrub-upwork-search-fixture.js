"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { JSDOM, VirtualConsole } = require("jsdom");

const sourcePath = process.argv[2] && path.resolve(process.argv[2]);
const outputPath = process.argv[3] && path.resolve(process.argv[3]);
if (!sourcePath || !outputPath) {
  throw new Error("Usage: node scripts/scrub-upwork-search-fixture.js RAW.html OUTPUT.html");
}

const TARGET_SELECTORS = [
  '[data-test*="job-pubilshed-date" i]',
  '[data-test*="published-date" i]',
  '[data-test*="job-tile-title" i]',
  '[data-test="payment-verified"]',
  '[data-test="total-feedback"]',
  '[data-test="feedback-rating UpCRating"]',
  '[data-test="total-spent"]',
  '[data-test="location"]',
  '[data-test="job-type-label"]',
  '[data-test="experience-level"]',
  '[data-test="is-fixed-price"]',
  '[data-test="duration-label"]',
  '[data-test="UpCLineClamp JobDescription"]',
  '[data-test="token"]',
  '[data-test="proposals-tier"]'
];
const TARGET_SELECTOR = TARGET_SELECTORS.join(",");
const MAX_FIXTURE_BYTES = 250_000;

function textOf(node) {
  return (node?.textContent || "").replace(/\s+/g, " ").trim();
}

function first(root, selectors) {
  for (const selector of selectors) {
    const selected = root.querySelector(selector);
    if (selected) return selected;
  }
  return null;
}

function keepTargetBranches(root) {
  const keep = new Set([root]);
  for (const target of root.querySelectorAll(TARGET_SELECTOR)) {
    keep.add(target);
    for (const descendant of target.querySelectorAll("*")) keep.add(descendant);
    for (let current = target.parentElement; current && current !== root; current = current.parentElement) keep.add(current);
  }
  for (const element of [...root.querySelectorAll("*")].reverse()) {
    if (!keep.has(element)) element.remove();
  }
  for (const node of [...root.querySelectorAll("script, style, svg, img, picture, video, audio, iframe, canvas")]) node.remove();
  for (const node of [...root.querySelectorAll("form, input, button")]) {
    if (!node.matches(TARGET_SELECTOR) && !node.querySelector(TARGET_SELECTOR)) node.remove();
  }
  const walker = root.ownerDocument.createTreeWalker(root, 4);
  const textNodes = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode);
  for (const node of textNodes) {
    if (!node.parentElement?.closest(TARGET_SELECTOR)) node.textContent = " ";
  }
}

function sanitizeAttributes(root, cardIndex) {
  let attributeIndex = 0;
  for (const element of [root, ...root.querySelectorAll("*")]) {
    for (const attribute of [...element.attributes]) {
      const name = attribute.name.toLowerCase();
      if (name === "class" || name === "data-test" || name === "data-ev-label") continue;
      if (name === "href") {
        element.setAttribute(name, "#");
      } else if (name === "id") {
        element.setAttribute(name, `fixture-${cardIndex + 1}-${++attributeIndex}`);
      } else if (name.startsWith("aria-") || name === "title" || name === "name" || name === "role" || name === "tabindex") {
        element.setAttribute(name, name === "tabindex" ? "-1" : "fixture");
      } else {
        element.removeAttribute(attribute.name);
      }
    }
  }
}

function setText(root, selector, value) {
  const selected = root.querySelector(selector);
  if (selected) selected.textContent = value;
  return selected;
}

function scrubCard(sourceCard, cardIndex) {
  const original = {
    href: first(sourceCard, ['a[href*="/jobs/"]'])?.getAttribute("href") || "",
    title: textOf(first(sourceCard, ['[data-test*="job-tile-title" i]'])),
    description: textOf(first(sourceCard, ['[data-test="UpCLineClamp JobDescription"]'])),
    location: textOf(first(sourceCard, ['[data-test="location"]']))
  };
  original.alreadyScrubbed = /^Example captured job \d+$/.test(original.title)
    && (!original.description || /^Generic captured description \d+\b/.test(original.description))
    && /^\/jobs\/example-captured-job-\d+_~\d{18}$/.test(original.href);
  const card = sourceCard.cloneNode(true);
  keepTargetBranches(card);
  sanitizeAttributes(card, cardIndex);

  const sequence = String(cardIndex + 1).padStart(18, "0");
  const title = first(card, ['[data-test*="job-tile-title" i]']);
  if (!title) throw new Error(`Captured card ${cardIndex + 1} has no title target.`);
  title.textContent = `Example captured job ${cardIndex + 1}`;
  if (title.tagName === "A") title.setAttribute("href", `/jobs/example-captured-job-${cardIndex + 1}_~${sequence}`);
  else {
    const link = title.querySelector("a") || title.closest("a");
    if (link) link.setAttribute("href", `/jobs/example-captured-job-${cardIndex + 1}_~${sequence}`);
  }
  setText(card, '[data-test*="job-pubilshed-date" i]', `Posted ${cardIndex + 1} hours ago`)
    || setText(card, '[data-test*="published-date" i]', `Posted ${cardIndex + 1} hours ago`);

  const fixedBudget = card.querySelector('[data-test="is-fixed-price"]');
  const jobType = card.querySelector('[data-test="job-type-label"]');
  if (fixedBudget) {
    fixedBudget.textContent = `Est. budget: $${500 + cardIndex * 25}.00`;
    if (jobType) jobType.textContent = "Fixed price";
  } else if (jobType) {
    jobType.textContent = `Hourly: $${20 + cardIndex}.00 - $${35 + cardIndex}.00`;
  }

  const description = card.querySelector('[data-test="UpCLineClamp JobDescription"]');
  if (description) {
    description.textContent = fixedBudget && cardIndex % 2 === 0
      ? `Generic captured description ${cardIndex + 1}. A source-data example contains $10-$12 and is not the project budget.`
      : `Generic captured description ${cardIndex + 1} for a privacy-safe extraction fixture.`;
  }
  setText(card, '[data-test="experience-level"]', cardIndex % 3 === 0 ? "Expert" : cardIndex % 3 === 1 ? "Intermediate" : "Entry Level");

  const duration = card.querySelector('[data-test="duration-label"]');
  if (duration) {
    const strong = duration.querySelectorAll("strong");
    if (strong.length >= 2) {
      strong[0].textContent = "Est. time:";
      strong[1].textContent = cardIndex % 2 ? "1 to 3 months, Less than 30 hrs/week" : "3 to 6 months, More than 30 hrs/week";
    } else {
      duration.textContent = "Est. time: 1 to 3 months, Less than 30 hrs/week";
    }
  }

  const payment = card.querySelector('[data-test="payment-verified"]');
  if (payment) payment.textContent = cardIndex % 2 ? "Unverified Payment unverified" : "Verified Payment verified";
  setText(card, '[data-test="total-feedback"]', `Rating is 4.${cardIndex % 10} out of 5. 4.${cardIndex % 10} Stars, based on ${cardIndex + 1} feedbacks`);
  setText(card, '[data-test="feedback-rating UpCRating"]', `4.${cardIndex % 10} out of 5 stars`);
  setText(card, '[data-test="total-spent"]', `$${cardIndex + 1}K+ spent`);
  setText(card, '[data-test="location"]', `Location Example Country ${String.fromCharCode(65 + (cardIndex % 26))}`);
  setText(card, '[data-test="proposals-tier"]', cardIndex % 2 ? "Proposals: 20 to 50" : "Proposals: 5 to 10");
  [...card.querySelectorAll('[data-test="token"]')].forEach((token, skillIndex) => {
    token.textContent = ["Python", "Automation", "Data Processing", "Microsoft Excel"][skillIndex % 4];
  });

  return { card, original };
}

function cloneShell(source, selector, fallbackTag, outputDocument) {
  const selected = source.querySelector(selector);
  const shell = selected ? selected.cloneNode(false) : outputDocument.createElement(fallbackTag);
  sanitizeAttributes(shell, 0);
  return outputDocument.importNode(shell, true);
}

function sanitizedMetadata(source, outputDocument) {
  const fragment = outputDocument.createDocumentFragment();
  for (const meta of source.querySelectorAll("head meta")) {
    const clone = outputDocument.createElement("meta");
    for (const name of ["name", "property", "http-equiv", "charset"]) {
      if (meta.hasAttribute(name)) clone.setAttribute(name, meta.getAttribute(name));
    }
    if (meta.hasAttribute("content")) clone.setAttribute("content", "fixture");
    fragment.append(clone);
  }
  for (const script of source.querySelectorAll('head script[type="application/ld+json"]')) {
    try {
      const scrub = (value) => {
        if (Array.isArray(value)) return value.map(scrub);
        if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, scrub(item)]));
        if (typeof value === "string") return "fixture";
        if (typeof value === "number") return 0;
        return value;
      };
      const clone = outputDocument.createElement("script");
      clone.type = "application/ld+json";
      clone.textContent = JSON.stringify(scrub(JSON.parse(script.textContent)));
      fragment.append(clone);
    } catch {
      throw new Error("Captured JSON-LD could not be parsed safely.");
    }
  }
  return fragment;
}

const virtualConsole = new VirtualConsole();
const sourceDocument = new JSDOM(fs.readFileSync(sourcePath, "utf8"), { virtualConsole }).window.document;
const sourceCards = [...sourceDocument.querySelectorAll('[data-test="JobTile"][data-ev-label="search_results_impression"]')];
if (!sourceDocument.querySelector('[data-test="JobsList"]')) throw new Error("Raw capture has no JobsList component.");
if (sourceCards.length < 2) throw new Error("Raw capture must contain at least two rendered job cards.");

const outputDom = new JSDOM("<!doctype html><html lang=\"en\"><head><title>Scrubbed captured Upwork search</title></head><body></body></html>");
const outputDocument = outputDom.window.document;
outputDocument.head.append(sanitizedMetadata(sourceDocument, outputDocument));
const main = cloneShell(sourceDocument, '[data-test="JobsPage"]', "main", outputDocument);
if (!main.hasAttribute("data-test")) main.setAttribute("data-test", "JobsPage");
const list = cloneShell(sourceDocument, '[data-test="JobsList"]', "section", outputDocument);
if (!list.hasAttribute("data-test")) list.setAttribute("data-test", "JobsList");
main.append(list);
outputDocument.body.append(main);

const originals = [];
for (const [index, sourceCard] of sourceCards.entries()) {
  const { card, original } = scrubCard(sourceCard, index);
  list.append(outputDocument.importNode(card, true));
  originals.push(original);
}

const fixture = `<!doctype html>\n${outputDocument.documentElement.outerHTML}\n`;
const fixtureBytes = Buffer.byteLength(fixture);
if (fixtureBytes > MAX_FIXTURE_BYTES) throw new Error(`Scrubbed fixture is ${fixtureBytes} bytes; maximum is ${MAX_FIXTURE_BYTES}.`);
if (/data-v-|<style|<svg|<iframe|data:(?:image|application)\/|https?:\/\//i.test(fixture)) throw new Error("Scrubbed fixture retains forbidden implementation or remote payloads.");
for (const original of originals) {
  if (original.alreadyScrubbed) continue;
  for (const value of [original.href, original.title, original.description]) {
    if (value.length >= 16 && fixture.includes(value)) throw new Error("Scrubbed fixture retains captured identity or content text.");
  }
  const id = original.href.match(/~(\d{8,})/)?.[1];
  if (id && fixture.includes(id)) throw new Error("Scrubbed fixture retains a captured job identifier.");
}

fs.writeFileSync(outputPath, fixture, { encoding: "utf8", mode: 0o644 });
process.stdout.write(JSON.stringify({ output: outputPath, cards: sourceCards.length, bytes: fixtureBytes }) + "\n");
