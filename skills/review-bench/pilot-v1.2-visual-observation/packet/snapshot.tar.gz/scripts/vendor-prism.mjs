import { build } from "esbuild";
import { copyFile, mkdir } from "node:fs/promises";

await mkdir("extension/vendor", { recursive: true });
await build({
  entryPoints: ["scripts/prism-entry.js"],
  outfile: "extension/vendor/prism-json.js",
  bundle: true,
  format: "iife",
  platform: "browser",
  target: ["chrome120"],
  legalComments: "none",
  minify: true
});
await copyFile("node_modules/prismjs/LICENSE", "extension/vendor/PRISM-LICENSE.txt");
