"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const source = path.join(root, "node_modules", "yaml", "browser");
const target = path.join(root, "extension", "vendor", "yaml");
if (!fs.existsSync(source)) throw new Error("Run npm install before vendoring the YAML parser.");
fs.mkdirSync(path.dirname(target), { recursive: true });
fs.cpSync(source, target, { recursive: true, force: true });
fs.copyFileSync(path.join(root, "node_modules", "yaml", "LICENSE"), path.join(root, "extension", "vendor", "YAML-LICENSE.txt"));
process.stdout.write(`Vendored yaml ${require("yaml/package.json").version}\n`);
