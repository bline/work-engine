#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const DEFAULT_WIDTHS = [320, 480, 800];
const DEFAULT_HEIGHT = 900;
const WAIT_INTERVAL = 100;

export const POPUP_TOUR_STATES = Object.freeze([
  Object.freeze({
    name: "Popup · adapter ready", kind: "ready", title: "Adapter ready",
    detail: "guru is enabled for this page. Run will use it without inference.",
    threshold: "Automatic confidence threshold: High", result: false, session: false
  }),
  Object.freeze({
    name: "Popup · automatic inference", kind: "partial", title: "No adapter for this page",
    detail: "Run will infer the structure, semantics, and fields automatically. It stops in the editor rather than guessing below high confidence.",
    threshold: "Automatic confidence threshold: High", result: false, session: false
  }),
  Object.freeze({
    name: "Popup · extraction complete", kind: "ready", title: "20 entities extracted",
    detail: "guru adapter; 100% required fields, 100% monitored fields.",
    threshold: "Automatic confidence threshold: High", result: true, session: false
  }),
  Object.freeze({
    name: "Popup · active session", kind: "ready", title: "Page added",
    detail: "40 unique entities are in the session.",
    threshold: "Automatic confidence threshold: High", result: true, session: true
  })
]);

export const VARIANT_RECOVERY_TOUR_STATES = Object.freeze([
  "Semantics · variant attention",
  "Semantics · variant evidence resolver",
  "Semantics · exact-shape fallback accepted",
  "Semantics · variant attention after shape change"
]);

export function parseWidths(value = "") {
  const widths = String(value).split(",").map((part) => Number(part.trim())).filter((width) => Number.isInteger(width) && width >= 240 && width <= 1600);
  if (!widths.length) return DEFAULT_WIDTHS.slice();
  return [...new Set(widths)];
}

export function tilePositions(size, viewport, overlap = 48, limit = 12) {
  if (!Number.isFinite(size) || !Number.isFinite(viewport) || size <= viewport || viewport <= overlap) return [0];
  const maximum = Math.max(0, size - viewport);
  const step = viewport - overlap;
  const positions = [0];
  for (let position = step; position < maximum && positions.length < limit - 1; position += step) positions.push(position);
  if (positions.at(-1) !== maximum) positions.push(maximum);
  return positions.slice(0, limit);
}

function slug(value) {
  return String(value).trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "capture";
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}

function escapeMarkdown(value) {
  return String(value).replace(/\\/g, "\\\\").replace(/\|/g, "\\|").replace(/\r?\n/g, "<br>");
}

function mermaidText(value, maximum = 100) {
  return String(value || "")
    .replace(/\r?\n/g, " ")
    .replace(/["|<>\[\]{}()]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maximum);
}

function provenanceStates(manifest) {
  const states = [];
  const seen = new Set();
  for (const capture of manifest.captures || []) {
    const provenance = capture.provenance;
    if (!provenance) continue;
    const key = `${provenance.journey || "tour"}\u0000${capture.state}`;
    if (seen.has(key)) continue;
    seen.add(key);
    states.push({ key, state: capture.state, provenance });
  }
  return states;
}

export function renderProvenanceGraph(manifest, { direction = "TD", level = "screen" } = {}) {
  const states = provenanceStates(manifest);
  if (!states.length) return `flowchart ${direction}\n  empty[\"No provenance recorded\"]`;
  if (level === "route") {
    const routeNodes = [];
    const nodeByKey = new Map();
    const routeByState = new Map(states.map((item) => [item.key, item.provenance.route || routeFromState(item.state)]));
    for (const item of states) {
      const journey = item.provenance.journey || "tour";
      const route = item.provenance.route || routeFromState(item.state);
      const key = `${journey}\u0000${route}`;
      if (nodeByKey.has(key)) continue;
      const node = { key, journey, route, identifier: `route${routeNodes.length + 1}` };
      routeNodes.push(node);
      nodeByKey.set(key, node);
    }
    const lines = [`flowchart ${direction}`];
    for (const node of routeNodes) lines.push(`  ${node.identifier}[\"${mermaidText(`${node.journey} · ${node.route}`)}\"]`);
    const edges = new Set();
    for (const item of states) {
      const provenance = item.provenance;
      if (!provenance.from) continue;
      const journey = provenance.journey || "tour";
      const fromRoute = routeByState.get(`${journey}\u0000${provenance.from}`);
      const toRoute = provenance.route || routeFromState(item.state);
      if (!fromRoute || fromRoute === toRoute) continue;
      const from = nodeByKey.get(`${journey}\u0000${fromRoute}`)?.identifier;
      const to = nodeByKey.get(`${journey}\u0000${toRoute}`)?.identifier;
      if (!from || !to || edges.has(`${from}\u0000${to}`)) continue;
      edges.add(`${from}\u0000${to}`);
      lines.push(`  ${from} --> ${to}`);
    }
    return lines.join("\n");
  }
  const identifiers = new Map(states.map((item, index) => [item.key, `state${index + 1}`]));
  const lines = [`flowchart ${direction}`];
  for (const item of states) {
    const identifier = identifiers.get(item.key);
    lines.push(`  ${identifier}[\"${mermaidText(item.state)}\"]`);
  }
  for (const item of states) {
    const provenance = item.provenance;
    if (!provenance.from) continue;
    const from = identifiers.get(`${provenance.journey || "tour"}\u0000${provenance.from}`);
    const to = identifiers.get(item.key);
    if (!from || !to) continue;
    const actions = (provenance.actions || [])
      .map((entry) => `${entry.action || "action"} ${entry.description || entry.target || ""}`.trim())
      .join("; ");
    lines.push(actions
      ? `  ${from} -->|${mermaidText(actions, 120)}| ${to}`
      : `  ${from} --> ${to}`);
  }
  return lines.join("\n");
}

export function renderMarkdownTour(manifest) {
  const widths = manifest.widths || [];
  const routes = markdownRoutes(manifest);
  const preferredHighlights = [
    /^Adapter library$/i,
    /^Semantic Library$/i,
    /^Structure · complete$/i,
    /^Semantics · graph editor$/i,
    /^Review · discovered fields$/i,
    /^Finish · built adapter$/i
  ];
  const highlights = preferredHighlights.map((pattern) => {
    const candidates = (manifest.captures || []).filter((capture) => pattern.test(capture.state) && (capture.scroll?.x ?? 0) === 0);
    return candidates.find((capture) => capture.width === Math.max(...widths)) || candidates[0];
  }).filter(Boolean);
  for (const state of [...new Set((manifest.captures || []).map((capture) => capture.state))]) {
    if (highlights.length >= 6 || highlights.some((capture) => capture.state === state)) continue;
    const candidates = manifest.captures.filter((capture) => capture.state === state && (capture.scroll?.x ?? 0) === 0);
    const capture = candidates.find((candidate) => candidate.width === Math.max(...widths)) || candidates[0];
    if (capture) highlights.push(capture);
  }
  const highlightMarkdown = highlights.map((capture) =>
    `### ${escapeMarkdown(capture.state)}\n\n<a href="${capture.file}"><img src="${capture.file}" alt="${escapeHtml(`${capture.state} — ${capture.label}`)}" width="720"></a>`
  ).join("\n\n");
  const routeRows = routes.map((route) =>
    `| [${escapeMarkdown(route.label)}](screens/${route.file}) | ${route.states.length} | ${route.captures.length} |`
  ).join("\n");
  return `# Site2JSON visual tour

Generated ${escapeMarkdown(manifest.createdAt)} from ${escapeMarkdown(manifest.inspectedPage || "an inspected page")}.

- Theme: **${escapeMarkdown(manifest.theme || "saved preference")}**
- Viewport widths: ${widths.map((width) => `**${width}px**`).join(", ")}
- Viewport height: **${manifest.height}px**
- Captures: **${manifest.captures?.length || 0}**
- Run completed: **${manifest.completed ? "yes" : "no"}**
- Disposable draft discarded: **${manifest.draftDiscarded ? "yes" : "no"}**

Open the [interactive contact sheet](index.html) or inspect the [machine-readable manifest](manifest.json).

## Provenance

The graph is generated from the same per-capture provenance stored in \`manifest.json\`. Edge labels describe the action that moved the tour between logical screens. Separate journeys may appear as disconnected paths.

\`\`\`mermaid
${renderProvenanceGraph(manifest, { level: "route" })}
\`\`\`

## Highlights

${highlightMarkdown || "No representative screenshots were captured."}

## Browse every screen

| Area | Screens | Captures |
| --- | ---: | ---: |
${routeRows || "| No screenshots captured | 0 | 0 |"}
`;
}

function markdownRoutes(manifest) {
  const routes = [];
  const byRoute = new Map();
  for (const capture of manifest.captures || []) {
    const routeName = capture.provenance?.route || routeFromState(capture.state) || "other";
    if (!byRoute.has(routeName)) {
      const route = { name: routeName, label: routeName.replace(/(^|-)([a-z])/g, (_, prefix, letter) => `${prefix ? " " : ""}${letter.toUpperCase()}`), file: `${slug(routeName)}.md`, states: [], captures: [] };
      byRoute.set(routeName, route);
      routes.push(route);
    }
    const route = byRoute.get(routeName);
    route.captures.push(capture);
    if (!route.states.includes(capture.state)) route.states.push(capture.state);
  }
  return routes;
}

export function renderMarkdownRouteDocuments(manifest) {
  const widths = manifest.widths || [];
  return markdownRoutes(manifest).map((route) => {
    const sections = route.states.map((state) => {
      const representative = route.captures.find((capture) => capture.state === state && capture.provenance)?.provenance;
      const arrival = representative
        ? `\n${representative.from ? `Arrived from **${escapeMarkdown(representative.from)}**` : "Tour entry point"}${representative.actions?.length ? ` via ${representative.actions.map((item) => `\`${escapeMarkdown(item.action)} ${escapeMarkdown(item.description || item.target || "")}\``).join(" → ")}` : ""}. Journey: \`${escapeMarkdown(representative.journey)}\`; route: \`${escapeMarkdown(representative.route)}\`.\n`
        : "";
      const header = `| ${widths.map((width) => `${width}px`).join(" | ")} |`;
      const divider = `| ${widths.map(() => "---").join(" | ")} |`;
      const row = `| ${widths.map((width) => {
        const captures = route.captures.filter((capture) => capture.state === state && capture.width === width);
        if (!captures.length) return "_Not captured_";
        return captures.map((capture) => `[![${escapeMarkdown(`${state} — ${capture.label}`)}](../${capture.file})](../${capture.file})<br><sub>${escapeMarkdown(capture.label)}</sub>`).join("<br><br>");
      }).join(" | ")} |`;
      return `## ${escapeMarkdown(state)}\n${arrival}\n${header}\n${divider}\n${row}`;
    }).join("\n\n");
    return {
      file: route.file,
      content: `# ${escapeMarkdown(route.label)} screens\n\n[← Visual tour overview](../README.md) · [Interactive contact sheet](../index.html) · [Manifest](../manifest.json)\n\n## Screen flow\n\n\`\`\`mermaid\n${renderProvenanceGraph({ ...manifest, captures: route.captures }, { direction: "TD" })}\n\`\`\`\n\n${sections}\n`
    };
  });
}

function routeFromState(state) {
  if (/^Review\s*·\s*(?:map discovered field|choose canonical identity)/i.test(String(state || ""))) return "field";
  const head = String(state || "").split("·")[0].trim().toLowerCase();
  return ({ popup: "popup", settings: "settings", structure: "structure", semantics: "semantics", discover: "discover", review: "review", finish: "finish", "adapter library": "library", "semantic library": "semantic-library", "automatic run": "review" })[head] || head.replace(/\s+/g, "-");
}

export function createTourProvenance({ journey, surface }) {
  let previousState = null;
  const path = [];
  let pendingActions = [];
  return Object.freeze({
    record(action, target, details = {}) {
      pendingActions.push({ action, target, ...details });
    },
    capture(state, details = {}) {
      path.push(state);
      const provenance = {
        journey,
        surface: details.surface || surface,
        route: details.route || routeFromState(state),
        from: previousState,
        actions: pendingActions,
        path: [...path]
      };
      previousState = state;
      pendingActions = [];
      return provenance;
    }
  });
}

export function renderContactSheet(manifest) {
  const states = [...new Set(manifest.captures.map((capture) => capture.state))];
  const widths = manifest.widths;
  const cells = states.map((state) => {
    const columns = widths.map((width) => {
      const captures = manifest.captures.filter((capture) => capture.state === state && capture.width === width);
      return `<td>${captures.map((capture) => {
        const actions = capture.provenance?.actions?.map((item) => `${item.action} ${item.target}`).join(" → ");
        const provenance = actions ? `<small>From ${escapeHtml(capture.provenance.from || "tour start")}: ${escapeHtml(actions)}</small>` : "";
        return `<figure><a href="${escapeHtml(capture.file)}"><img loading="lazy" src="${escapeHtml(capture.file)}" alt="${escapeHtml(state)} at ${width}px"></a><figcaption>${escapeHtml(capture.label)}${provenance}</figcaption></figure>`;
      }).join("") || "<em>Not captured</em>"}</td>`;
    }).join("");
    return `<tr><th scope="row">${escapeHtml(state)}</th>${columns}</tr>`;
  }).join("\n");
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Site2JSON visual tour</title><style>
:root{color-scheme:dark}body{margin:0;padding:24px;background:#0f1218;color:#edf2f7;font:14px system-ui,sans-serif}h1{margin-top:0}p{color:#aab4c2}table{width:100%;border-collapse:separate;border-spacing:12px;table-layout:fixed}th,td{vertical-align:top;text-align:left}thead th{position:sticky;top:0;background:#0f1218;padding:8px;z-index:2}tbody th{width:180px;padding:8px;color:#8fd1a6}figure{margin:0 0 16px;background:#171d27;border:1px solid #303a49;border-radius:8px;overflow:hidden}img{display:block;width:100%;height:auto;background:white}figcaption{padding:7px 9px;color:#aab4c2;font-size:12px}figcaption small{display:block;margin-top:5px;color:#8290a3;line-height:1.35}a{color:inherit}
</style></head><body><h1>Site2JSON visual tour</h1><p>${escapeHtml(manifest.createdAt)} · ${manifest.captures.length} captures · viewport height ${manifest.height}px</p><table><thead><tr><th>Screen</th>${widths.map((width) => `<th>${width}px</th>`).join("")}</tr></thead><tbody>${cells}</tbody></table></body></html>`;
}

class CdpClient {
  constructor(webSocketUrl) {
    this.webSocketUrl = webSocketUrl;
    this.sequence = 0;
    this.connect();
  }

  connect() {
    const socket = new WebSocket(this.webSocketUrl);
    const pending = new Map();
    this.socket = socket;
    this.pending = pending;
    this.ready = new Promise((resolve, reject) => {
      socket.addEventListener("open", resolve, { once: true });
      socket.addEventListener("error", reject, { once: true });
    });
    socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data);
      const operation = pending.get(message.id);
      if (!operation) return;
      pending.delete(message.id);
      if (message.error) operation.reject(new Error(`${operation.method}: ${message.error.message}`));
      else operation.resolve(message.result || {});
    });
    const disconnect = () => {
      for (const operation of pending.values()) operation.reject(new Error(`${operation.method}: Chrome debugging connection closed`));
      pending.clear();
    };
    socket.addEventListener("close", disconnect);
    socket.addEventListener("error", disconnect);
  }

  async reconnect() {
    this.socket.close();
    this.connect();
    await this.ready;
  }

  async call(method, params = {}, timeout = 20000) {
    await this.ready;
    const id = ++this.sequence;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`${method}: timed out after ${timeout}ms`));
      }, timeout);
      this.pending.set(id, {
        method,
        resolve: (value) => { clearTimeout(timer); resolve(value); },
        reject: (error) => { clearTimeout(timer); reject(error); }
      });
      this.socket.send(JSON.stringify({ id, method, params }));
    });
  }

  async evaluate(expression, timeout = 60000) {
    const result = await this.call("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true, userGesture: true }, timeout);
    if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text || "Browser evaluation failed");
    return result.result?.value;
  }

  close() { this.socket.close(); }
}

async function targets(endpoint) {
  const response = await fetch(`${endpoint.replace(/\/$/, "")}/json/list`);
  if (!response.ok) throw new Error(`Could not list Chrome targets at ${endpoint}: ${response.status}`);
  return response.json();
}

async function browserClient(endpoint) {
  const version = await fetch(`${endpoint.replace(/\/$/, "")}/json/version`).then((response) => response.json());
  return new CdpClient(version.webSocketDebuggerUrl);
}

async function delay(milliseconds) { await new Promise((resolve) => setTimeout(resolve, milliseconds)); }

async function waitFor(client, expression, description, timeout = 12000) {
  const started = Date.now();
  let lastError;
  while (Date.now() - started < timeout) {
    try {
      if (await client.evaluate(expression, Math.max(60000, timeout))) return;
    } catch (error) { lastError = error; }
    await delay(WAIT_INTERVAL);
  }
  throw new Error(`Timed out waiting for ${description}${lastError ? `: ${lastError.message}` : ""}`);
}

async function rawClick(client, selector) {
  const found = await client.evaluate(`(() => { const element = document.querySelector(${JSON.stringify(selector)}); if (!element || !element.offsetParent || element.disabled) return false; element.click(); return true; })()`, 60000);
  if (!found) throw new Error(`Visible enabled control not found: ${selector}`);
}

async function rawFill(client, selector, value) {
  const found = await client.evaluate(`(() => { const element = document.querySelector(${JSON.stringify(selector)}); if (!element) return false; element.value = ${JSON.stringify(value)}; element.dispatchEvent(new Event("input", { bubbles: true })); element.dispatchEvent(new Event("change", { bubbles: true })); return true; })()`, 60000);
  if (!found) throw new Error(`Input not found: ${selector}`);
}

async function rawClickPageElement(client, selector) {
  const clicked = await client.evaluate(`(() => {
    const element = document.querySelector(${JSON.stringify(selector)});
    if (!element) return false;
    element.scrollIntoView({ block: "center", inline: "center" });
    element.click();
    return true;
  })()`);
  if (!clicked) throw new Error(`The inspected page has no element matching ${selector}`);
}

async function applyPopupTourState(client, state) {
  await client.evaluate(`(() => {
    const state = ${JSON.stringify(state)};
    document.querySelector("#status-card").className = "status-card " + state.kind;
    document.querySelector("#status-indicator").className = "status-indicator " + state.kind;
    document.querySelector("#status-title").textContent = state.title;
    document.querySelector("#status-detail").textContent = state.detail;
    document.querySelector("#automatic-threshold").textContent = state.threshold;
    const resultActions = document.querySelector("#result-actions");
    resultActions.hidden = !state.result;
    document.querySelector("#copy-button").disabled = !state.result;
    document.querySelector("#download-button").disabled = !state.result;
    document.querySelector("#run-button").disabled = false;
    document.querySelector("#run-button").textContent = state.result ? "Run again" : "Run";
    document.querySelector("#open-picker-button").disabled = false;
    document.querySelector("#session-count").textContent = state.session ? "40 entities" : "Inactive";
    document.querySelector("#session-detail").textContent = state.session
      ? "2 page snapshots; positions 1, 2."
      : "Run each page through the same adapter-or-infer workflow, then export one deduplicated collection.";
    document.querySelector("#session-button").textContent = state.session ? "Add this page" : "Start session";
    document.querySelector("#session-button").disabled = false;
    document.querySelector("#discard-button").disabled = !state.session;
    document.querySelector("#copy-button").textContent = state.session ? "Copy session" : "Copy results";
    return true;
  })()`);
}

async function prepareCapture(client) {
  await client.evaluate(`(async () => {
    await document.fonts?.ready;
    let style = document.querySelector("#site2json-visual-tour-style");
    if (!style) { style = document.createElement("style"); style.id = "site2json-visual-tour-style"; style.textContent = "*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}"; document.documentElement.append(style); }
    document.querySelectorAll("[data-visual-tour-scroll-id]").forEach((element) => element.removeAttribute("data-visual-tour-scroll-id"));
    document.activeElement?.blur?.();
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    await Promise.race([
      new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))),
      new Promise((resolve) => setTimeout(resolve, 150))
    ]);
    window.scrollTo(0, 0);
    return window.scrollY;
  })()`);
}

async function scrollInventory(client) {
  return client.evaluate(`(() => {
    const visible = (element) => { const box = element.getBoundingClientRect(); const style = getComputedStyle(element); return box.width > 20 && box.height > 20 && style.visibility !== "hidden" && style.display !== "none"; };
    const items = [];
    let index = 0;
    for (const element of document.querySelectorAll("body *")) {
      if (!visible(element) || element.scrollWidth <= element.clientWidth + 4) continue;
      const style = getComputedStyle(element);
      if (!/(auto|scroll)/.test(style.overflowX) && !element.matches("table, pre, [role=grid]")) continue;
      const id = "scroll-" + (++index);
      element.dataset.visualTourScrollId = id;
      items.push({ id, label: element.id ? "#" + element.id : element.classList.length ? "." + [...element.classList].slice(0, 2).join(".") : element.tagName.toLowerCase(), width: element.scrollWidth, viewport: element.clientWidth });
    }
    return { documentHeight: document.scrollingElement.scrollHeight, viewportHeight: innerHeight, horizontal: items.slice(0, 8) };
  })()`);
}

async function saveScreenshot(client, outputDirectory, filename) {
  let screenshot;
  try {
    screenshot = await client.call("Page.captureScreenshot", { format: "png", fromSurface: true, captureBeyondViewport: false }, 30000);
  } catch (error) {
    await delay(300);
    screenshot = await client.call("Page.captureScreenshot", { format: "png", fromSurface: true, captureBeyondViewport: false }, 30000).catch(() => { throw error; });
  }
  await fs.writeFile(path.join(outputDirectory, filename), Buffer.from(screenshot.data, "base64"));
}

async function captureState(client, manifest, outputDirectory, state, widths, height, tileLimit, provenance = null) {
  try {
  for (const width of widths) {
    await client.call("Emulation.setDeviceMetricsOverride", { width, height, deviceScaleFactor: 1, mobile: false });
    await delay(120);
    await prepareCapture(client);
    const inventory = await scrollInventory(client);
    const vertical = tilePositions(inventory.documentHeight, inventory.viewportHeight, 80, tileLimit);
    for (let index = 0; index < vertical.length; index += 1) {
      await client.evaluate(`(() => { window.scrollTo(0, ${vertical[index]}); document.documentElement.scrollTop = ${vertical[index]}; document.body.scrollTop = ${vertical[index]}; return window.scrollY; })()`);
      await delay(50);
      const file = `${String(manifest.captures.length + 1).padStart(3, "0")}-${slug(state)}--${width}--v${String(index + 1).padStart(2, "0")}.png`;
      await saveScreenshot(client, outputDirectory, file);
      manifest.captures.push({ state, width, file, label: vertical.length > 1 ? `Vertical tile ${index + 1}/${vertical.length}` : "Initial view", scroll: { x: 0, y: vertical[index] }, ...(provenance ? { provenance } : {}) });
    }
    for (const item of inventory.horizontal) {
      const horizontal = tilePositions(item.width, item.viewport, 48, tileLimit).slice(1);
      for (let index = 0; index < horizontal.length; index += 1) {
        await client.evaluate(`(() => { const element = document.querySelector('[data-visual-tour-scroll-id="${item.id}"]'); if (!element) return false; element.scrollLeft = ${horizontal[index]}; element.scrollIntoView({ block: "center" }); return true; })()`);
        await delay(50);
        const file = `${String(manifest.captures.length + 1).padStart(3, "0")}-${slug(state)}--${width}--h${String(index + 1).padStart(2, "0")}.png`;
        await saveScreenshot(client, outputDirectory, file);
        manifest.captures.push({ state, width, file, label: `${item.label} · horizontal tile ${index + 2}/${horizontal.length + 1}`, scroll: { container: item.label, x: horizontal[index] }, ...(provenance ? { provenance } : {}) });
      }
    }
  }
  } finally {
    await client.call("Emulation.clearDeviceMetricsOverride").catch(() => {});
    await client.reconnect();
  }
}

function parseArguments(argv) {
  const options = { endpoint: "http://127.0.0.1:9222", widths: DEFAULT_WIDTHS.slice(), height: DEFAULT_HEIGHT, tileLimit: 8, pageMatch: "", itemSelector: ".jobRecord", output: "", keepDraft: false, theme: "", workflowOnly: false };
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    const value = argv[index + 1];
    if (argument === "--endpoint") options.endpoint = value, index += 1;
    else if (argument === "--widths") options.widths = parseWidths(value), index += 1;
    else if (argument === "--height") options.height = Number(value), index += 1;
    else if (argument === "--tile-limit") options.tileLimit = Number(value), index += 1;
    else if (argument === "--page-match") options.pageMatch = value, index += 1;
    else if (argument === "--item-selector") options.itemSelector = value, index += 1;
    else if (argument === "--output") options.output = value, index += 1;
    else if (argument === "--theme") options.theme = String(value || "").toLowerCase(), index += 1;
    else if (argument === "--workflow-only") options.workflowOnly = true;
    else if (argument === "--keep-draft") options.keepDraft = true;
    else if (argument === "--help") options.help = true;
    else throw new Error(`Unknown argument: ${argument}`);
  }
  if (!Number.isInteger(options.height) || options.height < 480) throw new Error("--height must be an integer of at least 480");
  if (!Number.isInteger(options.tileLimit) || options.tileLimit < 2 || options.tileLimit > 30) throw new Error("--tile-limit must be between 2 and 30");
  if (options.theme && !["system", "light", "dark"].includes(options.theme)) throw new Error("--theme must be system, light, or dark");
  return options;
}

function usage() {
  return `Capture the Site2JSON popup and manual adapter workflow at several side-panel widths.

Chrome must already be running with --remote-debugging-port=9222 and the Site2JSON side panel open.

Usage:
  npm run visual-tour -- --page-match guru.com --item-selector '.jobRecord'

Options:
  --endpoint URL         Chrome debugging endpoint (default http://127.0.0.1:9222)
  --widths LIST          Comma-separated widths (default 320,480,800)
  --height PX            Capture viewport height (default 900)
  --page-match TEXT      Substring identifying the inspected page target
  --item-selector CSS    Repeated example item selected during Structure
  --output DIRECTORY     Output directory (default tmp/visual-tour/<timestamp>)
  --theme THEME          Force system, light, or dark for this run, then restore it
  --workflow-only        Capture only the disposable adapter-creation workflow
  --tile-limit NUMBER    Maximum tiles per scroll axis (default 8)
  --keep-draft           Do not discard the tour-created draft
`;
}

async function run() {
  const options = parseArguments(process.argv.slice(2));
  if (options.help) return console.log(usage());
  const available = await targets(options.endpoint);
  const sidePanelTargets = available.filter((target) => target.type === "page" && /chrome-extension:\/\/[^/]+\/editor\/sidebar\.html/.test(target.url));
  const sidePanelTarget = sidePanelTargets.find((target) => /[?&]tabId=\d+/.test(target.url)) || sidePanelTargets[0];
  if (!sidePanelTarget) throw new Error("Open the Site2JSON extension side panel in the Chrome instance connected to this debugging port, then retry.");
  const extensionId = new URL(sidePanelTarget.url).host;
  const inspectedTarget = available.find((target) => target.type === "page" && !target.url.startsWith("chrome") && (!options.pageMatch || target.url.includes(options.pageMatch)));
  if (!inspectedTarget) throw new Error(`No inspected page target matched ${JSON.stringify(options.pageMatch || "a normal web page")}.`);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const outputDirectory = path.resolve(options.output || path.join("tmp", "visual-tour", stamp));
  await fs.mkdir(outputDirectory, { recursive: true });
  const manifest = {
    version: 2,
    createdAt: new Date().toISOString(),
    endpoint: options.endpoint,
    inspectedPage: inspectedTarget.url,
    itemSelector: options.itemSelector,
    widths: options.widths,
    height: options.height,
    theme: options.theme || "saved preference",
    provenance: {
      version: 1,
      description: "Each capture records its surface, logical route, preceding screenshot, complete tour path, and the actions taken since the preceding screenshot.",
      journeys: ["production-popup", "automatic-settings", "manual-adapter-creation"]
    },
    captures: [],
    completed: false,
    draftDiscarded: false
  };
  const browser = await browserClient(options.endpoint);
  const sidePanel = new CdpClient(sidePanelTarget.webSocketDebuggerUrl);
  const page = new CdpClient(inspectedTarget.webSocketDebuggerUrl);
  let popup;
  let popupTargetId;
  let optionsPage;
  let optionsTargetId;
  let createdDraft = false;
  let previousTheme = null;
  const popupProvenance = createTourProvenance({ journey: "production-popup", surface: "popup" });
  const optionsProvenance = createTourProvenance({ journey: "automatic-settings", surface: "options" });
  const sidePanelProvenance = createTourProvenance({ journey: "manual-adapter-creation", surface: "side-panel" });
  const trackerFor = (client) => client === popup ? popupProvenance : client === optionsPage ? optionsProvenance : sidePanelProvenance;
  const click = async (client, selector, description = "") => {
    await rawClick(client, selector);
    trackerFor(client).record("click", selector, ...(description ? [{ description }] : []));
  };
  const fill = async (client, selector, value, description = "") => {
    await rawFill(client, selector, value);
    trackerFor(client).record("fill", selector, { value, ...(description ? { description } : {}) });
  };
  const clickPageElement = async (client, selector) => {
    const selected = await sidePanel.evaluate(`Site2JsonBridge.run(function visualTourSelect(args) {
      return globalThis.Site2JsonPagePicker?.select(args.selector) || false;
    }, { selector: ${JSON.stringify(selector)} })`);
    if (!selected) await rawClickPageElement(client, selector);
    sidePanelProvenance.record("select-page-element", selector, { transport: selected ? "picker-api" : "page-click" });
  };
  const capture = (name, details = {}) => captureState(sidePanel, manifest, outputDirectory, name, options.widths, options.height, options.tileLimit, sidePanelProvenance.capture(name, details));
  try {
    await sidePanel.call("Page.enable");
    await page.call("Page.enable");
    if (options.theme) {
      previousTheme = await sidePanel.evaluate(`globalThis.Site2JsonTheme?.load?.() || document.documentElement.dataset.themePreference || "system"`);
      await sidePanel.evaluate(`globalThis.Site2JsonTheme.save(${JSON.stringify(options.theme)})`);
      await waitFor(sidePanel, `document.documentElement.dataset.theme === ${JSON.stringify(options.theme === "system" ? await sidePanel.evaluate(`globalThis.Site2JsonTheme.resolved("system")`) : options.theme)}`, `${options.theme} theme`);
    }
    if (!options.workflowOnly) {
    const popupTarget = await browser.call("Target.createTarget", { url: `chrome-extension://${extensionId}/popup.html`, background: false });
    popupTargetId = popupTarget.targetId;
    await delay(500);
    const popupInfo = (await targets(options.endpoint)).find((target) => target.id === popupTargetId);
    if (popupInfo) {
      popup = new CdpClient(popupInfo.webSocketDebuggerUrl);
      await popup.call("Page.enable");
      await waitFor(popup, `document.readyState === "complete" && Boolean(document.querySelector("#run-button"))`, "the popup to load");
      for (const state of POPUP_TOUR_STATES) {
        await applyPopupTourState(popup, state);
        popupProvenance.record("apply-tour-state", state.name, { synthetic: true });
        await captureState(popup, manifest, outputDirectory, state.name, options.widths, options.height, options.tileLimit, popupProvenance.capture(state.name));
      }
      popup.close();
      popup = null;
      await browser.call("Target.closeTarget", { targetId: popupTargetId });
      popupTargetId = null;
    }

    const optionsTarget = await browser.call("Target.createTarget", { url: `chrome-extension://${extensionId}/options.html`, background: false });
    optionsTargetId = optionsTarget.targetId;
    await delay(300);
    const optionsInfo = (await targets(options.endpoint)).find((target) => target.id === optionsTargetId);
    if (optionsInfo) {
      optionsPage = new CdpClient(optionsInfo.webSocketDebuggerUrl);
      await optionsPage.call("Page.enable");
      await waitFor(optionsPage, `document.readyState === "complete" && Boolean(document.querySelector("#automatic-confidence"))`, "automatic confidence settings");
      await optionsPage.evaluate(`(() => { document.querySelector("#automatic-confidence").value = "strong"; return true; })()`);
      optionsProvenance.record("set-value", "#automatic-confidence", { value: "strong", synthetic: true });
      await captureState(optionsPage, manifest, outputDirectory, "Settings · automatic confidence", options.widths, options.height, options.tileLimit, optionsProvenance.capture("Settings · automatic confidence"));
      optionsPage.close();
      optionsPage = null;
      await browser.call("Target.closeTarget", { targetId: optionsTargetId });
      optionsTargetId = null;
    }

    await sidePanel.call("Page.reload", { ignoreCache: true });
    sidePanelProvenance.record("reload", "side-panel", { ignoreCache: true });
    await delay(700);
    }
    await waitFor(sidePanel, `document.readyState === "complete" && Boolean(document.querySelector("#library-home"))`, "the side panel to reload");
    if (await sidePanel.evaluate(`document.querySelector("#library-home").hidden && !document.querySelector("#back-to-library-button").hidden`)) {
      await click(sidePanel, "#back-to-library-button");
    }
    await waitFor(sidePanel, `!document.querySelector("#library-home").hidden`, "the adapter library");
    await capture("Adapter library");
    if (!options.workflowOnly) {
    await click(sidePanel, '[data-app-view="semantics"]');
    await waitFor(sidePanel, `!document.querySelector("#semantic-library-home").hidden && (document.querySelector("#semantic-library-status").classList.contains("ready") || document.querySelector("#semantic-library-status").classList.contains("error"))`, "the Semantic Library");
    await capture("Semantic Library");
    if (await sidePanel.evaluate(`Boolean(document.querySelector("#semantic-library-open-history"))`)) {
      await click(sidePanel, "#semantic-library-open-history");
      await waitFor(sidePanel, `!document.querySelector("#semantic-library-history").hidden && (document.querySelector("#semantic-library-history-status").classList.contains("ready") || document.querySelector("#semantic-library-history-status").classList.contains("error"))`, "Semantic Library import history");
      await capture("Semantic Library · import history");
      await click(sidePanel, "#semantic-library-close-history");
      await waitFor(sidePanel, `document.querySelector("#semantic-library-history").hidden`, "the local Semantic Library");
    }
    if (await sidePanel.evaluate(`Boolean(document.querySelector("#semantic-library-open-import"))`)) {
      await click(sidePanel, "#semantic-library-open-import");
      await waitFor(sidePanel, `!document.querySelector("#semantic-library-import").hidden`, "the external catalog browser");
      await capture("Semantic Library · external catalog");
      try {
        await fill(sidePanel, "#semantic-library-catalog-search", "Person");
        await click(sidePanel, "#semantic-library-catalog-submit");
        await waitFor(sidePanel, `document.querySelector("#semantic-library-catalog-status").classList.contains("ready") || document.querySelector("#semantic-library-catalog-status").classList.contains("error")`, "external catalog search", 30000);
        await capture("Semantic Library · catalog results");
        const previewed = await sidePanel.evaluate(`(() => { const result = [...document.querySelectorAll("#semantic-library-catalog-results button")].find((button) => button.textContent.includes("foaf:Person")) || document.querySelector("#semantic-library-catalog-results button"); if (!result) return false; result.click(); return true; })()`);
        if (previewed) {
          sidePanelProvenance.record("click-result", "foaf:Person or first catalog result");
          await waitFor(sidePanel, `document.querySelector("#semantic-library-catalog-status").classList.contains("ready") || document.querySelector("#semantic-library-catalog-status").classList.contains("error")`, "external catalog import preview", 30000);
          await capture("Semantic Library · import preview");
        }

        if (await sidePanel.evaluate(`Boolean(document.querySelector("#semantic-library-mode-vocabularies"))`)) {
          await click(sidePanel, "#semantic-library-mode-vocabularies");
          await fill(sidePanel, "#semantic-library-catalog-search", "people");
          await click(sidePanel, "#semantic-library-catalog-submit");
          await waitFor(sidePanel, `document.querySelector("#semantic-library-catalog-status").classList.contains("ready") || document.querySelector("#semantic-library-catalog-status").classList.contains("error")`, "vocabulary catalog search", 30000);
          await capture("Semantic Library · vocabulary results");
          const vocabularyOpened = await sidePanel.evaluate(`(() => { const result = [...document.querySelectorAll("#semantic-library-catalog-results button")].find((button) => button.textContent.startsWith("bio ·")); if (!result) return false; result.click(); return true; })()`);
          if (vocabularyOpened) {
            sidePanelProvenance.record("click-result", "bio vocabulary");
            await waitFor(sidePanel, `document.querySelector("#semantic-library-vocabulary-status").classList.contains("ready") || document.querySelector("#semantic-library-vocabulary-status").classList.contains("error")`, "the pinned vocabulary", 30000);
            await capture("Semantic Library · vocabulary browser");
            const selectionStarted = await sidePanel.evaluate(`(() => { const input = document.querySelector("#semantic-library-vocabulary-terms input"); if (!input) return false; input.click(); document.querySelector("#semantic-library-preview-vocabulary").click(); return true; })()`);
            if (selectionStarted) {
              sidePanelProvenance.record("select-and-click", "first vocabulary term → #semantic-library-preview-vocabulary");
              await waitFor(sidePanel, `document.querySelector("#semantic-library-catalog-status").classList.contains("ready") || document.querySelector("#semantic-library-catalog-status").classList.contains("error")`, "the vocabulary package preview", 30000);
              await capture("Semantic Library · vocabulary package preview");
            }
          }
        }
      } catch (error) {
        console.warn(`Catalog tour states were incomplete: ${error.message}`);
      }
      await click(sidePanel, "#semantic-library-close-import");
      await waitFor(sidePanel, `document.querySelector("#semantic-library-import").hidden`, "the local Semantic Library");
    }
    if (await sidePanel.evaluate(`Boolean(document.querySelector("#semantic-library-results .semantic-library-result"))`)) {
      await click(sidePanel, "#semantic-library-results .semantic-library-result");
      await waitFor(sidePanel, `!document.querySelector("#semantic-library-detail").hidden && !document.querySelector("#semantic-library-detail-name").disabled`, "Semantic Library item details");
      await capture("Semantic Library · selected pattern");
    }
    await click(sidePanel, '[data-app-view="adapters"]');
    await waitFor(sidePanel, `!document.querySelector("#library-home").hidden`, "the adapter library");
    }
    await click(sidePanel, "#new-adapter-button");
    createdDraft = true;
    await waitFor(sidePanel, `!document.querySelector("#editor-workspace").hidden`, "a fresh draft");
    await capture("Structure · empty draft");

    await click(sidePanel, "#visual-select-button");
    await delay(250);
    await clickPageElement(page, options.itemSelector);
    await waitFor(sidePanel, `!document.querySelector("#selection-summary").hidden && !document.querySelector("#pick-scope-button").disabled`, "the visual selection");
    await capture("Structure · selected item");

    await click(sidePanel, "#pick-scope-button");
    await waitFor(sidePanel, `document.querySelector("#scope-levels .option-item")`, "scope proposals", 20000);
    await capture("Structure · scope proposals");
    await click(sidePanel, "#scope-use-preview-button");
    await waitFor(sidePanel, `!document.querySelector("#block-setup").hidden`, "block setup");
    await fill(sidePanel, "#block-name", "Results");
    await fill(sidePanel, "#block-schema-type", "JobPosting");
    await capture("Structure · block setup");
    await click(sidePanel, "#create-block-button");
    await waitFor(sidePanel, `!document.querySelector("#structure-complete").hidden`, "Structure completion", 20000);
    await capture("Structure · complete");

    await click(sidePanel, "#continue-semantics-button");
    await waitFor(sidePanel, `!document.querySelector("#step-semantics").classList.contains("route-inactive")`, "Semantics");
    await capture("Semantics · model selection");
    await sidePanel.evaluate(`(() => {
      const attention = globalThis.Site2JsonAttention?.create?.({ document });
      attention?.sync("visual-tour-variant", [{
        id: "visual-tour-variant-ambiguity", severity: "warning",
        message: "1 sampled nested value needs distinguishing evidence or an accepted fallback.",
        destination: { kind: "variant-evidence", screen: "semantics", slotPath: "item", rootIndex: 0, action: "resolve-evidence" }
      }]);
      document.querySelector("#site2json-attention-button")?.click();
      return true;
    })()`);
    sidePanelProvenance.record("classify-sample", "nested variant slot item", { synthetic: true, outcome: "ambiguous" });
    sidePanelProvenance.record("click", "#site2json-attention-button", { synthetic: true });
    await capture(VARIANT_RECOVERY_TOUR_STATES[0]);
    await sidePanel.evaluate(`(() => {
      document.querySelector("#site2json-attention-panel").hidden = true;
      document.querySelector("#variant-classification-review").hidden = false;
      document.querySelector("#variant-resolution-form").hidden = false;
      document.querySelector("#variant-resolution-title").textContent = "Resolve item 1 · item";
      document.querySelector("#variant-resolution-breakdown").innerHTML = [
        '<div class="variant-resolution-score decision"><strong>No safe winner</strong><span>Article and Product tie at 4 · required margin 2</span></div>',
        '<div class="variant-resolution-score"><strong>Article</strong><span>shape 4 · evidence 0 · total 4</span></div>',
        '<div class="variant-resolution-score"><strong>Product</strong><span>shape 4 · evidence 0 · total 4</span></div>'
      ].join("");
      const type = document.querySelector("#variant-resolution-type");
      type.replaceChildren(new Option("Thing · fallback", "Thing"), new Option("Article", "Article"), new Option("Product", "Product"));
      document.querySelector("#variant-resolution-status").textContent = "Choose stable rendered evidence, or accept this exact unresolved shape as the fallback.";
      return true;
    })()`);
    sidePanelProvenance.record("visit-attention", "visual-tour-variant-ambiguity", { synthetic: true, destination: "nested variant resolver" });
    await capture(VARIANT_RECOVERY_TOUR_STATES[1]);
    await sidePanel.evaluate(`(() => {
      document.querySelector("#variant-resolution-form").hidden = true;
      document.querySelector("#variant-classification-review").hidden = true;
      const status = document.querySelector("#semantic-variants-status");
      status.className = "hint ready";
      status.textContent = "This exact unresolved shape will use Thing as its fallback. A changed shape or configuration will request Attention again.";
      globalThis.Site2JsonAttention?.create?.({ document })?.sync("visual-tour-variant", []);
      return true;
    })()`);
    sidePanelProvenance.record("click", "#accept-variant-fallback-button", { synthetic: true, receipt: "privacy-safe exact-shape fingerprint" });
    await capture(VARIANT_RECOVERY_TOUR_STATES[2]);
    await sidePanel.evaluate(`(() => {
      const attention = globalThis.Site2JsonAttention?.create?.({ document });
      attention?.sync("visual-tour-variant", [{
        id: "visual-tour-variant-recurrence", severity: "warning",
        message: "The sampled item shape changed. Review distinguishing evidence or accept the new fallback shape.",
        destination: { kind: "variant-evidence", screen: "semantics", slotPath: "item", rootIndex: 0, action: "resolve-evidence" }
      }]);
      document.querySelector("#site2json-attention-button")?.click();
      return true;
    })()`);
    sidePanelProvenance.record("reclassify-after-shape-change", "nested variant slot item", { synthetic: true, outcome: "fallback receipt invalidated" });
    sidePanelProvenance.record("click", "#site2json-attention-button", { synthetic: true });
    await capture(VARIANT_RECOVERY_TOUR_STATES[3]);
    await sidePanel.evaluate(`(() => {
      globalThis.Site2JsonAttention?.create?.({ document })?.sync("visual-tour-variant", []);
      const status = document.querySelector("#semantic-variants-status");
      status.className = "hint";
      status.textContent = "";
      return true;
    })()`);
    sidePanelProvenance.record("clear-tour-state", "visual-tour variant recovery", { synthetic: true });
    await click(sidePanel, "#open-semantic-graph");
    await waitFor(sidePanel, `!document.querySelector("#semantic-composition-graph-view").hidden`, "semantic graph");
    await capture("Semantics · graph editor");
    await sidePanel.evaluate(`(() => {
      document.querySelector("#semantic-graph-type-details").open = true;
      document.querySelector("#semantic-graph-properties").open = true;
      const search = document.querySelector("#semantic-graph-property-search");
      search.value = "hiring";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    })()`);
    sidePanelProvenance.record("open-and-filter", "type details and available properties", { value: "hiring" });
    await capture("Semantics · graph type reference");
    await sidePanel.evaluate(`(() => {
      document.querySelector("#semantic-graph-properties").open = false;
      const search = document.querySelector("#semantic-graph-property-search");
      search.value = "";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    })()`);
    sidePanelProvenance.record("close-and-clear", "available properties");
    if (await sidePanel.evaluate(`!document.querySelector("#semantic-graph-create-custom-relationship").disabled`)) {
      await click(sidePanel, "#semantic-graph-create-custom-relationship");
      await waitFor(sidePanel, `!document.querySelector("#semantic-graph-custom-relationship-editor").hidden`, "custom relationship editor");
      await capture("Semantics · custom relationship editor");
      await click(sidePanel, "#semantic-graph-cancel-custom-relationship");
    }
    await click(sidePanel, "#close-semantic-graph");
    await click(sidePanel, "#open-semantic-advanced");
    await waitFor(sidePanel, `!document.querySelector("#semantic-advanced-view").hidden`, "semantic form editor");
    await capture("Semantics · form editor");
    await click(sidePanel, "#close-semantic-advanced");
    await click(sidePanel, "#confirm-semantics-button");
    await waitFor(sidePanel, `!document.querySelector("#step-fields").classList.contains("route-inactive")`, "Discover");
    await capture("Discover · before scan");
    await click(sidePanel, "#discover-fields-button");
    await waitFor(sidePanel, `!document.querySelector("#discovery-complete").hidden || /Scanned/.test(document.querySelector("#discovery-status")?.textContent || "")`, "field discovery", 30000);
    await capture("Discover · results");
    if (await sidePanel.evaluate(`!document.querySelector("#continue-review-button").hidden && !document.querySelector("#continue-review-button").disabled`)) {
      await click(sidePanel, "#continue-review-button");
      await waitFor(sidePanel, `!document.querySelector("#step-blocks").classList.contains("route-inactive")`, "Review");
      await capture("Review · discovered fields");
      await sidePanel.evaluate(`(() => {
        const banner = document.querySelector("#inference-review-banner");
        banner.hidden = false;
        document.querySelector("#inference-review-summary").textContent = "Automatic Run stopped here because field mapping confidence is below the configured High threshold. Review the inferred fields and canonical identity; nothing was published.";
        return true;
      })()`);
      sidePanelProvenance.record("apply-tour-state", "automatic inference review banner", { synthetic: true });
      await capture("Automatic Run · stopped for review");
      await sidePanel.evaluate(`(() => { document.querySelector("#inference-review-banner").hidden = true; return true; })()`);
      sidePanelProvenance.record("hide-tour-state", "#inference-review-banner", { synthetic: true });
      await sidePanel.evaluate(`(() => {
        const card = document.querySelector("#correction-promotion");
        card.hidden = false;
        document.querySelector("#correction-promotion-summary").textContent = "You changed “headline” to “title”. Only reusable labels will be saved; selectors and rendered page content are excluded.";
        document.querySelector("#correction-promotion-changes").innerHTML = "<li>Add “job heading” as an alias for schema:title.</li><li>Mark “job heading” as an exclusion for market:headline.</li>";
        document.querySelector("#correction-promotion-warning").hidden = false;
        document.querySelector("#correction-promotion-status").textContent = "Nothing changes until you confirm.";
        return true;
      })()`);
      sidePanelProvenance.record("apply-tour-state", "reusable correction preview", { synthetic: true });
      await capture("Review · reuse correction preview");
      await sidePanel.evaluate(`(() => { document.querySelector("#correction-promotion").hidden = true; return true; })()`);
      sidePanelProvenance.record("hide-tour-state", "#correction-promotion", { synthetic: true });
      if (await sidePanel.evaluate(`Boolean(document.querySelector("#unresolved-fields-body .unresolved-field-actions button"))`)) {
        await click(sidePanel, "#unresolved-fields-body .unresolved-field-actions button");
        await waitFor(sidePanel, `!document.querySelector("#step-field-editor").hidden`, "the unresolved field mapping editor");
        await capture("Review · map discovered field");
        await click(sidePanel, "#back-from-field-button");
        await waitFor(sidePanel, `document.querySelector("#step-field-editor").hidden`, "Review after closing the field editor");
      }
      let unresolved = await sidePanel.evaluate(`document.querySelectorAll("#unresolved-fields-body .unresolved-field-actions .danger").length`);
      while (unresolved > 0) {
        await click(sidePanel, "#unresolved-fields-body .unresolved-field-actions .danger");
        await waitFor(sidePanel, `document.querySelectorAll("#unresolved-fields-body .unresolved-field-actions .danger").length < ${unresolved}`, "an unresolved field to be removed");
        unresolved = await sidePanel.evaluate(`document.querySelectorAll("#unresolved-fields-body .unresolved-field-actions .danger").length`);
      }
      if (await sidePanel.evaluate(`document.querySelector('[data-workflow-step="finish"]').disabled`)) {
        const openedUrl = await sidePanel.evaluate(`(() => {
          const row = [...document.querySelectorAll("#block-table-body .field-row-header")].find((candidate) => candidate.querySelector(".field-column-label")?.textContent.trim() === "url");
          const edit = row?.querySelector(".edit");
          if (!edit) return false;
          edit.click();
          return true;
        })()`);
        if (!openedUrl) throw new Error("Discovery did not produce a URL field that can become canonical identity.");
        sidePanelProvenance.record("click-field-action", "url → edit");
        await waitFor(sidePanel, `!document.querySelector("#step-field-editor").hidden`, "the URL field editor");
        await sidePanel.evaluate(`(() => { const identity = document.querySelector("#field-identity"); identity.checked = true; identity.dispatchEvent(new Event("change", { bubbles: true })); return true; })()`);
        sidePanelProvenance.record("check", "#field-identity");
        await capture("Review · choose canonical identity");
        await click(sidePanel, "#add-field-button");
        await waitFor(sidePanel, `document.querySelector("#step-field-editor").hidden`, "the canonical identity to be saved");
      }
      await waitFor(sidePanel, `!document.querySelector('[data-workflow-step="finish"]').disabled`, "Finish to become available");
      await capture("Review · ready to finish");
    }
    if (await sidePanel.evaluate(`!document.querySelector('[data-workflow-step="finish"]').disabled`)) {
      await click(sidePanel, '[data-workflow-step="finish"]');
      await waitFor(sidePanel, `!document.querySelector("#step-build").classList.contains("route-inactive")`, "Finish");
      await capture("Finish · adapter draft");
      if (await sidePanel.evaluate(`!document.querySelector("#build-button").disabled`)) {
        await click(sidePanel, "#build-button");
        await waitFor(sidePanel, `document.querySelector("#build-output").textContent.trim() || document.querySelector("#build-status").classList.contains("error")`, "the adapter build", 30000);
        await capture("Finish · built adapter");
      }
      manifest.completed = true;
    }
  } finally {
    if (popup) popup.close();
    if (popupTargetId) await browser.call("Target.closeTarget", { targetId: popupTargetId }).catch(() => {});
    if (optionsPage) optionsPage.close();
    if (optionsTargetId) await browser.call("Target.closeTarget", { targetId: optionsTargetId }).catch(() => {});
    await sidePanel.call("Emulation.clearDeviceMetricsOverride").catch(() => {});
    if (createdDraft && !options.keepDraft) {
      try {
        await sidePanel.evaluate(`document.querySelector("#discard-draft-button")?.click(); true`);
        await delay(300);
        manifest.draftDiscarded = true;
        manifest.cleanup = { action: "click", target: "#discard-draft-button", outcome: "draft-discarded" };
      } catch { /* Preserve the primary tour failure. */ }
    }
    if (previousTheme) {
      try { await sidePanel.evaluate(`globalThis.Site2JsonTheme.save(${JSON.stringify(previousTheme)})`); }
      catch { /* Preserve the primary tour failure. */ }
    }
    await fs.writeFile(path.join(outputDirectory, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
    await fs.writeFile(path.join(outputDirectory, "index.html"), renderContactSheet(manifest));
    await fs.writeFile(path.join(outputDirectory, "README.md"), renderMarkdownTour(manifest));
    const screenDirectory = path.join(outputDirectory, "screens");
    await fs.rm(screenDirectory, { recursive: true, force: true });
    await fs.mkdir(screenDirectory, { recursive: true });
    await Promise.all(renderMarkdownRouteDocuments(manifest).map((document) =>
      fs.writeFile(path.join(screenDirectory, document.file), document.content)
    ));
    sidePanel.close(); page.close(); browser.close();
  }
  console.log(`Visual tour captured: ${outputDirectory}`);
  console.log(`Open ${path.join(outputDirectory, "index.html")}`);
  console.log(`Read ${path.join(outputDirectory, "README.md")}`);
}

if (import.meta.url === `file://${process.argv[1]}`) run().catch((error) => { console.error(error.stack || error.message); process.exitCode = 1; });
