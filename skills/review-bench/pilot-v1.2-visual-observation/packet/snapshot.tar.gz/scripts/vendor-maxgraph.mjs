import { build } from "esbuild";
import { copyFile, mkdir } from "node:fs/promises";

await mkdir("extension/vendor", { recursive: true });
await build({
  entryPoints: ["scripts/maxgraph-entry.js"],
  outfile: "extension/vendor/maxgraph.js",
  bundle: true,
  format: "iife",
  globalName: "Site2JsonMaxGraph",
  platform: "browser",
  target: ["chrome120"],
  legalComments: "eof",
  minify: true
});
await copyFile("node_modules/@maxgraph/core/LICENSE", "extension/vendor/MAXGRAPH-LICENSE.txt");
