# Schema.org vocabulary snapshot

This directory contains the pinned official Schema.org v30.0 JSON-LD vocabulary and its Apache-2.0 license. Exact source URLs and SHA-256 digests are recorded in `source.json`.

The extension does not load this 1.5 MB source file at runtime. `scripts/build-schemaorg-catalog.js` deterministically reduces it to `extension/editor/schema-catalog.generated.js`, which contains the class and property data needed by the browser editor.

To verify that the generated catalog matches the committed snapshot:

```sh
npm run build:schemaorg
git diff --exit-code -- extension/editor/schema-catalog.generated.js
```

To deliberately update the pinned release, first review and update the version, URLs, and expected digests in `scripts/update-schemaorg.js`, then run:

```sh
npm run update:schemaorg
npm run check
```

Digest changes are never accepted automatically. Review the upstream release, generated diff, vocabulary counts, and license before committing an update.
