# site2json

**Design Document — v0.6**

> Declarative web extraction into structured JSON-LD using schema.org and extensible vocabularies.

---

## 1. Executive Summary

site2json is a browser extension that converts the page a user is currently viewing into structured, machine-readable data. It operates only on the document already rendered in the active tab. It does not crawl, spider, auto-paginate, click links, issue background requests, or run without a user action.

The immediate driver is a daily personal workflow: moving data from web pages into AI tools without hand-copying or lossy HTML-to-Markdown conversion. The existing Upwork extension proves the pattern — visit search-result pages manually, convert each into structured job objects, merge them into a session, deduplicate, and export for downstream analysis.

Four structural decisions define the current design:

**An adapter is a single declarative file.** All site knowledge for one site lives in one YAML document, validated against a published JSON Schema. No executable code. Manifest V3 prohibits remotely hosted code, and accepting JavaScript from strangers to run against authenticated pages is a supply-chain risk that cannot be reviewed at volume.

**The transform library is the one central component.** Adapters name value normalizers — `parseCurrencyRange`, `parseRelativeDate` — that are implemented in the extension. Adapters cannot define them. This is what keeps adapters inert and store-compliant, and it is the project's only real chokepoint.

**Entities are the reusable unit within an adapter.** An adapter defines how to read a `JobPosting` once, then declares that the search page contains many and the detail page contains one. Arity, role, and fidelity are properties of blocks within a page, not of the page.

**Adapters are distributed through user-configured sources.** A source is a URL pointing at a list of adapters. Anyone — a community, a company, an individual — can publish or privately keep an adapter set without the project's involvement. Users choose which sources to trust and in what order.

## 2. Revision History

**v0.6 — Naming**

- Project named `site2json`. Namespace root is `https://site2json.dev/ns/`.
- `render` retired as the name of the operation; the operation is **extraction**. This frees "render" for its ordinary meaning (browser paints a document), which the document now uses exclusively that way.
- Internal naming uses plain, accurate terms — `extract`, `parse`, `fetch` — rather than euphemisms. Defensibility comes from the constraints in §7 and §12, not from vocabulary.

**v0.5 — Authoring pipeline**

- Adapter generation and repair documented as a first-class workflow (§22).
- Ground-truth rule: generated adapters and expected output must not share an author.
- Fixture preprocessor identified as required tooling.
- Selector quality linting to catch brittleness that fixture tests cannot see.
- Vocabulary registry to prevent extension-term drift across generated adapters.

**v0.4 — Clarity and stewardship**

- Adapter defined plainly as one DSL file; source defined plainly as a URL to a listing.
- Transform requirements resolved by capability check rather than version match; transform library declared append-only.
- `dslVersion` narrowed to grammar changes only.
- Default source policy, published under a separate identity from core.
- Documentation treated as a deliverable with a machine-consumption requirement.

**v0.3 — Distribution and trust**

- Adapter sources as a configurable list with signing, trust-on-first-use, and explicit ordering.
- Host permissions identified as the security boundary; adapters cannot initiate extractions.
- Update policy gated on capability change rather than on change.
- Adapter health monitoring from existing coverage metrics.
- Private and internal adapter sets promoted to a first-class use case.
- MV3 interpreter constraint recorded as a hard requirement on DSL evolution.

**v0.2 — Structure**

| Area | v0.1 | v0.2 |
|---|---|---|
| Discovery order | Declared semantics first | DOM is truth; declarations anchor and cross-check |
| Adapter form | Imperative JavaScript | Declarative definitions + core transforms |
| Unit of definition | Page type | Entity type, bound to page contexts |
| Page structure | Implicitly singular | Blocks with arity, role, fidelity |
| Provenance | Field-level | Per-field `inferred` flag |
| Generic fallback | Phase 5 | Deferred; borrow existing extraction |
| Authoring mode | In scope | Spun out |
| Testing | Not addressed | Fixture harness as core deliverable |
| ToS positioning | Partly definitional | Entirely behavioral |

## 3. Goals

- Convert the currently rendered page into structured data with a single deliberate user action.
- Make site knowledge cheap to write, cheap to review, and cheap to repair.
- Let users, companies, and communities distribute adapter sets independently of this project.
- Produce output that is durable and tool-agnostic, plus a compact projection tuned for LLM consumption.
- Support multi-page sessions with reliable deduplication and progressive enrichment.
- Keep browsing human-directed and all processing local.
- Fail visibly and specifically when a site changes.

## 4. Non-Goals

- Autonomous crawling, spidering, or link discovery.
- Automated navigation, clicking, pagination, scrolling, refreshing, or scheduling.
- Headless-browser operation.
- Bypassing authentication, access controls, CAPTCHAs, rate limits, or anti-bot measures.
- Replaying private API calls or exporting session credentials.
- Any centralized service that receives users' rendered page data.
- Core acting as a registry, reviewer, or guarantor of third-party sources. (A default source is published separately under its own identity — see §14.)
- Inventing vocabulary where Schema.org already describes the concept.
- Ranked or probabilistic interpretations. One interpretation, plus warnings.

## 5. Terminology

| Term | Meaning |
|---|---|
| **Adapter** | One declarative file containing everything site2json knows about one site. |
| **Source** | A URL (or local path) pointing at a list of adapters, plus integrity metadata. |
| **Extraction** | One conversion of the currently loaded document into structured data. Also the verb: `extract`. |
| **S2J Markup** | The portable, versioned intermediate format of collections, entities, values, relationships, and provenance produced by every V2 evidence source. It is data, not page HTML and not an adapter. |
| **Semantic DOM** | The live in-memory tree/API used to inspect and manipulate S2J Markup. It may retain ephemeral browser references that are never serialized into S2J Markup. |
| **Block** | A typed region of a page contributing entities, carrying arity, role, and fidelity. |
| **Entity definition** | A field map for one entity type — a section within an adapter file. |
| **Page binding** | Which entity definitions appear on a page type, where, and in what role — a section within an adapter file. |
| **Transform** | A named value normalizer implemented in the extension and referenced by name from adapters. |
| **Component matcher** | A host-independent matcher for an embedded third-party component. |
| **Fidelity** | How complete an observation of an entity is; used to resolve merges. |
| **Session** | A user-directed collection of extractions merged and exported together. |

Use **S2J Markup** in prose and UI copy; do not shorten it to **ASM**. Use **Semantic DOM** only for the live object model, in the same way that the DOM is distinct from serialized HTML.

Entity definitions and page bindings are not separate artifacts. They are two top-level keys in one adapter file.

## 6. Use Cases

**Personal AI workflow (primary).** Gather structured data from sites the user visits daily and hand it to a model without manual conversion. This alone justifies the project.

**Private and internal adapters (first-class).** Intranets, internal dashboards, vendor portals, SSO-gated tools — pages that will never have a public adapter and that browser-native AI agents handle poorly. A company or individual maintains its own source, public or private, with no involvement from this project and no signing infrastructure required for local use. This is likely the strongest adoption path and must not be a second-class citizen.

**Community adapters.** Shared sets for widely used public sites, maintained by whoever cares enough to maintain them.

## 7. Positioning and Site Respect

The project's constraints are technical, not rhetorical. The defensible claims are behavioral:

- No automation. Every extraction follows a user action on a page the user navigated to.
- No incremental load. The page was already fetched and rendered; rendering adds no requests.
- Human pacing. Pagination, scrolling, and navigation stay manual, so ads render and analytics fire normally.
- Local only. Nothing leaves the browser except through an explicit export.
- No redistribution. Output is for the user's own downstream use.

Two claims are deliberately **not** made. First, that reformatting rendered content into JSON is not "copying" — most terms of service cover collection of content by any means, and the definitional argument is weaker than the behavioral one. Second, that site owners will universally welcome it. For content sites the interests genuinely align. For marketplaces and aggregators the listing data *is* the product, and aggregate data is protected regardless of how it left the page. The realistic exposure there is account risk rather than legal risk; it is low for local personal use, and it is not reduced by how the project describes itself.

This is not legal advice, and site terms change.

The source model expresses this structurally rather than as a disclaimer: adapters for policy-sensitive sites are not published by core. Whoever maintains such a set does so under their own name, and users opt in deliberately. The relationship is the one between an ad blocker and its filter list maintainers.

## 8. Design Principles

**Rendered content only.** The constraint is the product. It bounds cost, prevents the project becoming a crawler, and keeps the trust story simple.

**DOM is truth; declarations are anchors.** Use declared structured data to locate and cross-check, not to override what the user can see.

**Declare when trusted; label inference when automatic.** Reviewed adapters declare whether a page is a list or detail view. The optional automatic-conversion tier may infer one block, but keeps that adapter explicitly unreviewed and applies separate gates to one-time export and local publication.

**One file per site.** Everything site2json knows about a site is in one place, reviewable in one diff.

**Adapters are inert data.** Validatable against a schema, updatable without a store release, generatable by a model.

**Constrain the transform vocabulary.** A fixed named library forces hard parsing into shared, tested core code and keeps the DSL from becoming a language.

**Permissions are the security boundary.** Trust decisions are enforced by what the user has granted, not by vetting adapter authors.

**One interpretation.** A single best result with explicit warnings for missing or ambiguous fields.

**Fail loudly.** Silent degradation is the failure mode that kills adapter projects.

**Local-first.** Extraction and session assembly are local. Export is explicit.

**Say what things are.** Code and documentation use plain accurate terms — `extract`, `parse`, `fetch`. Defensibility comes from §7 and §12, not from word choice.

## 9. Architecture

The pipeline is layered and additive. Layers contribute blocks; they do not compete for the same fields.

```text
Active document
      │
      ▼
[1] Page metadata (always)
      title, canonical URL, language, timestamps,
      OpenGraph, breadcrumbs, declared JSON-LD (as anchors)
      │
      ▼
[2] Component matchers (always)
      host-independent embedded components → blocks
      │
      ▼
[3] Site adapter (exactly one, if matched and permitted)
      page binding → entity definitions → blocks
      │
      ▼
[4] Automatic conversion (only if [3] did not match)
      classify one primary or collection block
      infer selectors, semantics, and fields
      confidence-gated draft / one-time export / local publication
      generated definitions remain explicitly unreviewed
      │
      ▼
Assembled page representation
      envelope + blocks + entities + warnings
      │
      ├─ session: merge, deduplicate, upgrade
      │
      └─ exporters
          ├─ JSON-LD (canonical)
          ├─ compact JSON projection (LLM)
          ├─ Markdown
          └─ clipboard / file
```

Layer 3 is exclusive: two adapters writing the same fields produce non-deterministic, undebuggable output. Selection is by specificity — host, path pattern, DOM assertion — then by source order (§13.4), then by explicit `priority`. Layer 4 never creates a competitor for a matched layer-3 adapter, including one whose extraction has degraded; that case enters repair. Layer 2 is non-exclusive because embedded components are matched by their own DOM signature across unrelated hosts; a site adapter may claim a region to suppress duplicate contribution.

## 10. The Block Model: Arity, Role, Fidelity

**Arity** — `one` or `many`. Determines parsing shape.

**Role** — what the block is for:

| Role | Meaning | Session behavior |
|---|---|---|
| `primary` | What the page is about | Merged |
| `collection` | The page's main list | Merged |
| `related` | Similar items, recommendations, carousels | Excluded |
| `navigation` | Pagination, breadcrumbs, facets | Retained as metadata |

Role matters more than arity. A "similar jobs" carousel is plural and structurally identical to search results; without a role it silently contaminates a session with items the user never searched for.

**Fidelity** — `summary` or `full`. A result card is a `summary` observation; a detail page is `full`. This is what makes progressive enrichment work: browse a list, click into an item, and the detail extraction upgrades the existing entry rather than duplicating it.

Merge rules:

1. Match on stable identifier, falling back to canonical URL.
2. Higher fidelity wins on conflicting scalar fields.
3. Equal fidelity: most recent extraction wins; the conflict is recorded as a warning.
4. Fields present in only one observation are unioned in.
5. Every merged entity records its contributing extraction IDs.

## 11. The Adapter

An adapter is authored and distributed as one YAML file. Core interprets a strictly validated normalized data object produced from that file; JSON definitions used during phase-6 grammar development are temporary normalized fixtures, not a second public adapter format. It contains two top-level sections:

- `entities` — field maps, written once per entity type and reused wherever that entity appears on the site.
- `pages` — match conditions and the blocks each page type contains.

A field that exists only on detail pages is simply excluded from card blocks through their field projection. Requirement and monitoring levels are likewise declared per block rather than per entity.

### 11.1 Example

```yaml
adapter: upwork
version: 3
dslVersion: 1
namespace: "https://site2json.dev/ns/upwork#"
hosts: ["www.upwork.com"]

vocabulary:
  terms:
    "upwork:proposalCount":
      description: "The number or range of proposals shown by Upwork."
      valueType: Text
      cardinality: one
      example: "5 to 10"

entities:
  JobPosting:
    schemaType: JobPosting
    identity:
      canonicalUrl:
        selectors: ["a[href*='/jobs/~']@href"]
        transform: [absoluteUrl, stripQuery]
    fields:
      title:
        selectors:
          - "[data-test='job-tile-title'] a"
          - "h2 a"
          - "xpath://h2//a[contains(@href,'/jobs/')]"
        transform: [text, trim]
      description:
        selectors: ["[data-test='job-description-text']"]
        transform: [text, collapseWhitespace]
      datePosted:
        selectors: ["[data-test='posted-on'] span"]
        transform: [text, parseRelativeDate]
      baseSalary:
        selectors: ["[data-test='job-type-label']"]
        transform: [text, parseCurrencyRange]
      skills:
        multiple: true
        selectors: ["[data-test='token'] span"]
        transform: [text, trim]
      "upwork:proposalCount":
        selectors: ["xpath://li[contains(., 'Proposals')]/strong"]
        transform: [text, trim]
      "upwork:client.payment_verified":
        selectors:
          - "xpath:.//*[not(*) and (normalize-space()='Payment verified' or normalize-space()='Payment method not verified')]"
        transform:
          - text
          - lowercase
          - name: mapValues
            args: [{ "payment verified": true, "payment method not verified": false }]

pages:
  - id: search-results
    match:
      host: ["www.upwork.com"]
      path:
        - { mode: exact, value: "/nx/search/jobs" }
      assert: "[data-test='job-tile-list']"
    pageType: SearchResultsPage
    metadata:
      collectionKey:
        source: pageUrl
        transform:
          - name: urlQueryCollectionKey
            args: ["upwork:jobs:", [from_recent_search, page, per_page]]
      snapshotKey:
        source: pageUrl
        transform:
          - name: urlQuerySnapshotKey
            args: ["upwork:jobs:", [from_recent_search, page, per_page], page, 1]
      logicalPosition:
        source: pageUrl
        transform:
          - name: urlQueryPositiveInteger
            args: [page, 1]
    blocks:
      - entity: JobPosting
        scope: "[data-test='job-tile-list'] > section"
        arity: many
        role: collection
        fidelity: summary
        require: [title, canonicalUrl]
      - entity: JobPosting
        scope: "[data-test='similar-jobs'] article"
        arity: many
        role: related
        fidelity: summary

  - id: job-detail
    match:
      host: ["www.upwork.com"]
      path:
        - { mode: prefix, value: "/jobs" }
        - { mode: prefix, value: "/nx/jobs" }
    pageType: ItemPage
    blocks:
      - entity: JobPosting
        scope: "main"
        arity: one
        role: primary
        fidelity: full
        require: [title, canonicalUrl, description]
```

Design notes:

- **Selector chains, ordered, first match wins.** The highest-value resilience feature, and far more natural declaratively than in code.
- **CSS and XPath both.** Label-value pairs ("Proposals: 20–50") are much easier with `following-sibling` and text predicates.
- **`@attr` suffix** for attribute extraction; default is the element.
- **`require` lives on the binding**, because the same entity is legitimately thinner in a card than on a detail page.
- **Dotted field names construct nested records.** `upwork:client.payment_verified` materializes as `{"upwork:client":{"payment_verified":…}}`; empty and prototype-mutating segments are rejected.
- **Page metadata uses the same fixed transform model.** Its input is one of the packaged sources `pageUrl`, `pageTitle`, or `language`; adapters cannot evaluate the document or reference arbitrary runtime state. Literal query-key lists configure packaged URL transforms without supplying executable patterns.
- **URL match conditions may use the same fixed transform model.** This handles structurally encoded routes, such as a URL-safe base64 query value containing keyed path segments, without adding adapter-supplied patterns or executable predicates.
- **Multiple selected values can use a fixed aggregate pipeline.** For example, several explicitly selected content regions can be normalized independently and joined with `joinLiteral`; the adapter still cannot define iteration or aggregation logic.
- **Blocks may project an explicit subset of entity fields.** This keeps detail-only properties structurally absent from search cards without duplicating the entity map. Fields selected for a block still materialize missing observations as `null`, preserving visible near-misses and stable detail-page shapes.
- **`hosts` is declared at adapter level** and is what the permission model checks against (§12).
- Missing required fields produce warnings, populate `quality`, and fail fixture tests.
- Entities within a block are deduplicated by canonical identity after extraction; missing identities and duplicate observations produce explicit warnings.

### 11.2 Transforms

Transforms are named value normalizers implemented in the extension. Adapters reference them; they cannot define them.

```text
text  trim  collapseWhitespace  lowercase  textSlice(start, end?)
int  float  boolean
absoluteUrl  stripQuery  canonicalize
splitLiteral(separator)  replaceLiteral(from, to)
parseCurrency  parseCurrencyRange
parseEnglishDateV1  parseRelativeDate  parseDuration
mapValues(table)  default(value)
base64UrlDecode  pathSegmentValue(key)  pathSegmentValues(key)
pathWithoutSegmentPairs(keys)  joinLiteral(separator)
```

The vocabulary stays small, composable, and site-independent. Selectors and XPath isolate a site's labels and values; generic operations then normalize them. Genuinely hard parsing — relative dates, currency ranges, duration strings — is centralized in shared, cross-site transforms with fixtures from more than one presentation wherever practical. Copying an imperative adapter's site-specific regular expressions into namespaced core transforms is not a declarative port and is not the normal extension mechanism.

New transforms are added to core by reviewed PR only when the operation is plausibly reusable. A site-specific packaged transform is an exceptional escape hatch, not the expected cost of adding each field or site.

Adapters cannot supply regular expressions or any other pattern program as transform arguments. Parsing patterns live inside named, reviewed core transforms. This applies even where the input appears bounded: adapter-controlled regex against extracted page text would let rendered content trigger catastrophic backtracking, while adapter-controlled regex against paths would create the same unnecessary execution surface for less benefit. Path matching therefore uses constrained literal `exact` and segment-aware `prefix` rules. Additional path semantics require a new packaged matcher, not an adapter-defined pattern.

**Compatibility is resolved by capability check, not version match.** An adapter already names every transform it uses, so site2json derives the required set at load time and verifies it can supply all of them. A missing transform produces an exact error — *requires `parseFuzzyDuration`, not available in site2json 0.1* — rather than an uninformative "needs transform library v4." No version metadata is needed for this, and nothing can drift out of sync with the file's actual contents.

**The transform library is append-only.** Transforms are never removed, and the behavior of an existing transform never changes. Where different behavior is needed, a new name is added and the old one deprecated in documentation. Adapters live in repositories that core cannot see or test against; a silent semantic change to a shared transform breaks them invisibly and at scale.

`dslVersion` is therefore reserved for grammar changes — new top-level keys, changed selector syntax, altered block semantics — which should be rare. It is not a proxy for the transform library.

### 11.3 The Compliance Constraint

Chrome Web Store policy permits fetching a remote configuration file where all logic for the functionality is contained in the extension package, and explicitly prohibits building an interpreter that runs complex commands fetched from a remote source *even when those commands arrive as data*. Selectors plus named core-implemented transforms sit on the configuration side of that line.

Therefore: **no embedded expression language.** No jq, no JSONPath, no adapter-supplied regular expressions, no custom pseudo-selector grammar, no per-adapter conditionals or loops. CSS and XPath identify rendered nodes but cannot compute values; fixed named core transforms interpret selected values. This is a fixed constraint on all future DSL evolution, not a style preference.

### 11.4 Escape Hatch

Distributed adapters contain no executable code. First reshape the extraction with CSS/XPath and compose the existing generic vocabulary. If a genuinely reusable operation is missing, add a named transform to core by reviewed PR. A narrowly site-specific packaged transform remains possible for a blocked, high-value adapter, but it is an explicit exception because it expands the permanent append-only core API.

The known cost is that a private or business user needing an unimplemented transform is blocked on the core project. Mitigations, in order of preference: keep the transform library generous and composable; batch community transform requests; accept narrow site-agnostic transforms liberally.

## 12. Permissions and the Security Boundary

**The security boundary is host permissions, not source vetting.** A hostile source could publish an adapter matching a webmail host with selectors that read message bodies. What prevents harm is not review; it is that the adapter cannot run on a host the user has not granted, and that nothing is extracted without a deliberate user action on that page.

Enforced properties:

- **Adapters cannot initiate an extraction.** They shape an extraction the user requested. No adapter-triggered execution, no background activation, no page-load hook.
- **Adapters have no network access.** They are data interpreted by core; they cannot exfiltrate anything.
- **Host permissions are requested per site, on demand,** via `optional_host_permissions`. Installing a source grants nothing.
- **Adapters for ungranted hosts are inert** and displayed as inactive.
- **Export is always explicit** and user-initiated.

Worst case is therefore bounded to: data the user was already looking at, on a site they already granted, at the moment they pressed the button — visible to them in the output before it goes anywhere.

Per-site permission requests also improve install conversion and reduce store review friction relative to a blanket all-sites request.

## 13. Sources

### 13.1 What a Source Is

A source is a URL pointing at a list of adapters. Concretely, a static directory someone hosts:

```text
https://example.com/adapters/
  index.json          ← the listing: which adapters, versions, hosts, hashes
  index.json.sig      ← signature over the listing
  adapters/
    upwork.yaml
    indeed.yaml
    github.yaml
```

And the user's configuration is an ordered list of those URLs:

```text
sources:
  1. https://example.com/adapters/index.json      (remote, signed)
  2. file:///home/me/work-adapters/index.json     (local, unsigned)
```

The extension fetches each listing, learns which adapters exist and which hosts they cover, and pulls the adapter files it needs. Everything site-specific lives in those files; no other part of the pipeline knows any site exists.

#### 13.1.1 Local Adapter Import Before Sources

The first custom-adapter onboarding path does not require a source. The browser side-panel editor's adapter library accepts a user-selected `.yaml` adapter file, validates it locally, shows the adapter ID, hosts, page types, and required transforms for confirmation, then stores an internal copy in `chrome.storage.local`. Imported adapters can be enabled, disabled, replaced by re-import, exported, or deleted beside the same editor used to create and repair them.

This is a local adapter registry, not a source subscription:

- No index, URL, signature, TOFU, update channel, or rollback history.
- No persistent filesystem access or directory watching. Editing the original file does not update the imported copy; the user re-imports it.
- The uploaded file remains inert data. All parsing, validation, selection, and named transform behavior is packaged extension code.
- Extraction remains user-initiated. The imported adapter is passed to the packaged interpreter for the active page; it cannot initiate execution or network access.

A stored entry has enough provenance to distinguish exact file changes from semantic changes:

```json
{
  "id": "my-adapter",
  "source": "local-file",
  "importedAt": "2026-08-09T03:30:00Z",
  "enabled": true,
  "dslVersion": 1,
  "sourceDigest": "sha256:…",
  "definitionDigest": "sha256:…",
  "definition": {}
}
```

- `sourceDigest` is SHA-256 over the exact bytes selected by the user, before text decoding or YAML parsing. It detects any difference from a subsequently selected file, including comments, whitespace, encoding, or line endings, and is also the appropriate integrity digest for a source-distributed file later.
- `definitionDigest` is SHA-256 over a deterministic canonical serialization of the validated, normalized definition. It detects whether two differently formatted files describe the same adapter behavior. Canonicalization sorts object keys recursively, preserves array order, and rejects values outside the DSL's validated data model before hashing.

The original YAML text may be retained for inspection and re-export, but runtime interpretation uses only the validated normalized definition. The generic local-file/directory source listed below is a later feature; unlike single-file import, it may maintain an index and detect changes automatically.

The YAML library is selected only after an acceptance test proves the configured parser rejects custom tags, aliases, merge keys, duplicate keys, and values outside the normalized DSL data model. A library's generic "safe" mode is not accepted as evidence by itself; the exact schema and parser options are part of the reviewed implementation.

### 13.2 Index Format

```json
{
  "source": "community-adapters",
  "indexVersion": 47,
  "publishedAt": "2026-08-08T09:00:00Z",
  "adapters": [
    { "id": "upwork", "version": 3, "dslVersion": 1,
      "hosts": ["www.upwork.com"],
      "path": "adapters/upwork.yaml",
      "sha256": "…" }
  ]
}
```

Source types:

| Type | Signed | Auto-update | Use |
|---|---|---|---|
| Default | Yes | Per §13.5 | Preconfigured, removable (see §14) |
| Remote | Required | Per §13.5 | Community and company sets |
| Local file/directory | Not required | On change | Personal and in-development adapters |

Local unsigned sources exist so an individual or company can maintain internal adapters without signing infrastructure. They are marked unverified in the UI and are never fetched over the network.

### 13.3 Trust on First Use

Each remote source declares a public key. The extension pins it when the user subscribes and refuses anything not signed by it. Key rotation is a rotation record signed by the outgoing key. No central authority, no CA, and a compromised host cannot silently swap keys.

The signed index carries each adapter's hash, so one signature covers the set transitively. Index versions are monotonic and older indexes are refused, preventing replay of a stale signed set to reintroduce a fixed bug.

Signing uses ECDSA P-256 via WebCrypto, with private keys held offline or in CI with a hardware token.

### 13.4 Subscribing and Ordering

- Adding a source requires paste-and-confirm. **No URL scheme, no deep link, no page-initiated subscribe** — otherwise a site could add its own source.
- Adding a source grants no permissions.
- The source list is explicitly ordered and user-reorderable. On adapter ID collision, the first source wins.
- Collisions are surfaced visibly, with a per-adapter pin ("always take `upwork` from source X").
- Resolution never uses "highest version wins," which would let a hostile source shadow a good adapter by bumping a number.

**Privacy:** the extension fetches whole listings and matches locally. It never queries a source for a specific domain, which would leak browsing history to the source operator.

### 13.5 Updates

**Auto-update silently unless the change alters what the extension can touch.** Per-adapter approval for every change asks users to adjudicate selector diffs they have no basis to judge, and defeats the purpose of the out-of-band channel — a selector fix should reach users the same day without a click.

Changes requiring explicit approval, presented as a banner while the previous version stays active:

- The adapter's `hosts` or match patterns widen.
- `dslVersion` changes.
- The source rotates its key.
- The source adds adapters for hosts the user has already granted.

Everything else — selector repairs, new optional fields — applies silently.

**Pinning and rollback.** The last-known-good version of each adapter is retained; adapters are small text files and history is nearly free. One-click revert, and a pin to stop updates for a specific adapter.

## 14. The Default Source

Shipping with no adapters means first run does nothing, which is bad for adoption. A default source is preconfigured and removable.

**It is published under its own identity**, in its own repository, with its own maintainer — not as part of core. Curating a set and honoring takedown requests is an editorial role, and separating it keeps core's neutrality legible to anyone who looks. Users can remove the default source entirely.

**Inclusion and removal criteria are written before they are needed.** Judging "sites that might object" case by case in the moment invites inconsistency and pressure. The stated policy:

- No adapter for a site whose listing data is its primary product (marketplaces, aggregators, listing services).
- Removal on request from a site operator, without argument, within a stated window.
- Removal is a delisting from the index. The extension does not reach into users' local caches, and forks are outside the maintainer's control. This limit is stated up front rather than discovered during a takedown.
- Removal reasons are logged publicly.

Being visibly responsive is what keeps this uneventful. Anything the default source excludes remains available from third-party sources, which is the point of the source model.

## 15. Semantic Discovery

Declared structured data is read on every page and used three ways: as an **anchor** for locating content, as a **source** for fields the DOM does not expose (identifiers, ISO timestamps behind relative displays), and as a **cross-check**.

Where declaration and DOM disagree, the DOM wins and the discrepancy is recorded as a warning. Embedded JSON-LD is usually produced for search-engine snippets rather than as a faithful description of the page; on job and product sites it is routinely a stripped, stale, or optimistically framed subset of what is rendered.

Trust order for fields the DOM does not carry: JSON-LD, Microdata, RDFa, OpenGraph, other meta tags.

## 16. Dynamic DOM Realities

**Virtualized lists.** Frameworks that mount only visible rows mean the DOM holds a fraction of results. Compare rendered count against any declared total and warn explicitly. Never report a partial list as complete.

**Infinite scroll.** Re-extracting the same URL within a session **replaces** the prior extraction of that URL. Last extraction wins with the most items; appending would double-count.

**Shadow DOM.** The v0.1 selector model is rooted in the light DOM and does not cross shadow boundaries. The visual picker detects selections inside open or closed shadow roots and refuses to generate a selector that the runtime cannot reproduce. Slotted nodes remain ordinary light-DOM content. A future open-root implementation must use an explicit structured selector path (host selector, boundary step, inner selector) shared by the editor and runtime; it must not invent a CSS-looking combinator that works only in the authoring UI. Closed roots are not supportable from page JavaScript and remain a visible extraction gap.

**Same-origin iframes.** Traversable and sometimes necessary. Cross-origin iframes are reported as a gap, never silently skipped.

**Late hydration.** A bounded mutation-observer settle window before extraction avoids capturing a skeleton screen. User-initiated, not background polling.

## 17. Extraction Envelope

```json
{
  "extraction": {
    "id": "r_01J8X…",
    "extractorVersion": "0.1.0",
    "adapter": "upwork",
    "adapterVersion": 3,
    "adapterSource": "community-adapters",
    "extractedAt": "2026-08-08T14:03:11Z",
    "pageUrl": "https://www.upwork.com/nx/search/jobs/?q=python",
    "pageType": "SearchResultsPage",
    "blocks": [
      { "entity": "JobPosting", "role": "collection", "arity": "many",
        "fidelity": "summary", "count": 30 },
      { "entity": "JobPosting", "role": "related", "arity": "many",
        "fidelity": "summary", "count": 6 }
    ],
    "warnings": [
      { "code": "field.missing", "field": "upwork:connectCost", "count": 4 },
      { "code": "list.possiblyTruncated",
        "detail": "declared 214 results, rendered 30" }
    ],
    "quality": { "complete": false, "requiredFieldCoverage": 0.98 }
  },
  "graph": {
    "@context": {
      "@vocab": "https://schema.org/",
      "upwork": "https://site2json.dev/ns/upwork#"
    },
    "@type": "SearchResultsPage",
    "mainEntity": {
      "@type": "ItemList",
      "numberOfItems": 30,
      "itemListElement": [{ "@type": "JobPosting" }]
    }
  }
}
```

Page meaning and extraction metadata stay separate. Provenance in normal output is a per-field `inferred` flag; full provenance is retained only in the fixture harness.

Vocabulary rules: use a Schema.org property if it fits; otherwise a namespaced property; a namespaced type only when the Schema.org type is genuinely wrong. Document every extension term with meaning, datatype, cardinality, and an example.

Adapter-local extension terms are documented inline under `vocabulary.terms`, so the public adapter remains one portable YAML file. A term name uses the adapter prefix and declares `description`, `valueType`, `cardinality` (`one` or `many`), and an inert example. Nested field paths such as `upwork:client.location` register the root term (`upwork:client`) and treat the suffix as structure within that value. This registry is descriptive and validation-oriented; it cannot contain transforms, expressions, selectors, or executable behavior.

## 18. Sessions

- Start a session from the current page; add extractions explicitly.
- Re-extracting the same URL replaces that extraction.
- Only `primary` and `collection` blocks merge into session entities; `related` is retained per-extraction but excluded.
- Deduplicate and upgrade per §10.
- Track logical position and flag gaps where determinable.
- Finish, copy, download, or discard explicitly.

## 19. Exporters

- **JSON-LD** — canonical representation, internal source of truth.
- **Compact JSON projection** — first-class. The primary consumer is an LLM, which gains nothing from `@context` and `@type` ceremony but pays for it in tokens. Projection is site-independent: Schema.org fields use stable compact aliases, extension properties flatten by their vocabulary-local name in snake_case, and colliding local names remain losslessly qualified under `extension_fields`. Missing top-level values and `site2json:*` provenance fields are omitted. Supports field selection so a given prompt gets only what it needs.
- **Markdown** — generated from the structured representation, not from HTML.
- **Clipboard / file** — explicit local export.

The popup exposes Compact JSON and JSON-LD as a remembered, profile-local export preference. One selection applies consistently to single-page and session copy/download actions, including keyboard shortcuts. Rendered-card `site2json:rawText` is excluded from Compact JSON by default and has a separate remembered opt-in; JSON-LD remains canonical and is unaffected. Session JSON-LD uses the merged entity graph while retaining snapshot extraction metadata, warnings, and entity observation history in the envelope.

Interoperability and token efficiency genuinely conflict. Where they do, the compact projection serves the daily workflow and JSON-LD stays canonical for storage, diffing, and downstream tooling.

## 20. Testing, Health, and Maintenance

A core deliverable. Adapters break when sites redeploy, and the failure is quiet: a field stops resolving and output silently degrades. Nobody files an issue for data they never saw.

**Fixture harness.** Every adapter ships saved HTML fixtures with expected output, run in CI on change and on schedule. Fixtures are captured from real pages through an in-extension action with a scrubbing pass for personal data.

**Coverage assertions.** Tests fail on missing required fields, not merely on parse errors. Warning counts are part of expected output.

**Field health monitoring.** The useful signal to the user is not "an update is available" but "this adapter is degrading." Track `requiredFieldCoverage` locally per adapter across recent extractions and surface an indicator when it drops. This catches silent rot in the field, days before anyone reports it, and provides a natural opt-in "send a fixture to the source maintainer" action that feeds repairs upstream.

**Assisted repair.** When a fixture test fails, feed the current fixture, the failing adapter, and the diff to a model and have it propose a correction. Because adapters are constrained YAML validated against a schema and verified against fixtures, proposals are machine-checked before a human sees them. For the long tail this likely outperforms waiting for contributors — a direct consequence of adapters being data rather than code.

## 21. Documentation

Documentation is a deliverable, not an afterthought, and it has an unusual requirement: most adapters will be written with a model in the loop, so the docs are as much a machine interface as a human one.

- **The JSON Schema is the specification.** Reference documentation generates from it so the two cannot drift.
- **Transform reference with input → output examples** for every entry. This will be the most-visited page by a wide margin and is the main thing an adapter author needs.
- **One complete annotated adapter** (Upwork) as the canonical worked example.
- **A single-file authoring bundle** — schema, full transform list, one complete adapter — sized to paste into a model. This one artifact likely does more for adapter coverage than the entire prose manual.
- **Fixture-first authoring tutorial:** capture the fixture, write expected output, then write the adapter until tests pass. This makes the harness feel like the tool it is rather than a chore.
- **Validation errors are documentation.** Every schema failure names the offending path and the fix.
- **Source operator guide:** index format, signing, key rotation, hosting.

## 22. Authoring Pipeline

Adapters are generated with a model in the loop. This works because Schema.org is a vocabulary models already know well — the task is mapping a page onto a familiar ontology rather than learning a novel one, which is why it succeeds where generating scraper code does not.

The visual editor uses one field-discovery pipeline. It first inventories recurring DOM values within a bounded sample, then applies Schema.org matching; an authoring option controls whether unmatched structural values are also added. Unmatched values remain explicitly unresolved editor state rather than invented vocabulary and must be mapped, documented as adapter-prefixed extensions, or removed before export. Discovery reconciles by source identity and may upgrade untouched suggestions, but never overwrites a field the author has edited. The complete in-memory adapter is already the draft—autofill does not create a second competing draft model.

Pages whose meaning spans several related types need more context than one flat entity picker can provide. [`SEMANTIC_COMPOSITIONS.md`](SEMANTIC_COMPOSITIONS.md) proposes an authoring-time graph of Schema.org nodes and relationships that constrains mapping suggestions without becoming runtime logic. It preserves the rule below that creation needs a human: compositions narrow and explain plausible choices, but do not assert that a value's shape proves its meaning.

The visual editor is one responsive browser side-panel application. It owns the draft, visual page selection, discovery, validation, and autosave while page-side scripts provide highlighting and evidence capture through the packaged browser bridge. The guided Structure → Semantics → Discover → Review → Finish flow is specified in `EDITOR.md` and `SEMANTIC_COMPOSITIONS.md` §8.

### 22.1 Ground Truth

**A generated adapter and its expected output must not come from the same generation.** If a model writes both, the fixture test verifies that the adapter matches what the model believed the page said, not what the page says. The loop closes on itself and passes indefinitely while being wrong.

Expected output is ground truth. It comes from human review, or from a separate pass that checks extracted output against the page without seeing the adapter.

### 22.2 Fixture Preprocessor

Real search pages are megabytes of HTML and cannot be used directly. A preprocessor is required tooling, not a convenience:

- Strip scripts, styles, SVG path data, inline base64, and tracking markup.
- Collapse repeated siblings to two or three representative examples, preserving all attributes.
- Retain declared JSON-LD, meta tags, and the surrounding structure of kept nodes.
- Emit a size-bounded document suitable for both model input and fixture storage.

### 22.3 Selector Quality

Fixture tests confirm an adapter works today; they cannot detect that it will break next week. A generated `div > div:nth-child(3) > span` passes and then fails on the next deploy.

- **Lint selectors.** Penalize positional selectors, hashed class names, and deep descendant chains. Reward `data-*` test attributes, ARIA roles, stable IDs, and text-anchored XPath.
- **Require multiple fixtures per page type**, including at least one messy case with promoted listings, missing fields, or unusual layouts. A single clean fixture teaches a model the page is more uniform than it is.

### 22.4 Vocabulary Registry

Generation must not invent freely. Two adapters produced in separate sessions will name the same concept differently — `upwork:proposalCount` in one, `upwork:numProposals` in the next — and the drift is invisible until something queries across them.

Each namespace keeps a registry of extension terms with meaning, datatype, and cardinality. Generation reads from it first and appends only with justification. The §11 rule holds: Schema.org property, then namespaced property, and a namespaced type only when the Schema.org type is genuinely wrong.

The editor's standard vocabulary is generated from a pinned official Schema.org release rather than maintained as an independent hand-written subset. The committed source snapshot and license carry their source URLs and verified SHA-256 digests; an explicit maintainer command updates the pin and regenerates the compact browser catalog. The generated catalog retains class inheritance, property domain and range sets, descriptions, extension-layer status, and supersession metadata. Schema.org does not declare ordinary property cardinality, so `one`/`many` choices shown by the editor are site2json authoring defaults and remain editable—not facts attributed to Schema.org. Runtime extraction performs no vocabulary network requests.

Field mapping keeps three kinds of support distinct. **Observed evidence** is computed once from the rendered candidate—lexical hints, value shape, element/attribute structure, and cross-item population—and the same analyzer is used for Schema.org, installed extension, and adapter-local terms. A catalog or search rank is never reused as observed evidence. **Catalog validity** records facts supplied by the selected vocabulary, including declared domain and range, direct versus inherited domain membership, and valid relationship targets. **Semantic priors** record weaker authoring guidance such as property salience, selected-composition expectations, and site2json's editable cardinality default. Confidence reports preserve those categories separately so the UI never describes an authoring convention as a Schema.org constraint.

### 22.5 Trusted Creation Requires Review

**Repair has built-in ground truth.** A failing fixture test supplies the old adapter, the new fixture, and a precise target, and the result is machine-checkable against schema and fixtures. This is a genuine unattended pipeline: test fails, model proposes a correction, validation and fixture run gate it, a PR opens.

**Trusted creation needs a human.** Nothing in the system can prove what a page *means*. Semantic mapping — which entity this is, which role a block plays, whether a field is genuinely `datePosted` — remains a judgment that validation cannot establish. Automatic conversion may create an explicitly unreviewed draft and, under unusually strong aggregate evidence, install it locally; it does not turn an inference into reviewed meaning.

The automatic path uses separate decisions for individual fields, the current export, and future reuse:

- only strong field mappings enter the generated definition automatically;
- a medium-confidence valid extraction may be downloaded once while its adapter remains an uninstalled draft;
- local publication requires a higher aggregate threshold across block shape, winner margin, semantic model, field coverage, identity, selector quality, and extraction warnings; and
- a low-confidence run saves its draft, emits no potentially misleading data, and directs the user to Elements → Site2JSON.

Before authoring, site2json resolves the current URL against published and draft state. A matching enabled adapter is used normally. A disabled adapter remains disabled. A manual draft is never overwritten. An automatic draft may be resumed. A matched but degraded published adapter enters repair instead of gaining a competing generated definition.

Automatic mode creates at most one entity-producing block. Its first decision is page shape: a repeating collection becomes `arity: many`, `role: collection`; a single primary entity becomes `arity: one`, `role: primary`. Absence of repetition is therefore not itself a failure and must not cause `body`, navigation, or an unrelated widget list to become the result scope.

Automatic adapter provenance generalizes the editor-only provenance already retained for fields. Draft and local-registry metadata record automatic origin, generator version, generation time, review status, and aggregate confidence without changing runtime behavior or definition digests. Portable adapter annotations are deferred until a distribution use case requires them.

Schema.org usage statistics may provide a weak prior and candidate evaluation order, never decisive semantic evidence. The project pins an official usage-statistics release with source URL, license, digest, and a reproducible compact generator, following the vocabulary-catalog process in §22.4. Co-occurrence data may improve composition priors only when its redistribution terms permit bundling. Observed page evidence must be able to defeat every popularity prior.

Field decisions are made jointly within an entity block rather than by independently accepting each field's local winner. The bounded assignment search prevents two candidates from claiming the same property and may use compatible relationship families, selected graph expectations, catalog validity, and semantic priors to resolve close local choices. These semantic contributions are reported as support for the assignment; they are not added to the list of observed signals. Automatic acceptance still requires page evidence and a safe counterfactual margin, and a cardinality-default conflict remains reviewable rather than being reported as a vocabulary violation.

Reusable local property profiles are never an invisible installation-dependent override. When one participates in an assignment, authoring repeats the bounded assignment without local profile hints. If the winning property or acceptance result changes, automatic authoring stops with an unresolved Review decision. Saving that decision is explicit consent and snapshots the contributing profile, its local revision and digest, source provenance, the observed/catalog/graph evidence report, alternatives and margins, and the no-profile counterfactual into the adapter's versioned top-level `authoring` envelope. This envelope is inert: the runtime validates and preserves it but never consults it during matching or extraction. Export and import therefore carry a support-grade explanation of why the adapter was authored while identical executable bindings behave identically on every install.

This makes the authoring bundle in §21 the primary interface to the project, with human-facing prose as the secondary artifact.

## 23. Distribution

**Hosting.** Sources are static files. GitHub Pages or a CDN fronting a repository is sufficient; raw repository URLs are rate-limited and unsuitable as a distribution channel. Source origins go in `host_permissions`.

**Repository split.** Core, the default adapter source, and the documentation site are separate repositories with separate maintainer identities.

## 24. Automatic Conversion and Generic Content

The user-facing **Auto-extract this page** action first looks for an existing matching DSL. Only an unsupported page enters automatic authoring. The packaged authoring engine discovers and ranks either one repeated collection or one primary entity, constructs an inert draft, validates it through the production interpreter, and tests the resulting extraction before applying the §22.5 confidence policy.

There are three outcomes:

1. **Publish and download:** exceptionally strong aggregate confidence installs the explicitly unreviewed adapter locally and downloads JSON.
2. **Draft and download once:** the current extraction is useful, but confidence is insufficient to make the definition sticky for future visits.
3. **Draft and review:** confidence is too low to emit data; the popup explains the failure and points to the saved draft in Elements → Site2JSON.

Page metadata, article-like content, and tables remain possible future inferred conveniences, but they are not substitutes for the single entity-producing block required by automatic adapter creation. Borrow established content extraction where appropriate rather than expanding the inert DSL into executable heuristics.

Deliberately deprioritized: highest effort, lowest return, and article extraction is well solved by existing libraries. Borrow rather than rebuild; treat generic output as a convenience rather than a supported path.

## 25. Spun Out: JSON-LD Authoring and Validation

The v0.1 authoring/validation mode is a separate project. It shares a pipeline but nothing else: a different user (site owner), a different lifecycle, a different trust model, and an inverted relationship to declared markup — it exists to find and fix bad declarations. It should consume this project as a library.

## 26. Development Sequence

Phases 1–4 are justified by a single user with a daily workflow, independent of adoption.

**Phase 1 — Refactor, no behavior change.** Session, dedup, quality reporting, keyboard actions, and export into core. Upwork logic works as-is behind an adapter boundary.

**Phase 2 — Canonical representation and envelope.** Block model with arity, role, fidelity. Upwork jobs to `JobPosting`, search pages to `SearchResultsPage` + `ItemList`, minimal Upwork vocabulary. Ship the compact LLM projection exporter.

**Phase 3 — Fixture harness.** Capture, expected output, coverage assertions, CI. Before any second adapter, so breakage is legible from the start.

**Phase 4 — Upwork job detail page.** Cheapest test of the entity/binding split and fidelity-based upgrade, on a site already understood.

**Phase 5 — Second site, in plain JavaScript, deliberately.** The point is discovering what two adapters share, not validating a guess.

**Phase 6 — Derive the DSL.** Design from phases 4–5, then validate by mechanically porting the Upwork adapter — the hardest known case. If Upwork does not fit, the DSL is wrong, discovered cheaply.

**Phase 7 — Local adapter import and permissions model.** Add the single-file local adapter registry from §13.1.1 first, followed by local unsigned indexed sources if needed. Use `activeTab` where deliberate current-page extraction is sufficient and `optional_host_permissions` only where persistent per-site grants are required. Makes personal, private, and internal adapters usable without remote infrastructure; worth having before any public release.

**Phase 8 — Documentation, authoring bundle, and fixture preprocessor.** Before inviting contributions, not after.

**Phase 9 — Remote sources.** Signing, TOFU key pinning, index format, ordering, update policy, rollback. Default source established under its own identity with published criteria.

**Phase 10 — Health monitoring and assisted repair.**

**Phase 11 — Component matchers and semantic discovery.**

**Deferred:** generic fallback, discussion adapters, downstream queue integrations.

### Nested relationship variants

A repeated block may preserve a semantic wrapper while classifying an entity below one of its relationships. For example, a search result can remain a `ListItem` whose `item` is selected from `Article`, `JobPosting`, or `Product` candidates with `Thing` as its fallback. The DSL stores these as bounded `variantSlots` on the block. Each slot has one dotted relationship path, one fallback entity, one to five candidate entities, compiled semantic-shape signals, optional explicit evidence, and the same minimum-score and minimum-margin gates used by root variants. Ambiguous slots retain the declared fallback and emit a reviewable warning rather than guessing.

#### Variant authoring and runtime classification

Variant authoring is deliberately two-pass. Semantics first declares a bounded set of types that may occur. Discover then maps the union of fields and relationships belonging to those types. Only after discovery can Site2JSON classify each sampled item using its complete extracted shape. This preserves the visible Structure → Semantics → Discover → Review order without pretending that a type assignment is proven before its fields are known.

Every variant candidate compiled into the DSL contains two inert signal families:

- `signals` are weighted field paths compiled from the candidate entity. A dotted path is a relationship signal. These are evaluated from successfully extracted values.
- `evidence` contains author-selected DOM or field rules. Explicit evidence supplements semantic shape and commonly resolves candidates whose useful fields overlap.

The production classifier sums the matched shape and explicit-evidence contributions, then applies both `minScore` and `minMargin`. It has no dependency on the Schema.org catalog, semantic library, or authoring scorer. The installed semantic library can influence the adapter that is built, but cannot change how that adapter behaves on another installation.

Classification reports retain every candidate's total, shape score, evidence score, matched signals, winning margin, and acceptance thresholds. If no candidate clears both gates, extraction emits the declared fallback entity and a reviewable warning instead of silently claiming a more specific type.

Structural monitoring also records which candidate populations cleared those gates when the baseline was captured. If a later page no longer produces a previously observed candidate population, Site2JSON reports `variant.classificationDrift`; selector coverage alone is not treated as sufficient health evidence for a shape-classified adapter.

Verification is scoped to observed samples, never to a website in general:

- Authors should include every expected variant in representative sample data whenever possible.
- “Observed” or “verified” means only the pages and items recorded by the authoring session. One page is not evidence that future pages contain the same population.
- A declared type that is absent from the sample remains unverified.
- Adding more candidate types does not prove that the adapter can distinguish them.
- When candidates expose equivalent extracted shapes, explicit evidence is required to establish a safe winner.
- Collection sessions should eventually aggregate classification verification across their captured pages; until then the UI must state the sampled page and item counts.

Automatic inference treats the first semantic pass as candidate-set inference. It discovers schema fields for that bounded union and performs definitive classification afterward. Ambiguous or fallback items stop the automatic path in Review and enter the evidence-resolution workflow; they do not force an earlier Semantics failure.

The evidence workflow shows the affected sample, candidate score breakdowns, supporting and conflicting signals, and the intended type. The author selects a distinguishing rendered element or field, saves the resulting inert rule, and Site2JSON reclassifies the full sample. Persistent Attention remains until the ambiguity clears or fallback behavior is explicitly accepted.

## 27. Open Questions

- Whether extension vocabulary lives under one project namespace or per-site namespaces.
- Whether component matchers ship as adapters in a source or stay bundled in core.
- Whether a source can be marked trusted for automatic host-permission requests, or whether every host grant stays manual forever.
- Whether first run preconfigures the default source or walks the user through choosing one.
- Whether sessions stay simple collections or become a general queue/project concept.
- Whether the compact projection needs named presets or per-extraction field selection suffices.
- How much settle-time heuristics belong in core versus per-adapter declarations.
- Whether the vocabulary registry is per-source or global, and who arbitrates term collisions.

## 28. Core Product Statement

> **Turn the page the user is intentionally viewing into clean structured data that machines can understand.**

*The human browses. site2json extracts. The user decides where the result goes.*
