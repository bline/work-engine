# Site2JSON lexicon

Site2JSON uses a small set of project-specific terms to separate page structure, observed values, semantic interpretation, and reusable extraction. This lexicon collects those concepts across the design documents. It is a conceptual glossary; [`VOCABULARY.md`](VOCABULARY.md) is the separate registry of emitted RDF/JSON-LD terms.

Lifecycle labels clarify where a term belongs:

- **V1** — the frozen scope/field adapter architecture.
- **V2** — the pre-release S2J Markup and Semantic DOM architecture being proved.
- **Shared** — applies across both architectures or at a product boundary.
- **Research** — belongs to corpus or evaluation work rather than the runtime contract.

## A

### Acceptance receipt

**V1, retained conceptually in V2.** A privacy-safe record that a person knowingly accepted an unresolved classification for one exact observed shape, candidate set, fallback, and confidence policy. A changed shape or policy invalidates the receipt instead of silently extending the acceptance.

### Adapter

**Shared.** An inert, declarative description of what Site2JSON knows about one site. In V1 it is the primary runtime artifact: one YAML file containing entity definitions, page bindings, selectors, transforms, and local vocabulary. In V2, a reusable adapter is an optional compilation product; one-shot extraction does not require one.

### Adapter source

**V1.** A user-configured URL or local path that publishes an ordered list of adapters plus integrity metadata. It is not a DOM source reference or a Semantic Library source category.

### Arbitration

**V2.** The comparison of competing structural, visual, accessibility, and semantic proposals without erasing their evidence provenance. Segmentation arbitration selects a defensible entity grouping; relationship arbitration selects how nested semantic entities connect.

### Attention

**V1, retained conceptually in V2.** The review workflow for unresolved or invalidated decisions, especially ambiguous variants and drifted evidence. Attention is a visible state requiring resolution, not a low-confidence guess hidden in output.

### Authoring profile

**Shared authoring concept.** Portable, inference-only guidance attached to a property, such as aliases, exclusions, expected value shapes, salience, cardinality defaults, examples, or recommended packaged transforms. It can influence a proposal but never becomes executable vocabulary or runtime logic.

## B

### Binding

**V2.** An optional reusable recipe for resolving a value or grouping on a future page. Initial source-binding kinds include `selector`, `sequence`, `literal`, and `visual`. A durable binding survives a future page load; an ephemeral source reference used for immediate highlighting does not.

### Block

**V1.** A typed logical page region that contributes entities and owns arity (`one` or `many`), role, fidelity, scope, and field projections. A block is not the same as a selector fallback: multiple selectors may describe the same block.

## C

### Canonical identity

**Shared.** The stable identifier used to recognize the same logical entity across observations, pages, and sessions, with canonical URL as a fallback. Identity enables deduplication and fidelity upgrades.

### Compact JSON projection

**Shared output term.** The LLM-oriented projection of the canonical entity graph into stable, compact field names. It is an export view, not the canonical semantic model.

### Component matcher

**V1.** A host-independent declarative matcher for a third-party component embedded across otherwise unrelated sites. Component matchers contribute blocks independently of the one selected site adapter.

### Composition graph

See [semantic composition](#semantic-composition).

## D

### Declarative DSL

**V1 and optional V2 compilation target.** The constrained, validated, inert data language used to express reusable extraction. It may name packaged transforms, but it cannot contain adapter-supplied executable code.

## E

### Entity definition

**V1.** The reusable field map for one entity type inside an adapter. Multiple page blocks can bind to the same definition while supplying different scopes, roles, or fidelity.

### Entity independence

**Shared inference axis.** The requirement that each proposed item be a distinct, sufficiently complete entity observation rather than a nested match, duplicate representation, or fragment. It is a hard gate for high-confidence collection inference: repetition or visual polish cannot compensate for its failure.

### Evidence family

**V2.** A provenance-preserving class of input evidence, such as DOM containment, semantic attributes, accessibility data, rendered geometry, computed presentation, screenshots, or OCR. Evidence remains separated so one analyzer cannot corroborate itself after normalization.

### Explicit evidence

**Shared classification term.** An author-selected rendered element or extracted field that distinguishes otherwise similar type candidates. It supplements semantic shape rather than replacing it.

### Extension term

**Shared.** An adapter-prefixed type or property declared when no standard vocabulary term accurately expresses the meaning. Extension terms remain inert declarations; [`VOCABULARY.md`](VOCABULARY.md) records the project and marketplace terms emitted today.

### Extraction

**Shared.** One user-initiated conversion of the currently rendered document into structured data; also the verb `extract`. Site2JSON reserves *render* for the browser painting a document.

### Extraction envelope

**V1 output term.** The page-level result containing metadata, blocks, entities, warnings, and extraction provenance before session assembly or projection.

## F

### Fidelity

**V1, still relevant to reusable V2 results.** How complete an entity observation is. A `summary` card can later be upgraded by a `full` detail-page observation without creating a duplicate.

### Fixture

**Shared testing term.** A controlled page artifact used to reproduce extraction behavior. A scrubbed page fixture is deterministic, privacy-reduced HTML representing one rendered page state; it is distinct from the compact structural baseline stored in an adapter.

## G

### Global candidate arbitration

**Shared authoring direction.** The reconciliation step after independent field scoring and before automatic acceptance. It detects incompatible claims on one evidence node, duplicate properties, singular-value conflicts, invalid nested mappings, and cross-variant mappings, preserving alternatives for review instead of guessing.

### Ground truth

**Shared authoring/evaluation term.** A human-reviewed statement of the intended extraction result or label. Deployed Schema.org declarations and automatically aligned corpus records are evidence or weak labels, not ground truth merely because they exist.

## H

### Hint map

**V1 authoring proposal.** Inference guidance supplied by a semantic composition—nodes, relationships, discovery priorities, aliases, and explanations. It narrows recommendations during authoring but is never executed by the extraction runtime.

## I

### Information-directed Review

**Shared authoring direction.** Prioritization of unresolved decisions by evidence disagreement, candidate margin, semantic importance, affected population, and likely reuse value. It changes review order only; it does not change inference or silently accept a decision.

## M

### Mapping proposal

**Shared authoring term.** A ranked, explained suggestion connecting an observation to a semantic property path and transform pipeline. It becomes a reviewed mapping only after author confirmation.

### Materialized value

**V2.** A value stored directly in a semantic-DOM node after being read from browser text, an attribute, OCR, an image crop, or another observation. It can be a complete extraction result even when no DOM node, selector, or reusable binding can be recovered.

## N

### Node alias

**Semantic-composition term.** A stable, human-readable identifier for a node's role inside a composition, such as `listing`, `service`, or `quoteAction`. It names a position in the authoring graph and is not itself an emitted vocabulary term.

## O

### Observation

**Shared, central term.** A meaning-neutral record of something found in page evidence: possible source locations, materialized value, value shape, samples, coverage, multiplicity, structural context, confidence, and provenance. Observation precedes semantic interpretation.

### OCR — Optical Character Recognition

**Established external term.** Image pixels → characters and text layout. In Site2JSON, OCR is one visual evidence source; it does not by itself determine entity boundaries or semantic meaning.

### OSR — Optical Structure Recognition

**V2, coined project term.** Image or rendered page → spatial and structural organization. OSR recognizes reading order, regions, repetition, alignment, grouping, and likely entity boundaries from visual presentation. It complements OCR: OCR recovers what the marks say; OSR recovers how the rendered parts are organized. Semantic assignment remains a downstream step that decides what those organized parts mean.

### One-shot extraction

**V2.** A valid extraction of the current page whose values or groupings need not be reconstructable on a future load. Failure to compile a durable binding may prevent adapter publication, but it does not invalidate the one-shot S2J Markup already produced.

## P

### Page Analysis

**Shared authoring direction.** The bounded pass that ranks page boundaries, semantic models, and item variants before the user or Automatic Run commits to a result. Its reports support both progressive manual review and the complete automatic decision.

### Page binding

**V1.** The part of an adapter that declares which entity definitions appear on a matched page, where they appear, and in what block role, arity, and fidelity.

### Property path

**Semantic-composition term.** A mapping destination through a semantic graph, such as `listing.datePosted` or `listing.itemOffered.name`. It identifies both a property and the related node that owns it.

### Provenance

**Shared.** Bounded metadata describing where evidence, an observation, decision, import, or merged entity came from. Provenance explains and audits a result; it does not become the result's semantic meaning.

## R

### Realized graph

**Semantic-composition term.** The portion of a composition graph that is actually emitted after reviewed observations materialize its nodes and relationships. Optional or common composition nodes with no supporting mapping need not appear.

### Reviewed mapping

**Shared authoring term.** An author-confirmed connection from an observation to a semantic property, reader, transform, and cardinality. Automatic rediscovery may report alternatives but cannot silently replace it.

### Reviewed correction promotion

**Shared knowledge-loop term.** The explicit, sanitized promotion of a useful human correction into reusable local inference guidance. It may retain safe aliases, exclusions, shapes, units, or normalization knowledge, but not selectors, URLs, or captured page text.

### Repetition consistency

**Shared inference axis.** The degree to which proposed item roots repeat a coherent evidence shape across a population. It supports a collection boundary but cannot establish that the repeated roots are independent entities.

### Run

**V2 product term.** The final automatic workflow that applies the same inference and review machinery as manual authoring. It accepts decisions only above their stage-specific thresholds and stops at the first unresolved decision.

## S

### S2J Markup

**V2.** Site2JSON's portable, versioned intermediate format: a tree of `collection`, `entity`, and `value` nodes carrying materialized values, semantic assignments when known, relationships, confidence, provenance, and optional serializable source references. It expresses perceived semantic organization rather than copying page HTML and is neither page markup nor an adapter recipe. Always write **S2J Markup**; do not abbreviate it as **ASM**.

### Schema assignment

**V2.** The post-observation stage that maps neutral values and entities to vocabulary properties, relationships, and candidate types. It follows segmentation so a tentative type cannot restrict which values are discovered and then appear to confirm itself.

### Semantic bundle

**Shared library term.** A portable, gzip-compressed package of semantic type/property identities, definitions, graph patterns, and source provenance. It excludes local database identities and runtime extraction logic.

### Semantic composition

**Shared authoring concept.** A reusable graph of named nodes, allowed semantic types, and explicit relationships, optionally with discovery priorities and explanations. It constrains mapping proposals and can compile into explicit adapter data; it is not executable extraction logic.

### Semantic DOM

**V2.** The live in-memory tree and API used to inspect and manipulate S2J Markup. It may retain ephemeral page nodes and browser objects for immediate highlighting, but those references are never serialized into S2J Markup. The relationship mirrors HTML and the browser DOM: markup is the portable data; the DOM is the live object model.

### Semantic Library

**Shared authoring service.** The local catalog of reusable custom types, properties, imported vocabulary packages, authoring profiles, and saved semantic graph bundles. Only committed local records participate in inference; remote lookup never participates directly in extraction.

### Semantic shape

**Shared classification term.** The set of candidate fields and relationships actually observed for an entity. Variant classification compares this whole-entity shape with candidate types rather than treating an isolated label as decisive.

### Semantic health baseline

**Shared planned drift term.** A bounded baseline of field coverage, value shape, cardinality, element or attribute kind, variant population, and candidate margins. It complements structural fingerprints by detecting selectors that still match but have begun capturing semantically different content.

### Segmentation

**V2.** The pre-semantic decision about which observations belong together as an entity or collection. Segmentation creates the neutral tree consumed by property assignment, variant classification, and relationship arbitration.

### Session

**V1 product term.** A user-directed collection of extractions merged into one export. Stable identity deduplicates entities, fidelity resolves conflicts, and observation history preserves contribution provenance.

### Shape profile

**V1 drift term.** One legitimate combination of structural dependencies observed for a result variant, including optional-element patterns and their population frequency. Multiple shape profiles prevent normal sparse results from being mislabeled as drift.

### Source reference

**V2.** Optional provenance or enrichment pointing to a capture region, observation, ephemeral browser node, DOM attribute, or similar origin of a materialized value. A source reference is not necessarily durable and is not an adapter source.

### Structural baseline

**V1 drift term.** Compact, bounded adapter data describing expected dependency shapes, selector cardinality, field coverage, and variant evidence for one block. It is compared with the live page and does not require loading the original fixture.

### Structural fingerprint

**V1 drift term.** A deterministic digest of the smallest normalized DOM projection on which an adapter depends. It detects relevant structural change while ignoring rendered values and unrelated markup. V2 may retain fingerprinting conceptually, but not V1's DOM-bound identity model.

### Structural usefulness

**Shared inference axis.** The degree to which a proposed boundary contains useful extractable evidence while avoiding unstable or ineligible wrappers.

### Stage-aware confidence policy

**Shared automation direction.** Separate acceptance thresholds for candidate generation, review suggestions, one-time Run, and automatic publication—and for structural, semantic, mapping, and arbitration decisions. It prevents one opaque confidence score from granting broader authority than its evidence supports.

## T

### Transform

**Shared.** A named, packaged value normalizer implemented by Site2JSON and referenced from inert adapter data. Adapters can configure approved transforms but cannot supply executable transform code.

### Typeless S2J Markup

**V2.** S2J Markup whose entities and values have been segmented and materialized before final vocabulary types and properties are assigned. *Typeless* means semantic interpretation is deferred, not that observations lack value shapes, structural roles, or provenance.

## V

### Variant classification

**Shared, redesigned in V2.** The decision about which candidate entity type best explains a complete observed semantic shape. It considers shape support, explicit evidence, relationship coherence, winner/runner-up margin, and deterministic fallback behavior; it remains distinct from segmentation and property assignment.

### Visual entity profile

**V2.** A normalized description of one perceived rendered entity based on relative position, reading order, alignment, spacing, prominence, presentation, containment, stable DOM evidence, and optional roles. Matching profiles can propose a collection without relying on brittle absolute pixel coordinates.

### Visual grouping and coherence

**V2 inference axis.** Bounded evidence from geometry and computed presentation that rendered parts behave as a group. It can generate or support a boundary, but it remains optional and cannot override failed entity independence.

## W

### Weak label

**Research.** A label derived automatically from deployed declarations, crawl alignment, or another noisy source. It can support corpus construction after quality measurement, but it is never called ground truth without human review.

## Term boundaries at a glance

```text
pixels ── OCR ──> text and text layout ─┐
   │                                    │
   └──── OSR ──> spatial organization ──┼─> observations
DOM, accessibility, and metadata ───────┘        │
                                                 v
                                           S2J Markup
                                                 │
                                  schema assignment + variants
                                                 │
                              one-shot result or compiled adapter
```

Three overloaded words deserve particular care:

- **Source** may mean an adapter distribution source, an observation's source reference, or imported vocabulary provenance. Qualify it in prose.
- **Profile** may mean a visual entity profile, a structural shape profile, or a reusable property authoring profile. These describe different layers.
- **S2J Markup** is the portable intermediate data, while **Semantic DOM** is its live object model. Neither term means the inspected browser DOM with annotations, and neither implies a reusable adapter recipe.
