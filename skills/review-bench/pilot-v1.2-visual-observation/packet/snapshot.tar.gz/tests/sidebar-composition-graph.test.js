"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const CompositionGraph = require("../extension/editor/sidebar-composition-graph");
const Compositions = require("../extension/editor/semantic-compositions");
const SemanticToolbox = require("../extension/core/semantic-toolbox");
const SemanticLibrary = require("../extension/core/semantic-library-service");
const Attention = require("../extension/editor/sidebar-attention");

const html = fs.readFileSync(path.resolve(__dirname, "../extension/editor/sidebar.html"), "utf8");

class FakeGraph {
  constructor(container) {
    this.container = container;
    this.selection = {
      listener: null,
      addListener(_name, listener) { this.listener = listener; }
    };
    this.vertices = [];
    this.edges = [];
    this.connectionHandler = {
      listeners: new Map(),
      setCreateTarget() {},
      isConnecting() { return this.connecting === true; },
      mouseMove() {},
      reset() { this.resetCalled = true; },
      mouseUp(_sender, mouseEvent) {
        if (!this.error) this.connect(this.previous?.cell, this.currentState?.cell, mouseEvent.getEvent(), mouseEvent.getCell());
      },
      addListener(name, listener) { this.listeners.set(name, listener); }
    };
    this.view = {
      scale: 1,
      translate: { x: 0, y: 0 },
      getScale() { return this.scale; },
      getTranslate() { return this.translate; },
      scaleAndTranslate(scale, x, y) { this.scale = scale; this.translate = { x, y }; },
      getState: (cell) => {
        if (!cell._shapeNode) cell._shapeNode = this.container.ownerDocument.createElement("div");
        if (!cell._textNode) cell._textNode = this.container.ownerDocument.createElement("div");
        return { cell, shape: { node: cell._shapeNode }, text: { node: cell._textNode } };
      }
    };
    FakeGraph.last = this;
  }
  addListener() {}
  setCellsEditable() {}
  setCellsResizable() {}
  setCellsMovable() {}
  setConnectable(value) { this.connectionHandler.enabled = value; }
  setAllowDanglingEdges() {}
  setPanning() {}
  setHtmlLabels() {}
  getDefaultParent() { return {}; }
  batchUpdate(operation) { operation(); }
  insertVertex(config) { const cell = { ...config }; this.vertices.push(cell); return cell; }
  insertEdge(config) { const cell = { ...config, geometry: { offset: null } }; this.edges.push(cell); return cell; }
  getSelectionModel() { return this.selection; }
  getSelectionCell() { return this.selectionCell || null; }
  setSelectionCell(cell) {
    this.selectionCell = cell;
    this.selection.listener?.();
  }
  selectCell(cell) {
    this.selectionCell = cell;
    this.selection.listener?.();
  }
  getView() { return this.view; }
  getPlugin(name) {
    if (name === "fit") return { fitCenter: () => { this.container.dataset.centered = "true"; } };
    if (name === "ConnectionHandler") return this.connectionHandler;
    return null;
  }
  validationAlert() {}
  clearSelection() {}
  destroy() {}
}

function fakeLayout(mode) {
  return class {
    constructor(graph) { this.graph = graph; }
    execute() {
      this.graph.container.dataset.layout = mode;
      this.graph.vertices.forEach((cell, index) => { cell.geometry = { x: 24 + index * 190, y: 30 + (index % 2) * 110 }; });
    }
  };
}

function dragEvent(window, type, dataTransfer, coordinates = {}) {
  const event = new window.Event(type, { bubbles: true, cancelable: true });
  Object.defineProperty(event, "dataTransfer", { value: dataTransfer });
  Object.defineProperty(event, "clientX", { value: coordinates.clientX || 0 });
  Object.defineProperty(event, "clientY", { value: coordinates.clientY || 0 });
  if (coordinates.relatedTarget) Object.defineProperty(event, "relatedTarget", { value: coordinates.relatedTarget });
  return event;
}

function setup(composition = Compositions.singleType("Person"), initialToolbox = null, { withAttention = false, onPreview = null, onFocus = null } = {}) {
  const dom = new JSDOM(html, { url: "chrome-extension://test/editor/sidebar.html", runScripts: "outside-only" });
  if (withAttention) dom.window.Site2JsonAttention = Attention;
  const block = { composition };
  const applied = [];
  const appliedTerms = [];
  const stored = {};
  if (initialToolbox) stored[SemanticToolbox.STORAGE_KEY] = SemanticToolbox.normalize(initialToolbox);
  const storage = {
    async get(key) { return { [key]: stored[key] }; },
    async set(values) { Object.assign(stored, values); }
  };
  const editor = CompositionGraph.create({
    document: dom.window.document,
    compositions: Compositions,
    getBlock: () => block,
    getAdapterPrefix: () => "example",
    onApply: async (composition, customTerms) => { applied.push(composition); appliedTerms.push(customTerms); },
    onPreview,
    onFocus,
    maxGraph: {
      Graph: FakeGraph,
      HierarchicalLayout: fakeLayout("hierarchical"),
      CompactTreeLayout: fakeLayout("tree"),
      FastOrganicLayout: fakeLayout("organic"),
      CircleLayout: fakeLayout("circle"),
      InternalEvent: { CHANGE: "change" },
      Point: class { constructor(x, y) { this.x = x; this.y = y; } }
    },
    toolboxApi: SemanticToolbox,
    libraryService: SemanticLibrary.createLegacyToolboxService({ toolboxApi: SemanticToolbox, storage }),
    attentionApi: withAttention ? Attention : false,
    storage
  });
  editor.render();
  return { dom, document: dom.window.document, editor, block, applied, appliedTerms, stored };
}

test("graph nodes and draggable Schema.org tiles use semantic family icons", async () => {
  const { dom, document } = setup(Compositions.singleType("ScholarlyArticle"));
  document.querySelector("#open-semantic-graph").click();
  assert.match(FakeGraph.last.vertices[0].value, /fontawesome-solid\.svg#newspaper/);

  const search = document.querySelector("#semantic-toolbox-search-input");
  search.value = "JobPosting";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 160));
  const use = document.querySelector('#semantic-toolbox-search-results [data-id="JobPosting"] use');
  assert.equal(use?.getAttribute("href"), "../vendor/fontawesome-solid.svg#briefcase");
  dom.window.close();
});

test("graph editor previews the working composition against live V2 page data without applying it", async () => {
  const previews = [];
  const { dom, document, applied } = setup(Compositions.singleType("Product"), null, {
    onPreview: async (composition, customTerms) => {
      previews.push({ composition, customTerms });
      return {
        durationMs: 12.4,
        profileDigest: "fnv1a32:12345678",
        summary: { entityCount: 2, assignedFieldCount: 5, unresolvedFieldCount: 1 },
        output: { "@context": "https://schema.org", "@graph": [{ "@type": "Product", name: "Analyzer" }] },
        formats: {
          markup: { format: "site2json-s2j-markup", root: { kind: "collection" } },
          compact: { entities: [{ type: "Product", name: "Analyzer" }] },
          jsonld: { "@context": "https://schema.org", "@graph": [{ "@type": "Product", name: "Analyzer" }] }
        }
      };
    }
  });
  document.querySelector("#open-semantic-graph").click();
  document.querySelector("#semantic-graph-layout-compare").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(previews.length, 1);
  assert.equal(previews[0].composition.nodes[previews[0].composition.root].types[0], "Product");
  assert.equal(applied.length, 0, "live preview must not apply the working graph");
  assert.equal(document.querySelector("#semantic-graph-live-preview").hidden, false);
  assert.match(document.querySelector("#semantic-graph-live-preview-summary").textContent, /2 parsed entities/);
  assert.match(document.querySelector("#semantic-graph-live-preview-status").textContent, /5 fields assigned · 1 unresolved · 12.4 ms/);
  assert.match(document.querySelector("#semantic-graph-live-preview-output").textContent, /\"Product\"/);
  assert.equal(document.querySelector("#semantic-graph-live-preview-output").dataset.format, "jsonld");
  document.querySelector('[data-live-preview-format="markup"]').click();
  assert.equal(document.querySelector("#semantic-graph-live-preview-output").dataset.format, "markup");
  assert.match(document.querySelector("#semantic-graph-live-preview-output").textContent, /site2json-s2j-markup/);
  assert.equal(document.querySelector('[data-live-preview-format="markup"]').getAttribute("aria-pressed"), "true");
  document.querySelector('[data-live-preview-format="compact"]').click();
  assert.equal(document.querySelector("#semantic-graph-live-preview-output").dataset.format, "compact");
  assert.match(document.querySelector("#semantic-graph-live-preview-output").textContent, /\"entities\"/);
  assert.equal(document.querySelector("#semantic-composition-graph-view").classList.contains("live-preview-open"), true);
  assert.equal(document.querySelector("#semantic-composition-graph-view").dataset.workspaceLayout, "compare");
  assert.equal(document.querySelector("#semantic-graph-layout-compare").getAttribute("aria-pressed"), "true");
  assert.equal(document.querySelector("#semantic-graph-layout-authoring").getAttribute("aria-pressed"), "false");

  document.querySelector("#semantic-graph-refresh-live-preview").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(previews.length, 2);

  document.querySelector("#semantic-graph-layout-authoring").click();
  assert.equal(document.querySelector("#semantic-graph-live-preview").hidden, true);
  assert.equal(document.querySelector("#semantic-composition-graph-view").dataset.workspaceLayout, "authoring");

  document.querySelector("#semantic-graph-layout-compare").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  document.querySelector("#semantic-graph-close-live-preview").click();
  assert.equal(document.querySelector("#semantic-graph-live-preview").hidden, true);
  assert.equal(document.querySelector("#semantic-composition-graph-view").classList.contains("live-preview-open"), false);
  assert.equal(document.querySelector("#semantic-composition-graph-view").dataset.workspaceLayout, "authoring");
  dom.window.close();
});

test("live preview records stable-ID type and field corrections as session overlays", async () => {
  const overlays = [];
  const focuses = [];
  const onPreview = async (_composition, _customTerms, overlay) => {
    overlays.push(overlay);
    const typeDecision = overlay?.reports?.["item:1"];
    const fieldDecision = overlay?.findings?.["item:1:title"];
    const selected = typeDecision?.selected || "https://schema.org/Product";
    const fieldTerm = fieldDecision?.term || "https://schema.org/name";
    return {
      previewId: `v2:review:${overlays.length}`,
      durationMs: 2,
      profileDigest: "fnv1a32:review",
      summary: {
        entityCount: 1,
        assignedFieldCount: fieldDecision?.status === "unresolved" ? 0 : 1,
        unresolvedFieldCount: fieldDecision?.status === "unresolved" ? 1 : 0
      },
      formats: {
        markup: { root: { id: "item:1", term: selected, children: [{ id: "item:1:title", term: fieldTerm, value: "Analyzer" }] } },
        compact: { entities: [{ type: selected, [fieldTerm.split("/").at(-1)]: "Analyzer" }] },
        jsonld: { "@graph": [{ "@type": selected, [fieldTerm.split("/").at(-1)]: "Analyzer" }] }
      },
      focusIndex: { aliases: {}, edges: {} },
      reviewIndex: {
        entities: [{
          entityId: "item:1", status: typeDecision?.status || "accepted", accepted: typeDecision?.accepted ?? true,
          selected, margin: 0.2, candidates: [{ term: "https://schema.org/Product" }, { term: "https://schema.org/Offer" }],
          formats: { markup: ["/root"], compact: ["/entities/0"], jsonld: ["/@graph/0"] }
        }],
        fields: [{
          nodeId: "item:1:title", role: "title", value: "Analyzer", status: fieldDecision?.status || "assigned", term: fieldDecision?.term || null,
          candidates: [{ term: "https://schema.org/name" }, { term: "https://schema.org/description" }],
          formats: { markup: ["/root/children/0"], compact: ["/entities/0/name"], jsonld: ["/@graph/0/name"] }
        }]
      }
    };
  };
  const { dom, document } = setup(Compositions.singleType("Product"), null, {
    onPreview,
    onFocus: async (focus) => {
      focuses.push(focus);
      return { ok: true, nodeIds: focus.reviewId ? [focus.reviewId] : [], sourceCount: focus.reviewId ? 1 : 0 };
    }
  });
  document.querySelector("#open-semantic-graph").click();
  document.querySelector("#semantic-graph-layout-compare").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(overlays.length, 1);
  assert.deepEqual(overlays[0], { findings: {}, reports: {} });
  const typeCard = document.querySelector(".semantic-live-review-card");
  typeCard.dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(focuses.at(-1), {
    previewId: "v2:review:1", kind: "review", reviewKind: "entity", reviewId: "item:1", reveal: true
  });
  assert.equal(document.querySelector(".semantic-live-review-card").getAttribute("aria-current"), "true");
  assert.equal(document.activeElement, document.querySelector(".semantic-live-review-card"), "keyboard review selection preserves focus across rendering");
  assert.ok([...document.querySelectorAll("#semantic-graph-live-preview-output .s2j-code-line.selected")]
    .some((line) => line.dataset.path === "/@graph/0"));
  const typeInput = document.querySelector('input[aria-label="Type for item:1"]');
  typeInput.value = "https://schema.org/Offer";
  typeInput.parentElement.querySelector("button").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(overlays[1].reports["item:1"].selected, "https://schema.org/Offer");
  assert.equal(focuses.at(-1).reviewId, "item:1", "the corrected decision retains synchronized source focus after re-derivation");
  assert.match(document.querySelector("#semantic-graph-live-review-count").textContent, /1 user decision/);

  const fieldInput = document.querySelector('input[aria-label="Property for item:1:title"]');
  fieldInput.closest(".semantic-live-review-card").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(focuses.at(-1).reviewId, "item:1:title");
  fieldInput.parentElement.querySelectorAll("button")[1].click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(overlays[2].findings["item:1:title"].status, "unresolved");
  assert.equal(overlays[2].reports["item:1"].selected, "https://schema.org/Offer", "re-derivation retains independent prior decisions");
  assert.match(document.querySelector("#semantic-graph-live-review-count").textContent, /2 user decisions/);

  const nodeTypes = document.querySelector("#semantic-graph-node-types");
  nodeTypes.value = "Offer";
  document.querySelector("#semantic-graph-update-node").click();
  assert.match(document.querySelector("#semantic-graph-live-preview-status").textContent, /review decisions are stale/);
  const staleInput = document.querySelector('input[aria-label="Type for item:1"]');
  staleInput.parentElement.querySelector("button").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(overlays.length, 3, "a stale stable-ID decision must not be submitted");
  assert.match(document.querySelector("#semantic-graph-live-preview-status").textContent, /stale.*Refresh/i);

  document.querySelector("#semantic-graph-refresh-live-preview").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(overlays.at(-1), { findings: {}, reports: {} }, "refreshing a stale preview clears incompatible decisions");

  document.querySelector("#semantic-graph-close-live-preview").click();
  document.querySelector("#semantic-graph-layout-compare").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(overlays.at(-1), { findings: {}, reports: {} }, "closing the preview clears session-only decisions");
  dom.window.close();
});

test("unresolved entity review cards present Thing as a fallback, not a classification", async () => {
  const { dom, document } = setup(Compositions.singleType("Product"), null, {
    onPreview: async () => ({
      previewId: "v2:unresolved-type",
      durationMs: 1,
      summary: { entityCount: 1, assignedFieldCount: 0, unresolvedFieldCount: 0 },
      formats: { markup: {}, compact: {}, jsonld: { "@graph": [{ "@type": "Thing" }] } },
      focusIndex: { aliases: {}, edges: {} },
      reviewIndex: {
        entities: [{ entityId: "item:1", status: "unresolved", accepted: false, selected: "https://schema.org/Thing", candidates: [], formats: {} }],
        fields: []
      }
    })
  });
  document.querySelector("#open-semantic-graph").click();
  document.querySelector("#semantic-graph-layout-compare").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const card = document.querySelector(".semantic-live-review-card");
  assert.match(card.querySelector("strong").textContent, /Entity type · Unresolved/);
  assert.doesNotMatch(card.querySelector("strong").textContent, /Thing/);
  assert.match(card.querySelector(".semantic-live-review-context").textContent, /fallback Thing/);
  dom.window.close();
});

test("graph selection focuses the corresponding live page sources and preview rows", async () => {
  const focuses = [];
  const { dom, document } = setup(Compositions.preset("site2json:freelance-opportunity"), null, {
    onPreview: async () => ({
      previewId: "v2:test-focus",
      durationMs: 4,
      profileDigest: "fnv1a32:focus",
      summary: { entityCount: 1, assignedFieldCount: 2, unresolvedFieldCount: 0 },
      formats: {
        markup: { root: { term: "https://schema.org/JobPosting", children: [{ term: "https://schema.org/Organization" }] } },
        compact: { entities: [{ type: "JobPosting", hiringOrganization: { type: "Organization" } }] },
        jsonld: { "@graph": [{ "@type": "JobPosting", hiringOrganization: { "@type": "Organization" } }] }
      },
      focusIndex: {
        aliases: {
          listing: { nodeIds: ["item:1"], formats: { markup: ["/root"], compact: ["/entities/0"], jsonld: ["/@graph/0"] } },
          buyer: { nodeIds: ["buyer:1"], formats: { markup: ["/root/children/0"], compact: ["/entities/0/hiringOrganization"], jsonld: ["/@graph/0/hiringOrganization"] } }
        },
        edges: {
          "listing\u001fhiringOrganization\u001fbuyer": {
            nodeIds: ["buyer:1"],
            formats: { markup: ["/root/children/0"], compact: ["/entities/0/hiringOrganization"], jsonld: ["/@graph/0/hiringOrganization"] }
          }
        }
      }
    }),
    onFocus: async (focus) => {
      focuses.push(focus);
      return { ok: true, nodeIds: [focus.alias || "none"], sourceCount: focus.alias ? 1 : 0 };
    }
  });
  document.querySelector("#open-semantic-graph").click();
  document.querySelector("#semantic-graph-layout-compare").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(focuses.at(-1).alias, "listing");
  assert.equal(focuses.at(-1).kind, "node");
  assert.ok(document.querySelectorAll("#semantic-graph-live-preview-output .s2j-code-line.selected").length > 0);
  const organization = FakeGraph.last.vertices.find((cell) => cell.semanticNodeAlias === "buyer");
  FakeGraph.last.selectCell(organization);
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(focuses.at(-1).alias, "buyer");
  assert.equal(focuses.at(-1).kind, "node");
  assert.equal(document.querySelector("#semantic-graph-live-preview-output").dataset.focusSourceCount, "1");
  assert.ok([...document.querySelectorAll("#semantic-graph-live-preview-output .s2j-code-line.selected")]
    .some((line) => line.textContent.includes("Organization")));
  const relationship = FakeGraph.last.edges.find((cell) => Number.isInteger(cell.semanticEdgeIndex)
    && Compositions.preset("site2json:freelance-opportunity").edges[cell.semanticEdgeIndex]?.property === "hiringOrganization");
  FakeGraph.last.selectCell(relationship);
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(focuses.at(-1).kind, "edge");
  assert.equal(focuses.at(-1).focusId, "listing\u001fhiringOrganization\u001fbuyer");
  assert.ok([...document.querySelectorAll("#semantic-graph-live-preview-output .s2j-code-line.selected")]
    .some((line) => line.dataset.path === "/@graph/0/hiringOrganization"));
  const listingLine = [...document.querySelectorAll("#semantic-graph-live-preview-output .s2j-code-line")]
    .find((line) => line.dataset.path === "/@graph/0/@type");
  listingLine.click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(focuses.at(-1).kind, "node");
  assert.equal(focuses.at(-1).alias, "listing");
  assert.equal(document.querySelector("#semantic-graph-live-preview-output").dataset.focusSourceCount, "1");
  assert.equal(document.querySelector("#semantic-graph-node-alias").textContent, "listing · root");
  dom.window.close();
});

test("live preview explains when a selected graph node has no assigned data", async () => {
  const { dom, document } = setup(Compositions.preset("site2json:freelance-opportunity"), null, {
    onPreview: async () => ({
      previewId: "v2:no-nested-data",
      durationMs: 3,
      profileDigest: "fnv1a32:none",
      summary: { entityCount: 1, assignedFieldCount: 1, unresolvedFieldCount: 0 },
      formats: { markup: {}, compact: {}, jsonld: {} },
      focusIndex: {
        aliases: {
          listing: { nodeIds: ["item:1"], formats: { markup: [""], compact: [""], jsonld: [""] } },
          buyer: { nodeIds: [], formats: { markup: [], compact: [], jsonld: [] } }
        },
        edges: {}
      }
    }),
    onFocus: async () => ({ ok: true, nodeIds: [], sourceCount: 0 })
  });
  document.querySelector("#open-semantic-graph").click();
  document.querySelector("#semantic-graph-layout-compare").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  FakeGraph.last.selectCell(FakeGraph.last.vertices.find((cell) => cell.semanticNodeAlias === "buyer"));
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.match(document.querySelector("#semantic-graph-live-preview-status").textContent, /No live data was assigned to “buyer” in this preview/);
  dom.window.close();
});

test("graph editor treats Compare as Authoring with live data added", async () => {
  const { dom, document, editor } = setup(undefined, null, {
    onPreview: async () => ({
      durationMs: 1,
      profileDigest: "fnv1a32:layout",
      summary: { entityCount: 0, assignedFieldCount: 0, unresolvedFieldCount: 0 },
      formats: { markup: {}, compact: {}, jsonld: {} }
    })
  });
  document.querySelector("#open-semantic-graph").click();
  document.querySelector("#semantic-graph-layout-compare").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(document.querySelector("#semantic-composition-graph-view").dataset.workspaceLayout, "compare");
  assert.equal(document.querySelector("#semantic-graph-live-preview").hidden, false);
  editor.render();
  assert.equal(document.querySelector("#semantic-graph-layout-compare").getAttribute("aria-pressed"), "true");
  document.querySelector("#semantic-graph-layout-authoring").click();
  assert.equal(document.querySelector("#semantic-composition-graph-view").dataset.workspaceLayout, "authoring");
  assert.equal(document.querySelector("#semantic-graph-layout-authoring").getAttribute("aria-pressed"), "true");
  assert.equal(document.querySelector("#semantic-graph-live-preview").hidden, true);
  dom.window.close();
});

test("graph editor maximizes into the side-panel viewport and restores without losing its working state", () => {
  const { dom, document } = setup(Compositions.singleType("Person"));
  document.querySelector("#open-semantic-graph").click();
  const view = document.querySelector("#semantic-composition-graph-view");
  const maximize = document.querySelector("#semantic-graph-maximize");

  maximize.click();
  assert.equal(view.classList.contains("maximized"), true);
  assert.equal(document.body.classList.contains("semantic-graph-maximized"), true);
  assert.equal(maximize.getAttribute("aria-label"), "Restore graph editor");
  assert.equal(maximize.getAttribute("aria-pressed"), "true");
  assert.equal(maximize.querySelector(".icon-maximize").hidden, true);
  assert.equal(maximize.querySelector(".icon-restore").hidden, false);
  assert.equal(document.querySelector("#semantic-graph-node-types").value, "Person");

  maximize.click();
  assert.equal(view.classList.contains("maximized"), false);
  assert.equal(document.body.classList.contains("semantic-graph-maximized"), false);
  assert.equal(maximize.getAttribute("aria-label"), "Maximize graph editor");
  assert.equal(maximize.getAttribute("aria-pressed"), "false");
  assert.equal(maximize.querySelector(".icon-maximize").hidden, false);
  assert.equal(maximize.querySelector(".icon-restore").hidden, true);
  dom.window.close();
});

test("graph editor adds a catalog-limited relationship and applies one composition transaction", async () => {
  const { dom, document, applied } = setup();
  document.querySelector("#open-semantic-graph").click();
  assert.equal(document.querySelector("#semantic-composition-graph-view").hidden, false);
  assert.equal(document.querySelector("#semantic-graph-node-alias").textContent, "listing · root");

  const property = document.querySelector("#semantic-graph-relation-property");
  assert.ok(Array.from(property.options, (option) => option.value).includes("affiliation"));
  property.value = "affiliation";
  property.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  assert.equal(document.querySelector("#semantic-graph-new-type").value, "Organization");
  document.querySelector("#semantic-graph-add-relationship").click();
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);

  document.querySelector("#semantic-graph-apply").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(applied.length, 1);
  assert.equal(Object.values(applied[0].nodes).some((node) => node.types.includes("Organization")), true);
  assert.equal(applied[0].edges.some((edge) => edge.property === "affiliation"), true);
  assert.equal(document.querySelector("#semantic-composition-graph-view").hidden, true);
  dom.window.close();
});

test("selected nodes expose multi-open type and property reference accordions", () => {
  const { dom, document } = setup(Compositions.singleType("Person"));
  document.querySelector("#open-semantic-graph").click();

  const settings = document.querySelector("#semantic-graph-node-settings");
  const typeDetails = document.querySelector("#semantic-graph-type-details");
  const properties = document.querySelector("#semantic-graph-properties");
  const connectDetails = document.querySelector("#semantic-graph-connect-details");
  assert.equal(settings.open, true);
  assert.equal(typeDetails.open, true);
  assert.equal(properties.open, false);
  assert.match(document.querySelector("#semantic-graph-type-details-body").textContent, /A person/);
  assert.ok(Number(document.querySelector("#semantic-graph-property-count").textContent) > 50);

  properties.open = true;
  assert.equal(typeDetails.open, true, "independent details elements remain open together");
  const search = document.querySelector("#semantic-graph-property-search");
  search.value = "affiliation";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  const rows = [...document.querySelectorAll(".semantic-property-row")];
  assert.equal(rows.length, 1);
  assert.match(rows[0].textContent, /affiliation/);
  assert.match(rows[0].textContent, /Organization/);
  rows[0].querySelector(".semantic-property-connect").click();
  assert.equal(connectDetails.open, true);
  assert.equal(document.querySelector("#semantic-graph-relation-property").value, "affiliation");
  assert.equal(properties.open, true);
  assert.equal(typeDetails.open, true);

  document.querySelector("#semantic-graph-cancel-relationship").click();
  assert.equal(connectDetails.open, false);
  assert.equal(document.querySelector("#semantic-graph-relation-property").value, "");
  assert.equal(document.querySelector("#semantic-graph-node-alias").textContent, "listing · root", "cancel keeps the source node selected");
  dom.window.close();
});

test("cancel closes the graph without applying its working copy", () => {
  const { dom, document, applied, block } = setup();
  document.querySelector("#open-semantic-graph").click();
  document.querySelector("#semantic-graph-node-types").value = "Organization";
  document.querySelector("#semantic-graph-update-node").click();
  document.querySelector("#semantic-graph-cancel").click();
  assert.equal(applied.length, 0);
  assert.deepEqual(block.composition.nodes.listing.types, ["Person"]);
  dom.window.close();
});

test("updating node metadata preserves the graph viewport and confirms the change", () => {
  const { dom, document } = setup();
  document.querySelector("#open-semantic-graph").click();
  const canvas = document.querySelector("#semantic-composition-canvas");
  FakeGraph.last.view.scaleAndTranslate(0.57, 13, 21);
  canvas.scrollLeft = 84;
  canvas.scrollTop = 31;

  document.querySelector("#semantic-graph-node-types").value = "Organization";
  document.querySelector("#semantic-graph-update-node").click();

  assert.equal(FakeGraph.last.view.scale, 0.57);
  assert.deepEqual(FakeGraph.last.view.translate, { x: 13, y: 21 });
  assert.equal(canvas.scrollLeft, 84);
  assert.equal(canvas.scrollTop, 31);
  assert.match(document.querySelector("#semantic-graph-node-update-status").textContent, /listing was updated/i);
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);
  dom.window.close();
});

test("auto arrange offers graph-shape layouts and centers the result", () => {
  const { dom, document } = setup(Compositions.preset("site2json:freelance-opportunity"));
  document.querySelector("#open-semantic-graph").click();
  const mode = document.querySelector("#semantic-graph-layout-mode");
  for (const name of ["hierarchical", "tree", "organic", "circle"]) {
    mode.value = name;
    document.querySelector("#semantic-graph-auto-layout").click();
    assert.equal(document.querySelector("#semantic-composition-canvas").dataset.layout, name);
    assert.equal(document.querySelector("#semantic-composition-canvas").dataset.centered, "true");
    assert.match(document.querySelector("#semantic-graph-auto-layout-status").textContent, /layout applied/i);
  }
  dom.window.close();
});

test("click selection focuses the canvas and Delete removes the selected node and unreachable descendants", () => {
  const composition = Compositions.preset("site2json:freelance-opportunity");
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  const graph = FakeGraph.last;
  const buyer = graph.vertices.find((cell) => cell.semanticNodeAlias === "buyer");

  graph.selectCell(buyer);
  assert.equal(document.activeElement, document.querySelector("#semantic-composition-canvas"));
  document.activeElement.dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "Delete", bubbles: true }));

  assert.equal(FakeGraph.last.vertices.some((cell) => cell.semanticNodeAlias === "buyer"), false);
  assert.equal(FakeGraph.last.vertices.some((cell) => cell.semanticNodeAlias === "buyerRating"), false);
  assert.equal(FakeGraph.last.vertices.some((cell) => cell.semanticNodeAlias === "service"), true);
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);
  dom.window.close();
});

test("keyboard connection mode creates an unambiguous Schema.org relationship", () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.location = { types: ["Place"], expectation: "common" };
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  const view = document.querySelector("#semantic-composition-graph-view");
  view.dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "c", bubbles: true }));
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Connecting from listing/);
  view.dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
  assert.equal(document.querySelector("#semantic-graph-edge-label").textContent, "listing — jobLocation → location");
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);
  dom.window.close();
});

test("rendered edges get an opaque label pill offset off the midpoint so their text never blends into node text", () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.location = { types: ["Place"], expectation: "common" };
  composition.edges.push({ from: "listing", property: "jobLocation", to: "location", expectation: "common" });
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  const edge = FakeGraph.last.edges.find((cell) => cell.value === "jobLocation");
  assert.ok(edge);
  assert.equal(edge.style.labelBackgroundColor, "#ffffff");
  assert.ok(edge.style.labelBorderColor);
  assert.ok(edge.geometry.offset);
  assert.ok(edge.geometry.offset.x !== 0 || edge.geometry.offset.y !== 0);
  assert.equal(edge.style.edgeStyle, "orthogonalEdgeStyle");
  dom.window.close();
});

test("selected relationships can be corrected after an automatic drag choice", () => {
  const composition = Compositions.singleType("SearchResultsPage");
  composition.nodes.itemList = { types: ["ItemList"], expectation: "common" };
  composition.edges.push({ from: "listing", property: "accessModeSufficient", to: "itemList", expectation: "common" });
  const { dom, document, applied } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  FakeGraph.last.selectCell(FakeGraph.last.edges[0]);
  const property = document.querySelector("#semantic-graph-edge-property");
  assert.equal([...property.options].some((option) => option.value === "mainEntity"), true);
  property.value = "mainEntity";
  document.querySelector("#semantic-graph-update-edge").click();
  assert.match(document.querySelector("#semantic-graph-edge-label").textContent, /mainEntity/);
  assert.match(document.querySelector("#semantic-graph-edge-update-status").textContent, /Updated to listing\.mainEntity/);
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);
  document.querySelector("#semantic-graph-apply").click();
  assert.equal(applied[0].edges[0].property, "mainEntity");
  dom.window.close();
});

test("connector drag constrains an ambiguous node pair to its valid relationship picker", () => {
  const composition = Compositions.singleType("Person");
  composition.nodes.organization = { types: ["Organization"], expectation: "common" };
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  const graph = FakeGraph.last;
  const source = graph.vertices.find((cell) => cell.semanticNodeAlias === "listing");
  const target = graph.vertices.find((cell) => cell.semanticNodeAlias === "organization");
  assert.equal(graph.connectionHandler.enabled, true);
  assert.ok(graph.connectionHandler.connectImage.src.startsWith("data:image/svg+xml"));
  assert.equal(graph.connectionHandler.validateConnection(source, target), null);
  graph.connectionHandler.connect(source, target);

  const property = document.querySelector("#semantic-graph-relation-property");
  assert.equal(document.querySelector("#semantic-graph-connect-details").open, true);
  const choices = Array.from(property.options, (option) => option.value).filter(Boolean);
  assert.deepEqual(choices, Compositions.structuralRelationshipOptions(["Person"], "Organization").map((option) => option.property));
  assert.match(document.querySelector("#semantic-graph-status").textContent, /valid relationships connect listing to organization/);
  property.value = "affiliation";
  property.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  assert.equal(document.querySelector("#semantic-graph-relation-target").value, "organization");
  document.querySelector("#semantic-graph-add-relationship").click();
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);
  dom.window.close();
});

test("connector release recovers a rendered target when maxGraph loses its target state", () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.location = { types: ["Place"], expectation: "common" };
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  const graph = FakeGraph.last;
  const source = graph.vertices.find((cell) => cell.semanticNodeAlias === "listing");
  const target = graph.vertices.find((cell) => cell.semanticNodeAlias === "location");
  graph.getView().getState(target).shape.node.getBoundingClientRect = () => ({ left: 20, right: 120, top: 30, bottom: 100 });
  graph.connectionHandler.connecting = true;
  graph.connectionHandler.previous = { cell: source };
  graph.connectionHandler.currentState = null;
  graph.connectionHandler.error = "";
  graph.connectionHandler.mouseUp(null, {
    getCell: () => null,
    getEvent: () => ({ clientX: 60, clientY: 60 })
  });
  assert.equal(document.querySelector("#semantic-graph-edge-label").textContent, "listing — jobLocation → location");
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);
  dom.window.close();
});

test("holding an incompatible connector target reveals the custom relationship editor", async () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.rating = { types: ["AggregateRating"], expectation: "optional" };
  assert.equal(Compositions.relationshipOptions(["JobPosting"], "AggregateRating").length, 0);
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  const graph = FakeGraph.last;
  const source = graph.vertices.find((cell) => cell.semanticNodeAlias === "listing");
  const target = graph.vertices.find((cell) => cell.semanticNodeAlias === "rating");
  graph.connectionHandler.connecting = true;
  graph.connectionHandler.previous = { cell: source };
  const mouseEvent = {
    getCell: () => target,
    getEvent: () => ({ clientX: 50, clientY: 50 }),
    consume() {}
  };
  graph.connectionHandler.mouseMove(null, mouseEvent);
  assert.equal(document.querySelector("#semantic-custom-connection-cue").hidden, false);
  assert.match(document.querySelector("#semantic-custom-connection-cue").textContent, /Hold for custom relationship/);
  await new Promise((resolve) => setTimeout(resolve, 700));
  assert.equal(document.querySelector("#semantic-custom-connection-cue").classList.contains("dwell-ready"), true);
  graph.connectionHandler.mouseUp(null, mouseEvent);
  assert.equal(graph.connectionHandler.resetCalled, true);
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-editor").hidden, false);
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-target").value, "rating");
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-target").disabled, true);
  dom.window.close();
});

test("custom relationship fallback applies its edge and adapter-local vocabulary together", async () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.rating = { types: ["AggregateRating"], expectation: "optional" };
  const { dom, document, applied, appliedTerms } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  document.querySelector("#semantic-graph-create-custom-relationship").click();
  const target = document.querySelector("#semantic-graph-custom-relationship-target");
  target.value = "rating";
  target.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  document.querySelector("#semantic-graph-custom-relationship-term").value = "example:ratingSummary";
  document.querySelector("#semantic-graph-custom-relationship-description").value = "The rating summary associated with this job posting.";
  document.querySelector("#semantic-graph-custom-relationship-description").dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  document.querySelector("#semantic-graph-save-custom-relationship").click();
  assert.equal(document.querySelector("#semantic-graph-edge-label").textContent, "listing — example:ratingSummary → rating");
  document.querySelector("#semantic-graph-apply").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(applied.length, 1);
  assert.deepEqual(applied[0].edges.at(-1), { from: "listing", property: "example:ratingSummary", to: "rating", expectation: "optional" });
  assert.deepEqual(appliedTerms[0]["example:ratingSummary"].domainIncludes, ["JobPosting"]);
  assert.deepEqual(appliedTerms[0]["example:ratingSummary"].rangeIncludes, ["AggregateRating"]);
  dom.window.close();
});

test("toolbox searches Schema.org types, pins favorites, and creates a disconnected graph node", async () => {
  const { dom, document, stored } = setup();
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(document.querySelectorAll("#semantic-toolbox-favorite-list .semantic-toolbox-tile").length, 6);

  const search = document.querySelector("#semantic-toolbox-search-input");
  search.value = "Article";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 100));
  const result = Array.from(document.querySelectorAll("#semantic-toolbox-search-results .semantic-toolbox-tile"))
    .find((tile) => tile.dataset.id === "Article");
  assert.ok(result);
  result.querySelector(".semantic-toolbox-pin").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(stored[SemanticToolbox.STORAGE_KEY].favorites.at(-1).id, "Article");

  result.click();
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Article was added/);
  assert.equal(document.querySelector("#semantic-graph-apply").disabled, true);

  document.querySelector("#semantic-composition-graph-view").dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "Delete", bubbles: true }));
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);

  document.querySelector("#semantic-graph-center").click();
  assert.equal(document.querySelector("#semantic-composition-canvas").dataset.centered, "true");
  dom.window.close();
});

test("marks a nested relationship target as an evidence-backed variant slot", async () => {
  const composition = Compositions.singleType("ListItem");
  composition.nodes.item = { types: ["Thing"], expectation: "common" };
  composition.edges.push({ from: "listing", property: "item", to: "item", expectation: "common" });
  const { dom, document, block, applied } = setup(composition);
  block.variantAnalysis = {
    thresholds: { minScore: 5, minMargin: 2 },
    candidates: [
      { schemaType: "Article", evidence: [{ selector: ".article", weight: 8 }] },
      { schemaType: "JobPosting", evidence: [{ selector: ".job", weight: 8 }] }
    ]
  };
  document.querySelector("#open-semantic-graph").click();
  FakeGraph.last.selectCell(FakeGraph.last.vertices.find((cell) => cell.semanticNodeAlias === "item"));
  const slot = document.querySelector("#semantic-graph-node-variant-slot");
  assert.equal(document.querySelector("#semantic-graph-node-alias").textContent.startsWith("item"), true);
  assert.equal(document.querySelector("#semantic-graph-node-variant-types-label").hidden, true);
  slot.click();
  assert.equal(document.querySelector("#semantic-graph-node-variant-types-label").hidden, false);
  assert.equal(document.querySelectorAll("#semantic-graph-node-variant-type-list .semantic-variant-type-chip").length, 2);
  document.querySelector("#semantic-graph-node-variant-types").value = "Article, JobPosting";
  document.querySelector("#semantic-graph-update-node").click();
  document.querySelector("#semantic-graph-apply").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(applied[0].nodes.item.variants.candidates.map((candidate) => candidate.type), ["Article", "JobPosting"]);
  dom.window.close();
});

test("variant authoring validation errors use Attention instead of the graph footer", () => {
  const composition = Compositions.singleType("ListItem");
  composition.nodes.item = { types: ["Thing"], expectation: "common" };
  composition.edges.push({ from: "listing", property: "item", to: "item", expectation: "common" });
  const { dom, document } = setup(composition, null, { withAttention: true });
  document.querySelector("#open-semantic-graph").click();
  FakeGraph.last.selectCell(FakeGraph.last.vertices.find((cell) => cell.semanticNodeAlias === "item"));
  document.querySelector("#semantic-graph-node-variant-slot").click();
  document.querySelector("#semantic-graph-node-variant-types").value = "Article, Product, JobPosting, Person, Organization, Event";
  document.querySelector("#semantic-graph-update-node").click();

  assert.equal(document.querySelector("#semantic-graph-status").textContent, "");
  assert.equal(document.querySelector("#site2json-attention-button").hidden, false);
  assert.equal(document.querySelector("#site2json-attention-count").textContent, "1");
  assert.match(document.querySelector("#site2json-attention-list").textContent, /between 1 and 5/i);
  assert.equal(document.querySelector("#semantic-graph-node-variant-types").getAttribute("aria-invalid"), "true");
  assert.equal(document.querySelector("#semantic-graph-node-update-status").textContent, "");
  assert.match(document.querySelector("#semantic-graph-node-variant-types").value, /Event/);
  dom.window.close();
});

test("favorite tiles reveal a drag-to-trash target and support keyboard removal", async () => {
  const { dom, document, stored } = setup();
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const tile = document.querySelector('#semantic-toolbox-favorite-list [data-id="Person"]');
  assert.equal(tile.querySelector("button"), null);

  const values = new Map();
  const transfer = {
    types: ["application/x-site2json-semantic-tool"],
    effectAllowed: "",
    dropEffect: "",
    setData(type, value) { values.set(type, value); },
    getData(type) { return values.get(type) || ""; }
  };
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const trash = document.querySelector("#semantic-toolbox-trash");
  assert.equal(trash.hidden, false);
  trash.dispatchEvent(dragEvent(dom.window, "dragover", transfer));
  assert.equal(trash.classList.contains("toolbox-drop-active"), true);
  trash.dispatchEvent(dragEvent(dom.window, "drop", transfer));
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(trash.hidden, true);
  assert.equal(stored[SemanticToolbox.STORAGE_KEY].favorites.some((item) => item.id === "Person"), false);

  const organization = document.querySelector('#semantic-toolbox-favorite-list [data-id="Organization"]');
  organization.dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "Delete", bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(stored[SemanticToolbox.STORAGE_KEY].favorites.some((item) => item.id === "Organization"), false);
  dom.window.close();
});

test("favorite reordering previews and honors the indicated insertion side", async () => {
  const { dom, document, stored } = setup();
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const source = document.querySelector('#semantic-toolbox-favorite-list [data-id="Person"]');
  const target = document.querySelector('#semantic-toolbox-favorite-list [data-id="Organization"]');
  target.getBoundingClientRect = () => ({ top: 0, bottom: 60, height: 60, left: 0, right: 60, width: 60 });
  const values = new Map();
  const transfer = {
    types: ["application/x-site2json-semantic-tool"],
    effectAllowed: "",
    dropEffect: "",
    setData(type, value) { values.set(type, value); },
    getData(type) { return values.get(type) || ""; }
  };

  source.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const dock = document.querySelector("#semantic-toolbox-favorites");
  dock.dispatchEvent(dragEvent(dom.window, "dragenter", transfer));
  assert.equal(dock.classList.contains("toolbox-drop-active"), true);
  target.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientY: 50 }));
  assert.equal(target.classList.contains("drop-after"), true);
  target.dispatchEvent(dragEvent(dom.window, "dragleave", transfer, { relatedTarget: source }));
  assert.equal(dock.classList.contains("toolbox-drop-active"), true);
  target.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientY: 50 }));
  target.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientY: 50 }));
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(stored[SemanticToolbox.STORAGE_KEY].favorites.slice(0, 3).map((item) => item.id), ["Organization", "Person", "JobPosting"]);
  assert.equal(document.querySelector("#semantic-toolbox-favorite-list .drop-after"), null);
  assert.equal(dock.classList.contains("toolbox-drop-active"), false);
  dom.window.close();
});

test("favorite dock exposes and applies insertion gaps at both list ends", async () => {
  const { dom, document, stored } = setup();
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const dock = document.querySelector("#semantic-toolbox-favorites");
  const list = document.querySelector("#semantic-toolbox-favorite-list");
  const values = new Map();
  const transfer = {
    types: ["application/x-site2json-semantic-tool"], effectAllowed: "", dropEffect: "",
    setData(type, value) { values.set(type, value); }, getData(type) { return values.get(type) || ""; }
  };
  const placeTiles = () => Array.from(list.querySelectorAll(".semantic-toolbox-tile")).forEach((tile, index) => {
    tile.getBoundingClientRect = () => ({ top: index * 70, bottom: index * 70 + 60, height: 60, left: 0, right: 60, width: 60 });
  });

  placeTiles();
  list.querySelector('[data-id="Person"]').dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  list.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientY: 1000 }));
  assert.equal(list.lastElementChild.classList.contains("drop-after"), true);
  dock.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientY: 1000 }));
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(stored[SemanticToolbox.STORAGE_KEY].favorites.at(-1).id, "Person");

  values.clear();
  placeTiles();
  list.querySelector('[data-id="Person"]').dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  list.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientY: -10 }));
  assert.equal(list.firstElementChild.classList.contains("drop-before"), true);
  dock.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientY: -10 }));
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(stored[SemanticToolbox.STORAGE_KEY].favorites[0].id, "Person");
  dom.window.close();
});

function stubTargetBounds(graph, alias, rect) {
  const vertex = graph.vertices.find((cell) => cell.semanticNodeAlias === alias);
  graph.getView().getState(vertex).shape.node.getBoundingClientRect = () => rect;
}

function toolboxDragTransfer() {
  const values = new Map();
  return {
    types: ["application/x-site2json-semantic-tool"],
    effectAllowed: "", dropEffect: "",
    setData(type, value) { values.set(type, value); },
    getData(type) { return values.get(type) || ""; }
  };
}

test("dropping a favorite type tile onto an existing node with one valid relationship connects it directly", async () => {
  const { dom, document } = setup(Compositions.singleType("JobPosting"));
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "listing", { left: 20, right: 120, top: 30, bottom: 100 });

  const tile = document.querySelector('#semantic-toolbox-favorite-list [data-id="Place"]');
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientX: 60, clientY: 60 }));

  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);
  assert.equal(Number.isInteger(FakeGraph.last.getSelectionCell()?.semanticEdgeIndex), true, "the newly created connector should remain visibly selected");
  assert.equal(document.querySelector("#semantic-graph-edge-editor").hidden, false);
  const place = FakeGraph.last.vertices.find((cell) => cell.semanticNodeAlias === "place");
  const listing = FakeGraph.last.vertices.find((cell) => cell.semanticNodeAlias === "listing");
  assert.notDeepEqual(place.position, listing.position);
  dom.window.close();
});

test("dropping Product on a JobPosting plus Demand root creates itemOffered without overlapping the root", async () => {
  const composition = Compositions.preset("site2json:freelance-opportunity");
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "listing", { left: 20, right: 120, top: 30, bottom: 100 });

  const tile = document.querySelector('#semantic-toolbox-favorite-list [data-id="Product"]');
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientX: 60, clientY: 60 }));
  assert.equal(graph.getView().getState(graph.vertices.find((cell) => cell.semanticNodeAlias === "listing")).shape.node.classList.contains("semantic-connect-valid"), true);
  canvas.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientX: 60, clientY: 60 }));

  const rendered = FakeGraph.last;
  const product = rendered.vertices.find((cell) => cell.semanticNodeAlias === "product");
  const listing = rendered.vertices.find((cell) => cell.semanticNodeAlias === "listing");
  assert.notDeepEqual(product.position, listing.position);
  assert.equal(rendered.edges.some((edge) => edge.source.semanticNodeAlias === "listing" && edge.target.semanticNodeAlias === "product" && edge.value === "itemOffered"), true);
  assert.match(document.querySelector("#semantic-graph-status").textContent, /Valid connected semantic graph/);
  dom.window.close();
});

test("dropping a favorite type tile onto an existing node with several relationships opens the picker pre-targeted", async () => {
  const composition = Compositions.singleType("Person");
  composition.nodes.organization = { types: ["Organization"], expectation: "common" };
  composition.edges.push({ from: "listing", property: "affiliation", to: "organization", expectation: "common" });
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "organization", { left: 20, right: 120, top: 30, bottom: 100 });

  const tile = document.querySelector('#semantic-toolbox-favorite-list [data-id="Person"]');
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientX: 60, clientY: 60 }));
  assert.equal(graph.getView().getState(graph.vertices.find((cell) => cell.semanticNodeAlias === "organization")).shape.node.classList.contains("semantic-connect-choice"), true);
  assert.equal(document.querySelector("#semantic-custom-connection-cue").hidden, false);
  assert.match(document.querySelector("#semantic-custom-connection-cue").textContent, /Choose relationship/);
  canvas.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientX: 60, clientY: 60 }));

  const property = document.querySelector("#semantic-graph-relation-property");
  assert.equal(document.querySelector("#semantic-graph-connect-details").open, true);
  const choices = Array.from(property.options, (option) => option.value).filter(Boolean);
  assert.deepEqual(choices, Compositions.structuralRelationshipOptions(["Organization"], "Person").map((option) => option.property));
  assert.match(document.querySelector("#semantic-graph-status").textContent, /valid relationships connect organization to person/);
  assert.equal(document.activeElement, property);
  assert.equal(property.value, choices[0]);
  assert.equal(document.querySelector("#semantic-graph-add-relationship").disabled, false);
  assert.equal(FakeGraph.last.edges.some((edge) => edge.semanticPendingConnection && edge.source.semanticNodeAlias === "organization" && edge.target.semanticNodeAlias === "person"), true);
  property.value = choices[0];
  property.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  assert.equal(document.querySelector("#semantic-graph-relation-target").value, "person");
  document.querySelector("#semantic-graph-add-relationship").click();
  assert.equal(FakeGraph.last.edges.some((edge) => edge.semanticPendingConnection), false);
  assert.equal(FakeGraph.last.edges.some((edge) => edge.source.semanticNodeAlias === "organization" && edge.target.semanticNodeAlias === "person"), true);
  dom.window.close();
});

test("the drop still honors the hovered target even if the release coordinates drift off the node", async () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.location = { types: ["Place"], expectation: "common" };
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "location", { left: 20, right: 120, top: 30, bottom: 100 });

  const tile = document.querySelector('#semantic-toolbox-favorite-list [data-id="Place"]');
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientX: 60, clientY: 60 }));
  canvas.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientX: 900, clientY: 900 }));

  assert.match(document.querySelector("#semantic-graph-status").textContent, /valid relationships connect location to place/);
  dom.window.close();
});

test("dropping a favorite type tile onto an incompatible node leaves it disconnected without dwelling", async () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.amount = { types: ["MonetaryAmount"], expectation: "optional" };
  assert.equal(Compositions.relationshipOptions(["Place"], "MonetaryAmount").length, 0);
  assert.equal(Compositions.relationshipOptions(["MonetaryAmount"], "Place").length, 0);
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "amount", { left: 20, right: 120, top: 30, bottom: 100 });

  const tile = document.querySelector('#semantic-toolbox-favorite-list [data-id="Place"]');
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientX: 60, clientY: 60 }));

  assert.match(document.querySelector("#semantic-graph-status").textContent, /Place was added as place\. Connect it to the root graph/);
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-editor").hidden, true);
  dom.window.close();
});

test("dwelling a dragged type over an incompatible node opens the custom relationship editor pre-targeted", async () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.amount = { types: ["MonetaryAmount"], expectation: "optional" };
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "amount", { left: 20, right: 120, top: 30, bottom: 100 });

  const tile = document.querySelector('#semantic-toolbox-favorite-list [data-id="Place"]');
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientX: 60, clientY: 60 }));
  assert.equal(document.querySelector("#semantic-custom-connection-cue").hidden, false);
  await new Promise((resolve) => setTimeout(resolve, 700));
  assert.equal(document.querySelector("#semantic-custom-connection-cue").classList.contains("dwell-ready"), true);

  canvas.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientX: 60, clientY: 60 }));
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-editor").hidden, false);
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-target").value, "place");
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-target").disabled, true);
  dom.window.close();
});

test("a node with an unrecognized custom type never leaks the packaged catalog's Thing fallback as a valid relationship", () => {
  assert.ok(Compositions.relationshipOptions(["TotallyMadeUpType"], "Person").some((option) => option.property === "owner"));
  const composition = {
    id: "test:mystery", label: "Mystery test", kind: "composition", root: "listing",
    nodes: {
      listing: { types: ["TotallyMadeUpType"], expectation: "core" },
      buyer: { types: ["Person"], expectation: "optional" }
    },
    edges: [],
    priorities: { listing: [], buyer: [] }
  };
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  const view = document.querySelector("#semantic-composition-graph-view");
  assert.equal(document.querySelector("#semantic-graph-node-alias").textContent, "listing · root");

  view.dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "c", bubbles: true }));
  assert.match(document.querySelector("#semantic-graph-status").textContent, /listing: buyer has no Schema\.org relationship/);
  view.dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-editor").hidden, false);
  assert.equal(document.querySelector("#semantic-graph-custom-relationship-target").value, "buyer");
  dom.window.close();
});

test("clicking the custom type tool creates a disconnected adapter-local type node", async () => {
  const { dom, document, applied } = setup();
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  document.querySelector("#semantic-toolbox-custom-type-tool").click();
  assert.equal(document.querySelector("#semantic-graph-custom-type-editor").hidden, false);
  assert.equal(document.querySelector("#semantic-graph-custom-type-relationship").hidden, true);

  document.querySelector("#semantic-graph-custom-type-name").value = "Editor";
  document.querySelector("#semantic-graph-custom-type-name").dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  document.querySelector("#semantic-graph-custom-type-description").value = "A person who edits listings.";
  document.querySelector("#semantic-graph-custom-type-description").dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  assert.equal(document.querySelector("#semantic-graph-save-custom-type").disabled, false);
  document.querySelector("#semantic-graph-save-custom-type").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(document.querySelector("#semantic-graph-custom-type-editor").hidden, true);
  assert.match(document.querySelector("#semantic-graph-status").textContent, /example:Editor was saved to the Semantic Library and added as editor/);
  assert.equal(document.querySelector("#semantic-graph-apply").disabled, true);

  document.querySelector("#semantic-composition-graph-view").dispatchEvent(new dom.window.KeyboardEvent("keydown", { key: "Delete", bubbles: true }));
  document.querySelector("#semantic-graph-apply").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(applied.length, 1);
  dom.window.close();
});

test("dropping the custom type tool onto an existing node opens the form with the relationship pre-attached", async () => {
  const { dom, document, applied, appliedTerms } = setup(Compositions.singleType("JobPosting"));
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "listing", { left: 20, right: 120, top: 30, bottom: 100 });

  const tile = document.querySelector("#semantic-toolbox-custom-type-tool");
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientX: 60, clientY: 60 }));
  canvas.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientX: 60, clientY: 60 }));

  assert.equal(document.querySelector("#semantic-graph-custom-type-editor").hidden, false);
  assert.equal(document.querySelector("#semantic-graph-custom-type-relationship").hidden, false);
  assert.equal(document.querySelector("#semantic-graph-custom-type-target").value, "listing");

  document.querySelector("#semantic-graph-custom-type-name").value = "Editor";
  document.querySelector("#semantic-graph-custom-type-name").dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  assert.equal(document.querySelector("#semantic-graph-custom-type-relationship-term").value, "example:editor");
  document.querySelector("#semantic-graph-custom-type-description").value = "A person who edits listings.";
  document.querySelector("#semantic-graph-custom-type-description").dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  document.querySelector("#semantic-graph-custom-type-relationship-description").value = "The editor of this listing.";
  document.querySelector("#semantic-graph-custom-type-relationship-description").dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  assert.equal(document.querySelector("#semantic-graph-save-custom-type").disabled, false);
  document.querySelector("#semantic-graph-save-custom-type").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.match(document.querySelector("#semantic-graph-status").textContent, /Added example:Editor as editor, connected to listing/);
  assert.equal(document.querySelector("#semantic-graph-apply").disabled, false);
  document.querySelector("#semantic-graph-apply").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(applied.length, 1);
  assert.equal(applied[0].nodes.editor.types[0], "example:Editor");
  assert.equal(applied[0].edges.at(-1).property, "example:editor");
  assert.equal(appliedTerms[0]["example:Editor"].kind, "type");
  assert.equal(appliedTerms[0]["example:editor"].kind, "relationship");
  dom.window.close();
});

test("dragging the custom type tool over any node marks it invalid without dwelling toward a schema match", async () => {
  const composition = Compositions.singleType("Person");
  composition.nodes.organization = { types: ["Organization"], expectation: "common" };
  const { dom, document } = setup(composition);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "organization", { left: 20, right: 120, top: 30, bottom: 100 });

  const tile = document.querySelector("#semantic-toolbox-custom-type-tool");
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "dragover", transfer, { clientX: 60, clientY: 60 }));

  const vertex = graph.vertices.find((cell) => cell.semanticNodeAlias === "organization");
  const node = graph.getView().getState(vertex).shape.node;
  assert.equal(node.classList.contains("semantic-connect-invalid"), true);
  assert.equal(node.classList.contains("semantic-connect-valid"), false);
  assert.equal(document.querySelector("#semantic-custom-connection-cue").hidden, true);
  dom.window.close();
});

test("a custom type created in the graph becomes searchable and reusable with its definition", async () => {
  const { dom, document } = setup();
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  document.querySelector("#semantic-toolbox-custom-type-tool").click();
  document.querySelector("#semantic-graph-custom-type-name").value = "Editor";
  document.querySelector("#semantic-graph-custom-type-name").dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  document.querySelector("#semantic-graph-custom-type-description").value = "A person who edits listings.";
  document.querySelector("#semantic-graph-custom-type-description").dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  document.querySelector("#semantic-graph-save-custom-type").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  const search = document.querySelector("#semantic-toolbox-search-input");
  search.value = "edits listings";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 120));
  const result = document.querySelector('#semantic-toolbox-search-results [data-kind="customType"][data-id="example:Editor"]');
  assert.ok(result, "the saved custom type was not returned by graph search");
  result.click();
  assert.equal(FakeGraph.last.vertices.filter((cell) => cell.value.includes("example:Editor")).length, 2);
  dom.window.close();
});

test("package-isolated canonical types stay separate in search and deduplicate only when materialized", async () => {
  let imported = SemanticToolbox.addCustomType(SemanticToolbox.normalize(null), {
    id: "import:alpha:customType:1",
    termId: "foaf:Person",
    label: "Person",
    description: "A person.",
    definition: {
      kind: "type", description: "A person.", valueType: "foaf:Person", cardinality: "one", example: "Person",
      canonicalUri: "http://xmlns.com/foaf/0.1/Person", supers: ["http://xmlns.com/foaf/0.1/Agent"]
    },
    provenance: { source: { id: "lov" }, canonicalUri: "http://xmlns.com/foaf/0.1/Person", vocabulary: { prefix: "foaf" }, importId: "import:alpha", bundle: { id: "import:alpha", label: "FOAF people bundle" } }
  });
  imported = SemanticToolbox.addCustomType(imported, {
    id: "import:beta:customType:1",
    termId: "foaf:Person",
    label: "Person",
    description: "A person.",
    definition: {
      kind: "type", description: "A person.", valueType: "foaf:Person", cardinality: "one", example: "Person",
      canonicalUri: "http://xmlns.com/foaf/0.1/Person", supers: ["http://xmlns.com/foaf/0.1/Agent"]
    },
    provenance: { source: { id: "lov" }, canonicalUri: "http://xmlns.com/foaf/0.1/Person", vocabulary: { prefix: "foaf" }, importId: "import:beta", bundle: { id: "import:beta", label: "CRM people bundle" } }
  });
  const { dom, document } = setup(Compositions.singleType("Organization"), imported);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const search = document.querySelector("#semantic-toolbox-search-input");
  search.value = "foaf:Person";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 140));
  const results = [...document.querySelectorAll('#semantic-toolbox-search-results [data-kind="customType"]')];
  assert.equal(results.length, 2, "each imported package should remain a separate graph choice");
  assert.match(results[0].parentElement.textContent, /FOAF people bundle|CRM people bundle/);
  assert.match(document.querySelector("#semantic-toolbox-search-results").textContent, /FOAF people bundle/);
  assert.match(document.querySelector("#semantic-toolbox-search-results").textContent, /CRM people bundle/);
  results[0].click();
  results[1].click();
  assert.equal(FakeGraph.last.vertices.filter((cell) => cell.value.includes("example:FoafPerson")).length, 2, "both package choices should materialize through one adapter-local semantic term");
  assert.match(document.querySelector("#semantic-graph-status").textContent, /added as example:FoafPerson/);
  dom.window.close();
});

test("a normally selected node can be saved as a one-node pattern", async () => {
  const { dom, document, stored } = setup(Compositions.preset("site2json:freelance-opportunity"));
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(document.querySelector("#semantic-graph-save-pattern").disabled, false);
  document.querySelector("#semantic-graph-save-pattern").click();
  assert.equal(document.querySelector("#semantic-graph-save-pattern-editor").hidden, false);
  assert.match(document.querySelector("#semantic-graph-save-pattern-summary").textContent, /1 node, 0 relationships selected, rooted at listing/);

  document.querySelector("#semantic-graph-save-pattern-name").value = "Listing root";
  document.querySelector("#semantic-graph-confirm-save-pattern").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  const saved = Object.values(stored[SemanticToolbox.STORAGE_KEY].patterns);
  assert.equal(saved.length, 1);
  assert.equal(saved[0].root, "listing");
  assert.deepEqual(Object.keys(saved[0].nodes), ["listing"]);
  assert.equal(saved[0].edges.length, 0);
  dom.window.close();
});

test("ctrl-clicking connected nodes builds a pattern selection that saves to the toolbox", async () => {
  const { dom, document, stored } = setup(Compositions.preset("site2json:freelance-opportunity"));
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "buyer", { left: 0, right: 100, top: 0, bottom: 60 });
  stubTargetBounds(graph, "buyerRating", { left: 0, right: 100, top: 200, bottom: 260 });
  const canvas = document.querySelector("#semantic-composition-canvas");

  assert.equal(document.querySelector("#semantic-graph-save-pattern").disabled, false, "the ordinary root selection is already saveable");
  canvas.dispatchEvent(new dom.window.MouseEvent("mousedown", { bubbles: true, clientX: 50, clientY: 30, ctrlKey: true }));
  assert.equal(document.querySelector("#semantic-graph-save-pattern").disabled, false);
  canvas.dispatchEvent(new dom.window.MouseEvent("mousedown", { bubbles: true, clientX: 50, clientY: 230, ctrlKey: true }));

  const buyerVertex = graph.vertices.find((cell) => cell.semanticNodeAlias === "buyer");
  assert.equal(graph.getView().getState(buyerVertex).shape.node.classList.contains("semantic-pattern-selected"), true);

  document.querySelector("#semantic-graph-save-pattern").click();
  assert.equal(document.querySelector("#semantic-graph-save-pattern-editor").hidden, false);
  assert.match(document.querySelector("#semantic-graph-save-pattern-summary").textContent, /2 nodes, 1 relationship selected, rooted at buyer/);

  document.querySelector("#semantic-graph-save-pattern-name").value = "Marketplace buyer";
  document.querySelector("#semantic-graph-confirm-save-pattern").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(document.querySelector("#semantic-graph-save-pattern-editor").hidden, true);
  assert.equal(document.querySelector("#semantic-graph-save-pattern").disabled, false, "the current graph node remains a valid one-node pattern");
  const saved = Object.values(stored[SemanticToolbox.STORAGE_KEY].patterns);
  assert.equal(saved.length, 1);
  assert.equal(saved[0].label, "Marketplace buyer");
  assert.equal(saved[0].root, "buyer");
  assert.deepEqual(Object.keys(saved[0].nodes).sort(), ["buyer", "buyerRating"]);
  assert.equal(saved[0].edges.length, 1);
  assert.equal(saved[0].edges[0].property, "aggregateRating");
  dom.window.close();
});

test("ctrl-clicking the same node twice clears the explicit subgraph selection", async () => {
  const { dom, document } = setup(Compositions.preset("site2json:freelance-opportunity"));
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "buyer", { left: 0, right: 100, top: 0, bottom: 60 });
  const canvas = document.querySelector("#semantic-composition-canvas");

  canvas.dispatchEvent(new dom.window.MouseEvent("mousedown", { bubbles: true, clientX: 50, clientY: 30, ctrlKey: true }));
  assert.equal(document.querySelector("#semantic-graph-save-pattern").disabled, false);
  canvas.dispatchEvent(new dom.window.MouseEvent("mousedown", { bubbles: true, clientX: 50, clientY: 30, ctrlKey: true }));
  assert.equal(document.querySelector("#semantic-graph-save-pattern").disabled, false, "ordinary node selection remains available after the explicit set is cleared");
  const buyerVertex = graph.vertices.find((cell) => cell.semanticNodeAlias === "buyer");
  assert.equal(graph.getView().getState(buyerVertex).shape.node.classList.contains("semantic-pattern-selected"), false);
  dom.window.close();
});

function seedPattern(record) {
  return SemanticToolbox.addPattern(SemanticToolbox.normalize(null), record);
}

const MARKETPLACE_BUYER_PATTERN = {
  id: "pattern:marketplace-buyer", label: "Marketplace buyer", description: "A buyer with an aggregate rating.",
  root: "buyer",
  nodes: {
    buyer: { types: ["Organization"], expectation: "core" },
    rating: { types: ["AggregateRating"], expectation: "optional" }
  },
  edges: [{ from: "buyer", property: "aggregateRating", to: "rating", expectation: "optional" }],
  terms: {}
};

test("search finds saved patterns alongside Schema.org types and can pin them to favorites", async () => {
  const { dom, document, stored } = setup();
  stored[SemanticToolbox.STORAGE_KEY] = seedPattern(MARKETPLACE_BUYER_PATTERN);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  const search = document.querySelector("#semantic-toolbox-search-input");
  search.value = "buyer";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 100));

  const result = Array.from(document.querySelectorAll("#semantic-toolbox-search-results .semantic-toolbox-tile"))
    .find((tile) => tile.dataset.kind === "pattern");
  assert.ok(result);
  assert.equal(result.querySelector(".semantic-toolbox-tile-label").textContent, "Marketplace buyer");

  result.querySelector(".semantic-toolbox-pin").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(stored[SemanticToolbox.STORAGE_KEY].favorites.at(-1).id, "pattern:marketplace-buyer");
  dom.window.close();
});

test("clicking a pattern tile inserts its whole subgraph as one unit, remapping alias collisions", async () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.buyer = { types: ["Person"], expectation: "optional" };
  const { dom, document, stored } = setup(composition);
  stored[SemanticToolbox.STORAGE_KEY] = seedPattern(MARKETPLACE_BUYER_PATTERN);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  const search = document.querySelector("#semantic-toolbox-search-input");
  search.value = "marketplace";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 100));
  const result = document.querySelector('#semantic-toolbox-search-results [data-kind="pattern"]');
  result.click();

  assert.match(document.querySelector("#semantic-graph-status").textContent, /“Marketplace buyer” was added as buyer2 \(2 nodes\)\. Connect it to the root graph/);
  const graph = FakeGraph.last;
  const insertedRoot = graph.vertices.find((cell) => cell.semanticNodeAlias === "buyer2");
  const insertedRating = graph.vertices.find((cell) => cell.semanticNodeAlias === "rating");
  assert.ok(insertedRoot);
  assert.ok(insertedRating);
  assert.equal(insertedRoot.value.includes("Organization"), true);
  assert.equal(document.querySelector("#semantic-graph-node-alias").textContent, "buyer2");
  assert.equal(document.querySelector("#semantic-graph-node-expectation").value, "common");
  dom.window.close();
});

test("dropping a pattern onto an existing node chains the same relationship picker as a single type tile", async () => {
  const { dom, document, stored } = setup(Compositions.singleType("Person"));
  stored[SemanticToolbox.STORAGE_KEY] = seedPattern(MARKETPLACE_BUYER_PATTERN);
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const graph = FakeGraph.last;
  stubTargetBounds(graph, "listing", { left: 20, right: 120, top: 30, bottom: 100 });

  const search = document.querySelector("#semantic-toolbox-search-input");
  search.value = "marketplace";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 100));
  const tile = document.querySelector('#semantic-toolbox-search-results [data-kind="pattern"]');
  const transfer = toolboxDragTransfer();
  tile.dispatchEvent(dragEvent(dom.window, "dragstart", transfer));
  const canvas = document.querySelector("#semantic-composition-canvas");
  canvas.dispatchEvent(dragEvent(dom.window, "drop", transfer, { clientX: 60, clientY: 60 }));

  const property = document.querySelector("#semantic-graph-relation-property");
  const choices = Array.from(property.options, (option) => option.value).filter(Boolean);
  assert.deepEqual(choices, Compositions.structuralRelationshipOptions(["Person"], "Organization").map((option) => option.property));
  assert.match(document.querySelector("#semantic-graph-status").textContent, /valid relationships connect listing to buyer/);
  dom.window.close();
});

test("inserting a pattern whose vocabulary term conflicts with an already-inserted pattern is blocked with a clear error", async () => {
  const { dom, document, stored } = setup(Compositions.singleType("JobPosting"));
  const patternA = {
    id: "pattern:a", label: "Pattern A", root: "buyer",
    nodes: { buyer: { types: ["Organization"], expectation: "core" } }, edges: [],
    terms: { "example:rating": { description: "A rating field.", valueType: "Text", cardinality: "one", example: "5 stars", kind: "field" } }
  };
  const patternB = {
    id: "pattern:b", label: "Pattern B", root: "seller",
    nodes: { seller: { types: ["Organization"], expectation: "core" } }, edges: [],
    terms: { "example:rating": { description: "A different meaning.", valueType: "Number", cardinality: "one", example: 5, kind: "field" } }
  };
  let toolboxSeed = SemanticToolbox.addPattern(SemanticToolbox.normalize(null), patternA);
  toolboxSeed = SemanticToolbox.addPattern(toolboxSeed, patternB);
  stored[SemanticToolbox.STORAGE_KEY] = toolboxSeed;
  document.querySelector("#open-semantic-graph").click();
  await new Promise((resolve) => setTimeout(resolve, 0));

  const search = document.querySelector("#semantic-toolbox-search-input");
  search.value = "pattern";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 100));
  const tiles = document.querySelectorAll('#semantic-toolbox-search-results [data-kind="pattern"]');
  const tileA = [...tiles].find((tile) => tile.dataset.id === "pattern:a");
  const tileB = [...tiles].find((tile) => tile.dataset.id === "pattern:b");
  tileA.click();
  assert.equal(FakeGraph.last.vertices.some((cell) => cell.semanticNodeAlias === "buyer"), true);

  tileB.click();
  assert.match(document.querySelector("#semantic-graph-status").textContent, /already defined with a different meaning/);
  assert.equal(FakeGraph.last.vertices.some((cell) => cell.semanticNodeAlias === "seller"), false);
  dom.window.close();
});
