"use strict";

const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Dsl = require("../extension/core/dsl");
const SelectorCandidates = require("../extension/editor/selector-candidates");
const FixtureCapture = require("../extension/editor/fixture-capture");
const AdapterDefinition = require("../extension/editor/adapter-definition");
const { bridgeCaptureFixture } = require("../extension/editor/sidebar-page-bridge");

function definition() {
  return {
    adapter: "fixture",
    version: 1,
    dslVersion: 1,
    namespace: "https://example.com/fixture#",
    hosts: ["example.com"],
    entities: {
      Listing: {
        schemaType: "Thing",
        identity: { canonicalUrl: { selectors: [".link@href"], transform: ["absoluteUrl", "stripQuery"] } },
        fields: {
          title: { selectors: [".title"], transform: ["text", "trim"] },
          image: { selectors: [".image@src"], transform: ["absoluteUrl", "stripQuery"] }
        }
      }
    },
    pages: [{
      id: "results",
      match: { host: ["example.com"], path: [{ mode: "exact", value: "/results" }] },
      pageType: "CollectionPage",
      blocks: [{
        entity: "Listing", scope: ".result-card[data-kind='listing']", arity: "many", role: "collection", fidelity: "summary", require: ["title"]
      }]
    }]
  };
}

function rendered({ secret = "Alice Person", generated = "Button__button__x7Ea9", remote = "https://private.example/alice" } = {}) {
  return new JSDOM(`<!doctype html><html><head><title>${secret}</title><style>.secret{color:red}</style><script>steal()</script></head><body class="unused ${generated}">
    <!-- private comment --><main data-testid="search-results" data-session="private-token">
      <article class="result-card ${generated}" data-kind="listing" onclick="steal()">
        <a class="link unused" href="${remote}"><h2 class="title">${secret}</h2></a>
        <img class="image" src="${remote}/photo.png" alt="${secret}">
        <input value="private form value" checked>
      </article>
    </main></body></html>`, { url: "https://example.com/results", runScripts: "outside-only" });
}

test("captures deterministic topology while removing content, executable code, remote URLs, and generated hooks", () => {
  const first = rendered();
  const second = rendered({ secret: "Bob Other", generated: "Button__button__q2Lm4", remote: "https://other.example/bob" });
  const a = FixtureCapture.capture(first.window.document, definition(), definition().pages[0]);
  const b = FixtureCapture.capture(second.window.document, definition(), definition().pages[0]);
  assert.equal(a.format, "site2json-scrubbed-html-v1");
  assert.equal(a.html, b.html);
  assert.match(a.html, /class="result-card"/);
  assert.match(a.html, /data-kind="listing"/);
  assert.match(a.html, /class="link" href="#"/);
  assert.match(a.html, /class="image" src="#"/);
  assert.match(a.html, /data-testid="search-results"/);
  assert.doesNotMatch(a.html, /Alice|Bob|private|Button__button|https?:|<script|<style|onclick|value=|checked/);
  first.window.close();
  second.window.close();
});

test("fixture metadata is strict DSL data and survives the adapter editor round trip", () => {
  const fixture = {
    format: FixtureCapture.FORMAT,
    source: "fixture-results.fixture.html",
    digest: `sha256:${"a".repeat(64)}`,
    bytes: 123,
    capturedAt: "2026-08-11T20:00:00.000Z"
  };
  const configured = definition();
  configured.pages[0].fixture = fixture;
  assert.doesNotThrow(() => Dsl.validateDefinition(configured));
  const invalid = structuredClone(configured);
  invalid.pages[0].fixture.digest = "sha256:not-a-digest";
  assert.throws(() => Dsl.validateDefinition(invalid), /SHA-256/);

  const editor = AdapterDefinition.editorStateFromDefinition(configured, "https://example.com/results");
  assert.deepEqual(editor.fixture, fixture);
  const rebuilt = AdapterDefinition.buildDraftDefinition({
    adapterId: "fixture", namespace: configured.namespace, pageUrl: editor.pageUrl,
    pageId: editor.pageId, pageType: editor.pageType, fixture: editor.fixture,
    blocks: editor.blocks, customTerms: editor.customTerms, version: editor.version
  });
  assert.deepEqual(rebuilt.pages[0].fixture, fixture);
});

test("the inspected-page bridge captures the matching rendered page through validated DSL", () => {
  const dom = rendered();
  dom.window.Site2JsonDsl = Dsl;
  dom.window.Site2JsonSelectorCandidates = SelectorCandidates;
  dom.window.Site2JsonFixtureCapture = FixtureCapture;
  const capture = dom.window.eval(`(${bridgeCaptureFixture.toString()})`);
  const result = capture({ definition: definition() });
  assert.equal(result.ok, true);
  assert.equal(result.pageId, "results");
  assert.equal(result.bytes, Buffer.byteLength(result.html));
  assert.match(createHash("sha256").update(result.html).digest("hex"), /^[a-f0-9]{64}$/);
  dom.window.close();
});
