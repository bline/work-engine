"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const AdapterDefinition = require("../extension/editor/adapter-definition");

function baseArgs(overrides = {}) {
  return {
    adapterId: "example",
    namespace: "https://site2json.dev/ns/example#",
    pageUrl: "https://www.example.com/search/jobs",
    pageId: "search-results",
    pageType: "SearchResultsPage",
    entityName: "JobPosting",
    schemaType: "JobPosting",
    scope: "[data-test=\"job-tile\"]",
    identityField: "url",
    fields: [
      { name: "url", selector: "h2 a", attribute: "href", kind: "url", multiple: false, identity: true },
      { name: "title", selector: "h2 a", attribute: null, kind: "text", multiple: false },
      { name: "skills", selector: "[data-test='token']", attribute: null, kind: "text", multiple: true }
    ],
    requireFields: ["title"],
    ...overrides
  };
}

test("builds a definition that the production DSL validator accepts", () => {
  const definition = AdapterDefinition.buildDraftDefinition(baseArgs());
  const result = AdapterDefinition.validateDraft(definition);
  assert.equal(result.ok, true);
  assert.equal(result.definition.adapter, "example");
  assert.equal(result.definition.hosts[0], "www.example.com");
  assert.equal(result.definition.pages[0].match.path[0].value, "/search/jobs");
  assert.deepEqual(result.definition.pages[0].blocks[0].require, ["title"]);
});

test("identity field uses url transforms and the declared attribute suffix", () => {
  const definition = AdapterDefinition.buildDraftDefinition(baseArgs());
  assert.deepEqual(definition.entities.JobPosting.identity, { field: "url" });
  const identity = definition.entities.JobPosting.fields.url;
  assert.deepEqual(identity.selectors, ["h2 a@href"]);
  assert.deepEqual(identity.transform, ["absoluteUrl", "stripQuery"]);
});

test("text fields use text/trim and multiple is only set when true", () => {
  const args = baseArgs();
  args.fields[1].corroboration = {
    version: 1,
    confidence: "strong",
    signals: [{ kind: "lexical", strength: "strong", detail: "title matches title" }]
  };
  const definition = AdapterDefinition.buildDraftDefinition(args);
  const title = definition.entities.JobPosting.fields.title;
  assert.deepEqual(title.transform, ["text", "trim"]);
  assert.equal(JSON.stringify(definition).includes("corroboration"), false, "editor-only inference evidence leaked into the adapter DSL");
  assert.equal(Object.hasOwn(title, "multiple"), false);
  const skills = definition.entities.JobPosting.fields.skills;
  assert.equal(skills.multiple, true);
});

test("round-trips author-accepted variant fallback receipts without adding runtime behavior", () => {
  const args = baseArgs();
  const block = {
    entityName: args.entityName, schemaType: args.schemaType, scope: args.scope,
    arity: "many", role: "collection", fidelity: "summary",
    identityField: args.identityField, fields: args.fields, requireFields: [],
    fallbackAcceptances: [{
      slotPath: "mainEntity", classificationFingerprint: "s2j1:shape",
      configurationDigest: "s2j1:config", fallbackEntity: "JobPosting",
      acceptedAt: "2026-08-14T12:00:00.000Z"
    }]
  };
  const definition = AdapterDefinition.buildDraftDefinition({ ...args, blocks: [block] });
  assert.equal(Object.hasOwn(definition.pages[0].blocks[0], "fallbackAcceptances"), false);
  assert.equal(definition.authoring.decisions[0].report.kind, "variant-fallback");
  assert.equal(AdapterDefinition.validateDraft(definition).ok, true);
  const restored = AdapterDefinition.editorStateFromDefinition(definition, args.pageUrl);
  assert.deepEqual(restored.blocks[0].fallbackAcceptances, block.fallbackAcceptances);
});

test("ports reviewed local-knowledge receipts without changing extraction bindings", () => {
  const args = baseArgs();
  args.fields[1].provenance = "manual";
  args.fields[1].corroboration = {
    version: 3,
    status: "accepted",
    confidence: "moderate",
    property: "title",
    score: 19,
    signals: [{ kind: "lexical", strength: "strong", reason: "Matched an authored alias." }],
    localKnowledge: {
      version: 1,
      material: true,
      acceptedByAuthor: true,
      selectedProperty: "title",
      withoutProfile: { accepted: false, property: "headline", confidence: "weak", score: 8 },
      sources: [{
        id: "local-title",
        termId: "example:title",
        revision: 2,
        profileDigest: "s2jp1:receipt-test",
        profile: { aliases: ["role heading"], normalization: ["text", "trim"] },
        source: { kind: "local", id: "semantic-library" },
        bundle: { id: "marketplace", label: "Marketplace" },
        importId: "import-1",
        canonicalUri: "https://example.com/title"
      }]
    }
  };

  const definition = AdapterDefinition.buildDraftDefinition(args);
  assert.equal(AdapterDefinition.validateDraft(definition).ok, true);
  assert.deepEqual(definition.entities.JobPosting.fields.title, { selectors: ["h2 a"], transform: ["text", "trim"] });
  assert.equal(definition.authoring.knowledge[0].digest, "s2jp1:receipt-test");
  assert.equal(definition.authoring.decisions[0].acceptedByAuthor, true);
  assert.equal(definition.authoring.decisions[0].report.localKnowledge.withoutProfile.property, "headline");

  const imported = AdapterDefinition.editorStateFromDefinition(definition, args.pageUrl);
  assert.equal(imported.blocks[0].fields.find((field) => field.name === "title").corroboration.localKnowledge.material, true);
});

test("preserves schema-selected pipelines and embeds documented extension terms", () => {
  const definition = AdapterDefinition.buildDraftDefinition(baseArgs({
    fields: [
      baseArgs().fields[0],
      { name: "datePosted", selector: ".posted", kind: "text", multiple: false, transform: ["text", "trim"] }
    ],
    customTerms: {
      "example:budget": { description: "Marketplace project budget.", valueType: "Object", cardinality: "one", example: "$500" }
    }
  }));
  assert.deepEqual(definition.entities.JobPosting.fields.datePosted.transform, ["text", "trim"]);
  assert.deepEqual(definition.vocabulary.terms["example:budget"], {
    description: "Marketplace project budget.", valueType: "Object", cardinality: "one", example: "$500"
  });
  assert.equal(AdapterDefinition.validateDraft(definition).ok, true);
});

test("path is derived from the current page's pathname as an exact rule", () => {
  const definition = AdapterDefinition.buildDraftDefinition(baseArgs({ pageUrl: "https://www.example.com/search/jobs/" }));
  assert.deepEqual(definition.pages[0].match.path[0], { mode: "exact", value: "/search/jobs" });
});

test("builds multiple independently typed block drafts on one page", () => {
  const first = baseArgs();
  const definition = AdapterDefinition.buildDraftDefinition({
    ...first,
    blocks: [
      {
        entityName: "JobPosting",
        schemaType: "JobPosting",
        scope: ".job",
        identityField: first.identityField,
        fields: first.fields,
        requireFields: ["title"]
      },
      {
        entityName: "RelatedJobPosting",
        schemaType: "JobPosting",
        scope: ".related-job",
        role: "related",
        identityField: "url",
        fields: [
          { name: "url", selector: "h3 a", attribute: "href", kind: "url", multiple: false, identity: true },
          { name: "title", selector: "h3", attribute: null, kind: "text", multiple: false }
        ],
        requireFields: []
      }
    ]
  });
  assert.deepEqual(Object.keys(definition.entities), ["JobPosting", "RelatedJobPosting"]);
  assert.equal(definition.pages[0].blocks.length, 2);
  assert.equal(definition.pages[0].blocks[1].role, "related");
  assert.equal(AdapterDefinition.validateDraft(definition).ok, true);
});

test("round-trips bounded variant candidates and their deterministic evidence", () => {
  const first = baseArgs();
  const variants = {
    minScore: 4,
    minMargin: 2,
    candidates: [
      { entityName: "PersonResult", schemaType: "Person", evidence: [{ selector: ".person", weight: 8 }] },
      { entityName: "ProjectResult", schemaType: "Project", evidence: [{ field: "skills", weight: 5 }] }
    ]
  };
  const definition = AdapterDefinition.buildDraftDefinition({
    ...first,
    blocks: [{ ...first, entityName: "Result", schemaType: "Thing", variants }]
  });
  assert.equal(AdapterDefinition.validateDraft(definition).ok, true);
  assert.deepEqual(definition.pages[0].blocks[0].variants, {
    fallback: "Result",
    minScore: 4,
    minMargin: 2,
    candidates: [
      { entity: "PersonResult", signals: [], evidence: [{ selector: ".person", weight: 8 }] },
      { entity: "ProjectResult", signals: [], evidence: [{ field: "skills", weight: 5 }] }
    ]
  });
  assert.equal(definition.entities.PersonResult.schemaType, "Person");
  assert.equal(definition.entities.ProjectResult.schemaType, "Project");
  const editor = AdapterDefinition.editorStateFromDefinition(definition, first.pageUrl);
  assert.deepEqual(editor.blocks[0].variants.candidates.map(({ entityName, schemaType, evidence }) => ({ entityName, schemaType, evidence })), variants.candidates);
  assert.equal(editor.blocks[0].variants.minScore, variants.minScore);
  assert.equal(editor.blocks[0].variants.minMargin, variants.minMargin);
  assert.deepEqual(editor.blocks[0].variants.candidates[0].fields.map((field) => field.name), ["url", "title", "skills"]);
  assert.equal(editor.blocks[0].variants.candidates[0].identityField, "url");
  assert.equal(editor.blocks[0].variants.candidates[0].fields[0].identity, true);
});

test("round-trips nested relationship variant slots", () => {
  const first = baseArgs();
  const nestedEntity = (entityName, schemaType) => ({
    entityName, schemaType, identityField: "url", fields: [
      { name: "url", selector: "h2 a", attribute: "href", kind: "url", identity: true },
      { name: "name", selector: "h2", kind: "text" }
    ]
  });
  const variantSlots = [{
    path: "item", minScore: 4, minMargin: 2,
    fallback: nestedEntity("ResultItem", "Thing"),
    candidates: [
      { ...nestedEntity("ArticleItem", "Article"), evidence: [{ selector: ".article", weight: 8 }] },
      { ...nestedEntity("JobItem", "JobPosting"), evidence: [{ selector: ".job", weight: 8 }] }
    ]
  }];
  const definition = AdapterDefinition.buildDraftDefinition({ ...first, blocks: [{ ...first, entityName: "ListEntry", schemaType: "ListItem", variantSlots }] });
  assert.equal(AdapterDefinition.validateDraft(definition).ok, true);
  assert.deepEqual(definition.pages[0].blocks[0].variantSlots[0], {
    path: "item", fallback: "ResultItem", minScore: 4, minMargin: 2,
    candidates: [
      { entity: "ArticleItem", signals: [{ field: "url", kind: "identity", weight: 1 }, { field: "name", kind: "field", weight: 2 }], evidence: [{ selector: ".article", weight: 8 }] },
      { entity: "JobItem", signals: [{ field: "url", kind: "identity", weight: 1 }, { field: "name", kind: "field", weight: 2 }], evidence: [{ selector: ".job", weight: 8 }] }
    ]
  });
  const editor = AdapterDefinition.editorStateFromDefinition(definition, first.pageUrl);
  assert.equal(editor.blocks[0].variantSlots[0].fallback.schemaType, "Thing");
  assert.deepEqual(editor.blocks[0].variantSlots[0].candidates.map((candidate) => candidate.schemaType), ["Article", "JobPosting"]);
});

test("imports legacy canonicalUrl identity as one semantic url field", () => {
  const definition = AdapterDefinition.buildDraftDefinition({
    ...baseArgs(),
    identityField: undefined,
    identity: { name: "canonicalUrl", selector: "h2 a", attribute: "href", kind: "url", multiple: false },
    fields: baseArgs().fields.filter((field) => field.name !== "url")
  });
  const editor = AdapterDefinition.editorStateFromDefinition(definition, baseArgs().pageUrl);
  assert.deepEqual(definition.entities.JobPosting.identity, { field: "url" });
  assert.deepEqual(editor.blocks[0].fields.map((field) => field.name), ["url", "title", "skills"]);
  assert.equal(editor.blocks[0].identityField, "url");
});

test("visual editing preserves a reviewed structural baseline until explicitly refreshed", () => {
  const structuralBaseline = {
    version: 1,
    scope: { typical: 20, minimum: 5 },
    variants: {
      JobPosting: {
        sampleSize: 20,
        shapes: [{ fingerprint: "s2j1:0123456789abcdef", frequency: 1 }],
        fields: {
          canonicalUrl: { coverage: 1, matchesPerItem: [1, 1] },
          title: { coverage: 1, matchesPerItem: [1, 1] },
          skills: { coverage: 0.8, matchesPerItem: [0, 4] }
        },
        evidence: []
      }
    }
  };
  const definition = AdapterDefinition.buildDraftDefinition(baseArgs({
    blocks: [{ ...baseArgs(), structuralBaseline }]
  }));
  assert.deepEqual(definition.pages[0].blocks[0].structuralBaseline, structuralBaseline);
  const editor = AdapterDefinition.editorStateFromDefinition(definition, baseArgs().pageUrl);
  assert.deepEqual(editor.blocks[0].structuralBaseline, structuralBaseline);
  assert.notEqual(editor.blocks[0].structuralBaseline, structuralBaseline);
  assert.equal(AdapterDefinition.validateDraft(definition).ok, true);
});

test("validateDraft surfaces the DSL's own error message for an invalid adapter id", () => {
  const definition = AdapterDefinition.buildDraftDefinition(baseArgs({ adapterId: "Not Valid" }));
  const result = AdapterDefinition.validateDraft(definition);
  assert.equal(result.ok, false);
  assert.match(result.message, /lowercase identifier/i);
});

test("validateDraft surfaces an error when a page host is not declared at adapter level", () => {
  const definition = AdapterDefinition.buildDraftDefinition(baseArgs({ pageUrl: "https://sub.example.com/search/jobs" }));
  definition.hosts = ["www.example.com"];
  const result = AdapterDefinition.validateDraft(definition);
  assert.equal(result.ok, false);
  assert.match(result.message, /host outside adapter\.hosts/i);
});

test("visual editing preserves untouched pages, match metadata, and selector fallbacks", () => {
  const original = AdapterDefinition.buildDraftDefinition(baseArgs());
  original.entities.JobPosting.fields.title.selectors.push(".fallback-title");
  original.pages[0].metadata = {
    logicalPosition: { source: "literal", value: 1, transform: [] }
  };
  original.pages.push({
    id: "detail",
    match: { host: ["www.example.com"], path: [{ mode: "prefix", value: "/job/" }] },
    pageType: "ItemPage",
    blocks: [{ entity: "JobPosting", scope: "main", arity: "one", role: "primary", fidelity: "full" }]
  });
  const editor = AdapterDefinition.editorStateFromDefinition(original, "https://www.example.com/search/jobs");
  assert.deepEqual(editor.blocks[0].fields.find((field) => field.name === "title").selectors, ["h2 a", ".fallback-title"]);
  const rebuiltPage = AdapterDefinition.buildDraftDefinition({
    adapterId: editor.adapterId,
    namespace: editor.namespace,
    version: editor.version,
    pageUrl: editor.pageUrl,
    pageId: editor.pageId,
    pageType: editor.pageType,
    blocks: editor.blocks,
    customTerms: editor.customTerms
  });
  const merged = AdapterDefinition.mergeWithBase(original, rebuiltPage, editor.pageId);
  assert.deepEqual(merged.pages[1], original.pages[1]);
  assert.deepEqual(merged.pages[0].metadata, original.pages[0].metadata);
  assert.deepEqual(merged.entities.JobPosting.fields.title.selectors, ["h2 a", ".fallback-title"]);
  assert.equal(AdapterDefinition.validateDraft(merged).ok, true);
});
