"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Vocabulary = require("../extension/editor/schema-vocabulary");

test("exposes inherited common properties and type-specific Schema.org properties", () => {
  assert.equal(Vocabulary.property("JobPosting", "description").valueType, "Text");
  assert.equal(Vocabulary.property("JobPosting", "datePosted").valueType, "Date");
  assert.equal(Vocabulary.property("Product", "sku").cardinality, "one");
  assert.equal(Vocabulary.property("JobPosting", "guru:budget"), null);
  const terms = Vocabulary.termsFor("JobPosting");
  assert.ok(terms.some((term) => term.name === "datePosted"));
  assert.ok(terms.every((term) => Array.isArray(term.domains) && Array.isArray(term.ranges)));
  terms[0].domains.push("MutationMustNotEscape");
  assert.equal(Vocabulary.termsFor("JobPosting")[0].domains.includes("MutationMustNotEscape"), false);
});

test("ranks DOM evidence and recommends only packaged transform pipelines", () => {
  const title = Vocabulary.suggestions("JobPosting", { tag: "h2", classes: ["job-title"], text: "Engineer" })[0];
  assert.equal(title.name, "title");
  assert.deepEqual(Vocabulary.defaultPipeline(title), ["text", "trim"]);
  assert.deepEqual(Vocabulary.defaultPipeline(Vocabulary.property("JobPosting", "datePosted")), ["text", "parseEnglishDateV1"]);
  const link = Vocabulary.suggestions("Thing", { tag: "a", attribute: "href", href: "/item/1" })[0];
  assert.equal(link.name, "url");
  const image = Vocabulary.suggestions("Thing", { tag: "img", attribute: "src", src: "/image.png" })[0];
  assert.equal(image.name, "image");
});

test("rejects repeated subordinate links and text-only avatar wrappers as top-level media fields", () => {
  const skillUrl = Vocabulary.suggestions("JobPosting", {
    tag: "a", attribute: "href", href: "/skills/javascript", classes: ["skillsList__skill"], context: "skills category", multiple: true
  }).find((term) => term.name === "url");
  assert.ok(skillUrl.score < 6);
  const skillSameAs = Vocabulary.suggestions("JobPosting", {
    tag: "a", attribute: "href", href: "/skills/javascript", classes: ["skillsList__skill"], context: "skills category", multiple: true
  }).find((term) => term.name === "sameAs");
  assert.ok(skillSameAs.score < 6);
  const genericActionsSameAs = Vocabulary.suggestions("JobPosting", {
    tag: "a", attribute: "href", href: "/login", classes: ["module_btn"], context: "actions", multiple: true
  }).find((term) => term.name === "sameAs");
  assert.ok(genericActionsSameAs.score < 6);
  const avatarWrapper = Vocabulary.suggestions("JobPosting", {
    tag: "div", classes: ["avatarinfo"], text: "Chris K Australia"
  }).find((term) => term.name === "image");
  assert.ok(avatarWrapper.score < 6);
  const nestedAvatarImage = Vocabulary.suggestions("JobPosting", {
    tag: "div", classes: ["avatarinfo"], text: "Chris K Australia"
  }).find((term) => term.leafName === "image");
  assert.ok(nestedAvatarImage.score < 6);
});

test("derives adapter budget extensions generically while keeping salary and nested schema fields distinct", () => {
  const budget = Vocabulary.suggestions("JobPosting", {
    tag: "div", classes: ["jobRecord__budget"], text: "Fixed Price | $10k-$25k"
  }, { adapterPrefix: "guru" })[0];
  assert.equal(budget.name, "guru:budget");
  assert.deepEqual(Vocabulary.defaultPipeline(budget), ["text", "parseProjectBudgetV1"]);
  const productBudget = Vocabulary.suggestions("Product", {
    tag: "div", classes: ["project-budget"], text: "Fixed Price | $10k-$25k"
  }, { adapterPrefix: "example" })[0];
  assert.equal(productBudget.name, "example:budget");
  const salary = Vocabulary.suggestions("JobPosting", { tag: "div", classes: ["salary"], text: "$80,000 salary" }, { adapterPrefix: "guru" })[0];
  assert.equal(salary.name, "baseSalary");
  const organizationName = Vocabulary.property("JobPosting", "hiringOrganization.name");
  assert.equal(organizationName.valueType, "Text");
  assert.equal(Vocabulary.property("JobPosting", "description.description"), null);
  assert.equal(Vocabulary.property("JobPosting", "image.image"), null);
  assert.equal(Vocabulary.property("JobPosting", "baseSalary.price"), null);
  assert.equal(Vocabulary.property("JobPosting", "baseSalary.value").leafName, "value");
});

test("recognizes absolute date-shaped evidence even when the word posted is outside the selected text", () => {
  const result = Vocabulary.suggestions("JobPosting", { tag: "strong", text: "on Dec 30, 2025" })[0];
  assert.equal(result.name, "datePosted");
});
