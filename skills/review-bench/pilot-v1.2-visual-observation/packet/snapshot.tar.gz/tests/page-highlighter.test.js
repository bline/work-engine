"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");

const source = fs.readFileSync(path.resolve(__dirname, "../extension/content/page-highlighter.js"), "utf8");

function visibleRect(left, top, width = 100, height = 40) {
  return { left, top, width, height, right: left + width, bottom: top + height };
}

test("page highlighter retains and independently clears multiple named groups", () => {
  const dom = new JSDOM(`<!doctype html><html><body>
    <section class="card"><h2 class="title">First</h2></section>
    <section class="card"><h2 class="title">Second</h2></section>
    <section class="card"><h2 class="title">Third</h2></section>
  </body></html>`, { runScripts: "outside-only", pretendToBeVisual: true });
  const { window } = dom;
  [...window.document.querySelectorAll(".card")].forEach((node, index) => { node.getBoundingClientRect = () => visibleRect(10, 20 + index * 60, 240, 50); });
  [...window.document.querySelectorAll(".title")].forEach((node, index) => { node.getBoundingClientRect = () => visibleRect(25, 30 + index * 60, 160, 25); });
  window.eval(source);

  const scopes = window.Site2JsonPageHighlighter.setGroup({ id: "scope", selector: ".card", color: "green", label: "Item" });
  const fields = window.Site2JsonPageHighlighter.setGroup({ id: "field", selector: ".title", color: "blue", numbered: false });
  assert.deepEqual(JSON.parse(JSON.stringify(scopes)), { ok: true, groupId: "scope", matchCount: 3, shown: 3 });
  assert.deepEqual(JSON.parse(JSON.stringify(fields)), { ok: true, groupId: "field", matchCount: 3, shown: 3 });
  assert.deepEqual(JSON.parse(JSON.stringify(window.Site2JsonPageHighlighter.snapshot())), [
    { id: "scope", selector: ".card", shown: 3 },
    { id: "field", selector: ".title", shown: 3 }
  ]);

  const host = window.document.querySelector("#__site2json-page-highlights");
  assert.equal(host.shadowRoot.querySelectorAll('[data-group="scope"]').length, 3);
  assert.equal(host.shadowRoot.querySelectorAll('[data-group="field"]').length, 3);
  assert.equal(host.shadowRoot.querySelector('[data-group="scope"] .badge').textContent, "Item 1");

  assert.equal(window.Site2JsonPageHighlighter.clearGroup("scope"), true);
  assert.equal(host.shadowRoot.querySelectorAll('[data-group="scope"]').length, 0);
  assert.equal(host.shadowRoot.querySelectorAll('[data-group="field"]').length, 3);
  window.Site2JsonPageHighlighter.clearAll();
  assert.equal(window.document.querySelector("#__site2json-page-highlights"), null);
  dom.window.close();
});

test("page highlighter caps rendered boxes while reporting the full match count", () => {
  const items = Array.from({ length: 230 }, (_item, index) => `<i class="item">${index}</i>`).join("");
  const dom = new JSDOM(`<!doctype html><html><body>${items}</body></html>`, { runScripts: "outside-only", pretendToBeVisual: true });
  const { window } = dom;
  [...window.document.querySelectorAll(".item")].forEach((node, index) => { node.getBoundingClientRect = () => visibleRect(0, index, 10, 10); });
  window.eval(source);
  const result = window.Site2JsonPageHighlighter.setGroup({ id: "many", selector: ".item" });
  assert.equal(result.matchCount, 230);
  assert.equal(result.shown, 200);
  dom.window.close();
});

test("page highlighter accepts ephemeral element references without durable selectors", () => {
  const dom = new JSDOM(`<!doctype html><html><body>
    <article>First</article><article>Second</article><aside>Ignore</aside>
  </body></html>`, { runScripts: "outside-only", pretendToBeVisual: true });
  const { window } = dom;
  [...window.document.querySelectorAll("article")].forEach((node, index) => {
    node.getBoundingClientRect = () => visibleRect(10, 20 + index * 60, 240, 50);
  });
  window.eval(source);

  const articles = [...window.document.querySelectorAll("article")];
  const result = window.Site2JsonPageHighlighter.setElementGroup({
    id: "semantic-focus", color: "purple", numbered: false
  }, [articles[0], articles[1], articles[0], null]);

  assert.deepEqual(JSON.parse(JSON.stringify(result)), {
    ok: true, groupId: "semantic-focus", matchCount: 2, shown: 2
  });
  assert.deepEqual(JSON.parse(JSON.stringify(window.Site2JsonPageHighlighter.snapshot())), [
    { id: "semantic-focus", shown: 2 }
  ]);
  const host = window.document.querySelector("#__site2json-page-highlights");
  assert.equal(host.shadowRoot.querySelectorAll('[data-group="semantic-focus"]').length, 2);
  assert.equal(host.shadowRoot.querySelector(".badge"), null);
  dom.window.close();
});
