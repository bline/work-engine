"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const Classifier = require("../extension/core/variant-classifier");

test("semantic shape can classify a candidate without explicit page evidence", () => {
  const result = Classifier.classify([
    { selected: "Article", signals: [{ field: "headline", kind: "field", weight: 10, matched: true }], evidence: [] },
    { selected: "Product", signals: [{ field: "price", kind: "field", weight: 10, matched: false }], evidence: [] }
  ], { minScore: 6, minMargin: 2 });
  assert.equal(result.accepted, true);
  assert.equal(result.winner.selected, "Article");
  assert.equal(result.winner.shapeScore, 10);
  assert.equal(result.winner.evidenceScore, 0);
});

test("explicit evidence resolves otherwise identical semantic shapes", () => {
  const result = Classifier.classify([
    { selected: "Article", signals: [{ field: "name", kind: "field", weight: 2, matched: true }], evidence: [{ selector: ".article", weight: 8, matched: true }] },
    { selected: "Product", signals: [{ field: "name", kind: "field", weight: 2, matched: true }], evidence: [{ selector: ".product", weight: 8, matched: false }] }
  ], { minScore: 6, minMargin: 2 });
  assert.equal(result.accepted, true);
  assert.equal(result.winner.selected, "Article");
  assert.equal(result.score, 10);
  assert.equal(result.margin, 8);
});

test("overlapping shapes remain ambiguous and retain a complete explanation", () => {
  const result = Classifier.classify([
    { selected: "Article", signals: [{ field: "name", kind: "field", weight: 4, matched: true }], evidence: [] },
    { selected: "Product", signals: [{ field: "name", kind: "field", weight: 4, matched: true }], evidence: [] }
  ], { minScore: 4, minMargin: 2 });
  assert.equal(result.accepted, false);
  assert.equal(result.reason, "ambiguous");
  assert.equal(result.margin, 0);
  assert.deepEqual(result.candidates.map((candidate) => candidate.shapeScore), [4, 4]);
});

test("the production classifier has no authoring or Schema.org catalog dependency", () => {
  const source = fs.readFileSync(path.join(__dirname, "../extension/core/variant-classifier.js"), "utf8");
  assert.doesNotMatch(source, /schema-(?:catalog|vocabulary)|semantic-ranking|authoring\//);
});
