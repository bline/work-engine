"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");

const root = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(root, "extension/editor/sidebar.html"), "utf8");
const source = fs.readFileSync(path.join(root, "extension/editor/sidebar.mjs"), "utf8");
const SchemaVocabulary = require("../extension/editor/schema-vocabulary");
const FieldDiscovery = require("../extension/editor/field-discovery");
const TransformCatalog = require("../extension/editor/transform-catalog");
const TransformPicker = require("../extension/editor/transform-picker");
const EditorController = require("../extension/editor/editor-controller");
const SemanticCompositions = require("../extension/editor/semantic-compositions");
const SemanticRanking = require("../extension/editor/semantic-ranking");
const VariantAnalysis = require("../extension/editor/variant-analysis");
const SidebarWorkflow = require("../extension/editor/sidebar-workflow");
const SidebarStructure = require("../extension/editor/sidebar-structure");
const SidebarSemantics = require("../extension/editor/sidebar-semantics");
const SidebarSemanticGraph = require("../extension/editor/sidebar-semantic-graph");
const SidebarAttention = require("../extension/editor/sidebar-attention");
const SidebarReview = require("../extension/editor/sidebar-review");
const SidebarWorkspace = require("../extension/editor/sidebar-workspace");
const SidebarSemanticLibrary = require("../extension/editor/sidebar-semantic-library");
const SidebarPageBridge = require("../extension/editor/sidebar-page-bridge");
const PageAnalysis = require("../extension/authoring/page-analysis");
const AutomaticConversion = require("../extension/authoring/automatic-conversion");
const SemanticLibraryInference = require("../extension/authoring/semantic-library-inference");
const TypeExtractionProfile = require("../extension/authoring/type-extraction-profile");
const FieldMappingCorroborator = require("../extension/authoring/field-mapping-corroborator");
const SemanticMappingArbitrator = require("../extension/authoring/semantic-mapping-arbitrator");
const SemanticToolbox = require("../extension/core/semantic-toolbox");
const SemanticLibrary = require("../extension/core/semantic-library-service");
const AdapterDefinition = require("../extension/editor/adapter-definition");
const Dsl = require("../extension/core/dsl");
const Model = require("../extension/core/model");

test("the sidebar imports correction promotion directly from the production ESM module", () => {
  assert.match(source, /^import \* as correctionPromotionApi from "\.\.\/authoring\/correction-promotion\.mjs";$/m);
  assert.doesNotMatch(source, /Site2JsonCorrectionPromotion/);
  assert.doesNotMatch(html, /correction-promotion\.js/);
});

async function waitFor(predicate, message) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  assert.fail(message);
}

async function waitForLong(predicate, message) {
  for (let attempt = 0; attempt < 3000; attempt += 1) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  assert.fail(message);
}

async function settleAsyncUi() {
  for (let index = 0; index < 3; index += 1) await new Promise((resolve) => setTimeout(resolve, 0));
}

async function loadSidebar(options = {}) {
  const sidebarUrl = `chrome-extension://test/editor/sidebar.html${options.omitTabId ? "" : `?tabId=${options.tabId || 41}`}`;
  const dom = new JSDOM(html, { url: sidebarUrl, runScripts: "outside-only" });
  const { window } = dom;
  const calls = [];
  window.HTMLElement.prototype.scrollIntoView = function scrollIntoView(options) {
    calls.push({ name: "scrollIntoView", elementId: this.id, options });
  };
  const workspaceCalls = { savedEntries: [], savedDrafts: [], active: [] };
  const tablePanelCalls = { messages: [], opened: [], options: [] };
  let tablePanelMessageListener = null;
  let tablePanelDisconnectListener = null;
  let runtimeMessageListener = null;
  let workspaceEntries = options.entries || [];
  let workspaceDrafts = options.drafts || [];
  let tabUpdatedListener = null;
  const sessionStorage = options.sessionStorage || {};
  window.chrome = {
    runtime: {
      onMessage: { addListener: (listener) => { runtimeMessageListener = listener; } },
      ...(options.tablePanel ? { connect: ({ name }) => {
        assert.equal(name, "site2json-sidebar:41");
        return {
          postMessage: (message) => { tablePanelCalls.messages.push(message); },
          onMessage: { addListener: (listener) => { tablePanelMessageListener = listener; } },
          onDisconnect: { addListener: (listener) => { tablePanelDisconnectListener = listener; } }
        };
      } } : {})
    },
    tabs: {
      get: async () => ({ id: options.tabId || 41, url: options.pageUrl || "https://example.com/jobs" }),
      query: async () => [{ id: options.tabId || 41, url: options.pageUrl || "https://example.com/jobs" }],
      onUpdated: { addListener: (listener) => { tabUpdatedListener = listener; } },
      sendMessage: async () => ({ ok: true })
    },
    ...(options.tablePanel ? {
      sidePanel: {
        setOptions: async (value) => { tablePanelCalls.options.push(value); },
        open: async (value) => { tablePanelCalls.opened.push(value); }
      }
    } : {}),
    ...(options.workspace ? { storage: {
      local: {},
      session: {
        get: async (key) => typeof key === "string" ? { [key]: sessionStorage[key] } : { ...sessionStorage },
        set: async (value) => Object.assign(sessionStorage, value),
        remove: async (key) => { delete sessionStorage[key]; }
      }
    } } : {}),
    action: { openPopup: async () => { tablePanelCalls.opened.push({ popup: true }); } }
  };
  if (options.workspace) {
    window.Site2JsonAdapterRegistry = {
      load: async () => workspaceEntries,
      save: async (entries) => { workspaceEntries = entries; workspaceCalls.savedEntries.push(entries); },
      summarize: (entry) => ({ version: entry.definition.version, hosts: entry.definition.hosts, pageTypes: entry.definition.pages.map((page) => page.pageType) }),
      setEnabled: (entries, id, enabled) => entries.map((entry) => entry.id === id ? { ...entry, enabled } : entry),
      remove: (entries, id) => entries.filter((entry) => entry.id !== id),
      sourceBytes: () => new Uint8Array(),
      upsert: (entries, entry) => [...entries.filter((candidate) => candidate.id !== entry.id), entry]
    };
    window.Site2JsonAdapterDraftRegistry = {
      load: async () => workspaceDrafts,
      save: async (drafts) => { workspaceDrafts = drafts; workspaceCalls.savedDrafts.push(drafts); },
      active: async () => options.activeDraftId || null,
      activate: async (id) => { workspaceCalls.active.push(id); },
      forAdapter: (drafts, adapterId) => drafts.find((draft) => draft.adapterId === adapterId) || null,
      createFromPublished: (entry) => ({
        id: `adapter:${entry.id}`, status: "draft", adapterId: entry.id, sourceName: entry.sourceName,
        baseDefinitionDigest: entry.definitionDigest, baseDefinition: structuredClone(entry.definition),
        workingDefinition: structuredClone(entry.definition), editorState: null,
        createdAt: "2026-08-09T01:00:00.000Z", updatedAt: "2026-08-09T01:00:00.000Z"
      }),
      createNew: () => ({ id: "new:test", status: "draft", adapterId: null, workingDefinition: null, editorState: null, createdAt: "2026-08-09T01:00:00.000Z", updatedAt: "2026-08-09T01:00:00.000Z" }),
      update: (draft, changes) => ({ ...draft, ...changes, updatedAt: "2026-08-09T02:00:00.000Z" }),
      upsert: (drafts, draft) => [...drafts.filter((candidate) => candidate.id !== draft.id), draft],
      remove: (drafts, id) => drafts.filter((draft) => draft.id !== id),
      publish: async (draft, entries, drafts) => {
        const entry = { id: draft.workingDefinition?.adapter || draft.adapterId || "automatic", enabled: true, definition: draft.workingDefinition };
        const nextEntries = [...entries, entry];
        const nextDrafts = drafts.filter((candidate) => candidate.id !== draft.id);
        workspaceCalls.savedEntries.push(nextEntries);
        workspaceCalls.savedDrafts.push(nextDrafts);
        return { entry, entries: nextEntries, drafts: nextDrafts };
      }
    };
  }
  window.Site2JsonBridge = {
    startSelection: async (mode) => { calls.push({ name: "startSelection", mode }); },
    cancelSelection: async () => { calls.push({ name: "cancelSelection" }); },
    useSelectionFrame: (frameId) => { calls.push({ name: "useSelectionFrame", frameId }); },
    syncSelectionFrame: async () => 0,
    run: async (fn, args) => {
      calls.push({ name: fn.name, args });
      if (fn.name === "bridgeReadSelection") {
        return options.selectionResult || { ok: true, summary: { tag: "li", id: null, classes: [], text: "First job" }, href: null };
      }
      if (fn.name === "bridgeLocateSelection") {
        return options.selectionLocation || { ok: false, reason: "outside-scope", selected: { tag: "li", text: "First job" } };
      }
      if (fn.name === "bridgeInferScope") {
        if (options.scopeResult) return options.scopeResult;
        const best = {
          selector: ".results > li", kind: "structure", matchCount: 2, siblingMatchCount: 2,
          parentCount: 1, findings: [{ kind: "good", message: "All matches share one parent." }]
        };
        return { ok: true, levels: [{ depth: 0, tag: "li", best }], chosen: best };
      }
      if (fn.name === "bridgeFindEvidenceScopes") {
        return options.evidenceScopeResult || { ok: true, evidenceCount: 0, confidence: "none", candidates: [], chosen: null };
      }
      if (fn.name === "bridgePageAnalysisContext") {
        return typeof options.pageAnalysisContext === "function"
          ? options.pageAnalysisContext()
          : options.pageAnalysisContext || { ok: true, pageUrl: "https://example.com/jobs", frameUrl: "https://example.com/jobs", revision: 0 };
      }
      if (fn.name === "bridgeAcceptScope") {
        return options.acceptScopeResult || { ok: true, matchCount: 2, sample: { tag: "li", id: null, classes: [], text: "First job" }, pageUrl: "https://example.com/jobs" };
      }
      if (fn.name === "bridgeBuildBlockTable") {
        const values = Object.fromEntries((args.fields || []).map((field) => [field.name, field.name === "title" ? "First job" : "value"]));
        const secondValues = Object.fromEntries((args.fields || []).map((field) => [field.name, field.name === "title" ? "Second job" : "value"]));
        const rows = [
          { index: 0, label: "First job", values },
          { index: 1, label: "Second job", values: secondValues }
        ].slice(0, options.acceptScopeResult?.matchCount || 2);
        return {
          ok: true,
          total: rows.length,
          rows
        };
      }
      if (fn.name === "bridgeAddFieldCandidate") {
        return options.fieldCandidate || {
          ok: true,
          element: { tag: "h2", id: null, classes: ["title"], text: "First job" },
          href: null,
          candidates: [{ selector: ".title", kind: "class", matchCount: 1, unique: true, note: "Unique match." }]
        };
      }
      if (fn.name === "bridgeDiscoverFields") {
        return options.discoveryResult || { ok: true, totalScopes: 2, sampledScopes: 2, truncated: false, candidates: [] };
      }
      if (fn.name === "bridgeCaptureStructuralBaseline") {
        return typeof options.structuralBaselineResult === "function"
          ? options.structuralBaselineResult(args)
          : options.structuralBaselineResult || { ok: true, baselines: [] };
      }
      if (fn.name === "bridgePreviewExtraction") {
        return options.previewExtractionResult || { ok: false, reason: "no-match" };
      }
      if (fn.name === "bridgeDiscoverVariantItems") {
        return options.variantItemsResult || { ok: true, total: 2, sampledItems: 2, items: [] };
      }
      if (fn.name === "bridgeClassifyVariantItems") {
        return options.variantClassificationResult || {
          ok: true, total: 2, sampled: 2,
          counts: [{ entityName: args.fallbackEntity, schemaType: args.schemaType, count: 2, fallback: true }],
          ambiguousCount: 0, unclassifiedCount: 2,
          rows: [0, 1].map((index) => ({ index, label: `Result ${index + 1}`, status: "unclassified", winner: null, fallback: { entityName: args.fallbackEntity, schemaType: args.schemaType }, alternatives: [] }))
        };
      }
      if (fn.name === "bridgeClassifyNestedVariantSlots") {
        return typeof options.nestedVariantClassificationResult === "function"
          ? options.nestedVariantClassificationResult(args, calls.filter((call) => call.name === "bridgeClassifyNestedVariantSlots").length)
          : options.nestedVariantClassificationResult || { ok: true, sampled: 0, total: 0, slots: [] };
      }
      if (fn.name === "bridgeCaptureVariantEvidence") {
        return options.variantEvidenceResult || { ok: true, rule: { selector: ".person", weight: 10 }, label: ".person is present" };
      }
      if (fn.name === "bridgePreviewField") {
        return { ok: true, values: ["First job", "Second job"], matchCounts: [1, 1], coverage: { present: 2, sampled: 2, total: 2 } };
      }
      return { ok: true };
    }
  };
  window.Site2JsonAdapterDefinition = options.adapterDefinition || {
    buildDraftDefinition: (args) => { calls.push({ name: "buildDraftDefinition", args }); return {}; },
    mergeWithBase: (_base, definition) => definition,
    validateDraft: () => ({ ok: true, definition: {} }),
    editorStateFromDefinition: () => null
  };
  window.Site2JsonSchemaVocabulary = SchemaVocabulary;
  window.Site2JsonFieldDiscovery = FieldDiscovery;
  window.Site2JsonTransformCatalog = TransformCatalog;
  window.Site2JsonTransformPicker = TransformPicker;
  window.Site2JsonEditorController = EditorController;
  window.Site2JsonSemanticCompositions = SemanticCompositions;
  window.Site2JsonSemanticRanking = SemanticRanking;
  window.Site2JsonVariantAnalysis = options.variantAnalysis || VariantAnalysis;
  window.Site2JsonSidebarWorkflow = SidebarWorkflow;
  window.Site2JsonSidebarStructure = SidebarStructure;
  window.Site2JsonSidebarSemantics = SidebarSemantics;
  window.Site2JsonSidebarSemanticGraph = SidebarSemanticGraph;
  window.Site2JsonAttention = SidebarAttention;
  window.Site2JsonSidebarReview = SidebarReview;
  window.Site2JsonSidebarWorkspace = SidebarWorkspace;
  window.Site2JsonSidebarSemanticLibrary = SidebarSemanticLibrary;
  window.Site2JsonSemanticLibraryService = options.semanticLibraryService || null;
  window.Site2JsonSemanticLibraryInference = SemanticLibraryInference;
  window.Site2JsonTypeExtractionProfile = TypeExtractionProfile;
  window.Site2JsonFieldMappingCorroborator = FieldMappingCorroborator;
  window.Site2JsonSemanticMappingArbitrator = SemanticMappingArbitrator;
  window.Site2JsonSidebarPageBridge = SidebarPageBridge;
  window.Site2JsonPageAnalysis = PageAnalysis;
  window.Site2JsonAutomaticConversion = AutomaticConversion;
  if (options.productionRuntime) {
    window.Site2JsonDsl = Dsl;
    window.Site2JsonModel = Model;
  }
  window.__testCorrectionPromotionApi = options.correctionPromotionApi || null;
  const evaluableSource = source.replace(
    /^import \* as correctionPromotionApi from "\.\.\/authoring\/correction-promotion\.mjs";$/m,
    "const correctionPromotionApi = globalThis.__testCorrectionPromotionApi || null;"
  );
  assert.notEqual(evaluableSource, source, "the sidebar test harness did not replace the production ESM import");
  window.eval(evaluableSource);
  window.__testPickerSelection = (frameId = 0) => runtimeMessageListener?.(
    { type: "site2json-picker:selection", selection: { instanceId: "test-selection" } },
    { tab: { id: options.tabId || 41 }, frameId }
  );
  if (options.sidepanel) await settleAsyncUi();
  else {
    window.__testPickerSelection();
    await waitFor(() => !window.document.querySelector("#selection-summary").hidden, "sidebar did not read the selection");
    await settleAsyncUi();
  }
  return {
    calls, dom, window, workspaceCalls, tablePanelCalls, sessionStorage,
    panelCommand: (command) => tablePanelMessageListener?.({ type: "panel-command", command }),
    panelMessage: (message) => tablePanelMessageListener?.(message),
    requestPanelSnapshot: () => tablePanelMessageListener?.({ type: "panel-request-snapshot" }),
    disconnectPanel: () => tablePanelDisconnectListener?.(),
    navigate: () => tabUpdatedListener?.(options.tabId || 41, { status: "loading" }, { id: options.tabId || 41, url: "https://example.com/next" })
  };
}

test("the visual picker replaces passive DevTools selection and preserves its iframe", async () => {
  const { calls, dom, window } = await loadSidebar({ sidepanel: true });
  window.__testPickerSelection(7);
  await waitFor(() => calls.some((call) => call.name === "bridgeReadSelection"), "the picker selection did not refresh the editor selection");
  const frameCall = calls.find((call) => call.name === "useSelectionFrame");
  assert.deepEqual(frameCall, { name: "useSelectionFrame", frameId: 7 });
  assert.equal(window.document.querySelector("#selection-summary").hidden, false);
  dom.window.close();
});

test("the sidebar owns published adapter management and starts isolated edit drafts", async () => {
  const entry = {
    id: "example", sourceName: "example.yaml", enabled: true,
    definitionDigest: `sha256:${"2".repeat(64)}`,
    definition: { adapter: "example", version: 1, namespace: "https://example.com/#", hosts: ["example.com"], pages: [{ id: "search", pageType: "SearchResultsPage" }] }
  };
  const { dom, window, workspaceCalls } = await loadSidebar({ workspace: true, entries: [entry] });
  const document = window.document;
  await waitFor(() => document.querySelector("#library-list [data-adapter-id='example']"), "published adapter was not rendered in the sidebar library");
  assert.equal(document.body.classList.contains("library-home-open"), true);
  assert.equal(document.querySelector("#library-home").hidden, false);
  assert.equal(document.querySelector("#editor-workspace").hidden, true);
  assert.equal(document.querySelector("#back-to-library-button").hidden, true);
  assert.ok(Array.from(document.querySelectorAll("#draft-picker option")).some((option) => /example v1/.test(option.textContent)));
  assert.equal(document.querySelector("#pick-scope-button").disabled, true);
  assert.match(document.querySelector("#structure-guidance").textContent, /Choose or create a working draft/);

  const toggle = document.querySelector("[data-action='toggle-adapter']");
  toggle.checked = false;
  toggle.dispatchEvent(new window.Event("change", { bubbles: true }));
  await waitFor(() => workspaceCalls.savedEntries.at(-1)?.[0].enabled === false, "enablement was not saved from the sidebar");

  document.querySelector("[data-adapter-id='example'] [data-action='edit-adapter']").click();
  await waitFor(() => workspaceCalls.savedDrafts.at(-1)?.[0]?.id === "adapter:example", "editing did not create a separate draft copy");
  await waitFor(() => workspaceCalls.active.at(-1) === "adapter:example", "the new edit draft was not activated");
  assert.equal(workspaceCalls.active.at(-1), "adapter:example");
  assert.match(document.querySelector("#library-list [data-draft-id='adapter:example']").textContent, /draft/i);
  await waitFor(() => !document.body.classList.contains("library-home-open"), "editing did not open the adapter workspace");
  await waitFor(() => !document.querySelector("header .app-heading #back-to-library-button").hidden, "editor navigation did not appear");

  document.querySelector("#back-to-library-button").click();
  await waitFor(() => document.body.classList.contains("library-home-open"), "Back did not return to the adapter library");
  assert.equal(document.querySelector("#library-home").hidden, false);

  let confirmationCount = 0;
  window.confirm = () => { confirmationCount += 1; return false; };
  document.querySelector("[data-draft-id='adapter:example'] [data-action='discard-library-draft']").click();
  await waitFor(() => !document.querySelector("[data-draft-id='adapter:example']"), "the manager did not discard the draft immediately");
  assert.equal(confirmationCount, 0, "discarding a draft from the Adapter Library opened a JavaScript confirmation");
  assert.ok(document.querySelector("[data-adapter-id='example']"), "discarding a draft removed its published adapter");

  document.querySelector("[data-adapter-id='example'] [data-action='edit-adapter']").click();
  await waitFor(() => !document.body.classList.contains("library-home-open"), "Resume did not reopen the draft editor");

  assert.equal(document.querySelector("#discard-draft-button").disabled, false);
  document.querySelector("#discard-draft-button").click();
  await waitFor(() => workspaceCalls.active.at(-1) === "new:test", "discarding did not activate a fresh draft");
  assert.ok(workspaceCalls.savedDrafts.at(-1).some((draft) => draft.id === "new:test"));
  assert.ok(!workspaceCalls.savedDrafts.at(-1).some((draft) => draft.id === "adapter:example"));
  assert.ok(document.querySelector("#library-list [data-adapter-id='example']"), "discarding a draft removed its published adapter");
  assert.match(document.querySelector("#draft-status").textContent, /published adapters were not changed/);
  assert.ok(document.querySelector("[data-workflow-step='structure']").classList.contains("selected"));
  dom.window.close();
});

test("a manifest-opened side panel resolves its active tab before loading the shared adapter library", async () => {
  const entry = {
    id: "shared", sourceName: "shared.yaml", enabled: true,
    definition: { adapter: "shared", version: 1, hosts: ["example.com"], pages: [{ pageType: "SearchResultsPage" }] }
  };
  const { dom, window } = await loadSidebar({ workspace: true, sidepanel: true, omitTabId: true, tabId: 73, entries: [entry] });
  await waitFor(() => window.document.querySelector("#library-list [data-adapter-id='shared']"), "the generic side panel did not load shared adapters");
  assert.doesNotMatch(window.location.search, /tabId=/);
  dom.window.close();
});

test("top-level navigation switches between adapters and the Semantic Library without opening an editor", async () => {
  const values = {};
  const storage = {
    async get(key) { return { [key]: values[key] }; },
    async set(next) { Object.assign(values, next); }
  };
  const service = SemanticLibrary.createLegacyToolboxService({ toolboxApi: SemanticToolbox, storage });
  await service.savePattern({
    pattern: {
      id: "pattern:article-author",
      label: "Article author",
      root: "article",
      nodes: { article: { types: ["Article"], expectation: "core" } },
      edges: [],
      terms: {}
    }
  });
  const { dom, window } = await loadSidebar({ workspace: true, semanticLibraryService: service });
  const document = window.document;
  document.querySelector("[data-app-view='semantics']").click();
  await waitFor(() => !document.querySelector("#semantic-library-home").hidden, "Semantic Library did not open");
  await waitFor(() => document.querySelector("#semantic-library-results [data-id='pattern:article-author']"), "Semantic Library results did not load");
  assert.equal(document.querySelector("#library-home").hidden, true);
  assert.equal(document.querySelector("[data-app-view='semantics']").getAttribute("aria-current"), "page");
  assert.match(document.querySelector("#editor-subtitle").textContent, /patterns, tags, and collections/);
  assert.equal(document.querySelector("#app-title").textContent, "Site2JSON Semantic Library");

  document.querySelector("[data-app-view='adapters']").click();
  assert.equal(document.querySelector("#library-home").hidden, false);
  assert.equal(document.querySelector("#semantic-library-home").hidden, true);
  assert.equal(document.querySelector("[data-app-view='adapters']").getAttribute("aria-current"), "page");
  assert.equal(document.querySelector("#app-title").textContent, "Site2JSON");
  dom.window.close();
});

test("refines a proposed scope explicitly between narrower children and wider parents", async () => {
  const candidate = (selector, depth, tag, matchCount) => ({
    depth, tag,
    best: { selector, kind: "class", matchCount, siblingMatchCount: matchCount, parentCount: 1, findings: [] }
  });
  const options = {
    scopeResult: {
      ok: true,
      levels: [candidate(".title", 0, "h2", 19), candidate(".job", 1, "li", 19), candidate(".results", 2, "ul", 1)],
      chosen: candidate(".job", 1, "li", 19).best
    }
  };
  const { calls, dom, window } = await loadSidebar(options);
  const document = window.document;
  document.querySelector("#pick-scope-button").click();
  await waitFor(() => !document.querySelector("#scope-adjustments").hidden, "scope boundary controls were not shown");
  assert.equal(document.querySelectorAll("#scope-levels .option-item").length, 3);
  assert.match(document.querySelector("#scope-status").textContent, /<li> boundary: 19 matches/);

  document.querySelector("#scope-narrower-button").click();
  await waitFor(() => calls.some((call) => call.name === "bridgeHighlightSelector" && call.args.selector === ".title"), "narrower boundary was not previewed");
  assert.equal(document.querySelector("#scope-narrower-button").disabled, true);
  document.querySelector("#scope-wider-button").click();
  assert.equal(document.querySelector("#scope-narrower-button").disabled, false);
  document.querySelector("#scope-use-preview-button").click();
  await waitFor(() => calls.some((call) => call.name === "bridgeAcceptScope" && call.args.selector === ".job"), "previewed boundary was not explicitly accepted");
  await waitFor(() => document.querySelector("#scope-adjustments").hidden, "scope refinement controls remained after acceptance");
  dom.window.close();
});

test("collapses to a selection-aware bridge while the expanded workspace owns the lease", async () => {
  const { dom, window, tablePanelCalls, panelMessage } = await loadSidebar({ tablePanel: true });
  const document = window.document;
  panelMessage({ type: "controller-state", lease: { owner: "expanded" } });
  assert.ok(document.body.classList.contains("workspace-expanded"));
  assert.equal(document.querySelector("#expanded-workspace-bridge").hidden, false);
  assert.equal(document.querySelector("#step-selection").hidden, false, "Elements selection context remains visible in bridge mode");
  document.querySelector("#resume-sidebar-button").click();
  assert.ok(tablePanelCalls.messages.some((message) => message.type === "lease-command" && message.owner === "sidebar"));

  panelMessage({ type: "controller-state", lease: { owner: "sidebar" } });
  assert.equal(document.body.classList.contains("workspace-expanded"), false);
  assert.equal(document.querySelector("#open-table-panel-button").disabled, false);
  dom.window.close();
});

test("keeps the legacy panel transport synchronized without disabling the active sidebar", async () => {
  const { calls, dom, window, tablePanelCalls, panelCommand, requestPanelSnapshot } = await loadSidebar({ tablePanel: true });
  const document = window.document;
  await settleAsyncUi();
  assert.deepEqual(tablePanelCalls.options, [], "sidebar startup must not disable or replace its own side-panel path");
  assert.equal(document.querySelector("#open-table-panel-button").hidden, true);
  document.querySelector("#open-table-panel-button").click();
  await settleAsyncUi();
  assert.equal(tablePanelCalls.opened.length, 0);
  assert.equal(tablePanelCalls.messages.some((message) => message.type === "lease-command" && message.owner === "expanded"), false);

  await createJobBlock(document);
  requestPanelSnapshot();
  const initial = tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1).snapshot;
  assert.equal(initial.activeBlock.schemaType, "JobPosting");
  assert.equal(initial.rows.length, 2);
  assert.equal(initial.activeBlock.composition.id, "schema:JobPosting");
  assert.equal(initial.activeBlock.compositionValidation.ok, true);
  const editor = tablePanelCalls.messages.filter((message) => message.type === "editor-snapshot").at(-1);
  assert.equal(editor.editor.activeBlockId, "block-1");
  assert.equal(editor.editor.blocks[0].schemaType, "JobPosting");
  assert.ok(Number.isInteger(editor.revision));

  panelCommand({ action: "analyze-semantics" });
  await waitFor(() => tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot.activeBlock?.semanticRanking?.status === "ready", "semantic evidence ranking was not published");
  const ranking = tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1).snapshot.activeBlock.semanticRanking;
  assert.equal(ranking.sampledScopes, 2);
  assert.equal(ranking.observationCount, 0);

  panelCommand({ action: "discover-fields", includeUnmapped: true });
  await waitFor(() => tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot.activeBlock?.discovery?.report?.kind === "ready", "expanded discovery report was not published");
  assert.equal(tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1).snapshot.activeBlock.discovery.canUndo, true);
  panelCommand({ action: "undo-discovery" });
  await waitFor(() => tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot.activeBlock?.discovery?.report?.message.includes("undone"), "expanded discovery undo was not published");

  panelCommand({ action: "update-finish-metadata", metadata: { adapterId: "example", namespace: "https://example.com/#", pageId: "search", pageType: "SearchResultsPage" } });
  await waitFor(() => tablePanelCalls.messages.filter((message) => message.type === "editor-snapshot").at(-1)?.editor.finish.adapterId === "example", "expanded finish metadata was not synchronized");
  panelCommand({ action: "build-draft", metadata: { adapterId: "example", namespace: "https://example.com/#", pageId: "search", pageType: "SearchResultsPage" } });
  await waitFor(() => /canonical identity/.test(tablePanelCalls.messages.filter((message) => message.type === "editor-snapshot").at(-1)?.editor.finish.buildStatus || ""), "expanded validation result was not synchronized");

  panelCommand({ action: "set-semantic-model", modelId: "site2json:freelance-opportunity" });
  await waitFor(() => tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot.activeBlock?.composition?.id === "site2json:freelance-opportunity", "semantic composition change was not published");
  assert.equal(tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1).snapshot.activeBlock.compositionValidation.ok, true);

  panelCommand({ action: "add-selected-field" });
  window.__testPickerSelection();
  await waitFor(() => !document.querySelector("#field-form").hidden, "panel add command did not open the field editor");
  document.querySelector("#field-name").value = "title";
  document.querySelector("#add-field-button").click();
  await waitFor(() => tablePanelCalls.messages.some((message) => message.type === "table-snapshot" && message.snapshot.activeBlock?.fields.some((field) => field.name === "title")), "saved field was not published to the table panel");
  const title = tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1).snapshot.activeBlock.fields.find((field) => field.name === "title");
  panelCommand({ action: "edit-field", fieldKey: title.key });
  assert.equal(document.querySelector("#field-editor-title").textContent, "Edit title");
  panelCommand({ action: "preview-field-form", chooseSemanticDefaults: true, form: {
    selector: ".title", name: "datePosted", kind: "text", attribute: "", multiple: false,
    identity: false, required: true, pipeline: ["text", "trim"], customTerm: null
  } });
  await waitFor(() => document.querySelector("#field-semantic-status").textContent.includes("JobPosting.datePosted"), "expanded semantic edits were not applied to the pending field");
  assert.ok(Array.from(document.querySelectorAll("#transform-steps .transform-step"), (node) => node.dataset.name).includes("parseEnglishDateV1"));
  panelCommand({ action: "scroll-to-target", target: { withinSelector: ".results > li", rootIndex: 1, selector: ".title" } });
  await waitFor(() => calls.some((call) => call.name === "bridgeRevealTarget" && call.args.scrollIntoView === true && call.args.rootIndex === 1), "double-click scroll command was not routed into the inspected page");
  dom.window.close();
});

test("expanded Structure commands create and activate multiple blocks", async () => {
  const { dom, tablePanelCalls, panelCommand } = await loadSidebar({ tablePanel: true });
  const latestSnapshot = () => tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot;

  panelCommand({ action: "infer-scope" });
  await waitFor(() => latestSnapshot()?.structure?.proposals?.length, "expanded scope proposals were not published");
  panelCommand({ action: "accept-scope", selector: ".results > li" });
  await waitFor(() => latestSnapshot()?.structure?.pendingScope?.selector === ".results > li", "expanded scope was not accepted");
  panelCommand({ action: "create-block", name: "Jobs", schemaType: "JobPosting" });
  await waitFor(() => latestSnapshot()?.blocks?.length === 1 && latestSnapshot()?.activeBlock?.name === "Jobs", "first expanded block was not created");

  panelCommand({ action: "infer-scope" });
  await waitFor(() => latestSnapshot()?.structure?.proposals?.length, "second expanded scope proposals were not published");
  panelCommand({ action: "accept-scope", selector: ".results > li" });
  await waitFor(() => latestSnapshot()?.structure?.pendingScope?.selector === ".results > li", "second expanded scope was not accepted");
  panelCommand({ action: "create-block", name: "Related jobs", schemaType: "JobPosting" });
  await waitFor(() => latestSnapshot()?.blocks?.length === 2 && latestSnapshot()?.activeBlock?.name === "Related jobs", "second expanded block was not created");
  assert.equal(Array.from(latestSnapshot().blocks, (block) => block.name).join("|"), "Jobs|Related jobs");
  dom.window.close();
});

test("evidence-first Structure scanning proposes a scope and prefills a confident semantic model", async () => {
  const observations = [
    { selector: ".title > a", kind: "url", suggestedName: "url", evidence: { tag: "a", attribute: "href", href: "/work/1", classes: ["result-title"], context: "h2 result title" } },
    { selector: ".title", kind: "text", suggestedName: "title", evidence: { tag: "h2", classes: ["result-title"], text: "Build an API" } },
    { selector: ".posted", kind: "text", suggestedName: "posted", evidence: { tag: "span", classes: ["posted"], text: "Posted Dec 30, 2025" } },
    { selector: ".skills", kind: "text", suggestedName: "skills", multiple: true, evidence: { tag: "a", classes: ["skills"], text: "Python", multiple: true } },
    { selector: ".budget", kind: "text", suggestedName: "budget", evidence: { tag: "div", classes: ["budget"], text: "Fixed Price | $500" } }
  ];
  const candidate = {
    selector: ".results > li", kind: "structure", tag: "li", matchCount: 12, parentCount: 1,
    consistentKinds: ["url", "heading", "date", "money"], identityRatio: 1, score: 190,
    findings: [{ kind: "good", message: "All candidate items share one collection parent." }], observations
  };
  const { calls, dom, tablePanelCalls, panelCommand } = await loadSidebar({
    tablePanel: true,
    evidenceScopeResult: { ok: true, evidenceCount: 60, confidence: "high", margin: 30, candidates: [candidate], chosen: candidate }
  });
  const latestSnapshot = () => tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot;

  panelCommand({ action: "find-page-scopes" });
  await waitFor(() => latestSnapshot()?.structure?.proposals?.[0]?.recommendation?.modelId === "site2json:freelance-opportunity", "semantic recommendation was not attached to the inferred scope");
  assert.equal(dom.window.document.querySelector("#scope-adjustments").hidden, true, "ranked page candidates must not masquerade as a narrower/wider ancestor chain");
  const useRecommended = dom.window.document.querySelector("#scope-levels .option-item.selected .option-actions button");
  assert.equal(useRecommended?.textContent, "Use recommended scope", "ranked scope cards must expose their explicit accept action");
  assert.equal(dom.window.document.querySelector("#scope-show-page-analysis").hidden, true);
  dom.window.document.querySelector("#pick-scope-button").click();
  await waitFor(() => !dom.window.document.querySelector("#scope-show-page-analysis").hidden, "manual scope proposal did not offer a return to Page Analysis");
  dom.window.document.querySelector("#scope-show-page-analysis").click();
  assert.equal(dom.window.document.querySelector("#scope-show-page-analysis").hidden, true);
  assert.equal(dom.window.document.querySelector("#scope-levels code").textContent, ".results > li", "returning to Page Analysis did not restore ranked candidates");
  const singleItemToggle = dom.window.document.querySelector("#single-item-scope");
  singleItemToggle.checked = true;
  singleItemToggle.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  assert.equal(dom.window.document.querySelector("#scope-levels .option-item"), null);
  singleItemToggle.checked = false;
  singleItemToggle.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  assert.equal(dom.window.document.querySelector("#scope-levels code").textContent, ".results > li", "eager Page Analysis results were not restored");
  assert.equal(dom.window.document.querySelector("#scope-adjustments").hidden, true, "restored Page Analysis results gained ancestor-chain controls");
  dom.window.document.querySelector("#scope-levels .option-item.selected .option-actions button").click();
  await waitFor(() => calls.some((call) => call.name === "bridgeAcceptScope" && call.args.selector === ".results > li"), "recommended scope card did not invoke acceptance");
  await waitFor(() => !dom.window.document.querySelector("#block-setup").hidden, "recommended scope did not open block setup");
  assert.equal(dom.window.document.querySelector("#block-schema-type").value, "JobPosting", "recommended scope did not retain its semantic evidence");
  panelCommand({ action: "create-block", name: "Jobs", schemaType: "JobPosting" });
  await waitFor(() => latestSnapshot()?.activeBlock?.composition?.id === "site2json:freelance-opportunity", "recommended composition was not used for the new block");
  dom.window.close();
});

test("eager Page Analysis accepts a semantically confident article as a collection of one", async () => {
  const observations = [
    { selector: "h1", kind: "text", suggestedName: "field", evidence: { tag: "h1", text: "How automatic extraction works" } },
    { selector: "time", kind: "text", suggestedName: "field", evidence: { tag: "time", attribute: "datetime", text: "August 13, 2026" } },
    { selector: "p:nth-of-type(1)", kind: "text", suggestedName: "field", evidence: { tag: "p", text: "A substantial article body with useful rendered content." } }
  ];
  const candidate = {
    selector: "article", kind: "structure", tag: "article", matchCount: 1, singleton: true,
    score: 124, findings: [{ kind: "good", message: "A semantic article root contains substantial content." }], observations
  };
  const { dom, tablePanelCalls, panelCommand } = await loadSidebar({
    tablePanel: true,
    evidenceScopeResult: { ok: true, mode: "single", evidenceCount: 8, confidence: "high", margin: 24, candidates: [candidate], chosen: candidate },
    acceptScopeResult: { ok: true, matchCount: 1, sample: { tag: "article", id: null, classes: [], text: "How automatic extraction works" }, pageUrl: "https://example.com/article" }
  });
  const document = dom.window.document;
  const latestSnapshot = () => tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot;
  panelCommand({ action: "find-page-scopes" });
  await waitFor(() => latestSnapshot()?.structure?.proposals?.[0]?.recommendation?.schemaType === "Article", "article semantic recommendation was not attached");
  assert.match(document.querySelector("#scope-heading").textContent, /detail-page scope/i);
  assert.match(document.querySelector("#scope-status").textContent, /clears the automatic boundary threshold/i);
  panelCommand({ action: "accept-scope", selector: "article" });
  await waitFor(() => latestSnapshot()?.structure?.pendingScope?.matchCount === 1, "singleton scope was not accepted");
  panelCommand({ action: "create-block", name: "Detail", schemaType: "Article" });
  await waitFor(() => latestSnapshot()?.activeBlock?.matchCount === 1, "singleton block was not created");
  assert.equal(latestSnapshot().activeBlock.matchCount, 1);
  dom.window.close();
});

test("Infer remaining steps reuses Page Analysis and reaches unreviewed Review without extraction or publication", async () => {
  const observations = [
    { selector: ".title > a", kind: "url", suggestedName: "url", evidence: { tag: "a", attribute: "href", href: "/jobs/1", classes: ["title"], context: "h2 title" }, coverage: { present: 3, sampled: 3 } },
    { selector: ".title", kind: "text", suggestedName: "title", evidence: { tag: "h2", classes: ["title"], text: "Build an API" }, coverage: { present: 3, sampled: 3 } },
    { selector: ".posted", kind: "text", suggestedName: "posted", evidence: { tag: "span", classes: ["posted"], text: "Posted Dec 30, 2025" }, coverage: { present: 3, sampled: 3 } },
    { selector: ".budget", kind: "text", suggestedName: "budget", evidence: { tag: "div", classes: ["budget"], text: "Fixed Price | $500" }, coverage: { present: 3, sampled: 3 } }
  ];
  const candidate = { selector: ".results > li", kind: "structure", tag: "li", matchCount: 3, parentCount: 1, consistentKinds: ["url", "heading", "date", "money"], identityRatio: 1, score: 190, findings: [], observations };
  const draft = {
    id: "auto-draft", status: "draft", adapterId: null, sourceName: "automatic.yaml", workingDefinition: null,
    editorState: { pageUrl: "https://example.com/jobs" }, createdAt: "2026-08-10T00:00:00.000Z", updatedAt: "2026-08-10T00:00:00.000Z"
  };
  const abandonedBlankDraft = {
    id: "blank-on-this-page", status: "draft", adapterId: null, sourceName: null, workingDefinition: null,
    editorState: { pageUrl: "https://example.com/jobs", blocks: [] }, createdAt: "2026-08-10T00:00:00.000Z", updatedAt: "2026-08-10T00:00:00.000Z"
  };
  const { dom, window, calls, tablePanelCalls, workspaceCalls } = await loadSidebar({
    workspace: true, tablePanel: true, activeDraftId: "auto-draft", drafts: [draft, abandonedBlankDraft],
    evidenceScopeResult: { ok: true, pageUrl: "https://example.com/jobs", evidenceCount: 30, confidence: "high", margin: 30, candidates: [candidate], chosen: candidate },
    acceptScopeResult: { ok: true, matchCount: 3, sample: { tag: "li", id: null, classes: [], text: "First job" }, pageUrl: "https://example.com/jobs" },
    discoveryResult: { ok: true, totalScopes: 3, sampledScopes: 3, truncated: false, candidates: observations }
  });
  await waitFor(() => window.document.querySelector("[data-draft-id='auto-draft'] [data-action='open-draft']"), "automatic draft was not listed on the library home");
  assert.equal(window.document.body.classList.contains("library-home-open"), true);
  window.document.querySelector("[data-draft-id='auto-draft'] [data-action='open-draft']").click();
  await waitFor(() => window.document.querySelector("#draft-picker").value === "draft:auto-draft", "automatic test draft was not opened");
  await waitFor(() => !window.document.querySelector("#infer-remaining-button").disabled, "automatic test draft was not ready");
  assert.equal(window.document.querySelector("#infer-remaining-button").hidden, false);
  assert.equal(window.document.querySelector("#infer-remaining-button").disabled, false);
  window.document.querySelector("#infer-remaining-button").click();
  await waitForLong(() => /Inference reached Review/.test(window.document.querySelector("#infer-remaining-status").textContent), `inference did not complete (status=${window.document.querySelector("#infer-remaining-status").textContent}; draft=${window.document.querySelector("#draft-status").textContent}; calls=${calls.map((call) => call.name).join(",")})`);
  assert.ok(calls.some((call) => call.name === "bridgeHighlightSelector" && call.args.selector === ".results > li"), "automatic inference did not highlight its accepted scope");
  const completed = tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot;
  assert.equal(completed.blocks[0].semanticsReviewed, false, "an inferred model must remain explicitly unreviewed");
  assert.equal(completed.inferenceReviewReady, true);
  assert.equal(window.document.querySelector("#adapter-id").value, "example");
  assert.equal(window.document.querySelector("#adapter-namespace").value, "https://site2json.dev/ns/example#", "the inferred namespace must be a submitted value, not placeholder text");
  assert.equal(window.document.querySelector("#inference-review-banner").hidden, false);
  assert.equal(window.document.querySelector('[data-editor-route="review"]').classList.contains("route-inactive"), false);
  assert.equal(calls.filter((call) => call.name === "bridgeFindEvidenceScopes").length, 1, "inference should reuse the completed page revision analysis");
  assert.equal(calls.some((call) => call.name === "bridgePreviewExtraction"), false, "the editor shortcut must not run extraction");
  assert.equal(workspaceCalls.savedEntries.length, 0, "the editor shortcut must not publish an adapter");
  const inferredDraft = workspaceCalls.savedDrafts.at(-1).find((item) => item.id === "auto-draft");
  const fieldEvidence = inferredDraft.editorState.inference.details.fields[0].corroboration;
  assert.ok(fieldEvidence.strong >= 2, "automatic field confidence did not consume per-field corroboration");
  assert.equal(fieldEvidence.weak, 0);
  assert.equal(fieldEvidence.unscored, 0);
  dom.window.close();
});

test("Infer remaining steps stops in Semantics when the inferred type is below threshold", async () => {
  const observations = [
    { selector: ".copy", kind: "text", suggestedName: "field", evidence: { tag: "div", text: "Unclassified content" }, coverage: { present: 4, sampled: 4 } }
  ];
  const candidate = {
    selector: ".results > li", kind: "structure", tag: "li", matchCount: 4, parentCount: 1,
    score: 150, findings: [], observations
  };
  const draft = {
    id: "uncertain-draft", status: "draft", adapterId: null, workingDefinition: null,
    editorState: { pageUrl: "https://example.com/uncertain" }, createdAt: "2026-08-10T00:00:00.000Z", updatedAt: "2026-08-10T00:00:00.000Z"
  };
  const { dom, window, calls, tablePanelCalls } = await loadSidebar({
    workspace: true, tablePanel: true, activeDraftId: draft.id, drafts: [draft],
    evidenceScopeResult: { ok: true, pageUrl: "https://example.com/uncertain", evidenceCount: 12, confidence: "high", margin: 20, candidates: [candidate], chosen: candidate },
    acceptScopeResult: { ok: true, matchCount: 4, sample: { tag: "li", id: null, classes: [], text: "Unclassified content" }, pageUrl: "https://example.com/uncertain" },
    discoveryResult: { ok: true, totalScopes: 4, sampledScopes: 4, truncated: false, candidates: observations }
  });
  await waitFor(() => window.document.querySelector(`[data-draft-id='${draft.id}'] [data-action='open-draft']`), "uncertain draft was not listed");
  window.document.querySelector(`[data-draft-id='${draft.id}'] [data-action='open-draft']`).click();
  await waitFor(() => !window.document.querySelector("#infer-remaining-button").disabled, "uncertain draft was not ready");
  window.document.querySelector("#infer-remaining-button").click();
  await waitForLong(() => /Stopped in Semantics/.test(window.document.querySelector("#infer-remaining-status").textContent), "semantic uncertainty did not stop inference");
  const completed = tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot;
  assert.equal(completed.blocks.length, 1, "the confident structural decision should remain available for manual semantic review");
  assert.equal(completed.inferenceReviewReady, false);
  assert.equal(window.document.querySelector('[data-editor-route="semantics"]').classList.contains("route-inactive"), false);
  assert.equal(calls.filter((call) => call.name === "bridgeDiscoverFields").length >= 1, true);
  assert.equal(calls.some((call) => call.name === "bridgePreviewExtraction"), false);
  dom.window.close();
});

test("Infer remaining steps handles a confident singleton detail page as a collection of one", async () => {
  const observations = [
    { selector: "h1", kind: "text", suggestedName: "headline", evidence: { tag: "h1", text: "How automatic extraction works" }, coverage: { present: 1, sampled: 1 } },
    { selector: "time", kind: "text", suggestedName: "datePublished", evidence: { tag: "time", attribute: "datetime", text: "August 13, 2026" }, coverage: { present: 1, sampled: 1 } },
    { selector: "p:nth-of-type(1)", kind: "text", suggestedName: "articleBody", evidence: { tag: "p", text: "A substantial article body with useful rendered content." }, coverage: { present: 1, sampled: 1 } }
  ];
  const candidate = {
    selector: "article", kind: "structure", tag: "article", matchCount: 1, singleton: true,
    score: 124, findings: [{ kind: "good", message: "A semantic article root contains substantial content." }], observations
  };
  const draft = {
    id: "detail-draft", status: "draft", adapterId: null, workingDefinition: null,
    editorState: { pageUrl: "https://example.com/article" }, createdAt: "2026-08-10T00:00:00.000Z", updatedAt: "2026-08-10T00:00:00.000Z"
  };
  const { dom, window, calls, tablePanelCalls } = await loadSidebar({
    workspace: true, tablePanel: true, activeDraftId: draft.id, drafts: [draft],
    evidenceScopeResult: { ok: true, mode: "single", pageUrl: "https://example.com/article", evidenceCount: 8, confidence: "high", margin: 24, candidates: [candidate], chosen: candidate },
    acceptScopeResult: { ok: true, matchCount: 1, sample: { tag: "article", id: null, classes: [], text: "How automatic extraction works" }, pageUrl: "https://example.com/article" },
    discoveryResult: { ok: true, totalScopes: 1, sampledScopes: 1, truncated: false, candidates: observations },
    variantItemsResult: { ok: true, total: 1, totalScopes: 1, sampledItems: 1, items: [{ index: 0, candidates: [] }] }
  });
  await waitFor(() => window.document.querySelector(`[data-draft-id='${draft.id}'] [data-action='open-draft']`), "detail draft was not listed");
  window.document.querySelector(`[data-draft-id='${draft.id}'] [data-action='open-draft']`).click();
  await waitFor(() => !window.document.querySelector("#infer-remaining-button").disabled, "detail draft was not ready");
  window.document.querySelector("#infer-remaining-button").click();
  await waitForLong(() => /Inference reached Review/.test(window.document.querySelector("#infer-remaining-status").textContent), "singleton inference did not reach Review");
  const completed = tablePanelCalls.messages.filter((message) => message.type === "table-snapshot").at(-1)?.snapshot;
  assert.equal(completed.blocks[0].matchCount, 1);
  assert.equal(completed.blocks[0].schemaType, "Article");
  assert.equal(completed.inferenceReviewReady, true);
  assert.ok(completed.activeBlock.fields.some((field) => field.name === "url" && field.identity), "the detail page URL was not selected as identity");
  assert.doesNotMatch(window.document.querySelector("#inference-review-summary").textContent, /needs a canonical identity/i);
  assert.equal(calls.some((call) => call.name === "bridgePreviewExtraction"), false);
  dom.window.close();
});

test("production Run stops in Structure, preserves automatic provenance, and exposes the failure beside its evidence", async () => {
  const request = {
    version: 1,
    id: "run-structure-stop",
    tabId: 41,
    pageUrl: "https://example.com/jobs",
    intent: "run",
    minimumConfidence: "strong",
    requestedAt: new Date().toISOString()
  };
  const { dom, window, workspaceCalls, sessionStorage } = await loadSidebar({
    workspace: true,
    sidepanel: true,
    sessionStorage: { site2jsonProductionRunRequest: request },
    evidenceScopeResult: {
      ok: true,
      pageUrl: request.pageUrl,
      evidenceCount: 3,
      confidence: "low",
      margin: 1,
      candidates: [],
      chosen: null
    }
  });
  await waitForLong(() => !sessionStorage.site2jsonProductionRunRequest, "production request was not consumed");
  await waitForLong(() => /Automatic conversion stopped in Structure/i.test(window.document.querySelector("#scope-status").textContent), "Structure did not expose the automatic stop");
  const saved = workspaceCalls.savedDrafts.at(-1)?.find((draft) => draft.editorState?.authoring?.origin === "automatic");
  assert.ok(saved, "stopped automatic work was not preserved as an automatic draft");
  assert.equal(saved.editorState.inference.stage, "structure");
  assert.equal(saved.editorState.inference.kind, "error");
  assert.equal(window.document.querySelector('[data-editor-route="structure"]').classList.contains("route-inactive"), false);
  assert.equal(sessionStorage.site2jsonProductionRunResult, undefined, "a below-threshold Run returned extraction data");
  dom.window.close();
});

test("production Run stops in Semantics before field discovery when the inferred type is uncertain", async () => {
  const pageUrl = "https://example.com/mixed";
  const request = {
    version: 1,
    id: "run-semantics-stop",
    tabId: 41,
    pageUrl,
    intent: "run",
    minimumConfidence: "moderate",
    requestedAt: new Date().toISOString()
  };
  const candidate = {
    selector: ".results > li",
    kind: "structure",
    tag: "li",
    matchCount: 4,
    parentCount: 1,
    score: 160,
    findings: [],
    observations: [{ selector: ".copy", kind: "text", suggestedName: "field", evidence: { tag: "div", text: "Unclassified content" } }]
  };
  const { calls, dom, sessionStorage, workspaceCalls, window } = await loadSidebar({
    workspace: true,
    sidepanel: true,
    pageUrl,
    sessionStorage: { site2jsonProductionRunRequest: request },
    evidenceScopeResult: { ok: true, pageUrl, evidenceCount: 20, confidence: "high", margin: 20, candidates: [candidate], chosen: candidate },
    acceptScopeResult: { ok: true, matchCount: 4, sample: { tag: "li", id: null, classes: [], text: "Unclassified content" }, pageUrl }
  });
  await waitForLong(() => workspaceCalls.savedDrafts.some((drafts) => drafts.some((draft) => draft.editorState?.inference?.stage === "semantics")), "uncertain semantic Run was not preserved");
  assert.equal(sessionStorage.site2jsonProductionRunResult, undefined);
  assert.equal(calls.some((call) => call.name === "bridgeDiscoverFields"), false, "field discovery ran before the semantic uncertainty was resolved");
  assert.equal(window.document.querySelector('[data-editor-route="semantics"]').classList.contains("route-inactive"), false);
  assert.match(window.document.querySelector("#infer-remaining-status").textContent, /stopped in Semantics/i);
  dom.window.close();
});

test("production Run bypasses inference for an enabled adapter and returns the requested session intent", async () => {
  const pageUrl = "https://example.com/jobs";
  const existing = AdapterDefinition.buildDraftDefinition({
    adapterId: "example",
    namespace: "https://site2json.dev/ns/example#",
    pageUrl,
    pageId: "collection",
    pageType: "CollectionPage",
    entityName: "JobPosting",
    schemaType: "JobPosting",
    scope: ".job",
    identityField: "url",
    fields: [
      { name: "url", selector: "a", attribute: "href", kind: "url", identity: true },
      { name: "title", selector: "h2", kind: "text" }
    ],
    requireFields: ["title"]
  });
  const request = {
    version: 1,
    id: "run-existing",
    tabId: 41,
    pageUrl,
    intent: "session",
    minimumConfidence: "strong",
    requestedAt: new Date().toISOString()
  };
  const observation = {
    extractedAt: "2026-08-13T12:00:00.000Z",
    pageTitle: "Jobs",
    pageType: "CollectionPage",
    page: {},
    blocks: [{
      id: "collection",
      entity: "JobPosting",
      role: "collection",
      arity: "many",
      fidelity: "summary",
      require: ["title"],
      entities: [{ "@type": "JobPosting", "@id": "https://example.com/jobs/1", url: "https://example.com/jobs/1", title: "First job" }]
    }],
    warnings: []
  };
  const { calls, dom, sessionStorage, tablePanelCalls } = await loadSidebar({
    workspace: true,
    sidepanel: true,
    productionRuntime: true,
    entries: [{ id: "example", enabled: true, definition: existing }],
    sessionStorage: { site2jsonProductionRunRequest: request },
    previewExtractionResult: { ok: true, observation }
  });
  await waitForLong(() => sessionStorage.site2jsonProductionRunResult, "existing adapter did not return a production result");
  const result = sessionStorage.site2jsonProductionRunResult;
  assert.equal(result.requestId, request.id);
  assert.equal(result.intent, "session");
  assert.equal(result.automatic, false);
  assert.equal(result.published, true);
  assert.equal(result.document.blocks[0].entities[0].title, "First job");
  assert.equal(calls.some((call) => call.name === "bridgeFindEvidenceScopes"), false, "an enabled adapter unexpectedly ran inference");
  assert.ok(tablePanelCalls.opened.some((entry) => entry.popup === true), "completed Run did not return control to the popup");
  dom.window.close();
});

test("production Run infers, validates, publishes, and returns extraction when every signal is strong", async () => {
  const pageUrl = "https://example.com/jobs";
  const request = {
    version: 1,
    id: "run-inferred-strong",
    tabId: 41,
    pageUrl,
    intent: "run",
    minimumConfidence: "strong",
    requestedAt: new Date().toISOString()
  };
  const observations = [
    { selector: ".title > a", attribute: "href", kind: "url", suggestedName: "url", coverage: { present: 3, sampled: 3 }, evidence: { tag: "a", attribute: "href", href: "/jobs/1", classes: ["title"], context: "h2 title", matchCounts: [1, 1, 1] } },
    { selector: ".title", kind: "text", suggestedName: "title", coverage: { present: 3, sampled: 3 }, evidence: { tag: "h2", classes: ["title"], text: "Build an API", matchCounts: [1, 1, 1] } },
    { selector: ".posted", kind: "text", suggestedName: "posted", coverage: { present: 3, sampled: 3 }, evidence: { tag: "time", attribute: "datetime", classes: ["posted"], text: "Dec 30, 2025", matchCounts: [1, 1, 1] } },
    { selector: ".budget", kind: "text", suggestedName: "budget", coverage: { present: 3, sampled: 3 }, evidence: { tag: "div", classes: ["budget"], text: "Fixed Price | $500", matchCounts: [1, 1, 1] } }
  ];
  const candidate = {
    selector: ".results > li",
    kind: "structure",
    tag: "li",
    matchCount: 3,
    parentCount: 1,
    consistentKinds: ["url", "heading", "date"],
    identityRatio: 1,
    score: 190,
    findings: [],
    observations
  };
  const observation = {
    extractedAt: "2026-08-13T12:00:00.000Z",
    pageTitle: "Jobs",
    pageType: "CollectionPage",
    page: {},
    blocks: [{
      id: "collection",
      entity: "Results",
      role: "collection",
      arity: "many",
      fidelity: "summary",
      require: [],
      entities: [{ "@type": "JobPosting", "@id": "https://example.com/jobs/1", url: "https://example.com/jobs/1", title: "Build an API", datePosted: "2025-12-30" }]
    }],
    warnings: []
  };
  const { calls, dom, sessionStorage, workspaceCalls, window } = await loadSidebar({
    workspace: true,
    sidepanel: true,
    productionRuntime: true,
    adapterDefinition: AdapterDefinition,
    sessionStorage: { site2jsonProductionRunRequest: request },
    evidenceScopeResult: { ok: true, pageUrl, evidenceCount: 24, confidence: "high", margin: 30, candidates: [candidate], chosen: candidate },
    acceptScopeResult: { ok: true, matchCount: 3, sample: { tag: "li", id: null, classes: [], text: "Build an API" }, pageUrl },
    discoveryResult: { ok: true, totalScopes: 3, sampledScopes: 3, truncated: false, candidates: observations },
    structuralBaselineResult: ({ definition }) => {
      const entity = definition.pages[0].blocks[0].entity;
      return { ok: true, baselines: [{
        version: 1,
        scope: { typical: 3, minimum: 1 },
        variants: {
          [entity]: {
            sampleSize: 3,
            shapes: [{ fingerprint: "s2j1:0123456789abcdef", frequency: 1 }],
            fields: {},
            evidence: []
          }
        }
      }] };
    },
    previewExtractionResult: { ok: true, observation }
  });
  try {
    await waitForLong(() => sessionStorage.site2jsonProductionRunResult || workspaceCalls.savedDrafts.some((drafts) => drafts.some((draft) => draft.editorState?.inference?.kind === "error")), "strong automatic inference did not complete");
  } catch {
    const text = (selector) => window.document.querySelector(selector)?.textContent || "";
    assert.fail(`strong automatic inference did not complete; request=${Boolean(sessionStorage.site2jsonProductionRunRequest)}; draft=${text("#draft-status")}; scope=${text("#scope-status")}; semantic=${text("#semantics-status")}; discover=${text("#discovery-status")}; build=${text("#build-status")}; calls=${calls.map((call) => call.name).join(",")}`);
  }
  const stopped = workspaceCalls.savedDrafts.flat().find((draft) => draft.editorState?.inference?.kind === "error");
  assert.ok(sessionStorage.site2jsonProductionRunResult, `strong automatic inference stopped unexpectedly: ${stopped?.editorState?.inference?.message || "unknown error"}`);
  const result = sessionStorage.site2jsonProductionRunResult;
  assert.equal(result.requestId, request.id);
  assert.equal(result.automatic, true);
  assert.equal(result.published, true);
  assert.equal(result.decision, AutomaticConversion.OUTCOMES.PUBLISH_AND_DOWNLOAD);
  assert.equal(result.document.blocks[0].entities[0].title, "Build an API");
  assert.ok(workspaceCalls.savedEntries.some((entries) => entries.some((entry) => entry.id === "example")), "strong automatic adapter was not published locally");
  assert.equal(calls.filter((call) => call.name === "bridgeFindEvidenceScopes").length, 1);
  dom.window.close();
});

test("production Run rejects a stale page revision before accepting its inferred scope", async () => {
  const pageUrl = "https://example.com/jobs";
  const request = {
    version: 1,
    id: "run-stale-page",
    tabId: 41,
    pageUrl,
    intent: "run",
    minimumConfidence: "strong",
    requestedAt: new Date().toISOString()
  };
  const candidate = {
    selector: ".results > li",
    kind: "structure",
    tag: "li",
    matchCount: 3,
    parentCount: 1,
    consistentKinds: ["url", "heading", "date"],
    identityRatio: 1,
    score: 190,
    findings: [],
    observations: [
      { selector: ".title > a", kind: "url", suggestedName: "url", evidence: { tag: "a", attribute: "href", href: "/jobs/1", classes: ["title"], context: "h2 title" } },
      { selector: ".title", kind: "text", suggestedName: "title", evidence: { tag: "h2", classes: ["title"], text: "Build an API" } },
      { selector: ".posted", kind: "text", suggestedName: "posted", evidence: { tag: "time", attribute: "datetime", classes: ["posted"], text: "Dec 30, 2025" } }
    ]
  };
  let revision = 0;
  const { calls, dom, sessionStorage, workspaceCalls, window } = await loadSidebar({
    workspace: true,
    sidepanel: true,
    sessionStorage: { site2jsonProductionRunRequest: request },
    pageAnalysisContext: () => ({ ok: true, pageUrl, frameUrl: pageUrl, revision: revision++ }),
    evidenceScopeResult: { ok: true, pageUrl, evidenceCount: 24, confidence: "high", margin: 30, candidates: [candidate], chosen: candidate }
  });
  await waitForLong(() => workspaceCalls.savedDrafts.some((drafts) => drafts.some((draft) => draft.editorState?.inference?.stage === "structure")), "stale automatic run was not preserved");
  assert.equal(sessionStorage.site2jsonProductionRunResult, undefined);
  assert.equal(calls.some((call) => call.name === "bridgeAcceptScope"), false, "stale analysis accepted a scope from an old document revision");
  assert.match(window.document.querySelector("#scope-status").textContent, /document changed/i);
  dom.window.close();
});

test("creates a typed block, renders its table, and pins table-driven highlights", async () => {
  const { calls, dom, window } = await loadSidebar();
  const document = window.document;
  document.querySelector("#pick-scope-button").click();
  await waitFor(() => document.querySelector("#scope-levels .option-item"), "scope proposal was not rendered");
  document.querySelector("#scope-use-preview-button").click();
  await waitFor(() => !document.querySelector("#block-setup").hidden, "block setup was not shown");
  document.querySelector("#block-schema-type").value = "RealEstate";
  document.querySelector("#block-schema-type").dispatchEvent(new window.Event("input", { bubbles: true }));
  assert.ok(Array.from(document.querySelectorAll("#schema-type-menu .combobox-option strong")).some((item) => item.textContent === "RealEstateListing"));
  document.querySelector("#block-name").value = "Jobs";
  document.querySelector("#block-schema-type").value = "JobPosting";
  document.querySelector("#create-block-button").click();
  await waitFor(() => document.querySelectorAll("#block-table-head .item-column-header").length === 2, "block table was not rendered");

  assert.equal(document.querySelector("#active-block-title").textContent, "Jobs");
  assert.match(document.querySelector("#active-block-meta").textContent, /JobPosting/);
  assert.equal(document.querySelectorAll("#block-picker option").length, 1);
  assert.equal(document.querySelector("#block-picker").value, "block-1");

  addSelectedField(document);
  await waitFor(() => !document.querySelector("#field-form").hidden, "field editor was not shown");
  document.querySelector("#field-name").value = "title";
  document.querySelector("#add-field-button").click();
  await waitFor(() => fieldColumn(document, "title"), "field column was not added");
  assert.deepEqual(Array.from(document.querySelectorAll("#block-table-head .item-column-header"), (cell) => cell.textContent), ["1", "2"]);
  assert.equal(document.querySelectorAll("#block-table-body tr").length, 1, "mapped fields should render as rows");
  assert.equal(document.body.classList.contains("field-editor-open"), false);
  assert.equal(document.querySelector("#field-list"), null);
  assert.equal(document.querySelector("#block-table-head").textContent.includes("Item"), false);
  const titleHeader = fieldColumn(document, "title");
  titleHeader.click();
  await waitFor(() => calls.some((call) => call.name === "bridgeHighlightSelector" && call.args.channel === "pinned" && call.args.selector === ".title"), "column click did not pin its source highlights");
  await waitFor(() => calls.some((call) => call.name === "bridgeRevealTarget" && call.args.withinSelector === ".results > li" && call.args.selector === ".title"), "column click did not reveal its first field node in Elements");
  assert.equal(document.querySelector("#clear-pinned-highlight-button").disabled, false);

  document.querySelectorAll("#block-table-head .item-column-header")[1].click();
  await waitFor(() => calls.some((call) => call.name === "bridgeRevealTarget" && call.args.selector === ".results > li" && call.args.matchIndex === 1), "row click did not reveal the exact scope node");
  titleHeader.parentElement.children[2].click();
  await waitFor(() => calls.some((call) => call.name === "bridgeRevealTarget" && call.args.withinSelector === ".results > li" && call.args.rootIndex === 1 && call.args.selector === ".title"), "cell click did not reveal the exact field node within its row");

  titleHeader.dispatchEvent(new window.MouseEvent("mouseenter"));
  await waitFor(() => calls.some((call) => call.name === "bridgeHighlightSelector" && call.args.channel === "transient" && call.args.withinSelector === ".results > li" && call.args.selector === ".title"), "field row hover did not preview its source nodes");
  titleHeader.click();
  await waitFor(() => calls.some((call) => call.name === "bridgeHighlightSelector" && call.args.channel === "pinned" && call.args.withinSelector === ".results > li" && call.args.selector === ".title"), "field row click did not pin its source nodes");
  await waitFor(() => calls.filter((call) => call.name === "bridgeRevealTarget" && call.args.withinSelector === ".results > li" && call.args.selector === ".title").length >= 2, "field row click did not reveal its representative node");

  const pinCallsBeforeEdit = calls.filter((call) => call.name === "bridgeHighlightSelector" && call.args.channel === "pinned").length;
  const previewsBeforeEdit = calls.filter((call) => call.name === "bridgePreviewField").length;
  titleHeader.querySelector(".edit").click();
  assert.equal(document.body.classList.contains("field-editor-open"), true);
  assert.equal(document.querySelector("#field-editor-title").textContent, "Edit title");
  assert.equal(calls.filter((call) => call.name === "bridgeHighlightSelector" && call.args.channel === "pinned").length, pinCallsBeforeEdit, "Edit should not also trigger the field row's pinned highlight action");
  await waitFor(() => calls.filter((call) => call.name === "bridgePreviewField").length > previewsBeforeEdit, "edited field preview did not finish");
  await settleAsyncUi();
  dom.window.close();
});

test("single-item mode accepts a unique detail scope while keeping collection-shaped blocks", async () => {
  const best = {
    selector: "article.detail", kind: "class", matchCount: 1, siblingMatchCount: 1,
    parentCount: 1, findings: [{ kind: "good", message: "Selector identifies one rendered item." }]
  };
  const options = {
    scopeResult: { ok: true, mode: "single", levels: [{ depth: 0, tag: "article", best }], chosen: best },
    acceptScopeResult: {
      ok: true, matchCount: 1,
      sample: { tag: "article", id: null, classes: ["detail"], text: "Solo article" },
      pageUrl: "https://example.com/article/solo"
    }
  };
  const { calls, dom, window } = await loadSidebar(options);
  const document = window.document;
  document.querySelector("#single-item-scope").checked = true;
  document.querySelector("#single-item-scope").dispatchEvent(new window.Event("change", { bubbles: true }));
  assert.equal(document.querySelector("#pick-scope-button").textContent, "Create single-item scope");
  assert.match(document.querySelector("#scope-status").textContent, /Single-item mode enabled/);
  document.querySelector("#pick-scope-button").click();
  await waitFor(() => document.querySelector("#scope-levels .option-item"), "single scope proposal was not rendered");
  assert.ok(calls.some((call) => call.name === "bridgeInferScope" && call.args.allowSingle === true));
  document.querySelector("#scope-use-preview-button").click();
  await waitFor(() => !document.querySelector("#block-setup").hidden, "single block setup was not shown");
  assert.equal(document.querySelector("#scope-cardinality"), null, "cardinality should not alter the collection data shape");
  document.querySelector("#block-name").value = "Article";
  document.querySelector("#block-schema-type").value = "Article";
  document.querySelector("#create-block-button").click();
  await waitFor(() => !document.querySelector("#structure-complete").hidden, "single block was not created");
  assert.match(document.querySelector("#structure-complete-summary").textContent, /1 matching item.*collection of Article items/);
  dom.window.close();
});

test("turning single-item mode off restores the existing repeating-scope detection", async () => {
  const { dom, window } = await loadSidebar();
  const document = window.document;
  const toggle = document.querySelector("#single-item-scope");

  document.querySelector("#pick-scope-button").click();
  await waitFor(() => document.querySelector("#scope-levels .option-item"), "repeating scope proposal was not rendered");
  const originalSelector = document.querySelector("#scope-levels code").textContent;
  const originalStatus = document.querySelector("#scope-status").textContent;

  toggle.checked = true;
  toggle.dispatchEvent(new window.Event("change", { bubbles: true }));
  assert.equal(document.querySelector("#scope-levels .option-item"), null, "repeating proposals should be hidden while entering single-item mode");

  toggle.checked = false;
  toggle.dispatchEvent(new window.Event("change", { bubbles: true }));
  assert.equal(document.querySelector("#scope-levels code").textContent, originalSelector);
  assert.equal(document.querySelector("#scope-status").textContent, originalStatus);
  assert.equal(document.querySelector("#scope-levels .selected code").textContent, originalSelector);
  dom.window.close();
});

async function createJobBlock(document) {
  document.querySelector("#pick-scope-button").click();
  await waitFor(() => document.querySelector("#scope-levels .option-item"), "scope proposal was not rendered");
  document.querySelector("#scope-use-preview-button").click();
  await waitFor(() => !document.querySelector("#block-setup").hidden, "block setup was not shown");
  document.querySelector("#block-schema-type").value = "JobPosting";
  document.querySelector("#create-block-button").click();
  await waitFor(() => document.querySelectorAll("#block-table-head .item-column-header").length === 2, "block table was not rendered");
}

test("routes a new block through explicit semantic review before discovery", async () => {
  const { dom, window } = await loadSidebar();
  const document = window.document;
  assert.ok(document.querySelector("[data-workflow-step='structure']").classList.contains("selected"));
  assert.ok(document.querySelector("#step-semantics").classList.contains("route-inactive"));

  await createJobBlock(document);
  assert.ok(document.querySelector("[data-workflow-step='structure']").classList.contains("selected"));
  assert.equal(document.querySelector("#structure-complete").hidden, false);
  assert.match(document.querySelector("#structure-complete-title").textContent, /Results.*semantic review/);
  assert.match(document.querySelector("#draft-status").textContent, /changes are autosaved/i);
  assert.doesNotMatch(document.querySelector("#draft-status").textContent, /select a rendered item/i);
  await waitFor(() => document.activeElement === document.querySelector("#continue-semantics-button"), "Structure completion action was not focused");
  document.querySelector("#continue-semantics-button").click();
  assert.ok(document.querySelector("[data-workflow-step='semantics']").classList.contains("selected"));
  assert.equal(document.querySelector("#step-semantics").classList.contains("route-inactive"), false);
  assert.ok(document.querySelector("#step-selection").classList.contains("route-inactive"));
  assert.match(document.querySelector("#semantic-model-summary").textContent, /JobPosting/);
  assert.match(document.querySelector("#semantic-model-status").textContent, /Choose the highlighted model/);
  assert.equal(document.querySelector("#confirm-semantics-button").disabled, false);

  document.querySelector("#confirm-semantics-button").click();
  await waitFor(() => document.querySelector("[data-workflow-step='discover']").classList.contains("selected"), "semantic confirmation did not advance to discovery");
  assert.equal(document.querySelector("#step-fields").classList.contains("route-inactive"), false);
  assert.ok(document.querySelector("#step-semantics").classList.contains("route-inactive"));
  dom.window.close();
});

test("shows initial semantic suggestions and makes model changes and refreshes visible", async () => {
  const observations = [
    { selector: ".title > a", kind: "url", suggestedName: "url", evidence: { tag: "a", attribute: "href", href: "/jobs/1", classes: ["title"], context: "h2 title" }, coverage: { present: 2, sampled: 2 } },
    { selector: ".title", kind: "text", suggestedName: "title", evidence: { tag: "h2", classes: ["title"], text: "Build an API" }, coverage: { present: 2, sampled: 2 } },
    { selector: ".posted", kind: "text", suggestedName: "datePosted", evidence: { tag: "span", classes: ["posted"], text: "Posted Dec 30, 2025" }, coverage: { present: 2, sampled: 2 } },
    { selector: ".budget", kind: "text", suggestedName: "budget", evidence: { tag: "div", classes: ["budget"], text: "Fixed Price | $500" }, coverage: { present: 2, sampled: 2 } }
  ];
  const { calls, dom, window } = await loadSidebar({
    discoveryResult: { ok: true, totalScopes: 2, sampledScopes: 2, truncated: false, candidates: observations }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#continue-semantics-button").click();

  const suggestions = Array.from(document.querySelectorAll("#semantic-ranking-summary .semantic-model-option"));
  assert.ok(suggestions.length > 0, "initial scope evidence did not render semantic suggestions");
  assert.match(document.querySelector("#semantic-ranking-summary").textContent, /Suggested for this page/);
  assert.equal(document.querySelectorAll("#semantic-ranking-summary .semantic-model-option.selected").length, 1);
  assert.match(document.querySelector("#semantic-ranking-summary .semantic-model-option.selected").textContent, /Selected/);

  const input = document.querySelector("#semantic-model-input");
  input.value = "Thing";
  input.dispatchEvent(new window.Event("input", { bubbles: true }));
  assert.match(document.querySelector("#semantic-ranking-summary").textContent, /Matching models/);
  document.querySelector('.semantic-model-option[data-model-id="schema:Thing"]').click();
  await waitFor(() => document.querySelector('.semantic-model-option.selected')?.dataset.modelId === "schema:Thing", "choosing a result did not visibly change the selected model");
  assert.equal(input.value, "", "choosing a model should restore the ranked list");
  assert.match(document.querySelector("#semantic-model-status").textContent, /Selected Thing/);
  assert.match(document.querySelector("#semantic-model-summary").textContent, /Thing/);

  const rankedIds = Array.from(document.querySelectorAll(".semantic-model-option"), (option) => option.dataset.modelId);
  input.value = "Organization";
  input.dispatchEvent(new window.Event("input", { bubbles: true }));
  assert.match(document.querySelector("#semantic-ranking-summary").textContent, /Matching models/);
  input.value = "";
  input.dispatchEvent(new window.Event("input", { bubbles: true }));
  assert.deepEqual(Array.from(document.querySelectorAll(".semantic-model-option"), (option) => option.dataset.modelId), rankedIds, "clearing search did not restore the preselected ranked list");

  const selectedBeforeRefresh = document.querySelector(".semantic-model-option.selected").dataset.modelId;
  const scansBeforeRefresh = calls.filter((call) => call.name === "bridgeDiscoverFields").length;
  document.querySelector("#analyze-semantics-button").click();
  await waitFor(() => calls.filter((call) => call.name === "bridgeDiscoverFields").length > scansBeforeRefresh, "refresh did not rescan rendered items");
  await waitFor(() => calls.some((call) => call.name === "scrollIntoView" && call.elementId === "semantic-ranking-summary"), "refreshed suggestions were not scrolled into view");
  await waitFor(() => document.activeElement?.classList.contains("semantic-model-option"), "refreshed suggestions did not receive focus");
  assert.equal(document.querySelector(".semantic-model-option.selected").dataset.modelId, selectedBeforeRefresh, "refreshing suggestions changed the selected model");

  const suggestion = Array.from(document.querySelectorAll("#semantic-ranking-summary .semantic-model-option")).find((option) => !option.classList.contains("selected"));
  const suggestionLabel = suggestion.querySelector("strong").textContent;
  const suggestionId = suggestion.dataset.modelId;
  suggestion.click();
  await waitFor(() => document.querySelector(`.semantic-model-option[data-model-id="${suggestionId}"]`)?.classList.contains("selected"), "chosen suggestion was not marked as current");
  assert.equal(document.querySelector(".semantic-model-option.selected strong").textContent, suggestionLabel);
  assert.match(document.querySelector("#semantic-model-status").textContent, new RegExp(`Selected ${suggestionLabel}`));
  dom.window.close();
});

test("detects mixed item types and only saves graph candidates with deterministic evidence", async () => {
  const analysis = {
    status: "ready", sampledItems: 3, mixed: true, ambiguousCount: 1,
    thresholds: { minScore: 6, minMargin: 2 },
    candidates: [
      { schemaType: "JobPosting", count: 2, averageScore: 18, entityName: "JobPostingResult", evidence: [{ selector: ".job", weight: 10 }] },
      { schemaType: "Person", count: 1, averageScore: 16, entityName: "PersonResult", evidence: [{ selector: ".person", weight: 10 }] },
      { schemaType: "Organization", count: 1, averageScore: 11, entityName: "OrganizationResult", evidence: [] }
    ],
    rows: [
      { index: 0, winner: { schemaType: "JobPosting" }, ambiguous: false },
      { index: 1, winner: { schemaType: "Person" }, ambiguous: false },
      { index: 2, winner: { schemaType: "Organization" }, ambiguous: true }
    ]
  };
  const { dom, window, calls } = await loadSidebar({
    variantItemsResult: { ok: true, total: 3, sampledItems: 3, items: [{}, {}, {}] },
    variantAnalysis: { analyze: () => structuredClone(analysis) },
    variantClassificationResult: {
      ok: true, total: 3, sampled: 3,
      counts: [
        { entityName: "JobPostingResult", schemaType: "JobPosting", count: 2, fallback: true },
        { entityName: "PersonResult", schemaType: "Person", count: 1, fallback: false }
      ],
      ambiguousCount: 1, unclassifiedCount: 0,
      rows: [
        { index: 0, label: "First job", status: "classified", winner: { entityName: "PersonResult", schemaType: "Person", score: 10, margin: 10 }, fallback: { entityName: "JobPostingResult", schemaType: "JobPosting" }, alternatives: [] },
        { index: 1, label: "Second job", status: "classified", winner: { entityName: "PersonResult", schemaType: "Person", score: 10, margin: 10 }, fallback: { entityName: "JobPostingResult", schemaType: "JobPosting" }, alternatives: [] },
        { index: 2, label: "Conflicted result", status: "ambiguous", winner: null, fallback: { entityName: "JobPostingResult", schemaType: "JobPosting" }, alternatives: [{ entityName: "OrganizationResult", schemaType: "Organization", score: 10 }, { entityName: "PersonResult", schemaType: "Person", score: 9 }] }
      ]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#continue-semantics-button").click();
  await waitFor(() => /3 result types detected/.test(document.querySelector("#semantic-variants-title").textContent), "initial variant analysis was not rendered automatically");
  assert.equal(document.querySelector("#analyze-variants-button").textContent, "Refresh item types");
  const initialScans = calls.filter((call) => call.name === "bridgeDiscoverVariantItems");
  assert.ok(initialScans.length > 0, "creating the block did not inspect item types");
  assert.deepEqual(
    { itemLimit: initialScans[0].args.itemLimit, elementLimit: initialScans[0].args.elementLimit, fast: initialScans[0].args.fast },
    { itemLimit: 24, elementLimit: 160, fast: true }
  );
  document.querySelector("#analyze-variants-button").click();
  await waitFor(() => /3 result types detected/.test(document.querySelector("#semantic-variants-title").textContent), "variant analysis was not rendered");
  assert.ok(calls.some((call) => call.name === "bridgeDiscoverVariantItems"), "variant analysis did not inspect items independently");
  assert.equal(document.querySelector("#apply-variants-button").disabled, false);
  assert.match(document.querySelector("#semantic-variants-status").textContent, /ready for field discovery/);
  assert.equal(document.querySelector("#variant-classification-review").hidden, false);
  assert.match(document.querySelector("#variant-classification-summary").textContent, /1 ambiguous/);
  assert.match(document.querySelector("#variant-classification-issues").textContent, /Result 3/);
  document.querySelector("#variant-classification-issues button").click();
  assert.equal(document.querySelector("#variant-resolution-form").hidden, false);
  document.querySelector("#variant-resolution-type").value = "Organization";
  document.querySelector("#variant-resolution-form").dispatchEvent(new window.Event("submit", { bubbles: true, cancelable: true }));
  await waitFor(() => calls.some((call) => call.name === "bridgeCaptureVariantEvidence" && call.args.rootIndex === 2), "resolution did not capture evidence from the selected issue");
  document.querySelector("#apply-variants-button").click();
  await waitFor(() => !document.querySelector("#clear-variants-button").hidden, "saved variant controls were not shown");
  assert.match(document.querySelector("#semantic-model-status").textContent, /Choose the highlighted model/);
  const picker = document.querySelector("#discovery-variant-picker");
  assert.equal(document.querySelector("#discovery-variant-label").hidden, false);
  picker.value = "PersonResult";
  picker.dispatchEvent(new window.Event("change", { bubbles: true }));
  await waitFor(() => calls.some((call) => call.name === "bridgeBuildBlockTable" && call.args.variantTarget === "PersonResult"), "Review did not switch to the Person population");
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => calls.some((call) => call.name === "bridgeDiscoverFields" && call.args.variantTarget === "PersonResult"), "Discovery did not scope itself to the Person population");
  assert.match(document.querySelector("#discovery-variant-summary").textContent, /classified as Person/);
  document.querySelector("#clear-variants-button").click();
  await waitFor(() => document.querySelector("#clear-variants-button").hidden, "single-model mode did not remove saved variants");
  dom.window.close();
});

test("page and per-item inference include every installed Semantic Library type", async () => {
  const types = ["Editor", "EditorialProject"].map((name) => ({
    id: `import:test:customType:${name}`,
    termId: `guru:${name}`,
    label: name,
    description: `A Guru ${name.toLowerCase()} result.`,
    definition: {
      kind: "type", description: `A Guru ${name.toLowerCase()} result.`, valueType: `guru:${name}`,
      cardinality: "one", example: name, canonicalUri: `https://example.test/guru#${name}`, supers: ["Thing"]
    },
    provenance: { canonicalUri: `https://example.test/guru#${name}`, source: { kind: "test", id: "guru" } }
  }));
  const service = {
    async search() { return { items: types.map((record) => ({ kind: "customType", id: record.id })), total: types.length, nextCursor: null }; },
    async getCustomTypes({ ids }) { return types.filter((record) => ids.includes(record.id)); },
    async getTerms() { return []; },
    async getPatterns() { return []; }
  };
  const item = (name, index) => {
    const marker = `${name.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()}-marker`;
    return {
      index,
      candidates: [{ selector: `.${marker}`, selectorKind: "class", suggestedName: "type", evidence: { tag: "article", classes: [marker], text: "" } }]
    };
  };
  const { dom, window } = await loadSidebar({
    semanticLibraryService: service,
    variantItemsResult: { ok: true, totalScopes: 2, sampledItems: 2, items: [item("Editor", 0), item("EditorialProject", 1)] }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#continue-semantics-button").click();
  await waitFor(() => /2 result types detected/.test(document.querySelector("#semantic-variants-title").textContent), `installed custom types did not participate in variant inference: ${document.querySelector("#semantic-variants-title").textContent} / ${document.querySelector("#semantic-variants-status").textContent}`);
  document.querySelector("#apply-variants-button").click();
  await waitFor(() => !document.querySelector("#clear-variants-button").hidden, "inferred local variants were not applied");
  assert.match(document.querySelector("#discovery-variant-picker").textContent, /example:Editor/);
  assert.match(document.querySelector("#discovery-variant-picker").textContent, /example:EditorialProject/);
  dom.window.close();
});

test("authors Schema.org and custom relationships in the normal Semantics interface", async () => {
  const { dom, window } = await loadSidebar({
    discoveryResult: {
      ok: true, totalScopes: 2, sampledScopes: 2, truncated: false,
      candidates: [{
        selector: ".editor", attribute: null, kind: "text", multiple: false, suggestedName: "editor",
        evidence: { tag: "span", id: null, classes: ["editor"], text: "Jane Smith", context: "div editor", href: null, multiple: false },
        coverage: { present: 2, sampled: 2 }, selectorKind: "class"
      }]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#continue-semantics-button").click();
  assert.equal(document.querySelector("#semantic-advanced-view").hidden, true);
  assert.equal(document.querySelector("#semantic-selection-view").hidden, false);
  assert.match(document.querySelector("#semantic-overview-counts").textContent, /nodes? · \d+ relationships?/);
  document.querySelector("#open-semantic-advanced").click();
  assert.equal(document.querySelector("#semantic-advanced-view").hidden, false);
  assert.equal(document.querySelector("#semantic-selection-view").hidden, true);
  await waitFor(() => document.activeElement === document.querySelector("#close-semantic-advanced"), "Advanced editor Back action was not focused");

  const from = document.querySelector("#semantic-relation-from");
  const property = document.querySelector("#semantic-relation-property");
  assert.equal(from.value, "listing");
  assert.ok(Array.from(property.options, (option) => option.value).includes("hiringOrganization"));
  property.value = "hiringOrganization";
  property.dispatchEvent(new window.Event("change", { bubbles: true }));
  assert.equal(document.querySelector("#semantic-relation-type").value, "Organization");
  document.querySelector("#semantic-relation-alias").value = "employer";
  document.querySelector("#semantic-relation-alias").dispatchEvent(new window.Event("input", { bubbles: true }));
  document.querySelector("#semantic-add-relationship-button").click();
  await waitFor(() => document.querySelectorAll("#semantic-node-list .semantic-node").length === 2, "related node was not added");
  assert.match(document.querySelector("#semantic-edge-list").textContent, /listing.*hiringOrganization.*employer/);

  document.querySelector("#semantic-edge-list .semantic-remove").click();
  await waitFor(() => document.querySelectorAll("#semantic-node-list .semantic-node").length === 1, "removing the relationship did not prune its unreachable node");

  property.value = "__custom__";
  property.dispatchEvent(new window.Event("change", { bubbles: true }));
  assert.equal(document.querySelector("#semantic-custom-relationship").hidden, false);
  document.querySelector("#semantic-relation-type").value = "Person";
  document.querySelector("#semantic-relation-type").dispatchEvent(new window.Event("input", { bubbles: true }));
  document.querySelector("#semantic-relation-alias").value = "editor";
  document.querySelector("#semantic-custom-term").value = "example:editor";
  document.querySelector("#semantic-custom-description").value = "The person responsible for editing this listing.";
  document.querySelector("#semantic-custom-aliases").value = "editor, edited by";
  document.querySelector("#semantic-add-relationship-button").click();
  await waitFor(() => /example:editor/.test(document.querySelector("#semantic-edge-list").textContent), "custom relationship was not added");
  assert.match(document.querySelector("#semantic-model-status").textContent, /Added example:editor relationship/);

  document.querySelector("#close-semantic-advanced").click();
  assert.equal(document.querySelector("#semantic-advanced-view").hidden, true);
  assert.match(document.querySelector("#semantic-overview-counts").textContent, /2 nodes · 1 relationship/);
  document.querySelector("#confirm-semantics-button").click();
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => fieldColumn(document, "example:editor.name"), "Discovery did not use the custom relationship vocabulary");
  dom.window.close();
});

test("nested variant Attention opens the resolver, persists evidence, reclassifies, and clears", async () => {
  const draft = {
    id: "nested-evidence", status: "draft", adapterId: null, workingDefinition: null,
    editorState: {
      pageUrl: "https://example.com/search", adapterId: "nested", namespace: "https://example.com/ns#",
      pageId: "search", pageType: "SearchResultsPage", customTerms: {},
      blocks: [{
        id: "results", name: "Results", entityName: "SearchResultsPage", schemaType: "SearchResultsPage",
        scope: ".results > li", arity: "many", role: "collection", fidelity: "summary", matchCount: 2,
        identityField: "url",
        fields: [
          { name: "url", selector: ".title", attribute: "href", kind: "url", multiple: false, transform: ["absoluteUrl"], identity: true, locked: true, unresolved: false },
          { name: "mainEntity.url", selector: ".title", attribute: "href", kind: "url", multiple: false, transform: ["absoluteUrl"], locked: true, unresolved: false },
          { name: "mainEntity.name", selector: ".title", attribute: null, kind: "text", multiple: false, transform: ["text", "trim"], locked: true, unresolved: false }
        ],
        requireFields: [], monitorFields: [], semanticsReviewed: true,
        composition: {
          id: "test:nested-results", label: "Nested search results", root: "listing",
          nodes: {
            listing: { types: ["SearchResultsPage"], expectation: "core" },
            result: {
              types: ["Thing"], expectation: "common",
              variants: {
                fallback: "Thing", minScore: 10, minMargin: 3,
                candidates: [{ type: "Article", evidence: [] }, { type: "JobPosting", evidence: [] }]
              }
            }
          },
          edges: [{ from: "listing", property: "mainEntity", to: "result", expectation: "common" }]
        }
      }]
    },
    createdAt: "2026-08-14T12:00:00.000Z", updatedAt: "2026-08-14T12:00:00.000Z"
  };
  let classificationPass = 0;
  const nestedVariantClassificationResult = (args) => {
    classificationPass += 1;
    const slot = args.slots[0];
    const article = slot.runtime.slot.candidates.find((candidate) => candidate.entity.includes("Article"));
    const job = slot.runtime.slot.candidates.find((candidate) => candidate.entity.includes("JobPosting"));
    const classified = classificationPass > 1 && article.evidence.some((rule) => rule.selector === ".article-marker");
    const row = classified
      ? {
          rootIndex: 0, slotPath: slot.path, label: "Article result", status: "classified",
          winner: { entityName: article.entity, schemaType: "Article", score: 20, shapeScore: 10, evidenceScore: 10, margin: 10 },
          fallback: { entityName: slot.runtime.slot.fallback, schemaType: "Thing" },
          alternatives: [{ entityName: article.entity, schemaType: "Article", score: 20, shapeScore: 10, evidenceScore: 10 }],
          classification: { accepted: true, reason: "candidate", winner: { entityName: article.entity, schemaType: "Article", score: 20 }, runnerUp: { entityName: job.entity, schemaType: "JobPosting", score: 10 }, margin: 10 }
        }
      : {
          rootIndex: 0, slotPath: slot.path, label: "Ambiguous result", status: "ambiguous", winner: null,
          fallback: { entityName: slot.runtime.slot.fallback, schemaType: "Thing" },
          alternatives: [
            { entityName: article.entity, schemaType: "Article", score: 10, shapeScore: 10, evidenceScore: 0 },
            { entityName: job.entity, schemaType: "JobPosting", score: 10, shapeScore: 10, evidenceScore: 0 }
          ],
          classification: { accepted: false, reason: "ambiguous", winner: { entityName: article.entity, schemaType: "Article", score: 10 }, runnerUp: { entityName: job.entity, schemaType: "JobPosting", score: 10 }, margin: 0 }
        };
    return {
      ok: true, sampled: 1, total: 1,
      slots: [{ path: slot.path, nodeAlias: slot.nodeAlias, sampled: 1, total: 1, ambiguousCount: classified ? 0 : 1, unclassifiedCount: 0, counts: [], rows: [row] }]
    };
  };
  const { calls, dom, window } = await loadSidebar({
    workspace: true, drafts: [draft], adapterDefinition: AdapterDefinition,
    discoveryResult: { ok: true, totalScopes: 1, sampledScopes: 1, truncated: false, candidates: [] },
    nestedVariantClassificationResult,
    variantEvidenceResult: { ok: true, rule: { selector: ".article-marker", weight: 10 }, label: ".article-marker is present" }
  });
  const document = window.document;
  await waitFor(() => document.querySelector("[data-draft-id='nested-evidence'] [data-action='open-draft']"), "nested draft was not listed");
  document.querySelector("[data-draft-id='nested-evidence'] [data-action='open-draft']").click();
  await waitFor(() => document.querySelector("#draft-status").textContent.includes("Editing autosaved draft"), "nested draft did not open");
  await waitFor(() => document.querySelector("#block-picker option[value='results']"), "nested block did not activate");
  document.querySelector("[data-workflow-step='discover']").click();
  await waitFor(() => !document.querySelector("#discover-fields-button").disabled, "nested discovery did not become available");
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => !document.querySelector("#site2json-attention-button").hidden, "nested ambiguity did not create Attention");
  document.querySelector("#site2json-attention-button").click();
  const visit = document.querySelector("#site2json-attention-list .site2json-attention-visit");
  assert.match(visit.textContent, /mainEntity.*need distinguishing evidence/);
  visit.click();
  await waitFor(() => !document.querySelector("#variant-resolution-form").hidden, "Attention did not open the nested resolver");
  assert.match(document.querySelector("#variant-resolution-title").textContent, /mainEntity.*result 1/);
  assert.equal(document.querySelector("#variant-resolution-type").value, "Article");
  document.querySelector("#variant-resolution-form").dispatchEvent(new window.Event("submit", { bubbles: true, cancelable: true }));
  await waitFor(() => classificationPass === 2, "saving evidence did not reclassify the affected nested slot");
  await waitFor(() => document.querySelector("#site2json-attention-button").hidden, "resolved nested evidence did not clear Attention");
  const classificationCalls = calls.filter((call) => call.name === "bridgeClassifyNestedVariantSlots");
  assert.equal(classificationCalls.length, 2);
  assert.equal(classificationCalls[1].args.slots.length, 1);
  assert.deepEqual(classificationCalls[1].args.slots[0].runtime.slot.candidates.find((candidate) => candidate.entity.includes("Article")).evidence, [{ selector: ".article-marker", weight: 10 }]);
  assert.ok(calls.some((call) => call.name === "bridgeCaptureVariantEvidence" && call.args.rootIndex === 0));
  dom.window.close();
});

test("Discovery ends with an explicit handoff to separate mapped and unresolved Review tables", async () => {
  const { calls, dom, window } = await loadSidebar({
    discoveryResult: {
      ok: true, totalScopes: 2, sampledScopes: 2, truncated: false,
      candidates: [{
        selector: ".title-link", attribute: "href", kind: "url", multiple: false, suggestedName: "url",
        coverage: { present: 2, sampled: 2 }, selectorKind: "class",
        evidence: { tag: "a", attribute: "href", id: null, classes: ["title-link"], text: "First job", context: "h2 title", href: "/jobs/1", multiple: false, matchCounts: [1, 1] }
      }, {
        selector: ".title", attribute: null, kind: "text", multiple: false, suggestedName: "title",
        coverage: { present: 2, sampled: 2 }, selectorKind: "class",
        evidence: { tag: "h2", id: null, classes: ["title"], text: "First job", context: "h2 title", href: null, multiple: false }
      }, {
        selector: ".internal-code", attribute: null, kind: "text", multiple: false, suggestedName: "internalCode",
        coverage: { present: 2, sampled: 2 }, selectorKind: "class",
        evidence: { tag: "span", id: null, classes: ["internal-code"], text: "ABC-1", context: "span internal-code", href: null, multiple: false }
      }]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#continue-semantics-button").click();
  document.querySelector("#confirm-semantics-button").click();
  await waitFor(() => document.querySelector("[data-workflow-step='discover']").classList.contains("selected"), "workflow did not enter Discovery");
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => !document.querySelector("#discovery-complete").hidden, "Discovery completion handoff did not appear");
  assert.match(document.querySelector("#discovery-complete-title").textContent, /3 discovered fields ready to review/);
  assert.match(document.querySelector("#discovery-complete-summary").textContent, /2 mapped · 1 unresolved.*url.*canonical identity.*mapping decision/i);
  await waitFor(() => document.activeElement === document.querySelector("#continue-review-button"), "Review handoff was not focused");
  document.querySelector("#continue-review-button").click();
  assert.ok(document.querySelector("[data-workflow-step='review']").classList.contains("selected"));
  assert.equal(document.querySelector("#step-blocks").classList.contains("route-inactive"), false);
  assert.ok(fieldColumn(document, "title"));
  assert.equal(fieldColumn(document, "_unmapped_internalCode_1"), null, "unresolved fields should not remain in the mapped values table");
  const unresolved = unresolvedFieldRow(document, "internal Code");
  assert.ok(unresolved, "unresolved field was not placed in the mapping queue");
  assert.equal(unresolved.querySelectorAll("button").length, 2);
  assert.deepEqual(Array.from(unresolved.querySelectorAll("button"), (button) => button.textContent), ["Map", "Delete"]);
  unresolved.children[1].dispatchEvent(new window.MouseEvent("mouseenter"));
  await waitFor(() => calls.some((call) => call.name === "bridgeHighlightSelector" && call.args.channel === "transient" && call.args.selector === ".internal-code"), "unresolved field hover did not preview its source nodes");
  fieldColumn(document, "title").dispatchEvent(new window.MouseEvent("mouseenter"));
  await waitFor(() => calls.some((call) => call.name === "bridgeHighlightSelector" && call.args.channel === "transient" && call.args.selector === ".title"), "mapped field hover did not preview its source nodes");
  dom.window.close();
});

test("Review explains blockers and hands a complete draft to Finish", async () => {
  const { dom, window } = await loadSidebar({
    discoveryResult: {
      ok: true, totalScopes: 2, sampledScopes: 2, truncated: false,
      candidates: [{
        selector: ".title-link", attribute: "href", kind: "url", multiple: false, suggestedName: "url",
        coverage: { present: 2, sampled: 2 }, selectorKind: "class",
        evidence: { tag: "a", attribute: "href", id: null, classes: ["title-link"], text: "First job", context: "h2 title", href: "/jobs/1", multiple: false, matchCounts: [1, 1] }
      }, {
        selector: ".title", attribute: null, kind: "text", multiple: false, suggestedName: "title",
        coverage: { present: 2, sampled: 2 }, selectorKind: "class",
        evidence: { tag: "h2", id: null, classes: ["title"], text: "First job", context: "h2 title", href: null, multiple: false }
      }]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#continue-semantics-button").click();
  document.querySelector("#confirm-semantics-button").click();
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => !document.querySelector("#discovery-complete").hidden, "Discovery completion did not appear");
  document.querySelector("#continue-review-button").click();
  await waitFor(() => !document.querySelector("#review-complete").hidden, "Review completion did not appear");
  assert.equal(document.querySelector("#review-complete-label").textContent, "Review ready");
  assert.match(document.querySelector("#review-complete-summary").textContent, /2 mapped fields.*canonical identities are ready/i);
  assert.equal(document.querySelector("#continue-finish-button").disabled, false);
  assert.equal(document.querySelector("#inference-shortcut").hidden, false);
  document.querySelector("#continue-finish-button").click();
  assert.ok(document.querySelector("[data-workflow-step='finish']").classList.contains("selected"));
  assert.equal(document.querySelector("#step-build").classList.contains("route-inactive"), false);
  assert.equal(document.querySelector("#inference-shortcut").hidden, true);
  assert.equal(document.querySelector("#infer-remaining-status").hidden, true);
  dom.window.close();
});

function fieldColumn(document, name) {
  return Array.from(document.querySelectorAll("#block-table .field-row-header"))
    .find((cell) => cell.querySelector(".field-column-label")?.childNodes[0]?.textContent === name) || null;
}

function unresolvedFieldRow(document, label) {
  return Array.from(document.querySelectorAll("#unresolved-fields-body tr"))
    .find((row) => row.querySelector("strong")?.textContent === label) || null;
}

function addSelectedField(document) {
  document.querySelector("#block-table-head .add-field-column-button").click();
  document.defaultView.__testPickerSelection();
}

test("clears inspected-page highlights when the sidebar closes or the inspected page navigates", async () => {
  const { calls, dom, window, navigate } = await loadSidebar();
  const document = window.document;
  document.querySelector("#pick-scope-button").click();
  await waitFor(() => document.querySelector("#scope-levels .option-item"), "scope proposal was not rendered");
  document.querySelector("#scope-use-preview-button").click();
  await waitFor(() => calls.some((call) => call.name === "bridgeHighlightSelector" && call.args.channel === "pinned"), "scope was not pinned");

  window.dispatchEvent(new window.PageTransitionEvent("pagehide"));
  await waitFor(() => calls.some((call) => call.name === "bridgeClearHighlights" && Object.keys(call.args || {}).length === 0), "closing did not clear both highlight channels");
  assert.equal(document.querySelector("#clear-pinned-highlight-button").disabled, true);

  navigate();
  await waitFor(() => document.querySelector("#selection-status").textContent !== "", "navigation did not refresh selection state");
  assert.equal(document.querySelector("#preview-extraction-button").disabled, true);
  dom.window.close();
});

test("blocks authoring selections inside Shadow DOM with an explicit boundary message", async () => {
  const { dom, window } = await loadSidebar({
    selectionResult: {
      ok: true,
      summary: { tag: "h2", id: null, classes: ["title"], text: "Shadow title" },
      href: null,
      shadowBoundary: { mode: "open", host: { tag: "job-card", id: "first", classes: [], text: "" } }
    }
  });
  const document = window.document;
  assert.equal(document.querySelector("#pick-scope-button").disabled, true);
  assert.match(document.querySelector("#selection-status").textContent, /open Shadow DOM root hosted by <job-card#first>/i);
  dom.window.close();
});

test("recommends Schema.org fields and requires inline documentation for extension terms", async () => {
  const { dom, window } = await loadSidebar();
  const document = window.document;
  document.querySelector("#pick-scope-button").click();
  await waitFor(() => document.querySelector("#scope-levels .option-item"), "scope proposal was not rendered");
  document.querySelector("#scope-use-preview-button").click();
  await waitFor(() => !document.querySelector("#block-setup").hidden, "block setup was not shown");
  document.querySelector("#block-schema-type").value = "JobPosting";
  document.querySelector("#create-block-button").click();
  await waitFor(() => document.querySelectorAll("#block-table-head .item-column-header").length === 2, "block table was not rendered");

  addSelectedField(document);
  await waitFor(() => !document.querySelector("#field-form").hidden, "field editor was not shown");
  assert.equal(document.querySelector("#field-name").value, "title");
  assert.match(document.querySelector("#field-semantic-status").textContent, /Schema\.org core JobPosting\.title/);
  document.querySelector("#field-name").value = "hiringOrganization.name";
  document.querySelector("#field-name").dispatchEvent(new window.Event("input", { bubbles: true }));
  assert.equal(document.querySelector("#field-name-menu").hidden, false);
  assert.ok(Array.from(document.querySelectorAll("#field-name-menu .combobox-option strong")).some((item) => item.textContent === "hiringOrganization.name"));

  document.querySelector("#field-name").value = "example:budget";
  document.querySelector("#field-name").dispatchEvent(new window.Event("input", { bubbles: true }));
  assert.equal(document.querySelector("#custom-term-form").hidden, false);
  document.querySelector("#add-field-button").click();
  assert.match(document.querySelector("#field-status").textContent, /Document the extension term/i);
  document.querySelector("#custom-term-description").value = "The marketplace-specific project budget.";
  document.querySelector("#custom-term-example").value = "$500";
  document.querySelector("#add-field-button").click();
  await waitFor(() => fieldColumn(document, "example:budget"), "extension field table did not finish rendering");
  dom.window.close();
});

test("recommends a structured adapter budget instead of baseSalary for project-price evidence", async () => {
  const { dom, window } = await loadSidebar({
    fieldCandidate: {
      ok: true,
      element: { tag: "div", id: null, classes: ["jobRecord__budget"], text: "Fixed Price | $10k-$25k", context: "div record jobRecord" },
      href: null,
      candidates: [{ selector: ".jobRecord__budget", kind: "class", matchCount: 1, unique: true, note: "Unique match." }]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  addSelectedField(document);
  await waitFor(() => !document.querySelector("#field-form").hidden, "field editor was not shown");
  assert.equal(document.querySelector("#field-name").value, "example:budget");
  assert.deepEqual(Array.from(document.querySelectorAll("#transform-steps .transform-step"), (item) => item.dataset.name), ["text", "parseProjectBudgetV1"]);
  assert.equal(document.querySelector("#custom-term-value-type").value, "Object");
  assert.match(document.querySelector("#custom-term-description").value, /budget/i);
  await waitFor(() => document.querySelector("#field-preview").textContent.includes("Coverage:"), "budget preview did not finish");
  dom.window.close();
});

test("recommends datePosted and ISO date parsing for an absolute rendered date", async () => {
  const { dom, window } = await loadSidebar({
    fieldCandidate: {
      ok: true,
      element: { tag: "strong", id: null, classes: [], text: "on Dec 30, 2025", context: "div jobRecord__meta" },
      href: null,
      candidates: [{ selector: ".jobRecord__meta strong:first-of-type", kind: "class", matchCount: 1, unique: true, note: "Unique match." }]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  addSelectedField(document);
  await waitFor(() => !document.querySelector("#field-form").hidden, "field editor was not shown");
  assert.equal(document.querySelector("#field-name").value, "datePosted");
  assert.deepEqual(Array.from(document.querySelectorAll("#transform-steps .transform-step"), (item) => item.dataset.name), ["text", "parseEnglishDateV1"]);
  await waitFor(() => document.querySelector("#field-preview").textContent.includes("Coverage:"), "date preview did not finish");
  dom.window.close();
});

test("transform autocomplete groups reviewed metadata and searches intent keywords", async () => {
  const { dom, window } = await loadSidebar();
  const document = window.document;
  await createJobBlock(document);
  addSelectedField(document);
  await waitFor(() => !document.querySelector("#field-form").hidden, "field editor was not shown");
  assert.deepEqual(Array.from(document.querySelectorAll("#transform-steps .transform-step"), (item) => item.dataset.name), ["text", "trim"]);
  const input = document.querySelector("#field-transform");
  input.dispatchEvent(new window.Event("focus"));
  assert.equal(document.querySelector("#transform-menu .combobox-group-label").textContent, "Recommended");
  input.value = "dollars";
  input.dispatchEvent(new window.Event("input", { bubbles: true }));
  const money = document.querySelector("#transform-menu [data-name='parseMoneyV1']");
  assert.ok(money);
  assert.match(money.textContent, /Money amount.*text → number.*monetary amount/i);
  money.click();
  assert.deepEqual(Array.from(document.querySelectorAll("#transform-steps .transform-step"), (item) => item.dataset.name), ["text", "trim", "parseMoneyV1"]);
  document.querySelector("#transform-steps [data-name='trim'] button").click();
  assert.deepEqual(Array.from(document.querySelectorAll("#transform-steps .transform-step"), (item) => item.dataset.name), ["text", "parseMoneyV1"]);

  input.value = "fixed width";
  input.dispatchEvent(new window.Event("input", { bubbles: true }));
  const slice = document.querySelector("#transform-menu [data-name='textSlice']");
  assert.ok(slice);
  assert.match(slice.textContent, /1–2 arguments/i);
  slice.click();
  assert.equal(document.querySelector("#transform-argument-form").hidden, false);
  const argumentInputs = document.querySelectorAll("#transform-argument-fields [data-argument-index]");
  assert.equal(argumentInputs.length, 2);
  argumentInputs[0].value = "2";
  argumentInputs[1].value = "10";
  document.querySelector("#save-transform-arguments").click();
  assert.equal(document.querySelector("#transform-steps [data-name='textSlice']").firstChild.textContent, "textSlice(2, 10)");
  await settleAsyncUi();
  dom.window.close();
});

test("visual editing updates configured argument-bearing transform steps", async () => {
  const structured = { name: "joinLiteral", args: [" "] };
  const draft = {
    id: "adapter:configured", status: "draft", adapterId: "configured", workingDefinition: null,
    editorState: {
      pageUrl: "https://example.com/jobs", adapterId: "configured", namespace: "https://example.com/#",
      pageId: "search", pageType: "SearchResultsPage", customTerms: {},
      blocks: [{
        id: "configured-jobs", name: "Jobs", entityName: "JobPosting", schemaType: "JobPosting",
        scope: ".results > li", arity: "many", role: "collection", fidelity: "summary", matchCount: 2,
        identity: { name: "canonicalUrl", selector: ".title", attribute: "href", kind: "url", multiple: false, transform: ["absoluteUrl", "stripQuery"] },
        fields: [{ name: "description", selector: ".summary", attribute: null, kind: "text", multiple: true, transform: ["text", structured], provenance: "imported", locked: true, unresolved: false }],
        requireFields: ["description"], monitorFields: []
      }]
    },
    createdAt: "2026-08-10T01:00:00.000Z", updatedAt: "2026-08-10T01:00:00.000Z"
  };
  const { calls, dom, window } = await loadSidebar({ workspace: true, drafts: [draft] });
  const document = window.document;
  await waitFor(() => document.querySelector("[data-draft-id='adapter:configured'] [data-action='open-draft']"), "configured draft was not listed");
  document.querySelector("[data-draft-id='adapter:configured'] [data-action='open-draft']").click();
  await waitFor(() => fieldColumn(document, "description"), "configured draft fields were not opened");
  await waitFor(() => calls.some((call) => call.name === "bridgeDiscoverVariantItems"), "opening a saved block did not refresh its transient item-type analysis");
  const initialVariantScan = calls.find((call) => call.name === "bridgeDiscoverVariantItems");
  assert.deepEqual(
    { itemLimit: initialVariantScan.args.itemLimit, elementLimit: initialVariantScan.args.elementLimit, fast: initialVariantScan.args.fast },
    { itemLimit: 24, elementLimit: 160, fast: true }
  );
  fieldColumn(document, "description").querySelector(".edit").click();
  const configured = document.querySelector("#transform-steps [data-name='joinLiteral']");
  assert.ok(configured.classList.contains("configured"));
  assert.equal(configured.firstChild.textContent, 'joinLiteral(" ")');
  configured.click();
  assert.equal(document.querySelector("#transform-argument-form").hidden, false);
  const delimiter = document.querySelector("#transform-argument-fields [data-argument-index='0']");
  assert.equal(delimiter.value, " ");
  delimiter.value = " · ";
  document.querySelector("#save-transform-arguments").click();
  assert.equal(document.querySelector("#transform-argument-form").hidden, true);
  assert.equal(document.querySelector("#transform-steps [data-name='joinLiteral']").firstChild.textContent, 'joinLiteral(" · ")');
  document.querySelector("#add-field-button").click();
  await waitFor(() => calls.some((call) => call.name === "bridgeBuildBlockTable" && call.args.fields?.some((field) => field.name === "description")), "saved field table did not refresh");
  const lastTable = calls.filter((call) => call.name === "bridgeBuildBlockTable").at(-1);
  assert.deepEqual(lastTable.args.fields.find((field) => field.name === "description").transform, ["text", { name: "joinLiteral", args: [" · "] }]);
  await settleAsyncUi();
  dom.window.close();
});

test("one discovery action adds schema matches and unresolved values, reruns idempotently, and supports undo", async () => {
  const { dom, window } = await loadSidebar({
    discoveryResult: {
      ok: true,
      totalScopes: 20,
      sampledScopes: 10,
      truncated: false,
      candidates: [
        {
          selector: ".title-link", attribute: "href", kind: "url", multiple: false, suggestedName: "url",
          coverage: { present: 10, sampled: 10 }, selectorKind: "class",
          evidence: { tag: "a", attribute: "href", id: null, classes: ["title-link"], text: "First job", context: "h2 title", href: "/jobs/1", multiple: false, matchCounts: [1, 1] }
        },
        {
          selector: ".title", attribute: null, kind: "text", multiple: false, suggestedName: "title",
          evidence: { tag: "h2", id: null, classes: ["title"], text: "First job", context: "h2 title", href: null, multiple: false }
        },
        {
          selector: ".internal-code", attribute: null, kind: "text", multiple: false, suggestedName: "internalCode",
          evidence: { tag: "span", id: null, classes: ["internal-code"], text: "ABC-1", context: "span internal-code", href: null, multiple: false }
        }
      ]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => unresolvedFieldRow(document, "internal Code"), "unresolved discovered field was not rendered");
  assert.ok(fieldColumn(document, "title"));
  assert.equal(fieldColumn(document, "_unmapped_internalCode_1"), null);
  assert.equal(document.querySelectorAll("#unresolved-fields-body tr").length, 1);
  assert.ok(fieldColumn(document, "url"));
  assert.equal(document.querySelector("#undo-discovery-button").disabled, false);
  assert.match(document.querySelector("#discovery-status").textContent, /selected “url” as the canonical identity.*added 3.*1 newly added field is unresolved/i);
  assert.equal(document.querySelector("#discovery-report-details").hidden, false);
  assert.equal(document.querySelector("#discovery-report-details").open, false, "successful scan diagnostics should not duplicate the completion card");

  document.querySelector("#discover-fields-button").click();
  await waitFor(() => /kept 3/.test(document.querySelector("#discovery-status").textContent), "second discovery did not reconcile existing sources");
  assert.equal(document.querySelectorAll("#block-table-body .field-column-label").length, 2);
  assert.equal(document.querySelectorAll("#unresolved-fields-body tr").length, 1);

  document.querySelector("#undo-discovery-button").click();
  await waitFor(() => document.querySelectorAll("#block-table-body .field-column-label").length === 2, "latest batch undo should restore the state before the idempotent rerun");
  assert.equal(document.querySelector("#undo-discovery-button").disabled, true);
  await settleAsyncUi();
  dom.window.close();
});

test("bulk discovery adds a recognized project budget as a documented singular extension", async () => {
  const { calls, dom, window } = await loadSidebar({
    discoveryResult: {
      ok: true, totalScopes: 19, sampledScopes: 19, truncated: false,
      candidates: [
        {
          selector: ".jobRecord__title > a", attribute: "href", kind: "url", multiple: false, suggestedName: "url",
          coverage: { present: 19, sampled: 19 }, selectorKind: "class",
          evidence: {
            tag: "a", attribute: "href", id: null, classes: [], text: "First job", context: "h2 jobRecord__title",
            href: "/work/detail/1", multiple: false, matchCounts: [1, 1]
          }
        },
        {
          selector: ".jobRecord__budget", attribute: null, kind: "text", multiple: true, suggestedName: "budget",
          coverage: { present: 19, sampled: 19 }, selectorKind: "class",
          evidence: {
            tag: "div", id: null, classes: ["jobRecord__budget"], text: "Fixed Price | $10k-$25k",
            context: "div record jobRecord", multiple: true, matchCounts: [2, 2]
          }
        }
      ]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => fieldColumn(document, "example:budget"), "budget extension was not discovered");
  const lastTable = calls.filter((call) => call.name === "bridgeBuildBlockTable").at(-1);
  const budget = lastTable.args.fields.find((field) => field.name === "example:budget");
  assert.equal(budget.selector, ".jobRecord__budget");
  assert.equal(budget.multiple, false);
  assert.deepEqual(budget.transform, ["text", "parseProjectBudgetV1"]);
  assert.equal(budget.corroboration.confidence, "strong");
  const budgetSignals = budget.corroboration.signals.map((signal) => signal.kind);
  assert.ok(budgetSignals.includes("lexical"));
  assert.ok(budgetSignals.includes("value"));

  document.querySelector("#build-button").click();
  await waitFor(() => document.querySelector("#build-status").textContent.includes("valid"), "discovered extension draft was not built");
  const build = calls.filter((call) => call.name === "buildDraftDefinition").at(-1);
  assert.deepEqual(JSON.parse(JSON.stringify(build.args.customTerms["example:budget"])), {
    description: "An adapter-specific structured budget or rate range.",
    valueType: "Object", cardinality: "one", example: "Fixed Price | $10k-$25k"
  });
  assert.equal(document.querySelector("#block-table-head .unresolved-column"), null);

  const tableCallsBeforeUndo = calls.filter((call) => call.name === "bridgeBuildBlockTable").length;
  document.querySelector("#undo-discovery-button").click();
  await waitFor(() => !fieldColumn(document, "example:budget"), "budget discovery was not undone");
  await waitFor(() => calls.filter((call) => call.name === "bridgeBuildBlockTable").length > tableCallsBeforeUndo, "undo table refresh did not finish");
  await settleAsyncUi();
  dom.window.close();
});

test("a discovered semantic url field can be inferred, edited, and removed as identity", async () => {
  const { dom, window } = await loadSidebar({
    discoveryResult: {
      ok: true, totalScopes: 2, sampledScopes: 2, truncated: false,
      candidates: [{
        selector: ".title-link", attribute: "href", kind: "url", multiple: false, suggestedName: "url",
        coverage: { present: 2, sampled: 2 }, selectorKind: "class",
        evidence: { tag: "a", attribute: "href", id: null, classes: ["title-link"], text: "First job", context: "h2 title", href: "/jobs/1", multiple: false, matchCounts: [1, 1] }
      }]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => fieldColumn(document, "url"), "identity controls were not rendered");
  assert.match(fieldColumn(document, "url").textContent, /identity/i);
  fieldColumn(document, "url").querySelector(".edit").click();
  assert.equal(document.querySelector("#add-field-button").textContent, "Save identity field");
  assert.equal(document.querySelector("#field-identity").checked, true);
  assert.deepEqual(Array.from(document.querySelectorAll("#transform-steps .transform-step"), (item) => item.dataset.name), ["absoluteUrl", "stripQuery"]);
  document.querySelector("#field-selector").value = ".canonical-link";
  document.querySelector("#field-selector").dispatchEvent(new window.Event("input", { bubbles: true }));
  document.querySelector("#add-field-button").click();
  await waitFor(() => fieldColumn(document, "url")?.title.includes(".canonical-link"), "identity edit was not saved");
  fieldColumn(document, "url").querySelector(".edit").click();
  assert.equal(document.querySelector("#delete-field-button").textContent, "Delete identity field");
  document.querySelector("#delete-field-button").click();
  await waitFor(() => !fieldColumn(document, "url"), "identity field was not removed");
  assert.match(document.querySelector("#discovery-status").textContent, /removed identity field “url”/i);
  await settleAsyncUi();
  dom.window.close();
});

test("a nested dotted identity does not require the hidden custom-term form", async () => {
  const { dom, window } = await loadSidebar({
    discoveryResult: {
      ok: true, totalScopes: 2, sampledScopes: 2, truncated: false,
      candidates: [{
        selector: ".title-link", attribute: "href", kind: "url", multiple: false, suggestedName: "url",
        coverage: { present: 2, sampled: 2 }, selectorKind: "class",
        evidence: { tag: "a", attribute: "href", id: null, classes: ["title-link"], text: "First job", context: "h2 title", href: "/jobs/1", multiple: false, matchCounts: [1, 1] }
      }]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => fieldColumn(document, "url"), "identity field was not discovered");
  fieldColumn(document, "url").querySelector(".edit").click();
  document.querySelector("#field-name").value = "mainEntity.itemListElement.item.url";
  document.querySelector("#field-name").dispatchEvent(new window.Event("input", { bubbles: true }));
  assert.equal(document.querySelector("#field-identity").checked, true);
  assert.equal(document.querySelector("#custom-term-form").hidden, true);
  document.querySelector("#add-field-button").click();
  await waitFor(() => fieldColumn(document, "mainEntity.itemListElement.item.url"), "nested identity was not saved");
  assert.equal(document.querySelector("#field-status").textContent.includes("Document the extension term"), false);
  await settleAsyncUi();
  dom.window.close();
});

test("unmapped discovery fields block building until the author edits their semantic mapping", async () => {
  const { dom, window } = await loadSidebar({
    discoveryResult: {
      ok: true,
      totalScopes: 2,
      sampledScopes: 2,
      truncated: false,
      candidates: [{
        selector: ".internal-code", attribute: null, kind: "text", multiple: false, suggestedName: "internalCode",
        evidence: { tag: "span", id: null, classes: ["internal-code"], text: "ABC-1", context: "span internal-code", href: null, multiple: false }
      }]
    }
  });
  const document = window.document;
  await createJobBlock(document);
  document.querySelector("#discover-fields-button").click();
  await waitFor(() => unresolvedFieldRow(document, "internal Code"), "unresolved field was not rendered");
  document.querySelector("#build-button").click();
  assert.match(document.querySelector("#build-status").textContent, /Review 1 unmapped discovered field/i);

  unresolvedFieldRow(document, "internal Code").querySelector("button").click();
  assert.equal(document.querySelector("#field-name").value, "");
  assert.equal(document.querySelector("#field-editor-title").textContent, "Map discovered field");
  assert.match(document.querySelector("#field-editor-context").textContent, / · \.internal-code$/);
  assert.equal(document.querySelector("#field-status").classList.contains("error"), false);
  assert.equal(document.querySelector("#field-semantic-status").classList.contains("error"), false);
  assert.match(document.querySelector("#field-status").textContent, /Choose what this discovered value means/i);
  assert.equal(document.querySelector("#add-field-button").textContent, "Save field");
  assert.equal(document.querySelector("#delete-field-button").hidden, false);
  document.querySelector("#add-field-button").click();
  assert.equal(document.querySelector("#field-status").classList.contains("error"), true, "submitting an unnamed mapping did not surface validation");
  document.querySelector("#field-name").value = "description";
  document.querySelector("#field-name").dispatchEvent(new window.Event("input", { bubbles: true }));
  document.querySelector("#add-field-button").click();
  await waitFor(() => fieldColumn(document, "description"), "edited discovery field was not saved");
  assert.equal(document.querySelector("#unresolved-fields-section").hidden, true);
  assert.equal(document.querySelector("#undo-discovery-button").disabled, true);
  await settleAsyncUi();
  dom.window.close();
});
