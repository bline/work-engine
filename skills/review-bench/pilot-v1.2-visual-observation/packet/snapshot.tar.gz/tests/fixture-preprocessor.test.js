"use strict";

const assert = require("node:assert/strict");
const childProcess = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");

const root = path.resolve(__dirname, "..");
const script = path.join(root, "scripts/scrub-upwork-search-fixture.js");
const fixtures = [{ name: "upwork-search-captured-page-1.html", cards: 7 }, { name: "upwork-search-captured-page-2.html", cards: 10 }];

test("the Upwork reducer deterministically regenerates both committed scrubbed captures", (context) => {
  const temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), "site2json-fixture-"));
  context.after(() => fs.rmSync(temporaryDirectory, { recursive: true, force: true }));

  for (const fixture of fixtures) {
    const source = path.join(__dirname, "fixtures", fixture.name);
    const output = path.join(temporaryDirectory, fixture.name);
    childProcess.execFileSync(process.execPath, [script, source, output], { stdio: "pipe" });
    assert.equal(fs.readFileSync(output, "utf8"), fs.readFileSync(source, "utf8"));
    const document = new JSDOM(fs.readFileSync(output, "utf8")).window.document;
    assert.equal(document.querySelectorAll('[data-test="JobTile"]').length, fixture.cards);
    assert.ok(document.querySelector('[data-test="JobsList"]'));
  }
});

test("the two reduced captures preserve distinct source card populations", () => {
  const [first, second] = fixtures.map((fixture) => fs.readFileSync(path.join(__dirname, "fixtures", fixture.name), "utf8"));
  assert.notEqual(first, second);
  assert.ok(Buffer.byteLength(second) > Buffer.byteLength(first));
});
