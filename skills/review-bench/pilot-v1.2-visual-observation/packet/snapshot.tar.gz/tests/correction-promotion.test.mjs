import assert from "node:assert/strict";
import test from "node:test";

await import("../extension/core/utils.js");
await import("../extension/core/transforms.js");
const Promotion = await import("../extension/authoring/correction-promotion.mjs");

function source(overrides = {}) {
  return {
    id: "library:headline",
    termId: "market:headline",
    revision: 3,
    profileDigest: "s2jp1:old",
    profile: { version: 1, aliases: ["headline"], provenance: { source: "user" } },
    ...overrides
  };
}

test("proposes only sanitized lexical changes and never carries selectors or rendered text", () => {
  const proposal = Promotion.proposal({
    originalField: {
      selector: "#secret-account > .EmployerName__root__x7Ea9",
      evidence: { id: "employerName", classes: ["EmployerName__root__x7Ea9"], text: "Acme Private Holdings" },
      corroboration: {
        property: "headline",
        globalArbitration: { selectedFrom: ["headline", "name", "description"] },
        localKnowledge: { material: true, sources: [source()] }
      }
    },
    selectedTerm: { name: "name", librarySources: [source({ id: "library:name", termId: "schema:name", profile: { version: 1, provenance: { source: "user" } } })] },
    adapterId: "guru",
    decisionId: "results:JobPosting:name"
  });

  assert.equal(proposal.profileInfluenced, true);
  assert.deepEqual(proposal.changes.map(({ operation, value }) => ({ operation, value })), [
    { operation: "add-alias", value: "employer name" },
    { operation: "add-negative-alias", value: "employer name" }
  ]);
  assert.equal(JSON.stringify(proposal).includes("secret-account"), false);
  assert.equal(JSON.stringify(proposal).includes("Acme Private"), false);
});

test("rejects proposals that target terms outside ranked alternatives", () => {
  const proposal = Promotion.proposal({
    originalField: {
      selector: "#secret-account > .EmployerName__root__x7Ea9",
      evidence: { id: "employerName", classes: ["EmployerName__root__x7Ea9"], text: "Acme Private Holdings" },
      corroboration: {
        property: "headline",
        globalArbitration: { selectedFrom: ["headline", "description", "offers"] },
        localKnowledge: { material: true, sources: [source()] }
      }
    },
    selectedTerm: { name: "name", librarySources: [source({ id: "library:name", termId: "schema:name", profile: { version: 1, provenance: { source: "user" } } })] },
    adapterId: "guru"
  });
  assert.equal(proposal, null);
});

test("requires ranked alternatives metadata before returning a proposal", () => {
  const proposal = Promotion.proposal({
    originalField: {
      selector: "#secret-account > .EmployerName__root__x7Ea9",
      evidence: { id: "employerName", classes: ["EmployerName__root__x7Ea9"], text: "Acme Private Holdings" },
      corroboration: {
        property: "headline",
        localKnowledge: { material: true, sources: [source()] }
      }
    },
    selectedTerm: { name: "headline", librarySources: [source({ id: "library:headline", termId: "schema:headline", profile: { version: 1, provenance: { source: "user" } } })] },
    adapterId: "guru"
  });
  assert.equal(proposal, null);
});

test("applies a revision-checked update and records bounded correction provenance", async () => {
  let record = {
    id: "library:headline", termId: "market:headline", label: "Headline", revision: 3,
    definition: { kind: "field", description: "A heading.", valueType: "Text", authoringProfile: { version: 1, aliases: ["headline"], provenance: { source: "user" } } }
  };
  const service = {
    async getProperty() { return structuredClone(record); },
    async saveProperty({ property, expectedRevision }) {
      assert.equal(expectedRevision, 3);
      record = { ...structuredClone(property), revision: 4 };
      return structuredClone(record);
    }
  };
  const proposal = {
    version: 1, adapterId: "guru", decisionId: "results:JobPosting:title", changes: [{
      recordId: record.id, termId: record.termId, expectedRevision: 3, operation: "add-negative-alias", value: "employer name"
    }]
  };
  await Promotion.apply(service, proposal, { now: () => "2026-08-13T12:00:00.000Z" });

  assert.deepEqual(record.definition.authoringProfile.negativeAliases, ["employer name"]);
  assert.deepEqual(record.definition.authoringProfile.provenance.corrections, [{
    adapterId: "guru",
    decisionId: "results:JobPosting:title",
    operation: "add-negative-alias",
    value: "employer name",
    updatedAt: "2026-08-13T12:00:00.000Z"
  }]);
});

test("refuses to overwrite a profile whose revision changed after inference", async () => {
  const service = {
    async getProperty() { return { id: "p", label: "Property", revision: 8, definition: {} }; },
    async saveProperty() { throw new Error("must not save"); }
  };
  await assert.rejects(() => Promotion.apply(service, {
    version: 1, adapterId: "guru", decisionId: "d", changes: [{ recordId: "p", termId: "p", expectedRevision: 7, operation: "add-alias", value: "role" }]
  }), (error) => {
    assert.equal(error.code, "REVISION_CONFLICT");
    assert.match(error.message, /changed after this decision/i);
    return true;
  });
});
