"use strict";

const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const Catalog = require("../extension/editor/schema-catalog.generated");
const Vocabulary = require("../extension/editor/schema-vocabulary");
const Generator = require("../scripts/build-schemaorg-catalog");

const root = path.resolve(__dirname, "..");
const metadata = JSON.parse(fs.readFileSync(path.join(root, "third_party/schemaorg/source.json"), "utf8"));
const snapshot = fs.readFileSync(path.join(root, "third_party/schemaorg/schemaorg-v30.0.jsonld"));

test("packages the pinned official Schema.org snapshot with verified source metadata", () => {
  assert.equal(Catalog.version, "30.0");
  assert.equal(Catalog.source, "https://schema.org/version/30.0/schemaorg-current-https.jsonld");
  assert.equal(Catalog.sourceSha256, metadata.sourceSha256);
  assert.equal(`sha256:${crypto.createHash("sha256").update(snapshot).digest("hex")}`, metadata.sourceSha256);
  assert.ok(Object.keys(Catalog.classes).length > 900);
  assert.ok(Object.keys(Catalog.properties).length > 1_400);
});

test("retains inheritance, multiple ranges, descriptions, and vocabulary status", () => {
  assert.deepEqual(Catalog.classes.JobPosting.supers, ["Intangible"]);
  assert.match(Catalog.properties.baseSalary.description, /base salary/i);
  assert.deepEqual(Catalog.properties.hiringOrganization.ranges, ["Organization", "Person"]);
  assert.equal(Catalog.properties.datePosted.status, "core");
  assert.ok(Object.values(Catalog.properties).some((property) => property.status === "pending"));
  assert.equal(Object.hasOwn(Catalog.properties.skills, "cardinality"), false);
});

test("derives inherited and nested editor properties from the generated catalog", () => {
  assert.equal(Vocabulary.catalogVersion, "30.0");
  assert.ok(Vocabulary.typeNames().includes("RealEstateListing"));
  assert.ok(Vocabulary.propertiesFor("JobPosting").some((property) => property.name === "identifier"));
  assert.deepEqual(Vocabulary.property("JobPosting", "hiringOrganization.name").ranges, ["Text"]);
});

test("the catalog generator normalizes singleton relationships and extension status deterministically", () => {
  const generated = Generator.buildCatalog({ "@graph": [{
    "@id": "schema:Example",
    "@type": "rdfs:Class",
    "rdfs:comment": " Example class. ",
    "rdfs:subClassOf": { "@id": "schema:Thing" },
    "schema:isPartOf": { "@id": "https://pending.schema.org" }
  }, {
    "@id": "schema:exampleValue",
    "@type": "rdf:Property",
    "rdfs:comment": " Example   value. ",
    "schema:domainIncludes": { "@id": "schema:Example" },
    "schema:rangeIncludes": [{ "@id": "schema:Text" }, { "@id": "schema:Number" }]
  }] }, { version: "test", source: "fixture", sourceSha256: "sha256:test" });
  assert.deepEqual(generated.classes.Example, { supers: ["Thing"], description: "Example class.", status: "pending" });
  assert.deepEqual(generated.properties.exampleValue, {
    domains: ["Example"], ranges: ["Number", "Text"], description: "Example value.", status: "core"
  });
});
