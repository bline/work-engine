"use strict";

const assert = require("node:assert/strict");

const PATTERN_A = {
  id: "pattern:article-author",
  label: "Article author",
  description: "An article and its author.",
  root: "article",
  nodes: {
    article: { types: ["Article"], expectation: "core" },
    author: { types: ["Person"], expectation: "common" }
  },
  edges: [{ from: "article", property: "author", to: "author", expectation: "common" }],
  terms: {}
};

const PATTERN_B = {
  id: "pattern:marketplace-buyer",
  label: "Marketplace buyer",
  description: "A buyer with an aggregate rating.",
  root: "buyer",
  nodes: { buyer: { types: ["Organization"], expectation: "core" } },
  edges: [],
  terms: {}
};

const CUSTOM_TYPE = {
  id: "guru:Editor",
  label: "Editor",
  description: "A person responsible for editing a marketplace listing.",
  definition: {
    kind: "type",
    description: "A person responsible for editing a marketplace listing.",
    valueType: "guru:Editor",
    cardinality: "one",
    example: "Editor"
  }
};

function semanticLibraryServiceContract(test, name, createService) {
  test(`${name}: exposes a serializable, capability-driven contract`, async () => {
    const service = await createService();
    const capabilities = await service.getCapabilities();
    assert.equal(capabilities.contractVersion, 1);
    assert.equal(capabilities.features.patterns, true);
    assert.equal(capabilities.features.customTypes, true);
    assert.equal(capabilities.features.tags, true);
    assert.equal(capabilities.features.collections, true);
    assert.equal(capabilities.features.sourceCategories, true);
    assert.doesNotThrow(() => JSON.stringify(capabilities));
    for (const method of [
      "listFavorites", "addFavorite", "removeFavorite",
      "listTags", "getTag", "getTags", "saveTag", "deleteTag", "getTagAssignments", "assignTags",
      "search", "getTerms", "getVocabulary", "listVocabularyTerms", "resolveSubgraph",
      "listPatterns", "getPatterns", "getPattern", "savePattern", "deletePattern",
      "listCustomTypes", "getCustomTypes", "getCustomType", "saveCustomType", "deleteCustomType",
      "listCollections", "getCollection", "getCollections", "saveCollection", "updateCollectionMembers", "deleteCollection",
      "planImport", "startImport", "getImportJob", "cancelImport"
    ]) assert.equal(typeof service[method], "function", `${method} must be implemented`);
  });

  test(`${name}: searches and revisions reusable custom types beside graph bundles`, async () => {
    const service = await createService();
    const created = await service.saveCustomType({ customType: CUSTOM_TYPE, expectedRevision: 0 });
    assert.equal(created.revision, 1);
    const search = await service.search({ query: "marketplace listing", pageSize: 20 });
    assert.deepEqual(search.items.map((item) => [item.kind, item.id]), [["customType", CUSTOM_TYPE.id]]);
    assert.equal(search.facets.kinds.items.find((facet) => facet.id === "customType").label, "Custom types");
    assert.deepEqual((await service.getCustomTypes({ ids: [CUSTOM_TYPE.id, "missing"] })).map((item) => item.id), [CUSTOM_TYPE.id]);

    const updated = await service.saveCustomType({
      customType: { ...created, label: "Listing editor" },
      expectedRevision: created.revision
    });
    assert.equal(updated.revision, 2);
    await assert.rejects(service.deleteCustomType({ id: CUSTOM_TYPE.id, expectedRevision: 1 }), (error) => error.code === "REVISION_CONFLICT");
    await service.deleteCustomType({ id: CUSTOM_TYPE.id, expectedRevision: 2 });
    await assert.rejects(service.getCustomType(CUSTOM_TYPE.id), (error) => error.code === "NOT_FOUND");
  });

  test(`${name}: stores and reorders favorites atomically`, async () => {
    const service = await createService();
    await service.addFavorite({ favorite: { kind: "schemaType", id: "Article" }, index: 0 });
    let favorites = await service.listFavorites();
    assert.equal(favorites[0].id, "Article");
    assert.equal(favorites.filter((favorite) => favorite.id === "Article").length, 1);
    await service.removeFavorite({ favorite: { kind: "schemaType", id: "Person" } });
    favorites = await service.listFavorites();
    assert.equal(favorites.some((favorite) => favorite.id === "Person"), false);
  });

  test(`${name}: searches patterns with opaque cursor pagination and batch retrieval`, async () => {
    const service = await createService();
    await service.savePattern({ pattern: PATTERN_B });
    await service.savePattern({ pattern: PATTERN_A });

    const first = await service.search({ query: "", kinds: ["pattern"], pageSize: 1 });
    assert.equal(first.items.length, 1);
    assert.equal(first.total, 2);
    assert.match(first.nextCursor, /^v1:/);
    const second = await service.search({ query: "", kinds: ["pattern"], pageSize: 1, cursor: first.nextCursor });
    assert.equal(second.items.length, 1);
    assert.notEqual(second.items[0].id, first.items[0].id);
    assert.equal(second.nextCursor, null);

    const match = await service.search({ query: "aggregate rating", kinds: ["pattern"] });
    assert.deepEqual(match.items.map((item) => item.id), [PATTERN_B.id]);
    const records = await service.getPatterns({ ids: [PATTERN_B.id, PATTERN_A.id, "missing"] });
    assert.deepEqual(records.map((record) => record.id), [PATTERN_B.id, PATTERN_A.id]);
    assert.doesNotThrow(() => JSON.stringify(records));
  });

  test(`${name}: uses revisions for API-safe optimistic concurrency`, async () => {
    const service = await createService();
    const created = await service.savePattern({ pattern: PATTERN_A, expectedRevision: 0 });
    assert.equal(created.revision, 1);
    assert.ok(created.createdAt);
    const updated = await service.savePattern({
      pattern: { ...created, description: "Updated description." },
      expectedRevision: created.revision
    });
    assert.equal(updated.revision, 2);
    assert.equal(updated.createdAt, created.createdAt);

    await assert.rejects(
      service.savePattern({ pattern: { ...created, description: "Stale update." }, expectedRevision: 1 }),
      (error) => error.code === "REVISION_CONFLICT" && error.details.actualRevision === 2
    );
    assert.equal((await service.getPattern(PATTERN_A.id)).description, "Updated description.");
  });

  test(`${name}: assigns user tags in batches and exposes filtered-search facets`, async () => {
    const service = await createService();
    await service.savePattern({ pattern: { ...PATTERN_A, provenance: { categories: ["Imported publishing"] } } });
    await service.savePattern({ pattern: PATTERN_B });
    const employment = await service.saveTag({ tag: { id: "tag:employment", label: "Employment" }, expectedRevision: 0 });
    const favorite = await service.saveTag({ tag: { id: "tag:favorite", label: "Favorite" }, expectedRevision: 0 });
    assert.equal(employment.revision, 1);
    assert.equal(favorite.revision, 1);

    await service.assignTags({
      targets: [{ kind: "pattern", id: PATTERN_A.id }, { kind: "pattern", id: PATTERN_B.id }],
      tagIds: [employment.id],
      mode: "add"
    });
    await service.assignTags({ targets: [{ kind: "pattern", id: PATTERN_A.id }], tagIds: [favorite.id], mode: "add" });

    const employmentResults = await service.search({ filters: { tagIds: [employment.id] } });
    assert.equal(employmentResults.total, 2);
    assert.equal(employmentResults.facets.tags.items.find((facet) => facet.id === employment.id).count, 2);
    const both = await service.search({ filters: { tagIds: [employment.id, favorite.id] } });
    assert.deepEqual(both.items.map((item) => item.id), [PATTERN_A.id]);
    assert.deepEqual(both.items[0].sourceCategories, [{ id: "Imported publishing", label: "Imported publishing", source: null }]);
    assert.deepEqual(both.items[0].tagIds.sort(), [employment.id, favorite.id].sort());
    assert.equal(both.facets.sourceCategories.items.find((facet) => facet.id === "Imported publishing").count, 1);
    const categoryResults = await service.search({ filters: { sourceCategoryIds: ["Imported publishing"] } });
    assert.deepEqual(categoryResults.items.map((item) => item.id), [PATTERN_A.id]);

    const assignments = await service.getTagAssignments({ targets: [{ kind: "pattern", id: PATTERN_A.id }] });
    assert.deepEqual(assignments[0].tagIds.sort(), [employment.id, favorite.id].sort());
    await service.deleteTag({ id: favorite.id, expectedRevision: 1 });
    assert.deepEqual((await service.getTagAssignments({ targets: [{ kind: "pattern", id: PATTERN_A.id }] }))[0].tagIds, [employment.id]);
  });

  test(`${name}: manages revisioned collections and filters search by membership`, async () => {
    const service = await createService();
    await service.savePattern({ pattern: PATTERN_A });
    await service.savePattern({ pattern: PATTERN_B });
    const created = await service.saveCollection({
      collection: {
        id: "collection:marketplace",
        label: "Marketplace",
        members: [{ kind: "pattern", id: PATTERN_B.id }]
      },
      expectedRevision: 0
    });
    assert.equal(created.revision, 1);
    assert.equal(created.members.length, 1);

    const updated = await service.updateCollectionMembers({
      id: created.id,
      members: [{ kind: "pattern", id: PATTERN_A.id }],
      mode: "add",
      expectedRevision: created.revision
    });
    assert.equal(updated.revision, 2);
    assert.equal(updated.members.length, 2);
    const results = await service.search({ filters: { collectionIds: [created.id] } });
    assert.equal(results.total, 2);
    assert.equal(results.facets.collections.items.find((facet) => facet.id === created.id).count, 2);

    await service.deletePattern({ id: PATTERN_B.id, expectedRevision: 1 });
    const afterDelete = await service.getCollection(created.id);
    assert.deepEqual(afterDelete.members, [{ kind: "pattern", id: PATTERN_A.id }]);
    assert.equal(afterDelete.revision, 3);
  });

  test(`${name}: returns stable errors for unsupported capabilities and missing records`, async () => {
    const service = await createService();
    await assert.rejects(service.getVocabulary("lov:test"), (error) => error.code === "NOT_SUPPORTED");
    await assert.rejects(service.getPattern("pattern:missing"), (error) => error.code === "NOT_FOUND");
    await assert.rejects(
      service.search({ cursor: "database-row-12" }),
      (error) => error.code === "INVALID_CURSOR"
    );
  });
}

module.exports = { CUSTOM_TYPE, PATTERN_A, PATTERN_B, semanticLibraryServiceContract };
