"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { IDBFactory } = require("fake-indexeddb");
const Toolbox = require("../extension/core/semantic-toolbox");
const IndexedDb = require("../extension/core/semantic-library-indexeddb");
const SemanticLibrary = require("../extension/core/semantic-library-service");
const { CUSTOM_TYPE, PATTERN_A, semanticLibraryServiceContract } = require("./contracts/semantic-library-service.contract");

function memoryStorage(initial = {}) {
  const values = structuredClone(initial);
  const removed = [];
  return {
    values,
    removed,
    async get(keys) {
      const selected = Array.isArray(keys) ? keys : [keys];
      return Object.fromEntries(selected.map((key) => [key, structuredClone(values[key])]).filter(([, value]) => value !== undefined));
    },
    async set(next) { Object.assign(values, structuredClone(next)); },
    async remove(keys) {
      for (const key of Array.isArray(keys) ? keys : [keys]) { delete values[key]; removed.push(key); }
    }
  };
}

function indexedService({ factory = new IDBFactory(), legacyStorage = memoryStorage(), dbName = `site2json-test-${Math.random()}` } = {}) {
  return SemanticLibrary.createIndexedDbToolboxService({
    toolboxApi: Toolbox,
    indexedDbApi: IndexedDb,
    indexedDB: factory,
    legacyStorage,
    dbName,
    now: () => "2026-08-13T12:00:00.000Z"
  });
}

semanticLibraryServiceContract(test, "IndexedDB Semantic Library service", () => indexedService());

test("IndexedDB storage migrates the normalized legacy toolbox once into record-oriented stores", async () => {
  const factory = new IDBFactory();
  const dbName = "site2json-migration-test";
  const importedType = {
    ...CUSTOM_TYPE,
    provenance: { source: { id: "lov" }, canonicalUri: "https://example.test/Editor" }
  };
  const seed = Toolbox.normalize({
    favorites: [{ kind: "customType", id: importedType.id }],
    customTypes: { [importedType.id]: importedType },
    patterns: { [PATTERN_A.id]: PATTERN_A },
    tags: { "tag:people": { id: "tag:people", label: "People", description: "Person-related terms." } },
    tagAssignments: { [`customType\u001f${importedType.id}`]: ["tag:people"] },
    collections: {
      "collection:people": {
        id: "collection:people",
        label: "People",
        members: [{ kind: "customType", id: importedType.id }]
      }
    },
    toolkits: { "toolkit:people": { label: "People toolkit" } }
  });
  const legacy = memoryStorage({ [Toolbox.STORAGE_KEY]: seed });
  const storage = IndexedDb.createStorage({ indexedDB: factory, toolboxApi: Toolbox, legacyStorage: legacy, dbName, now: () => "2026-08-13T12:00:00.000Z" });
  await storage.ready();

  const migrated = (await storage.get(Toolbox.STORAGE_KEY))[Toolbox.STORAGE_KEY];
  const diagnostics = await storage.diagnostics();
  assert.equal(migrated.customTypes[importedType.id].provenance.source.id, "lov");
  assert.equal(migrated.patterns[PATTERN_A.id].label, PATTERN_A.label);
  assert.deepEqual(migrated.tagAssignments[`customType\u001f${importedType.id}`], ["tag:people"]);
  assert.equal(migrated.toolkits["toolkit:people"].label, "People toolkit");
  assert.equal(diagnostics.counts.customTypes, 1);
  assert.equal(diagnostics.counts.patterns, 1);
  assert.equal(diagnostics.counts.tags, 1);
  assert.equal(diagnostics.counts.collections, 1);
  assert.equal(diagnostics.counts.imports, 0, "the import-manifest store should exist before import history is implemented");
  assert.equal(diagnostics.migration.sourceHadData, true);
  assert.deepEqual(legacy.removed, [Toolbox.STORAGE_KEY]);

  legacy.values[Toolbox.STORAGE_KEY] = Toolbox.normalize({ customTypes: { "other:Type": { ...CUSTOM_TYPE, id: "other:Type", label: "Other", definition: { ...CUSTOM_TYPE.definition, valueType: "other:Type" } } } });
  const reopened = IndexedDb.createStorage({ indexedDB: factory, toolboxApi: Toolbox, legacyStorage: legacy, dbName });
  const secondRead = (await reopened.get(Toolbox.STORAGE_KEY))[Toolbox.STORAGE_KEY];
  assert.ok(secondRead.customTypes[importedType.id]);
  assert.equal(secondRead.customTypes["other:Type"], undefined, "a completed migration must never replay a stale legacy toolbox");
  await storage.close();
  await reopened.close();
});

test("IndexedDB services persist revisions across independent service instances", async () => {
  const factory = new IDBFactory();
  const dbName = "site2json-persistence-test";
  const legacy = memoryStorage();
  const first = indexedService({ factory, legacyStorage: legacy, dbName });
  assert.equal((await first.getCapabilities()).implementation, "indexeddb-toolbox");
  const created = await first.saveCustomType({ customType: CUSTOM_TYPE, expectedRevision: 0 });
  const second = indexedService({ factory, legacyStorage: legacy, dbName });
  assert.equal((await second.getCustomType(CUSTOM_TYPE.id)).revision, created.revision);
  const updated = await second.saveCustomType({ customType: { ...created, label: "Persistent editor" }, expectedRevision: created.revision });
  assert.equal((await first.getCustomType(CUSTOM_TYPE.id)).label, "Persistent editor");
  assert.equal(updated.revision, 2);
});

test("IndexedDB persists import manifests and atomically records their rollback", async () => {
  const factory = new IDBFactory();
  const dbName = "site2json-import-history-test";
  const legacy = memoryStorage();
  const first = indexedService({ factory, legacyStorage: legacy, dbName });
  const proposal = {
    source: "semantic-catalog", label: "Import example:Person",
    requested: { kind: "class", id: "example:Person" },
    records: { customTypes: [{
      id: "example:Person", label: "Person", description: "A person.",
      definition: { kind: "type", description: "A person.", valueType: "example:Person" },
      provenance: { source: { id: "lov" }, canonicalUri: "https://example.test/Person" }
    }], properties: [] }
  };
  const plan = await first.planImport({ proposal });
  const job = await first.startImport({ planId: plan.id });

  const second = indexedService({ factory, legacyStorage: legacy, dbName });
  assert.equal((await second.listImports()).items[0].id, job.id);
  const recordReference = (await second.getImportJob(job.id)).records[0];
  assert.equal(recordReference.termId, "example:Person");
  assert.match(recordReference.id, new RegExp(`^${job.id}:customType:`));
  const diagnostics = await IndexedDb.createStorage({ indexedDB: factory, toolboxApi: Toolbox, legacyStorage: legacy, dbName }).diagnostics();
  assert.equal(diagnostics.counts.imports, 1);

  const undone = await second.undoImport({ id: job.id });
  assert.equal(undone.status, "undone");
  await assert.rejects(() => first.getCustomType(recordReference.id), (error) => error.code === "NOT_FOUND");
  assert.equal((await first.getImportJob(job.id)).status, "undone");
});

test("IndexedDB storage exposes every bounded record store required by the service", async () => {
  const factory = new IDBFactory();
  const dbName = "site2json-schema-test";
  const storage = IndexedDb.createStorage({ indexedDB: factory, toolboxApi: Toolbox, legacyStorage: memoryStorage(), dbName });
  await storage.ready();
  const database = await new Promise((resolve, reject) => {
    const request = factory.open(dbName, IndexedDb.DATABASE_VERSION);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  assert.deepEqual([...database.objectStoreNames], [...IndexedDb.ALL_STORES].sort());
  database.close();
  await storage.close();
});

test("IndexedDB service pages a five-thousand-type library without returning the full collection", async () => {
  const factory = new IDBFactory();
  const dbName = "site2json-large-library-test";
  const customTypes = {};
  for (let index = 0; index < 5000; index += 1) {
    const id = `bulk:Type${String(index).padStart(4, "0")}`;
    const description = `Imported bulk semantic type ${index}.`;
    customTypes[id] = {
      id,
      label: `Bulk type ${index}`,
      description,
      definition: { kind: "type", valueType: id, description }
    };
  }
  const legacy = memoryStorage({ [Toolbox.STORAGE_KEY]: Toolbox.normalize({ customTypes }) });
  const service = indexedService({ factory, legacyStorage: legacy, dbName });
  const first = await service.search({ query: "Bulk", pageSize: 30 });
  assert.equal(first.total, 5000);
  assert.equal(first.items.length, 30);
  assert.match(first.nextCursor, /^v1:/);
  const second = await service.search({ query: "Bulk", pageSize: 30, cursor: first.nextCursor });
  assert.equal(second.items.length, 30);
  assert.notEqual(second.items[0].id, first.items[0].id);
});
