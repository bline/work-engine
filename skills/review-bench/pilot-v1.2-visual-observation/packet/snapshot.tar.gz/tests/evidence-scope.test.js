"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const EvidenceScope = require("../extension/editor/evidence-scope");

test("recovers repeated entity siblings from co-occurring evidence instead of nested repeated tags", () => {
  const cards = [1, 2, 3].map((index) => `
    <article data-test="job-card">
      <span class="posted">Dec ${10 + index}, 2025</span>
      <h2><a href="/jobs/${index}">Example job ${index}</a></h2>
      <div class="budget">$${index}00 fixed price</div>
      <p class="description">Build a useful system.</p>
      <div class="skills"><a href="/skills/javascript">JavaScript</a><a href="/skills/api">API</a></div>
    </article>`).join("");
  const document = new JSDOM(`
    <nav><a href="/home">Home</a><a href="/about">About</a></nav>
    <main data-test="results">${cards}</main>
  `).window.document;
  const result = EvidenceScope.find(document);
  assert.equal(result.chosen.selector, '[data-test="job-card"]');
  assert.equal(result.chosen.matchCount, 3);
  assert.equal(result.chosen.parentCount, 1);
  assert.equal(result.chosen.identityRatio, 1);
  assert.ok(result.chosen.consistentKinds.includes("heading"));
  assert.ok(result.chosen.consistentKinds.includes("money"));
  assert.ok(result.chosen.consistentKinds.includes("date"));
  assert.equal(result.confidence, "high");
  assert.ok(result.chosen.observations.length >= 4);
});

test("finds Guru result siblings from a captured-shape fixture without site-specific rules", () => {
  const html = fs.readFileSync(path.join(__dirname, "fixtures/guru-search-results.html"), "utf8");
  const dom = new JSDOM(html, { url: "https://www.guru.com/work/" });
  const result = EvidenceScope.find(dom.window.document);
  assert.equal(result.chosen.selector, ".module_list.cozy > li");
  assert.equal(result.chosen.matchCount, 3);
  assert.equal(result.chosen.parentCount, 1);
  assert.equal(result.confidence, "high");
  assert.ok(result.chosen.consistentKinds.includes("url"));
  assert.ok(result.chosen.consistentKinds.includes("money"));
  assert.ok(result.chosen.findings.every((finding) => !/guru/i.test(finding.message)));
  dom.window.close();
});

test("does not mistake a plain navigation link list for a rich entity collection", () => {
  const document = new JSDOM(`<nav class="menu"><a href="/one">One</a><a href="/two">Two</a><a href="/three">Three</a></nav>`).window.document;
  const result = EvidenceScope.find(document);
  assert.equal(result.chosen, null);
  assert.equal(result.confidence, "none");
});

test("rejects a shared class selector when it also captures page-level wrappers", () => {
  const cards = [1, 2, 3].map((index) => `
    <li class="result-card">
      <time datetime="2026-08-${10 + index}">Aug ${10 + index}, 2026</time>
      <h2><a href="/jobs/${index}">Job ${index}</a></h2>
      <span>$${index}00</span>
    </li>`).join("");
  const document = new JSDOM(`
    <body class="responsive resp">
      <form class="responsive resp"><ul class="results">${cards}</ul></form>
    </body>
  `).window.document;
  const result = EvidenceScope.find(document);
  assert.notEqual(result.chosen?.selector, ".responsive.resp");
  assert.equal(result.chosen?.selector, ".result-card");
  assert.equal(result.chosen?.matchCount, 3);
});

test("falls back to a confident collection-shaped singleton on an article detail page", () => {
  const document = new JSDOM(`
    <header><nav><a href="/">Home</a></nav></header>
    <main>
      <article class="post-detail">
        <h1>How automatic extraction works</h1>
        <time datetime="2026-08-13">August 13, 2026</time>
        <p>This detailed article contains enough useful prose to represent one rendered item. It explains how extraction identifies content and preserves semantic meaning across a page.</p>
        <p>A second paragraph provides additional examples, context, and evidence so the detail boundary can be distinguished from navigation.</p>
      </article>
    </main>
  `).window.document;
  const result = EvidenceScope.find(document);
  assert.equal(result.mode, "single");
  assert.equal(result.confidence, "high");
  assert.equal(result.chosen.selector, "article");
  assert.equal(result.chosen.matchCount, 1);
  assert.ok(result.chosen.observations.length > 0);
});

test("keeps a split detail title and body together when their shared root is convincing", () => {
  const document = new JSDOM(`
    <body>
      <header class="masthead"><h1>Site2JSON redesign review and implementation notes</h1></header>
      <div class="layout">
        <nav><a href="/one">One</a></nav>
        <main class="content">
          <p>This detailed document contains a substantial body separated from its title by an unusual layout. The detector should preserve both pieces when they describe one item.</p>
          <p>There is enough prose and semantic evidence here to distinguish the content from ordinary application chrome and navigation.</p>
        </main>
      </div>
    </body>
  `).window.document;
  const result = EvidenceScope.find(document);
  assert.equal(result.mode, "single");
  assert.equal(result.confidence, "high");
  assert.equal(result.chosen.selector, "body");
  assert.ok(result.chosen.findings.some((finding) => /entity header and substantial sibling content/i.test(finding.message)));
});

test("an entity header and substantial content sibling select their smallest common parent", () => {
  const document = new JSDOM(`
    <div class="detail-shell">
      <header>
        <h1>A split-layout article without a main element</h1>
        <time datetime="2026-08-13">August 13, 2026</time>
      </header>
      <section class="prose">
        <p>This article body is a sibling of its semantic header rather than a descendant of it. The shared parent is therefore the smallest complete entity boundary available to extraction.</p>
        <p>Additional prose gives the structural detector enough meaningful content to distinguish this entity from a toolbar, navigation header, or another piece of application chrome.</p>
      </section>
    </div>
  `).window.document;
  const result = EvidenceScope.find(document);
  assert.equal(result.mode, "single");
  assert.equal(result.confidence, "high");
  assert.equal(result.chosen.selector, ".detail-shell");
  assert.equal(result.chosen.reason, "header-content-siblings");
});

test("a primary article beats a high-scoring related collection", () => {
  const related = [1, 2, 3].map((index) => `
    <article data-test="related-card">
      <h2><a href="/related/${index}">Related story ${index}</a></h2>
      <time datetime="2026-08-${10 + index}">August ${10 + index}, 2026</time>
      <img src="/related-${index}.jpg" alt="Related story ${index}">
      <span>$${index}00 · ${90 + index}% recommended</span>
    </article>`).join("");
  const document = new JSDOM(`
    <main>
      <article class="post-detail">
        <h1>The primary article on this detail page</h1>
        <time datetime="2026-08-13">August 13, 2026</time>
        <p>This is the primary article content and it remains meaningful after every related card is removed from consideration. It contains the subject the visitor intentionally opened.</p>
        <p>A second substantial paragraph establishes that the singleton is not merely a wrapper around the recommendations rendered elsewhere on this page.</p>
      </article>
      <section class="related-recommendations"><h2>Related stories</h2>${related}</section>
    </main>
  `).window.document;
  const repeated = EvidenceScope.findRepeating(document);
  assert.equal(repeated.confidence, "high", "the related collection must be genuinely competitive for this regression");
  assert.equal(repeated.chosen.secondaryContextRatio, 1);
  const result = EvidenceScope.find(document);
  assert.equal(result.mode, "single");
  assert.equal(result.chosen.selector, ".post-detail");
  assert.equal(result.arbitration.winner, "single");
  assert.equal(result.arbitration.reason, "primary-detail");
  assert.equal(result.secondaryScopes[0].selector, '[data-test="related-card"]');
});

test("a credible repeated collection wins before the singleton fallback", () => {
  const cards = [1, 2, 3].map((index) => `
    <article data-test="result-card">
      <h2><a href="/jobs/${index}">Job ${index}</a></h2>
      <time datetime="2026-08-${10 + index}">August ${10 + index}, 2026</time>
      <p>A sufficiently descriptive result summary for this particular opportunity.</p>
      <span>$${index}00 fixed price</span>
    </article>`).join("");
  const document = new JSDOM(`<main>${cards}</main>`).window.document;
  const result = EvidenceScope.find(document);
  assert.equal(result.mode, "collection");
  assert.equal(result.chosen.selector, '[data-test="result-card"]');
  assert.equal(result.chosen.matchCount, 3);
  assert.equal(result.chosen.entityIndependence.topologyRatio, 1);
  assert.equal(result.chosen.entityIndependence.completenessRatio, 1);
});

test("nested repeated-looking matches cannot claim high collection confidence", () => {
  const document = new JSDOM(`
    <main>
      <div class="job-section">
        <h1><a href="/jobs/one">Senior engineer</a></h1>
        <time datetime="2026-08-14">August 14, 2026</time>
        <div class="job-section">
          <h2><a href="/jobs/one">About the job</a></h2>
          <p>This is the second half of the same detailed job, not another independently extractable result.</p>
          <span>$120000 USD</span>
        </div>
      </div>
    </main>
  `).window.document;
  const repeated = EvidenceScope.findRepeating(document);
  const nested = repeated.candidates.find((candidate) => candidate.selector === ".job-section");
  assert.ok(nested);
  assert.ok(nested.entityIndependence.nestedMatchCount >= 2);
  assert.ok(nested.findings.some((finding) => /not independent collection items/i.test(finding.message)));
  assert.notEqual(repeated.confidence, "high");
  const result = EvidenceScope.find(document);
  assert.notEqual(result.confidence, "high");
});

test("fragmented siblings cannot outrank their complete singleton parent", () => {
  const document = new JSDOM(`
    <main>
      <section class="job-fragment">
        <h1><a href="/jobs/one">Senior engineer</a></h1>
        <time datetime="2026-08-14">August 14, 2026</time>
        <span>$120000 USD</span>
      </section>
      <section class="job-fragment">
        <h2><a href="/apply/one">Job description and application</a></h2>
        <time datetime="2026-08-14">August 14, 2026</time>
        <p>This long description belongs to the same detailed job. It explains the role, responsibilities, qualifications, team, location, and application process. The successful engineer will build reliable systems, collaborate with several teams, document technical decisions, review implementations, mentor colleagues, and improve the product over time. This additional material deliberately makes the body fragment much larger than the compact summary fragment rendered above it.</p>
        <span>$120000 USD</span>
      </section>
    </main>
  `).window.document;
  const repeated = EvidenceScope.findRepeating(document);
  const fragments = repeated.candidates.find((candidate) => candidate.selector === ".job-fragment");
  assert.ok(fragments);
  assert.ok(fragments.entityIndependence.sizeBalance < 0.3);
  assert.ok(fragments.findings.some((finding) => /split into fragments/i.test(finding.message)));
  assert.notEqual(repeated.confidence, "high");
});

test("duplicate identities cannot claim high collection confidence", () => {
  const rows = ["Primary job summary", "SEO repetition"].map((label) => `
    <section class="job-copy">
      <h2><a href="/jobs/one?utm_source=duplicate">${label}</a></h2>
      <time datetime="2026-08-14">August 14, 2026</time>
      <p>Repeated information about the same detailed opportunity.</p>
      <span>$120000 USD</span>
    </section>`).join("");
  const document = new JSDOM(`<main><h1>Senior engineer</h1>${rows}</main>`, { url: "https://example.test/jobs/one" }).window.document;
  const repeated = EvidenceScope.findRepeating(document);
  const duplicate = repeated.candidates.find((candidate) => candidate.selector === ".job-copy");
  assert.ok(duplicate);
  assert.equal(duplicate.entityIndependence.identityDistinctness, 0.5);
  assert.ok(duplicate.findings.some((finding) => /identity repeats/i.test(finding.message)));
  assert.notEqual(repeated.confidence, "high");
});

test("a results-page header beside the result content does not turn the page into one detail item", () => {
  const cards = [1, 2, 3].map((index) => `
    <article data-test="result-card">
      <h2><a href="/jobs/${index}">Job ${index}</a></h2>
      <time datetime="2026-08-${10 + index}">August ${10 + index}, 2026</time>
      <p>A descriptive result summary for opportunity ${index} with enough meaningful text to form a card.</p>
      <span>$${index}00 fixed price</span>
    </article>`).join("");
  const document = new JSDOM(`
    <body>
      <header><h1>Find available freelance jobs</h1></header>
      <main>${cards}</main>
    </body>
  `).window.document;
  const singleton = EvidenceScope.findSingleton(document);
  assert.ok(singleton.candidates.some((candidate) => candidate.reason === "header-content-siblings"), "the sibling-header heuristic must be exercised by this regression");
  const result = EvidenceScope.find(document);
  assert.equal(result.mode, "collection");
  assert.equal(result.chosen.selector, '[data-test="result-card"]');
  assert.equal(result.arbitration.winner, "collection");
});

test("a substantial results header and filters do not beat content dominated by repeated cards", () => {
  const cards = Array.from({ length: 20 }, (_, index) => `
    <li data-test="result-card">
      <h2><a href="/jobs/${index}">Opportunity ${index}</a></h2>
      <time datetime="2026-08-${String((index % 20) + 1).padStart(2, "0")}">August ${index + 1}, 2026</time>
      <p>This rendered opportunity has a substantial description, location, required skills, buyer details, and project terms for the person reviewing search results.</p>
      <span>$${index + 1}00 fixed price</span>
    </li>`).join("");
  const document = new JSDOM(`
    <main id="search-app">
      <header><h1>Find freelance opportunities</h1></header>
      <section class="search-controls">
        <p>Search all categories, choose employer spend, adjust filters, sort the results, save this query, and review recently posted work matching your experience.</p>
        <p>Use the controls below to narrow the marketplace by location, budget, duration, skills, availability, and verified employer history.</p>
      </section>
      <ul id="results">${cards}</ul>
    </main>
  `).window.document;
  const result = EvidenceScope.find(document);
  assert.equal(result.mode, "collection");
  assert.equal(result.chosen.selector, '[data-test="result-card"]');
  assert.equal(result.arbitration.winner, "collection");
  assert.ok(result.arbitration.repeatedWords > 300);
});

test("does not promote navigation-only chrome into a singleton detail item", () => {
  const document = new JSDOM(`<nav class="menu"><a href="/one">One</a><a href="/two">Two</a><a href="/three">Three</a></nav>`).window.document;
  const result = EvidenceScope.find(document);
  assert.equal(result.chosen, null);
  assert.equal(result.confidence, "none");
});

test("manual singleton inference uses the same scorer around the selected article content", () => {
  const document = new JSDOM(`<main><article><h1>Selected detail</h1><p>A concise body chosen explicitly by its author.</p></article></main>`).window.document;
  const result = EvidenceScope.findSingleton(document, { selectedElement: document.querySelector("p"), includeObservations: false });
  assert.equal(result.mode, "single");
  assert.equal(result.chosen.selector, "article");
  assert.ok(result.levels.some((level) => level.best?.selector === "article"));
});

test("manual singleton inference preserves an explicitly selected body split-layout scope", () => {
  const document = new JSDOM(`<body><header><h1>Split title</h1></header><main><p>Split body</p></main></body>`).window.document;
  const result = EvidenceScope.findSingleton(document, { selectedElement: document.body, includeObservations: false });
  assert.equal(result.chosen.selector, "body");
  assert.ok(result.levels.some((level) => level.best?.selector === "main"));
});

test("manual selection inside split content offers the header and content common parent", () => {
  const document = new JSDOM(`
    <div class="detail-shell">
      <header><h1>Split entity title</h1><time datetime="2026-08-13">August 13, 2026</time></header>
      <div class="body-copy">
        <p>The selected paragraph belongs to an entity whose title is rendered in a sibling header. Its common parent must remain available as the complete extraction boundary.</p>
        <p>Substantial additional prose keeps the signal distinct from a site toolbar or a short navigation heading in ordinary application chrome.</p>
      </div>
    </div>
  `).window.document;
  const result = EvidenceScope.findSingleton(document, { selectedElement: document.querySelector("p"), includeObservations: false });
  assert.equal(result.chosen.selector, ".detail-shell");
  assert.equal(result.chosen.reason, "header-content-siblings");
});
