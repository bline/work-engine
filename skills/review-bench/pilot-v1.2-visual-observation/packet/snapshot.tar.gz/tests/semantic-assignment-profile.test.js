"use strict";

const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const assert = require("node:assert/strict");
const profileCompiler = require("../extension/authoring/semantic-assignment-profile");
const semanticAssignment = require("../extension/ir/semantic-assignment");
const semanticDom = require("../extension/ir/semantic-dom");
const serialization = require("../extension/ir/serialization");

test("compiles bounded Schema.org domain, range, and relationship evidence", () => {
  const profile = profileCompiler.compile({ candidateTypes: ["JobPosting", "Article", "Product"] });
  assert.equal(profile.format, profileCompiler.FORMAT);
  assert.match(profile.digest, /^fnv1a32:[0-9a-f]{8}$/);
  assert.equal(profile.bounded.truncated, false);

  const job = profile.types.find((type) => type.term.endsWith("/JobPosting"));
  const article = profile.types.find((type) => type.term.endsWith("/Article"));
  const product = profile.types.find((type) => type.term.endsWith("/Product"));
  assert.ok(job.signals["https://schema.org/datePosted"] > 0);
  assert.ok(article.signals["https://schema.org/datePublished"] > 0);
  assert.equal(product.signals["https://schema.org/price"], undefined, "Product.price must not be invented; price belongs through offers");
  assert.deepEqual(product.relationships.find((relationship) => relationship.term.endsWith("/offers")).targetTypes, [
    "https://schema.org/Demand", "https://schema.org/Offer"
  ]);
  assert.deepEqual(product.relationships.find((relationship) => relationship.term.endsWith("/offers")).materializations, [{
    role: "price",
    property: "https://schema.org/price",
    targetType: "https://schema.org/Offer",
    ranges: ["Number", "Text"],
    score: 5,
    source: "schema"
  }]);
  assert.deepEqual(
    product.relationships.flatMap((relationship) => relationship.materializations.map((materialization) => [relationship.term, materialization.targetType, materialization.property])),
    [["https://schema.org/offers", "https://schema.org/Offer", "https://schema.org/price"]],
    "valid but unreviewed ontology paths must not invent nested entities"
  );
  assert.deepEqual(job.relationships.find((relationship) => relationship.term.endsWith("/baseSalary"))?.materializations || [], []);
  assert.deepEqual(article.relationships.find((relationship) => relationship.term.endsWith("/offers"))?.materializations || [], []);
  assert.deepEqual(profile.roleCandidates.author.find((candidate) => candidate.term.endsWith("/author")).ranges, ["Organization", "Person"]);
});

test("compiles installed local types and properties with provenance", () => {
  const editor = {
    id: "site:Editor",
    label: "Editor",
    definition: { kind: "type", canonicalUri: "https://example.test/vocab#Editor" }
  };
  const portfolio = {
    id: "site:portfolioUrl",
    definition: {
      kind: "field",
      canonicalUri: "https://example.test/vocab#portfolioUrl",
      domainIncludes: ["site:Editor"],
      rangeIncludes: ["URL"],
      authoringProfile: { aliases: ["url", "portfolio"], salience: 90 }
    }
  };
  const worksFor = {
    id: "site:worksFor",
    definition: {
      kind: "relationship",
      canonicalUri: "https://example.test/vocab#worksFor",
      domainIncludes: ["site:Editor"],
      rangeIncludes: ["Organization"]
    }
  };
  const profile = profileCompiler.compile({
    candidateTypes: ["site:Editor"],
    libraryTypes: [editor],
    libraryProperties: [portfolio, worksFor]
  });
  const type = profile.types[0];
  assert.equal(type.term, "https://example.test/vocab#Editor");
  assert.equal(type.source, "local-vocabulary");
  assert.ok(type.signals["https://example.test/vocab#portfolioUrl"] > 0);
  assert.equal(type.relationships[0].term, "https://example.test/vocab#worksFor");
  assert.deepEqual(profile.provenance.localTypeIds, ["site:Editor"]);
  assert.deepEqual(profile.provenance.localPropertyIds.sort(), ["site:portfolioUrl", "site:worksFor"]);

  const tree = semanticDom.document({
    id: "editor-1",
    kind: "entity",
    children: [{ id: "portfolio-1", kind: "value", role: "url", value: "https://example.test/me" }]
  });
  const result = semanticAssignment.assign(tree, { profile, variants: { minScore: 2, minMargin: 1 } });
  assert.equal(result.tree.root.term, "https://example.test/vocab#Editor");
  assert.equal(result.tree.root.children[0].term, "https://example.test/vocab#portfolioUrl");
  assert.equal(result.findings[0].candidates[0].source, "local-vocabulary");
  assert.equal(result.findings[0].candidates[0].observedShape, "URL");
});

test("runtime semantic assignment dependency graph has no catalog or storage dependency", () => {
  const entry = path.join(__dirname, "../extension/ir/semantic-assignment.js");
  const visited = new Set();
  function visit(filename) {
    const resolved = require.resolve(filename);
    if (visited.has(resolved)) return;
    visited.add(resolved);
    const source = fs.readFileSync(resolved, "utf8");
    assert.doesNotMatch(source, /schema-catalog|schema-vocabulary|indexeddb/i, `runtime dependency leaked through ${path.basename(resolved)}`);
    for (const match of source.matchAll(/require\(["'](\.[^"']+)["']\)/g)) visit(path.resolve(path.dirname(resolved), match[1]));
  }
  visit(entry);
  assert.deepEqual([...visited].map((filename) => path.basename(filename)).sort(), [
    "semantic-assignment.js", "semantic-dom.js", "type-assignment.js"
  ]);
});

test("the no-profile fallback does not treat direct price as Product evidence", () => {
  const product = require("../extension/ir/type-assignment").DEFAULT_TYPES.find((type) => type.term.endsWith("/Product"));
  assert.equal(product.signals["https://schema.org/price"], undefined);
});

test("range evidence distinguishes exact values while preserving entity labels", () => {
  assert.deepEqual(semanticAssignment.rangeEvidence({ value: "2026-08-15" }, ["Date"]), {
    compatible: true, score: 2, observed: "Date", declared: ["Date"], materialization: "exact"
  });
  const author = semanticAssignment.rangeEvidence({ value: "Ada Lovelace" }, ["Person", "Organization"]);
  assert.equal(author.compatible, true);
  assert.equal(author.materialization, "entity-label");
});

test("materializes Product offers and serializes Offer price as a nested entity", () => {
  const profile = profileCompiler.compile({ candidateTypes: ["Product", "Thing"] });
  const tree = semanticDom.document({
    id: "product-1",
    kind: "entity",
    children: [
      { id: "product-name", kind: "value", role: "title", value: "Visual Analyzer" },
      { id: "product-price", kind: "value", role: "price", value: "49.00" }
    ]
  });
  const result = semanticAssignment.assign(tree, { profile });
  assert.equal(result.tree.root.term, "https://schema.org/Product");
  const offer = result.tree.root.children.find((child) => child.kind === "entity");
  assert.equal(offer.term, "https://schema.org/Offer");
  assert.equal(offer.assignment.relationship, "https://schema.org/offers");
  assert.equal(offer.children[0].term, "https://schema.org/price");
  assert.deepEqual(serialization.serialize(semanticDom.document({
    id: "products", kind: "collection", children: [result.tree.root]
  })).data["@graph"], [{
    "@type": "Product",
    name: "Visual Analyzer",
    offers: { "@type": "Offer", price: "49.00" }
  }]);
  assert.equal(result.findings.find((finding) => finding.role === "price").candidates[0].relationship, "https://schema.org/offers");
});

test("compiles authored graph priorities and coalesces multiple fields into one related entity", () => {
  const composition = {
    id: "test:product-offer",
    root: "product",
    nodes: {
      product: { types: ["Product"], expectation: "core" },
      offer: { types: ["Offer"], expectation: "common" }
    },
    edges: [{ from: "product", property: "offers", to: "offer", expectation: "common" }],
    priorities: { product: ["name"], offer: ["price", "priceCurrency"] }
  };
  const profile = profileCompiler.compile({ candidateTypes: ["Product", "Thing"], composition });
  const offers = profile.types.find((type) => type.term.endsWith("/Product")).relationships.find((relationship) => relationship.term.endsWith("/offers"));
  assert.deepEqual(offers.materializations.map((item) => item.role), ["price", "priceCurrency"]);
  assert.equal(offers.materializationWeight, 4);
  assert.deepEqual(profile.provenance.compositionIds, ["test:product-offer"]);

  const result = semanticAssignment.assign(semanticDom.document({
    id: "product-2",
    kind: "entity",
    children: [
      { id: "name-2", kind: "value", role: "title", value: "Portable analyzer" },
      { id: "price-2", kind: "value", role: "price", value: "79.00" },
      { id: "currency-2", kind: "value", role: "priceCurrency", value: "USD" }
    ]
  }), { profile });
  const offer = result.tree.root.children.find((child) => child.assignment?.relationship?.endsWith("/offers"));
  assert.deepEqual(offer.children.map((child) => child.term), ["https://schema.org/price", "https://schema.org/priceCurrency"]);
  assert.equal(result.tree.root.children.filter((child) => child.assignment?.relationship?.endsWith("/offers")).length, 1);
});

test("compiles a local-vocabulary graph into a portable nested runtime profile", () => {
  const libraryTypes = [
    { id: "store:Listing", definition: { kind: "type", canonicalUri: "https://example.test/store#Listing" } },
    { id: "store:Quote", definition: { kind: "type", canonicalUri: "https://example.test/store#Quote" } }
  ];
  const libraryProperties = [
    { id: "store:quote", definition: { kind: "relationship", canonicalUri: "https://example.test/store#quote", domainIncludes: ["store:Listing"], rangeIncludes: ["store:Quote"] } },
    { id: "store:amount", definition: { kind: "field", canonicalUri: "https://example.test/store#amount", domainIncludes: ["store:Quote"], rangeIncludes: ["Number"] } },
    { id: "store:currency", definition: { kind: "field", canonicalUri: "https://example.test/store#currency", domainIncludes: ["store:Quote"], rangeIncludes: ["Text"] } }
  ];
  const composition = {
    id: "store:listing-quote",
    root: "listing",
    nodes: {
      listing: { types: ["store:Listing"], expectation: "core" },
      quote: { types: ["store:Quote"], expectation: "common" }
    },
    edges: [{ from: "listing", property: "store:quote", to: "quote", expectation: "common" }],
    priorities: { quote: ["store:amount", "store:currency"] }
  };
  const profile = profileCompiler.compile({ composition, libraryTypes, libraryProperties });
  assert.deepEqual(profile.provenance.localTypeIds.sort(), ["store:Listing", "store:Quote"]);
  assert.deepEqual(profile.provenance.localPropertyIds.sort(), ["store:amount", "store:currency", "store:quote"]);
  const result = semanticAssignment.assign(semanticDom.document({
    id: "listing-local",
    kind: "entity",
    children: [
      { id: "amount-local", kind: "value", role: "amount", value: "125" },
      { id: "currency-local", kind: "value", role: "currency", value: "USD" }
    ]
  }), { profile });
  assert.equal(result.tree.root.term, "https://example.test/store#Listing");
  const quote = result.tree.root.children[0];
  assert.equal(quote.term, "https://example.test/store#Quote");
  assert.equal(quote.assignment.relationship, "https://example.test/store#quote");
  assert.deepEqual(quote.children.map((child) => child.term), ["https://example.test/store#amount", "https://example.test/store#currency"]);
});

test("carries a bounded authored relationship path through deep nested serialization", () => {
  const composition = {
    id: "test:item-list-product-offer",
    root: "list",
    nodes: {
      list: { types: ["ItemList"], expectation: "core" },
      entry: { types: ["ListItem"], expectation: "common" },
      product: { types: ["Product"], expectation: "common" },
      offer: { types: ["Offer"], expectation: "optional" }
    },
    edges: [
      { from: "list", property: "itemListElement", to: "entry", expectation: "common" },
      { from: "entry", property: "item", to: "product", expectation: "common" },
      { from: "product", property: "offers", to: "offer", expectation: "optional" }
    ],
    priorities: { offer: ["price"] }
  };
  const profile = profileCompiler.compile({ composition, candidateTypes: ["ItemList", "Thing"] });
  const relation = profile.types.find((type) => type.term.endsWith("/ItemList")).relationships.find((item) => item.term.endsWith("/itemListElement"));
  assert.deepEqual(relation.materializations[0].path.map((step) => step.relationship.split("/").pop()), ["itemListElement", "item", "offers"]);
  const assigned = semanticAssignment.assign(semanticDom.document({
    id: "list-deep", kind: "entity", children: [{ id: "deep-price", kind: "value", role: "price", value: "19.00" }]
  }), { profile });
  const output = serialization.serialize(semanticDom.document({ id: "lists", kind: "collection", children: [assigned.tree.root] })).data["@graph"][0];
  assert.deepEqual(output, {
    "@type": "ItemList",
    itemListElement: { "@type": "ListItem", item: { "@type": "Product", offers: { "@type": "Offer", price: "19.00" } } }
  });
});
