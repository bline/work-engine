"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Pipeline = require("../extension/ir/pipeline");
const SemanticAssignmentProfile = require("../extension/authoring/semantic-assignment-profile");
const v2ReviewSurface = require("../extension/ir/v2-review-surface");
const { bridgeDetectSemanticDomV2, bridgeFocusPageDetectionV2, bridgeFocusSemanticDomV2, bridgePreviewSemanticDomV2, bridgeSurveySemanticDomV2 } = require("../extension/editor/sidebar-page-bridge");

test("the browser V2 survey returns bounded JSON-safe authoring evidence without DOM references", () => {
  const dom = new JSDOM(`
    <main><ul>
      <li class="job-card"><h2><a href="/a">Alpha role</a></h2><p>First job description.</p><span>Posted yesterday</span></li>
      <li class="job-card"><h2><a href="/b">Beta role</a></h2><p>Second job description.</p><span>Posted 2 days ago</span></li>
    </ul></main>
  `, { url: "https://example.test/jobs", runScripts: "outside-only" });
  dom.window.Site2JsonIrPageDetection = require("../extension/ir/page-detection");
  const result = dom.window.eval(`(${bridgeSurveySemanticDomV2.toString()})(${JSON.stringify({ plan: { collection: { id: "survey" } } })})`);
  assert.equal(result.ok, true);
  assert.ok(result.summary.surveyedCount > 0);
  assert.ok(result.observations.some((observation) => observation.suggestedName === "datePosted"));
  assert.ok(result.observations.every((observation) => observation.provenance.decision === "observed"));
  assert.ok(result.observations.find((observation) => observation.suggestedName === "title").provenance.occurrences >= 2);
  assert.equal(result.observations.find((observation) => observation.suggestedName === "title").sampleValues.length, 2);
  assert.doesNotThrow(() => JSON.stringify(result));
  assert.doesNotMatch(JSON.stringify(result), /HTML\w*Element|ownerDocument|sourceRefs/);
});

test("the browser V2 bridge returns a JSON-safe live semantic-DOM preview", () => {
  const dom = new JSDOM(`
    <main>
      <article><h2><a href="/a">Alpha</a></h2><p>$10.00</p></article>
      <article><h2><a href="/b">Beta</a></h2><p>$20.00</p></article>
    </main>
  `, { url: "https://example.test/products", runScripts: "outside-only" });
  dom.window.Site2JsonIrPipeline = Pipeline;
  const profile = SemanticAssignmentProfile.compile({ candidateTypes: ["Product", "Thing"] });
  dom.window.Site2JsonIrV2ReviewSurface = v2ReviewSurface;

  // Browser bridges serialize the function before evaluating it in the page.
  // Exercise that boundary instead of calling it with Node module closures.
  const result = dom.window.eval(`(${bridgePreviewSemanticDomV2.toString()})(${JSON.stringify({
    profile,
    focusModel: { root: "listing", nodes: { listing: { types: ["Thing"] } }, edges: [] },
    plan: { collection: { id: "live-preview" } }
  })})`);

  assert.equal(result.ok, true);
  assert.match(result.previewId, /^v2:/);
  assert.equal(result.pageUrl, "https://example.test/products");
  assert.equal(result.profileDigest, profile.digest);
  assert.equal(result.summary.entityCount, 2);
  assert.equal(result.summary.grouping.hardValid, true);
  assert.equal(result.summary.grouping.entityCount, 2);
  assert.deepEqual(result.output["@graph"].map((entity) => entity["@type"]), ["Thing", "Thing"]);
  assert.equal(result.formats.markup.format, "site2json-s2j-markup");
  assert.deepEqual(result.formats.compact.entities.map((entity) => entity.type), ["Thing", "Thing"]);
  assert.deepEqual(result.formats.jsonld, result.output);
  assert.deepEqual([...result.focusIndex.aliases.listing.nodeIds], ["live-preview:item:1", "live-preview:item:2"]);
  assert.deepEqual([...result.focusIndex.aliases.listing.formats.jsonld], ["/@graph/0", "/@graph/1"]);
  assert.deepEqual(result.reviewIndex.entities.map((entry) => entry.entityId), ["live-preview:item:1", "live-preview:item:2"]);
  assert.ok(result.reviewIndex.fields.length > 0);
  assert.ok(result.reviewIndex.fields.every((entry) => entry.formats.markup.length > 0));
  assert.deepEqual(result.evidence.reports.map((report) => report.selected), ["https://schema.org/Thing", "https://schema.org/Thing"]);
  assert.doesNotThrow(() => JSON.stringify(result));
  assert.doesNotMatch(JSON.stringify(result), /HTMLArticleElement|ownerDocument|sourceRefs/);

  const highlighted = [];
  dom.window.Site2JsonPageHighlighter = {
    setElementGroup(_config, elements) { highlighted.push(...elements); return { shown: elements.length }; },
    clearGroup() {}
  };
  const focus = dom.window.eval(`(${bridgeFocusSemanticDomV2.toString()})(${JSON.stringify({
    previewId: result.previewId,
    alias: "listing",
    reveal: false
  })})`);
  assert.equal(focus.ok, true);
  assert.equal(focus.nodeIds.length, 2);
  assert.equal(focus.sourceCount, 2);
  assert.deepEqual(highlighted, [...dom.window.document.querySelectorAll("article")]);

  const reviewFocus = dom.window.eval(`(${bridgeFocusSemanticDomV2.toString()})(${JSON.stringify({
    previewId: result.previewId,
    kind: "review",
    reviewKind: "entity",
    reviewId: "live-preview:item:1",
    reveal: false
  })})`);
  assert.equal(reviewFocus.ok, true);
  assert.deepEqual([...reviewFocus.nodeIds], ["live-preview:item:1"]);
  assert.equal(reviewFocus.sourceCount, 1);

  const unknownReviewFocus = dom.window.eval(`(${bridgeFocusSemanticDomV2.toString()})(${JSON.stringify({
    previewId: result.previewId,
    kind: "review",
    reviewKind: "field",
    reviewId: "not-in-this-preview",
    reveal: false
  })})`);
  assert.equal(unknownReviewFocus.ok, true);
  assert.deepEqual([...unknownReviewFocus.nodeIds], []);
  assert.equal(unknownReviewFocus.sourceCount, 0);

  const corrected = dom.window.eval(`(${bridgePreviewSemanticDomV2.toString()})(${JSON.stringify({
    profile,
    focusModel: { root: "listing", nodes: { listing: { types: ["Thing"] } }, edges: [] },
    plan: { collection: { id: "live-preview" } },
    overlay: { reports: [{ entityId: "live-preview:item:1", status: "accepted", accepted: true, selected: "https://schema.org/Product" }] }
  })})`);
  assert.deepEqual(corrected.output["@graph"].map((entity) => entity["@type"]), ["Product", "Thing"]);
  assert.equal(corrected.reviewIndex.entities[0].status, "accepted");
  assert.equal(corrected.reviewIndex.entities[0].selected, "https://schema.org/Product");
  assert.equal(corrected.evidence.reports[0].selected, "https://schema.org/Thing", "the observed evidence remains distinct from the corrected effective state");
});

test("live-preview focus keeps namespaces distinct and resolves every graph path to an alias", () => {
  const dom = new JSDOM(`<main><article></article></main>`, { url: "https://example.test/jobs", runScripts: "outside-only" });
  const value = (id, term, relationship) => ({
    id, kind: "entity", term,
    assignment: relationship ? { relationship } : {},
    children: []
  });
  const hiring = value("organization:hiring", "https://schema.org/Organization", "https://schema.org/hiringOrganization");
  const provider = value("organization:provider", "https://schema.org/Organization", "https://schema.org/provider");
  const localCollision = value("organization:local", "https://example.test/vocab#Organization", "https://schema.org/hiringOrganization");
  const listing = value("listing:1", "https://schema.org/JobPosting");
  listing.children.push(hiring, provider, localCollision);
  const tree = { format: "site2json-s2j-markup", root: { id: "root", kind: "root", children: [listing] } };
  dom.window.Site2JsonIrPipeline = {
    infer() {
      return {
        tree,
        observed: { sourceRefs: new Map() },
        semantics: { findings: [], reports: [] },
        grouping: { winner: { id: "manual", kind: "collection", score: 1, hardValid: true, sources: [dom.window.document.querySelector("article")], axes: {}, evidence: [] } },
        output: { data: { "@context": "https://schema.org", "@graph": [{ "@type": "JobPosting" }] }, compact: { entities: [] } }
      };
    }
  };
  const args = {
    profile: { digest: "test" },
    focusModel: {
      root: "listing",
      nodes: {
        listing: { types: ["JobPosting"] },
        organization: { types: ["Organization"] }
      },
      edges: [
        { from: "listing", property: "hiringOrganization", to: "organization" },
        { from: "listing", property: "provider", to: "organization" }
      ]
    },
    plan: { collection: { id: "manual" } }
  };
  dom.window.Site2JsonIrV2ReviewSurface = v2ReviewSurface;
  const result = dom.window.eval(`(${bridgePreviewSemanticDomV2.toString()})(${JSON.stringify(args)})`);
  assert.equal(result.ok, true);
  assert.deepEqual([...result.focusIndex.aliases.organization.nodeIds].sort(), ["organization:hiring", "organization:provider"]);
  assert.equal(result.focusIndex.aliases.organization.nodeIds.includes("organization:local"), false, "a local type with the same leaf name must remain distinct");
  const edgeEntries = Object.values(result.focusIndex.edges);
  assert.deepEqual(JSON.parse(JSON.stringify(edgeEntries.map((entry) => entry.nodeIds))), [["organization:hiring"], ["organization:provider"]]);
  dom.window.close();
});

test("the browser V2 bridge returns a JSON-safe multi-group page detection ledger", () => {
  const dom = new JSDOM(`
    <main>
      <section data-testid="articles">
        <article><h2><a href="/a">Alpha article</a></h2><p>First article description for detection.</p><time class="published" datetime="2026-08-01"></time><span class="author">Ada</span></article>
        <article><h2><a href="/b">Beta article</a></h2><p>Second article description for detection.</p><time class="published" datetime="2026-08-02"></time><span class="author">Bob</span></article>
      </section>
      <section data-testid="jobs">
        <article><h2><a href="/j1">First job</a></h2><p>First job description for detection.</p><time class="posted" datetime="2026-08-03"></time><span class="employment">FULL_TIME</span></article>
        <article><h2><a href="/j2">Second job</a></h2><p>Second job description for detection.</p><time class="posted" datetime="2026-08-04"></time><span class="employment">PART_TIME</span></article>
      </section>
    </main>
  `, { url: "https://example.test/mixed", runScripts: "outside-only" });
  dom.window.Site2JsonIrPipeline = Pipeline;
  const assignmentProfile = SemanticAssignmentProfile.compile({ candidateTypes: ["Article", "JobPosting", "Thing"] });
  dom.window.Site2JsonIrV2ReviewSurface = v2ReviewSurface;
  const result = dom.window.eval(`(${bridgeDetectSemanticDomV2.toString()})(${JSON.stringify({
    profile: assignmentProfile,
    plan: { collection: { id: "page-detection" } }
  })})`);

  assert.equal(result.ok, true);
  assert.equal(result.summary.selectedCount, 2);
  assert.deepEqual(JSON.parse(JSON.stringify(result.selected.map((detection) => detection.typeSignature))), [
    ["https://schema.org/Article"],
    ["https://schema.org/JobPosting"]
  ]);
  assert.ok(result.candidates.some((candidate) => candidate.status === "alternative"));
  assert.doesNotThrow(() => JSON.stringify(result));
  assert.doesNotMatch(JSON.stringify(result), /HTML\w*Element|ownerDocument|sourceRefs/);

  let highlighted = [];
  dom.window.Site2JsonPageHighlighter = {
    setElementGroup(_options, sources) { highlighted = sources; return { shown: sources.length }; },
    clearGroup() { highlighted = []; }
  };
  const focused = dom.window.eval(`(${bridgeFocusPageDetectionV2.toString()})(${JSON.stringify({
    detectionId: result.selected[0].id,
    entityIndex: 0,
    role: "title"
  })})`);
  assert.equal(focused.ok, true);
  assert.equal(focused.sourceCount, 1);
  assert.equal(highlighted[0].tagName, "H2");
  dom.window.close();
});
