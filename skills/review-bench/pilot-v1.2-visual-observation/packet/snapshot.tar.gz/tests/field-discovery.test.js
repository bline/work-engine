"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const FieldDiscovery = require("../extension/editor/field-discovery");

function resultsDocument() {
  const cards = [1, 2, 3].map((index) => `
    <li class="card">
      <a class="resultTitle" href="/jobs/${index}">Engineer ${index}</a>
      <p class="summary">Build a system ${index}</p>
      <div class="mysteryCode">Code ${index}</div>
      <ul class="skills"><li class="skill">Python</li><li class="skill">API</li></ul>
    </li>
  `).join("");
  return new JSDOM(`<ul>${cards}</ul>`);
}

test("generated styling tokens do not become discovered selectors or semantic names", () => {
  const dom = new JSDOM(`
    <main>
      <article class="result-card"><h2 class="css-1ujsas3 title">First</h2></article>
      <article class="result-card"><h2 class="css-9zz8yy7 title">Second</h2></article>
    </main>
  `);
  const result = FieldDiscovery.discover(dom.window.document, ".result-card");
  const title = result.candidates.find((candidate) => candidate.sampleValues.includes("First"));
  assert.ok(title);
  assert.equal(title.selector, ".title");
  assert.equal(title.suggestedName, "title");
  assert.doesNotMatch(title.evidence.context, /css-/);
  dom.window.close();
});

test("discovers recurring text, attributes, and multiple values across sampled scopes", () => {
  const dom = resultsDocument();
  const result = FieldDiscovery.discover(dom.window.document, ".card");
  assert.equal(result.ok, true);
  assert.equal(result.totalScopes, 3);
  const title = result.candidates.find((candidate) => candidate.selector === ".resultTitle" && !candidate.attribute);
  assert.deepEqual(title.sampleValues, ["Engineer 1", "Engineer 2", "Engineer 3"]);
  const url = result.candidates.find((candidate) => candidate.selector === ".resultTitle" && candidate.attribute === "href");
  assert.equal(url.kind, "url");
  const skills = result.candidates.find((candidate) => candidate.selector === ".skill");
  assert.equal(skills.multiple, true);
  assert.deepEqual(skills.sampleValues[0], ["Python", "API"]);
  dom.window.close();
});

test("attribute discovery never broadens linked values to same-class wrappers without the attribute", () => {
  const cards = [1, 2, 3].map((index) => `
    <article class="card">
      <span class="skillsList__skill"><a href="/categories/design">Design</a></span>
      <a class="skillsList__skill skillsList__skill--linked" href="/skills/js-${index}">JavaScript</a>
      <a class="skillsList__skill skillsList__skill--linked" href="/skills/api-${index}">API</a>
    </article>
  `).join("");
  const dom = new JSDOM(`<main>${cards}</main>`);
  const result = FieldDiscovery.discover(dom.window.document, ".card");
  const links = result.candidates.filter((candidate) => candidate.attribute === "href");
  assert.ok(links.length);
  assert.equal(links.some((candidate) => candidate.selector === ".skillsList__skill"), false);
  for (const candidate of links) {
    for (const scope of dom.window.document.querySelectorAll(".card")) {
      assert.ok([...scope.querySelectorAll(candidate.selector)].every((node) => node.hasAttribute("href")));
    }
  }
  dom.window.close();
});

test("fast variant evidence samples across the page and keeps invisible type markers under two seconds", () => {
  const cards = Array.from({ length: 72 }, (_, index) => {
    const type = index === 71 ? "Product" : "Person";
    const details = Array.from({ length: 18 }, (_item, detail) => `<span class="detail-${detail}">${type} detail ${detail}</span>`).join("");
    return `<article class="result" data-type="${type}"><h2 class="${type.toLowerCase()}-name">${type} ${index}</h2>${details}</article>`;
  }).join("");
  const dom = new JSDOM(`<main>${cards}</main>`);
  const started = performance.now();
  const result = FieldDiscovery.discoverItems(dom.window.document, ".result", { fast: true, itemLimit: 24, elementLimit: 160 });
  const durationMs = performance.now() - started;
  assert.equal(result.ok, true);
  assert.equal(result.sampledScopes, 24);
  assert.equal(result.items.at(-1).index, 71, "even sampling missed a variant at the end of the page");
  assert.ok(result.items.at(-1).candidates.some((candidate) => candidate.selector === '[data-type="Product"]'));
  assert.ok(durationMs < 2000, `bounded variant evidence scan took ${Math.round(durationMs)} ms`);
  dom.window.close();
});

test("reconciliation adds schema matches and explicitly unresolved fields without duplicating sources", () => {
  const candidates = [
    { selector: ".title", attribute: null, kind: "text", multiple: false, suggestedName: "title", evidence: {} },
    { selector: ".opaque", attribute: null, kind: "text", multiple: false, suggestedName: "opaqueValue", evidence: {} }
  ];
  const resolve = (candidate) => candidate.selector === ".title"
    ? { name: "title", transform: ["text", "trim"] }
    : null;
  const first = FieldDiscovery.reconcile([], candidates, resolve, { includeUnmapped: true });
  assert.deepEqual(first.fields.map((field) => [field.name, field.unresolved]), [
    ["title", false], ["_unmapped_opaqueValue_1", true]
  ]);
  assert.deepEqual(first.summary, { added: 2, upgraded: 0, unchanged: 0, skipped: 0, unresolved: 1, pruned: 0 });
  const second = FieldDiscovery.reconcile(first.fields, candidates, resolve, { includeUnmapped: true });
  assert.equal(second.fields.length, 2);
  assert.equal(second.summary.unchanged, 2);
});

test("later discovery upgrades unresolved suggestions but never overwrites a locked author decision", () => {
  const candidate = { selector: ".opaque", attribute: null, kind: "text", multiple: false, suggestedName: "opaque", evidence: {} };
  const unresolved = FieldDiscovery.reconcile([], [candidate], () => null, { includeUnmapped: true }).fields;
  const upgraded = FieldDiscovery.reconcile(unresolved, [candidate], () => ({ name: "description", transform: ["text", "collapseWhitespace"] })).fields[0];
  assert.equal(upgraded.name, "description");
  assert.equal(upgraded.unresolved, false);
  const locked = { ...unresolved[0], name: "example:code", unresolved: false, locked: true, provenance: "manual" };
  const protectedField = FieldDiscovery.reconcile([locked], [candidate], () => ({ name: "description", transform: ["text", "collapseWhitespace"] })).fields[0];
  assert.equal(protectedField.name, "example:code");
  assert.equal(protectedField.locked, true);
});

test("schema-only discovery skips unresolved candidates", () => {
  const candidate = { selector: ".opaque", attribute: null, kind: "text", multiple: false, suggestedName: "opaque", evidence: {} };
  const result = FieldDiscovery.reconcile([], [candidate], () => null, { includeUnmapped: false });
  assert.deepEqual(result.fields, []);
  assert.equal(result.summary.skipped, 1);
});

test("discovers every item under the bounded default and derives a heading link as identity", () => {
  const cards = Array.from({ length: 19 }, (_, index) => `
    <li class="card">
      <h2 class="jobRecord__title"><a href="/work/detail/${index + 1}">Job ${index + 1}</a></h2>
    </li>
  `).join("");
  const dom = new JSDOM(`<ul>${cards}</ul>`);
  const result = FieldDiscovery.discover(dom.window.document, ".card");
  assert.equal(result.sampledScopes, 19);
  const identity = FieldDiscovery.identityCandidate(result.candidates);
  assert.equal(identity.selector, ".jobRecord__title > a");
  assert.equal(identity.attribute, "href");
  assert.equal(identity.suggestedName, "url");
  const mapped = result.candidates.find((candidate) => candidate.selector === identity.selector && candidate.attribute === "href");
  const fields = FieldDiscovery.reconcile([], [mapped], () => ({
    name: "url", source: "schema", cardinality: "one", transform: ["absoluteUrl", "stripQuery"]
  })).fields;
  assert.equal(FieldDiscovery.identityFieldCandidate(fields)?.name, "url");
  dom.window.close();
});

test("reconciliation prefers the broad recurring skills hook and schema cardinality", () => {
  const candidates = [
    {
      selector: "div > span:nth-of-type(1) > a > strong", attribute: null, kind: "text", multiple: false,
      suggestedName: "field", selectorKind: "fallback", evidence: { matchCounts: [1, 1, 1] }
    },
    {
      selector: ".skillsList__skill", attribute: null, kind: "text", multiple: true,
      suggestedName: "skill", selectorKind: "class", evidence: { matchCounts: [5, 4, 3] }
    }
  ];
  const result = FieldDiscovery.reconcile([], candidates, () => ({
    name: "skills", cardinality: "many", transform: ["text", "trim"]
  }));
  assert.equal(result.fields.length, 1);
  assert.equal(result.fields[0].selector, ".skillsList__skill");
  assert.equal(result.fields[0].multiple, true);

  const salary = FieldDiscovery.reconcile([], [{
    selector: ".budget", attribute: null, kind: "text", multiple: true,
    suggestedName: "budget", selectorKind: "class", evidence: { matchCounts: [2, 2] }
  }], () => ({ name: "baseSalary", cardinality: "one", transform: ["text", "trim"] }));
  assert.equal(salary.fields[0].multiple, false);
});

test("duplicate semantic fields keep the independently better-corroborated selector", () => {
  const candidates = [
    {
      selector: ".card-body", attribute: null, kind: "text", multiple: false,
      suggestedName: "body", selectorKind: "class", evidence: { matchCounts: [1, 1] }
    },
    {
      selector: ".description", attribute: null, kind: "text", multiple: false,
      suggestedName: "description", selectorKind: "class", evidence: { matchCounts: [1, 1] }
    }
  ];
  const result = FieldDiscovery.reconcile([], candidates, (candidate) => ({
    name: "description", cardinality: "one", transform: ["text", "collapseWhitespace"],
    corroboration: {
      confidence: "moderate",
      score: candidate.selector === ".description" ? 12 : 6,
      adjustedScore: candidate.selector === ".description" ? 20 : 10
    }
  }));
  assert.equal(result.fields.length, 1);
  assert.equal(result.fields[0].selector, ".description");
  assert.equal(result.fields[0].corroboration.adjustedScore, 20);
});

test("unmapped names are numbered from the first unresolved field", () => {
  const candidates = [
    { selector: ".one", attribute: null, kind: "text", multiple: false, suggestedName: "field", evidence: {} },
    { selector: ".two", attribute: null, kind: "text", multiple: false, suggestedName: "field", evidence: {} }
  ];
  const result = FieldDiscovery.reconcile([], candidates, () => null);
  assert.deepEqual(result.fields.map((field) => field.name), ["_unmapped_field_1", "_unmapped_field_2"]);
});

test("Guru fixture discovery uses the canonical title link and the full multi-value skills hook", () => {
  const html = fs.readFileSync(path.resolve(__dirname, "fixtures/guru-search-results.html"), "utf8");
  const dom = new JSDOM(html);
  const result = FieldDiscovery.discover(dom.window.document, "li[data-id]");
  const identity = FieldDiscovery.identityCandidate(result.candidates);
  const skills = result.candidates.find((candidate) => candidate.selector === ".skillsList__skill" && !candidate.attribute);
  const budget = result.candidates.find((candidate) => candidate.selector === ".jobRecord__budget" && !candidate.attribute);
  assert.equal(identity.selector, ".jobRecord__title > a");
  assert.equal(identity.attribute, "href");
  assert.equal(skills.multiple, true);
  assert.deepEqual(skills.evidence.matchCounts, [5, 4, 3]);
  assert.equal(budget.multiple, false);
  assert.equal(budget.evidence.text, "Fixed Price | $500-$1k");
  dom.window.close();
});

test("reconciliation preserves extension vocabulary metadata and its singular cardinality", () => {
  const result = FieldDiscovery.reconcile([], [{
    selector: ".jobRecord__budget", attribute: null, kind: "text", multiple: true,
    suggestedName: "budget", selectorKind: "class", evidence: { matchCounts: [2, 2] }
  }], () => ({
    name: "guru:budget", source: "extension", cardinality: "one",
    description: "A structured project budget.", valueType: "Object", example: "Fixed Price | $500-$1k",
    transform: ["text", "parseProjectBudgetV1"]
  }));
  assert.equal(result.fields[0].semanticSource, "extension");
  assert.equal(result.fields[0].multiple, false);
  assert.deepEqual(result.fields[0].transform, ["text", "parseProjectBudgetV1"]);
  assert.deepEqual(result.fields[0].vocabularyTerm, {
    description: "A structured project budget.", valueType: "Object", cardinality: "one", example: "Fixed Price | $500-$1k"
  });
});

test("a structured extension wrapper suppresses redundant presentation descendants", () => {
  const candidates = [
    {
      selector: ".jobRecord__budget", attribute: null, kind: "text", multiple: false,
      suggestedName: "budget", selectorKind: "class", evidence: { matchCounts: [1, 1] }
    },
    {
      selector: ".jobRecord__budget > span", attribute: null, kind: "text", multiple: true,
      suggestedName: "field", selectorKind: "class", evidence: { matchCounts: [1, 3] }
    }
  ];
  const existing = [{
    name: "_unmapped_field_1", selector: ".jobRecord__budget > span", attribute: null, kind: "text",
    multiple: true, provenance: "discovery", locked: false, unresolved: true
  }];
  const result = FieldDiscovery.reconcile(existing, candidates, (candidate) => candidate.selector === ".jobRecord__budget" ? {
    name: "guru:budget", source: "extension", score: 100, valueType: "Object", cardinality: "one",
    description: "A structured project budget.", example: "Fixed Price | $10k-$25k",
    transform: ["text", "parseProjectBudgetV1"]
  } : null);
  assert.deepEqual(result.fields.map((field) => field.name), ["guru:budget"]);
  assert.equal(result.summary.pruned, 1);
  assert.equal(result.summary.unresolved, 0);

  const locked = { ...existing[0], locked: true, provenance: "manual" };
  const protectedResult = FieldDiscovery.reconcile([locked], candidates, (candidate) => candidate.selector === ".jobRecord__budget" ? {
    name: "guru:budget", source: "extension", score: 100, valueType: "Object", cardinality: "one",
    description: "A structured project budget.", example: "Fixed Price | $10k-$25k",
    transform: ["text", "parseProjectBudgetV1"]
  } : null);
  assert.ok(protectedResult.fields.some((field) => field.name === "_unmapped_field_1"));
});
