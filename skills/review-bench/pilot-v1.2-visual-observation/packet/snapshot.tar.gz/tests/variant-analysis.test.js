"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const VariantAnalysis = require("../extension/editor/variant-analysis");
const Dsl = require("../extension/core/dsl");
const VariantClassifier = require("../extension/core/variant-classifier");
const FieldDiscovery = require("../extension/editor/field-discovery");
const SelectorCandidates = require("../extension/editor/selector-candidates");
const AdapterDefinition = require("../extension/editor/adapter-definition");
const { bridgeBuildBlockTable, bridgeCaptureVariantEvidence, bridgeClassifyVariantItems, bridgeClassifyNestedVariantSlots, bridgeDiscoverFields } = require("../extension/editor/sidebar-page-bridge");

function rankingFor(typesByMarker) {
  return {
    rank(candidates) {
      const marker = candidates[0]?.suggestedName;
      return { types: (typesByMarker[marker] || []).map(([type, score]) => ({ id: `schema:${type}`, label: type, score })) };
    }
  };
}

test("detects mixed per-item winners and derives selectors that discriminate their populations", () => {
  const result = VariantAnalysis.analyze([
    { index: 0, candidates: [{ suggestedName: "person", selector: ".person-name", selectorKind: "class" }] },
    { index: 1, candidates: [{ suggestedName: "person", selector: ".person-name", selectorKind: "class" }] },
    { index: 2, candidates: [{ suggestedName: "project", selector: ".project-status", selectorKind: "class" }] }
  ], {
    ranking: rankingFor({ person: [["Person", 20], ["Project", 4]], project: [["Project", 18], ["Person", 3]] })
  });
  assert.equal(result.mixed, true);
  assert.deepEqual(result.candidates.map((candidate) => [candidate.schemaType, candidate.count]), [["Person", 2], ["Project", 1]]);
  assert.deepEqual(result.candidates[0].evidence, [{ selector: ".person-name", weight: 10 }]);
  assert.deepEqual(result.candidates[1].evidence, [{ selector: ".project-status", weight: 10 }]);
  assert.equal(result.ambiguousCount, 0);
});

test("keeps close scoring items ambiguous instead of manufacturing a variant decision", () => {
  const result = VariantAnalysis.analyze([
    { index: 0, candidates: [{ suggestedName: "unclear", selector: ".name", selectorKind: "class" }] }
  ], { ranking: rankingFor({ unclear: [["Person", 12], ["Organization", 11]] }), minMargin: 2 });
  assert.equal(result.mixed, false);
  assert.equal(result.candidates.length, 0);
  assert.equal(result.ambiguousCount, 1);
  assert.equal(result.rows[0].ambiguous, true);
});

test("bounds per-item ranking to aggregate page candidates", () => {
  const calls = [];
  VariantAnalysis.analyze([{ candidates: [{ selector: ".name", selectorKind: "class" }] }], {
    candidateTypes: ["Person", "Organization"],
    ranking: { rank(_candidates, options) { calls.push(options); return { types: [] }; } }
  });
  assert.deepEqual(calls[0].allowedTypes, ["Person", "Organization"]);
});

test("keeps a provisional scored alternate even when explicit discriminating evidence is not available yet", () => {
  const result = VariantAnalysis.analyze([
    { index: 0, candidates: [{ suggestedName: "job", selector: ".shared", selectorKind: "class" }] },
    { index: 1, candidates: [{ suggestedName: "recycling", selector: ".shared", selectorKind: "class" }] }
  ], {
    fallbackType: "JobPosting",
    candidateTypes: ["JobPosting", "RecyclingCenter"],
    ranking: rankingFor({ job: [["JobPosting", 20]], recycling: [["RecyclingCenter", 18]] })
  });
  assert.equal(result.mixed, true);
  assert.deepEqual(result.candidates.map((candidate) => candidate.schemaType), ["JobPosting", "RecyclingCenter"]);
  assert.equal(result.candidates[1].evidence.length, 0);
  assert.equal(result.ambiguousCount, 0);
  assert.equal(result.rows[1].winner.schemaType, "RecyclingCenter");
});

test("Review reclassifies rendered rows from saved variant rules", () => {
  const dom = new JSDOM('<ul><li class="job"></li><li class="person"></li><li class="person org"></li></ul>', { url: "https://example.com/search", runScripts: "outside-only" });
  dom.window.Site2JsonDsl = Dsl;
  dom.window.Site2JsonVariantClassifier = VariantClassifier;
  const run = dom.window.eval(`(${bridgeBuildBlockTable.toString()})`);
  const result = run({
    scopeSelector: "li", schemaType: "JobPosting", identity: null, fields: [],
    variants: {
      minScore: 6, minMargin: 2,
      candidates: [
        { schemaType: "Person", evidence: [{ selector: ".person", weight: 10 }] },
        { schemaType: "Organization", evidence: [{ selector: ".org", weight: 10 }] }
      ]
    }
  });
  assert.equal(result.rows[0].variant.winner.schemaType, "JobPosting");
  assert.equal(result.rows[1].variant.winner.schemaType, "Person");
  assert.equal(result.rows[2].variant.ambiguous, true);
  dom.window.close();
});

test("Discovery samples only the selected variant population", () => {
  const dom = new JSDOM(`
    <ul>
      <li class="result" data-type="Person"><a href="/people/1"><span class="person-name">Ada</span></a></li>
      <li class="result" data-type="Project"><a href="/projects/1"><span class="project-title">Apollo</span></a></li>
    </ul>
  `, { url: "https://example.com/search", runScripts: "outside-only" });
  dom.window.Site2JsonDsl = Dsl;
  dom.window.Site2JsonVariantClassifier = VariantClassifier;
  dom.window.Site2JsonFieldDiscovery = FieldDiscovery;
  const run = dom.window.eval(`(${bridgeDiscoverFields.toString()})`);
  const result = run({
    scopeSelector: ".result", fallbackEntity: "Result", variantTarget: "PersonResult",
    variants: {
      minScore: 6, minMargin: 2,
      candidates: [{ entityName: "PersonResult", schemaType: "Person", fields: [], identity: null, evidence: [{ selector: ":scope", attribute: "data-type", equals: "Person", weight: 10 }] }]
    }
  });
  assert.equal(result.ok, true);
  assert.equal(result.totalScopes, 1);
  assert.equal(result.blockTotalScopes, 2);
  assert.ok(result.candidates.some((candidate) => candidate.sampleValues.includes("Ada")));
  assert.ok(result.candidates.every((candidate) => !candidate.sampleValues.includes("Apollo")));
  dom.window.close();
});

test("Elements selections become evidence-only attribute probes", () => {
  const dom = new JSDOM('<article class="result"><img class="type-icon" alt="Person"></article>', { runScripts: "outside-only" });
  dom.window.Site2JsonSelectorCandidates = SelectorCandidates;
  dom.window.$0 = dom.window.document.querySelector("img");
  const run = dom.window.eval(`(${bridgeCaptureVariantEvidence.toString()})`);
  const result = run({ scopeSelector: ".result" });
  assert.equal(result.ok, true);
  assert.equal(result.rule.attribute, "alt");
  assert.equal(result.rule.equals, "Person");
  assert.equal(result.rule.weight, 10);
  dom.window.close();
});

test("classification review separates deterministic, ambiguous, and fallback results", () => {
  const dom = new JSDOM(`
    <ul>
      <li class="result person">Ada</li>
      <li class="result project">Apollo</li>
      <li class="result person project">Conflicted</li>
      <li class="result">Unknown</li>
    </ul>
  `, { url: "https://example.com/search", runScripts: "outside-only" });
  dom.window.Site2JsonDsl = Dsl;
  dom.window.Site2JsonVariantClassifier = VariantClassifier;
  const run = dom.window.eval(`(${bridgeClassifyVariantItems.toString()})`);
  const result = run({
    scopeSelector: ".result", fallbackEntity: "OtherResult", schemaType: "Thing",
    variants: {
      minScore: 6, minMargin: 2,
      candidates: [
        { entityName: "PersonResult", schemaType: "Person", evidence: [{ selector: ".person", weight: 10 }] },
        { entityName: "ProjectResult", schemaType: "Project", evidence: [{ selector: ".project", weight: 10 }] }
      ]
    }
  });
  assert.equal(result.ok, true);
  assert.deepEqual(Array.from(result.rows, (row) => row.status), ["classified", "classified", "ambiguous", "unclassified"]);
  assert.equal(result.ambiguousCount, 1);
  assert.equal(result.unclassifiedCount, 1);
  assert.deepEqual(Array.from(result.counts, (count) => [count.schemaType, count.count]), [["Thing", 2], ["Person", 1], ["Project", 1]]);
  dom.window.close();
});

test("nested preview uses the production DSL classifier on each parent scope", () => {
  const dom = new JSDOM(`
    <article class="result"><a class="article-url" href="/article/1">Article</a></article>
    <article class="result"><a class="job-url" href="/job/1">Job</a></article>
  `, { url: "https://example.test/search", runScripts: "outside-only" });
  dom.window.Site2JsonDsl = Dsl;
  const field = (name, selector) => ({ name, selector, attribute: "href", kind: "url", transform: ["absoluteUrl", "stripQuery"], identity: true });
  const slot = {
    path: "item", minScore: 6, minMargin: 2,
    fallback: { entityName: "ThingFallback", schemaType: "Thing", identityField: "url", fields: [field("url", "a")] },
    candidates: [
      { entityName: "ArticleItem", schemaType: "Article", identityField: "url", fields: [field("url", ".article-url")], evidence: [] },
      { entityName: "JobItem", schemaType: "JobPosting", identityField: "url", fields: [field("url", ".job-url")], evidence: [] }
    ]
  };
  const runtime = AdapterDefinition.compileVariantSlotRuntime(slot);
  const run = dom.window.eval(`(${bridgeClassifyNestedVariantSlots.toString()})`);
  const result = run({ scopeSelector: ".result", slots: [{ path: "item", nodeAlias: "thing", runtime }] });
  assert.equal(result.ok, true);
  assert.deepEqual(Array.from(result.slots[0].rows, (row) => row.winner?.schemaType), ["Article", "JobPosting"]);
  assert.equal(result.slots[0].nodeAlias, "thing");
  assert.equal(result.slots[0].ambiguousCount, 0);
  dom.window.close();
});

test("evidence resolution must use the item being resolved", () => {
  const dom = new JSDOM('<article class="result"><img alt="Person"></article><article class="result"><img alt="Project"></article>', { runScripts: "outside-only" });
  dom.window.Site2JsonSelectorCandidates = SelectorCandidates;
  dom.window.$0 = dom.window.document.querySelector("img");
  const run = dom.window.eval(`(${bridgeCaptureVariantEvidence.toString()})`);
  const result = run({ scopeSelector: ".result", rootIndex: 1 });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "wrong-item");
  assert.match(result.message, /result 2/);
  dom.window.close();
});

test("the manual mixed-result fixture exercises classified, ambiguous, and unclassified rows", () => {
  const html = fs.readFileSync(path.join(__dirname, "fixtures", "mixed-result-types.html"), "utf8");
  const dom = new JSDOM(html, { url: "https://example.test/directory", runScripts: "outside-only" });
  dom.window.Site2JsonDsl = Dsl;
  dom.window.Site2JsonVariantClassifier = VariantClassifier;
  const run = dom.window.eval(`(${bridgeClassifyVariantItems.toString()})`);
  const result = run({
    scopeSelector: ".result", fallbackEntity: "OtherResult", schemaType: "Thing",
    variants: {
      minScore: 6, minMargin: 2,
      candidates: [
        { entityName: "PersonResult", schemaType: "Person", evidence: [{ selector: ".person-marker", weight: 10 }] },
        { entityName: "EventResult", schemaType: "Event", evidence: [{ selector: ".event-marker", weight: 10 }] },
        { entityName: "OrganizationResult", schemaType: "Organization", evidence: [{ selector: ".organization-marker", weight: 10 }] }
      ]
    }
  });
  assert.deepEqual(Array.from(result.rows, (row) => row.status), ["classified", "classified", "classified", "classified", "ambiguous", "unclassified"]);
  assert.equal(result.ambiguousCount, 1);
  assert.equal(result.unclassifiedCount, 1);
  dom.window.close();
});
