"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const Drafts = require("../extension/core/adapter-drafts");
const Registry = require("../extension/core/adapter-registry");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(path.join(root, "reference-adapters/upwork-search.dsl.json"));

function memoryStorage(initial = {}) {
  const state = { ...initial };
  return {
    state,
    get: async (key) => typeof key === "string" ? { [key]: state[key] } : { ...state },
    set: async (value) => Object.assign(state, value)
  };
}

test("editing clones the complete published definition into an isolated draft", async () => {
  const editorState = { blocks: [{ id: "jobs", composition: { id: "schema:JobPosting" } }] };
  const { entry } = await Registry.createEntry(source, "upwork.yaml", { importedAt: "2026-08-09T01:00:00.000Z", editorState });
  const draft = Drafts.createFromPublished(entry, { now: "2026-08-09T02:00:00.000Z" });
  assert.equal(draft.id, "adapter:upwork");
  assert.equal(draft.baseDefinitionDigest, entry.definitionDigest);
  assert.deepEqual(draft.baseDefinition, entry.definition);
  assert.deepEqual(draft.workingDefinition, entry.definition);
  assert.deepEqual(draft.editorState, editorState);
  draft.editorState.blocks[0].id = "changed-editor-only";
  assert.equal(entry.editorState.blocks[0].id, "jobs");
  draft.workingDefinition.pages[0].id = "changed-only-in-draft";
  assert.notEqual(entry.definition.pages[0].id, "changed-only-in-draft");
});

test("draft storage is separate from the published adapter registry", async () => {
  const storage = memoryStorage();
  const draft = Drafts.createNew({ id: "new:test", now: "2026-08-09T02:00:00.000Z" });
  await Drafts.save([draft], storage);
  await Drafts.activate(draft.id, storage);
  assert.deepEqual(await Drafts.load(storage), [draft]);
  assert.equal(await Drafts.active(storage), draft.id);
  assert.equal(storage.state[Registry.STORAGE_KEY], undefined);
});

test("publishing validates, atomically replaces the published entry, and removes the draft", async () => {
  const { entry } = await Registry.createEntry(source, "upwork.yaml", { importedAt: "2026-08-09T01:00:00.000Z", enabled: false });
  const draft = Drafts.createFromPublished(entry, { now: "2026-08-09T02:00:00.000Z" });
  draft.workingDefinition.version += 1;
  draft.editorState = { blocks: [{ id: "jobs", composition: { id: "site2json:freelance-opportunity" } }] };
  const storage = memoryStorage({ [Registry.STORAGE_KEY]: [entry], [Drafts.STORAGE_KEY]: [draft] });
  const requestedLocks = [];
  const lockManager = {
    async request(name, operation) {
      requestedLocks.push(name);
      return operation();
    }
  };
  const result = await Drafts.publish(draft, [entry], [draft], {
    storage,
    now: "2026-08-09T03:00:00.000Z",
    lockManager
  });
  assert.deepEqual(requestedLocks, [Drafts.PUBLISH_LOCK]);
  assert.equal(result.entry.definition.version, entry.definition.version + 1);
  assert.equal(result.entry.enabled, false);
  assert.deepEqual(result.entry.editorState, draft.editorState);
  assert.deepEqual(result.drafts, []);
  assert.deepEqual(storage.state[Registry.STORAGE_KEY], result.entries);
  assert.deepEqual(storage.state[Drafts.STORAGE_KEY], []);
  assert.equal(storage.state[Drafts.ACTIVE_DRAFT_KEY], null);
  assert.match(result.sourceText, /^adapter: upwork/m);
});

test("publishing refuses to overwrite an adapter that changed after editing began", async () => {
  const { entry } = await Registry.createEntry(source, "upwork.yaml", { importedAt: "2026-08-09T01:00:00.000Z" });
  const draft = Drafts.createFromPublished(entry);
  const replacementDefinition = structuredClone(entry.definition);
  replacementDefinition.version += 1;
  const replacementSource = Buffer.from(JSON.stringify(replacementDefinition));
  const { entry: replacement } = await Registry.createEntry(replacementSource, "upwork-new.yaml");
  const storage = memoryStorage({
    [Registry.STORAGE_KEY]: [replacement],
    [Drafts.STORAGE_KEY]: [draft]
  });
  await assert.rejects(
    // The caller still has the original entry cached. Publishing must compare
    // against the newer value in storage while holding the publish lock.
    Drafts.publish(draft, [entry], [draft], { storage }),
    /changed after this draft was created/i
  );
  assert.deepEqual(storage.state[Registry.STORAGE_KEY], [replacement]);
  assert.deepEqual(storage.state[Drafts.STORAGE_KEY], [draft]);
});

test("publishing preserves concurrent drafts from authoritative storage", async () => {
  const { entry } = await Registry.createEntry(source, "upwork.yaml", { importedAt: "2026-08-09T01:00:00.000Z" });
  const draft = Drafts.createFromPublished(entry);
  draft.workingDefinition.version += 1;
  const otherDraft = Drafts.createNew({ id: "new:concurrent" });
  const storage = memoryStorage({
    [Registry.STORAGE_KEY]: [entry],
    [Drafts.STORAGE_KEY]: [draft, otherDraft]
  });
  const result = await Drafts.publish(draft, [entry], [draft], { storage });
  assert.deepEqual(result.drafts, [otherDraft]);
  assert.deepEqual(storage.state[Drafts.STORAGE_KEY], [otherDraft]);
});
