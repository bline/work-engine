"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");

const source = fs.readFileSync(path.resolve(__dirname, "../extension/editor/browser-bridge.js"), "utf8");

test("side-panel bridge runs the shared page operation in the visually selected frame", async () => {
  const dom = new JSDOM("<!doctype html>", {
    url: "chrome-extension://test/editor/sidebar.html?tabId=41",
    runScripts: "outside-only"
  });
  const { window } = dom;
  const calls = [];
  window.chrome = {
    runtime: {},
    scripting: {
      executeScript: async (request) => {
        calls.push(request);
        if (request.files) return [{ frameId: 0 }, { frameId: 7 }];
        return [{ frameId: request.target.frameIds[0], result: { operation: request.func.name, args: request.args[0] } }];
      }
    },
    tabs: {
      sendMessage: async (tabId, message) => { calls.push({ tabId, message }); }
    }
  };
  window.eval(source);
  assert.equal(window.Site2JsonBridge.host, "sidepanel");
  window.Site2JsonBridge.useSelectionFrame(7);
  function bridgeProbe(args) { return args; }
  const result = await window.Site2JsonBridge.run(bridgeProbe, { selector: ".card" });
  assert.deepEqual(JSON.parse(JSON.stringify(result)), { operation: "bridgeProbe", args: { selector: ".card" } });
  const operation = calls.find((call) => call.func);
  assert.deepEqual(JSON.parse(JSON.stringify(operation.target)), { tabId: 41, frameIds: [7] });

  const v2Result = await window.Site2JsonBridge.runV2(bridgeProbe, { profile: "compiled" });
  assert.deepEqual(JSON.parse(JSON.stringify(v2Result)), { operation: "bridgeProbe", args: { profile: "compiled" } });
  const fileCalls = calls.filter((call) => call.files);
  const normalInjection = fileCalls.find((call) => call.files.includes("content/page-picker.js"));
  const v2Injection = fileCalls.find((call) => call.files.includes("ir/pipeline.js"));
  assert.ok(normalInjection);
  assert.ok(v2Injection);
  assert.equal(normalInjection.files.includes("ir/pipeline.js"), false, "ordinary authoring must not eagerly inject V2");
  assert.equal(v2Injection.files.includes("content/page-picker.js"), false, "V2 preview must keep picker injection separate");
  const operations = calls.filter((call) => call.func);
  assert.deepEqual(JSON.parse(JSON.stringify(operations[1].target)), { tabId: 41, frameIds: [7] }, "V2 must follow the picker-selected frame too");

  await window.Site2JsonBridge.startSelection("new-field");
  const start = calls.find((call) => call.message?.type === "site2json-picker:start");
  assert.equal(start.tabId, 41);
  assert.equal(start.message.mode, "new-field");
  assert.ok(calls.filter((call) => call.files).length >= 2, "starting a pick should refresh scripts in every accessible frame");
  dom.window.close();
});

test("browser bridge can adopt the active tab after opening without a tab-specific URL", async () => {
  const dom = new JSDOM("<!doctype html>", {
    url: "chrome-extension://test/editor/sidebar.html",
    runScripts: "outside-only"
  });
  const calls = [];
  dom.window.chrome = {
    runtime: {},
    scripting: {
      executeScript: async (request) => {
        calls.push(request);
        return request.files ? [{ frameId: 0 }] : [{ frameId: 0, result: request.args[0] }];
      }
    },
    tabs: { sendMessage: async () => {} }
  };
  dom.window.eval(source);
  assert.equal(dom.window.Site2JsonBridge.host, "sidepanel");
  assert.equal(dom.window.Site2JsonBridge.frameId(), 0);
  assert.equal(Number.isNaN(dom.window.Site2JsonBridge.tabId), true);
  assert.equal(dom.window.Site2JsonBridge.useTab(77), true);
  assert.equal(dom.window.Site2JsonBridge.tabId, 77);
  await dom.window.Site2JsonBridge.run((value) => value, { ready: true });
  assert.deepEqual(JSON.parse(JSON.stringify(calls.at(-1).target)), { tabId: 77, frameIds: [0] });
  dom.window.close();
});
