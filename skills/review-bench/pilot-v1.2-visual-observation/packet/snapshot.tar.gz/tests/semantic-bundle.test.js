"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const Bundle = require("../extension/core/semantic-bundle");

const TYPE = {
  termId: "guru:Editor",
  label: "Editor",
  description: "A person responsible for editing a marketplace listing.",
  canonicalUri: "https://example.test/Editor",
  definition: {
    kind: "type",
    description: "A person responsible for editing a marketplace listing.",
    valueType: "guru:Editor",
    supers: ["Person"]
  },
  provenance: { source: { id: "shared-toolkit", label: "Shared toolkit" } }
};

function exampleBundle() {
  return Bundle.create({
    name: "Guru editorial semantics",
    description: "Types and relationships for marketplace editors.",
    createdAt: "2026-08-13T16:00:00.000Z",
    types: [TYPE],
    properties: [{
      termId: "guru:editor",
      label: "editor",
      description: "The editor responsible for a listing.",
      definition: {
        kind: "relationship",
        description: "The editor responsible for a listing.",
        domainIncludes: ["JobPosting"],
        rangeIncludes: ["guru:Editor"]
      }
    }],
    patterns: [{
      patternId: "pattern:listing-editor",
      label: "Listing editor",
      description: "A listing connected to its editor.",
      root: "listing",
      nodes: {
        listing: { types: ["JobPosting"], expectation: "core" },
        editor: { types: ["guru:Editor"], expectation: "common" }
      },
      edges: [{ from: "listing", property: "guru:editor", to: "editor", expectation: "common" }],
      terms: {}
    }]
  });
}

test("semantic bundle schema is a versioned draft 2020-12 contract", () => {
  const schema = JSON.parse(fs.readFileSync(path.resolve(__dirname, "../schemas/semantic-bundle-v1.schema.json"), "utf8"));
  assert.equal(schema.$schema, "https://json-schema.org/draft/2020-12/schema");
  assert.equal(schema.$id, Bundle.SCHEMA_ID);
  assert.equal(schema.properties.format.const, Bundle.FORMAT);
  assert.equal(schema.properties.version.const, Bundle.VERSION);
  assert.deepEqual(schema.properties.records.required, ["types", "properties", "patterns"]);
  assert.deepEqual(schema.required, ["$schema", "format", "version", "bundle", "records"]);
});

test("semantic bundles round-trip through bounded gzip without local storage identities", async () => {
  const original = exampleBundle();
  const compressed = await Bundle.encode(original);
  assert.equal(compressed[0], 0x1f);
  assert.equal(compressed[1], 0x8b);
  const decoded = await Bundle.decode(compressed);
  assert.deepEqual(decoded, original);
  assert.equal(JSON.stringify(decoded).includes("import:"), false);
  assert.equal(Bundle.suggestedFilename(decoded.bundle.name), "guru-editorial-semantics.site2json.json.gz");
});

test("semantic bundle decoder also accepts decompressed JSON for recovery workflows", async () => {
  const decoded = await Bundle.decode(new TextEncoder().encode(Bundle.serialize(exampleBundle())));
  assert.equal(decoded.records.types[0].termId, "guru:Editor");
});

test("semantic bundle validation rejects internal fields, unsafe keys, invalid graphs, and versions", async () => {
  const internal = exampleBundle();
  internal.records.types[0].id = "internal-indexeddb-id";
  assert.throws(() => Bundle.validate(internal), (error) => error.code === "VALIDATION_ERROR" && /\.id is not part/.test(error.message));

  const invalidGraph = exampleBundle();
  invalidGraph.records.patterns[0].edges[0].to = "missing";
  assert.throws(() => Bundle.validate(invalidGraph), (error) => error.code === "VALIDATION_ERROR" && /connect nodes/.test(error.message));

  const future = exampleBundle();
  future.version = 2;
  assert.throws(() => Bundle.validate(future), (error) => error.code === "UNSUPPORTED_VERSION");

  const unsafe = Bundle.serialize(exampleBundle()).replace('"provenance": {', '"provenance": { "__proto__": {},');
  await assert.rejects(() => Bundle.decode(new TextEncoder().encode(unsafe)), (error) => error.code === "UNSAFE_CONTENT");
});

test("semantic bundle decoder stops decompression at the configured safety boundary", async () => {
  const compressed = await Bundle.encode(exampleBundle());
  await assert.rejects(
    () => Bundle.decode(compressed, { maxDecompressedBytes: 128 }),
    (error) => error.code === "DECOMPRESSED_SIZE_LIMIT"
  );
  await assert.rejects(
    () => Bundle.decode(compressed, { maxCompressedBytes: 8 }),
    (error) => error.code === "COMPRESSED_SIZE_LIMIT"
  );
});
