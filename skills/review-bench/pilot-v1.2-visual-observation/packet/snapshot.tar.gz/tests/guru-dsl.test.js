"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Dsl = require("../extension/core/dsl");
const Guru = require("../reference-adapters/guru");

const root = path.resolve(__dirname, "..");
const definition = JSON.parse(fs.readFileSync(path.join(root, "reference-adapters/guru.dsl.json"), "utf8"));
const searchFixture = fs.readFileSync(path.join(__dirname, "fixtures/guru-search-results.html"), "utf8");
const detailFixture = fs.readFileSync(path.join(__dirname, "fixtures/guru-job-detail.html"), "utf8");
const pageTwoQuery = "L2Qvam9icy9jL3Byb2dyYW1taW5nLWRldmVsb3BtZW50L21heHF1b3Rlcy81MC9wZy8yLw==";
const skillsQuery = "L2Qvam9icy9jL3Byb2dyYW1taW5nLWRldmVsb3BtZW50L3NraWxsL3B5dGhvbi9za2lsbC9HYW1pbmctU3lzdGVtcy9tYXhxdW90ZXMvNTAv";
const minimumSpendQuery = "L2Qvam9icy9jL3Byb2dyYW1taW5nLWRldmVsb3BtZW50L21pbnNwZW5kLzUwMC9tYXhxdW90ZXMvNTAv";

test("strict DSL validation accepts the Guru definition", () => {
  const validated = Dsl.validateDefinition(definition);
  assert.equal(validated.adapter, "guru");
  assert.equal(validated.dslVersion, Dsl.DSL_VERSION);
});

test("Guru definition extensions remain inert and strictly validated", () => {
  const invalidMatchSource = structuredClone(definition);
  invalidMatchSource.pages.find((page) => page.id === "search-results").match.url.source = "literal";
  invalidMatchSource.pages.find((page) => page.id === "search-results").match.url.value = true;
  assert.throws(() => Dsl.validateDefinition(invalidMatchSource), /match\.url must use the pageUrl source/i);

  const aggregateWithoutMultiple = structuredClone(definition);
  const rawText = aggregateWithoutMultiple.entities.JobPosting.fields["site2json:rawText"];
  rawText.multiple = false;
  assert.throws(() => Dsl.validateDefinition(aggregateWithoutMultiple), /aggregate requires multiple: true/i);

  const unknownProjectedField = structuredClone(definition);
  unknownProjectedField.pages.find((page) => page.id === "search-results").blocks[0].fields.push("guru:employer.executeJavaScript");
  assert.throws(() => Dsl.validateDefinition(unknownProjectedField), /block\.fields references unknown field/i);
});

test("the declarative Guru search page exactly matches the imperative observation across encoded routes", () => {
  const adapter = Dsl.compile(definition);
  for (const query of [pageTwoQuery, skillsQuery, minimumSpendQuery]) {
    const dom = new JSDOM(searchFixture, { url: `https://www.guru.com/work/?q=${query}` });
    const url = new URL(dom.window.location.href);
    assert.equal(adapter.match(url, dom.window.document), true);
    assert.deepEqual(adapter.extract(dom.window.document, url), Guru.extract(dom.window.document, url));
    dom.window.close();
  }
});

test("the declarative Guru detail page exactly matches the imperative observation", () => {
  const dom = new JSDOM(detailFixture, { url: "https://www.guru.com/work/detail/3100001" });
  const url = new URL(dom.window.location.href);
  const adapter = Dsl.compile(definition);
  assert.equal(adapter.match(url, dom.window.document), true);
  assert.deepEqual(adapter.extract(dom.window.document, url), Guru.extract(dom.window.document, url));
  assert.equal(adapter.extract(dom.window.document, url).blocks[0].entities[0]["site2json:rawText"].includes("$9k-$12k"), false);
  dom.window.close();
});

test("missing Guru detail employer stats remain explicit nulls while search cards omit detail-only fields", () => {
  const withoutStats = detailFixture.replace(/\s*<tr><td>Jobs Posted<\/td><td class="right">12<\/td><\/tr>/, "")
    .replace(/\s*<tr><td>Jobs Paid<\/td><td class="right">8 \(67%\)<\/td><\/tr>/, "");
  const detailDom = new JSDOM(withoutStats, { url: "https://www.guru.com/work/detail/3100001" });
  const detailUrl = new URL(detailDom.window.location.href);
  const adapter = Dsl.compile(definition);
  const declarative = adapter.extract(detailDom.window.document, detailUrl);
  assert.deepEqual(declarative, Guru.extract(detailDom.window.document, detailUrl));
  assert.equal(declarative.blocks[0].entities[0]["guru:employer"].jobsPosted, null);
  assert.equal(declarative.blocks[0].entities[0]["guru:employer"].jobsPaid, null);

  const searchDom = new JSDOM(searchFixture, { url: `https://www.guru.com/work/?q=${pageTwoQuery}` });
  const searchEntity = adapter.extract(searchDom.window.document, new URL(searchDom.window.location.href)).blocks[0].entities[0];
  assert.equal(Object.hasOwn(searchEntity["guru:employer"], "jobsPosted"), false);
  assert.equal(Object.hasOwn(searchEntity["guru:employer"], "jobsPaid"), false);
  detailDom.window.close();
  searchDom.window.close();
});

test("Guru URL matching rejects malformed encoded searches and detail extraction fails loudly without its component", () => {
  const adapter = Dsl.compile(definition);
  const malformed = new JSDOM(searchFixture, { url: "https://www.guru.com/work/?q=not_base64!" });
  assert.equal(adapter.match(new URL(malformed.window.location.href), malformed.window.document), false);
  const missing = new JSDOM("<!doctype html><main><h1>Unscoped job</h1></main>", { url: "https://www.guru.com/work/detail/3100001" });
  const missingUrl = new URL(missing.window.location.href);
  assert.equal(adapter.match(missingUrl, missing.window.document), true);
  assert.throws(() => adapter.extract(missing.window.document, missingUrl), /No declarative page binding matched/i);
  malformed.window.close();
  missing.window.close();
});
