"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Toolbox = require("../extension/core/semantic-toolbox");
const Bundle = require("../extension/core/semantic-bundle");
const SemanticLibrary = require("../extension/core/semantic-library-service");
const { semanticLibraryServiceContract } = require("./contracts/semantic-library-service.contract");

function createLegacyService(options = {}) {
  const values = {};
  const storage = {
    async get(key) { return { [key]: values[key] }; },
    async set(next) { Object.assign(values, next); }
  };
  return SemanticLibrary.createLegacyToolboxService({ toolboxApi: Toolbox, storage, ...options });
}

semanticLibraryServiceContract(test, "legacy toolbox Semantic Library service", createLegacyService);

test("bulk property profile updates validate every revision before one atomic write", async () => {
  const service = createLegacyService();
  const base = (id) => ({
    id, termId: id, label: id, description: `${id} property`,
    definition: { kind: "field", description: `${id} property`, valueType: "Text", cardinality: "one", example: id }
  });
  const first = await service.saveProperty({ property: base("test:first"), expectedRevision: 0 });
  const second = await service.saveProperty({ property: base("test:second"), expectedRevision: 0 });
  await assert.rejects(() => service.saveProperties({ updates: [
    { property: { ...first, label: "Changed first" }, expectedRevision: first.revision },
    { property: { ...second, label: "Changed second" }, expectedRevision: second.revision + 1 }
  ] }), (error) => error.code === "REVISION_CONFLICT");
  assert.equal((await service.getProperty(first.id)).label, first.label);
  assert.equal((await service.getProperty(second.id)).label, second.label);

  const saved = await service.saveProperties({ updates: [
    { property: { ...first, label: "Changed first" }, expectedRevision: first.revision },
    { property: { ...second, label: "Changed second" }, expectedRevision: second.revision }
  ] });
  assert.deepEqual(saved.map((record) => record.label), ["Changed first", "Changed second"]);
});

test("legacy service previews and atomically commits catalog imports with provenance", async () => {
  const service = createLegacyService();
  const proposal = {
    source: "semantic-catalog",
    label: "Import foaf:Person",
    requested: { kind: "class", id: "foaf:Person", canonicalUri: "http://xmlns.com/foaf/0.1/Person" },
    snapshot: { graph: "http://data.bioontology.org/ontologies/FOAF/submissions/10", submissionId: 10 },
    records: {
      customTypes: [{
        id: "foaf:Person", label: "Person", description: "A person.",
        definition: { kind: "type", description: "A person.", valueType: "foaf:Person", cardinality: "one", example: "Person", canonicalUri: "http://xmlns.com/foaf/0.1/Person" },
        provenance: { source: { id: "lov", label: "Linked Open Vocabularies" }, canonicalUri: "http://xmlns.com/foaf/0.1/Person", categories: ["People"] }
      }],
      properties: [{
        id: "foaf:knows", label: "knows", description: "A person known by this person.",
        definition: { kind: "relationship", description: "A person known by this person.", valueType: "http://xmlns.com/foaf/0.1/Person", cardinality: "one", example: "knows", canonicalUri: "http://xmlns.com/foaf/0.1/knows", domainIncludes: ["http://xmlns.com/foaf/0.1/Person"], rangeIncludes: ["http://xmlns.com/foaf/0.1/Person"] },
        provenance: { source: { id: "lov", label: "Linked Open Vocabularies" }, canonicalUri: "http://xmlns.com/foaf/0.1/knows", categories: ["People"] }
      }]
    }
  };
  const plan = await service.planImport({ proposal });
  assert.deepEqual(plan.counts, { customTypes: 1, properties: 1, skipped: 0, collisions: 0 });
  assert.equal((await service.search({ query: "Person" })).total, 0, "preview must not mutate storage");
  const job = await service.startImport({ planId: plan.id });
  assert.equal(job.status, "completed");
  assert.match(job.id, /^import:/);
  const typeReference = job.records.find((record) => record.kind === "customType");
  const propertyReference = job.records.find((record) => record.kind === "property");
  assert.notEqual(typeReference.id, "foaf:Person", "library identity must be package-qualified");
  assert.equal(typeReference.termId, "foaf:Person");
  assert.equal((await service.getCustomType(typeReference.id)).provenance.source.id, "lov");
  assert.equal((await service.getCustomType(typeReference.id)).provenance.importId, job.id);
  assert.equal((await service.getProperty(propertyReference.id)).definition.kind, "relationship");
  const results = await service.search({ query: "person" });
  assert.deepEqual(results.items.map((item) => item.kind).sort(), ["customType", "property"]);
  assert.equal(results.facets.sources.items.find((source) => source.id === "lov").count, 2);

  const repeat = await service.planImport({ proposal });
  assert.deepEqual(repeat.counts, { customTypes: 1, properties: 1, skipped: 0, collisions: 0 });
  const repeatedJob = await service.startImport({ planId: repeat.id });
  assert.notEqual(repeatedJob.records[0].id, job.records[0].id);
  assert.equal((await service.search({ query: "person" })).total, 4, "overlapping packages must remain separate library records");

  const history = await service.listImports();
  assert.equal(history.total, 2);
  assert.equal(history.items[0].records, undefined, "history pages must not return potentially large record manifests");
  const undone = await service.undoImport({ id: job.id });
  assert.equal(undone.status, "undone");
  assert.deepEqual(undone.undo.removed.map((record) => record.id).sort(), job.records.map((record) => record.id).sort());
  assert.equal((await service.search({ query: "person" })).total, 2, "undoing one package must not affect an overlapping package");
  await assert.rejects(() => service.undoImport({ id: job.id }), (error) => error.code === "ALREADY_UNDONE");
  await service.undoImport({ id: repeatedJob.id });
  assert.equal((await service.search({ query: "person" })).total, 0);
});

test("import rollback preserves records edited after import", async () => {
  const service = createLegacyService();
  const proposal = {
    source: "semantic-catalog",
    label: "Import example:Editor",
    records: {
      customTypes: [{
        id: "example:Editor", label: "Editor", description: "An editor.",
        definition: { kind: "type", description: "An editor.", valueType: "example:Editor" },
        provenance: { source: { id: "lov" }, canonicalUri: "https://example.test/Editor" }
      }],
      properties: [{
        id: "example:edits", label: "edits", description: "The work being edited.",
        definition: { kind: "relationship", description: "The work being edited.", domainIncludes: ["https://example.test/Editor"] },
        provenance: { source: { id: "lov" }, canonicalUri: "https://example.test/edits" }
      }]
    }
  };
  const plan = await service.planImport({ proposal });
  const job = await service.startImport({ planId: plan.id });
  const importedReference = job.records.find((record) => record.kind === "customType");
  const propertyReference = job.records.find((record) => record.kind === "property");
  const imported = await service.getCustomType(importedReference.id);
  await service.saveCustomType({ customType: { ...imported, label: "Copy editor" }, expectedRevision: imported.revision });

  const result = await service.undoImport({ id: job.id });
  assert.deepEqual(result.undo.removed.map((record) => record.id), [propertyReference.id]);
  assert.deepEqual(result.undo.retained.map((record) => record.id), [importedReference.id]);
  assert.equal((await service.getCustomType(importedReference.id)).label, "Copy editor");
  await assert.rejects(() => service.getProperty(propertyReference.id), (error) => error.code === "NOT_FOUND");
});

test("catalog packages reject terms without canonical identity", async () => {
  const service = createLegacyService();
  await assert.rejects(() => service.planImport({ proposal: {
    source: "semantic-catalog",
    records: { customTypes: [{
      id: "example:Unknown", label: "Unknown", description: "Missing canonical identity.",
      definition: { kind: "type", description: "Missing canonical identity.", valueType: "example:Unknown" }
    }], properties: [] }
  } }), (error) => error.code === "VALIDATION_ERROR" && /canonical HTTP\(S\) URI/.test(error.message));
});

test("portable bundles preview without mutation and import isolated types, properties, and graph patterns", async () => {
  const service = createLegacyService({ bundleApi: Bundle, now: () => "2026-08-13T16:00:00.000Z" });
  const bundle = Bundle.create({
    name: "Editorial toolkit",
    createdAt: "2026-08-13T15:00:00.000Z",
    types: [{
      termId: "guru:Editor", label: "Editor", description: "An editor.",
      definition: { kind: "type", description: "An editor.", valueType: "guru:Editor", supers: ["Person"] }
    }],
    properties: [{
      termId: "guru:editor", label: "editor", description: "The listing editor.",
      definition: { kind: "relationship", description: "The listing editor.", domainIncludes: ["JobPosting"], rangeIncludes: ["guru:Editor"] }
    }],
    patterns: [{
      patternId: "pattern:editor", label: "Listing editor", description: "A listing and editor.", root: "listing",
      nodes: { listing: { types: ["JobPosting"] }, editor: { types: ["guru:Editor"] } },
      edges: [{ from: "listing", property: "guru:editor", to: "editor" }], terms: {}
    }]
  });
  const plan = await service.planBundleImport({ bundle });
  assert.deepEqual(plan.counts, { customTypes: 1, properties: 1, patterns: 1, skipped: 0, collisions: 0 });
  assert.equal((await service.search({ query: "Editor" })).total, 0);

  const job = await service.startImport({ planId: plan.id });
  assert.equal(job.records.length, 3);
  assert.equal(new Set(job.records.map((record) => record.kind)).size, 3);
  assert.ok(job.records.every((record) => record.id.startsWith(`${job.id}:`)));
  const patternReference = job.records.find((record) => record.kind === "pattern");
  assert.equal((await service.getPattern(patternReference.id)).patternId, "pattern:editor");

  const exported = await service.exportBundle({ target: patternReference });
  assert.equal(exported.bundle.name, "Editorial toolkit", "an imported record exports its complete owning package");
  assert.deepEqual(Object.fromEntries(Object.entries(exported.records).map(([key, value]) => [key, value.length])), { types: 1, properties: 1, patterns: 1 });
  assert.equal(JSON.stringify(exported).includes(job.id), false, "local import identity must not enter a portable file");
  const selectedOnly = await service.exportBundle({ targets: [patternReference], includeOwningPackage: false });
  assert.deepEqual(Object.fromEntries(Object.entries(selectedOnly.records).map(([key, value]) => [key, value.length])), { types: 0, properties: 0, patterns: 1 }, "bulk selection must not silently expand one imported item to its owning package");

  const secondPlan = await service.planBundleImport({ bundle: exported });
  const secondJob = await service.startImport({ planId: secondPlan.id });
  assert.notEqual(secondJob.records[0].id, job.records[0].id);
  assert.equal((await service.search({ query: "Editor" })).total, 6);
  await service.undoImport({ id: job.id });
  assert.equal((await service.search({ query: "Editor" })).total, 3, "undo removes only the selected package copy");
});

test("portable export supports a single local record and a heterogeneous collection", async () => {
  const service = createLegacyService({ bundleApi: Bundle, now: () => "2026-08-13T16:00:00.000Z" });
  await service.saveCustomType({ customType: {
    id: "guru:Editor", label: "Editor", description: "An editor.",
    definition: { kind: "type", description: "An editor.", valueType: "guru:Editor" }
  } });
  await service.savePattern({ pattern: {
    id: "pattern:editor", label: "Editor graph", description: "A saved graph.", root: "editor",
    nodes: { editor: { types: ["guru:Editor"] } }, edges: [], terms: {}
  } });
  await service.saveCollection({ collection: {
    id: "collection:editor", label: "Editor collection", description: "Reusable editor semantics.",
    members: [{ kind: "customType", id: "guru:Editor" }, { kind: "pattern", id: "pattern:editor" }, { kind: "schemaType", id: "Person" }]
  }, expectedRevision: 0 });

  const single = await service.exportBundle({ target: { kind: "customType", id: "guru:Editor" } });
  assert.deepEqual([single.records.types.length, single.records.patterns.length], [1, 0]);
  const collection = await service.exportBundle({ collectionId: "collection:editor" });
  assert.equal(collection.bundle.name, "Editor collection");
  assert.deepEqual([collection.records.types.length, collection.records.patterns.length], [1, 1]);
});
