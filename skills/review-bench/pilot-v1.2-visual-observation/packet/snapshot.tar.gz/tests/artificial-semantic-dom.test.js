"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Normalization = require("../extension/ir/normalization");
const Extraction = require("../extension/ir/extraction");
const Validation = require("../extension/ir/validation");
const Pipeline = require("../extension/ir/pipeline");
const ComparisonReport = require("../extension/ir/comparison-report");
const FieldObservation = require("../extension/ir/field-observation");
const SemanticAssignmentProfile = require("../extension/authoring/semantic-assignment-profile");

const terms = Object.freeze({
  type: "https://schema.org/Thing",
  title: "https://schema.org/name",
  url: "https://schema.org/url",
  description: "https://schema.org/description"
});

function plan(itemBinding) {
  return {
    bindings: {
      items: itemBinding,
      title: { kind: "selector", selector: "h3", all: false, read: "text" },
      url: { kind: "selector", selector: "h3 a", all: false, read: "attribute", attribute: "href" },
      description: { kind: "selector", selector: ".snippet", all: false, read: "text" }
    },
    collection: {
      id: "results",
      items: "items",
      type: terms.type,
      values: [
        { id: "title", term: terms.title, source: "title" },
        { id: "url", term: terms.url, source: "url" },
        { id: "description", term: terms.description, source: "description" }
      ]
    }
  };
}

test("wrapped cards normalize into a portable collection/entity/value tree", () => {
  const document = new JSDOM(`
    <main>
      <article class="result"><h3><a href="/one">First result</a></h3><p class="snippet">First description.</p></article>
      <article class="result"><h3><a href="/two">Second result</a></h3><p class="snippet">Second description.</p></article>
    </main>
  `).window.document;
  const normalized = Normalization.normalize(document, plan({ kind: "selector", selector: ".result", all: true }));
  assert.equal(normalized.tree.root.kind, "collection");
  assert.equal(normalized.tree.root.children.length, 2);
  assert.deepEqual(normalized.tree.root.children.map((entity) => entity.children.map((value) => value.term)), [
    [terms.title, terms.url, terms.description],
    [terms.title, terms.url, terms.description]
  ]);
  assert.equal(Validation.validate(normalized.tree).ok, true);
  assert.deepEqual(Extraction.extract(normalized), [
    { "@type": "Thing", name: "First result", url: "/one", description: "First description." },
    { "@type": "Thing", name: "Second result", url: "/two", description: "Second description." }
  ]);
  assert.doesNotMatch(JSON.stringify(normalized.tree), /First result|Second description/);
});

test("flat sibling sequences produce the same semantic tree and extraction shape", () => {
  const document = new JSDOM(`
    <main id="results">
      <h3><a href="/one">First result</a></h3>
      <p class="snippet">First description.</p>
      <h3><a href="/two">Second result</a></h3>
      <p class="snippet">Second description.</p>
    </main>
  `).window.document;
  const normalized = Normalization.normalize(document, plan({
    kind: "sequence",
    within: "#results",
    startsWith: "h3",
    directChildren: true
  }));
  assert.equal(normalized.tree.root.children.length, 2);
  assert.equal(Validation.validate(normalized.tree).ok, true);
  assert.deepEqual(Extraction.extract(normalized), [
    { "@type": "Thing", name: "First result", url: "/one", description: "First description." },
    { "@type": "Thing", name: "Second result", url: "/two", description: "Second description." }
  ]);
});

test("live source nodes remain ephemeral and do not leak into serialized IR", () => {
  const document = new JSDOM(`<main><article class="result"><h3>One</h3><p class="snippet">Description</p></article></main>`).window.document;
  const normalized = Normalization.normalize(document, plan({ kind: "selector", selector: ".result", all: true }));
  const entity = normalized.tree.root.children[0];
  assert.equal(normalized.sourceRefs.get(entity.id).tagName, "ARTICLE");
  assert.doesNotThrow(() => JSON.stringify(normalized.tree));
  assert.equal(JSON.stringify(normalized.tree).includes("HTMLArticleElement"), false);
});

function fixture(name) {
  return new JSDOM(fs.readFileSync(path.join(__dirname, "fixtures", name), "utf8")).window.document;
}

function wdcCase(name) {
  const directory = path.join(__dirname, "..", "research", "wdc-page-analysis", "data", "derived", "jobposting", "validated-static-pages", name);
  return {
    document: new JSDOM(fs.readFileSync(path.join(directory, "page.html"), "utf8")).window.document,
    metadata: JSON.parse(fs.readFileSync(path.join(directory, "metadata.json"), "utf8"))
  };
}

function v2Plan(items) {
  if (!items) return { collection: { id: "v2-results" } };
  const bindings = {
    title: { kind: "selector", selector: "h2", all: false, read: "text" },
    url: { kind: "selector", selector: "h2 a", all: false, read: "attribute", attribute: "href" },
    description: { kind: "selector", selector: ".description", all: false, read: "text" },
    datePosted: { kind: "selector", selector: ".posted", all: false, read: "attribute", attribute: "datetime" },
    datePublished: { kind: "selector", selector: ".published", all: false, read: "attribute", attribute: "datetime" },
    employmentType: { kind: "selector", selector: ".employment", all: false, read: "text" },
    author: { kind: "selector", selector: ".author", all: false, read: "text" },
    price: { kind: "selector", selector: ".price", all: false, read: "text" }
  };
  if (items) bindings.items = items;
  return {
    bindings,
    collection: {
      id: "v2-results",
      ...(items ? { items: "items" } : {}),
      observations: ["title", "url", "description", "datePosted", "datePublished", "employmentType", "author", "price"]
        .map((id) => ({ id, role: id, source: id }))
    }
  };
}

function wrappedV1Definition() {
  return {
    adapter: "v2-comparison-control",
    version: 1,
    dslVersion: 1,
    namespace: "https://example.com/v2-comparison#",
    hosts: ["example.com"],
    entities: {
      Result: {
        schemaType: "JobPosting",
        identity: { field: "url" },
        fields: {
          name: { selectors: ["h2"], transform: ["text", "trim"] },
          url: { selectors: ["h2 a@href"], transform: ["trim"] },
          description: { selectors: [".description"], transform: ["text", "trim"] },
          datePosted: { selectors: [".posted@datetime"], transform: ["trim"] },
          employmentType: { selectors: [".employment"], transform: ["text", "trim"] }
        }
      }
    },
    pages: [{
      id: "results",
      match: { host: ["example.com"], path: [{ mode: "exact", value: "/results" }] },
      pageType: "SearchResultsPage",
      blocks: [{ entity: "Result", scope: ".result", arity: "many", role: "collection", fidelity: "summary" }]
    }]
  };
}

test("V2 wrapped cards flow from neutral observations through schema and variant assignment", () => {
  const result = Pipeline.infer(fixture("v2-wrapped-results.html"), v2Plan());
  const report = ComparisonReport.build(result, "wrapped control");

  assert.equal(result.observed.tree.root.children.length, 2);
  assert.equal(result.observed.tree.root.children[0].term, undefined);
  assert.equal(result.observed.tree.root.children[0].children[0].term, undefined);
  assert.equal(result.observed.tree.root.children[0].children[0].value, "Senior Rust Engineer");
  assert.deepEqual(result.observed.bindings, {});
  assert.deepEqual(result.output.data["@graph"].map((entity) => entity["@type"]), ["JobPosting", "JobPosting"]);
  assert.equal(report.grouping.entityCount, 2);
  assert.equal(report.mappings.every((mapping) => mapping.status === "assigned"), true);
  assert.equal(report.variants.every((variant) => variant.accepted && variant.margin >= 2), true);
  assert.equal(report.output.provenance.entities.length, 2);
  assert.equal(report.grouping.strategy.kind, "siblings");
  assert.equal(result.output.provenance.grouping.kind, "siblings");
});

test("comparison report executes V1 and V2 against the same page", () => {
  const dom = new JSDOM(fs.readFileSync(path.join(__dirname, "fixtures", "v2-wrapped-results.html"), "utf8"), { url: "https://example.com/results" });
  const comparison = ComparisonReport.compare(dom.window.document, {
    label: "wrapped result migration control",
    v1: { definition: wrappedV1Definition(), url: dom.window.location.href },
    v2: { plan: v2Plan() }
  });

  assert.equal(comparison.v1.engine, "v1-dsl");
  assert.equal(comparison.v2.engine, "v2-semantic-dom");
  assert.equal(comparison.deltas.bothSucceeded, true);
  assert.equal(comparison.deltas.outputEqual, true);
  assert.equal(comparison.deltas.failureChanged, false);
  assert.equal(comparison.v1.explanations.blocks[0].entities.length, 2);
  assert.equal(comparison.v2.explanations.grouping.entityCount, 2);
  assert.equal(comparison.v1.confidence.unresolved, 0);
  assert.equal(comparison.v2.confidence.unresolved, 0);
  dom.window.close();
});

test("comparison report preserves different V1 and V2 failure behavior", () => {
  const dom = new JSDOM(fs.readFileSync(path.join(__dirname, "fixtures", "v2-wrapped-results.html"), "utf8"), { url: "https://example.com/results" });
  const broken = wrappedV1Definition();
  broken.pages[0].match.path[0].value = "/different";
  const comparison = ComparisonReport.compare(dom.window.document, {
    v1: { definition: broken, url: dom.window.location.href },
    v2: { plan: v2Plan() }
  });

  assert.equal(comparison.v1.failure.failed, true);
  assert.match(comparison.v1.failure.message, /No declarative page binding matched/i);
  assert.equal(comparison.v1.confidence.stopped, true);
  assert.equal(comparison.v2.failure.failed, false);
  assert.equal(comparison.deltas.failureChanged, true);
  dom.window.close();
});

test("automatic field observation does not promote an unrelated body link to entity identity", () => {
  const document = new JSDOM(`<article><h2>Job description</h2><p>Read the complete role at <a href="/unrelated">this reference</a>.</p></article>`).window.document;
  const observations = FieldObservation.observe(document.querySelector("article"), { singleton: false });
  assert.equal(observations.some((observation) => observation.role === "url"), false);
  assert.equal(observations.find((observation) => observation.role === "title").value, "Job description");
});

test("relative posted text is normalized without requiring a time element", () => {
  const document = new JSDOM(`<article><div class="meta">Posted <strong>16 hrs ago</strong> · <strong>47</strong> Quotes Received</div></article>`).window.document;
  const observations = FieldObservation.observe(document.querySelector("article"), {
    singleton: false,
    now: "2026-08-15T16:00:00.000Z"
  });
  const posted = observations.find((observation) => observation.role === "datePosted");

  assert.equal(posted.value, "2026-08-15T00:00:00.000Z");
  assert.equal(posted.source, "dom:relative-posted-text");
  assert.equal(posted.sourceNode.className, "meta");
});

test("absolute posted text is normalized without requiring a time element", () => {
  const document = new JSDOM(`<article><div class="meta">Posted on <strong>Aug 14, 2026</strong> · No Quotes Received</div></article>`).window.document;
  const posted = FieldObservation.observe(document.querySelector("article"), { singleton: false })
    .find((observation) => observation.role === "datePosted");

  assert.equal(posted.value, "2026-08-14");
  assert.equal(posted.source, "dom:absolute-posted-text");
  assert.equal(posted.sourceNode.className, "meta");
});

test("V2 classifies real Guru-shaped cards from relative posted text", () => {
  const profile = SemanticAssignmentProfile.compile({ candidateTypes: ["JobPosting", "Thing"] });
  const result = Pipeline.infer(fixture("v2-guru-results.html"), v2Plan(), { profile });

  assert.equal(result.grouping.winner.kind, "siblings");
  assert.deepEqual(result.output.data["@graph"].map((entity) => entity["@type"]), ["JobPosting", "JobPosting"]);
  assert.deepEqual(result.output.data["@graph"].map((entity) => entity.title), [
    "AI Commodity Research & Trading Platform",
    "Semantic Data Engineer"
  ]);
  assert.deepEqual(result.output.data["@graph"].map((entity) => entity.description), [
    "Build a fully functioning commodity intelligence platform.",
    "Build bounded semantic extraction systems."
  ]);
  assert.equal(result.output.data["@graph"].every((entity) => /^\d{4}-\d{2}-\d{2}(?:T|$)/.test(entity.datePosted)), true);
  assert.equal(result.properties.findings.every((finding) => finding.status === "assigned"), true);
  assert.equal(result.types.reports.every((report) => report.accepted && report.margin >= 2), true);
});

test("V2 flat sequences materialize a price observation through Product offers", () => {
  const profile = SemanticAssignmentProfile.compile({ candidateTypes: ["JobPosting", "Article", "Product", "Thing"] });
  const result = Pipeline.infer(fixture("v2-flat-heterogeneous-results.html"), v2Plan(), { profile });
  const report = ComparisonReport.build(result, "flat heterogeneous proof");

  assert.equal(report.grouping.entityCount, 3);
  assert.deepEqual(result.output.data["@graph"].map((entity) => entity["@type"]), ["Article", "JobPosting", "Product"]);
  assert.deepEqual(result.output.data["@graph"], [
    { "@type": "Article", headline: "A Semantic DOM for Extraction", url: "/article/semantic-dom", description: "An architecture note about normalized observations.", datePublished: "2026-08-15", author: "Site2JSON Research" },
    { "@type": "JobPosting", title: "Ontology Engineer", url: "/jobs/ontology-engineer", description: "Design schema-guided extraction systems.", datePosted: "2026-08-12", employmentType: "FULL_TIME" },
    { "@type": "Product", name: "Visual Analyzer", url: "/products/visual-analyzer", description: "A bounded screenshot analysis package.", offers: { "@type": "Offer", price: "49.00" } }
  ]);
  assert.deepEqual(report.variants.map((variant) => variant.winner?.term.split("/").pop() || null), ["Article", "JobPosting", "Product"]);
  assert.equal(report.variants[2].selected, "https://schema.org/Product");
  assert.equal(report.variants[2].accepted, true);
  assert.equal(report.validation.reviewRequired, false);
  assert.equal(report.variants.every((variant) => variant.alternatives.length === 4), true);
  assert.doesNotMatch(JSON.stringify(result.output), /selector|HTMLHeadingElement/);
  assert.equal(report.grouping.strategy.kind, "sequence");
  assert.equal(result.output.provenance.grouping.entityCount, 3);
});

test("joint semantic assignment resolves a neutral date from the rest of each entity shape", () => {
  const document = new JSDOM(`
    <main>
      <article>
        <h2><a href="/notes/one">Extraction architecture</a></h2>
        <p>A note about semantic extraction.</p>
        <time datetime="2026-08-10">August 10</time>
        <span class="author">Research team</span>
      </article>
      <article>
        <h2><a href="/jobs/two">Semantic systems engineer</a></h2>
        <p>Build extraction infrastructure.</p>
        <time datetime="2026-08-11">August 11</time>
        <span class="employment">FULL_TIME</span>
      </article>
    </main>
  `, { url: "https://example.com/mixed" }).window.document;
  const result = Pipeline.infer(document, v2Plan());

  assert.deepEqual(
    result.observed.tree.root.children.map((entity) => entity.children.find((child) => child.role === "date")?.role),
    ["date", "date"]
  );
  assert.deepEqual(result.output.data["@graph"].map((entity) => entity["@type"]), ["Article", "JobPosting"]);
  assert.equal(result.output.data["@graph"][0].datePublished, "2026-08-10");
  assert.equal(result.output.data["@graph"][1].datePosted, "2026-08-11");

  const dateFindings = result.properties.findings.filter((finding) => finding.role === "date");
  assert.deepEqual(dateFindings.map((finding) => finding.term), [
    "https://schema.org/datePublished",
    "https://schema.org/datePosted"
  ]);
  assert.equal(dateFindings.every((finding) => finding.candidates.length === 2), true);
  assert.equal(dateFindings.every((finding) => finding.selectedType.endsWith(finding.term.endsWith("datePosted") ? "JobPosting" : "Article")), true);
  assert.equal(result.types.reports.every((report) => report.accepted), true);
});

test("joint semantic assignment keeps a type-dependent property unresolved when the entity shape ties", () => {
  const document = new JSDOM(`
    <main>
      <article>
        <h2><a href="/undetermined">Undetermined dated result</a></h2>
        <time datetime="2026-08-12">August 12</time>
      </article>
    </main>
  `, { url: "https://example.com/undetermined" }).window.document;
  const result = Pipeline.infer(document, v2Plan());
  const dateFinding = result.properties.findings.find((finding) => finding.role === "date");

  assert.equal(result.output.data["@graph"][0]["@type"], "Thing");
  assert.equal(Object.hasOwn(result.output.data["@graph"][0], "datePosted"), false);
  assert.equal(Object.hasOwn(result.output.data["@graph"][0], "datePublished"), false);
  assert.equal(dateFinding.status, "unresolved");
  assert.deepEqual(dateFinding.candidates.map((candidate) => candidate.term), [
    "https://schema.org/datePosted",
    "https://schema.org/datePublished"
  ]);
  assert.equal(result.types.reports[0].tied, true);
});

function wdcJobPlan(items, sourceUrl) {
  if (!items) return { collection: { id: "wdc-job-detail" } };
  const bindings = {
    title: { kind: "selector", selector: "h1", all: false, read: "text" },
    url: { kind: "literal", value: sourceUrl },
    description: { kind: "selector", selector: "span.prose article", all: false, read: "text" },
    salary: { kind: "selector", selector: "header dl > div:nth-child(2) dd", all: false, read: "text" }
  };
  if (items) bindings.items = items;
  return {
    bindings,
    collection: {
      id: "wdc-job-detail",
      ...(items ? { items: "items" } : {}),
      observations: ["title", "url", "description", "salary"].map((id) => ({ id, role: id, source: id }))
    }
  };
}

test("V2 respects the reviewed WDC singleton instead of treating fragmented SEO roots as jobs", () => {
  const sample = wdcCase("jobposting-structure-04");
  assert.equal(sample.metadata.decision.pageRole, "primary-detail");
  assert.equal(sample.metadata.decision.observedItemCount, 1);
  assert.equal(sample.metadata.decision.preferredCandidate, "A");
  assert.equal(sample.metadata.candidates.A.selector, "main");
  assert.equal(sample.metadata.candidates.B.matchCount, 2);

  const accepted = Pipeline.infer(sample.document, wdcJobPlan(null, sample.metadata.sourceUrl));
  const acceptedReport = ComparisonReport.build(accepted, sample.metadata.reviewId);
  assert.equal(acceptedReport.grouping.entityCount, 1);
  assert.equal(acceptedReport.variants[0].accepted, true);
  assert.equal(accepted.output.data["@graph"][0]["@type"], "JobPosting");
  assert.equal(accepted.output.data["@graph"][0].name, "18058933365 - Full-Stack Developer");
  assert.equal(accepted.output.data["@graph"][0].url, sample.metadata.sourceUrl);
  assert.equal(accepted.output.data["@graph"][0].baseSalary, "24k-30k USD");
  assert.match(accepted.output.data["@graph"][0].description, /^Position: Full Stack AI Developer/);
  assert.equal(acceptedReport.grouping.strategy.kind, "singleton");
  assert.equal(acceptedReport.grouping.strategy.evidence.landmark, "main");

  const rejectedNodes = Array.from(sample.document.querySelectorAll(sample.metadata.candidates.B.selector));
  const inferredFragments = accepted.grouping.candidates.find((candidate) => candidate.sources.length === rejectedNodes.length
    && candidate.sources.every((source, index) => source === rejectedNodes[index]));
  assert.ok(inferredFragments, "grouping inference should discover the rejected fragmented SEO roots itself");
  assert.equal(inferredFragments.hardValid, false);
  assert.ok(inferredFragments.axes.entityIndependence < 0.75);
  assert.notEqual(accepted.grouping.winner.id, inferredFragments.id);

  const fragmented = Pipeline.run(sample.document, wdcJobPlan(
    { kind: "selector", selector: sample.metadata.candidates.B.selector, all: true },
    sample.metadata.sourceUrl
  ));
  const fragmentedReport = ComparisonReport.build(fragmented, `${sample.metadata.reviewId}:rejected-fragments`);
  assert.equal(fragmentedReport.grouping.entityCount, 2);
  assert.equal(fragmentedReport.variants.every((variant) => variant.accepted === false), true);
  assert.deepEqual(fragmented.output.data["@graph"].map((entity) => entity["@type"]), ["Thing", "Thing"]);
});

test("an exact type-score tie has no reported winner", () => {
  const result = Pipeline.infer(fixture("v2-wrapped-results.html"), v2Plan(), {
    variants: {
      minScore: 1,
      minMargin: 0,
      types: [
        { term: "https://schema.org/Article", signals: { "https://schema.org/name": 1 } },
        { term: "https://schema.org/JobPosting", signals: { "https://schema.org/name": 1 } }
      ]
    }
  });
  assert.equal(result.types.reports.every((report) => report.tied), true);
  assert.equal(result.types.reports.every((report) => report.winner === null), true);
  assert.equal(result.types.reports.every((report) => report.leading?.term === "https://schema.org/Article"), true);
  assert.deepEqual(result.output.data["@graph"].map((entity) => entity["@type"]), ["Thing", "Thing"]);
});
