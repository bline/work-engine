"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const ScopeInference = require("../extension/editor/scope-inference");

function domFor(html) {
  return new JSDOM(html).window.document;
}

const SEARCH_RESULTS_HTML = `
  <div data-test="job-tile-list">
    <section data-test="job-tile" class="card">
      <h2 data-test="job-title"><a href="/jobs/~1">First job</a></h2>
      <p data-test="job-description-text">First description</p>
    </section>
    <section data-test="job-tile" class="card">
      <h2 data-test="job-title"><a href="/jobs/~2">Second job</a></h2>
      <p data-test="job-description-text">Second description</p>
    </section>
    <section data-test="job-tile" class="card">
      <h2 data-test="job-title"><a href="/jobs/~3">Third job</a></h2>
      <p data-test="job-description-text">Third description</p>
    </section>
  </div>
`;

test("one-example inference proposes the repeating card as the narrowest stable boundary", () => {
  const document = domFor(SEARCH_RESULTS_HTML);
  const picked = document.querySelectorAll("[data-test='job-tile']")[0];
  const result = ScopeInference.inferRepeatingScope(picked, document);
  assert.ok(result.chosen);
  assert.equal(result.chosen.selector, "[data-test=\"job-tile\"]");
  assert.equal(result.chosen.matchCount, 3);
  assert.equal(result.chosen.depth, 0);
  assert.equal(result.chosen.siblingMatchCount, 3);
  assert.equal(result.mode, "collection");
});

test("one-example inference starting from a field inside the card still finds the card boundary at a deeper level", () => {
  const document = domFor(SEARCH_RESULTS_HTML);
  const picked = document.querySelectorAll("[data-test='job-title']")[1];
  const result = ScopeInference.inferRepeatingScope(picked, document);
  assert.ok(result.chosen);
  assert.equal(result.chosen.selector, "[data-test=\"job-tile\"]");
  assert.ok(result.chosen.depth >= 1);
  const levelZero = result.levels.find((level) => level.depth === 0);
  assert.equal(levelZero.best.selector, "[data-test=\"job-title\"]");
  assert.equal(levelZero.best.siblingMatchCount, 1);
});

test("selecting a collection container proposes its repeated direct children as a narrower boundary", () => {
  const document = domFor(`
    <main>
      <ol class="react-results--main">
        <li><aside>Search assist</aside></li>
        <li data-layout="organic"><article>First result</article></li>
        <li data-layout="organic"><article>Second result</article></li>
        <li data-layout="organic"><article>Third result</article></li>
        <li data-layout="related_searches"><aside>Related searches</aside></li>
      </ol>
    </main>
  `);
  const result = ScopeInference.inferRepeatingScope(document.querySelector("ol"), document);
  assert.ok(result.chosen);
  assert.equal(result.chosen.selector, "[data-layout=\"organic\"]");
  assert.equal(result.chosen.matchCount, 3);
  assert.equal(result.chosen.siblingMatchCount, 3);
  assert.equal(result.chosen.depth, -1);
});

test("classless repeated children are anchored to a stable parent instead of scattered positional matches", () => {
  const document = domFor(`
    <nav><ul><li>Account</li><li>Settings</li></ul></nav>
    <main>
      <ul class="module_list cozy">
        <li data-id="2114556"><div class="jobRecord"><h2 class="jobRecord__title">First job</h2></div></li>
        <li data-id="2113857"><div class="jobRecord"><h2 class="jobRecord__title">Second job</h2></div></li>
        <li data-id="2113038"><div class="jobRecord"><h2 class="jobRecord__title">Third job</h2></div></li>
      </ul>
    </main>
    <footer><ul><li>Privacy</li><li>Terms</li></ul></footer>
  `);
  const picked = document.querySelector('[data-id="2114556"]');
  const result = ScopeInference.inferRepeatingScope(picked, document);
  assert.ok(result.chosen);
  assert.equal(result.chosen.selector, ".module_list.cozy > li");
  assert.equal(result.chosen.matchCount, 3);
  assert.equal(result.chosen.parentCount, 1);
  assert.equal(result.chosen.siblingMatchCount, 3);
  assert.deepEqual(result.chosen.findings, [
    { kind: "good", message: "All matches share one parent." },
    { kind: "good", message: "3 matching sibling items surround the selection." }
  ]);
});

test("scope inference ignores generated card classes and anchors repeated tags to a stable container", () => {
  const document = domFor(`
    <main class="results">
      <article class="css-1ujsas3"><h2>First</h2></article>
      <article class="css-1ujsas3"><h2>Second</h2></article>
      <article class="css-1ujsas3"><h2>Third</h2></article>
    </main>
  `);
  const picked = document.querySelector("article");
  const result = ScopeInference.inferRepeatingScope(picked, document);
  assert.ok(result.chosen);
  assert.equal(result.chosen.selector, ".results > article");
  assert.doesNotMatch(result.chosen.selector, /css-/);
});

test("candidatesByDepth exposes every ancestor level so the boundary can be moved up or down", () => {
  const document = domFor(SEARCH_RESULTS_HTML);
  const picked = document.querySelectorAll("[data-test='job-tile']")[0];
  const levels = ScopeInference.candidatesByDepth(picked, document);
  assert.ok(levels.length >= 2);
  assert.equal(levels[0].tagName, "section");
  assert.equal(levels[1].tagName, "div");
  assert.equal(levels[1].best, null);
});

test("a non-repeating element is rejected by default", () => {
  const document = domFor(`<main><article id="only-one">Solo content</article></main>`);
  const picked = document.querySelector("#only-one");
  const result = ScopeInference.inferRepeatingScope(picked, document);
  assert.equal(result.chosen, null);
  assert.equal(result.mode, null);
});

test("single-item mode produces a valid scope for a non-repeating element", () => {
  const document = domFor(`<main><article id="only-one">Solo content</article></main>`);
  const picked = document.querySelector("#only-one");
  const result = ScopeInference.inferRepeatingScope(picked, document, { allowSingle: true });
  assert.ok(result.chosen);
  assert.equal(result.chosen.selector, "#only-one");
  assert.equal(result.chosen.matchCount, 1);
  assert.equal(result.mode, "single");
  assert.deepEqual(result.chosen.findings, [{ kind: "good", message: "Selector identifies one rendered item." }]);
});

test("single-item inference prefers a semantic article root over a selected leaf", () => {
  const document = domFor(`<main><article><h1>Solo article</h1><p>Body</p></article></main>`);
  const result = ScopeInference.inferRepeatingScope(document.querySelector("h1"), document, { allowSingle: true });
  assert.equal(result.chosen.selector, "article");
  assert.equal(result.chosen.depth, 1);
  assert.equal(result.mode, "single");
});

test("single-item mode bypasses repeated-boundary detection", () => {
  const document = domFor(`
    <main><article id="detail"><div class="related"><p>One</p><p>Two</p></div></article></main>
  `);
  const result = ScopeInference.inferRepeatingScope(document.querySelector(".related p"), document, { allowSingle: true });
  assert.equal(result.chosen.selector, "#detail");
  assert.equal(result.chosen.matchCount, 1);
  assert.equal(result.mode, "single");
});

test("single-item mode respects an explicit body scope while offering narrower semantic roots", () => {
  const document = domFor(`<body><header>Site navigation</header><main><article>Detail</article></main><footer>Legal</footer></body>`);
  const result = ScopeInference.inferRepeatingScope(document.body, document, { allowSingle: true });
  assert.equal(result.chosen.selector, "body");
  assert.equal(result.chosen.matchCount, 1);
  assert.deepEqual(result.levels.map((level) => level.tagName), ["article", "main", "body"]);
});

test("a split detail layout keeps sibling title and content inside the selected body scope", () => {
  const document = domFor(`
    <body>
      <header class="masthead"><h1>Article title</h1></header>
      <div class="layout"><nav>Sections</nav><main class="content"><p>Article body</p></main></div>
    </body>
  `);
  const result = ScopeInference.inferRepeatingScope(document.body, document, { allowSingle: true });
  assert.equal(result.chosen.selector, "body");
  const root = document.querySelector(result.chosen.selector);
  assert.equal(root.querySelector("h1").textContent, "Article title");
  assert.equal(root.querySelector("main p").textContent, "Article body");
  assert.ok(result.levels.some((level) => level.best?.selector === "main"), "main should remain available as a narrower alternative");
});

test("two-example inference finds the shared card boundary and requires matching tag names", () => {
  const document = domFor(SEARCH_RESULTS_HTML);
  const exampleA = document.querySelectorAll("[data-test='job-title']")[0];
  const exampleB = document.querySelectorAll("[data-test='job-title']")[2];
  const result = ScopeInference.inferRepeatingScopeFromExamples(exampleA, exampleB, document);
  assert.ok(result.chosen);
  assert.equal(result.chosen.selector, "[data-test=\"job-tile\"]");
  assert.equal(result.chosen.matchCount, 3);
});

test("two-example inference rejects a candidate whose matched ancestor tags differ", () => {
  const document = domFor(`
    <div class="row">
      <section class="item"><span>A</span></section>
      <article class="item"><span>B</span></article>
    </div>
  `);
  const exampleA = document.querySelector("section.item span");
  const exampleB = document.querySelector("article.item span");
  const result = ScopeInference.inferRepeatingScopeFromExamples(exampleA, exampleB, document);
  assert.equal(result.candidates.some((candidate) => candidate.selector === ".item"), false);
});
