"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Catalog = require("../extension/editor/transform-catalog");
const Picker = require("../extension/editor/transform-picker");

test("transform autocomplete uses reviewed categories, descriptions, and intent keywords", () => {
  const money = Catalog.details("parseMoneyV1");
  assert.equal(money.category, "Money and rates");
  assert.equal(money.output, "number");
  assert.match(money.description, /monetary amount/i);
  assert.equal(Catalog.search("dollars", { zeroArgumentOnly: true })[0].name, "parseMoneyV1");
  assert.equal(Catalog.search("pagination", { zeroArgumentOnly: true }).length, 0);
  assert.ok(Catalog.search("pagination").some((item) => item.name === "pathSnapshotKey"));
});

test("recommended transforms remain in their permanent category", () => {
  const groups = Catalog.grouped("date", { recommended: ["parseEnglishDateV1"], zeroArgumentOnly: true });
  assert.equal(groups[0].name, "Recommended");
  assert.equal(groups[0].items[0].name, "parseEnglishDateV1");
  assert.ok(groups.find((group) => group.name === "Dates and times").items.some((item) => item.name === "parseEnglishDateV1"));
});

test("pipeline helpers edit packaged structured arguments without losing inert data", () => {
  const structured = { name: "joinLiteral", args: [" "] };
  const source = ["text", structured, "trim"];
  const cloned = Picker.clonePipeline(source);
  assert.deepEqual(cloned, source);
  assert.notEqual(cloned[1], structured);
  assert.equal(Picker.formatStep(cloned[1]), 'joinLiteral(" ")');
  assert.equal(Picker.isLocked(cloned[1]), false);
  assert.deepEqual(Picker.removeAt(cloned, 1), { pipeline: ["text", "trim"], removed: true });
  assert.deepEqual(Picker.removeAt(cloned, 0).pipeline, [structured, "trim"]);
  assert.deepEqual(Picker.addZeroArgument([structured], "collapseWhitespace"), [structured, "collapseWhitespace"]);
  assert.throws(() => Picker.addZeroArgument([], "joinLiteral"), /not an available zero-argument transform/i);
  assert.deepEqual(Picker.parseArguments("textSlice", ["2", "10"]), { name: "textSlice", args: [2, 10] });
  assert.deepEqual(Picker.parseArguments("urlQueryFirst", ["q\nquery"]), { name: "urlQueryFirst", args: [["q", "query"]] });
  assert.deepEqual(Picker.parseArguments("mapValues", ['{"yes":true,"no":false}']), { name: "mapValues", args: [{ yes: true, no: false }] });
  assert.deepEqual(Picker.setAt(["text"], 1, { name: "textSlice", args: [2] }), ["text", { name: "textSlice", args: [2] }]);
  assert.throws(() => Picker.parseArguments("textSlice", ["two", "10"]), /whole number/i);
  assert.throws(() => Picker.parseArguments("joinLiteral", ["x".repeat(33)]), /at most 32/i);
});
