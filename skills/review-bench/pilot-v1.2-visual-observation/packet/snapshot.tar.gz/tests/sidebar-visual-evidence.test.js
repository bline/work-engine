"use strict";
const assert=require("node:assert/strict"),fs=require("node:fs"),path=require("node:path"),test=require("node:test");
const {JSDOM}=require("jsdom"),Observation=require("../extension/ir/visual-evidence-observation"),Contract=require("../extension/ir/visual-evidence-contract"),VisualEvidence=require("../extension/editor/sidebar-visual-evidence"),DetectionFirst=require("../extension/editor/sidebar-detection-first");
const html=fs.readFileSync(path.resolve(__dirname,"../extension/editor/sidebar.html"),"utf8");
const semanticTarget=(id="headline")=>({id,kind:"field",label:"Article.headline",semantic:{typeTerm:"https://schema.org/Article",propertyTerm:"https://schema.org/headline",path:"https://schema.org/Article > https://schema.org/headline"},repeatedGroup:{mode:"one"}});
const detectionFixture=()=>({
  id:"group-1",typeSignature:["Article"],status:"review",grouping:{entityCount:1},output:{"@type":"Article",headline:"Hello"},
  effective:{
    tree:{root:{children:[{id:"entity-1",kind:"entity",term:"https://schema.org/Article",children:[{id:"headline-1",kind:"value",term:"https://schema.org/headline",role:"headline",value:"Hello",children:[]}]}]}},
    findings:[{nodeId:"headline-1",status:"assigned",term:"https://schema.org/headline",selectedType:"https://schema.org/Article"}],
    reports:[{entityId:"entity-1",accepted:true,selected:"https://schema.org/Article"}]
  }
});
test("records granular decisions and returns serializable provenance",()=>{const dom=new JSDOM(html);let result;const view=VisualEvidence.create({document:dom.window.document,onComplete:(value)=>{result=value;}});view.open({caller:"detection",context:{pageRevision:"rev-1"},targets:[semanticTarget("headline"),semanticTarget("url")]});view.record({pickerVersion:6,element:{tag:"h1"},candidates:[],interpretation:{kind:"text",value:"Title"}});dom.window.document.querySelector("#visual-evidence-skip").click();dom.window.document.querySelector("#visual-evidence-complete").click();assert.equal(result.decisions.headline.status,"authored");assert.equal(result.decisions.url.status,"unresolved");assert.doesNotMatch(JSON.stringify(result),/ownerDocument|HTML[A-Z].*Element|Title/);});
test("cancel remains distinct from completion",()=>{const dom=new JSDOM(html);let cancelled;let completed=false;const view=VisualEvidence.create({document:dom.window.document,onCancel:(value)=>{cancelled=value;},onComplete:()=>{completed=true;}});view.open({caller:"graph",context:{pageRevision:"rev-1"},targets:[semanticTarget("job:title")]});view.record({pickerVersion:6,element:{tag:"h1"},candidates:[],interpretation:{kind:"text",value:"Engineer"}});dom.window.document.querySelector("#visual-evidence-cancel").click();assert.equal(cancelled.status,"cancelled");assert.equal(completed,false);});
test("Detection invokes shared workflow without changing acceptance",()=>{const dom=new JSDOM(html);let invocation;const view=DetectionFirst.create({document:dom.window.document,onVisualEvidence:(value)=>{invocation=value;}});view.render({detection:{summary:{selectedCount:1,entityCount:1},selected:[detectionFixture()]}},{});dom.window.document.querySelector(".detection-evidence-button").click();assert.equal(invocation.targets[0].semantic.propertyTerm,"https://schema.org/headline");assert.deepEqual(view.decisions(),{});});
test("Detection evidence controls remain inside their field descriptions",()=>{const dom=new JSDOM(html);const view=DetectionFirst.create({document:dom.window.document,onVisualEvidence:()=>{}});view.render({detection:{summary:{selectedCount:1,entityCount:1},selected:[detectionFixture()]}},{});const button=dom.window.document.querySelector(".detection-evidence-button");assert.equal(button.parentElement.tagName,"DD");assert.equal(button.textContent,"Provide page evidence");});

test("records validated canonical observations from Detection and Graph",()=>{
  const detection={id:"group-1",grouping:{kind:"collection",entityCount:2,axes:{repetition:0.9}},effective:{
    tree:{root:{children:[{id:"entity-1",kind:"entity",term:"https://schema.org/Product",children:[{id:"offer-1",kind:"entity",term:"https://schema.org/Offer",assignment:{relationship:"https://schema.org/offers"},children:[{id:"price-1",kind:"value",term:"https://schema.org/price",role:"price",value:"19.00",children:[]}]}]}]}},
    findings:[{nodeId:"price-1",status:"assigned",term:"https://schema.org/price",selectedType:"https://schema.org/Product"}],reports:[{entityId:"entity-1",accepted:true,selected:"https://schema.org/Product"}]
  }};
  const detectionTarget=Observation.detectionTargets(detection)[0];
  assert.equal(detectionTarget.semantic.path,"https://schema.org/Product > https://schema.org/offers > https://schema.org/Offer > https://schema.org/price");
  const graphTarget=Observation.graphTarget({root:"product",nodes:{product:{types:["https://schema.org/Product"]},offer:{types:["https://schema.org/Offer"]}},edges:[{from:"product",property:"https://schema.org/offers",to:"offer"}]},"offer",{property:"https://schema.org/price"});
  assert.equal(graphTarget.semantic.path,"https://schema.org/Product > https://schema.org/offers > https://schema.org/Offer > https://schema.org/price");
  assert.doesNotMatch(graphTarget.semantic.path,/graph:/i);

  for(const target of [detectionTarget,graphTarget]){
    const dom=new JSDOM(html);let result;const view=VisualEvidence.create({document:dom.window.document,onComplete:(value)=>{result=value;},now:()=>"2026-08-19T12:00:00.000Z",nextObservationId:()=>"vo-test"});
    view.open({caller:"detection",context:{pageRevision:"rev-7"},targets:[target]});
    view.record({pickerVersion:1,frameUrl:"https://example.test",element:{tag:"span",role:null},candidates:[{selector:".price"}],interpretation:{kind:"text",value:"19.00"}});
    dom.window.document.querySelector("#visual-evidence-complete").click();
    const observation=result.decisions[target.id];
    assert.equal(Contract.validateObservation(observation).ok,true);
    assert.equal(observation.target.propertyTerm,"https://schema.org/price");
    assert.equal(observation.provenance.detectionRunId,target.detectionRunId || undefined);
    assert.doesNotMatch(JSON.stringify(observation),/19\.00|ownerDocument|openingTag/);
  }
});

