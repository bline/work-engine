"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Toolbox = require("../extension/core/semantic-toolbox");

test("semantic toolbox defaults, reorders, removes, and persists favorites", async () => {
  const values = {};
  const storage = {
    async get(key) { return { [key]: values[key] }; },
    async set(next) { Object.assign(values, next); }
  };
  const defaults = await Toolbox.load(storage);
  assert.deepEqual(defaults.favorites.map((item) => item.id), [...Toolbox.DEFAULT_FAVORITES]);

  let toolbox = Toolbox.addFavorite(defaults, { kind: "schemaType", id: "Article" }, 0);
  assert.equal(toolbox.favorites[0].id, "Article");
  assert.equal(toolbox.favorites.filter((item) => item.id === "Article").length, 1);
  toolbox = Toolbox.removeFavorite(toolbox, { kind: "schemaType", id: "Person" });
  await Toolbox.save(toolbox, storage);

  const restored = await Toolbox.load(storage);
  assert.equal(restored.favorites[0].id, "Article");
  assert.equal(restored.favorites.some((item) => item.id === "Person"), false);
  assert.equal(restored.version, 6);
  assert.deepEqual(Object.keys(restored), ["version", "favorites", "customTypes", "properties", "patterns", "tags", "tagAssignments", "collections", "toolkits"]);
});

test("semantic toolbox stores normalized reusable custom types", () => {
  const toolbox = Toolbox.addCustomType(Toolbox.normalize(null), {
    id: "guru:Editor",
    label: "Editor",
    description: "A person responsible for editing a marketplace listing.",
    definition: {
      kind: "type",
      description: "A person responsible for editing a marketplace listing.",
      valueType: "guru:Editor",
      cardinality: "one",
      example: "Editor"
    }
  });
  assert.equal(toolbox.customTypes["guru:Editor"].definition.kind, "type");
  assert.equal(toolbox.customTypes["guru:Editor"].definition.valueType, "guru:Editor");
  assert.equal(Toolbox.removeCustomType(toolbox, "guru:Editor").customTypes["guru:Editor"], undefined);
});

test("semantic toolbox stores imported relationship properties with provenance", () => {
  const toolbox = Toolbox.addProperty(Toolbox.normalize(null), {
    id: "foaf:knows",
    label: "knows",
    description: "A person known by this person.",
    definition: {
      kind: "relationship",
      description: "A person known by this person.",
      valueType: "http://xmlns.com/foaf/0.1/Person",
      cardinality: "one",
      example: "knows",
      canonicalUri: "http://xmlns.com/foaf/0.1/knows",
      domainIncludes: ["http://xmlns.com/foaf/0.1/Person"],
      rangeIncludes: ["http://xmlns.com/foaf/0.1/Person"]
    },
    provenance: { source: { id: "lov" }, canonicalUri: "http://xmlns.com/foaf/0.1/knows" }
  });
  assert.equal(toolbox.properties["foaf:knows"].definition.kind, "relationship");
  assert.equal(toolbox.properties["foaf:knows"].provenance.source.id, "lov");
  assert.equal(Toolbox.removeProperty(toolbox, "foaf:knows").properties["foaf:knows"], undefined);
});

test("semantic toolbox stores validated inference-only property profiles", () => {
  const toolbox = Toolbox.addProperty(Toolbox.normalize(null), {
    id: "guru:proposalCount",
    label: "proposal count",
    description: "The number of proposals received.",
    definition: {
      kind: "relationship",
      description: "The number of proposals received.",
      valueType: "Integer",
      domainIncludes: ["JobPosting"],
      authoringProfile: {
        aliases: ["quotes", "bids"], negativeAliases: ["budget"],
        expectedShapes: ["integer"], normalization: ["text", "int"], salience: 90
      }
    }
  });
  assert.deepEqual(toolbox.properties["guru:proposalCount"].definition.authoringProfile.aliases, ["quotes", "bids"]);
  assert.equal(toolbox.properties["guru:proposalCount"].definition.authoringProfile.version, 1);
  const rejected = Toolbox.addProperty(toolbox, {
    id: "guru:unsafe", label: "unsafe", description: "Unsafe transform.",
    definition: { kind: "relationship", description: "Unsafe transform.", authoringProfile: { normalization: ["eval"] } }
  });
  assert.equal(rejected.properties["guru:unsafe"], undefined);
});

test("semantic toolbox stores, normalizes, and removes patterns", async () => {
  const values = {};
  const storage = {
    async get(key) { return { [key]: values[key] }; },
    async set(next) { Object.assign(values, next); }
  };
  const defaults = await Toolbox.load(storage);
  const pattern = {
    id: "pattern:marketplace-buyer",
    label: "Marketplace buyer",
    description: "A buyer with aggregate rating.",
    root: "buyer",
    nodes: {
      buyer: { types: ["Organization"], expectation: "core" },
      rating: { types: ["AggregateRating"], expectation: "optional" }
    },
    edges: [{ from: "buyer", property: "aggregateRating", to: "rating", expectation: "optional" }],
    terms: {}
  };

  let toolbox = Toolbox.addPattern(defaults, pattern);
  assert.equal(toolbox.patterns["pattern:marketplace-buyer"].label, "Marketplace buyer");
  assert.equal(toolbox.patterns["pattern:marketplace-buyer"].nodes.buyer.types[0], "Organization");
  await Toolbox.save(toolbox, storage);

  const restored = await Toolbox.load(storage);
  assert.equal(restored.patterns["pattern:marketplace-buyer"].root, "buyer");

  const withoutRoot = Toolbox.addPattern(restored, { ...pattern, id: "pattern:bad", root: "missing" });
  assert.equal(withoutRoot.patterns["pattern:bad"], undefined);

  toolbox = Toolbox.removePattern(restored, "pattern:marketplace-buyer");
  assert.equal(toolbox.patterns["pattern:marketplace-buyer"], undefined);
});

test("semantic toolbox normalizes tags, heterogeneous collection members, and assignments", () => {
  const normalized = Toolbox.normalize({
    tags: {
      employment: { id: "employment", label: "Employment", color: "#AABBCC" },
      bad: { id: "bad", label: "" }
    },
    tagAssignments: {
      "pattern\u001fpattern:jobs": ["employment", "missing", "employment"],
      malformed: ["employment"]
    },
    collections: {
      marketplace: {
        id: "marketplace",
        label: "Marketplace",
        members: [
          { kind: "pattern", id: "pattern:jobs" },
          { kind: "pattern", id: "pattern:jobs" },
          { kind: "collection", id: "recursive" }
        ]
      }
    }
  });
  assert.equal(normalized.tags.employment.color, "#aabbcc");
  assert.equal(normalized.tags.bad, undefined);
  assert.deepEqual(normalized.tagAssignments, { "pattern\u001fpattern:jobs": ["employment"] });
  assert.deepEqual(normalized.collections.marketplace.members, [{ kind: "pattern", id: "pattern:jobs" }]);
});
