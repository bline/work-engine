"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");

const root = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(root, "extension/options.html"), "utf8");
const scripts = ["core/automatic-settings.js", "options.js"].map((file) => fs.readFileSync(path.join(root, "extension", file), "utf8"));

test("the options page points adapter management at the focused side panel", () => {
  const dom = new JSDOM(html, { runScripts: "outside-only" });
  const text = dom.window.document.body.textContent.replace(/\s+/g, " ");
  assert.match(text, /Open adapter editor/);
  assert.match(text, /side panel/);
  assert.match(text, /visual picker.*no DevTools workspace is required/);
  assert.ok(dom.window.document.querySelector("#automatic-confidence"));
  assert.equal(dom.window.document.querySelector("input[type=file]"), null);
  dom.window.close();
});

test("the configured automatic confidence threshold loads and saves", async () => {
  const local = { site2jsonAutomaticSettings: { minimumConfidence: "moderate" } };
  const dom = new JSDOM(html, { runScripts: "outside-only" });
  dom.window.chrome = { storage: { local: {
    async get(key) { return { [key]: local[key] }; },
    async set(value) { Object.assign(local, value); }
  } } };
  for (const script of scripts) dom.window.eval(script);
  await new Promise((resolve) => setTimeout(resolve, 0));
  const select = dom.window.document.querySelector("#automatic-confidence");
  assert.equal(select.value, "moderate");
  select.value = "strong";
  select.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(JSON.parse(JSON.stringify(local.site2jsonAutomaticSettings)), { minimumConfidence: "strong" });
  assert.match(dom.window.document.querySelector("#settings-status").textContent, /high confidence/i);
  dom.window.close();
});
