"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Prism = require("prismjs/components/prism-core");
require("prismjs/components/prism-json");
const JsonPreview = require("../extension/editor/json-preview");

test("JSON preview highlights tokens without interpreting page-derived strings as markup", () => {
  const dom = new JSDOM("<pre><code></code></pre>");
  const element = dom.window.document.querySelector("code");
  const hostile = "</code><img src=x onerror=globalThis.pwned=true>";

  JsonPreview.render(element, { title: hostile, count: 2, ready: true, missing: null }, Prism);

  assert.equal(element.querySelector("img"), null);
  assert.equal(element.textContent.includes(hostile), true);
  assert.equal(element.querySelectorAll(".token.property").length, 4);
  assert.equal(element.querySelectorAll(".token.string").length, 1);
  assert.equal(element.querySelectorAll(".token.number").length, 1);
  assert.equal(element.querySelectorAll(".token.boolean").length, 1);
  assert.equal(element.querySelectorAll(".token.null").length, 1);
  assert.equal(element.textContent, JsonPreview.serialize({ title: hostile, count: 2, ready: true, missing: null }));
  dom.window.close();
});

test("JSON preview falls back to safe plain text when Prism is unavailable", () => {
  const dom = new JSDOM("<pre><code></code></pre>");
  const element = dom.window.document.querySelector("code");

  JsonPreview.render(element, { value: "<script>bad()</script>" }, null);

  assert.equal(element.querySelector("script"), null);
  assert.match(element.textContent, /<script>bad\(\)<\/script>/);
  dom.window.close();
});

test("JSON preview marks and reveals lines matching the active semantic types", () => {
  const dom = new JSDOM("<pre><code></code></pre>");
  const element = dom.window.document.querySelector("code");
  const revealed = [];
  dom.window.HTMLElement.prototype.scrollIntoView = function scrollIntoView(options) { revealed.push({ node: this, options }); };

  JsonPreview.render(element, {
    entities: [{ type: "Product", name: "Analyzer" }, { type: "Person", name: "Ada" }]
  }, Prism, { highlightStrings: ["Product"] });

  const selected = [...element.querySelectorAll(".s2j-code-line.selected")];
  assert.equal(selected.length, 1);
  assert.match(selected[0].textContent, /Product/);
  assert.equal(revealed.length, 1);
  assert.equal(revealed[0].node, selected[0]);
  assert.equal(element.textContent, JsonPreview.serialize({
    entities: [{ type: "Product", name: "Analyzer" }, { type: "Person", name: "Ada" }]
  }));
  dom.window.close();
});

test("JSON preview focuses exact output paths and exposes their graph aliases", () => {
  const dom = new JSDOM("<pre><code></code></pre>");
  const element = dom.window.document.querySelector("code");
  const focused = [];
  const value = { "@graph": [{ "@type": "JobPosting", hiringOrganization: { "@type": "Organization", name: "Acme" } }] };

  JsonPreview.render(element, value, Prism, {
    highlightPaths: ["/@graph/0/hiringOrganization"],
    pathAliases: {
      "/@graph/0": ["listing"],
      "/@graph/0/hiringOrganization": ["buyer"]
    },
    onFocus: (aliases, path) => focused.push({ aliases, path })
  });

  const selected = [...element.querySelectorAll(".s2j-code-line.selected")];
  assert.ok(selected.length >= 3);
  assert.ok(selected.every((line) => line.dataset.path.startsWith("/@graph/0/hiringOrganization")));
  const name = [...element.querySelectorAll(".s2j-code-line")].find((line) => line.dataset.path.endsWith("/name"));
  assert.deepEqual(name.dataset.focusAliases.split("\u001f"), ["buyer", "listing"]);
  const graphRow = [...element.querySelectorAll(".s2j-code-line")].find((line) => line.dataset.path === "/@graph/0");
  assert.deepEqual(graphRow.dataset.focusAliases.split("\u001f"), ["listing"], "ancestor rows must not inherit a descendant node alias");
  name.click();
  assert.deepEqual(focused, [{ aliases: ["buyer", "listing"], path: "/@graph/0/hiringOrganization/name" }]);
  assert.equal(element.textContent, JsonPreview.serialize(value));
  dom.window.close();
});

test("path-aware serialization stays byte-for-byte aligned with formatted JSON", () => {
  for (const value of [null, {}, [], { nested: [{ empty: [] }, { ready: true }] }]) {
    assert.equal(JsonPreview.serializedLines(value).map((line) => line.text).join("\n"), JsonPreview.serialize(value));
  }
});
