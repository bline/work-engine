"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Arbitrator = require("../extension/authoring/semantic-mapping-arbitrator");

function candidate({ selector, suggestedName, context, tag = "div", attribute = null, kind = "text", sampled = 10 }) {
  return {
    selector, suggestedName, kind, attribute, multiple: false,
    coverage: { present: sampled, sampled },
    sampleValues: [suggestedName, `${suggestedName} two`],
    evidence: { tag, attribute, classes: selector.replace(/^[.#]/, "").split(/[. ]/), context, text: suggestedName, matchCounts: Array(sampled).fill(1) }
  };
}

function term(name, score, { source = "schema", valueType = "Text", cardinality = "one", salience = 60 } = {}) {
  return { name, source, score, valueType, cardinality, salience };
}

test("globally arbitrates duplicate claims for a singular semantic property", () => {
  const primary = candidate({ selector: ".title", suggestedName: "title", context: "primary title", tag: "h2" });
  const secondary = candidate({ selector: ".subtitle", suggestedName: "title", context: "secondary title" });
  const result = Arbitrator.arbitrate([
    { candidate: primary, suggestions: [term("title", 34)] },
    { candidate: secondary, suggestions: [term("title", 18)] }
  ]);

  assert.equal(result.assignments[0].term?.name, "title");
  assert.equal(result.assignments[1].term, null);
  assert.equal(result.summary.accepted, 1);
  assert.ok(result.alternatives.length > 0);
});

test("uses related paths to resolve a locally ambiguous nested mapping", () => {
  const organizationName = candidate({ selector: ".employer-name", suggestedName: "name", context: "employer company" });
  const organizationDescription = candidate({ selector: ".profile-summary", suggestedName: "description", context: "profile summary" });
  const result = Arbitrator.arbitrate([
    {
      candidate: organizationName,
      suggestions: [term("hiringOrganization.name", 26, { source: "extension" }), term("buyer.name", 26, { source: "extension" })]
    },
    {
      candidate: organizationDescription,
      suggestions: [term("hiringOrganization.description", 24, { source: "extension" }), term("buyer.description", 24, { source: "extension" })]
    }
  ]);

  assert.equal(result.assignments[0].term?.name, "hiringOrganization.name");
  assert.equal(result.assignments[1].term?.name, "hiringOrganization.description");
  assert.equal(result.assignments[1].report.globalArbitration.relationshipFamily, "hiringOrganization");
  assert.equal(result.assignments[1].report.semanticSupport.strength, "strong");
});

test("uses a selected composition relationship as a semantic prior", () => {
  const description = candidate({ selector: ".profile-summary", suggestedName: "description", context: "profile summary" });
  const result = Arbitrator.arbitrate([{
    candidate: description,
    suggestions: [term("hiringOrganization.description", 24, { source: "extension" }), term("buyer.description", 24, { source: "extension" })]
  }], { relationshipExpectations: { hiringOrganization: "core" } });

  assert.equal(result.assignments[0].term?.name, "hiringOrganization.description");
  assert.equal(result.assignments[0].report.globalArbitration.relationshipExpectation, 4);
});

test("does not turn one weak local hint into an accepted mapping", () => {
  const weak = candidate({ selector: ".label", suggestedName: "name", context: "label", sampled: 1 });
  const result = Arbitrator.arbitrate([{ candidate: weak, suggestions: [term("name", 8)] }]);

  assert.equal(result.assignments[0].accepted, false);
  assert.equal(result.assignments[0].term, null);
});

test("still reports globalArbitration when no candidate clears eligibility, so manual corrections can be promoted", () => {
  const noSignal = candidate({ selector: ".zzz-unrelated-class", suggestedName: "zzzunrelated", context: "totally unrelated context text", sampled: 1 });
  const result = Arbitrator.arbitrate([{ candidate: noSignal, suggestions: [term("completelyDifferentName", 1)] }]);

  assert.equal(result.assignments[0].accepted, false);
  assert.equal(result.assignments[0].term, null);
  assert.ok(result.assignments[0].report, "a report must still be produced for the unresolved field");
  assert.ok(Array.isArray(result.assignments[0].report.globalArbitration?.selectedFrom), "globalArbitration must be attached even when nothing was selected");
});

test("does not reclaim properties already mapped on the entity", () => {
  const heading = candidate({ selector: ".title", suggestedName: "title", context: "title", tag: "h2" });
  const result = Arbitrator.arbitrate(
    [{ candidate: heading, suggestions: [term("title", 34), term("headline", 20)] }],
    { existingPropertyNames: ["title"] }
  );

  assert.notEqual(result.assignments[0].term?.name, "title");
});

test("stops automatic acceptance when a local profile changes the winning property", () => {
  const heading = candidate({ selector: ".title", suggestedName: "title", context: "title", tag: "h2" });
  const profiledTitle = {
    ...term("title", 30),
    aliases: ["title"],
    negativeAliases: ["title"],
    authoringProfile: { negativeAliases: ["title"] },
    profileBaseline: { aliases: ["title"], cardinality: "one", normalization: ["text", "trim"], salience: 60 },
    librarySources: [{
      id: "profile-title",
      termId: "schema:title",
      revision: 4,
      profileDigest: "s2jp1:test",
      profile: { negativeAliases: ["title"] },
      source: { kind: "local" }
    }]
  };
  const result = Arbitrator.arbitrate([{
    candidate: heading,
    suggestions: [profiledTitle, { ...term("headline", 24), aliases: ["title", "headline"] }]
  }]);

  assert.equal(result.assignments[0].accepted, false);
  assert.equal(result.assignments[0].term, null);
  assert.equal(result.assignments[0].report.status, "profile-review-required");
  assert.equal(result.assignments[0].report.property, "headline");
  assert.equal(result.assignments[0].report.localKnowledge.material, true);
  assert.equal(result.assignments[0].report.localKnowledge.withoutProfile.property, "title");
  assert.equal(result.assignments[0].report.localKnowledge.sources[0].profileDigest, "s2jp1:test");
});
