"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Reconstruction = require("../extension/ir/durable-binding-reconstruction");
const SourceBindings = require("../extension/ir/source-bindings");

function documentFor(html) { return new JSDOM(html).window.document; }

test("reconstructs and verifies a stable selector without retaining live nodes", () => {
  const document = documentFor(`<main><article data-testid="job"><h2 class="title">Engineer</h2></article></main>`);
  const source = document.querySelector(".title");
  const node = { id: "run:item:1:title", kind: "value", value: "Engineer" };
  const result = Reconstruction.reconstruct({ node, sources: [source], document });
  assert.equal(result.ok, true);
  assert.equal(result.binding.kind, "selector");
  assert.deepEqual(SourceBindings.resolve(result.binding, document), [source]);
  assert.equal(SourceBindings.read(result.binding, [source]), "Engineer");
  assert.equal(result.provenance.identityScope, "detection-run");
  assert.doesNotThrow(() => JSON.stringify(result));
  assert.equal(Object.isFrozen(result), true);
});

test("returns an explicit frozen failure when only a fallback selector is available", () => {
  const document = documentFor(`<div><span>Only value</span></div>`);
  const result = Reconstruction.reconstruct({ node: { id: "run:value:1", value: "Only value" }, sources: [document.querySelector("span")], document });
  assert.equal(result.ok, false);
  assert.equal(result.status, "cannot-reconstruct");
  assert.equal(result.reason, "no-durable-round-trip");
  assert.equal(Object.isFrozen(result.provenance), true);
});

test("does not guess missing or non-element source references", () => {
  const document = documentFor(`<main id="page">Text</main>`);
  const node = { id: "run:value:1", value: "Text" };
  assert.equal(Reconstruction.reconstruct({ node, sourceRefs: new Map(), document }).reason, "missing-source");
  assert.equal(Reconstruction.reconstruct({ node, sources: [document.querySelector("main").firstChild], document }).reason, "non-element-source");
});

test("reconstructs a flat sequence only after an exact ordered resolver round trip", () => {
  const document = documentFor(`<main id="results"><h3 class="item-start">First result</h3><p class="snippet">First description.</p></main>`);
  const sources = Array.from(document.querySelector("#results").children);
  const result = Reconstruction.reconstruct({ node: { id: "run:item:1", kind: "entity" }, sources, document });
  assert.equal(result.ok, true);
  assert.equal(result.binding.kind, "sequence");
  const groups = SourceBindings.resolve(result.binding, document);
  assert.equal(groups.length, 1);
  assert.deepEqual(groups[0], sources);
  assert.equal(result.verification.sourceCount, 2);
});

test("reconstruction is side-effect free and failure leaves ephemeral preview inputs usable", () => {
  const document = documentFor(`<main><span>One</span><span>Two</span></main>`);
  const sources = [document.querySelector("span")];
  const sourceRefs = new Map([["run:value:1", sources]]);
  const before = document.documentElement.outerHTML;
  const result = Reconstruction.reconstruct({ node: { id: "run:value:1", value: "One" }, sourceRefs, document });
  assert.equal(result.ok, false);
  assert.equal(document.documentElement.outerHTML, before);
  assert.equal(sourceRefs.get("run:value:1"), sources);
  assert.equal(Object.prototype.hasOwnProperty.call(result, "adapter"), false);
  assert.equal(Object.prototype.hasOwnProperty.call(result, "published"), false);
});
