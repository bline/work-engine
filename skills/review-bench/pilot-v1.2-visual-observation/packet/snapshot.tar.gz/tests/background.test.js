"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const script = fs.readFileSync(path.resolve(__dirname, "../extension/background.js"), "utf8");

function loadBackground({ failOpen = false } = {}) {
  let listener;
  let connectListener;
  let createdListener;
  let activatedListener;
  let updatedListener;
  const pending = {};
  const calls = { opened: 0, removed: [], sidePanelOptions: [] };
  const chrome = {
    commands: { onCommand: { addListener: (value) => { listener = value; } } },
    runtime: { onConnect: { addListener: (value) => { connectListener = value; } } },
    action: { openPopup: async () => { calls.opened += 1; if (failOpen) throw new Error("blocked"); } },
    sidePanel: { setOptions: async (options) => { calls.sidePanelOptions.push(options); } },
    tabs: {
      query: async () => [{ id: 11 }, { id: 12 }],
      onCreated: { addListener: (value) => { createdListener = value; } },
      onActivated: { addListener: (value) => { activatedListener = value; } },
      onUpdated: { addListener: (value) => { updatedListener = value; } }
    },
    storage: { session: {
      set: async (value) => Object.assign(pending, value),
      remove: async (key) => { calls.removed.push(key); delete pending[key]; }
    } }
  };
  vm.runInNewContext(script, { chrome, console: { error: () => {} }, Date, Set });
  return { activatedListener, calls, connectListener, createdListener, listener, pending, updatedListener };
}

function fakePort(name) {
  let messageListener;
  let disconnectListener;
  const sent = [];
  return {
    name,
    sent,
    postMessage: (message) => { sent.push(message); },
    onMessage: { addListener: (listener) => { messageListener = listener; } },
    onDisconnect: { addListener: (listener) => { disconnectListener = listener; } },
    receive: (message) => messageListener?.(message),
    disconnect: () => disconnectListener?.()
  };
}

test("supported shortcuts queue a popup command", async () => {
  for (const command of ["start-session", "add-page", "copy-session", "download-session"]) {
    const { calls, listener, pending } = loadBackground();
    await listener(command);
    assert.equal(calls.opened, 1);
    assert.equal(pending.pendingShortcutCommand.command, command);
  }
});

test("gives every browser tab a tab-specific side-panel URL", async () => {
  const loaded = loadBackground();
  await new Promise((resolve) => setImmediate(resolve));
  assert.deepEqual(JSON.parse(JSON.stringify(loaded.calls.sidePanelOptions.slice(0, 2))), [
    { tabId: 11, path: "editor/sidebar.html?tabId=11", enabled: true },
    { tabId: 12, path: "editor/sidebar.html?tabId=12", enabled: true }
  ]);

  await loaded.createdListener({ id: 13 });
  await loaded.activatedListener({ tabId: 14 });
  await loaded.updatedListener(15);
  assert.deepEqual(loaded.calls.sidePanelOptions.slice(-3).map((options) => options.tabId), [13, 14, 15]);
});

test("unknown shortcuts are ignored and popup failures clear pending work", async () => {
  const unknown = loadBackground();
  await unknown.listener("unknown");
  assert.equal(unknown.calls.opened, 0);

  const failure = loadBackground({ failOpen: true });
  await failure.listener("copy-session");
  assert.equal(failure.pending.pendingShortcutCommand, undefined);
  assert.deepEqual(failure.calls.removed, ["pendingShortcutCommand"]);
});

test("relays table-panel commands and snapshots only within the inspected tab", () => {
  const { connectListener } = loadBackground();
  const sidebar = fakePort("site2json-sidebar:41");
  const panel = fakePort("site2json-table:41");
  const otherPanel = fakePort("site2json-table:42");
  connectListener(sidebar);
  connectListener(panel);
  connectListener(otherPanel);

  assert.ok(panel.sent.some((message) => message.type === "relay-status" && message.sidebarConnected));
  assert.ok(sidebar.sent.some((message) => message.type === "panel-request-snapshot"));
  panel.receive({ type: "panel-command", command: { action: "refresh" } });
  assert.ok(sidebar.sent.some((message) => message.type === "panel-command" && message.command.action === "refresh"));
  sidebar.receive({ type: "table-snapshot", snapshot: { rows: [] } });
  assert.ok(panel.sent.some((message) => message.type === "table-snapshot"));
  assert.equal(otherPanel.sent.some((message) => message.type === "table-snapshot"), false);

  sidebar.disconnect();
  assert.ok(panel.sent.some((message) => message.type === "relay-status" && message.sidebarConnected === false));
});

test("routes controller state and expanded-surface lifecycle within one inspected tab", () => {
  const { connectListener } = loadBackground();
  const controller = fakePort("site2json-controller:41");
  const sidebar = fakePort("site2json-sidebar:41");
  const workspace = fakePort("site2json-table:41");
  connectListener(controller);
  connectListener(sidebar);
  connectListener(workspace);

  assert.ok(controller.sent.some((message) => message.type === "surface-connected" && message.surface === "expanded"));
  sidebar.receive({ type: "table-snapshot", snapshot: { activeBlockId: "jobs" } });
  assert.ok(controller.sent.some((message) => message.type === "table-snapshot" && message.snapshot.activeBlockId === "jobs"));
  controller.receive({ type: "controller-state", lease: { owner: "expanded" } });
  assert.ok(sidebar.sent.some((message) => message.type === "controller-state"));
  assert.ok(workspace.sent.some((message) => message.type === "controller-state"));

  workspace.disconnect();
  assert.ok(controller.sent.some((message) => message.type === "surface-disconnected" && message.surface === "expanded"));
});

test("labels controller-routed commands with their originating editor surface", () => {
  const { connectListener } = loadBackground();
  const controller = fakePort("site2json-controller:41");
  const sidebar = fakePort("site2json-sidebar:41");
  const workspace = fakePort("site2json-table:41");
  connectListener(controller);
  connectListener(sidebar);
  connectListener(workspace);

  workspace.receive({ type: "editor-command", command: { action: "refresh" } });
  assert.ok(controller.sent.some((message) => message.type === "editor-command" && message.sourceSurface === "expanded"));
  sidebar.receive({ type: "editor-command", command: { action: "navigate-step", step: "finish" } });
  assert.ok(controller.sent.some((message) => message.type === "editor-command" && message.sourceSurface === "sidebar"));
});
