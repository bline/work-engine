"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const AutomaticConversion = require("../extension/authoring/automatic-conversion");
const AdapterDefinition = require("../extension/editor/adapter-definition");

function definition(adapter = "example") {
  return AdapterDefinition.buildDraftDefinition({
    adapterId: adapter,
    namespace: `https://site2json.dev/ns/${adapter}#`,
    pageUrl: "https://www.example.com/search/jobs",
    pageId: "search",
    pageType: "SearchResultsPage",
    entityName: "JobPosting",
    schemaType: "JobPosting",
    scope: ".job",
    identity: { selector: "h2 a", attribute: "href", kind: "url", multiple: false },
    fields: [{ name: "title", selector: "h2", kind: "text", multiple: false }],
    requireFields: ["title"]
  });
}

test("uses a matching enabled adapter before automatic authoring", () => {
  const existing = definition();
  const result = AutomaticConversion.resolveExisting({
    entries: [{ id: "example", enabled: true, definition: existing }],
    drafts: [{ id: "draft", workingDefinition: existing, editorState: { authoring: { origin: "automatic" } } }]
  }, "https://www.example.com/search/jobs?page=2");
  assert.equal(result.outcome, AutomaticConversion.OUTCOMES.USE_EXISTING);
  assert.equal(result.id, "example");
});

test("respects disabled adapters and preserves manual drafts", () => {
  const existing = definition();
  assert.equal(AutomaticConversion.resolveExisting({
    entries: [{ id: "example", enabled: false, definition: existing }]
  }, "https://www.example.com/search/jobs").outcome, AutomaticConversion.OUTCOMES.DISABLED_EXISTING);

  assert.equal(AutomaticConversion.resolveExisting({
    drafts: [{ id: "manual", adapterId: null, workingDefinition: null, editorState: { pageUrl: "https://www.example.com/search/jobs", blocks: [{ id: "block-1" }] } }]
  }, "https://www.example.com/search/jobs").outcome, AutomaticConversion.OUTCOMES.PRESERVE_MANUAL_DRAFT);
});

test("ignores empty placeholder drafts that have not authored anything", () => {
  const result = AutomaticConversion.resolveExisting({
    drafts: [{
      id: "blank",
      adapterId: null,
      workingDefinition: null,
      editorState: { pageUrl: "https://www.example.com/search/jobs", blocks: [] }
    }]
  }, "https://www.example.com/search/jobs");
  assert.equal(result.outcome, AutomaticConversion.OUTCOMES.AUTHOR);
  assert.equal(AutomaticConversion.meaningfulDraft({ editorState: { pageUrl: "https://www.example.com/search/jobs" } }), false);
});

test("resumes only drafts explicitly tagged as automatic", () => {
  const existing = definition();
  const result = AutomaticConversion.resolveExisting({
    drafts: [{
      id: "automatic",
      adapterId: "example",
      workingDefinition: existing,
      editorState: { authoring: { origin: "automatic", reviewStatus: "unreviewed" } }
    }]
  }, "https://www.example.com/search/jobs");
  assert.equal(result.outcome, AutomaticConversion.OUTCOMES.RESUME_AUTOMATIC_DRAFT);
});

test("automatic provenance extends editor state without changing the definition", () => {
  const workingDefinition = definition();
  const draft = { id: "new:1", workingDefinition, editorState: { pageUrl: "https://www.example.com/search/jobs" } };
  const metadata = AutomaticConversion.automaticMetadata({
    generatorVersion: "0.1.0",
    generatedAt: "2026-08-10T12:00:00.000Z",
    confidence: { scope: "strong" }
  });
  const tagged = AutomaticConversion.tagDraft(draft, metadata);
  assert.equal(tagged.editorState.authoring.origin, "automatic");
  assert.equal(tagged.editorState.authoring.reviewStatus, "unreviewed");
  assert.deepEqual(tagged.workingDefinition, workingDefinition);
  assert.equal(draft.editorState.authoring, undefined);
});

test("maps the two legitimate automatic page shapes onto block metadata", () => {
  assert.deepEqual(AutomaticConversion.blockShape("collection"), { arity: "many", role: "collection", fidelity: "summary" });
  assert.deepEqual(AutomaticConversion.blockShape("primary"), { arity: "one", role: "primary", fidelity: "full" });
  assert.throws(() => AutomaticConversion.blockShape("navigation"), /Unknown automatic page shape/);
});

test("separates one-time download confidence from publication confidence", () => {
  const strong = { scope: "strong", scopeMargin: "strong", semantics: "strong", fields: "strong", extraction: "strong" };
  const publish = AutomaticConversion.decideOutcome(strong);
  assert.deepEqual({ outcome: publish.outcome, publish: publish.publish, download: publish.download }, {
    outcome: AutomaticConversion.OUTCOMES.PUBLISH_AND_DOWNLOAD, publish: true, download: true
  });

  const oneTime = AutomaticConversion.decideOutcome({ ...strong, semantics: "moderate" });
  assert.equal(oneTime.outcome, AutomaticConversion.OUTCOMES.DRAFT_AND_DOWNLOAD);
  assert.equal(oneTime.publish, false);
  assert.equal(oneTime.download, true);

  const review = AutomaticConversion.decideOutcome({ ...strong, scopeMargin: "weak" });
  assert.equal(review.outcome, AutomaticConversion.OUTCOMES.DRAFT_AND_REVIEW);
  assert.equal(review.publish, false);
  assert.equal(review.download, false);
  assert.match(review.reasons[0], /scope margin/i);
});

test("a high run threshold stops moderate inference instead of producing data", () => {
  const signals = { scope: "strong", scopeMargin: "strong", semantics: "strong", fields: "moderate", extraction: "strong" };
  const moderate = AutomaticConversion.decideOutcome(signals, { minimumConfidence: "moderate" });
  assert.equal(moderate.outcome, AutomaticConversion.OUTCOMES.DRAFT_AND_DOWNLOAD);
  assert.equal(moderate.download, true);
  const high = AutomaticConversion.decideOutcome(signals, { minimumConfidence: "strong" });
  assert.equal(high.outcome, AutomaticConversion.OUTCOMES.DRAFT_AND_REVIEW);
  assert.equal(high.download, false);
  assert.match(high.reasons[0], /strong run threshold/);
});
