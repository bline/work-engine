"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");

const root = path.resolve(__dirname, "..");
const selectorScript = fs.readFileSync(path.join(root, "extension/editor/selector-candidates.js"), "utf8");
const scopeScript = fs.readFileSync(path.join(root, "extension/editor/scope-inference.js"), "utf8");
const highlighterScript = fs.readFileSync(path.join(root, "extension/content/page-highlighter.js"), "utf8");
const pickerScript = fs.readFileSync(path.join(root, "extension/content/page-picker.js"), "utf8");

function nextFrame(window) {
  return new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
}

test("page picker keeps selector generation out of hover and publishes it on click", async () => {
  const dom = new JSDOM("<!doctype html><html><body><main><button data-testid='save'>Save record</button></main></body></html>", {
    url: "https://example.test/editor",
    runScripts: "outside-only",
    pretendToBeVisual: true
  });
  const { window } = dom;
  const runtimeListeners = [];
  const sent = [];
  window.chrome = {
    runtime: {
      onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
      sendMessage: async (message) => { sent.push(message); }
    }
  };
  window.eval(selectorScript);
  window.eval(scopeScript);
  window.eval(highlighterScript);
  const originalGenerate = window.Site2JsonSelectorCandidates.generateCandidates;
  let generationCount = 0;
  window.Site2JsonSelectorCandidates.generateCandidates = (...args) => {
    generationCount += 1;
    return originalGenerate(...args);
  };
  window.eval(pickerScript);

  runtimeListeners[0]({ type: "site2json-picker:start" });
  const button = window.document.querySelector("button");
  button.getBoundingClientRect = () => ({ left: 20, top: 30, right: 140, bottom: 70, width: 120, height: 40 });
  button.dispatchEvent(new window.MouseEvent("pointermove", { bubbles: true }));
  await nextFrame(window);

  assert.equal(generationCount, 0);
  const host = window.document.querySelector("site2json-picker-ui");
  assert.ok(host);
  assert.equal(host.shadowRoot.querySelector(".highlight").style.display, "block");
  assert.equal(host.shadowRoot.querySelector(".tag").textContent, 'button[data-testid="save"]');

  button.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true }));
  assert.ok(generationCount > 0, "selector and scope analysis should run after the click");
  assert.equal(sent[0].type, "site2json-picker:selection");
  assert.equal(sent[0].selection.selector, '[data-testid="save"]');
  assert.equal(sent[0].selection.matchCount, 1);
  assert.equal(host.shadowRoot.querySelector(".highlight").classList.contains("locked"), true);

  window.Site2JsonPagePicker.cancel();
  dom.window.close();
});

test("page picker exposes an isolated deterministic selection hook for extension automation", async () => {
  const dom = new JSDOM("<!doctype html><html><body><article class='result'>Result</article></body></html>", {
    url: "https://example.test/results",
    runScripts: "outside-only",
    pretendToBeVisual: true
  });
  const { window } = dom;
  const runtimeListeners = [];
  const sent = [];
  window.HTMLElement.prototype.scrollIntoView = () => {};
  window.chrome = { runtime: {
    onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
    sendMessage: async (message) => { sent.push(message); }
  } };
  window.eval(selectorScript);
  window.eval(scopeScript);
  window.eval(highlighterScript);
  window.eval(pickerScript);
  assert.equal(window.Site2JsonPagePicker.select(".result"), false, "automation selected while the picker was inactive");
  runtimeListeners[0]({ type: "site2json-picker:start" });
  assert.equal(window.Site2JsonPagePicker.select(".result"), true);
  assert.equal(sent[0].type, "site2json-picker:selection");
  assert.equal(sent[0].selection.element.tag, "article");
  assert.equal(window.Site2JsonPagePicker.select("???"), false);
  dom.window.close();
});

test("page picker shows a stable structural selector without generated classes", async () => {
  const dom = new JSDOM(`<!doctype html><html><body>
    <ul id="serviceList"><li class="record Button__button__x7Ea9"><strong class="title">Job</strong></li></ul>
  </body></html>`, { url: "https://example.test/jobs", runScripts: "outside-only", pretendToBeVisual: true });
  const { window } = dom;
  const runtimeListeners = [];
  window.chrome = { runtime: {
    onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
    sendMessage: async () => {}
  } };
  window.eval(selectorScript);
  window.eval(scopeScript);
  window.eval(highlighterScript);
  window.eval(pickerScript);
  runtimeListeners[0]({ type: "site2json-picker:start" });

  const title = window.document.querySelector("strong");
  title.getBoundingClientRect = () => ({ left: 20, top: 30, right: 140, bottom: 70, width: 120, height: 40 });
  title.dispatchEvent(new window.MouseEvent("pointermove", { bubbles: true }));
  await nextFrame(window);

  const heading = window.document.querySelector("site2json-picker-ui").shadowRoot.querySelector(".tag").textContent;
  assert.equal(heading, "#serviceList > li.record > strong.title");
  assert.doesNotMatch(heading, /x7Ea9/);
  dom.window.close();
});

test("long hover selectors collapse ancestors in the middle", async () => {
  const dom = new JSDOM(`<!doctype html><html><body>
    <main id="results"><section class="card"><header class="record-header"><div class="actions"><button class="apply">Apply</button></div></header></section></main>
  </body></html>`, { url: "https://example.test/jobs", runScripts: "outside-only", pretendToBeVisual: true });
  const { window } = dom;
  const runtimeListeners = [];
  window.chrome = { runtime: {
    onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
    sendMessage: async () => {}
  } };
  window.eval(selectorScript);
  window.eval(scopeScript);
  window.eval(highlighterScript);
  window.eval(pickerScript);
  runtimeListeners[0]({ type: "site2json-picker:start" });

  const button = window.document.querySelector("button");
  button.getBoundingClientRect = () => ({ left: 20, top: 30, right: 140, bottom: 70, width: 120, height: 40 });
  button.dispatchEvent(new window.MouseEvent("pointermove", { bubbles: true }));
  await nextFrame(window);

  assert.equal(
    window.document.querySelector("site2json-picker-ui").shadowRoot.querySelector(".tag").textContent,
    "section.card > … > div.actions > button.apply"
  );
  dom.window.close();
});

test("page picker distinguishes a repeating scope from the exact clicked card", async () => {
  const dom = new JSDOM(`<!doctype html><html><body>
    <ul id="serviceList">
      <li><article>First</article></li>
      <li><article>Second</article></li>
      <li><article>Third</article></li>
    </ul>
  </body></html>`, { url: "https://example.test/jobs", runScripts: "outside-only", pretendToBeVisual: true });
  const { window } = dom;
  const runtimeListeners = [];
  const sent = [];
  window.chrome = { runtime: {
    onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
    sendMessage: async (message) => { sent.push(message); }
  } };
  window.eval(selectorScript);
  window.eval(scopeScript);
  window.eval(highlighterScript);
  window.eval(pickerScript);
  runtimeListeners[0]({ type: "site2json-picker:start" });

  const card = window.document.querySelectorAll("#serviceList > li")[2];
  card.getBoundingClientRect = () => ({ left: 20, top: 30, right: 220, bottom: 130, width: 200, height: 100 });
  card.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true }));

  const picked = sent[0].selection;
  assert.equal(picked.scopeProposal.selector, "#serviceList > li");
  assert.equal(picked.scopeProposal.matchCount, 3);
  assert.equal(picked.selector, "#serviceList > li");
  assert.equal(picked.exactSelector, "#serviceList > li:nth-of-type(3)");
  assert.equal(picked.exactMatchCount, 1);
  assert.deepEqual(JSON.parse(JSON.stringify(window.Site2JsonPageHighlighter.snapshot())), [
    { id: "picker-scope", selector: "#serviceList > li", shown: 3 }
  ]);
  dom.window.close();
});

test("field picking defers repeating-scope inference and leaves scope highlighting to the field preview", () => {
  const dom = new JSDOM(`<!doctype html><html><body>
    <ul id="serviceList"><li><a class="title">First</a></li><li><a class="title">Second</a></li></ul>
  </body></html>`, { url: "https://example.test/jobs", runScripts: "outside-only", pretendToBeVisual: true });
  const { window } = dom;
  const runtimeListeners = [];
  const sent = [];
  window.chrome = { runtime: {
    onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
    sendMessage: async (message) => { sent.push(message); }
  } };
  window.eval(selectorScript);
  window.eval(scopeScript);
  window.eval(highlighterScript);
  let inferenceCount = 0;
  const infer = window.Site2JsonScopeInference.inferRepeatingScope;
  window.Site2JsonScopeInference.inferRepeatingScope = (...args) => { inferenceCount += 1; return infer(...args); };
  window.eval(pickerScript);
  runtimeListeners[0]({ type: "site2json-picker:start", mode: "new-field" });

  const title = window.document.querySelector(".title");
  title.getBoundingClientRect = () => ({ left: 20, top: 30, right: 140, bottom: 70, width: 120, height: 40 });
  title.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true }));

  assert.equal(inferenceCount, 0);
  assert.equal(sent[0].selection.scopeProposal, null);
  assert.deepEqual(JSON.parse(JSON.stringify(window.Site2JsonPageHighlighter.snapshot())), []);
  dom.window.close();
});

test("dismissing picker chrome preserves the selected element for editor bridge operations", () => {
  const dom = new JSDOM("<!doctype html><html><body><button>Save</button></body></html>", {
    url: "https://example.test/editor", runScripts: "outside-only", pretendToBeVisual: true
  });
  const { window } = dom;
  const runtimeListeners = [];
  window.chrome = { runtime: {
    onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
    sendMessage: async () => {}
  } };
  window.eval(selectorScript);
  window.eval(scopeScript);
  window.eval(highlighterScript);
  window.eval(pickerScript);
  runtimeListeners[0]({ type: "site2json-picker:start", mode: "new-field" });
  const button = window.document.querySelector("button");
  button.getBoundingClientRect = () => ({ left: 20, top: 30, right: 140, bottom: 70, width: 120, height: 40 });
  button.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true }));
  runtimeListeners[0]({ type: "site2json-picker:dismiss" });

  assert.equal(window.document.querySelector("site2json-picker-ui"), null);
  assert.equal(window.__site2jsonSelectedElement, button);
  dom.window.close();
});

test("Visual Evidence ambiguity choices support keyboard navigation and Escape cancellation", () => {
  const dom = new JSDOM("<!doctype html><html><body><a href='/job'>Visible job</a></body></html>", {
    url: "https://example.test/jobs", runScripts: "outside-only", pretendToBeVisual: true
  });
  const { window } = dom;
  const runtimeListeners = [];
  const sent = [];
  window.chrome = { runtime: {
    onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
    sendMessage: async (message) => { sent.push(message); }
  } };
  window.eval(selectorScript); window.eval(scopeScript); window.eval(highlighterScript); window.eval(pickerScript);
  runtimeListeners[0]({ type: "site2json-picker:start", mode: "visual-evidence" });
  const anchor = window.document.querySelector("a");
  anchor.getBoundingClientRect = () => ({ left: 20, top: 30, right: 140, bottom: 70, width: 120, height: 40 });
  anchor.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true, clientX: 30, clientY: 40 }));
  const menu = window.document.querySelector("site2json-picker-ui").shadowRoot.querySelector(".menu");
  assert.equal(menu.style.display, "block");
  assert.deepEqual([...menu.querySelectorAll("button")].map((button) => button.textContent), ["Visible text", "Link URL"]);
  menu.dispatchEvent(new window.KeyboardEvent("keydown", { key: "End", bubbles: true, cancelable: true }));
  assert.equal(menu.shadowRoot?.activeElement || menu.getRootNode().activeElement, menu.querySelectorAll("button")[1]);
  menu.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true }));
  assert.equal(window.document.querySelector("site2json-picker-ui"), null);
  assert.equal(sent.at(-1).type, "site2json-picker:cancelled");
  dom.window.close();
});
