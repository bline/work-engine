"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");

const {
  SCHEMA_THING,
  buildEvidence,
  derive,
  normalizeOverlay
} = require("../extension/ir/v2-review-surface");

function sampleTree() {
  return {
    format: "site2json-s2j-markup",
    root: {
      id: "root",
      kind: "root",
      children: [{
        id: "listing:1",
        kind: "entity",
        term: "https://schema.org/Product",
        children: [{
          id: "listing:1:title",
          kind: "value",
          term: "https://schema.org/name",
          role: "title",
          value: "Acme widget"
        }, {
          id: "listing:1:url",
          kind: "value",
          term: "https://schema.org/url",
          role: "url",
          value: "https://example.test/products/acme-widget"
        }]
      }]
    }
  };
}

const sampleFindings = [
  { nodeId: "listing:1:title", role: "title", status: "assigned", term: "https://schema.org/name" },
  { nodeId: "listing:1:url", role: "url", status: "assigned", term: "https://schema.org/url" }
];

const sampleReports = [
  { entityId: "listing:1", selected: "https://schema.org/Product", accepted: true, status: "accepted" }
];

function sampleOutput() {
  return {
    data: {
      "@context": "https://schema.org",
      "@graph": [{ "@type": "Product", name: "Acme widget", url: "https://example.test/products/acme-widget" }]
    },
    compact: {
      entities: [{ type: "Product", name: "Acme widget", url: "https://example.test/products/acme-widget" }]
    }
  };
}

test("buildEvidence produces deeply frozen V2 review-surface objects", () => {
  const evidence = buildEvidence({
    tree: sampleTree(),
    findings: sampleFindings,
    reports: sampleReports,
    output: sampleOutput()
  });

  assert.equal(Object.isFrozen(evidence), true);
  assert.equal(Object.isFrozen(evidence.tree), true);
  assert.equal(Object.isFrozen(evidence.tree.root), true);
  assert.equal(Object.isFrozen(evidence.findings), true);
  assert.equal(Object.isFrozen(evidence.findings[0]), true);
  assert.equal(Object.isFrozen(evidence.reports), true);
  assert.equal(Object.isFrozen(evidence.reports[0]), true);
  assert.throws(() => { evidence.reports[0].status = "rejected"; }, TypeError);
});

test("normalizeOverlay indexes findings and reports by stable V2 node IDs", () => {
  const overlay = normalizeOverlay({
    findingDecisions: {
      "listing:1:title": { status: "unresolved" }
    },
    fieldDecisions: [
      { nodeId: "listing:1:url", status: "assigned", selectedTerm: "https://schema.org/url" }
    ],
    typeDecisions: {
      "listing:1": { status: "accepted", selected: "https://schema.org/Thing" }
    },
    reports: [
      { entityId: "listing:2", selected: "https://schema.org/Offer", accepted: true, status: "accepted" }
    ]
  });

  assert.equal(overlay.findings["listing:1:title"].status, "unresolved");
  assert.equal(overlay.findings["listing:1:url"].status, "assigned");
  assert.equal(overlay.findings["listing:1:url"].term, "https://schema.org/url");
  assert.equal(overlay.reports["listing:1"].selected, SCHEMA_THING);
  assert.equal(overlay.reports["listing:1"].accepted, false);
  assert.equal(overlay.reports["listing:2"].selected, "https://schema.org/Offer");
});

test("derive applies stable-ID overlay decisions to effective findings and JSON-LD output", () => {
  const evidence = buildEvidence({
    tree: sampleTree(),
    findings: sampleFindings,
    reports: sampleReports,
    output: sampleOutput(),
    grouping: { id: "manual", kind: "collection", score: 1, axes: {}, sources: [] }
  });

  const derived = derive(evidence, {
    findings: [{ nodeId: "listing:1:title", status: "assigned", term: "https://schema.org/description" }],
    reports: [{ entityId: "listing:1", status: "accepted", selected: "https://schema.org/Offer" }]
  });

  const entity = derived.output.data?.["@graph"]?.[0] || {};
  assert.equal(entity["@type"], "Offer");
  assert.equal(entity["description"], "Acme widget");
  assert.equal(entity["name"], undefined);
  assert.equal(derived.findings[0].term, "https://schema.org/description");
  assert.equal(derived.reports[0].accepted, true);
  assert.equal(derived.output.compact?.entities?.[0]?.type, "Offer");
  assert.equal(derived.output.compact?.entities?.[0]?.description, "Acme widget");
  assert.equal(derived.validation.ok, true);
});

test("derive keeps tree assignments and serialized output aligned after overlay edits", () => {
  const evidence = buildEvidence({
    tree: sampleTree(),
    findings: sampleFindings,
    reports: sampleReports,
    output: sampleOutput()
  });

  const derived = derive(evidence, {
    findings: [{ nodeId: "listing:1:title", status: "unresolved" }],
    reports: [{ entityId: "listing:1", status: "accepted", selected: "https://schema.org/Offer" }]
  });

  const [entity] = derived.tree.root.children;
  const [titleValue, urlValue] = entity.children;
  const entityRecord = derived.output.data?.["@graph"]?.[0] || {};

  assert.equal(titleValue.assignment?.stage, "review-overlay");
  assert.equal(titleValue.assignment?.decision, "unresolved");
  assert.equal(titleValue.term, undefined);
  assert.equal(entity.assignment?.stage, "review-overlay");
  assert.equal(entity.assignment?.decision, "type");
  assert.equal(entity.assignment?.entityType, "https://schema.org/Offer");
  assert.equal(entity.term, "https://schema.org/Offer");
  assert.equal(urlValue.assignment?.stage, undefined);
  assert.equal(entityRecord["@type"], "Offer");
  assert.equal(derived.output.compact?.entities?.[0]?.type, "Offer");
  assert.equal(derived.findings.find((finding) => finding.nodeId === "listing:1:title").status, "unresolved");
  assert.equal(derived.output.compact?.entities?.[0]?.url, "https://example.test/products/acme-widget");
});

test("derive ignores overlay entries for missing V2 node IDs", () => {
  const evidence = buildEvidence({
    tree: sampleTree(),
    findings: sampleFindings,
    reports: sampleReports,
    output: sampleOutput()
  });

  const derived = derive(evidence, {
    findings: [{ nodeId: "listing:9:missing", status: "assigned", term: "https://schema.org/title" }],
    reports: [{ entityId: "listing:99", status: "accepted", selected: "https://schema.org/Thing" }]
  });

  const outputEntity = derived.output.data?.["@graph"]?.[0] || {};
  const [titleFinding, urlFinding] = derived.findings;

  assert.equal(derived.reports[0].selected, "https://schema.org/Product");
  assert.equal(outputEntity["@type"], "Product");
  assert.equal(titleFinding.term, "https://schema.org/name");
  assert.equal(urlFinding.term, "https://schema.org/url");
  assert.equal(derived.output.compact?.entities?.[0]?.type, "Product");
});

test("derive keeps a rejected type decision out of the serialized output", () => {
  const evidence = buildEvidence({
    tree: sampleTree(),
    findings: sampleFindings,
    reports: sampleReports,
    output: sampleOutput()
  });

  const derived = derive(evidence, {
    reports: [{ entityId: "listing:1", accepted: false, selected: "https://schema.org/Offer" }]
  });

  assert.equal(derived.reports[0].accepted, false);
  assert.equal(derived.reports[0].status, "unresolved");
  assert.equal(derived.reports[0].selected, SCHEMA_THING);
  const entity = derived.output.data?.["@graph"]?.[0] || {};
  assert.equal(entity["@type"], "Thing", "a rejected type must not leak into the serialized output");
  assert.equal(derived.output.compact?.entities?.[0]?.type, "Thing");
});

test("normalizeReportDecision and normalizeFindingDecision treat 'rejected' as unresolved, not accepted", () => {
  const rejectedReport = require("../extension/ir/v2-review-surface").normalizeReportDecision({
    entityId: "e1", status: "rejected", selected: "https://schema.org/SomeType"
  });
  assert.equal(rejectedReport.accepted, false);
  assert.equal(rejectedReport.selected, SCHEMA_THING);

  const rejectedFindingWithTerm = require("../extension/ir/v2-review-surface").normalizeFindingDecision({
    nodeId: "x", status: "rejected", term: "https://schema.org/name"
  });
  assert.equal(rejectedFindingWithTerm.status, "unresolved");
  assert.equal(rejectedFindingWithTerm.term, undefined);

  const rejectedFindingWithoutTerm = require("../extension/ir/v2-review-surface").normalizeFindingDecision({
    nodeId: "x", status: "rejected"
  });
  assert.ok(rejectedFindingWithoutTerm, "a bare rejection must still register as a decision, not be silently dropped");
  assert.equal(rejectedFindingWithoutTerm.status, "unresolved");
});

test("derive treats Thing only as unresolved fallback", () => {
  const evidence = buildEvidence({
    tree: sampleTree(),
    findings: sampleFindings,
    reports: sampleReports,
    output: sampleOutput()
  });

  const derived = derive(evidence, {
    reports: [{ entityId: "listing:1", status: "accepted", selected: SCHEMA_THING, accepted: true }]
  });

  const entity = derived.output.data?.["@graph"]?.[0] || {};
  assert.equal(entity["@type"], "Thing");
  assert.equal(derived.reports[0].selected, SCHEMA_THING);
  assert.equal(derived.reports[0].accepted, false);
});
