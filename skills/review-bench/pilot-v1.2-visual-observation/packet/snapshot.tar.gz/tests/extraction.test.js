"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Exporters = require("../extension/core/exporters");
const Session = require("../extension/core/session");

const root = path.resolve(__dirname, "..");
const scripts = [
  path.join(root, "extension/core/utils.js"),
  path.join(root, "extension/core/model.js"),
  path.join(root, "reference-adapters/upwork.js")
].map((file) => fs.readFileSync(file, "utf8"));
const fixture = fs.readFileSync(path.join(__dirname, "fixtures", "upwork-search-results.html"), "utf8");
const detailFixture = fs.readFileSync(path.join(__dirname, "fixtures", "upwork-job-detail.html"), "utf8");
const panelFixture = fs.readFileSync(path.join(__dirname, "fixtures", "upwork-job-panel.html"), "utf8");

function runExtraction(html = fixture, url = "https://www.upwork.com/nx/search/jobs/?q=python") {
  const dom = new JSDOM(html, { url, runScripts: "outside-only" });
  for (const script of scripts) dom.window.eval(script);
  try {
    return dom.window.Site2JsonModel.extract([dom.window.Site2JsonAdapters.Upwork], dom.window.document, dom.window.location);
  } catch (error) {
    return { ok: false, reason: "extraction-error", message: error.message };
  }
}

test("extracts Upwork cards through the generic block model", () => {
  const result = runExtraction();
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.adapter, "upwork");
  assert.equal(result.document.extraction.pageType, "SearchResultsPage");
  assert.equal(result.document.context.upwork, "https://site2json.dev/ns/upwork#");
  assert.equal(result.document.extraction.logicalPosition, 1);
  assert.equal(result.document.extraction.quality.requiredFieldCoverage, 1);
  assert.deepEqual({ ...result.document.extraction.blocks[0] }, {
    id: "search-results",
    entity: "JobPosting",
    role: "collection",
    arity: "many",
    fidelity: "summary",
    count: 2
  });

  const [hourly, fixed] = result.document.blocks[0].entities;
  assert.equal(hourly["@type"], "JobPosting");
  assert.equal(hourly.identifier, "0123456789");
  assert.equal(hourly.url, "https://www.upwork.com/jobs/~0123456789abcdef");
  assert.deepEqual({ ...hourly["upwork:budget"] }, {
    type: "hourly", minimum: 30, maximum: 50, amount: null, currency: "USD", raw_text: "Hourly: $30.00-$50.00/hr"
  });
  assert.deepEqual([...hourly.skills], ["Python", "pandas"]);
  assert.equal(hourly["upwork:client"].location, "United States");
  assert.equal(fixed["upwork:budget"].amount, 150);
});

test("normalizes collection identity while retaining logical page position", () => {
  const first = runExtraction(fixture, "https://www.upwork.com/nx/search/jobs/?q=python&sort=recency");
  const third = runExtraction(fixture, "https://www.upwork.com/nx/search/jobs/?sort=recency&page=3&q=python&from_recent_search=true");
  assert.equal(first.document.extraction.collectionKey, third.document.extraction.collectionKey);
  assert.notEqual(first.document.extraction.snapshotKey, third.document.extraction.snapshotKey);
  assert.equal(third.document.extraction.logicalPosition, 3);
});

test("returns an explicit unsupported result when no adapter matches", () => {
  const result = runExtraction(fixture, "https://example.com/jobs");
  assert.deepEqual({ ...result }, { ok: false, reason: "unsupported" });
});

test("keeps identifiable partial entities and reports field-level warnings", () => {
  const html = `<!doctype html><title>Results</title><article data-test="JobTile"><h2><a href="/jobs/~0partial">Small Python task</a></h2></article>`;
  const result = runExtraction(html, "https://www.upwork.com/nx/search/jobs/");
  assert.equal(result.ok, true);
  assert.equal(result.document.blocks[0].entities.length, 1);
  assert.equal(result.document.blocks[0].entities[0]["site2json:warnings"], undefined);
  assert.equal(result.document.extraction.quality.complete, true);
  assert.equal(result.document.extraction.quality.requiredFieldCoverage, 1);
  assert.equal(result.document.extraction.quality.monitoredFieldCoverage, 0);
  const missing = Array.from(result.document.extraction.warnings, (warning) => warning.field);
  assert.ok(missing.includes("description"));
  assert.ok(missing.includes("upwork:postedText"));
  assert.ok(missing.includes("upwork:budget"));
});

test("deduplicates repeated rendered cards by stable identity", () => {
  const repeated = fixture.replace("</main>", `${fixture.match(/<article data-test="JobTile">[\s\S]*?<\/article>/)[0]}</main>`);
  const result = runExtraction(repeated);
  assert.equal(result.document.blocks[0].entities.length, 2);
  assert.equal(result.document.extraction.warnings.filter((warning) => warning.code === "entity.duplicate").length, 1);
});

test("extracts an Upwork detail page as one full primary entity", () => {
  const result = runExtraction(detailFixture, "https://www.upwork.com/jobs/~0123456789abcdef/?source=search");
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.pageType, "ItemPage");
  assert.equal(result.document.extraction.collectionKey, null);
  assert.equal(result.document.extraction.logicalPosition, null);
  assert.equal(result.document.extraction.quality.requiredFieldCoverage, 1);
  assert.equal(result.document.extraction.quality.monitoredFieldCoverage, 1);
  assert.deepEqual({ ...result.document.extraction.blocks[0] }, {
    id: "job-detail",
    entity: "JobPosting",
    role: "primary",
    arity: "one",
    fidelity: "full",
    count: 1
  });
  const entity = result.document.blocks[0].entities[0];
  assert.equal(entity.url, "https://www.upwork.com/jobs/~0123456789abcdef");
  assert.match(entity.description, /production-ready Python pipeline/);
  assert.deepEqual([...entity.skills], ["Python", "pandas", "Data Cleaning"]);
  assert.equal(entity["upwork:budget"].minimum, 35);
  assert.equal(entity["upwork:connectCost"], 8);

  const exported = Exporters.jsonLd(result.document);
  assert.equal(exported.graph["@type"], "ItemPage");
  assert.equal(exported.graph.mainEntity["@id"], entity["@id"]);
});

test("recognizes the alternate nx detail route", () => {
  const result = runExtraction(detailFixture, "https://www.upwork.com/nx/jobs/~0123456789abcdef");
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.pageType, "ItemPage");
  assert.equal(result.document.blocks[0].entities[0].url, "https://www.upwork.com/nx/jobs/~0123456789abcdef");
});

test("extracts the captured routed job panel as a full primary entity", () => {
  const result = runExtraction(panelFixture, "https://www.upwork.com/nx/search/jobs/details/~012345678901234567890?q=design");
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.pageType, "ItemPage");
  assert.equal(result.document.extraction.page.presentation, "overlay");
  assert.equal(result.document.extraction.collectionKey, null);
  assert.equal(result.document.extraction.quality.requiredFieldCoverage, 1);
  assert.equal(result.document.extraction.blocks[0].id, "job-detail-panel");
  assert.equal(result.document.extraction.blocks[0].role, "primary");
  assert.equal(result.document.extraction.blocks[0].fidelity, "full");

  const entity = result.document.blocks[0].entities[0];
  assert.equal(entity.identifier, "012345678901234567890");
  assert.equal(entity.url, "https://www.upwork.com/jobs/~012345678901234567890");
  assert.equal(entity.title, "Design two documents for a product launch");
  assert.match(entity.description, /A client is launching a new product/);
  assert.equal(entity["upwork:postedText"], "Posted 3 weeks ago");
  assert.equal(entity["upwork:budget"].type, "hourly");
  assert.equal(entity["upwork:experienceLevel"], "Intermediate");
  assert.equal(entity["upwork:duration"], "Less than 1 month");
  assert.equal(entity["upwork:weeklyHours"], "Less than 30 hrs/week");
  assert.ok(entity.skills.includes("Graphic Design"));
  assert.equal(entity["upwork:client"].payment_verified, false);
  assert.equal(entity["upwork:client"].location, "Example Country");
  assert.equal(entity["upwork:activity"].proposal_count_text, "5 to 10");
  assert.equal(entity["upwork:activity"].interviewing, 1);
  assert.equal(entity["upwork:activity"].invites_sent, 1);
  assert.equal(entity["upwork:connectCost"], 6);
});

test("a visible job panel takes precedence even if the browser retains the search URL", () => {
  const result = runExtraction(panelFixture, "https://www.upwork.com/nx/search/jobs/?q=design");
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.pageType, "ItemPage");
  assert.equal(result.document.extraction.blocks[0].id, "job-detail-panel");
});

test("standalone extraction recognizes the shared captured job-details component", () => {
  const captured = new JSDOM(panelFixture);
  const component = captured.window.document.querySelector(".job-details-content").outerHTML;
  const result = runExtraction(`<!doctype html><main>${component}</main>`, "https://www.upwork.com/jobs/~012345678901234567890");
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.pageType, "ItemPage");
  assert.equal(result.document.extraction.blocks[0].id, "job-detail");
  assert.equal(result.document.blocks[0].entities[0].title, "Design two documents for a product launch");
  assert.match(result.document.blocks[0].entities[0].description, /A client is launching a new product/);
});

test("standalone extraction fails visibly when the job component is absent", () => {
  const result = runExtraction("<!doctype html><main><h1>Unscoped page heading</h1></main>", "https://www.upwork.com/jobs/~012345678901234567890");
  assert.equal(result.ok, false);
  assert.equal(result.reason, "extraction-error");
  assert.match(result.message, /detail region could not be located/i);
});

test("a matching detail page upgrades its search summary without adding an entity", () => {
  const search = runExtraction(fixture, "https://www.upwork.com/nx/search/jobs/?q=python").document;
  const detail = runExtraction(detailFixture, "https://www.upwork.com/jobs/~0123456789abcdef").document;
  assert.equal(Session.sameCollection(Session.create(search), detail), true);

  let session = Session.create(search);
  session = Session.addDocument(session, detail);
  const merged = Session.merge(session);
  assert.equal(merged.length, 2);
  const upgraded = merged.find((entity) => entity.identifier === "0123456789");
  assert.match(upgraded.description, /production-ready Python pipeline/);
  assert.equal(upgraded["upwork:budget"].minimum, 35);
  assert.deepEqual(upgraded.skills, ["Python", "pandas", "Data Cleaning"]);
  assert.deepEqual(upgraded["site2json:observations"].map((observation) => observation.fidelity), ["summary", "full"]);
});

test("an unrelated detail page cannot contaminate a search session", () => {
  const search = runExtraction(fixture, "https://www.upwork.com/nx/search/jobs/?q=python").document;
  const unrelated = runExtraction(detailFixture, "https://www.upwork.com/jobs/~9999999999unrelated").document;
  const session = Session.create(search);
  assert.equal(Session.sameCollection(session, unrelated), false);
  assert.throws(() => Session.addDocument(session, unrelated), /different collection/);
});
