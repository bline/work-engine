"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Transforms = require("../extension/core/transforms");

test("the minimum transform registry exposes stable named capabilities", () => {
  assert.deepEqual(Transforms.capabilities(), [
    "absoluteUrl", "afterLastLiteral", "afterOptionalLastLiteral", "arraySlice", "base64UrlDecode", "beforeOptionalFirstLiteral", "canonicalUrlForTemplates", "collapseWhitespace",
    "float", "int", "joinLiteral", "leadingDigits", "lowercase", "mapValues", "parseEnglishDateV1", "parseMoneyV1", "parsePercentV1",
    "parseProjectBudgetV1", "parseRatingV1", "pathSegmentPositiveInteger", "pathSegmentValue", "pathSegmentValues",
    "pathSnapshotKey", "pathUnknownSegments", "pathWithoutSegmentPairs", "prefixLiteral", "removeOptionalPrefixLiteral",
    "removePrefixLiteral", "requireIncludesLiteral", "requirePathPrefix", "stripLeadingLabel", "stripQuery", "text", "textSlice", "trim", "urlLastPathSegment",
    "urlQueryCollectionKey", "urlQueryFirst", "urlQueryParameters", "urlQueryPositiveInteger", "urlQuerySnapshotKey",
    "urlQuerySorted"
  ]);
  assert.equal(Transforms.has("text"), true);
  assert.equal(Transforms.has("adapterJavaScript"), false);
  const details = Transforms.capabilityDetails();
  assert.equal(details.length, Transforms.capabilities().length);
  assert.ok(details.every((item) => item.category && item.label && item.description && item.input && item.output && Array.isArray(item.keywords) && Array.isArray(item.argumentDefinitions)));
  assert.deepEqual(details.find((item) => item.name === "joinLiteral"), {
    name: "joinLiteral", minimumArguments: 1, maximumArguments: 1,
    category: "Collections", label: "Join with delimiter",
    description: "Join string array values using a configured delimiter.",
    input: "array", output: "text", keywords: ["combine", "concatenate", "separator"],
    argumentDefinitions: [{
      name: "delimiter", label: "Delimiter", type: "string", description: "Text inserted between values.", maximumLength: 32
    }]
  });
  assert.deepEqual(Transforms.requiredCapabilities([
    ["text", "trim"],
    ["absoluteUrl", "stripQuery", "trim"]
  ]), ["absoluteUrl", "stripQuery", "text", "trim"]);
});

test("transform pipelines normalize rendered text and URLs", () => {
  const dom = new JSDOM("<p>  Hello\n  world </p>");
  const paragraph = dom.window.document.querySelector("p");
  assert.equal(Transforms.runPipeline(paragraph, ["text", "collapseWhitespace"]), "Hello world");
  assert.equal(Transforms.runPipeline(" /jobs/1?source=test#top ", ["trim", "absoluteUrl", "stripQuery"], {
    pageUrl: "https://www.example.com/search"
  }), "https://www.example.com/jobs/1#top");
  dom.window.close();
});

test("pipelines propagate null and reject unknown or malformed operations", () => {
  assert.equal(Transforms.runPipeline(null, ["text", "trim"]), null);
  assert.equal(Transforms.runPipeline("not a url", ["stripQuery"]), null);
  assert.throws(() => Transforms.validatePipeline(["executeJavaScript"]), /requires transform executeJavaScript, which is not available/i);
  assert.throws(() => Transforms.validatePipeline([{ name: "trim", args: [true] }]), /received 1 arguments; expected 0/i);
  assert.throws(() => Transforms.validatePipeline([{ name: "trim", code: "return value" }]), /unknown transform step key: code/i);
  assert.throws(() => Transforms.validatePipeline([{ name: "urlQueryFirst", args: ["q"] }]), /received invalid arguments/i);
});

test("packaged URL-query transforms produce deterministic session metadata", () => {
  const url = "https://www.upwork.com/nx/search/jobs/?sort=recency&page=3&q=python&from_recent_search=true";
  const excluded = ["from_recent_search", "page", "per_page"];
  assert.equal(Transforms.runPipeline(url, [{ name: "urlQueryCollectionKey", args: ["upwork:jobs:", excluded] }]), "upwork:jobs:q=python&sort=recency");
  assert.equal(Transforms.runPipeline(url, [{ name: "urlQuerySnapshotKey", args: ["upwork:jobs:", excluded, "page", 1] }]), "upwork:jobs:q=python&sort=recency:page:3");
  assert.equal(Transforms.runPipeline(url, [{ name: "urlQueryPositiveInteger", args: ["page", 1] }]), 3);
});

test("the reviewed project-budget transform covers equivalent Upwork and Guru presentations", () => {
  assert.deepEqual(Transforms.runPipeline("Hourly: $30.00-$50.00/hr", ["parseProjectBudgetV1"]), {
    type: "hourly", minimum: 30, maximum: 50, amount: null, currency: "USD", raw_text: "Hourly: $30.00-$50.00/hr"
  });
  assert.deepEqual(Transforms.runPipeline("Fixed-price — Est. Budget: $150.00", ["parseProjectBudgetV1"]), {
    type: "fixed", minimum: null, maximum: null, amount: 150, currency: "USD", raw_text: "Est. Budget: $150.00"
  });
  assert.deepEqual(Transforms.runPipeline("Fixed Price | $500-$1k", ["parseProjectBudgetV1"]), {
    type: "fixed", minimum: 500, maximum: 1000, amount: null, currency: "USD", raw_text: "Fixed Price | $500-$1k"
  });
  assert.deepEqual(Transforms.runPipeline("Fixed Price or Hourly", ["parseProjectBudgetV1"]), {
    type: "fixed_or_hourly", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: "Fixed Price or Hourly"
  });
  assert.deepEqual(Transforms.runPipeline("Fixed Price", ["parseProjectBudgetV1"]), {
    type: "fixed", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: "Fixed Price"
  });
  assert.deepEqual(Transforms.runPipeline("Fixed-Price", ["parseProjectBudgetV1"]), {
    type: "fixed", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: "Fixed Price"
  });
});

test("canonical URL templates are bounded structural matching, not adapter-supplied regex", () => {
  const step = { name: "canonicalUrlForTemplates", args: [["www.upwork.com"], ["/jobs/~{segment}", "/nx/jobs/~{segment}"]] };
  assert.equal(Transforms.runPipeline("https://www.upwork.com/jobs/~0123/", [step]), "https://www.upwork.com/jobs/~0123");
  assert.equal(Transforms.runPipeline("https://www.upwork.com/nx/search/jobs/", [step]), null);
  assert.equal(Transforms.runPipeline("https://example.com/jobs/~0123", [step]), null);
});

test("literal transforms recover identifiers from canonical and slugged job paths", () => {
  assert.equal(Transforms.runPipeline("~0123", [{ name: "afterLastLiteral", args: ["~"] }]), "0123");
  assert.equal(Transforms.runPipeline("descriptive-slug_~0456", [{ name: "requireIncludesLiteral", args: ["~"] }, { name: "afterLastLiteral", args: ["~"] }]), "0456");
  assert.equal(Transforms.runPipeline("search", [{ name: "requireIncludesLiteral", args: ["~"] }]), null);
});

test("optional literal slicing isolates combined duration presentations without patterns", () => {
  const combined = "1 to 3 months, Less than 30 hrs/week";
  assert.equal(Transforms.runPipeline(combined, [{ name: "beforeOptionalFirstLiteral", args: [","] }, "trim"]), "1 to 3 months");
  assert.equal(Transforms.runPipeline(combined, [{ name: "afterOptionalLastLiteral", args: [","] }, "trim"]), "Less than 30 hrs/week");
  assert.equal(Transforms.runPipeline("More than 6 months", [{ name: "beforeOptionalFirstLiteral", args: [","] }]), "More than 6 months");
});

test("bounded text slicing supports fixed-width formats without exposing patterns", () => {
  assert.equal(Transforms.runPipeline("ID: 001234", [{ name: "textSlice", args: [4] }]), "001234");
  assert.equal(Transforms.runPipeline("abcdef", [{ name: "textSlice", args: [-3, -1] }]), "de");
  assert.throws(() => Transforms.validatePipeline([{ name: "textSlice", args: [100_001] }]), /invalid arguments/i);
});

test("encoded keyed routes are decoded and projected with fixed structural transforms", () => {
  const route = "/d/jobs/c/programming-development/skill/python/skill/automation/maxquotes/50/pg/2/";
  const encoded = btoa(route);
  assert.equal(Transforms.runPipeline(encoded, ["base64UrlDecode", { name: "requirePathPrefix", args: [["d", "jobs"]] }]), route);
  assert.deepEqual(Transforms.runPipeline(route, [{ name: "pathSegmentValues", args: ["skill"] }]), ["python", "automation"]);
  assert.equal(Transforms.runPipeline(route, [{ name: "pathSegmentPositiveInteger", args: ["pg", 1] }]), 2);
  assert.equal(Transforms.runPipeline(route, [{ name: "pathWithoutSegmentPairs", args: [["pg"]] }]), "/d/jobs/c/programming-development/skill/python/skill/automation/maxquotes/50/");
  assert.equal(Transforms.runPipeline(route, [{ name: "pathSnapshotKey", args: ["guru:jobs:", ["pg"], "pg", 1] }]), "guru:jobs:/d/jobs/c/programming-development/skill/python/skill/automation/maxquotes/50/:page:2");
  assert.deepEqual(Transforms.runPipeline(`${route}unexpected/value/`, [{ name: "pathUnknownSegments", args: [["c", "skill", "maxquotes", "pg"], ["d", "jobs"]] }]), ["unexpected", "value"]);
});

test("generic scalar and aggregate transforms cover marketplace-neutral values", () => {
  assert.equal(Transforms.runPipeline("$12.5k spent", ["parseMoneyV1"]), 12500);
  assert.equal(Transforms.runPipeline("98% positive", ["parsePercentV1"]), 98);
  assert.equal(Transforms.runPipeline(["heading", "summary", "employer"], [{ name: "joinLiteral", args: [" "] }]), "heading summary employer");
});

test("absolute English dates are found inside rendered labels and normalized to ISO dates", () => {
  assert.equal(Transforms.runPipeline("Posted on Dec 30, 2025 · 90 Quotes", ["text", "parseEnglishDateV1"]), "2025-12-30");
  assert.equal(Transforms.runPipeline("Posted Dec. 30th, 2025", ["parseEnglishDateV1"]), "2025-12-30");
  assert.equal(Transforms.runPipeline("Closes 2 January 2026", ["parseEnglishDateV1"]), "2026-01-02");
  assert.equal(Transforms.runPipeline("Published 2026-08-09 at noon", ["parseEnglishDateV1"]), "2026-08-09");
  assert.equal(Transforms.runPipeline("Posted on Feb 30, 2025", ["parseEnglishDateV1"]), null);
  assert.equal(Transforms.runPipeline("Posted yesterday", ["parseEnglishDateV1"]), null);
});
