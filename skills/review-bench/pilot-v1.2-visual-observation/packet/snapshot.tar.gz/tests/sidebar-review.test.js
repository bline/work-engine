"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const SidebarReview = require("../extension/editor/sidebar-review");

const html = fs.readFileSync(path.resolve(__dirname, "../extension/editor/sidebar.html"), "utf8");

test("inline Review renders structural findings with page preview and repair actions", () => {
  const dom = new JSDOM(html);
  const calls = [];
  const review = SidebarReview.create({
    document: dom.window.document,
    onActivate() {}, onPreview: (target) => calls.push(["preview", target]), onClearPreview: () => calls.push(["clear"]),
    onPin() {}, onReveal() {}, onEdit() {}, onRemove() {}, onAdd() {},
    onCheckDrift: () => calls.push(["check"]), onOpenFinding: (finding) => calls.push(["open", finding])
  });
  const finding = {
    severity: "error", title: "Jobs · canonical URL", message: "Selector coverage fell from 100% to 0%.",
    target: { withinSelector: ".job", selector: ".link" }, fieldKey: "identity"
  };
  review.renderDrift({ status: "ready", message: "1 structural finding · 1 error.", findings: [finding] }, true);
  const document = dom.window.document;
  assert.equal(document.querySelector("#structural-findings-section").hidden, false);
  assert.match(document.querySelector("#structural-findings-summary").textContent, /1 structural finding/);
  const row = document.querySelector(".structural-finding");
  row.dispatchEvent(new dom.window.MouseEvent("mouseenter"));
  row.dispatchEvent(new dom.window.MouseEvent("mouseleave"));
  row.click();
  document.querySelector("#check-structural-health-button").click();
  assert.deepEqual(calls, [["preview", finding.target], ["clear"], ["open", finding], ["check"]]);
  review.renderDrift({ status: "unavailable", message: "No structural baseline is saved for this page.", findings: [] }, false);
  assert.equal(document.querySelector("#structural-findings-section").hidden, false);
  assert.equal(document.querySelector("#check-structural-health-button").disabled, true);
  assert.match(document.querySelector("#structural-findings-summary").textContent, /No structural baseline/);
  dom.window.close();
});
