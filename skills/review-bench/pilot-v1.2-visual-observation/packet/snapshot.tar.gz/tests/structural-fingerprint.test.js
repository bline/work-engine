"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Dsl = require("../extension/core/dsl");
const Model = require("../extension/core/model");
const { bridgeCaptureStructuralBaseline } = require("../extension/editor/sidebar-page-bridge");

function definition() {
  return {
    adapter: "fixture",
    version: 1,
    dslVersion: 1,
    namespace: "https://example.com/fixture#",
    hosts: ["example.com"],
    entities: {
      Listing: {
        schemaType: "Thing",
        identity: { canonicalUrl: { selectors: [".link@href"], transform: ["absoluteUrl", "stripQuery"] } },
        fields: {
          title: { selectors: [".title"], transform: ["text", "trim"] },
          image: { selectors: [".image@src"], transform: ["absoluteUrl", "stripQuery"] }
        }
      }
    },
    pages: [{
      id: "results",
      match: { host: ["example.com"], path: [{ mode: "exact", value: "/results" }] },
      pageType: "CollectionPage",
      blocks: [{
        entity: "Listing", scope: ".result-card", arity: "many", role: "collection", fidelity: "summary",
        require: ["title"], monitor: ["image"]
      }]
    }]
  };
}

function page(cards) {
  return new JSDOM(`<main class="results">${cards.join("")}</main>`, { url: "https://example.com/results", runScripts: "outside-only" });
}

function card(index, { image = true, generatedClass = "css-1ujsas3", titleClass = "title", duplicateTitle = false } = {}) {
  return `<article class="result-card ${generatedClass}">
    <a class="link" href="/item/${index}"><h2 class="${titleClass}">Item ${index}</h2>${duplicateTitle ? `<h2 class="${titleClass}">Duplicate</h2>` : ""}</a>
    ${image ? `<img class="image" src="/image/${index}.png">` : ""}
  </article>`;
}

function withBaseline(sourceDefinition, dom) {
  const captured = Dsl.captureStructuralBaselines(sourceDefinition, dom.window.document, new URL(dom.window.location.href));
  const result = structuredClone(sourceDefinition);
  result.pages[0].blocks[0].structuralBaseline = captured[0];
  return result;
}

test("captures a bounded, text-free baseline with known optional shapes", () => {
  const dom = page([card(1), card(2, { image: false }), card(3)]);
  const baseline = Dsl.captureStructuralBaselines(definition(), dom.window.document, new URL(dom.window.location.href))[0];
  assert.equal(baseline.version, 1);
  assert.deepEqual(baseline.scope, { typical: 3, minimum: 1 });
  assert.equal(baseline.variants.Listing.shapes.length, 2);
  assert.deepEqual(baseline.variants.Listing.fields.image, { coverage: 0.6667, matchesPerItem: [0, 1] });
  assert.match(baseline.variants.Listing.shapes[0].fingerprint, /^s2j1:[a-f0-9]{16}$/);
  assert.doesNotMatch(JSON.stringify(baseline), /Item 1|css-1ujsas3|image\/1/);
  assert.doesNotThrow(() => Dsl.validateDefinition(withBaseline(definition(), dom)));
  dom.window.close();
});

test("the inspected-page bridge captures baselines through the production DSL", () => {
  const dom = page([card(1), card(2)]);
  dom.window.Site2JsonDsl = Dsl;
  const capture = dom.window.eval(`(${bridgeCaptureStructuralBaseline.toString()})`);
  const result = capture({ definition: definition() });
  assert.equal(result.ok, true);
  assert.equal(result.baselines[0].scope.typical, 2);
  dom.window.close();
});

test("keeps structural profiles separate for mixed result variants", () => {
  const mixedDefinition = definition();
  mixedDefinition.entities.PersonResult = structuredClone(mixedDefinition.entities.Listing);
  mixedDefinition.entities.PersonResult.schemaType = "Person";
  mixedDefinition.pages[0].blocks[0].variants = {
    fallback: "Listing",
    candidates: [{ entity: "PersonResult", signals: [], evidence: [{ selector: ":scope", attribute: "data-kind", equals: "person", weight: 10 }] }],
    minScore: 5,
    minMargin: 2
  };
  const dom = page([
    card(1).replace("<article ", '<article data-kind="person" '),
    card(2, { image: false })
  ]);
  const baseline = Dsl.captureStructuralBaselines(mixedDefinition, dom.window.document, new URL(dom.window.location.href))[0];
  assert.deepEqual(Object.keys(baseline.variants).sort(), ["Listing", "PersonResult"]);
  assert.equal(baseline.variants.PersonResult.evidence[0].coverage, 1);
  assert.equal(baseline.variants.Listing.evidence[0].coverage, 0);
  mixedDefinition.pages[0].blocks[0].structuralBaseline = baseline;
  assert.doesNotThrow(() => Dsl.validateDefinition(mixedDefinition));
  dom.window.close();
});

test("reports when a previously observed variant population no longer classifies", () => {
  const mixedDefinition = definition();
  mixedDefinition.entities.PersonResult = structuredClone(mixedDefinition.entities.Listing);
  mixedDefinition.entities.PersonResult.schemaType = "Person";
  mixedDefinition.pages[0].blocks[0].variants = {
    fallback: "Listing",
    candidates: [{ entity: "PersonResult", signals: [], evidence: [{ selector: ":scope", attribute: "data-kind", equals: "person", weight: 10 }] }],
    minScore: 5,
    minMargin: 2
  };
  const baselinePage = page([card(1).replace("<article ", '<article data-kind="person" '), card(2)]);
  mixedDefinition.pages[0].blocks[0].structuralBaseline = Dsl.captureStructuralBaselines(mixedDefinition, baselinePage.window.document, new URL(baselinePage.window.location.href))[0];
  baselinePage.window.close();
  const redesigned = page([card(1), card(2)]);
  const observation = Dsl.compile(mixedDefinition).extract(redesigned.window.document, new URL(redesigned.window.location.href));
  assert.ok(observation.warnings.some((warning) => warning.code === "variant.classificationDrift" && warning.variant === "PersonResult"));
  redesigned.window.close();
});

test("CSS-in-JS hash changes and already-known optional shapes stay quiet", () => {
  const original = page([card(1), card(2, { image: false }), card(3)]);
  const configured = withBaseline(definition(), original);
  const changed = page([
    card(4, { generatedClass: "css-9zz8yy7" }),
    card(5, { image: false, generatedClass: "css-abcd123" })
  ]);
  const observation = Dsl.compile(configured).extract(changed.window.document, new URL(changed.window.location.href));
  assert.deepEqual((observation.warnings || []).filter((warning) => /^(?:scope|shape|field|variant)\./.test(warning.code)), []);
  original.window.close();
  changed.window.close();
});

test("a silently vanished optional selector produces targeted runtime drift warnings", () => {
  const original = page([card(1), card(2, { image: false }), card(3)]);
  const configured = withBaseline(definition(), original);
  const changed = page([card(4, { image: false }), card(5, { image: false }), card(6, { image: false })]);
  const observation = Dsl.compile(configured).extract(changed.window.document, new URL(changed.window.location.href));
  const missing = observation.warnings.find((warning) => warning.code === "field.selectorMissing" && warning.field === "image");
  assert.ok(missing);
  assert.equal(missing.severity, "strong-warning");
  assert.equal(missing.baseline, 0.6667);
  assert.equal(missing.current, 0);
  original.window.close();
  changed.window.close();
});

test("a selected attribute disappearing is treated as selector coverage loss", () => {
  const original = page([card(1), card(2)]);
  const configured = withBaseline(definition(), original);
  const changed = page([
    card(3).replace('src="/image/3.png"', ""),
    card(4).replace('src="/image/4.png"', "")
  ]);
  const findings = Dsl.structuralFindings(configured, configured.pages[0], changed.window.document, new URL(changed.window.location.href));
  assert.ok(findings.some((finding) => finding.code === "field.selectorMissing" && finding.field === "image"));
  original.window.close();
  changed.window.close();
});

test("new dependency shapes and changed selector cardinality are reported", () => {
  const original = page([card(1), card(2), card(3)]);
  const configured = withBaseline(definition(), original);
  const changed = page([card(4, { duplicateTitle: true }), card(5)]);
  const findings = Dsl.structuralFindings(configured, configured.pages[0], changed.window.document, new URL(changed.window.location.href));
  assert.ok(findings.some((finding) => finding.code === "shape.unknown" && finding.count === 1));
  assert.ok(findings.some((finding) => finding.code === "field.cardinalityDrift" && finding.field === "title"));
  original.window.close();
  changed.window.close();
});

test("a vanished block scope survives the empty-result path as an actionable warning", () => {
  const original = page([card(1), card(2)]);
  const configured = withBaseline(definition(), original);
  const empty = page([]);
  const adapter = { ...Dsl.compile(configured), source: "local-file" };
  const result = Model.extract([adapter], empty.window.document, empty.window.location);
  assert.equal(result.ok, false);
  assert.equal(result.reason, "empty");
  assert.ok(result.warnings.some((warning) => warning.code === "scope.noMatches" && warning.severity === "error"));
  original.window.close();
  empty.window.close();
});

test("structural baselines reject executable or unbounded data", () => {
  const dom = page([card(1)]);
  const configured = withBaseline(definition(), dom);
  configured.pages[0].blocks[0].structuralBaseline.script = "inspect(document)";
  assert.throws(() => Dsl.validateDefinition(configured), /Unknown .* key: script/);
  delete configured.pages[0].blocks[0].structuralBaseline.script;
  configured.pages[0].blocks[0].structuralBaseline.variants.Listing.shapes = Array.from({ length: 17 }, (_value, index) => ({ fingerprint: `s2j1:${index.toString(16).padStart(16, "0")}`, frequency: 0 }));
  assert.throws(() => Dsl.validateDefinition(configured), /between 1 and 16 profiles/);
  dom.window.close();
});
