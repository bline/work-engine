"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const SemanticToolbox = require("../extension/core/semantic-toolbox");
const SemanticBundle = require("../extension/core/semantic-bundle");
const SemanticLibrary = require("../extension/core/semantic-library-service");
const SidebarSemanticLibrary = require("../extension/editor/sidebar-semantic-library");

const html = fs.readFileSync(path.resolve(__dirname, "../extension/editor/sidebar.html"), "utf8");
const ARTICLE_PATTERN = {
  id: "pattern:article-author",
  label: "Article author",
  description: "An article and its author.",
  root: "article",
  nodes: {
    article: { types: ["Article"], expectation: "core" },
    author: { types: ["Person"], expectation: "common" }
  },
  edges: [{ from: "article", property: "author", to: "author", expectation: "common" }],
  terms: {}
};
const BUYER_PATTERN = {
  id: "pattern:marketplace-buyer",
  label: "Marketplace buyer",
  description: "A buyer with an aggregate rating.",
  root: "buyer",
  nodes: { buyer: { types: ["Organization"], expectation: "core" } },
  edges: [],
  terms: {}
};
const EDITOR_TYPE = {
  id: "guru:Editor",
  label: "Editor",
  description: "A person responsible for editing a marketplace listing.",
  definition: {
    kind: "type",
    description: "A person responsible for editing a marketplace listing.",
    valueType: "guru:Editor",
    cardinality: "one",
    example: "Editor"
  }
};

async function waitFor(predicate, message) {
  for (let attempt = 0; attempt < 200; attempt += 1) {
    if (await predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  assert.fail(message);
}

async function importedRecord(service, kind, termId) {
  const result = await service.search({ query: termId, kinds: [kind], pageSize: 100 });
  const summary = result.items.find((item) => item.termId === termId);
  if (!summary) return null;
  return kind === "customType" ? service.getCustomType(summary.id) : service.getProperty(summary.id);
}

async function setup({ catalog = null } = {}) {
  const values = {};
  const storage = {
    async get(key) { return { [key]: values[key] }; },
    async set(next) { Object.assign(values, next); }
  };
  const service = SemanticLibrary.createLegacyToolboxService({ toolboxApi: SemanticToolbox, bundleApi: SemanticBundle, storage });
  await service.savePattern({ pattern: ARTICLE_PATTERN });
  await service.savePattern({ pattern: BUYER_PATTERN });
  await service.saveCustomType({ customType: EDITOR_TYPE });
  const employment = await service.saveTag({ tag: { id: "tag:employment", label: "Employment" }, expectedRevision: 0 });
  await service.assignTags({ targets: [{ kind: "pattern", id: ARTICLE_PATTERN.id }], tagIds: [employment.id], mode: "add" });
  const marketplace = await service.saveCollection({
    collection: { id: "collection:marketplace", label: "Marketplace", members: [{ kind: "pattern", id: BUYER_PATTERN.id }] },
    expectedRevision: 0
  });
  const dom = new JSDOM(html, { url: "chrome-extension://test/editor/sidebar.html", runScripts: "outside-only" });
  dom.window.confirm = () => true;
  const manager = SidebarSemanticLibrary.create({ document: dom.window.document, service, bundleApi: SemanticBundle, ...(catalog ? { catalog } : {}) });
  manager.open();
  await waitFor(() => dom.window.document.querySelectorAll("#semantic-library-results .semantic-library-result").length === 3, "library results did not render");
  return { dom, document: dom.window.document, manager, service, employment, marketplace };
}

test("Semantic Library manager searches, filters, and organizes a selected pattern", async () => {
  const { dom, document, service } = await setup();
  assert.equal(document.querySelector("#semantic-library-result-count").textContent, "3");
  assert.match(document.querySelector("#semantic-library-kind-facets").textContent, /Graph bundles 2/);
  assert.match(document.querySelector("#semantic-library-kind-facets").textContent, /Custom types 1/);
  assert.equal(document.querySelector("#semantic-library-tag-facets").textContent.includes("Employment 1"), true);
  assert.equal(document.querySelector("#semantic-library-collection-facets").textContent.includes("Marketplace 1"), true);

  document.querySelector(`[data-id="${ARTICLE_PATTERN.id}"]`).click();
  await waitFor(() => document.querySelector("#semantic-library-detail-name").value === "Article author", "pattern details did not open");
  assert.match(document.querySelector("#semantic-library-assigned-tags").textContent, /Employment/);

  document.querySelector("#semantic-library-tag-input").value = "Favorite";
  document.querySelector("#semantic-library-add-tag").click();
  await waitFor(() => /Favorite/.test(document.querySelector("#semantic-library-assigned-tags").textContent), "new tag was not assigned");

  document.querySelector("#semantic-library-collection-input").value = "Publishing";
  document.querySelector("#semantic-library-add-collection").click();
  await waitFor(() => /Publishing/.test(document.querySelector("#semantic-library-assigned-collections").textContent), "new collection was not assigned");

  document.querySelector("#semantic-library-detail-name").value = "Authored article";
  document.querySelector("#semantic-library-save-pattern").click();
  await waitFor(async () => (await service.getPattern(ARTICLE_PATTERN.id)).label === "Authored article", "pattern rename was not saved");

  const employmentFacet = [...document.querySelectorAll("#semantic-library-tag-facets button")]
    .find((button) => /Employment/.test(button.textContent));
  employmentFacet.click();
  await waitFor(() => document.querySelectorAll("#semantic-library-results .semantic-library-result").length === 1, "tag filter did not reduce results");
  assert.equal(document.querySelector("#semantic-library-results .semantic-library-result").dataset.id, ARTICLE_PATTERN.id);
  dom.window.close();
});

test("Semantic Library edits a reusable property inference profile without exposing it on other records", async () => {
  const { dom, document, manager, service } = await setup();
  await service.saveProperty({
    property: {
      id: "guru:proposalCount", label: "proposal count", description: "The number of proposals received.",
      definition: {
        kind: "relationship", description: "The number of proposals received.", valueType: "Integer",
        domainIncludes: ["JobPosting"], rangeIncludes: ["Integer"]
      }
    },
    expectedRevision: 0
  });
  await manager.refresh();
  document.querySelector('[data-id="guru:proposalCount"]').click();
  await waitFor(() => document.querySelector("#semantic-library-detail-name").value === "proposal count", "property details did not open");
  assert.equal(document.querySelector("#semantic-library-property-profile").hidden, false);
  document.querySelector("#semantic-library-profile-aliases").value = "quotes, bids";
  document.querySelector("#semantic-library-profile-negative-aliases").value = "budget";
  document.querySelector("#semantic-library-profile-shapes").value = "integer";
  document.querySelector("#semantic-library-profile-normalization").value = "text, int";
  document.querySelector("#semantic-library-profile-salience").value = "90";
  document.querySelector("#semantic-library-save-pattern").click();
  await waitFor(async () => (await service.getProperty("guru:proposalCount")).definition.authoringProfile?.salience === 90, "property profile was not saved");
  const saved = await service.getProperty("guru:proposalCount");
  assert.deepEqual(saved.definition.authoringProfile.aliases, ["quotes", "bids"]);
  assert.deepEqual(saved.definition.authoringProfile.normalization, ["text", "int"]);

  document.querySelector(`[data-id="${ARTICLE_PATTERN.id}"]`).click();
  await waitFor(() => document.querySelector("#semantic-library-detail-name").value === "Article author", "pattern details did not reopen");
  assert.equal(document.querySelector("#semantic-library-property-profile").hidden, true);
  dom.window.close();
});

test("Semantic Library keeps import sources adjacent and exports a selection across searches", async () => {
  const { dom, document, manager } = await setup();
  const actionOrder = [...document.querySelectorAll(".semantic-library-heading-actions button")].map((button) => button.textContent);
  assert.deepEqual(actionOrder, ["Import bundle…", "Import vocabulary…", "Import history"]);

  document.querySelector("#semantic-library-select-items").click();
  assert.equal(document.querySelector("#semantic-library-bulk-actions").hidden, false);
  let checkboxes = [...document.querySelectorAll("#semantic-library-results .semantic-library-result-row input")];
  checkboxes[0].click();
  checkboxes[1].click();
  assert.equal(document.querySelector("#semantic-library-selection-count").textContent, "2 selected");

  document.querySelector("#semantic-library-search").value = "Marketplace buyer";
  await manager.refresh();
  checkboxes = [...document.querySelectorAll("#semantic-library-results .semantic-library-result-row input")];
  assert.equal(checkboxes.length, 1);
  checkboxes[0].click();
  assert.equal(document.querySelector("#semantic-library-selection-count").textContent, "3 selected", "selection must persist across result sets");

  let downloaded = null;
  dom.window.URL.createObjectURL = (blob) => { downloaded = { blob }; return "blob:semantic-selection"; };
  dom.window.URL.revokeObjectURL = () => undefined;
  dom.window.HTMLAnchorElement.prototype.click = function click() { downloaded.name = this.download; };
  document.querySelector("#semantic-library-export-selected").click();
  await waitFor(() => downloaded?.name, "selected records were not exported");
  assert.equal(downloaded.name, "3-selected-semantic-records.site2json.json.gz");
  assert.match(document.querySelector("#semantic-library-status").textContent, /Exported 3 selected records/);

  document.querySelector("#semantic-library-clear-selection").click();
  assert.equal(document.querySelector("#semantic-library-selection-count").textContent, "0 selected");
  assert.equal(document.querySelector("#semantic-library-export-selected").disabled, true);
  document.querySelector("#semantic-library-select-items").click();
  assert.equal(document.querySelector("#semantic-library-bulk-actions").hidden, true);
  dom.window.close();
});

test("Semantic Library manager previews a gzip bundle, imports a new package, and exports it", async () => {
  const { dom, document, manager, service } = await setup();
  const bundle = SemanticBundle.create({
    name: "Portable editorial semantics",
    description: "A shared editorial type.",
    createdAt: "2026-08-13T16:00:00.000Z",
    types: [{
      termId: "shared:CopyEditor", label: "Copy editor", description: "An editor who prepares copy.",
      definition: { kind: "type", description: "An editor who prepares copy.", valueType: "shared:CopyEditor", supers: ["Person"] }
    }]
  });
  const compressed = await SemanticBundle.encode(bundle);
  await manager.previewBundleFile({ name: "editorial.site2json.json.gz", async arrayBuffer() { return compressed.buffer; } });
  assert.equal(document.querySelector("#semantic-library-file-import").hidden, false);
  assert.equal(document.querySelector("#semantic-library-local-browser").hidden, true);
  assert.match(document.querySelector("#semantic-library-file-title").textContent, /Portable editorial semantics/);
  assert.match(document.querySelector("#semantic-library-file-meta").textContent, /Types\s*1/);
  assert.match(document.querySelector("#semantic-library-file-status").textContent, /Nothing has been saved/);
  assert.equal((await service.search({ query: "Copy editor" })).total, 0, "preview must not mutate the library");

  document.querySelector("#semantic-library-confirm-file").click();
  await waitFor(async () => (await service.search({ query: "Copy editor" })).total === 1, "portable bundle was not imported");
  const imported = (await service.search({ query: "Copy editor" })).items[0];
  assert.match(imported.id, /^import:/);

  document.querySelector("#semantic-library-search").value = "Copy editor";
  await manager.refresh();
  document.querySelector("#semantic-library-results .semantic-library-result").click();
  await waitFor(() => document.querySelector("#semantic-library-detail-name").value === "Copy editor", "imported bundle detail did not open");
  assert.equal(document.querySelector("#semantic-library-export-bundle").textContent, "Export package");
  let downloaded = null;
  dom.window.URL.createObjectURL = (blob) => { downloaded = { blob }; return "blob:semantic-bundle"; };
  dom.window.URL.revokeObjectURL = () => undefined;
  dom.window.HTMLAnchorElement.prototype.click = function click() { downloaded.name = this.download; };
  document.querySelector("#semantic-library-export-bundle").click();
  await waitFor(() => downloaded?.name, "semantic package download was not created");
  assert.equal(downloaded.name, "portable-editorial-semantics.site2json.json.gz");
  assert.equal(downloaded.blob.type, "application/gzip");
  dom.window.close();
});

test("Semantic Library manager duplicates and deletes patterns through revision-safe service calls", async () => {
  const { dom, document, service } = await setup();
  document.querySelector(`[data-id="${ARTICLE_PATTERN.id}"]`).click();
  await waitFor(() => document.querySelector("#semantic-library-detail-name").value === "Article author", "pattern details did not open");
  document.querySelector("#semantic-library-duplicate-pattern").click();
  await waitFor(async () => (await service.listPatterns({ pageSize: 20 })).total === 3, "pattern was not duplicated");
  await waitFor(() => /copy/.test(document.querySelector("#semantic-library-detail-name").value), "duplicate was not selected");
  document.querySelector("#semantic-library-delete-pattern").click();
  await waitFor(async () => (await service.listPatterns({ pageSize: 20 })).total === 2, "duplicate was not deleted");
  assert.equal(document.querySelector("#semantic-library-detail").hidden, true);
  dom.window.close();
});

test("Semantic Library manager edits, organizes, duplicates, and deletes reusable custom types", async () => {
  const { dom, document, service } = await setup();
  document.querySelector(`[data-id="${EDITOR_TYPE.id}"]`).click();
  await waitFor(() => document.querySelector("#semantic-library-detail-name").value === "Editor", "custom type details did not open");
  assert.equal(document.querySelector("#semantic-library-detail-kind").textContent, "Custom type");
  assert.match(document.querySelector("#semantic-library-detail-meta").textContent, /guru:Editor/);

  document.querySelector("#semantic-library-tag-input").value = "People";
  document.querySelector("#semantic-library-add-tag").click();
  await waitFor(() => /People/.test(document.querySelector("#semantic-library-assigned-tags").textContent), "custom type tag was not assigned");

  document.querySelector("#semantic-library-detail-name").value = "Marketplace editor";
  document.querySelector("#semantic-library-save-pattern").click();
  await waitFor(async () => (await service.getCustomType(EDITOR_TYPE.id)).label === "Marketplace editor", "custom type rename was not saved");

  document.querySelector("#semantic-library-duplicate-pattern").click();
  await waitFor(async () => (await service.listCustomTypes({ pageSize: 20 })).total === 2, "custom type was not duplicated");
  await waitFor(() => /copy/.test(document.querySelector("#semantic-library-detail-name").value), "custom type duplicate was not selected");
  document.querySelector("#semantic-library-delete-pattern").click();
  await waitFor(async () => (await service.listCustomTypes({ pageSize: 20 })).total === 1, "custom type duplicate was not deleted");
  dom.window.close();
});

test("Semantic Library manager previews and imports a pinned external class", async () => {
  const term = {
    termType: "class", uri: "http://xmlns.com/foaf/0.1/Person", prefixedName: "foaf:Person", label: "Person",
    vocabulary: { prefix: "foaf" }, tags: ["People"], metrics: { occurrencesInDatasets: 42 }
  };
  const proposal = {
    source: "semantic-catalog", label: "Import foaf:Person", requested: { kind: "class", id: "foaf:Person", canonicalUri: term.uri },
    snapshot: { acronym: "FOAF", submissionId: 10, graph: "http://data.bioontology.org/ontologies/FOAF/submissions/10" }, warnings: [],
    records: {
      customTypes: [{
        id: "foaf:Person", label: "Person", description: "A person.",
        definition: { kind: "type", description: "A person.", valueType: "foaf:Person", cardinality: "one", example: "Person", canonicalUri: term.uri, supers: ["http://xmlns.com/foaf/0.1/Agent"] },
        provenance: { source: { id: "lov", label: "Linked Open Vocabularies" }, canonicalUri: term.uri, categories: [{ id: "lov:people", label: "People" }] }
      }],
      properties: []
    }
  };
  const catalog = {
    async searchTerms() { return { items: [term], total: 1 }; },
    async planTermImport() { return proposal; }
  };
  const { dom, document, service } = await setup({ catalog });
  document.querySelector("#semantic-library-open-import").click();
  assert.equal(document.querySelector("#semantic-library-import").hidden, false);
  document.querySelector("#semantic-library-catalog-search").value = "Person";
  document.querySelector("#semantic-library-catalog-submit").click();
  await waitFor(() => document.querySelectorAll("#semantic-library-catalog-results button").length === 1, "catalog result did not render");
  document.querySelector("#semantic-library-catalog-results button").click();
  await waitFor(() => /submission 10/.test(document.querySelector("#semantic-library-import-meta").textContent), "import preview did not resolve");
  assert.equal(await service.search({ query: "foaf:Person" }).then((result) => result.total), 0, "preview changed local storage");
  document.querySelector("#semantic-library-confirm-import").click();
  await waitFor(async () => Boolean(await importedRecord(service, "customType", "foaf:Person")), "catalog type was not imported");
  assert.equal((await importedRecord(service, "customType", "foaf:Person")).provenance.source.id, "lov");
  assert.equal(document.querySelector("#semantic-library-import").hidden, true);
  document.querySelector("#semantic-library-open-history").click();
  await waitFor(() => document.querySelectorAll("#semantic-library-history-list .semantic-library-history-item").length === 1, "import history did not render");
  assert.match(document.querySelector("#semantic-library-history-list").textContent, /1 record imported/);
  document.querySelector("#semantic-library-history-list button").click();
  await waitFor(async () => !(await importedRecord(service, "customType", "foaf:Person")), "undo did not remove the imported type");
  assert.match(document.querySelector("#semantic-library-history-list").textContent, /Undone/);
  dom.window.close();
});

test("Semantic Library manager searches and imports LovPortal properties", async () => {
  const uri = "http://xmlns.com/foaf/0.1/knows";
  const term = { termType: "property", uri, prefixedName: "foaf:knows", label: "knows", vocabulary: { prefix: "foaf", label: "Friend of a Friend" }, tags: ["People"], snapshot: { acronym: "FOAF", submissionId: 10, graph: "http://data.bioontology.org/ontologies/FOAF/submissions/10" } };
  const proposal = {
    source: "semantic-catalog", label: "Import foaf:knows", requested: { kind: "property", id: "foaf:knows", canonicalUri: uri }, snapshot: term.snapshot, warnings: [],
    records: { customTypes: [], properties: [{
      id: "foaf:knows", label: "knows", description: "A person known by this person.",
      definition: { kind: "relationship", description: "A person known by this person.", valueType: "http://xmlns.com/foaf/0.1/Person", cardinality: "one", example: "knows", canonicalUri: uri, domainIncludes: ["http://xmlns.com/foaf/0.1/Person"], rangeIncludes: ["http://xmlns.com/foaf/0.1/Person"] },
      provenance: { source: { id: "lov" }, canonicalUri: uri }
    }] }
  };
  const requests = [];
  const catalog = {
    async searchTerms(request) { requests.push(request); return { items: [term], total: 1, page: 1, pageSize: 20 }; },
    async planTermImport() { return proposal; }
  };
  const { dom, document, service } = await setup({ catalog });
  document.querySelector("#semantic-library-open-import").click();
  document.querySelector("#semantic-library-catalog-term-kind").value = "property";
  document.querySelector("#semantic-library-catalog-search").value = "knows";
  document.querySelector("#semantic-library-catalog-submit").click();
  await waitFor(() => document.querySelectorAll("#semantic-library-catalog-results button").length === 1, "property result did not render");
  assert.deepEqual(requests[0].types, ["property"]);
  document.querySelector("#semantic-library-catalog-results button").click();
  await waitFor(() => /Preview complete/.test(document.querySelector("#semantic-library-catalog-status").textContent), "property preview did not render");
  assert.equal(document.querySelector("#semantic-library-import-properties").closest("label").hidden, true);
  document.querySelector("#semantic-library-confirm-import").click();
  await waitFor(async () => Boolean(await importedRecord(service, "property", "foaf:knows")), "property was not imported");
  dom.window.close();
});

test("Semantic Library presents overlapping imported terms as separate bundle-owned records", async () => {
  const { dom, document, manager, service } = await setup();
  const proposal = (label) => ({
    source: "semantic-catalog", label, requested: { kind: "class", id: "foaf:Person" },
    snapshot: { acronym: "FOAF", submissionId: label === "FOAF people bundle" ? 10 : 11 },
    records: { customTypes: [{
      id: "foaf:Person", label: "Person", description: "A person.",
      definition: { kind: "type", description: "A person.", valueType: "foaf:Person", canonicalUri: "http://xmlns.com/foaf/0.1/Person" },
      provenance: { source: { id: "lov" }, canonicalUri: "http://xmlns.com/foaf/0.1/Person" }
    }], properties: [] }
  });
  for (const label of ["FOAF people bundle", "CRM people bundle"]) {
    const plan = await service.planImport({ proposal: proposal(label) });
    await service.startImport({ planId: plan.id });
  }
  document.querySelector("#semantic-library-search").value = "foaf:Person";
  await manager.refresh();
  const rows = [...document.querySelectorAll("#semantic-library-results .semantic-library-result")];
  assert.equal(rows.length, 2);
  assert.match(rows[0].textContent + rows[1].textContent, /FOAF people bundle/);
  assert.match(rows[0].textContent + rows[1].textContent, /CRM people bundle/);
  assert.notEqual(rows[0].dataset.id, rows[1].dataset.id);
  dom.window.close();
});

test("Semantic Library manager browses a vocabulary and imports a connected selection", async () => {
  const vocabulary = { uri: "http://xmlns.com/foaf/0.1/", prefix: "foaf", label: "Friend of a Friend", description: "People and their relationships.", tags: ["People"], languages: ["English"] };
  const snapshot = { acronym: "FOAF", submissionId: 10, graph: "http://data.bioontology.org/ontologies/FOAF/submissions/10" };
  const terms = [
    { termType: "class", uri: "http://xmlns.com/foaf/0.1/Agent", prefixedName: "foaf:Agent", label: "Agent", description: "An agent.", vocabulary: { prefix: "foaf" }, parents: [], snapshot },
    { termType: "class", uri: "http://xmlns.com/foaf/0.1/Person", prefixedName: "foaf:Person", label: "Person", description: "A person.", vocabulary: { prefix: "foaf" }, parents: ["http://xmlns.com/foaf/0.1/Agent"], snapshot }
  ];
  const provenance = { source: { id: "lov", label: "Linked Open Vocabularies" }, canonicalUri: terms[0].uri, vocabulary: { prefix: "foaf", acronym: "FOAF", graph: snapshot.graph, submissionId: 10 }, categories: [{ id: "lov:people", label: "People" }] };
  const proposal = {
    source: "semantic-catalog", label: "Import foaf vocabulary selection",
    requested: { kind: "vocabularySubset", id: "foaf", canonicalUri: vocabulary.uri, selectedCount: 1 }, snapshot,
    hierarchy: { selectedCount: 1, includedAncestorCount: 1 }, warnings: [],
    records: {
      customTypes: terms.map((term) => ({
        id: term.prefixedName, label: term.label, description: term.description,
        definition: { kind: "type", description: term.description, valueType: term.prefixedName, cardinality: "one", example: term.label, canonicalUri: term.uri, ...(term.parents.length ? { supers: term.parents } : {}) },
        provenance: { ...provenance, canonicalUri: term.uri }
      })),
      properties: []
    }
  };
  const calls = [];
  const catalog = {
    async listCategories() { calls.push(["categories"]); return { items: [{ id: "category:people", label: "People", count: 1 }], total: 1 }; },
    async searchVocabularies(request) { calls.push(["search", request.page, request.category]); return { items: [vocabulary], total: 1, page: 1, pageSize: 15 }; },
    async browseVocabulary(_vocabulary, request) { calls.push(["browse", request.page]); return { items: terms, total: 2, page: 1, pageSize: 25, snapshot }; },
    async planVocabularyImport(_vocabulary, selected, options) { calls.push(["plan", selected.map((term) => term.prefixedName), options.includeAncestors]); return proposal; }
  };
  const { dom, document, service } = await setup({ catalog });
  document.querySelector("#semantic-library-open-import").click();
  document.querySelector("#semantic-library-mode-vocabularies").click();
  await waitFor(() => document.querySelectorAll("#semantic-library-catalog-category-list button").length === 1, "cached catalog categories did not render");
  document.querySelector("#semantic-library-catalog-category-list button").click();
  await waitFor(() => document.querySelectorAll("#semantic-library-catalog-results button").length === 1, "vocabulary result did not render");
  assert.deepEqual(calls.find((call) => call[0] === "search"), ["search", 1, "category:people"]);
  document.querySelector("#semantic-library-catalog-results button").click();
  await waitFor(() => document.querySelectorAll("#semantic-library-vocabulary-terms input").length === 2, "vocabulary classes did not render");
  const personCheckbox = [...document.querySelectorAll("#semantic-library-vocabulary-terms label")].find((label) => /foaf:Person/.test(label.textContent)).querySelector("input");
  personCheckbox.click();
  assert.match(document.querySelector("#semantic-library-vocabulary-selection").textContent, /1 class selected/);
  document.querySelector("#semantic-library-preview-vocabulary").click();
  await waitFor(() => /Connected parents\s*1/.test(document.querySelector("#semantic-library-import-meta").textContent), "connected package preview did not render");
  assert.equal((await service.search({ query: "foaf:Person" })).total, 0, "package preview changed local storage");
  document.querySelector("#semantic-library-confirm-import").click();
  await waitFor(async () => Boolean(await importedRecord(service, "customType", "foaf:Person")), "selected vocabulary class was not imported");
  assert.ok(await importedRecord(service, "customType", "foaf:Agent"), "connected parent class was not imported");
  assert.deepEqual(calls.find((call) => call[0] === "plan"), ["plan", ["foaf:Person"], true]);
  dom.window.close();
});
