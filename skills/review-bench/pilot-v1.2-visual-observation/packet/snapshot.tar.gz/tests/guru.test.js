"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Exporters = require("../extension/core/exporters");
const Session = require("../extension/core/session");

const root = path.resolve(__dirname, "..");
const scripts = [
  path.join(root, "extension/core/utils.js"),
  path.join(root, "extension/core/model.js"),
  path.join(root, "reference-adapters/guru.js")
].map((file) => fs.readFileSync(file, "utf8"));
const searchFixture = fs.readFileSync(path.join(__dirname, "fixtures", "guru-search-results.html"), "utf8");
const detailFixture = fs.readFileSync(path.join(__dirname, "fixtures", "guru-job-detail.html"), "utf8");

const pageTwoQuery = "L2Qvam9icy9jL3Byb2dyYW1taW5nLWRldmVsb3BtZW50L21heHF1b3Rlcy81MC9wZy8yLw==";
const skillsQuery = "L2Qvam9icy9jL3Byb2dyYW1taW5nLWRldmVsb3BtZW50L3NraWxsL3B5dGhvbi9za2lsbC9HYW1pbmctU3lzdGVtcy9tYXhxdW90ZXMvNTAv";
const minimumSpendQuery = "L2Qvam9icy9jL3Byb2dyYW1taW5nLWRldmVsb3BtZW50L21pbnNwZW5kLzUwMC9tYXhxdW90ZXMvNTAv";

function runExtraction(html, url) {
  const dom = new JSDOM(html, { url, runScripts: "outside-only" });
  for (const script of scripts) dom.window.eval(script);
  let result;
  try {
    result = dom.window.Site2JsonModel.extract([dom.window.Site2JsonAdapters.Guru], dom.window.document, dom.window.location);
  } catch (error) {
    result = { ok: false, reason: "extraction-error", message: error.message };
  }
  dom.window.close();
  return result;
}

test("decodes Guru search routes while retaining ordered query structure", () => {
  const dom = new JSDOM("", { url: `https://www.guru.com/work/?q=${skillsQuery}`, runScripts: "outside-only" });
  for (const script of scripts.slice(0, 3)) dom.window.eval(script);
  const metadata = dom.window.Site2JsonAdapters.Guru.searchMetadata(new URL(dom.window.location.href));
  assert.equal(metadata.category, "programming-development");
  assert.deepEqual(Array.from(metadata.skillTermsOrdered), ["python", "Gaming-Systems"]);
  assert.equal(metadata.primarySkillTerm, "python");
  assert.deepEqual(Array.from(metadata.additionalSkillTerms), ["Gaming-Systems"]);
  assert.equal(metadata.maxQuotes, 50);
  dom.window.close();
});

test("records Guru minspend as an employer-history filter", () => {
  const result = runExtraction(searchFixture, `https://www.guru.com/work/?q=${minimumSpendQuery}`);
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.page.search.employerMinimumSpend, 500);
  assert.equal(result.document.blocks[0].entities[0]["guru:budget"].minimum, 500);
  assert.equal(result.document.blocks[0].entities[1]["guru:budget"].type, "fixed_or_hourly");
});

test("extracts Guru search cards and normalizes page identity", () => {
  const result = runExtraction(searchFixture, `https://www.guru.com/work/?q=${pageTwoQuery}`);
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.adapter, "guru");
  assert.equal(result.document.context.guru, "https://site2json.dev/ns/guru#");
  assert.equal(result.document.extraction.pageType, "SearchResultsPage");
  assert.equal(result.document.extraction.logicalPosition, 2);
  assert.equal(result.document.extraction.page.search.page, 2);
  assert.equal(result.document.extraction.page.search.maxQuotes, 50);
  assert.equal(result.document.blocks[0].entities.length, 3);

  const [fixed, choice, hourly] = result.document.blocks[0].entities;
  assert.equal(fixed.identifier, "3100001");
  assert.equal(fixed.url, "https://www.guru.com/work/detail/3100001");
  assert.deepEqual(Array.from(fixed.skills), ["Python", "Microsoft Excel", "Data Cleaning"]);
  assert.equal(fixed["guru:budget"].maximum, 1000);
  assert.equal(fixed["guru:quoteCount"], 8);
  assert.equal(fixed["guru:employer"].totalSpend, 2500);
  assert.equal(choice["guru:budget"].type, "fixed_or_hourly");
  assert.equal(hourly["guru:budget"].type, "hourly");
  assert.equal(hourly["guru:budget"].minimum, 25);

  const firstPage = runExtraction(searchFixture, `https://www.guru.com/work/?q=${btoa("/d/jobs/c/programming-development/maxquotes/50/")}`);
  assert.equal(firstPage.document.extraction.collectionKey, result.document.extraction.collectionKey);
  assert.notEqual(firstPage.document.extraction.snapshotKey, result.document.extraction.snapshotKey);
});

test("extracts a Guru detail entity without reading similar-job content", () => {
  const result = runExtraction(detailFixture, "https://www.guru.com/work/detail/3100001");
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.pageType, "ItemPage");
  assert.equal(result.document.extraction.collectionKey, null);
  assert.equal(result.document.extraction.blocks[0].role, "primary");
  assert.equal(result.document.extraction.blocks[0].fidelity, "full");
  const entity = result.document.blocks[0].entities[0];
  assert.equal(entity.identifier, "3100001");
  assert.match(entity.description, /production-ready workflow/);
  assert.equal(entity["guru:budget"].minimum, 500);
  assert.equal(entity["guru:budget"].maximum, 1000);
  assert.equal(entity["guru:employer"].jobsPaid, 8);
  assert.equal(entity["site2json:rawText"].includes("$9k-$12k"), false);
});

test("a Guru detail observation upgrades its matching search summary", () => {
  const search = runExtraction(searchFixture, `https://www.guru.com/work/?q=${pageTwoQuery}`).document;
  const detail = runExtraction(detailFixture, "https://www.guru.com/work/detail/3100001").document;
  let session = Session.create(search);
  session = Session.addDocument(session, detail);
  const merged = Session.merge(session);
  assert.equal(merged.length, 3);
  const upgraded = merged.find((entity) => entity.identifier === "3100001");
  assert.match(upgraded.description, /production-ready workflow/);
  assert.deepEqual(upgraded["site2json:observations"].map((item) => item.fidelity), ["summary", "full"]);
});

test("compact Guru output exposes marketplace-specific fields", () => {
  const document = runExtraction(searchFixture, `https://www.guru.com/work/?q=${pageTwoQuery}`).document;
  const compact = Exporters.compact(document);
  assert.equal(compact.adapter, "guru");
  assert.equal(compact.jobs[0].quote_count, 8);
  assert.equal(compact.jobs[0].employer.totalSpend, 2500);
  assert.equal(compact.jobs[0].client, undefined);
  const jsonLd = Exporters.jsonLd(document);
  assert.equal(jsonLd.graph["@context"].guru, "https://site2json.dev/ns/guru#");
});

test("Guru detail extraction fails loudly without its scoped component", () => {
  const result = runExtraction("<!doctype html><main><h1>Unscoped job</h1></main>", "https://www.guru.com/work/detail/3100001");
  assert.equal(result.ok, false);
  assert.equal(result.reason, "extraction-error");
  assert.match(result.message, /detail region could not be located/i);
});

test("scrubbed Guru fixtures omit captured-page implementation and download artifacts", () => {
  for (const fixture of [searchFixture, detailFixture]) {
    assert.doesNotMatch(fixture, /data-v-[a-f0-9]+/i);
    assert.doesNotMatch(fixture, /(?:s3\.amazonaws\.com|cloudinary\.com|prodprojfiles|tinyurl\.com)/i);
    assert.doesNotMatch(fixture, /<[!]--|<svg/i);
    assert.doesNotMatch(fixture, /[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}/i);
  }
});
