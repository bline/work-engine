"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const SemanticGraph = require("../extension/editor/sidebar-semantic-graph");

function fixture(onResolveEvidence, onPickEvidence = () => {}, onAcceptFallback = () => {}) {
  const dom = new JSDOM(`
    <section id="semantic-variants"><strong id="semantic-variants-title"></strong><small id="semantic-variants-summary"></small>
      <div id="semantic-variant-graph"></div><p id="semantic-variants-status"></p>
      <button id="analyze-variants-button"></button><button id="apply-variants-button"></button>
      <button id="add-variant-evidence-button"></button><button id="clear-variants-button"></button>
      <section id="variant-classification-review" hidden>
        <span id="variant-classification-summary"></span><div id="variant-classification-counts"></div><div id="variant-classification-issues"></div>
        <button id="refresh-variant-classification-button"></button>
        <form id="variant-resolution-form" hidden><strong id="variant-resolution-title"></strong>
          <div id="variant-resolution-breakdown"></div><select id="variant-resolution-type"></select>
          <button id="select-variant-resolution-evidence-button" type="button"></button>
          <button id="save-variant-resolution-button" type="submit"></button><button id="accept-variant-fallback-button" type="button"></button><button id="cancel-variant-resolution-button" type="button"></button>
          <p id="variant-resolution-status"></p>
        </form>
      </section>
    </section>
  `);
  const block = { schemaType: "SearchResultsPage", variantAnalysis: null, variants: null };
  const view = SemanticGraph.create({
    document: dom.window.document,
    getBlock: () => block,
    onAnalyze() {}, onApply() {}, onClear() {}, onAddEvidence() {},
    onResolveEvidence, onPickEvidence, onAcceptFallback, onRevealItem() {}, onClearPreview() {}
  });
  return { dom, document: dom.window.document, view };
}

test("the shared resolver accepts nested slot context and returns it unchanged when saving evidence", async () => {
  let resolved = null;
  let pickerContext = null;
  const { dom, document, view } = fixture(async (context) => { resolved = context; }, async (context) => { pickerContext = context; });
  const row = {
    rootIndex: 4, status: "ambiguous",
    alternatives: [
      { entityName: "ArticleItem", schemaType: "Article", score: 8, shapeScore: 8, evidenceScore: 0 },
      { entityName: "JobItem", schemaType: "JobPosting", score: 7, shapeScore: 7, evidenceScore: 0 }
    ],
    classification: { winner: { schemaType: "Article" }, runnerUp: { schemaType: "JobPosting" }, margin: 1 }
  };
  assert.equal(view.openResolver({
    kind: "nested", row, slotPath: "itemList.itemListElement.item", nodeAlias: "thing", rootIndex: 4,
    candidateType: "JobPosting",
    candidates: [{ entityName: "ArticleItem", schemaType: "Article" }, { entityName: "JobItem", schemaType: "JobPosting" }]
  }), true);
  assert.equal(document.querySelector("#variant-resolution-form").hidden, false);
  assert.match(document.querySelector("#variant-resolution-title").textContent, /itemList\.itemListElement\.item.*result 5/);
  assert.equal(document.querySelector("#variant-resolution-type").value, "JobPosting");
  assert.match(document.querySelector("#variant-resolution-breakdown").textContent, /runner-up JobPosting · margin 1/);
  document.querySelector("#select-variant-resolution-evidence-button").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(pickerContext.slotPath, "itemList.itemListElement.item");
  document.querySelector("#variant-resolution-form").dispatchEvent(new dom.window.Event("submit", { bubbles: true, cancelable: true }));
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(resolved, {
    kind: "nested", slotPath: "itemList.itemListElement.item", nodeAlias: "thing",
    candidates: [{ entityName: "ArticleItem", schemaType: "Article" }, { entityName: "JobItem", schemaType: "JobPosting" }],
    rootIndex: 4, schemaType: "JobPosting"
  });
  dom.window.close();
});

test("the shared resolver accepts only the exact unresolved classification shape as fallback", async () => {
  let accepted = null;
  const { dom, document, view } = fixture(() => {}, () => {}, async (context) => { accepted = context; });
  const row = {
    rootIndex: 2, status: "ambiguous", alternatives: [{ entityName: "ArticleItem", schemaType: "Article", score: 8 }],
    classification: { accepted: false, classificationFingerprint: "s2j1:shape", configurationDigest: "s2j1:config" }
  };
  view.openResolver({ kind: "nested", row, slotPath: "mainEntity", rootIndex: 2, candidates: [{ entityName: "ArticleItem", schemaType: "Article" }] });
  document.querySelector("#accept-variant-fallback-button").click();
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(accepted.slotPath, "mainEntity");
  assert.equal(accepted.row.classification.classificationFingerprint, "s2j1:shape");
  assert.equal(document.querySelector("#variant-resolution-form").hidden, true);
  dom.window.close();
});
