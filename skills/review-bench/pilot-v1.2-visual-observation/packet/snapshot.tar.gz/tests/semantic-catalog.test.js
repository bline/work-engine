"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Catalog = require("../extension/core/semantic-catalog");

function response(value) {
  return { ok: true, status: 200, async json() { return value; } };
}

test("LovPortal enrichment pins the newest vocabulary snapshot and resolves direct relationships", async () => {
  const queries = [];
  const catalog = Catalog.create({
    fetchImpl: async (url) => {
      const parsed = new URL(url);
      const query = parsed.searchParams.get("query");
      queries.push(query);
      if (query.includes("SELECT DISTINCT ?g")) return response({ results: { bindings: [
        { g: { type: "uri", value: "http://data.bioontology.org/ontologies/FOAF/submissions/9" } },
        { g: { type: "uri", value: "http://data.bioontology.org/ontologies/FOAF/submissions/10" } }
      ] } });
      if (query.includes("?direction")) return response({ results: { bindings: [
        { direction: { value: "term" }, predicate: { value: "http://data.bioontology.org/metadata/def/prefixIRI" }, object: { type: "literal", value: "foaf:Person" } },
        { direction: { value: "term" }, predicate: { value: "http://www.w3.org/2000/01/rdf-schema#label" }, object: { type: "literal", value: "Person" } },
        { direction: { value: "term" }, predicate: { value: "http://www.w3.org/2000/01/rdf-schema#comment" }, object: { type: "literal", value: "A person." } },
        { direction: { value: "term" }, predicate: { value: "http://www.w3.org/2000/01/rdf-schema#subClassOf" }, object: { type: "uri", value: "http://xmlns.com/foaf/0.1/Agent" } },
        { direction: { value: "property" }, subject: { value: "http://xmlns.com/foaf/0.1/knows" }, predicate: { value: "http://www.w3.org/2000/01/rdf-schema#domain" }, object: { value: "http://xmlns.com/foaf/0.1/Person" } }
      ] } });
      return response({ results: { bindings: [
        { property: { value: "http://xmlns.com/foaf/0.1/knows" }, predicate: { value: "http://data.bioontology.org/metadata/def/prefixIRI" }, value: { type: "literal", value: "foaf:knows" } },
        { property: { value: "http://xmlns.com/foaf/0.1/knows" }, predicate: { value: "http://www.w3.org/2000/01/rdf-schema#comment" }, value: { type: "literal", value: "A person known by this person." } },
        { property: { value: "http://xmlns.com/foaf/0.1/knows" }, predicate: { value: "http://www.w3.org/2000/01/rdf-schema#range" }, value: { type: "uri", value: "http://xmlns.com/foaf/0.1/Person" } }
      ] } });
    }
  });
  const proposal = await catalog.planTermImport({
    kind: "catalogTerm", termType: "class", uri: "http://xmlns.com/foaf/0.1/Person", prefixedName: "foaf:Person",
    label: "Person", description: "", vocabulary: { prefix: "foaf" }, tags: ["People"]
  });
  assert.equal(proposal.snapshot.submissionId, 10);
  assert.deepEqual(proposal.records.customTypes[0].definition.supers, ["http://xmlns.com/foaf/0.1/Agent"]);
  assert.equal(proposal.records.properties[0].id, "foaf:knows");
  assert.equal(proposal.records.properties[0].definition.rangeIncludes[0], "http://xmlns.com/foaf/0.1/Person");
  assert.equal(proposal.records.customTypes[0].provenance.retrievedThrough.id, "lovportal-sparql");
  assert.ok(queries.every((query) => !query.includes("undefined")));
});

test("LovPortal pages a vocabulary and plans a connected bounded subset", async () => {
  const queries = [];
  const snapshotGraph = "http://data.bioontology.org/ontologies/FOAF/submissions/10";
  const personUri = "http://xmlns.com/foaf/0.1/Person";
  const agentUri = "http://xmlns.com/foaf/0.1/Agent";
  const catalog = Catalog.create({
    fetchImpl: async (url) => {
      const query = new URL(url).searchParams.get("query");
      queries.push(query);
      if (query.includes("AS ?matches")) return response({ results: { bindings: [
        { g: { value: snapshotGraph }, matches: { value: "13" } }
      ] } });
      if (query.includes("AS ?total")) return response({ results: { bindings: [{ total: { value: "13" } }] } });
      if (query.includes("ORDER BY LCASE") && query.includes("LIMIT 2 OFFSET 0")) return response({ results: { bindings: [
        { term: { type: "uri", value: agentUri }, prefixed: { value: "foaf:Agent" }, label: { value: "Agent" }, parent: { type: "uri", value: "http://www.w3.org/2002/07/owl#Thing" } },
        { term: { type: "uri", value: personUri }, prefixed: { value: "foaf:Person" }, label: { value: "Person" }, parent: { type: "uri", value: agentUri } }
      ] } });
      if (query.includes("VALUES ?child") && query.includes(personUri)) return response({ results: { bindings: [
        { term: { type: "uri", value: agentUri } }
      ] } });
      if (query.includes("VALUES ?child") && query.includes(agentUri)) return response({ results: { bindings: [] } });
      if (query.includes("VALUES ?selected")) return response({ results: { bindings: [
        { property: { value: "http://xmlns.com/foaf/0.1/knows" }, predicate: { value: "http://data.bioontology.org/metadata/prefixIRI" }, value: { value: "foaf:knows" } },
        { property: { value: "http://xmlns.com/foaf/0.1/knows" }, predicate: { value: "http://www.w3.org/2000/01/rdf-schema#domain" }, value: { type: "uri", value: personUri } },
        { property: { value: "http://xmlns.com/foaf/0.1/knows" }, predicate: { value: "http://www.w3.org/2000/01/rdf-schema#range" }, value: { type: "uri", value: personUri } }
      ] } });
      if (query.includes("VALUES ?term")) return response({ results: { bindings: [
        { term: { type: "uri", value: agentUri }, prefixed: { value: "foaf:Agent" }, label: { value: "Agent" }, parent: { type: "uri", value: "http://www.w3.org/2002/07/owl#Thing" } },
        { term: { type: "uri", value: personUri }, prefixed: { value: "foaf:Person" }, label: { value: "Person" }, parent: { type: "uri", value: agentUri } }
      ] } });
      throw new Error(`Unexpected query: ${query}`);
    }
  });
  const vocabulary = {
    uri: "http://xmlns.com/foaf/0.1/", prefix: "foaf", label: "Friend of a Friend", tags: ["People"],
    provenance: { curator: { id: "lov" } }, snapshot: { graph: snapshotGraph, acronym: "FOAF", submissionId: 10 }
  };
  const page = await catalog.browseVocabulary(vocabulary, { pageSize: 2 });
  assert.equal(page.total, 13);
  assert.equal(page.items[1].prefixedName, "foaf:Person");
  assert.equal(page.snapshot.submissionId, 10);

  const proposal = await catalog.planVocabularyImport(vocabulary, [page.items[1]], { snapshot: page.snapshot, includeAncestors: true, includeProperties: true });
  assert.equal(proposal.requested.kind, "vocabularySubset");
  assert.equal(proposal.hierarchy.selectedCount, 1);
  assert.equal(proposal.hierarchy.includedAncestorCount, 1);
  assert.deepEqual(proposal.records.customTypes.map((record) => record.id), ["foaf:Agent", "foaf:Person"]);
  assert.equal(proposal.records.properties[0].id, "foaf:knows");
  assert.equal(proposal.records.customTypes[0].provenance.vocabulary.submissionId, 10);
  assert.ok(queries.some((query) => query.includes("LIMIT 2 OFFSET 0")));
});

function metadataFixtures() {
  const categoryUri = "http://data.bioontology.org/categories/SOCIO";
  const ontologyUri = "http://data.bioontology.org/ontologies/FOAF";
  const graph = `${ontologyUri}/submissions/10`;
  return {
    categoryUri, ontologyUri, graph,
    ontology: { results: { bindings: [
      { ontology: { value: ontologyUri }, acronym: { value: "FOAF" }, name: { value: "Friend of a Friend" }, category: { value: categoryUri }, group: { value: "http://data.bioontology.org/groups/W3C" } }
    ] } },
    categories: { results: { bindings: [
      { category: { value: categoryUri }, acronym: { value: "SOCIO" }, name: { value: "Sociology" } }
    ] } },
    submissions: { results: { bindings: [
      { submission: { value: graph }, ontology: { value: ontologyUri }, submissionId: { value: "10" }, namespace: { value: "http://xmlns.com/foaf/0.1/" }, uri: { value: "http://xmlns.com/foaf/0.1/" }, description: { value: "People and their relationships." } }
    ] } }
  };
}

test("LovPortal discovery caches vocabulary categories and filters browsing locally", async () => {
  const fixture = metadataFixtures();
  const queries = [];
  const stored = {};
  const enrichment = { async query(query) {
    queries.push(query);
    if (query.includes("metadata/Category")) return fixture.categories;
    if (query.includes("metadata/OntologySubmission")) return fixture.submissions;
    return fixture.ontology;
  } };
  const discovery = Catalog.createLovPortalDiscovery({
    enrichment,
    storage: { async get(key) { return { [key]: stored[key] }; }, async set(value) { Object.assign(stored, value); } }
  });
  const categories = await discovery.listCategories();
  const first = await discovery.searchVocabularies({ category: fixture.categoryUri });
  const second = await discovery.searchVocabularies({ query: "friend" });
  assert.equal(categories.items[0].label, "Sociology");
  assert.equal(categories.items[0].count, 1);
  assert.equal(first.items[0].snapshot.submissionId, 10);
  assert.equal(second.items[0].prefix, "foaf");
  assert.equal(queries.length, 3, "cached vocabulary browsing repeated remote metadata queries");
  assert.ok(stored[Catalog.METADATA_CACHE_KEY]);
});

test("LovPortal indexed search supports classes and properties, rejects stale graphs, and deduplicates canonical terms", async () => {
  const fixture = metadataFixtures();
  const personUri = "http://xmlns.com/foaf/0.1/Person";
  const knowsUri = "http://xmlns.com/foaf/0.1/knows";
  const enrichment = { async query(query) {
    if (query.includes("bif:contains")) return { results: { bindings: [
      { g: { value: fixture.graph.replace("/10", "/9") }, term: { value: personUri }, kind: { value: "http://www.w3.org/2002/07/owl#Class" }, label: { value: "Person" }, prefixed: { value: "foaf:Person" }, ftScore: { value: "1" } },
      { g: { value: fixture.graph }, term: { value: personUri }, kind: { value: "http://www.w3.org/2002/07/owl#Class" }, label: { value: "Person" }, prefixed: { value: "foaf:Person" }, ftScore: { value: "1" } },
      { g: { value: fixture.graph }, term: { value: knowsUri }, kind: { value: "http://www.w3.org/2002/07/owl#ObjectProperty" }, rdfsLabel: { value: "knows" }, ftScore: { value: "1" } }
    ] } };
    if (query.includes("metadata/Category")) return fixture.categories;
    if (query.includes("metadata/OntologySubmission")) return fixture.submissions;
    return fixture.ontology;
  } };
  const discovery = Catalog.createLovPortalDiscovery({ enrichment });
  const result = await discovery.searchTerms({ query: "Person", types: ["class", "property"] });
  assert.deepEqual(result.items.map((term) => term.prefixedName), ["foaf:Person", "foaf:knows"]);
  assert.equal(result.items[0].snapshot.graph, fixture.graph);
  assert.equal(result.items[0].provenance.discoveredThrough.id, "lovportal-sparql");
});
