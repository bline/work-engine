"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Exporters = require("../extension/core/exporters");
const Session = require("../extension/core/session");

function document() {
  return {
    extraction: {
      id: "r_1", extractorVersion: "0.1.0", extractedAt: "2026-08-08T12:00:00.000Z", adapter: "upwork", adapterVersion: 1,
      pageUrl: "https://www.upwork.com/nx/search/jobs/?q=csv", pageTitle: "CSV jobs",
      pageType: "SearchResultsPage", collectionKey: "upwork:jobs:q=csv", logicalPosition: 1,
      snapshotKey: "upwork:jobs:q=csv:page:1",
      warnings: [], quality: { complete: true, requiredFieldCoverage: 1, monitoredFieldCoverage: .8 }
    },
    context: { upwork: "https://site2json.dev/ns/upwork#" },
    blocks: [{
      role: "collection", fidelity: "summary", entities: [{
        "@type": "JobPosting", "@id": "https://www.upwork.com/jobs/~1", identifier: "1",
        url: "https://www.upwork.com/jobs/~1", title: "Clean CSV", description: "Clean a CSV file.",
        skills: ["CSV"], datePosted: "2026-08-08", "upwork:postedText": "Posted today",
        "upwork:budget": { type: "fixed", amount: 100 }, "upwork:connectCost": null
      }]
    }, {
      role: "related", fidelity: "summary", entities: [{ "@type": "JobPosting", "@id": "related", title: "Related" }]
    }]
  };
}

test("exports canonical JSON-LD without contaminating it with related blocks", () => {
  const result = Exporters.jsonLd(document());
  assert.equal(result.extraction.formatVersion, 1);
  assert.equal(result.extraction.adapterVersion, 1);
  assert.equal(result.graph["@type"], "SearchResultsPage");
  assert.equal(result.graph["@context"].upwork, "https://site2json.dev/ns/upwork#");
  assert.equal(result.graph.mainEntity.numberOfItems, 1);
  assert.equal(result.graph.mainEntity.itemListElement[0].title, "Clean CSV");
});

test("exports a compact job projection for LLM workflows", () => {
  const result = Exporters.compact(document());
  assert.equal(result.format_version, 1);
  assert.equal(result.adapter_version, 1);
  assert.equal(result.extractor_version, "0.1.0");
  assert.equal(result.jobs.length, 1);
  assert.deepEqual(result.jobs[0], {
    id: "1",
    url: "https://www.upwork.com/jobs/~1",
    title: "Clean CSV",
    description_excerpt: "Clean a CSV file.",
    skills: ["CSV"],
    date_posted: "2026-08-08",
    posted_text: "Posted today",
    budget: { type: "fixed", amount: 100 }
  });
  assert.equal(result.jobs[0].warnings, undefined);
  assert.equal(result.jobs[0].connect_cost, undefined);
  assert.equal(result.summary.monitored_field_coverage, .8);
  assert.deepEqual(result.warnings, []);
  assert.equal(result.entities, undefined);
});

test("compact projection is vocabulary-independent and preserves colliding local names", () => {
  const entity = {
    "@type": "JobPosting", "@id": "https://example.com/1", identifier: "1", title: "Example",
    "market:weeklyHours": "20 hours", "alpha:rating": 4, "beta:rating": 5
  };
  assert.deepEqual(Exporters.compactEntity(entity), {
    id: "1",
    url: "https://example.com/1",
    title: "Example",
    weekly_hours: "20 hours",
    extension_fields: { "alpha:rating": 4, "beta:rating": 5 }
  });
});

test("raw text is excluded by default, opt-in, and subject to compact field selection", () => {
  const entity = {
    "@type": "JobPosting", "@id": "https://example.com/1", identifier: "1", title: "Example",
    description: "Short description", "market:budget": { amount: 100 }, "site2json:rawText": "x".repeat(10_000)
  };
  const defaultProjection = Exporters.compactEntity(entity);
  const rawProjection = Exporters.compactEntity(entity, { includeRawText: true });
  assert.equal(defaultProjection.raw_text, undefined);
  assert.equal(rawProjection.raw_text.length, 10_000);
  assert.ok(JSON.stringify(rawProjection).length - JSON.stringify(defaultProjection).length > 9_900);
  assert.deepEqual(Exporters.compactEntity(entity, { fields: ["id", "title", "budget"] }), {
    id: "1", title: "Example", budget: { amount: 100 }
  });
});

test("exports a canonical JSON-LD session with merged entities and provenance", () => {
  const session = Session.create(document());
  const result = Exporters.jsonLdSession(session, Session);
  assert.equal(result.extraction.source, "site2json-session");
  assert.equal(result.extraction.formatVersion, 1);
  assert.equal(result.extraction.adapterVersion, 1);
  assert.deepEqual(result.extraction.extractorVersions, ["0.1.0"]);
  assert.equal(result.extraction.adapter, "upwork");
  assert.equal(result.extraction.snapshots.length, 1);
  assert.equal(result.extraction.summary.entitiesExported, 1);
  assert.equal(result.graph["@context"].upwork, "https://site2json.dev/ns/upwork#");
  assert.equal(result.graph.mainEntity.numberOfItems, 1);
  assert.equal(result.graph.mainEntity.itemListElement[0].title, "Clean CSV");
  assert.equal(result.graph.mainEntity.itemListElement[0]["site2json:observations"].length, 1);
});

test("exports compact sessions through the shared exporter", () => {
  const result = Exporters.compactSession(Session.create(document()), Session);
  assert.equal(result.source, "site2json-session");
  assert.equal(result.format_version, 1);
  assert.equal(result.adapter_version, 1);
  assert.deepEqual(result.extractor_versions, ["0.1.0"]);
  assert.equal(result.summary.entities_exported, 1);
  assert.equal(result.jobs[0].title, "Clean CSV");
});
