"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const EditorController = require("../extension/editor/editor-controller");

function fakePort() {
  let listener;
  const sent = [];
  return {
    sent,
    postMessage(message) { sent.push(message); },
    onMessage: { addListener(value) { listener = value; } },
    receive(message) { listener(message); },
    disconnect() {}
  };
}

test("derives the guided workflow from draft contents instead of separate wizard state", () => {
  assert.equal(EditorController.deriveWorkflow({}).current, "structure");
  const discovered = EditorController.deriveWorkflow({
    blocks: [{ id: "jobs" }],
    activeBlock: { fields: [
      { identity: true, unresolved: false },
      { identity: false, unresolved: true }
    ] }
  });
  assert.equal(discovered.current, "review");
  assert.equal(discovered.unresolved, 1);
  assert.equal(discovered.steps.find((step) => step.id === "discover").status, "complete");

  const inferred = EditorController.deriveWorkflow({
    inferenceReviewReady: true,
    blocks: [{ id: "jobs", semanticsReviewed: false }],
    activeBlock: { fields: [{ identity: false, unresolved: false }] }
  });
  assert.equal(inferred.current, "review");
  assert.equal(inferred.steps.find((step) => step.id === "semantics").status, "attention");
  assert.equal(inferred.steps.find((step) => step.id === "discover").status, "complete");

  const ready = EditorController.deriveWorkflow({
    blocks: [{ id: "jobs" }], validDefinition: true,
    activeBlock: { fields: [{ identity: true }, { identity: false, unresolved: false }] }
  });
  assert.equal(ready.current, "finish");
  assert.equal(ready.steps.find((step) => step.id === "finish").status, "complete");
});

test("owns the active-view lease and returns it after expanded-workspace loss", () => {
  const port = fakePort();
  let clock = 1_000;
  let timerCallback;
  const controller = EditorController.create({
    port,
    now: () => clock,
    leaseTimeout: 100,
    setTimer(callback) { timerCallback = callback; return 1; },
    clearTimer() {}
  });

  port.receive({ type: "surface-connected", surface: "expanded" });
  assert.equal(controller.snapshot().lease.owner, "expanded");
  port.receive({ type: "table-snapshot", snapshot: { blocks: [], rows: [] }, validDefinition: false });
  assert.deepEqual(controller.snapshot().snapshot.rows, []);
  port.receive({ type: "workspace-heartbeat" });
  clock += 99;
  timerCallback();
  assert.equal(controller.snapshot().lease.owner, "expanded");
  clock += 2;
  timerCallback();
  assert.equal(controller.snapshot().lease.owner, "sidebar");

  port.receive({ type: "lease-command", owner: "expanded" });
  port.receive({ type: "surface-disconnected", surface: "expanded" });
  assert.equal(controller.snapshot().lease.owner, "sidebar");
  controller.dispose();
});

test("keeps the newest complete editor snapshot across client revisions", () => {
  const port = fakePort();
  const controller = EditorController.create({ port, setTimer: () => 1, clearTimer() {} });
  port.receive({ type: "editor-snapshot", sessionId: "sidebar-a", revision: 2, editor: { activeBlockId: "jobs", blocks: [{ id: "jobs" }] } });
  port.receive({ type: "editor-snapshot", sessionId: "sidebar-a", revision: 1, editor: { activeBlockId: "stale", blocks: [] } });
  assert.equal(controller.snapshot().editor.activeBlockId, "jobs");
  port.receive({ type: "editor-snapshot", sessionId: "sidebar-b", revision: 1, editor: { activeBlockId: "products", blocks: [{ id: "products" }] } });
  assert.equal(controller.snapshot().editor.activeBlockId, "products", "a newly loaded sidebar starts a new revision stream");
  controller.dispose();
});

test("serializes commands from the leased surface and reports rejected concurrent work", () => {
  const port = fakePort();
  const controller = EditorController.create({ port, setTimer: () => 1, clearTimer() {} });
  port.receive({ type: "surface-connected", surface: "expanded" });
  port.receive({ type: "editor-command", sourceSurface: "sidebar", command: { action: "refresh" } });
  assert.equal(port.sent.at(-1).reason, "inactive-surface");

  port.receive({ type: "editor-command", sourceSurface: "expanded", command: { action: "refresh" } });
  const execute = port.sent.findLast((message) => message.type === "execute-command");
  assert.equal(execute.command.action, "refresh");
  assert.equal(controller.snapshot().pendingCommand.action, "refresh");
  port.receive({ type: "editor-command", sourceSurface: "expanded", command: { action: "clear-preview" } });
  assert.equal(port.sent.at(-1).command.action, "clear-preview", "transient highlight cleanup must not wait behind a draft command");
  port.receive({ type: "editor-command", sourceSurface: "expanded", command: { action: "preview-field-form" } });
  assert.equal(port.sent.at(-1).command.action, "preview-field-form", "live unsaved field previews must not wait behind a draft command");
  port.receive({ type: "editor-command", sourceSurface: "expanded", command: { action: "remove-field" } });
  assert.equal(port.sent.at(-1).reason, "command-pending");

  port.receive({ type: "command-result", commandId: execute.commandId, ok: true });
  assert.equal(controller.snapshot().pendingCommand, null);
  assert.equal(controller.snapshot().lastCommandResult.ok, true);
  controller.dispose();
});

test("clears a stranded command when its executor disconnects or times out", () => {
  const port = fakePort();
  let clock = 0;
  let tick;
  const controller = EditorController.create({
    port, now: () => clock, commandTimeout: 20,
    setTimer(callback) { tick = callback; return 1; }, clearTimer() {}
  });
  port.receive({ type: "editor-command", sourceSurface: "sidebar", command: { action: "refresh" } });
  clock = 21;
  tick();
  assert.equal(controller.snapshot().pendingCommand, null);
  assert.match(controller.snapshot().lastCommandResult.error, /timed out/i);

  port.receive({ type: "editor-command", sourceSurface: "sidebar", command: { action: "refresh" } });
  port.receive({ type: "surface-disconnected", surface: "sidebar" });
  assert.equal(controller.snapshot().pendingCommand, null);
  assert.match(controller.snapshot().lastCommandResult.error, /disconnected/i);
  controller.dispose();
});
