import assert from "node:assert/strict";
import { createRequire } from "node:module";
import test from "node:test";

await import("../extension/core/utils.js");
await import("../extension/core/transforms.js");
const { default: PropertyProfile } = await import("../extension/core/property-profile.mjs");
const require = createRequire(import.meta.url);
const CompatibilityPropertyProfile = require("../extension/core/property-profile.js");

test("the generated classic bridge exposes the canonical named API", () => {
  assert.deepEqual(
    Object.keys(CompatibilityPropertyProfile).filter((name) => name !== "default").sort(),
    ["MAX_ITEM_LENGTH", "MAX_LIST_ITEMS", "VALUE_SHAPES", "VERSION", "isEmpty", "normalize"]
  );
  assert.deepEqual(CompatibilityPropertyProfile.normalize({ aliases: ["title"] }), PropertyProfile.normalize({ aliases: ["title"] }));
});

test("normalizes bounded reusable inference guidance", () => {
  assert.deepEqual(PropertyProfile.normalize({
    aliases: ["quotes", "quotes", " bids "],
    negativeAliases: ["budget"],
    expectedShapes: ["INTEGER", "currency"],
    units: ["USD"],
    normalization: ["text", "int"],
    cardinality: "one",
    salience: 88,
    examples: ["12 proposals"]
  }), {
    version: 1,
    aliases: ["quotes", "bids"],
    negativeAliases: ["budget"],
    expectedShapes: ["integer", "currency"],
    units: ["USD"],
    normalization: ["text", "int"],
    cardinality: "one",
    salience: 88,
    examples: ["12 proposals"],
    provenance: { source: "user" }
  });
});

test("rejects unknown value shapes, transforms, and unsafe cardinality claims", () => {
  assert.throws(() => PropertyProfile.normalize({ expectedShapes: ["telephone-ish"] }), /Unknown expected value shape/);
  assert.throws(() => PropertyProfile.normalize({ normalization: ["runArbitraryJavascript"] }), /Unknown packaged transform/);
  assert.throws(() => PropertyProfile.normalize({ cardinality: "exactly-seven" }), /one or many/);
});

test("preserves bounded correction provenance without site evidence", () => {
  const profile = PropertyProfile.normalize({
    aliases: ["employer name"],
    provenance: {
      source: "user-correction",
      updatedAt: "2026-08-13T12:00:00.000Z",
      corrections: [{
        adapterId: "guru", decisionId: "results:JobPosting:name", operation: "add-alias", value: "employer name", updatedAt: "2026-08-13T12:00:00.000Z"
      }]
    }
  });
  assert.equal(profile.provenance.corrections[0].decisionId, "results:JobPosting:name");
});
