"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const SemanticLibraryInference = require("../extension/authoring/semantic-library-inference");
const SemanticRanking = require("../extension/editor/semantic-ranking");
const SchemaVocabulary = require("../extension/editor/schema-vocabulary");
const SemanticCompositions = require("../extension/editor/semantic-compositions");

function record(id, { canonicalUri = `https://example.test/vocab#${id.split(":").at(-1)}`, supers = ["Thing"] } = {}) {
  return {
    id: `package:${id}`,
    termId: id,
    label: id.split(":").at(-1),
    description: `A locally installed ${id} semantic type.`,
    definition: { kind: "type", description: `A locally installed ${id} semantic type.`, valueType: id, cardinality: "one", example: id, canonicalUri, supers },
    provenance: { canonicalUri, source: { kind: "test", id: "fixture" }, bundle: { id: "package:test", label: "Test vocabulary" } }
  };
}

function serviceFor({ types = [], properties = [], patterns = [] }) {
  const summaries = [
    ...types.map((item) => ({ kind: "customType", id: item.id })),
    ...properties.map((item) => ({ kind: "property", id: item.id })),
    ...patterns.map((item) => ({ kind: "pattern", id: item.id }))
  ];
  const searchCalls = [];
  return {
    searchCalls,
    async search({ cursor, pageSize }) {
      searchCalls.push(cursor || null);
      const offset = cursor ? Number(cursor.split(":")[1]) : 0;
      const items = summaries.slice(offset, offset + pageSize);
      return { items, total: summaries.length, nextCursor: offset + items.length < summaries.length ? `v1:${offset + items.length}` : null };
    },
    async getCustomTypes({ ids }) { return types.filter((item) => ids.includes(item.id)); },
    async getTerms({ ids }) { return properties.filter((item) => ids.includes(item.id)); },
    async getPatterns({ ids }) { return patterns.filter((item) => ids.includes(item.id)); }
  };
}

test("indexes every installed type, canonically deduplicates scoring, and ranks local variants", async () => {
  const editor = record("guru:Editor");
  const duplicate = { ...record("other:Editor", { canonicalUri: editor.provenance.canonicalUri }), id: "package-2:editor" };
  const filler = Array.from({ length: 2101 }, (_, index) => record(`bulk:Type${index}`));
  const service = serviceFor({ types: [editor, duplicate, ...filler] });
  const catalog = SemanticLibraryInference.create({ service, ranking: SemanticRanking, vocabulary: SchemaVocabulary });
  const stats = await catalog.load();
  assert.equal(service.searchCalls.length, 22);
  assert.equal(stats.types, 2103);
  assert.equal(stats.canonicalTypes, 2102);

  const evidence = [{ selector: '[data-type="Editor"]', suggestedName: "type", evidence: { classes: ["editor-card"] } }];
  const ranked = catalog.rank(evidence, { allowedTypes: ["guru:Editor"], typeLimit: 4 });
  assert.equal(ranked.types[0].schemaType, "guru:Editor");
  assert.equal(ranked.types[0].librarySourceCount, 2);
  assert.equal(ranked.types.filter((item) => item.kind === "library-type").length, 1);

  const materialized = catalog.materialize(ranked.types[0].id, { adapterPrefix: "site", existingTerms: {} });
  assert.equal(materialized.schemaType, "site:Editor");
  assert.equal(materialized.customTerms["site:Editor"].canonicalUri, "https://example.test/vocab#Editor");
  assert.deepEqual(materialized.customTerms["site:Editor"].supers, ["Thing"]);
});

test("runtime assignment inputs do not expand a Schema.org fallback into every local subtype", async () => {
  const editor = record("guru:Editor", { supers: ["Thing"] });
  const catalog = SemanticLibraryInference.create({ service: serviceFor({ types: [editor] }), ranking: SemanticRanking, vocabulary: SchemaVocabulary });
  await catalog.load();
  assert.deepEqual(catalog.assignmentInputs(["Thing"]), { types: [], properties: [] });
  assert.deepEqual(catalog.assignmentInputs(["guru:Editor"]).types.map((item) => item.termId), ["guru:Editor"]);
});

test("installed properties are eligible for automatic mapping but are rebased into the adapter vocabulary", async () => {
  const editor = record("guru:Editor");
  const property = {
    id: "package:guru:portfolio",
    termId: "guru:portfolio",
    label: "portfolio",
    description: "The editor portfolio URL.",
    definition: {
      kind: "relationship", description: "The editor portfolio URL.", valueType: "URL", cardinality: "one", example: "https://example.test/portfolio",
      canonicalUri: "https://example.test/vocab#portfolio", domainIncludes: ["https://example.test/vocab#Editor"], rangeIncludes: ["URL"]
    },
    provenance: { canonicalUri: "https://example.test/vocab#portfolio", source: { kind: "test", id: "fixture" } }
  };
  const catalog = SemanticLibraryInference.create({ service: serviceFor({ types: [editor], properties: [property] }), ranking: SemanticRanking, vocabulary: SchemaVocabulary });
  await catalog.load();
  const suggestions = catalog.propertySuggestions("guru:Editor", {
    suggestedName: "portfolio", kind: "url", evidence: { tag: "a", attribute: "href", href: "/work", classes: ["portfolio-link"] }
  }, { adapterPrefix: "site", existingTerms: {} });
  assert.equal(suggestions[0].name, "site:portfolio");
  assert.equal(suggestions[0].source, "extension");
  assert.equal(suggestions[0].vocabularyTerm.canonicalUri, "https://example.test/vocab#portfolio");
  assert.ok(suggestions[0].score >= 32);
  const available = catalog.propertiesForType("guru:Editor", { adapterPrefix: "site", existingTerms: {} });
  assert.equal(available.length, 1);
  assert.equal(available[0].name, "site:portfolio");
  assert.equal(available[0].score, 0, "profile construction must not depend on page evidence");
  assert.equal(available[0].librarySources[0].canonicalUri, "https://example.test/vocab#portfolio");
});

test("materializes an inferred local graph bundle as a self-contained adapter graph", async () => {
  const pattern = {
    id: "package:editor-organization",
    patternId: "guru:editor-organization",
    label: "Editor and organization",
    description: "An editor related to an organization.",
    root: "editor",
    nodes: {
      editor: { types: ["guru:Editor"], expectation: "core", evidenceKeywords: ["editor"] },
      organization: { types: ["Organization"], expectation: "common", evidenceKeywords: ["company"] }
    },
    edges: [{ from: "editor", property: "guru:worksFor", to: "organization", expectation: "common" }],
    terms: {
      "guru:Editor": { kind: "type", description: "A working editor.", valueType: "guru:Editor", cardinality: "one", example: "Editor", supers: ["Person"], canonicalUri: "https://example.test/guru#Editor" },
      "guru:worksFor": { kind: "relationship", description: "The editor's organization.", valueType: "Organization", cardinality: "one", example: "Publisher", domainIncludes: ["guru:Editor"], rangeIncludes: ["Organization"], canonicalUri: "https://example.test/guru#worksFor", authoringProfile: { version: 1, aliases: ["publisher"], provenance: { source: "user" } } }
    },
    provenance: { source: { kind: "test", id: "fixture" } }
  };
  const catalog = SemanticLibraryInference.create({ service: serviceFor({ patterns: [pattern] }), ranking: SemanticRanking, vocabulary: SchemaVocabulary });
  await catalog.load();
  const ranked = catalog.rank([
    { selector: ".editor", suggestedName: "editor", evidence: { classes: ["editor"] } },
    { selector: ".company", suggestedName: "company", evidence: { classes: ["company"] } }
  ]);
  const model = ranked.compositions.find((candidate) => candidate.kind === "library-pattern");
  assert.ok(model);
  const materialized = catalog.materialize(model.id, { adapterPrefix: "site", existingTerms: {} });
  assert.equal(materialized.composition.nodes.editor.types[0], "site:Editor");
  assert.equal(materialized.composition.edges[0].property, "site:worksFor");
  assert.deepEqual(materialized.customTerms["site:worksFor"].domainIncludes, ["site:Editor"]);
  assert.equal(materialized.customTerms["site:worksFor"].authoringProfile, undefined, "inference-only profiles must not enter the adapter DSL");
  assert.equal(SemanticCompositions.validate(materialized.composition, materialized.customTerms).ok, true);
});
