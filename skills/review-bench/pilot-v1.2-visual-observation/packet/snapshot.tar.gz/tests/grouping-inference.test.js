"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const GroupingInference = require("../extension/ir/grouping-inference");

function snapshotGroupingIds(document) {
  const { candidates } = GroupingInference.infer(document, { collection: { id: "page" } });
  const groups = candidates.map((candidate) => ({
    id: candidate.id,
    kind: candidate.kind,
    sourceCount: candidate.sources.length,
    evidence: candidate.evidence
  }));
  return groups.sort((left, right) => `${left.kind}:${left.id}`.localeCompare(`${right.kind}:${right.id}`));
}

function stableMarkup() {
  return `
    <main>
      <section class="results" aria-label="jobs">
        <article data-testid="job-card">
          <h2><a href="/jobs/one">Senior role A</a></h2>
        </article>
        <article data-testid="job-card">
          <h2><a href="/jobs/two">Senior role B</a></h2>
        </article>
        <article data-testid="job-card">
          <h2><a href="/jobs/three">Senior role C</a></h2>
        </article>
      </section>
      <section class="sidebar">
        <article><h2>Sidebar item one</h2></article>
        <article><h2>Sidebar item two</h2></article>
      </section>
    </main>
  `;
}

function snapshotFromHtml(html) {
  return snapshotGroupingIds(new JSDOM(html).window.document);
}

test("grouping candidate ids are derived from source structure and remain stable after sibling reorder", () => {
  const documentA = new JSDOM(stableMarkup()).window.document;
  const documentB = new JSDOM(`
    <main>
      <section class="results" aria-label="jobs">
        <article data-testid="job-card">
          <h2><a href="/jobs/two">Senior role B</a></h2>
        </article>
        <article data-testid="job-card">
          <h2><a href="/jobs/one">Senior role A</a></h2>
        </article>
        <article data-testid="job-card">
          <h2><a href="/jobs/three">Senior role C</a></h2>
        </article>
      </section>
      <aside>Promoted content</aside>
      <section class="sidebar">
        <article><h2>Sidebar item one</h2></article>
        <article><h2>Sidebar item two</h2></article>
      </section>
    </main>
  `).window.document;

  const first = snapshotGroupingIds(documentA);
  const second = snapshotGroupingIds(documentB);
  assert.deepEqual(first.map((entry) => entry.id), second.map((entry) => entry.id));
  assert.ok(first.some((entry) => /^group:[0-9a-f]{8}$/.test(entry.id)));
});

test("grouping ids do not remap when unrelated wrapper content is inserted", () => {
  const base = snapshotFromHtml(`
    <div id="root">
      <section class="results">
        <h2>Title A</h2>
        <a href="/jobs/a">A</a>
        <h2>Title B</h2>
        <a href="/jobs/b">B</a>
        <h2>Title C</h2>
        <a href="/jobs/c">C</a>
      </section>
    </div>
  `);
  const changed = snapshotFromHtml(`
    <div id="root">
      <p class="announcement">New feature highlighted</p>
      <section class="results">
        <h2>Title A</h2>
        <a href="/jobs/a">A</a>
        <h2>Title B</h2>
        <a href="/jobs/b">B</a>
        <h2>Title C</h2>
        <a href="/jobs/c">C</a>
      </section>
    </div>
  `);
  assert.equal(base.length, changed.length);
  assert.deepEqual(base.map((entry) => entry.id), changed.map((entry) => entry.id));
});
