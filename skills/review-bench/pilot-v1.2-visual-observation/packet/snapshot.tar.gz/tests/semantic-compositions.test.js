"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Compositions = require("../extension/editor/semantic-compositions");

test("single Schema.org types normalize into valid one-node compositions", () => {
  const composition = Compositions.singleType("JobPosting");
  assert.equal(composition.root, "listing");
  assert.deepEqual(composition.nodes.listing.types, ["JobPosting"]);
  assert.equal(composition.nodes.listing.expectation, "core");
  assert.deepEqual(Compositions.validate(composition), { ok: true, errors: [], warnings: [] });
});

test("semantic type search ranks an exact type before description matches", () => {
  const result = Compositions.choices("Event");
  assert.equal(result.types[0].label, "Event");
  assert.ok(result.types.some((choice) => choice.label === "BusinessEvent"));
});

test("the packaged freelance composition is inert, connected, and vocabulary-compatible", () => {
  const composition = Compositions.preset("site2json:freelance-opportunity");
  assert.deepEqual(Compositions.validate(composition), { ok: true, errors: [], warnings: [] });
  assert.deepEqual(composition.nodes.listing.types, ["JobPosting", "Demand"]);
  assert.ok(composition.edges.some((edge) => edge.from === "listing" && edge.property === "hiringOrganization" && edge.to === "buyer"));
  assert.equal(JSON.stringify(composition).includes("selector"), false);
  assert.equal(JSON.stringify(composition).includes("hostname"), false);
});

test("composition validation rejects disconnected nodes and invalid relationships", () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.buyer = { types: ["Organization"], expectation: "common" };
  let result = Compositions.validate(composition);
  assert.equal(result.ok, false);
  assert.ok(result.errors.some((message) => /disconnected/.test(message)));
  composition.edges.push({ from: "listing", property: "notAProperty", to: "buyer", expectation: "common" });
  result = Compositions.validate(composition);
  assert.equal(result.ok, false);
  assert.ok(result.errors.some((message) => /not available/.test(message)));
});

test("composition node evidence aliases remain bounded inert data", () => {
  const valid = Compositions.preset("site2json:freelance-opportunity");
  assert.equal(Compositions.validate(valid).ok, true);
  valid.nodes.buyer.evidenceKeywords = ["client", { selector: ".client" }];
  assert.match(Compositions.validate(valid).errors.join(" "), /invalid evidenceKeywords/);
});

test("nested variant validation carries a structured Attention destination", () => {
  const composition = Compositions.singleType("SearchResultsPage");
  composition.nodes.item = {
    types: ["Thing"], expectation: "optional",
    variants: { fallback: "Thing", candidates: [], minScore: 6, minMargin: 2 }
  };
  composition.edges.push({ from: composition.root, to: "item", property: "mainEntity", expectation: "optional" });
  const result = Compositions.validate(composition);
  const issue = result.issues.find((candidate) => /between 1 and 5/.test(candidate.message));
  assert.deepEqual(issue.destination, {
    kind: "semantic-graph", screen: "semantics", nodeAlias: "item",
    section: "variant-types", action: "edit-variant-slot"
  });
});

test("relationship proposals use Schema.org range compatibility", () => {
  const options = Compositions.relationshipOptions(["JobPosting"], "Organization");
  assert.ok(options.some((option) => option.property === "hiringOrganization"));
  assert.equal(options.some((option) => option.property === "datePosted"), false);
  const relationships = Compositions.relationshipOptions(["JobPosting"]);
  assert.ok(relationships.some((option) => option.property === "hiringOrganization" && option.entityRanges.includes("Organization")));
  assert.deepEqual(Compositions.relationshipTargetTypes(["JobPosting"], "hiringOrganization").slice(0, 2), ["Organization", "Person"]);
});

test("type reference exposes descriptions plus direct and inherited property ranges", () => {
  const details = Compositions.typeDetails("JobPosting");
  assert.equal(details.source, "Schema.org");
  assert.ok(details.description.includes("job opening"));
  assert.ok(details.supers.includes("Intangible"));

  const properties = Compositions.propertyReference(["JobPosting"]);
  const hiring = properties.find((property) => property.property === "hiringOrganization");
  assert.equal(hiring.direct, true);
  assert.deepEqual(hiring.entityRanges, ["Organization", "Person"]);
  const description = properties.find((property) => property.property === "description");
  assert.equal(description.direct, false);
  assert.ok(description.inheritedFrom.includes("Thing"));
  assert.ok(description.ranges.includes("Text"));
});

test("type reference includes adapter-local types and relationships", () => {
  const customTerms = {
    "guru:Editor": { kind: "type", description: "A marketplace editor.", supers: ["Person"] },
    "guru:editor": { kind: "relationship", description: "The assigned editor.", domainIncludes: ["JobPosting"], rangeIncludes: ["guru:Editor"] }
  };
  assert.equal(Compositions.typeDetails("guru:Editor", customTerms).source, "Adapter vocabulary");
  const property = Compositions.propertyReference(["JobPosting"], customTerms).find((candidate) => candidate.property === "guru:editor");
  assert.equal(property.direct, true);
  assert.deepEqual(property.entityRanges, ["guru:Editor"]);
  assert.equal(property.source, "Adapter vocabulary");
});

test("structural relationship proposals reject universal Thing fallbacks", () => {
  assert.deepEqual(Compositions.structuralRelationshipOptions(["Product"], "JobPosting"), []);
  assert.equal(Compositions.structuralRelationshipOptions(["JobPosting", "Demand"], "Product").some((option) => option.property === "itemOffered"), true);
  assert.equal(Compositions.structuralRelationshipOptions(["Product"], "Demand").some((option) => option.property === "offers"), true);
  assert.equal(Compositions.structuralRelationshipOptions(["Person"], "Organization").some((option) => option.property === "worksFor"), true);
});

test("structural relationship proposals retain intentional page containment through Thing", () => {
  const options = Compositions.structuralRelationshipOptions(["SearchResultsPage"], "ItemList");
  assert.equal(options.some((option) => option.property === "mainEntity"), true);
});

test("removing a node prunes descendants that would otherwise become disconnected", () => {
  const composition = Compositions.preset("site2json:freelance-opportunity");
  const next = Compositions.removeNode(composition, "buyer");
  assert.equal(next.nodes.buyer, undefined);
  assert.equal(next.nodes.buyerRating, undefined);
  assert.equal(Compositions.validate(next).ok, true);
});

test("removing a relationship prunes only the branch no longer reachable from the root", () => {
  const composition = Compositions.preset("site2json:freelance-opportunity");
  const buyerEdge = composition.edges.findIndex((edge) => edge.from === "listing" && edge.to === "buyer");
  const next = Compositions.removeEdge(composition, buyerEdge);
  assert.equal(next.nodes.buyer, undefined);
  assert.equal(next.nodes.buyerRating, undefined);
  assert.ok(next.nodes.service);
  assert.equal(Compositions.validate(next).ok, true);
});

test("custom vocabulary relationships validate against their declared domains and ranges", () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.editor = { types: ["Person"], expectation: "optional" };
  composition.edges.push({ from: "listing", property: "example:editor", to: "editor", expectation: "optional" });
  const terms = {
    "example:editor": {
      kind: "relationship", description: "The editor.", valueType: "Person", cardinality: "one", example: "Jane",
      domainIncludes: ["JobPosting"], rangeIncludes: ["Person"], evidenceAliases: ["editor", "edited by"]
    }
  };
  assert.equal(Compositions.validate(composition).ok, false);
  assert.deepEqual(Compositions.validate(composition, terms), { ok: true, errors: [], warnings: [] });
});

test("a node may use a custom vocabulary type declared with kind type", () => {
  const composition = Compositions.singleType("JobPosting");
  composition.nodes.editor = { types: ["example:Editor"], expectation: "optional" };
  composition.edges.push({ from: "listing", property: "example:editor", to: "editor", expectation: "optional" });
  const terms = {
    "example:Editor": { kind: "type", description: "A site-specific editor person.", valueType: "example:Editor", cardinality: "one", example: "Editor", supers: ["Person"] },
    "example:editor": {
      kind: "relationship", description: "The editor.", valueType: "example:Editor", cardinality: "one", example: "Jane",
      domainIncludes: ["JobPosting"], rangeIncludes: ["example:Editor"], evidenceAliases: ["editor", "edited by"]
    }
  };
  assert.match(Compositions.validate(composition).errors.join(" "), /unknown Schema\.org type example:Editor/);
  assert.deepEqual(Compositions.validate(composition, terms), { ok: true, errors: [], warnings: [] });
});
