"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const icons = require("../extension/editor/schema-type-icons");

test("schema icons resolve explicit mappings and normalize Schema.org identifiers", () => {
  assert.deepEqual(icons.resolution("schema:JobPosting"), {
    requestedType: "JobPosting", matchedType: "JobPosting", icon: "briefcase", distance: 0, source: "explicit"
  });
  assert.equal(icons.resolution("https://schema.org/Person").icon, "user");
});

test("schema icons inherit the nearest mapped semantic family", () => {
  const result = icons.resolution("ScholarlyArticle");
  assert.equal(result.matchedType, "Article");
  assert.equal(result.icon, "newspaper");
  assert.equal(result.source, "inherited");
  assert.ok(result.distance > 0);
});

test("schema icons use a truthful generic fallback for custom or unknown types", () => {
  assert.deepEqual(icons.resolution("guru:Editor"), {
    requestedType: "guru:Editor", matchedType: "Thing", icon: "cube", distance: null, source: "fallback"
  });
});
