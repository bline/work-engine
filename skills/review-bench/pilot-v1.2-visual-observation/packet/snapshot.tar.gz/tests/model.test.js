"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Model = require("../extension/core/model");

test("required-field quality is calculated across all entities", () => {
  const adapter = { id: "test", version: 1, source: "bundled" };
  const result = Model.assemble(adapter, {
    pageType: "CollectionPage", pageTitle: "Things", blocks: [{
      id: "things", entity: "Thing", role: "collection", arity: "many", fidelity: "summary",
      require: ["name", "url"], monitor: ["details.rating", "tags"], entities: [
        { "@type": "Thing", name: "One", url: "https://example.com/1", details: { rating: 5 }, tags: ["a"] },
        { "@type": "Thing", name: "Two", url: null, details: { rating: null }, tags: [] }
      ]
    }]
  }, "https://example.com/");
  assert.equal(result.extraction.quality.complete, false);
  assert.equal(result.extraction.quality.requiredFieldCoverage, .75);
  assert.equal(result.extraction.quality.monitoredFieldCoverage, .5);
  assert.deepEqual(result.extraction.warnings[0], { code: "field.missing", field: "url", count: 1, block: "things" });
  assert.deepEqual(result.extraction.warnings.slice(1), [
    { code: "field.missing", field: "details.rating", count: 1, block: "things" },
    { code: "field.missing", field: "tags", count: 1, block: "things" }
  ]);
});

test("invalid adapter blocks fail visibly", () => {
  assert.throws(() => Model.validateBlock({ role: "mystery", fidelity: "summary", arity: "many", entities: [] }), /Unknown block role/);
  assert.throws(() => Model.validateBlock({ role: "primary", fidelity: "summary", arity: "one", entities: [{ "@type": "Thing" }, { "@type": "Thing" }] }), /arity one/);
  assert.throws(() => Model.validateBlock({ role: "primary", fidelity: "summary", arity: "one", monitor: "name", entities: [] }), /monitor value/);
});
