"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { JSDOM } = require("jsdom");

globalThis.Site2JsonSchemaTypeIcons = require("../extension/editor/schema-type-icons");
const detectionFirst = require("../extension/editor/sidebar-detection-first");

function documentFixture() {
  return new JSDOM(`<!doctype html><body>
    <section id="step-page-detection" hidden>
      <button id="refresh-page-detection-button"></button>
      <div id="page-detection-status"></div>
      <div id="page-detection-summary" hidden></div>
      <div id="page-detection-results"></div>
      <button id="use-manual-structure-button"></button>
    </section>
  </body>`).window.document;
}

function report() {
  return {
    survey: { durationMs: 8 },
    detection: {
      durationMs: 12,
      summary: { selectedCount: 1, reviewCount: 0, entityCount: 2 },
      selected: [{
        id: "group:1",
        status: "selected",
        typeSignature: ["https://schema.org/JobPosting"],
        grouping: { entityCount: 2 },
        output: { "@graph": [
          { "@type": "JobPosting", title: "Semantic engineer", url: "/jobs/one" },
          { "@type": "JobPosting", title: "Visual systems engineer", url: "/jobs/two" }
        ] }
      }]
    }
  };
}

test("detection-first renders inferred groups without claiming they were accepted", () => {
  const document = documentFixture();
  const view = detectionFirst.create({ document });
  view.render(report(), {});
  assert.equal(document.querySelector("#step-page-detection").hidden, false);
  assert.match(document.querySelector("#page-detection-status").textContent, /currently open page/);
  assert.equal(document.querySelectorAll(".detection-card").length, 2);
  assert.equal(document.querySelector(".detection-group").classList.contains("state-undecided"), true);
  assert.equal(document.querySelector(".detection-review-toggle").textContent, "?");
  assert.match(document.querySelector(".detection-card").textContent, /Semantic engineer/);
  assert.match(document.querySelector("#page-detection-status").textContent, /1 detected group awaits review/);
});

test("detection review records only the selected group decision and preserves provenance", () => {
  const document = documentFixture();
  let change = null;
  const view = detectionFirst.create({ document, onDecision: (detection, decision, decisions) => { change = { detection, decision, decisions }; } });
  view.render(report(), {});
  document.querySelector(".detection-review-choice.accepted").click();
  assert.equal(change.detection.id, "group:1");
  assert.equal(change.decision.state, "accepted");
  assert.deepEqual(change.decision.detectedTypes, ["https://schema.org/JobPosting"]);
  assert.equal(change.decisions["group:1"].state, "accepted");
  assert.equal(document.querySelector(".detection-group").classList.contains("state-accepted"), true);
  assert.match(document.querySelector("#page-detection-status").textContent, /explicit review decision/);
});

test("card and field hover expose detection focus at the most specific available level", () => {
  const document = documentFixture();
  const focuses = [];
  const view = detectionFirst.create({ document, onFocus: (focus) => focuses.push(focus), onClearFocus: () => focuses.push(null) });
  view.render(report(), {});
  const card = document.querySelector(".detection-card");
  card.dispatchEvent(new document.defaultView.MouseEvent("mouseenter", { bubbles: false }));
  const value = card.querySelector("dd");
  value.dispatchEvent(new document.defaultView.MouseEvent("mouseenter", { bubbles: false }));
  assert.deepEqual(focuses.slice(0, 2), [
    { detectionId: "group:1", entityIndex: 0 },
    { detectionId: "group:1", entityIndex: 0, role: "title" }
  ]);
});
