"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Settings = require("../extension/core/automatic-settings");

test("automatic inference settings default to a high confidence threshold", async () => {
  assert.deepEqual(Settings.normalize(), { minimumConfidence: "strong" });
  assert.equal(Settings.label("strong"), "High");
  assert.equal(Settings.label("moderate"), "Moderate");
  assert.deepEqual(await Settings.load(null), { minimumConfidence: "strong" });
});

test("automatic inference settings round-trip through a storage-neutral interface", async () => {
  const values = {};
  const storage = {
    async get(key) { return { [key]: values[key] }; },
    async set(next) { Object.assign(values, next); }
  };
  await Settings.save({ minimumConfidence: "moderate" }, storage);
  assert.deepEqual(await Settings.load(storage), { minimumConfidence: "moderate" });
  await Settings.save({ minimumConfidence: "unsafe" }, storage);
  assert.deepEqual(await Settings.load(storage), { minimumConfidence: "strong" });
});
