"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const PageSemanticProfile = require("../extension/authoring/page-semantic-profile");

test("builds a bounded, provenance-bearing profile from shared Schema and local-library ranking", () => {
  const localType = {
    id: "site:Editor",
    label: "Editor",
    definition: { kind: "type", canonicalUri: "https://example.test/vocab#Editor", supers: ["Person"] }
  };
  const localProperty = {
    id: "site:portfolio",
    definition: {
      kind: "field",
      canonicalUri: "https://example.test/vocab#portfolio",
      domainIncludes: ["site:Editor"],
      rangeIncludes: ["URL"],
      authoringProfile: { aliases: ["portfolio"] }
    }
  };
  const inference = {
    rank(observations, options) {
      assert.equal(observations.length, 2);
      assert.equal(options.typeLimit, 16);
      return {
        observationCount: observations.length,
        types: [
          { id: "schema:JobPosting", schemaType: "JobPosting", kind: "type", score: 42, explained: 2, total: 2, evidence: [{ observation: "datePosted", path: "listing.datePosted" }] },
          { id: "library:editor", schemaType: "site:Editor", kind: "library-type", score: 31, explained: 1, total: 2, evidence: [{ observation: "portfolio", path: "listing.site:portfolio" }] }
        ],
        compositions: []
      };
    },
    assignmentInputs(types) {
      assert.deepEqual(types, ["JobPosting", "site:Editor", "Thing"]);
      return { types: [localType], properties: [localProperty] };
    }
  };

  const result = PageSemanticProfile.build([
    { suggestedName: "datePosted", evidence: { text: "Posted yesterday" } },
    { suggestedName: "portfolio", kind: "url", evidence: { classes: ["portfolio"] } }
  ], { inference });

  assert.deepEqual(result.shortlist.map((entry) => [entry.type, entry.source, entry.reason]), [
    ["JobPosting", "schema.org", "ranked-type"],
    ["site:Editor", "local-vocabulary", "ranked-type"],
    ["Thing", "schema.org", "unresolved-fallback"]
  ]);
  assert.equal(result.profile.types.some((type) => type.term === "https://schema.org/JobPosting"), true);
  assert.equal(result.profile.types.some((type) => type.term === "https://example.test/vocab#Editor"), true);
  assert.deepEqual(result.provenance.localTypeIds, ["site:Editor"]);
  assert.deepEqual(result.provenance.localPropertyIds, ["site:portfolio"]);
  assert.equal(result.provenance.observationCount, 2);
});

test("the shortlist preserves uncertainty and remains bounded", () => {
  const ranked = {
    observationCount: 4,
    types: Array.from({ length: 40 }, (_, index) => ({
      id: `schema:Type${index}`,
      schemaType: `Type${index}`,
      kind: "type",
      score: 40 - index,
      explained: 1,
      total: 4,
      evidence: []
    })),
    compositions: []
  };
  const selected = PageSemanticProfile.shortlist(ranked, { typeLimit: 5 });
  assert.equal(selected.length, 6);
  assert.deepEqual(selected.slice(0, 5).map((entry) => entry.type), ["Type0", "Type1", "Type2", "Type3", "Type4"]);
  assert.equal(selected[5].type, "Thing");
  assert.equal(selected[5].reason, "unresolved-fallback");
});

test("the shortlist excludes weaker duplicate interpretations but keeps uniquely explained populations", () => {
  const ranked = {
    observationCount: 3,
    types: [
      { schemaType: "JobPosting", kind: "type", score: 84, explained: 3, total: 3, evidence: [{ observation: "title" }, { observation: "date" }] },
      { schemaType: "MusicGroup", kind: "type", score: 74, explained: 3, total: 3, evidence: [{ observation: "title" }, { observation: "date" }] },
      { schemaType: "Person", kind: "type", score: 40, explained: 1, total: 3, evidence: [{ observation: "author" }] }
    ],
    compositions: []
  };
  const selected = PageSemanticProfile.shortlist(ranked);
  assert.deepEqual(selected.map((entry) => entry.type), ["JobPosting", "Person", "Thing"]);
});

test("explicit zero bounds remain explicit instead of reverting to defaults", () => {
  const ranked = {
    observationCount: 1,
    types: [{ schemaType: "JobPosting", kind: "type", score: 10, explained: 1, total: 1, evidence: [{ observation: "datePosted" }] }],
    compositions: [{ schemaType: "Article", score: 10, explained: 1, total: 1, evidence: [{ observation: "headline" }] }]
  };
  assert.deepEqual(PageSemanticProfile.shortlist(ranked, { typeLimit: 0, compositionLimit: 0, scoreRatio: 0 }).map((entry) => entry.type), ["Thing"]);

  const inference = {
    rank(_observations, options) {
      assert.equal(options.typeLimit, 0);
      return ranked;
    },
    assignmentInputs(types) {
      assert.deepEqual(types, ["Thing"]);
      return { types: [], properties: [] };
    }
  };
  const result = PageSemanticProfile.build([], { inference, typeLimit: 0, compositionLimit: 0, scoreRatio: 0 });
  assert.deepEqual(result.provenance.bounded, { typeLimit: 0, compositionLimit: 0, scoreRatio: 0, truncated: false });
});
