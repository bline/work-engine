"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Attention = require("../extension/editor/sidebar-attention");

function fixture() {
  const document = new JSDOM(`
    <aside id="site2json-attention-panel" hidden><div id="site2json-attention-list"></div></aside>
    <button id="site2json-attention-button" hidden><span id="site2json-attention-count"></span></button>
  `).window.document;
  return { document, attention: Attention.create({ document }) };
}

test("attention tracks only persistent warnings and errors and navigates to their destinations", () => {
  const { document, attention } = fixture();
  let destination = null;
  attention.registerNavigator("semantic-graph", (value) => { destination = value; });
  attention.sync("graph", [{
    id: "variant-evidence", severity: "error", message: "Variant evidence is missing.",
    destination: { kind: "semantic-graph", nodeAlias: "thing" }
  }]);

  const button = document.querySelector("#site2json-attention-button");
  assert.equal(button.hidden, false);
  assert.equal(document.querySelector("#site2json-attention-count").textContent, "1");
  button.click();
  document.querySelector(".site2json-attention-visit").click();
  assert.equal(destination.nodeAlias, "thing");
});

test("dismissed attention stays hidden until the underlying issue resolves and recurs", () => {
  const { document, attention } = fixture();
  const issue = { id: "warning", severity: "warning", message: "Review this choice.", destination: {} };
  attention.sync("graph", [issue]);
  document.querySelector(".site2json-attention-dismiss").click();
  assert.equal(document.querySelector("#site2json-attention-button").hidden, true);

  attention.sync("graph", [issue]);
  assert.equal(document.querySelector("#site2json-attention-button").hidden, true);
  attention.sync("graph", []);
  attention.sync("graph", [issue]);
  assert.equal(document.querySelector("#site2json-attention-button").hidden, false);
});
