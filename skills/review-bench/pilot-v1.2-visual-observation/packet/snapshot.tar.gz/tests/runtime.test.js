"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Runtime = require("../extension/extract");

const root = path.resolve(__dirname, "..");
const definition = JSON.parse(fs.readFileSync(path.join(root, "reference-adapters/upwork-search.dsl.json"), "utf8"));
const fixture = fs.readFileSync(path.join(__dirname, "fixtures/upwork-search-results.html"), "utf8");

test("the production runtime compiles imported definitions and records their local origin", () => {
  const dom = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/?q=python" });
  const result = Runtime.extract([definition], dom.window.document, dom.window.location);
  assert.equal(result.ok, true);
  assert.equal(result.document.extraction.adapter, "upwork");
  assert.equal(result.document.extraction.adapterSource, "local-file");
  assert.equal(result.document.blocks[0].entities.length, 2);
  dom.window.close();
});

test("the production runtime reports an empty local registry explicitly", () => {
  const dom = new JSDOM("<!doctype html><title>Example</title>", { url: "https://example.com/" });
  assert.deepEqual(Runtime.extract([], dom.window.document, dom.window.location), { ok: false, reason: "no-adapters" });
  dom.window.close();
});
