"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Dsl = require("../extension/core/dsl");
const Exporters = require("../extension/core/exporters");
const Model = require("../extension/core/model");
const Upwork = require("../reference-adapters/upwork");

const root = path.resolve(__dirname, "..");
const definition = JSON.parse(fs.readFileSync(path.join(root, "reference-adapters/upwork-search.dsl.json"), "utf8"));
const fixture = fs.readFileSync(path.join(__dirname, "fixtures/upwork-search-results.html"), "utf8");
const capturedSearchFixtures = [{
  html: fs.readFileSync(path.join(__dirname, "fixtures/upwork-search-captured-page-1.html"), "utf8"),
  page: 1,
  cards: 7
}, {
  html: fs.readFileSync(path.join(__dirname, "fixtures/upwork-search-captured-page-2.html"), "utf8"),
  page: 2,
  cards: 10
}];
const detailFixture = fs.readFileSync(path.join(__dirname, "fixtures/upwork-job-detail.html"), "utf8");
const panelFixture = fs.readFileSync(path.join(__dirname, "fixtures/upwork-job-panel.html"), "utf8");

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

test("strict DSL validation accepts the vertical-slice adapter", () => {
  const validated = Dsl.validateDefinition(definition);
  assert.equal(validated.adapter, "upwork");
  assert.equal(validated.dslVersion, Dsl.DSL_VERSION);
  assert.notEqual(validated, definition);
});

test("a semantic field can be the single source of truth for entity identity", () => {
  const linkedIdentity = {
    adapter: "example", version: 1, dslVersion: 1, namespace: "https://example.com/#", hosts: ["example.com"],
    entities: {
      Job: {
        schemaType: "JobPosting",
        identity: { field: "url" },
        fields: {
          url: { selectors: ["h2 a@href"], transform: ["absoluteUrl", "stripQuery"] },
          title: { selectors: ["h2"], transform: ["text", "trim"] }
        }
      }
    },
    pages: [{
      id: "jobs", match: { host: ["example.com"], path: [{ mode: "exact", value: "/jobs" }] }, pageType: "SearchResultsPage",
      blocks: [{ entity: "Job", scope: "article", arity: "many", role: "collection", fidelity: "summary" }]
    }]
  };
  const dom = new JSDOM('<article><h2><a href="/jobs/42?tracking=x">Engineer</a></h2></article>', { url: "https://example.com/jobs" });
  const result = Dsl.compile(linkedIdentity).extract(dom.window.document, new URL(dom.window.location.href));
  assert.deepEqual(result.blocks[0].entities[0], {
    "@type": "JobPosting", "@id": "https://example.com/jobs/42", url: "https://example.com/jobs/42", title: "Engineer"
  });
  const missing = clone(linkedIdentity);
  missing.entities.Job.identity.field = "identifier";
  assert.throws(() => Dsl.validateDefinition(missing), /references unknown field identifier/i);
  dom.window.close();
});

test("validates inert adapter-local vocabulary declarations", () => {
  const withVocabulary = clone(definition);
  withVocabulary.vocabulary = { terms: {
    "upwork:budget": { description: "Marketplace project budget.", valueType: "Object", cardinality: "one", example: "$500" }
  } };
  assert.equal(Dsl.validateDefinition(withVocabulary).vocabulary.terms["upwork:budget"].valueType, "Object");
  withVocabulary.vocabulary.terms["upwork:editor"] = {
    description: "The person responsible for editing the listing.", valueType: "Person", cardinality: "one", example: "Jane",
    kind: "relationship", domainIncludes: ["JobPosting"], rangeIncludes: ["Person"], evidenceAliases: ["editor", "edited by"]
  };
  assert.equal(Dsl.validateDefinition(withVocabulary).vocabulary.terms["upwork:editor"].kind, "relationship");
  const incompleteRelationship = clone(withVocabulary);
  delete incompleteRelationship.vocabulary.terms["upwork:editor"].rangeIncludes;
  assert.throws(() => Dsl.validateDefinition(incompleteRelationship), /requires domainIncludes and rangeIncludes/i);
  const wrongPrefix = clone(withVocabulary);
  wrongPrefix.vocabulary.terms["guru:budget"] = wrongPrefix.vocabulary.terms["upwork:budget"];
  assert.throws(() => Dsl.validateDefinition(wrongPrefix), /must use the adapter prefix/i);
  const withCustomType = clone(withVocabulary);
  withCustomType.vocabulary.terms["upwork:Editor"] = {
    description: "A site-specific person type for listing editors.", valueType: "upwork:Editor", cardinality: "one", example: "Editor",
    kind: "type", supers: ["Person"]
  };
  assert.equal(Dsl.validateDefinition(withCustomType).vocabulary.terms["upwork:Editor"].kind, "type");
  const invalidKind = clone(withVocabulary);
  invalidKind.vocabulary.terms["upwork:budget"].kind = "type-o";
  assert.throws(() => Dsl.validateDefinition(invalidKind), /kind must be field, relationship, or type/i);
  const executableShape = clone(withVocabulary);
  executableShape.vocabulary.terms["upwork:budget"].code = "return value";
  assert.throws(() => Dsl.validateDefinition(executableShape), /unknown vocabulary term .* key: code/i);
});

test("strict DSL validation rejects executable, unknown, and unavailable behavior", () => {
  const topLevelLogic = { ...clone(definition), script: "extract()" };
  assert.throws(() => Dsl.validateDefinition(topLevelLogic), /unknown adapter key: script/i);

  const fieldLogic = clone(definition);
  fieldLogic.entities.JobPosting.fields.title.condition = "value.length > 0";
  assert.throws(() => Dsl.validateDefinition(fieldLogic), /unknown .* key: condition/i);

  const unknownTransform = clone(definition);
  unknownTransform.entities.JobPosting.fields.title.transform = ["runAdapterCode"];
  assert.throws(() => Dsl.validateDefinition(unknownTransform), /requires transform runAdapterCode, which is not available/i);

  const widerHost = clone(definition);
  widerHost.pages[0].match.host = ["mail.example.com"];
  assert.throws(() => Dsl.validateDefinition(widerHost), /host outside adapter\.hosts/i);

  const regexPath = clone(definition);
  regexPath.pages[0].match.path = [{ mode: "exact", value: "/nx/search/jobs.*" }];
  assert.throws(() => Dsl.validateDefinition(regexPath), /literal path, not a pattern/i);

  const stringPath = clone(definition);
  stringPath.pages[0].match.path = "^/nx/search/jobs";
  assert.throws(() => Dsl.validateDefinition(stringPath), /array of path rules/i);

  const unsafeField = clone(definition);
  unsafeField.entities.JobPosting.fields["upwork:client.__proto__.value"] = unsafeField.entities.JobPosting.fields.title;
  assert.throws(() => Dsl.validateDefinition(unsafeField), /not a safe field path/i);

  const unavailablePageSource = clone(definition);
  unavailablePageSource.pages.find((page) => page.id === "search-results").metadata.collectionKey.source = "documentJavaScript";
  assert.throws(() => Dsl.validateDefinition(unavailablePageSource), /source is not available/i);
});

test("the declarative Upwork slice extracts canonical identity and common fields", () => {
  const dom = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/?q=python" });
  const adapter = Dsl.compile(definition);
  const url = new URL(dom.window.location.href);
  assert.equal(adapter.match(url, dom.window.document), true);
  const result = Model.assemble(adapter, adapter.extract(dom.window.document, url), url.href);
  assert.equal(result.extraction.adapter, "upwork");
  assert.equal(result.extraction.pageType, "SearchResultsPage");
  assert.equal(result.extraction.quality.requiredFieldCoverage, 1);
  assert.equal(result.extraction.quality.monitoredFieldCoverage, 0.7);
  assert.deepEqual(result.blocks[0].monitor, [
    "description",
    "upwork:postedText",
    "upwork:budget",
    "upwork:experienceLevel",
    "skills",
    "upwork:client.payment_verified",
    "upwork:client.rating",
    "upwork:client.total_spend_text",
    "upwork:client.location",
    "upwork:activity.proposal_count_text"
  ]);
  assert.equal(result.blocks[0].entities.length, 2);
  assert.deepEqual(result.blocks[0].entities.map((entity) => ({
    url: entity.url,
    title: entity.title,
    description: entity.description,
    skills: entity.skills
  })), [{
    url: "https://www.upwork.com/jobs/~0123456789abcdef",
    title: "Clean several CSV files with Python",
    description: "Deduplicate and normalize several exported CSV files.",
    skills: ["Python", "pandas"]
  }, {
    url: "https://www.upwork.com/jobs/~0fedcba987654321",
    title: "Geocode addresses",
    description: "Convert a spreadsheet of addresses to coordinates.",
    skills: ["Geocoding"]
  }]);
  dom.window.close();
});

test("dotted DSL fields materialize safe nested records", () => {
  const dom = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/?q=python" });
  const observation = Dsl.compile(definition).extract(dom.window.document, new URL(dom.window.location.href));
  const [entity] = observation.blocks[0].entities;
  assert.deepEqual(entity["upwork:client"], {
    payment_verified: true,
    rating: null,
    total_spend_text: null,
    location: "United States"
  });
  assert.deepEqual(entity["upwork:activity"], {
    proposal_count_text: "5 to 10",
    interviewing: null,
    invites_sent: null
  });
  dom.window.close();
});

test("page bindings normalize collection identity, snapshots, and logical position", () => {
  const adapter = Dsl.compile(definition);
  const firstDom = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/?q=python&sort=recency" });
  const thirdDom = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/?sort=recency&page=3&q=python&from_recent_search=true" });
  const first = adapter.extract(firstDom.window.document, new URL(firstDom.window.location.href));
  const third = adapter.extract(thirdDom.window.document, new URL(thirdDom.window.location.href));
  assert.equal(first.collectionKey, third.collectionKey);
  assert.notEqual(first.snapshotKey, third.snapshotKey);
  assert.equal(third.logicalPosition, 3);
  assert.deepEqual(third.page.searchParameters, {
    from_recent_search: ["true"], page: ["3"], q: ["python"], sort: ["recency"]
  });
  firstDom.window.close();
  thirdDom.window.close();
});

test("declarative blocks deduplicate repeated canonical identities", () => {
  const repeated = fixture.replace("</main>", `${fixture.match(/<article data-test="JobTile">[\s\S]*?<\/article>/)[0]}</main>`);
  const dom = new JSDOM(repeated, { url: "https://www.upwork.com/nx/search/jobs/?q=python" });
  const observation = Dsl.compile(definition).extract(dom.window.document, new URL(dom.window.location.href));
  assert.equal(observation.blocks[0].entities.length, 2);
  assert.deepEqual(observation.warnings, [{ code: "entity.duplicate", count: 1, block: "search-results" }]);
  dom.window.close();
});

function variantDefinition() {
  const identity = { canonicalUrl: { selectors: ["a@href"], transform: ["absoluteUrl", "stripQuery"] } };
  const fields = { name: { selectors: ["h2"], transform: ["text", "trim"] } };
  return {
    adapter: "mixed", version: 1, dslVersion: 1, namespace: "https://example.com/mixed#", hosts: ["example.com"],
    entities: {
      Result: { schemaType: "Thing", identity, fields },
      PersonResult: { schemaType: "Person", identity, fields },
      ProjectResult: { schemaType: "Project", identity, fields }
    },
    pages: [{
      id: "search", match: { host: ["example.com"], path: [{ mode: "exact", value: "/search" }] }, pageType: "SearchResultsPage",
      blocks: [{
        entity: "Result", scope: ".result", arity: "many", role: "collection", fidelity: "summary",
        variants: {
          fallback: "Result", minScore: 1, minMargin: 1,
          candidates: [
            { entity: "PersonResult", signals: [], evidence: [{ selector: ".person", weight: 10 }] },
            { entity: "ProjectResult", signals: [], evidence: [{ selector: ".project", weight: 10 }] }
          ]
        }
      }]
    }]
  };
}

test("variant blocks classify each repeated scope against a bounded deterministic candidate set", () => {
  const dom = new JSDOM(`
    <div class="result person"><a href="/people/1"><h2>Ada</h2></a></div>
    <div class="result project"><a href="/projects/2"><h2>Apollo</h2></a></div>
    <div class="result person project"><a href="/search/3"><h2>Ambiguous</h2></a></div>
  `, { url: "https://example.com/search" });
  const observation = Dsl.compile(variantDefinition()).extract(dom.window.document, new URL(dom.window.location.href));
  assert.deepEqual(observation.blocks[0].entities.map((entity) => entity["@type"]), ["Person", "Project", "Thing"]);
  assert.deepEqual(observation.blocks[0].variants, {
    counts: { PersonResult: 1, ProjectResult: 1, Result: 1 },
    ambiguous: 1
  });
  assert.ok(observation.warnings.some((warning) => warning.code === "variant.ambiguous" && warning.count === 1));
  dom.window.close();
});

test("variant reports fingerprint matched shape separately from candidate configuration", () => {
  const configured = Dsl.validateDefinition(variantDefinition());
  const slot = configured.pages[0].blocks[0].variants;
  const dom = new JSDOM(`
    <div class="result person"><a href="/people/1"><h2>Ada</h2></a></div>
    <div class="result person"><a href="/people/2"><h2>Grace</h2></a></div>
    <div class="result project"><a href="/projects/3"><h2>Apollo</h2></a></div>
  `, { url: "https://example.com/search" });
  const scopes = dom.window.document.querySelectorAll(".result");
  const first = Dsl.classifyVariant(scopes[0], slot, configured, { pageUrl: dom.window.location.href }).classification;
  const reorderedEquivalent = Dsl.classifyVariant(scopes[1], slot, configured, { pageUrl: dom.window.location.href }).classification;
  const changedShape = Dsl.classifyVariant(scopes[2], slot, configured, { pageUrl: dom.window.location.href }).classification;
  const changedThreshold = Dsl.classifyVariant(scopes[0], { ...slot, minMargin: slot.minMargin + 1 }, configured, { pageUrl: dom.window.location.href }).classification;
  assert.equal(first.classificationFingerprint, reorderedEquivalent.classificationFingerprint);
  assert.notEqual(first.classificationFingerprint, changedShape.classificationFingerprint);
  assert.equal(first.configurationDigest, reorderedEquivalent.configurationDigest);
  assert.notEqual(first.configurationDigest, changedThreshold.configurationDigest);
  dom.window.close();
});

test("variant blocks classify from extracted semantic shape without explicit page evidence", () => {
  const shaped = variantDefinition();
  shaped.entities.PersonResult.fields = {
    ...shaped.entities.PersonResult.fields,
    email: { selectors: [".email"], transform: ["text", "trim"] }
  };
  shaped.entities.ProjectResult.fields = {
    ...shaped.entities.ProjectResult.fields,
    skills: { selectors: [".skills"], transform: ["text", "trim"] }
  };
  shaped.pages[0].blocks[0].variants.candidates = [
    { entity: "PersonResult", signals: [{ field: "email", kind: "field", weight: 10 }], evidence: [] },
    { entity: "ProjectResult", signals: [{ field: "skills", kind: "field", weight: 10 }], evidence: [] }
  ];
  shaped.pages[0].blocks[0].fields = ["name"];
  const dom = new JSDOM(`
    <div class="result"><a href="/people/1"><h2>Ada</h2></a><span class="email">ada@example.com</span></div>
    <div class="result"><a href="/projects/2"><h2>Apollo</h2></a><span class="skills">JavaScript</span></div>
  `, { url: "https://example.com/search" });
  const observation = Dsl.compile(shaped).extract(dom.window.document, new URL(dom.window.location.href));
  assert.deepEqual(observation.blocks[0].entities.map((entity) => entity["@type"]), ["Person", "Project"]);
  assert.deepEqual(observation.blocks[0].variants, { counts: { PersonResult: 1, ProjectResult: 1 }, ambiguous: 0 });
  dom.window.close();
});

test("variant evidence can inspect an attribute without extracting it", () => {
  const withProbe = variantDefinition();
  withProbe.pages[0].blocks[0].variants.candidates = [{
    entity: "PersonResult", signals: [],
    evidence: [{ selector: ":scope", attribute: "data-type", equals: "Person", weight: 10 }]
  }];
  const dom = new JSDOM('<div class="result" data-type="Person"><a href="/people/1"><h2>Ada</h2></a></div>', { url: "https://example.com/search" });
  const observation = Dsl.compile(withProbe).extract(dom.window.document, new URL(dom.window.location.href));
  assert.equal(observation.blocks[0].entities[0]["@type"], "Person");
  assert.equal(Object.hasOwn(observation.blocks[0].entities[0], "data-type"), false);
  dom.window.close();
});

test("nested variant slots preserve a ListItem wrapper while classifying its item", () => {
  const nested = {
    adapter: "mixed-list", version: 1, dslVersion: 1, namespace: "https://example.com/mixed#", hosts: ["example.com"],
    entities: {
      ListEntry: { schemaType: "ListItem", identity: { field: "url" }, fields: { url: { selectors: ["a@href"], transform: ["absoluteUrl"] }, position: { selectors: [".position"], transform: ["text", "trim"] } } },
      ThingItem: { schemaType: "Thing", identity: { field: "url" }, fields: { url: { selectors: ["a@href"], transform: ["absoluteUrl"] }, name: { selectors: ["h2"], transform: ["text", "trim"] } } },
      ArticleItem: { schemaType: "Article", identity: { field: "url" }, fields: { url: { selectors: ["a@href"], transform: ["absoluteUrl"] }, name: { selectors: ["h2"], transform: ["text", "trim"] } } },
      JobItem: { schemaType: "JobPosting", identity: { field: "url" }, fields: { url: { selectors: ["a@href"], transform: ["absoluteUrl"] }, name: { selectors: ["h2"], transform: ["text", "trim"] } } }
    },
    pages: [{ id: "search", match: { host: ["example.com"], path: [{ mode: "exact", value: "/search" }] }, pageType: "SearchResultsPage", blocks: [{
      entity: "ListEntry", scope: "li", arity: "many", role: "collection", fidelity: "summary",
      variantSlots: [{ path: "item", fallback: "ThingItem", minScore: 1, minMargin: 1, candidates: [
        { entity: "ArticleItem", signals: [], evidence: [{ selector: ".article", weight: 10 }] },
        { entity: "JobItem", signals: [], evidence: [{ selector: ".job", weight: 10 }] }
      ] }]
    }] }]
  };
  const dom = new JSDOM('<ol><li class="article"><span class="position">1</span><a href="/a"><h2>Guide</h2></a></li><li class="job"><span class="position">2</span><a href="/j"><h2>Engineer</h2></a></li></ol>', { url: "https://example.com/search" });
  const block = Dsl.compile(nested).extract(dom.window.document, new URL(dom.window.location.href)).blocks[0];
  assert.equal(block.entities[0]["@type"], "ListItem");
  assert.equal(block.entities[0].position, "1");
  assert.equal(block.entities[0].item["@type"], "Article");
  assert.equal(block.entities[1].item["@type"], "JobPosting");
  assert.deepEqual(block.variantSlots, [{ path: "item", counts: { ArticleItem: 1, JobItem: 1 }, ambiguous: 0 }]);
  nested.pages[0].blocks[0].structuralBaseline = Dsl.captureStructuralBaselines(nested, dom.window.document, new URL(dom.window.location.href))[0];
  dom.window.close();
  const redesigned = new JSDOM('<ol><li><a href="/a">Guide</a></li><li><a href="/j">Engineer</a></li></ol>', { url: "https://example.com/search" });
  const drifted = Dsl.compile(nested).extract(redesigned.window.document, new URL(redesigned.window.location.href));
  assert.ok(drifted.warnings.some((warning) => warning.code === "variant.classificationDrift" && warning.path === "item" && warning.variant === "ArticleItem"));
  assert.ok(drifted.warnings.some((warning) => warning.code === "variant.classificationDrift" && warning.path === "item" && warning.variant === "JobItem"));
  redesigned.window.close();
});

test("nested variant slots can classify relationship targets from their semantic shape", () => {
  const nested = {
    adapter: "shape-list", version: 1, dslVersion: 1, namespace: "https://example.com/shape#", hosts: ["example.com"],
    entities: {
      ListEntry: { schemaType: "ListItem", identity: { field: "url" }, fields: { url: { selectors: ["a@href"], transform: ["absoluteUrl"] } } },
      ThingItem: { schemaType: "Thing", identity: { field: "url" }, fields: { url: { selectors: ["a@href"], transform: ["absoluteUrl"] } } },
      ArticleItem: { schemaType: "Article", identity: { field: "url" }, fields: { url: { selectors: ["a@href"], transform: ["absoluteUrl"] }, articleBody: { selectors: [".article-body"], transform: ["text", "trim"] } } },
      JobItem: { schemaType: "JobPosting", identity: { field: "url" }, fields: { url: { selectors: ["a@href"], transform: ["absoluteUrl"] }, employmentType: { selectors: [".employment-type"], transform: ["text", "trim"] } } }
    },
    pages: [{ id: "search", match: { host: ["example.com"], path: [{ mode: "exact", value: "/search" }] }, pageType: "SearchResultsPage", blocks: [{
      entity: "ListEntry", scope: "li", arity: "many", role: "collection", fidelity: "summary",
      variantSlots: [{ path: "item", fallback: "ThingItem", minScore: 6, minMargin: 2, candidates: [
        { entity: "ArticleItem", signals: [{ field: "articleBody", kind: "field", weight: 10 }], evidence: [] },
        { entity: "JobItem", signals: [{ field: "employmentType", kind: "field", weight: 10 }], evidence: [] }
      ] }]
    }] }]
  };
  const dom = new JSDOM('<ol><li><a href="/a">Guide</a><p class="article-body">Long guide</p></li><li><a href="/j">Engineer</a><span class="employment-type">Full time</span></li></ol>', { url: "https://example.com/search" });
  const block = Dsl.compile(nested).extract(dom.window.document, new URL(dom.window.location.href)).blocks[0];
  assert.deepEqual(block.entities.map((entity) => entity.item["@type"]), ["Article", "JobPosting"]);
  assert.deepEqual(block.variantSlots, [{ path: "item", counts: { ArticleItem: 1, JobItem: 1 }, ambiguous: 0 }]);
  dom.window.close();
});

test("variant validation rejects unbounded, unknown, and non-deterministic declarations", () => {
  const unknown = variantDefinition();
  unknown.pages[0].blocks[0].variants.candidates[0].entity = "Missing";
  assert.throws(() => Dsl.validateDefinition(unknown), /unknown entity Missing/i);

  const unbounded = variantDefinition();
  unbounded.pages[0].blocks[0].variants.candidates = Array.from({ length: 6 }, (_value, index) => ({
    entity: index % 2 ? "PersonResult" : "ProjectResult", signals: [], evidence: [{ selector: `.type-${index}`, weight: 1 }]
  }));
  assert.throws(() => Dsl.validateDefinition(unbounded), /between 1 and 5/i);

  const invalidRule = variantDefinition();
  invalidRule.pages[0].blocks[0].variants.candidates[0].evidence[0].field = "name";
  assert.throws(() => Dsl.validateDefinition(invalidRule), /exactly one selector or field/i);

  const incompleteProbe = variantDefinition();
  incompleteProbe.pages[0].blocks[0].variants.candidates[0].evidence[0].attribute = "alt";
  assert.throws(() => Dsl.validateDefinition(incompleteProbe), /attribute and \.equals/i);
});

test("the declarative search adapter is fully equivalent to the imperative fixture observation", () => {
  const dom = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/?q=python" });
  const url = new URL(dom.window.location.href);
  const declarative = Dsl.compile(definition).extract(dom.window.document, url);
  const imperative = Upwork.extract(dom.window.document, url);
  assert.deepEqual(declarative, imperative);
  dom.window.close();
});

test("both scrubbed real-page Upwork captures retain card counts and exact declarative parity", () => {
  const adapter = Dsl.compile(definition);
  for (const captured of capturedSearchFixtures) {
    const href = `https://www.upwork.com/nx/search/jobs/?q=automation&sort=recency&page=${captured.page}`;
    const dom = new JSDOM(captured.html, { url: href });
    const url = new URL(href);
    assert.equal(dom.window.document.querySelectorAll('[data-test="JobTile"]').length, captured.cards);
    const declarative = adapter.extract(dom.window.document, url);
    assert.equal(declarative.blocks[0].entities.length, captured.cards);
    assert.deepEqual(declarative, Upwork.extract(dom.window.document, url));
    const assembled = Model.assemble(adapter, declarative, url.href);
    assert.equal(assembled.extraction.quality.requiredFieldCoverage, 1);
    assert.ok(assembled.extraction.quality.monitoredFieldCoverage >= 0.6);
    assert.ok(assembled.extraction.warnings.length <= 10);
    dom.window.close();
  }
});

test("captured-page Compact JSON omits raw card text and stays materially smaller", () => {
  const adapter = Dsl.compile(definition);
  for (const captured of capturedSearchFixtures) {
    const href = `https://www.upwork.com/nx/search/jobs/?q=automation&page=${captured.page}`;
    const dom = new JSDOM(captured.html, { url: href });
    const url = new URL(href);
    const assembled = Model.assemble(adapter, adapter.extract(dom.window.document, url), url.href);
    const compact = Exporters.compact(assembled);
    const withRawText = Exporters.compact(assembled, { includeRawText: true });
    assert.ok(compact.jobs.every((job) => job.raw_text === undefined));
    assert.ok(JSON.stringify(compact).length <= JSON.stringify(withRawText).length * 0.8);
    dom.window.close();
  }
});

test("captured-page regression preserves scoped budgets when descriptions contain dollar ranges", () => {
  const captured = capturedSearchFixtures[1];
  const href = "https://www.upwork.com/nx/search/jobs/?q=automation&page=2";
  const dom = new JSDOM(captured.html, { url: href });
  const observation = Dsl.compile(definition).extract(dom.window.document, new URL(href));
  const adversarial = observation.blocks[0].entities.find((entity) => entity.description?.includes("$10-$12"));
  assert.ok(adversarial);
  assert.equal(adversarial["upwork:budget"].type, "fixed");
  assert.notEqual(adversarial["upwork:budget"].amount, 10);
  const hourly = observation.blocks[0].entities.find((entity) => entity["upwork:duration"] && entity["upwork:weeklyHours"]);
  assert.ok(hourly);
  assert.equal(hourly["upwork:budget"].type, "hourly");
  dom.window.close();
});

test("both captured-derived Upwork fixtures omit raw identity and executable implementation artifacts", () => {
  for (const captured of capturedSearchFixtures) {
    assert.doesNotMatch(captured.html, /data-v-|<style|<svg|<iframe|https?:\/\//i);
    assert.doesNotMatch(captured.html, /<script(?![^>]*type="application\/ld\+json")/i);
    assert.doesNotMatch(captured.html, /022\d{15,}|[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}/i);
    assert.match(captured.html, /Example captured job 1/);
  }
});

test("the declarative standalone detail page is fully equivalent to the imperative fixture observation", () => {
  const dom = new JSDOM(detailFixture, { url: "https://www.upwork.com/jobs/~0123456789abcdef/?source=search" });
  const url = new URL(dom.window.location.href);
  const declarative = Dsl.compile(definition).extract(dom.window.document, url);
  const imperative = Upwork.extract(dom.window.document, url);
  assert.deepEqual(declarative, imperative);
  dom.window.close();
});

test("the declarative job panel is fully equivalent on routed and retained search URLs", () => {
  for (const href of [
    "https://www.upwork.com/nx/search/jobs/details/~012345678901234567890?q=design",
    "https://www.upwork.com/nx/search/jobs/?q=design"
  ]) {
    const dom = new JSDOM(panelFixture, { url: href });
    const url = new URL(dom.window.location.href);
    const declarative = Dsl.compile(definition).extract(dom.window.document, url);
    const imperative = Upwork.extract(dom.window.document, url);
    assert.deepEqual(declarative, imperative);
    dom.window.close();
  }
});

test("ordered selector fallbacks use the first selector that matches", () => {
  const changed = fixture.replace("data-test=\"job-tile-title\"", "data-test=\"renamed-title\"");
  const dom = new JSDOM(changed, { url: "https://www.upwork.com/nx/search/jobs/" });
  const adapter = Dsl.compile(definition);
  const result = adapter.extract(dom.window.document, new URL(dom.window.location.href));
  assert.equal(result.blocks[0].entities[0].title, "Clean several CSV files with Python");
  dom.window.close();
});

test("XPath selectors are evaluated inside each declared block scope", () => {
  const xpathDefinition = clone(definition);
  xpathDefinition.entities.JobPosting.fields.title.selectors = ["xpath:.//h2/a"];
  const dom = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/" });
  const result = Dsl.compile(xpathDefinition).extract(dom.window.document, new URL(dom.window.location.href));
  assert.deepEqual(result.blocks[0].entities.map((entity) => entity.title), ["Clean several CSV files with Python", "Geocode addresses"]);
  dom.window.close();
});

test("bindings cannot leak untransformed DOM nodes into extracted data", () => {
  const unsafeDefinition = clone(definition);
  unsafeDefinition.entities.JobPosting.fields.title.transform = [];
  const dom = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/" });
  assert.throws(() => Dsl.compile(unsafeDefinition).extract(dom.window.document, new URL(dom.window.location.href)), /produced a non-data value/i);
  dom.window.close();
});

test("missing canonical identity omits the entity and produces a visible warning", () => {
  const noLinks = fixture.replaceAll(/<a href=[^>]+>([^<]+)<\/a>/g, "$1");
  const dom = new JSDOM(noLinks, { url: "https://www.upwork.com/nx/search/jobs/" });
  const adapter = Dsl.compile(definition);
  const observation = adapter.extract(dom.window.document, new URL(dom.window.location.href));
  assert.equal(observation.blocks[0].entities.length, 0);
  assert.deepEqual(observation.warnings.find((warning) => warning.code === "entity.identityMissing"), {
    code: "entity.identityMissing", count: 2, block: "search-results"
  });
  dom.window.close();
});

test("page matching claims known routes and extraction fails loudly when the rendered component is absent", () => {
  const adapter = Dsl.compile(definition);
  const missing = new JSDOM("<main></main>", { url: "https://www.upwork.com/nx/search/jobs/" });
  const missingUrl = new URL(missing.window.location.href);
  assert.equal(adapter.match(missingUrl, missing.window.document), true);
  assert.throws(() => adapter.extract(missing.window.document, missingUrl), /No declarative page binding matched/i);
  const foreign = new JSDOM(fixture, { url: "https://example.com/nx/search/jobs/" });
  assert.equal(adapter.match(new URL(foreign.window.location.href), foreign.window.document), false);
  missing.window.close();
  foreign.window.close();
});

test("path matching uses constrained exact and prefix rules", () => {
  const prefixDefinition = clone(definition);
  prefixDefinition.pages[0].match.path = [{ mode: "prefix", value: "/nx/search" }];
  const adapter = Dsl.compile(prefixDefinition);
  const matching = new JSDOM(fixture, { url: "https://www.upwork.com/nx/search/jobs/" });
  const adjacent = new JSDOM(fixture, { url: "https://www.upwork.com/nx/searching/jobs/" });
  assert.equal(adapter.match(new URL(matching.window.location.href), matching.window.document), true);
  assert.equal(adapter.match(new URL(adjacent.window.location.href), adjacent.window.document), false);
  matching.window.close();
  adjacent.window.close();
});
