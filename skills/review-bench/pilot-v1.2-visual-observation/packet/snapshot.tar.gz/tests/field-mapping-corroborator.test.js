"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Corroborator = require("../extension/authoring/field-mapping-corroborator");
const Profile = require("../extension/authoring/type-extraction-profile");

function ranked(type, candidate, options) {
  return Profile.suggestions(Profile.build(type), candidate, options);
}

test("accepts a field when independent lexical, structural, population, and margin evidence agree", () => {
  const candidate = {
    selector: ".job-title", suggestedName: "title", kind: "text", attribute: null, multiple: false,
    coverage: { present: 20, sampled: 20 }, sampleValues: ["Engineer", "Designer"],
    evidence: { tag: "h2", classes: ["job-title"], context: "article job card", matchCounts: Array(20).fill(1), text: "Engineer" }
  };
  const decision = Corroborator.corroborate(candidate, ranked("JobPosting", candidate));
  assert.equal(decision.accepted, true);
  assert.equal(decision.term.name, "title");
  assert.equal(decision.confidence, "strong");
  assert.deepEqual(decision.report.signals.map((signal) => signal.kind), ["lexical", "structure", "population"]);
  assert.ok(decision.report.margin >= 4);
});

test("keeps an unlabeled heading unresolved when title, headline, and name remain ambiguous", () => {
  const candidate = {
    selector: "h2", suggestedName: "field", kind: "text", attribute: null, multiple: false,
    coverage: { present: 10, sampled: 10 }, sampleValues: ["First", "Second"],
    evidence: { tag: "h2", classes: [], context: "article", matchCounts: Array(10).fill(1), text: "First" }
  };
  const decision = Corroborator.corroborate(candidate, ranked("CreativeWork", candidate));
  assert.equal(decision.accepted, false);
  assert.equal(decision.confidence, "weak");
  assert.match(decision.report.reasons.join(" "), /safe margin/i);
});

test("rejects subordinate action, skill, and avatar evidence as direct entity URL or image mappings", () => {
  const apply = {
    selector: ".apply-link", suggestedName: "url", kind: "url", attribute: "href", multiple: false,
    coverage: { present: 20, sampled: 20 }, sampleValues: ["/apply/1", "/apply/2"],
    evidence: { tag: "a", classes: ["apply-link"], context: "actions apply", href: "/apply/1", matchCounts: Array(20).fill(1) }
  };
  const applyDecision = Corroborator.corroborate(apply, ranked("JobPosting", apply));
  assert.notEqual(applyDecision.term?.name, "url");

  const skills = {
    selector: ".skillsList__skill", suggestedName: "url", kind: "url", attribute: "href", multiple: true,
    coverage: { present: 20, sampled: 20 }, sampleValues: [["/skills/js", "/skills/css"]],
    evidence: { tag: "a", classes: ["skillsList__skill"], context: "skills tags", href: "/skills/js", multiple: true, matchCounts: Array(20).fill(2) }
  };
  const skillDecision = Corroborator.corroborate(skills, ranked("JobPosting", skills));
  assert.notEqual(skillDecision.term?.name, "url");

  const avatar = {
    selector: ".avatarinfo", suggestedName: "avatarinfo", kind: "text", attribute: null, multiple: false,
    coverage: { present: 20, sampled: 20 }, sampleValues: ["Chris K Australia"],
    evidence: { tag: "div", classes: ["avatarinfo"], context: "client profile", matchCounts: Array(20).fill(1), text: "Chris K Australia" }
  };
  const avatarDecision = Corroborator.corroborate(avatar, ranked("JobPosting", avatar));
  assert.notEqual(avatarDecision.term?.name, "image");
});

test("lets a locally installed exact property outrank a generic URL shape", () => {
  const candidate = {
    selector: ".portfolio-link", suggestedName: "url", kind: "url", attribute: "href", multiple: false,
    coverage: { present: 8, sampled: 8 }, sampleValues: ["/work/1", "/work/2"],
    evidence: { tag: "a", classes: ["portfolio-link"], context: "editor portfolio", href: "/work/1", matchCounts: Array(8).fill(1) }
  };
  const suggestions = [
    {
      name: "site:portfolio", source: "extension", score: 38, valueType: "URL", cardinality: "one",
      aliases: ["portfolio"], vocabularyTerm: { evidenceAliases: ["portfolio"], valueType: "URL", cardinality: "one" }
    },
    { name: "url", source: "schema", score: 42, valueType: "URL", cardinality: "one", aliases: ["url"] }
  ];
  const decision = Corroborator.corroborate(candidate, suggestions);
  assert.equal(decision.accepted, true);
  assert.equal(decision.term.name, "site:portfolio");
  assert.equal(decision.confidence, "strong");
  assert.equal(decision.report.runnerUp.property, "url");
});

test("accepts value-shape plus population evidence for an absolute date", () => {
  const candidate = {
    selector: ".posted", suggestedName: "date", kind: "text", attribute: null, multiple: false,
    coverage: { present: 6, sampled: 6 }, sampleValues: ["Aug 13, 2026", "Aug 14, 2026"],
    evidence: { tag: "strong", classes: ["posted"], context: "job meta", text: "Aug 13, 2026", matchCounts: Array(6).fill(1) }
  };
  const decision = Corroborator.corroborate(candidate, ranked("JobPosting", candidate));
  assert.equal(decision.accepted, true);
  assert.equal(decision.term.name, "datePosted");
  assert.ok(decision.report.signals.some((signal) => signal.kind === "value"));
  assert.ok(decision.report.signals.some((signal) => signal.kind === "population"));
});

test("does not count incoming suggestion scores as an independent evidence family", () => {
  const candidate = {
    selector: ".label", suggestedName: "name", kind: "text", attribute: null, multiple: false,
    coverage: { present: 1, sampled: 1 }, sampleValues: ["Ada"],
    evidence: { tag: "span", classes: ["label"], context: "profile", text: "Ada", matchCounts: [1] }
  };
  const inflated = Corroborator.corroborate(candidate, [{
    name: "name", source: "extension", score: 1000, valueType: "Text", cardinality: "one", aliases: ["name"]
  }]);
  const neutral = Corroborator.corroborate(candidate, [{
    name: "name", source: "extension", score: 0, valueType: "Text", cardinality: "one", aliases: ["name"]
  }]);

  assert.equal(inflated.accepted, false);
  assert.equal(inflated.report.score, neutral.report.score);
  assert.deepEqual(inflated.report.signals, neutral.report.signals);
});

test("reports cardinality as an editable authoring-policy conflict, not a Schema.org constraint", () => {
  const candidate = {
    selector: ".titles", suggestedName: "title", kind: "text", attribute: null, multiple: true,
    coverage: { present: 5, sampled: 5 }, sampleValues: [["First", "Second"]],
    evidence: { tag: "h2", classes: ["titles"], context: "titles", text: "First", matchCounts: Array(5).fill(2) }
  };
  const decision = Corroborator.corroborate(candidate, [{
    name: "title", source: "schema", score: 999, valueType: "Text", cardinality: "one", aliases: ["title"]
  }]);

  assert.equal(decision.accepted, false);
  assert.equal(decision.report.authoring.cardinality.source, "site2json-authoring-default");
  assert.match(decision.report.reasons.join(" "), /not a Schema\.org constraint/i);
});
