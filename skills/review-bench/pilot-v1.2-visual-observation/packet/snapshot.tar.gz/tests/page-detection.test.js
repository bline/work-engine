"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Pipeline = require("../extension/ir/pipeline");
const SemanticAssignmentProfile = require("../extension/authoring/semantic-assignment-profile");

function profile(types) {
  return SemanticAssignmentProfile.compile({ candidateTypes: types });
}

test("overlap direction identifies the actual containing detection", () => {
  const document = new JSDOM(`<main><section><article>Result</article></section></main>`).window.document;
  const outer = { sources: [document.querySelector("main")] };
  const inner = { sources: [document.querySelector("article")] };
  const detection = require("../extension/ir/page-detection");
  assert.equal(detection.overlapKind(outer, inner), "left-contains-right");
  assert.equal(detection.overlapKind(inner, outer), "right-contains-left");
});

test("page survey collects bounded typeless observations before semantic classification", () => {
  const document = new JSDOM(`
    <main><ul>
      <li class="job-card"><h2><a href="/jobs/one">Ontology engineer</a></h2><p>Build semantic extraction infrastructure.</p><span>Posted yesterday</span></li>
      <li class="job-card"><h2><a href="/jobs/two">Visual systems engineer</a></h2><p>Build visual grouping infrastructure.</p><span>Posted 2 days ago</span></li>
    </ul></main>
  `, { url: "https://example.com/jobs" }).window.document;
  const survey = require("../extension/ir/page-detection").survey(document, { collection: { id: "survey" } });
  assert.ok(survey.candidateCount >= survey.candidates.length);
  assert.ok(survey.candidates.length > 0);
  const roles = new Set(survey.candidates.flatMap((candidate) => candidate.observed.tree.root.children.flatMap((entity) => entity.children.map((field) => field.role))));
  assert.equal(roles.has("title"), true);
  assert.equal(roles.has("url"), true);
  assert.equal(roles.has("datePosted"), true);
  assert.equal(survey.candidates.every((candidate) => candidate.observed.tree.root.children.every((entity) => entity.term === undefined)), true);
});

test("page detection selects multiple independent semantic groups and preserves overlapping alternatives", () => {
  const document = new JSDOM(`
    <main>
      <section data-testid="news-results">
        <article><h2><a href="/notes/one">Architecture note</a></h2><p>A detailed architecture note about extraction.</p><time class="published" datetime="2026-08-01"></time><span class="author">Ada</span></article>
        <article><h2><a href="/notes/two">Research note</a></h2><p>A detailed research note about extraction.</p><time class="published" datetime="2026-08-02"></time><span class="author">Bob</span></article>
      </section>
      <section data-testid="job-results">
        <article><h2><a href="/jobs/one">Ontology engineer</a></h2><p>Build semantic extraction infrastructure.</p><time class="posted" datetime="2026-08-03"></time><span class="employment">FULL_TIME</span></article>
        <article><h2><a href="/jobs/two">Visual systems engineer</a></h2><p>Build visual grouping infrastructure.</p><time class="posted" datetime="2026-08-04"></time><span class="employment">PART_TIME</span></article>
      </section>
    </main>
  `, { url: "https://example.com/mixed" }).window.document;

  const result = Pipeline.detectPage(document, { collection: { id: "page" } }, {
    profile: profile(["Article", "JobPosting", "Thing"])
  });

  assert.equal(result.summary.selectedCount, 2);
  assert.equal(result.summary.entityCount, 4);
  assert.equal(result.summary.acceptedEntityCount, 4);
  assert.equal(result.candidates.length, result.summary.candidateCount);
  assert.deepEqual(result.selected.map((detection) => detection.typeSignature), [
    ["https://schema.org/Article"],
    ["https://schema.org/JobPosting"]
  ]);
  assert.deepEqual(result.selected.flatMap((detection) => detection.output.data["@graph"]).map((entity) => entity["@type"]), [
    "Article", "Article", "JobPosting", "JobPosting"
  ]);
  const overlapping = result.candidates.find((candidate) => candidate.status === "alternative");
  assert.ok(overlapping);
  assert.deepEqual(overlapping.reasons, ["overlapping-alternative"]);
  assert.ok(overlapping.alternativeTo);
  assert.doesNotMatch(JSON.stringify(result.selected.map((detection) => detection.output)), /HTML\w*Element|querySelector|selector/i);
});

test("page detection keeps heterogeneous entity types inside one credible repeated group", () => {
  const document = new JSDOM(fs.readFileSync(path.join(__dirname, "fixtures", "v2-flat-heterogeneous-results.html"), "utf8")).window.document;
  const result = Pipeline.detectPage(document, { collection: { id: "flat-results" } }, {
    profile: profile(["Article", "JobPosting", "Product", "Thing"])
  });

  assert.equal(result.summary.selectedCount, 1);
  assert.deepEqual(result.selected[0].typeSignature, [
    "https://schema.org/Article",
    "https://schema.org/JobPosting",
    "https://schema.org/Product"
  ]);
  assert.deepEqual(result.selected[0].output.data["@graph"].map((entity) => entity["@type"]), ["Article", "JobPosting", "Product"]);
});

test("page detection exposes semantic uncertainty as review rather than silently selecting a type", () => {
  const document = new JSDOM(`
    <main>
      <article><h2><a href="/one">First undetermined result</a></h2><p>A sufficiently descriptive first result.</p></article>
      <article><h2><a href="/two">Second undetermined result</a></h2><p>A sufficiently descriptive second result.</p></article>
    </main>
  `, { url: "https://example.com/uncertain" }).window.document;
  const result = Pipeline.detectPage(document, { collection: { id: "uncertain" } }, {
    profile: profile(["Article", "JobPosting", "Thing"])
  });

  assert.equal(result.summary.reviewCount, 1);
  assert.equal(result.selected[0].status, "review");
  assert.ok(result.selected[0].reasons.includes("semantic-confidence"));
  assert.deepEqual(result.selected[0].output.data["@graph"].map((entity) => entity["@type"]), ["Thing", "Thing"]);
  assert.equal(result.selected[0].semantics.reports.every((report) => report.accepted === false), true);
});
