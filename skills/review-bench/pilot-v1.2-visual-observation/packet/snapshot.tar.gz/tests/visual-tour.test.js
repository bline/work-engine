"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");

test("visual tour width parsing and scroll tiling remain deterministic", async () => {
  const tour = await import("../scripts/capture-visual-tour.mjs");
  assert.deepEqual(tour.parseWidths("320, 480,320,800"), [320, 480, 800]);
  assert.deepEqual(tour.parseWidths("invalid"), [320, 480, 800]);
  assert.deepEqual(tour.tilePositions(400, 500), [0]);
  assert.deepEqual(tour.tilePositions(1000, 400, 50), [0, 350, 600]);
});

test("visual tour contact sheet groups captures by state and width", async () => {
  const { renderContactSheet } = await import("../scripts/capture-visual-tour.mjs");
  const html = renderContactSheet({
    createdAt: "2026-08-12T12:00:00.000Z", height: 900, widths: [320, 800],
    captures: [
      { state: "Structure <empty>", width: 320, file: "one.png", label: "Initial view" },
      {
        state: "Structure <empty>", width: 800, file: "two.png", label: "Horizontal & final",
        provenance: { from: "Adapter library", actions: [{ action: "click", target: "#new-adapter-button" }] }
      }
    ]
  });
  assert.match(html, /Structure &lt;empty&gt;/);
  assert.match(html, /320px/);
  assert.match(html, /Horizontal &amp; final/);
  assert.match(html, /two\.png/);
  assert.match(html, /From Adapter library: click #new-adapter-button/);
});

test("visual tour README catalogs screenshots and graphs provenance", async () => {
  const { renderMarkdownTour, renderMarkdownRouteDocuments, renderProvenanceGraph } = await import("../scripts/capture-visual-tour.mjs");
  const manifest = {
    createdAt: "2026-08-13T12:00:00.000Z", inspectedPage: "https://example.test/jobs", theme: "dark",
    height: 900, widths: [320, 800], completed: true, draftDiscarded: true,
    captures: [
      {
        state: "Adapter library", width: 320, file: "library.png", label: "Initial view",
        provenance: { journey: "manual", route: "library", from: null, actions: [{ action: "reload", target: "side-panel" }] }
      },
      {
        state: "Structure · empty draft", width: 320, file: "structure-320.png", label: "Initial view",
        provenance: { journey: "manual", route: "structure", from: "Adapter library", actions: [{ action: "click", target: "[data-app-view=adapters] #new-adapter-button" }] }
      },
      {
        state: "Structure · empty draft", width: 800, file: "structure-800.png", label: "Initial view",
        provenance: { journey: "manual", route: "structure", from: "Adapter library", actions: [{ action: "click", target: "[data-app-view=adapters] #new-adapter-button" }] }
      }
    ]
  };
  const graph = renderProvenanceGraph(manifest);
  assert.match(graph, /flowchart TD/);
  assert.match(graph, /Adapter library/);
  assert.match(graph, /-->|click data-app-view=adapters #new-adapter-button|/);
  assert.doesNotMatch(graph, /\[data-app-view/);
  assert.equal((graph.match(/Structure · empty draft/g) || []).length, 1, "width captures share one graph node");
  const routeGraph = renderProvenanceGraph(manifest, { level: "route" });
  assert.match(routeGraph, /manual · library/);
  assert.match(routeGraph, /manual · structure/);
  assert.equal((routeGraph.match(/manual · structure/g) || []).length, 1);

  const markdown = renderMarkdownTour(manifest);
  assert.match(markdown, /# Site2JSON visual tour/);
  assert.match(markdown, /```mermaid/);
  assert.match(markdown, /\[interactive contact sheet\]\(index\.html\)/);
  assert.match(markdown, /\[Structure\]\(screens\/structure\.md\)/);
  assert.match(markdown, /<img src="structure-800\.png"/);
  assert.match(markdown, /Run completed: \*\*yes\*\*/);

  const documents = renderMarkdownRouteDocuments(manifest);
  const structure = documents.find((document) => document.file === "structure.md");
  assert.ok(structure);
  assert.match(structure.content, /\[!\[Structure · empty draft — Initial view\]\(\.\.\/structure-800\.png\)\]/);
  assert.match(structure.content, /Arrived from \*\*Adapter library\*\*/);
  assert.match(structure.content, /## Screen flow/);
});

test("visual tour provenance records the actions between logical screenshots", async () => {
  const { createTourProvenance } = await import("../scripts/capture-visual-tour.mjs");
  const tracker = createTourProvenance({ journey: "manual-adapter-creation", surface: "side-panel" });
  tracker.record("reload", "side-panel");
  const library = tracker.capture("Adapter library");
  tracker.record("click", "#new-adapter-button");
  const structure = tracker.capture("Structure · empty draft");
  tracker.record("click", "#unresolved-fields-body button");
  const field = tracker.capture("Review · map discovered field");
  assert.deepEqual(library, {
    journey: "manual-adapter-creation",
    surface: "side-panel",
    route: "library",
    from: null,
    actions: [{ action: "reload", target: "side-panel" }],
    path: ["Adapter library"]
  });
  assert.equal(structure.from, "Adapter library");
  assert.equal(structure.route, "structure");
  assert.deepEqual(structure.actions, [{ action: "click", target: "#new-adapter-button" }]);
  assert.deepEqual(structure.path, ["Adapter library", "Structure · empty draft"]);
  assert.equal(field.route, "field");
});

test("visual tour defines deterministic production popup states", async () => {
  const { POPUP_TOUR_STATES } = await import("../scripts/capture-visual-tour.mjs");
  assert.deepEqual(POPUP_TOUR_STATES.map((state) => state.name), [
    "Popup · adapter ready",
    "Popup · automatic inference",
    "Popup · extraction complete",
    "Popup · active session"
  ]);
  assert.equal(POPUP_TOUR_STATES.find((state) => state.name.includes("automatic inference")).kind, "partial");
  assert.equal(POPUP_TOUR_STATES.find((state) => state.name.includes("extraction complete")).result, true);
  assert.equal(POPUP_TOUR_STATES.find((state) => state.name.includes("active session")).session, true);
});

test("visual tour includes the complete variant recovery journey", async () => {
  const { VARIANT_RECOVERY_TOUR_STATES } = await import("../scripts/capture-visual-tour.mjs");
  assert.deepEqual(VARIANT_RECOVERY_TOUR_STATES, [
    "Semantics · variant attention",
    "Semantics · variant evidence resolver",
    "Semantics · exact-shape fallback accepted",
    "Semantics · variant attention after shape change"
  ]);
});
