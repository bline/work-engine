"use strict";
const assert = require("node:assert/strict");
const test = require("node:test");
const Contract = require("../extension/ir/visual-evidence-contract");

const observation = () => ({
  version: 1, observationId: "vo-1", status: "authored",
  target: { typeTerm: "https://schema.org/Article", propertyTerm: "https://schema.org/headline", path: "Article.headline", variantKey: "Article" },
  action: { kind: "rendered-page-click", frameUrl: "https://example.test/results", element: { tag: "h2", role: "heading", candidateFingerprints: ["s2j1:heading"] }, interpretation: { kind: "text", reader: "text" } },
  repeatedGroup: { mode: "many", groupObservationId: "group-1", selectedItemOrdinal: 3, itemCountAtAuthoring: 20, scopeFingerprint: "s2j1:scope" },
  provenance: { source: "human-rendered-page-click", authoredAt: "2026-08-17T12:00:00.000Z", pickerVersion: 6, pageRevision: "revision-1", detectionRunId: "group-1:0:title" }
});
const binding = () => ({
  kind: "visual", version: 1,
  scope: { mode: "many", rootCandidates: [{ kind: "stable-selector", selector: ".result-card" }], itemRelation: "descendant" },
  target: { relation: "descendant", locatorCandidates: [{ kind: "stable-relative-selector", selector: "h2" }], renderedRole: "heading", tag: "h2", reader: "text" },
  layout: { normalizedRect: { x: 0.04, y: 0.08, width: 0.82, height: 0.12 }, order: { axis: "block", rank: 1 } },
  validation: { uniqueness: "exactly-one-per-item", minimumCoverage: 0.6, maximumMultiplicity: 1, shape: "text", allowedRoleDrift: ["heading", "text"] },
  baseline: { scope: { typical: 20, minimum: 1 }, coverage: 1, matchesPerItem: [1, 1], shapeFingerprint: "s2j1:shape" },
  provenance: { observationIds: ["vo-1"], compiler: "visual-binding-compiler@1" }
});

test("accepts lifecycle-specific observation and inert binding shapes", () => {
  const observed = Contract.validateObservation(observation());
  const portable = Contract.validatePortableBinding(binding());
  assert.equal(observed.ok, true);
  assert.equal(portable.ok, true);
  assert.deepEqual(portable.value, binding());
  assert.equal(Object.isFrozen(portable.value), true);
  assert.equal(Object.isFrozen(portable.value.target), true);
  assert.equal("target" in portable.value.provenance, false);
});

test("portable bindings reject live objects, executable readers, and unknown fields", () => {
  const live = binding(); live.target.node = { nodeType: 1, ownerDocument: {} };
  const executable = binding(); executable.target.reader = () => "title";
  const unknown = binding(); unknown.certainty = "definite";
  for (const candidate of [live, executable, unknown]) {
    const result = Contract.validatePortableBinding(candidate);
    assert.equal(result.ok, false);
    assert.equal(result.value, null);
  }
});

test("portable bindings reject invalid repeated groups, raw snapshots, and draft observations", () => {
  const invalidGroup = binding(); invalidGroup.scope.mode = "many"; invalidGroup.scope.rootCandidates = [];
  const rawSnapshot = binding(); rawSnapshot.rawText = "Observed headline";
  for (const candidate of [invalidGroup, rawSnapshot, observation()]) {
    const result = Contract.validatePortableBinding(candidate);
    assert.equal(result.ok, false);
    assert.equal(result.value, null);
  }
});

test("strict bounds reject unbounded candidates and malformed authored group context", () => {
  const tooMany = binding(); tooMany.target.locatorCandidates = Array.from({ length: 17 }, (_, index) => ({ kind: "stable-relative-selector", selector: `h2:nth-child(${index + 1})` }));
  const wrongKindFields = binding(); wrongKindFields.scope.rootCandidates[0].tags = Array.from({ length: 17 }, () => "article");
  const badObservation = observation(); badObservation.repeatedGroup.selectedItemOrdinal = 20;
  assert.equal(Contract.validatePortableBinding(tooMany).ok, false);
  assert.equal(Contract.validatePortableBinding(wrongKindFields).ok, false);
  assert.equal(Contract.validateObservation(badObservation).ok, false);
});

test("unresolved observations preserve the absence of a rendered-page click", () => {
  const unresolved = observation();
  unresolved.status = "unresolved";
  delete unresolved.action;
  delete unresolved.provenance.pickerVersion;
  unresolved.provenance.source = "human-left-unresolved";
  assert.equal(Contract.validateObservation(unresolved).ok, true);
  unresolved.provenance.source = "human-rendered-page-click";
  assert.equal(Contract.validateObservation(unresolved).ok, false);
  unresolved.provenance.pickerVersion = 6;
  assert.equal(Contract.validateObservation(unresolved).ok, true);
});
