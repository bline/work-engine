"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const Theme = require("../extension/core/theme");

test("appearance preferences normalize safely and resolve system color scheme", () => {
  assert.equal(Theme.normalize("light"), "light");
  assert.equal(Theme.normalize("dark"), "dark");
  assert.equal(Theme.normalize("unexpected"), "system");
  assert.equal(Theme.resolved("system", { matches: true }), "dark");
  assert.equal(Theme.resolved("system", { matches: false }), "light");
  assert.equal(Theme.resolved("light", { matches: true }), "light");
});

test("selected wizard location overrides every progress-state color", () => {
  const css = fs.readFileSync(path.join(__dirname, "../extension/theme.css"), "utf8");
  const progress = css.indexOf(".workflow-steps button.pending");
  const location = css.indexOf(".workflow-steps button.selected", progress);
  assert.ok(progress >= 0 && location > progress, "selected location styling must follow progress styling in the cascade");
  assert.match(css.slice(location), /\.workflow-steps button\.active/);
  assert.match(css.slice(location), /color:\s*var\(--s2j-selection-text\)\s*!important/);
});

test("completion cards route child text through theme-aware contrast tokens", () => {
  const css = fs.readFileSync(path.join(__dirname, "../extension/theme.css"), "utf8");
  assert.match(css, /\.step-completion \.step-completion-label\s*\{[^}]*var\(--s2j-success\)[^}]*\}/s);
  assert.match(css, /\.step-completion strong\s*\{[^}]*var\(--s2j-text\)[^}]*\}/s);
  assert.match(css, /\.step-completion p\s*\{[^}]*var\(--s2j-text-muted\)[^}]*\}/s);
  assert.match(css, /\.step-completion\.attention \.step-completion-label\s*\{[^}]*var\(--s2j-warning\)[^}]*\}/s);
});
