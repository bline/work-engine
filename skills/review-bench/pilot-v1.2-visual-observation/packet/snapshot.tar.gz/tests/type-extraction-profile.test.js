"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Profile = require("../extension/authoring/type-extraction-profile");
const Vocabulary = require("../extension/editor/schema-vocabulary");

test("builds a bounded, evidence-independent extraction profile for one semantic type", () => {
  const profile = Profile.build("JobPosting");
  assert.equal(profile.version, 1);
  assert.equal(profile.schemaType, "JobPosting");
  assert.ok(profile.properties.length <= Profile.MAX_PROPERTIES);
  assert.ok(profile.properties.some((property) => property.name === "title"));
  assert.ok(profile.properties.some((property) => property.name === "datePosted"));
  assert.equal(profile.properties.some((property) => property.name === "sku"), false);
  assert.deepEqual(profile.properties.find((property) => property.name === "url").normalization, ["absoluteUrl", "stripQuery"]);
  assert.ok(profile.summary.schema > 0);
  assert.equal(profile.summary.extension, 0);
  assert.equal(profile.properties.find((property) => property.name === "datePosted").catalogValidity.domain.match, "direct");
  assert.equal(profile.properties.find((property) => property.name === "description").catalogValidity.domain.match, "inherited");
  const organizationName = profile.properties.find((property) => property.name === "hiringOrganization.name");
  assert.equal(organizationName.catalogValidity.relationship.property, "hiringOrganization");
  assert.equal(organizationName.catalogValidity.relationship.targetType, "Organization");
  assert.equal(organizationName.semanticPrior.cardinality.source, "site2json-authoring-default");
});

test("ranks only the profile cross-section against page evidence", () => {
  const profile = Profile.build("JobPosting");
  const title = Profile.suggestions(profile, {
    suggestedName: "title", kind: "text", evidence: { tag: "h2", classes: ["job-title"], text: "Engineer" }
  });
  assert.equal(title[0].name, "title");
  const link = Profile.suggestions(profile, {
    suggestedName: "url", kind: "url", evidence: { tag: "a", attribute: "href", href: "/jobs/1", classes: ["job-link"] }
  });
  assert.equal(link[0].name, "url");
  assert.equal(link.some((property) => property.name === "sku"), false);
});

test("combines installed and adapter-local properties without admitting entity relationships", () => {
  const installed = {
    name: "site:portfolio", source: "extension", valueType: "URL", cardinality: "one",
    vocabularyTerm: {
      kind: "relationship", canonicalUri: "https://example.test/vocab#portfolio",
      domainIncludes: ["guru:Editor"], rangeIncludes: ["URL"], evidenceAliases: ["portfolio"]
    },
    librarySources: [{ canonicalUri: "https://example.test/vocab#portfolio" }]
  };
  const profile = Profile.build("guru:Editor", {
    schemaType: "Person",
    libraryProperties: [installed],
    customTerms: {
      "site:byline": { kind: "field", valueType: "Text", domainIncludes: ["guru:Editor"], evidenceAliases: ["byline"] },
      "site:metadata": { kind: "field", valueType: "Object", domainIncludes: ["guru:Editor"] },
      "site:employer": { kind: "relationship", valueType: "Organization", domainIncludes: ["guru:Editor"], rangeIncludes: ["Organization"] },
      "site:irrelevant": { kind: "field", valueType: "Text", domainIncludes: ["Product"] }
    }
  });
  assert.ok(profile.properties.some((property) => property.name === "site:portfolio"));
  assert.ok(profile.properties.some((property) => property.name === "site:byline"));
  assert.ok(profile.properties.some((property) => property.name === "site:metadata"));
  assert.equal(profile.properties.some((property) => property.name === "site:employer"), false);
  assert.equal(profile.properties.some((property) => property.name === "site:irrelevant"), false);

  const suggestions = Profile.suggestions(profile, {
    suggestedName: "portfolio", kind: "url", evidence: { tag: "a", attribute: "href", href: "/work", classes: ["portfolio-link"] }
  }, { librarySuggestions: [{ ...installed, score: 38 }] });
  const portfolio = suggestions.find((property) => property.name === "site:portfolio");
  assert.ok(portfolio.score >= 8);
  assert.notEqual(portfolio.score, 38, "an imported scorer leaked into the shared observed-evidence score");
  assert.equal(portfolio.scoreSource, "shared-observed-evidence");
  assert.equal(portfolio.vocabularyTerm.canonicalUri, "https://example.test/vocab#portfolio");
});

test("applies reusable aliases, exclusions, shapes, transforms, and salience from a local property profile", () => {
  const installed = {
    name: "guru:proposalCount", source: "extension", valueType: "Integer", cardinality: "one",
    vocabularyTerm: {
      kind: "relationship", domainIncludes: ["JobPosting"], rangeIncludes: ["Integer"],
      authoringProfile: {
        aliases: ["quotes received"], negativeAliases: ["project budget"],
        expectedShapes: ["integer"], normalization: ["text", "int"], salience: 91
      }
    }
  };
  const profile = Profile.build("JobPosting", { libraryProperties: [installed] });
  const property = profile.properties.find((candidate) => candidate.name === "guru:proposalCount");
  assert.deepEqual(property.normalization, ["text", "int"]);
  assert.equal(property.salience, 91);
  assert.ok(property.aliases.includes("quotes received"));

  const matching = Profile.suggestions(profile, {
    suggestedName: "quotes", kind: "text", sampleValues: ["12", "8"],
    coverage: { sampled: 2, present: 2 }, evidence: { tag: "span", classes: ["quotes-received"], matchCounts: [1, 1] }
  }).find((candidate) => candidate.name === "guru:proposalCount");
  const excluded = Profile.suggestions(profile, {
    suggestedName: "budget", kind: "text", sampleValues: ["12", "8"],
    coverage: { sampled: 2, present: 2 }, evidence: { tag: "span", classes: ["project-budget"], matchCounts: [1, 1] }
  }).find((candidate) => candidate.name === "guru:proposalCount");
  assert.ok(matching.score >= 10);
  assert.deepEqual(Vocabulary.defaultPipeline(matching), ["text", "int"]);
  assert.ok(excluded.score < matching.score);
  assert.ok(excluded.score < 8);
});
