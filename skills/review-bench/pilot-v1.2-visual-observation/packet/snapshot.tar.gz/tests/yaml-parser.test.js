"use strict";

const assert = require("node:assert/strict");
const path = require("node:path");
const { pathToFileURL } = require("node:url");
const test = require("node:test");
const parser = require("../lib/yaml-parser");

test("the configured YAML parser accepts inert YAML and JSON data", () => {
  assert.deepEqual(parser.parse("adapter: example\nversion: 1\nhosts:\n  - example.com\n"), {
    adapter: "example", version: 1, hosts: ["example.com"]
  });
  assert.deepEqual(parser.parse('{"adapter":"example","version":1}'), { adapter: "example", version: 1 });
});

test("the vendored browser module uses the same reviewed parser policy", async () => {
  require("../extension/core/yaml-policy");
  await import(pathToFileURL(path.resolve(__dirname, "../extension/vendor/yaml-parser.mjs")).href);
  assert.deepEqual(globalThis.Site2JsonYamlParser.parse("adapter: example\nversion: 1\n"), { adapter: "example", version: 1 });
  assert.throws(() => globalThis.Site2JsonYamlParser.parse("a: &value one\nb: *value\n"), /(anchors|aliases) are not allowed/i);
});

test("the configured YAML parser rejects duplicate keys, custom tags, and multiple documents", () => {
  assert.throws(() => parser.parse("adapter: one\nadapter: two\n"), /keys must be unique/i);
  assert.throws(() => parser.parse("adapter: !custom example\n"), /unresolved tag/i);
  assert.throws(() => parser.parse("adapter: one\n---\nadapter: two\n"), /exactly one/i);
});

test("the configured YAML parser rejects anchors, aliases, and merge keys", () => {
  assert.throws(() => parser.parse("adapter: &name example\n"), /anchors are not allowed/i);
  assert.throws(() => parser.parse("adapter: &name example\ncopy: *name\n"), /(anchors|aliases) are not allowed/i);
  assert.throws(() => parser.parse("base: &base\n  host: example.com\nadapter:\n  <<: *base\n"), /(anchors|merge keys|aliases) are not allowed/i);
});

test("the configured YAML parser rejects unsafe keys and non-finite values", () => {
  assert.throws(() => parser.parse("adapter: example\nconstructor: unsafe\n"), /unsafe yaml mapping key/i);
  assert.throws(() => parser.parse("adapter: example\nvalue: .inf\n"), /finite json-compatible/i);
});
