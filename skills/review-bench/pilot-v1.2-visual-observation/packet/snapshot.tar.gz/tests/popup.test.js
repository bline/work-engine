"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const Session = require("../extension/core/session");

const root = path.resolve(__dirname, "..");
const definition = JSON.parse(fs.readFileSync(path.join(root, "reference-adapters/upwork-search.dsl.json"), "utf8"));
const html = fs.readFileSync(path.join(root, "extension/popup.html"), "utf8");
const scripts = ["core/utils.js", "core/transforms.js", "core/variant-classifier.js", "core/dsl.js", "core/adapter-registry.js", "core/adapter-drafts.js", "core/automatic-settings.js", "authoring/automatic-conversion.js", "core/exporters.js", "core/session.js", "popup.js"]
  .map((file) => fs.readFileSync(path.join(root, "extension", file), "utf8"));

function extractedDocument(position = 1) {
  return {
    extraction: {
      id: `r_${position}`, extractorVersion: "0.1.0", adapter: "upwork", adapterVersion: 1,
      adapterSource: "bundled", extractedAt: `2026-08-08T1${position}:00:00.000Z`,
      pageUrl: `https://www.upwork.com/nx/search/jobs/?q=csv&page=${position}`, pageTitle: "CSV jobs",
      pageType: "SearchResultsPage", language: "en", page: { searchTerm: "csv" },
      collectionKey: "upwork:jobs:q=csv", snapshotKey: `upwork:jobs:q=csv:page:${position}`,
      logicalPosition: position, blocks: [{ id: "results", entity: "JobPosting", role: "collection", arity: "many", fidelity: "summary", count: 1 }],
      warnings: [], quality: { complete: true, requiredFieldCoverage: 1, monitoredFieldCoverage: 1 }
    },
    blocks: [{ id: "results", entity: "JobPosting", role: "collection", arity: "many", fidelity: "summary", require: ["title", "url"], entities: [{
      "@type": "JobPosting", "@id": `https://www.upwork.com/jobs/~${position}`, identifier: String(position),
      url: `https://www.upwork.com/jobs/~${position}`, title: `Job ${position}`, skills: [], "site2json:rawText": `Raw job ${position}`
    }] }]
  };
}

function detailDocument() {
  const document = extractedDocument();
  document.extraction.id = "r_detail";
  document.extraction.extractedAt = "2026-08-08T14:00:00.000Z";
  document.extraction.pageUrl = "https://www.upwork.com/jobs/~1";
  document.extraction.pageTitle = "Job 1 detail";
  document.extraction.pageType = "ItemPage";
  document.extraction.page = {};
  document.extraction.collectionKey = null;
  document.extraction.snapshotKey = "upwork:job:https://www.upwork.com/jobs/~1";
  document.extraction.logicalPosition = null;
  document.extraction.blocks = [{ id: "job-detail", entity: "JobPosting", role: "primary", arity: "one", fidelity: "full", count: 1 }];
  document.blocks[0].id = "job-detail";
  document.blocks[0].role = "primary";
  document.blocks[0].arity = "one";
  document.blocks[0].fidelity = "full";
  document.blocks[0].entities[0].description = "Full job description";
  return document;
}

async function waitFor(predicate, message) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  assert.fail(message);
}

async function loadPopup({ pendingCommand = null, productionResult = null, pageDocument = extractedDocument(), initialSession = null, exportFormat = null, includeRawText = null, adapters = [{ id: "upwork", source: "local-file", enabled: true, definition }], drafts = [], automaticConfidence = null, run = true } = {}) {
  const local = { site2jsonLocalAdapters: adapters };
  local.site2jsonAdapterDrafts = drafts;
  if (initialSession) local.site2jsonSession = initialSession;
  if (exportFormat) local.site2jsonExportFormat = exportFormat;
  if (includeRawText !== null) local.site2jsonCompactIncludeRawText = includeRawText;
  if (automaticConfidence) local.site2jsonAutomaticSettings = { minimumConfidence: automaticConfidence };
  const session = {
    ...(pendingCommand ? { pendingShortcutCommand: { command: pendingCommand } } : {}),
    ...(productionResult ? { site2jsonProductionRunResult: productionResult } : {})
  };
  const calls = { clipboard: [], removed: [], badge: [], scripting: [], options: 0, sidePanel: [], downloads: [], blobs: [] };
  const dom = new JSDOM(html, { url: "chrome-extension://test/popup.html", runScripts: "outside-only" });
  const { window } = dom;
  local.site2jsonLocalAdapters = window.JSON.parse(JSON.stringify(adapters));
  local.site2jsonAdapterDrafts = window.JSON.parse(JSON.stringify(drafts));
  window.TextEncoder = TextEncoder;
  window.chrome = {
    tabs: { query: async () => [{ id: 1, url: "https://www.upwork.com/nx/search/jobs/?q=csv" }] },
    scripting: { executeScript: async (request) => {
      calls.scripting.push(request);
      if (request.files) {
        assert.deepEqual(Array.from(request.files), ["core/utils.js", "core/transforms.js", "core/variant-classifier.js", "core/dsl.js", "core/model.js", "extract.js"]);
        return [{}];
      }
      assert.equal(request.args[0][0].adapter, "upwork");
      return [{ result: { ok: true, document: pageDocument } }];
    } },
    runtime: { openOptionsPage: async () => { calls.options += 1; } },
    sidePanel: {
      setOptions: async (value) => calls.sidePanel.push({ action: "setOptions", value }),
      open: async (value) => calls.sidePanel.push({ action: "open", value })
    },
    action: {
      setBadgeBackgroundColor: async () => {},
      setBadgeText: async ({ text }) => calls.badge.push(text)
    },
    storage: {
      local: {
        get: async () => ({ ...local }),
        set: async (value) => Object.assign(local, value),
        remove: async (key) => { calls.removed.push(key); delete local[key]; }
      },
      session: {
        get: async () => ({ ...session }),
        set: async (value) => Object.assign(session, value),
        remove: async (key) => { delete session[key]; }
      }
    }
  };
  Object.defineProperty(window.navigator, "clipboard", {
    configurable: true,
    value: { writeText: async (value) => calls.clipboard.push(value) }
  });
  window.URL.createObjectURL = (blob) => {
    calls.blobs.push(blob);
    return `blob:site2json-${calls.blobs.length}`;
  };
  window.URL.revokeObjectURL = () => {};
  window.HTMLAnchorElement.prototype.click = function click() {
    calls.downloads.push({ download: this.download, href: this.href });
  };
  const nativeTimeout = window.setTimeout.bind(window);
  window.setTimeout = (callback, delay, ...args) => delay === 250 ? 0 : nativeTimeout(callback, delay, ...args);
  for (const script of scripts) window.eval(script);
  await window.Site2JsonPopupReady;
  if (pendingCommand) {
    await waitFor(() => !session.pendingShortcutCommand, "popup did not consume the shortcut");
  } else if (productionResult) {
    await waitFor(() => !session.site2jsonProductionRunResult && /(?:extracted|Page added)/.test(window.document.querySelector("#status-title").textContent), "popup did not consume the production result");
  } else {
    const expected = adapters.length ? "Adapter ready" : drafts.length ? "Adapter draft needs attention" : "No adapter for this page";
    await waitFor(() => window.document.querySelector("#status-title").textContent.includes(expected), `popup did not finish its adapter preflight: ${window.document.querySelector("#status-title").textContent} — ${window.document.querySelector("#status-detail").textContent}`);
    if (adapters.length && run) {
      window.document.querySelector("#run-button").click();
      await waitFor(() => window.document.querySelector("#status-title").textContent.includes("extracted"), "popup did not run the enabled adapter");
    }
  }
  return { calls, dom, local, session, window };
}

test("an empty local registry points the user to adapter management without injecting page code", async () => {
  const { calls, dom, window } = await loadPopup({ adapters: [] });
  assert.equal(calls.scripting.length, 0);
  assert.equal(window.document.querySelector("#copy-button").disabled, true);
  const editorHelp = window.document.querySelector(".editor-entry").textContent.replace(/\s+/g, " ");
  assert.match(editorHelp, /Automatic runs remain reviewable/);
  assert.match(editorHelp, /exact decision that needs attention/);
  assert.match(window.document.querySelector("#status-detail").textContent, /infer the structure, semantics, and fields automatically/i);
  assert.match(window.document.querySelector("#automatic-threshold").textContent, /High/);
  window.document.querySelector("#manage-adapters-button").click();
  await waitFor(() => calls.options === 1, "options page was not opened");
  dom.window.close();
});

test("Run without an adapter queues automatic inference with the visible confidence threshold", async () => {
  const { calls, dom, session, window } = await loadPopup({ adapters: [], run: false });
  window.document.querySelector("#run-button").click();
  await waitFor(() => session.site2jsonProductionRunRequest, "automatic run request was not queued");
  await waitFor(() => calls.sidePanel.length === 2, "automatic run did not open the side panel");
  assert.equal(session.site2jsonProductionRunRequest.intent, "run");
  assert.equal(session.site2jsonProductionRunRequest.minimumConfidence, "strong");
  assert.equal(session.site2jsonProductionRunRequest.tabId, 1);
  assert.deepEqual(JSON.parse(JSON.stringify(calls.sidePanel)), [
    { action: "setOptions", value: { tabId: 1, path: "editor/sidebar.html?tabId=1", enabled: true } },
    { action: "open", value: { tabId: 1 } }
  ]);
  assert.equal(calls.scripting.length, 0);
  dom.window.close();
});

test("a configured moderate threshold is shown and sent to automatic inference", async () => {
  const { calls, dom, session, window } = await loadPopup({ adapters: [], automaticConfidence: "moderate", run: false });
  assert.match(window.document.querySelector("#automatic-threshold").textContent, /Moderate/);
  assert.match(window.document.querySelector("#status-detail").textContent, /below moderate confidence/i);
  window.document.querySelector("#session-button").click();
  await waitFor(() => session.site2jsonProductionRunRequest, "session inference request was not queued");
  await waitFor(() => calls.sidePanel.length === 2, "session inference did not open the side panel");
  assert.equal(session.site2jsonProductionRunRequest.intent, "session");
  assert.equal(session.site2jsonProductionRunRequest.minimumConfidence, "moderate");
  dom.window.close();
});

test("an automatically inferred session result returns to the popup and joins the active session", async () => {
  const documentValue = extractedDocument(2);
  const productionResult = {
    version: 1,
    requestId: "automatic-session-result",
    tabId: 1,
    intent: "session",
    minimumConfidence: "moderate",
    automatic: true,
    published: false,
    decision: "draft-and-download",
    completedAt: "2026-08-13T12:00:00.000Z",
    document: documentValue
  };
  const { dom, local, session, window } = await loadPopup({
    adapters: [],
    productionResult,
    run: false
  });
  assert.equal(session.site2jsonProductionRunResult, undefined);
  assert.equal(window.document.querySelector("#session-count").textContent, "1 entities");
  assert.equal(local.site2jsonSession.snapshots[documentValue.extraction.snapshotKey].extraction.adapter, "upwork");
  assert.match(window.document.querySelector("#status-detail").textContent, /unreviewed draft/i);
  dom.window.close();
});

test("preflight preserves an existing manual draft instead of promising fresh inference", async () => {
  const drafts = [{
    id: "new:manual",
    status: "draft",
    adapterId: null,
    workingDefinition: null,
    editorState: {
      pageUrl: "https://www.upwork.com/nx/search/jobs/?q=csv",
      blocks: [{ id: "results", scope: ".job" }]
    },
    createdAt: "2026-08-13T12:00:00.000Z",
    updatedAt: "2026-08-13T12:00:00.000Z"
  }];
  const { calls, dom, session, window } = await loadPopup({ adapters: [], drafts, run: false });
  assert.equal(window.document.querySelector("#status-title").textContent, "Adapter draft needs attention");
  assert.match(window.document.querySelector("#status-detail").textContent, /preserve its decisions/i);
  window.document.querySelector("#run-button").click();
  await waitFor(() => session.site2jsonProductionRunRequest, "draft review request was not queued");
  await waitFor(() => calls.sidePanel.length === 2, "existing draft did not open in the side panel");
  assert.equal(calls.scripting.length, 0);
  dom.window.close();
});

test("the editor button configures and opens the shared editor in a tab-specific side panel", async () => {
  const { calls, dom, window } = await loadPopup();
  window.document.querySelector("#open-picker-button").click();
  await waitFor(() => calls.sidePanel.length === 2, "picker side panel was not opened");
  assert.deepEqual(JSON.parse(JSON.stringify(calls.sidePanel)), [
    { action: "setOptions", value: { tabId: 1, path: "editor/sidebar.html?tabId=1", enabled: true } },
    { action: "open", value: { tabId: 1 } }
  ]);
  dom.window.close();
});

test("a supported page can be copied as a single compact extraction", async () => {
  const { calls, dom, window } = await loadPopup();
  const copy = window.document.querySelector("#copy-button");
  assert.equal(copy.disabled, false);
  assert.equal(copy.textContent, "Copy results");
  copy.click();
  await waitFor(() => calls.clipboard.length === 1, "copy did not complete");
  const exported = JSON.parse(calls.clipboard[0]);
  assert.equal(exported.source, "site2json");
  assert.equal(exported.jobs[0].title, "Job 1");
  assert.equal(exported.jobs[0].raw_text, undefined);
  assert.equal(calls.removed.length, 0);
  dom.window.close();
});

test("the remembered Compact JSON raw-text option is opt-in", async () => {
  const { calls, dom, window } = await loadPopup({ includeRawText: true });
  assert.equal(window.document.querySelector("#include-raw-text").checked, true);
  window.document.querySelector("#copy-button").click();
  await waitFor(() => calls.clipboard.length === 1, "raw-text extraction was not copied");
  assert.equal(JSON.parse(calls.clipboard[0]).jobs[0].raw_text, "Raw job 1");
  dom.window.close();
});

test("changing Compact JSON raw-text inclusion persists immediately", async () => {
  const { dom, local, window } = await loadPopup();
  const rawText = window.document.querySelector("#include-raw-text");
  rawText.checked = true;
  rawText.dispatchEvent(new window.Event("change", { bubbles: true }));
  await waitFor(() => local.site2jsonCompactIncludeRawText === true, "raw-text setting was not persisted");
  dom.window.close();
});

test("the remembered JSON-LD format controls single-page copy output", async () => {
  const { calls, dom, window } = await loadPopup({ exportFormat: "jsonld" });
  assert.equal(window.document.querySelector('input[value="jsonld"]').checked, true);
  assert.equal(window.document.querySelector("#download-button").textContent, "Download JSON-LD");
  window.document.querySelector("#copy-button").click();
  await waitFor(() => calls.clipboard.length === 1, "JSON-LD extraction was not copied");
  const exported = JSON.parse(calls.clipboard[0]);
  assert.equal(exported.graph["@type"], "SearchResultsPage");
  assert.equal(exported.graph.mainEntity.itemListElement[0].title, "Job 1");
  assert.equal(exported.jobs, undefined);
  dom.window.close();
});

test("changing the export format persists immediately", async () => {
  const { dom, local, window } = await loadPopup();
  const jsonLd = window.document.querySelector('input[value="jsonld"]');
  jsonLd.checked = true;
  jsonLd.dispatchEvent(new window.Event("change", { bubbles: true }));
  await waitFor(() => window.document.querySelector("#download-button").textContent === "Download JSON-LD", "format choice was not applied");
  assert.equal(local.site2jsonExportFormat, "jsonld");
  assert.equal(window.document.querySelector("#download-button").textContent, "Download JSON-LD");
  dom.window.close();
});

test("JSON-LD download uses a distinct filename and media type", async () => {
  const { calls, dom, window } = await loadPopup({ exportFormat: "jsonld" });
  window.document.querySelector("#download-button").click();
  await waitFor(() => calls.downloads.length === 1, "JSON-LD download was not started");
  assert.match(calls.downloads[0].download, /^site2json-upwork-jsonld-/);
  assert.match(calls.downloads[0].download, /\.json$/);
  assert.equal(calls.blobs[0].type, "application/ld+json");
  dom.window.close();
});

test("starting and copying a session stores, merges, and clears it", async () => {
  const { calls, dom, local, window } = await loadPopup();
  window.document.querySelector("#session-button").click();
  await waitFor(() => window.document.querySelector("#session-count").textContent === "1 entities", "session was not rendered");
  assert.ok(local.site2jsonSession);
  assert.equal(window.document.querySelector("#session-count").textContent, "1 entities");
  window.document.querySelector("#copy-button").click();
  await waitFor(() => calls.removed.includes("site2jsonSession"), "copied session was not cleared");
  const exported = JSON.parse(calls.clipboard[0]);
  assert.equal(exported.source, "site2json-session");
  assert.equal(exported.jobs.length, 1);
  assert.match(window.document.querySelector("#status-detail").textContent, /copied and cleared/i);
  dom.window.close();
});

test("JSON-LD session copy exports the merged graph and clears the session", async () => {
  const storedSession = Session.create(extractedDocument());
  const { calls, dom, window } = await loadPopup({ initialSession: storedSession, exportFormat: "jsonld" });
  window.document.querySelector("#copy-button").click();
  await waitFor(() => calls.removed.includes("site2jsonSession"), "JSON-LD session was not cleared");
  const exported = JSON.parse(calls.clipboard[0]);
  assert.equal(exported.extraction.source, "site2json-session");
  assert.equal(exported.extraction.snapshots.length, 1);
  assert.equal(exported.graph.mainEntity.numberOfItems, 1);
  assert.equal(exported.graph.mainEntity.itemListElement[0]["site2json:observations"].length, 1);
  dom.window.close();
});

test("session shortcuts honor the remembered JSON-LD format", async () => {
  const storedSession = Session.create(extractedDocument());
  const { calls, dom } = await loadPopup({ initialSession: storedSession, exportFormat: "jsonld", pendingCommand: "copy-session" });
  await waitFor(() => calls.clipboard.length === 1, "shortcut did not copy the session");
  const exported = JSON.parse(calls.clipboard[0]);
  assert.equal(exported.extraction.source, "site2json-session");
  assert.equal(exported.graph.mainEntity.numberOfItems, 1);
  dom.window.close();
});

test("a detail page can upgrade the matching entity in a stored search session", async () => {
  const search = extractedDocument();
  const storedSession = Session.create(search);
  const { calls, dom, local, window } = await loadPopup({ pageDocument: detailDocument(), initialSession: storedSession });
  const add = window.document.querySelector("#session-button");
  assert.equal(add.disabled, false);
  assert.equal(add.textContent, "Add this page");
  add.click();
  await waitFor(() => window.document.querySelector("#status-title").textContent === "Page added", "detail page was not added");
  assert.equal(Object.keys(local.site2jsonSession.snapshots).length, 2);
  window.document.querySelector("#copy-button").click();
  await waitFor(() => calls.clipboard.length === 1, "upgraded session was not copied");
  const exported = JSON.parse(calls.clipboard[0]);
  assert.equal(exported.jobs.length, 1);
  assert.equal(exported.jobs[0].description_excerpt, "Full job description");
  dom.window.close();
});

test("a colliding numeric ID from another adapter cannot join the UI session", async () => {
  const search = extractedDocument();
  const storedSession = Session.create(search);
  const foreign = detailDocument();
  foreign.extraction.adapter = "guru";
  foreign.extraction.pageUrl = "https://www.guru.com/work/detail/1";
  foreign.extraction.snapshotKey = "guru:job:1";
  foreign.blocks[0].entities[0].url = "https://www.guru.com/work/detail/1";
  foreign.blocks[0].entities[0]["@id"] = "https://www.guru.com/work/detail/1";
  const { dom, window } = await loadPopup({ pageDocument: foreign, initialSession: storedSession });
  const add = window.document.querySelector("#session-button");
  assert.equal(add.disabled, true);
  dom.window.close();
});
