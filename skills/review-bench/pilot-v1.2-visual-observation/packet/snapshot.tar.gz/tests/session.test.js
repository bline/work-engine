"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const Session = require("../extension/core/session");

function extraction(position, entities, { fidelity = "summary", collectionKey = "search:csv", extractedAt, adapter = "test" } = {}) {
  const time = extractedAt || `2026-08-08T${String(10 + position).padStart(2, "0")}:00:00.000Z`;
  return {
    extraction: {
      id: `r_${position}_${time}`, extractorVersion: "0.1.0", extractedAt: time, adapter, adapterVersion: 1, pageUrl: `https://example.com/?page=${position}`,
      pageTitle: "Results", pageType: "SearchResultsPage", collectionKey, snapshotKey: `search:csv:${position}`,
      logicalPosition: position, warnings: [], quality: { complete: true, requiredFieldCoverage: 1 }, blocks: []
    },
    blocks: [{ id: "results", entity: "Thing", role: "collection", arity: "many", fidelity, entities }]
  };
}

function entity(id, fields = {}) {
  return { "@type": "Thing", "@id": `https://example.com/${id}`, name: `Thing ${id}`, ...fields };
}

function detail(id, fields = {}) {
  const document = extraction(null, [entity(id, fields)], { fidelity: "full", collectionKey: null, extractedAt: "2026-08-08T18:00:00.000Z" });
  document.extraction.pageType = "ItemPage";
  document.extraction.snapshotKey = `detail:${id}`;
  document.blocks[0].role = "primary";
  document.blocks[0].arity = "one";
  return document;
}

test("creates sessions, reports gaps, and replaces matching snapshots", () => {
  let session = Session.create(extraction(1, [entity("1"), entity("2")]));
  session = Session.addDocument(session, extraction(3, [entity("2"), entity("3")]));
  assert.deepEqual(Session.summarize(session), {
    snapshots: 2, positions: [1, 3], missingPositions: [2], entityObservations: 4, uniqueEntities: 3, duplicateObservations: 1
  });
  session = Session.addDocument(session, extraction(1, [entity("4")]));
  assert.equal(Session.summarize(session).snapshots, 2);
  assert.deepEqual(Session.merge(session).map((item) => item["@id"]), ["https://example.com/4", "https://example.com/2", "https://example.com/3"]);
});

test("rejects documents from a different collection", () => {
  const session = Session.create(extraction(1, [entity("1")]));
  assert.throws(() => Session.addDocument(session, extraction(2, [entity("2")], { collectionKey: "search:other" })), /different collection/);
});

test("rejects snapshots extracted with a different version of the same adapter", () => {
  const session = Session.create(extraction(1, [entity("1")]));
  const changedAdapter = extraction(2, [entity("2")]);
  changedAdapter.extraction.adapterVersion = 2;
  assert.equal(Session.sameCollection(session, changedAdapter), false);
  assert.throws(() => Session.addDocument(session, changedAdapter), /different collection/);
});

test("matching primary details enrich a collection while unrelated details are rejected", () => {
  let session = Session.create(extraction(1, [entity("1"), entity("2")]));
  const matching = detail("1", { description: "Full detail" });
  const unrelated = detail("3", { description: "Unrelated" });
  assert.equal(Session.sameCollection(session, matching), true);
  assert.equal(Session.sameCollection(session, unrelated), false);
  session = Session.addDocument(session, matching);
  assert.equal(Session.merge(session).find((item) => item["@id"] === "https://example.com/1").description, "Full detail");
  assert.throws(() => Session.addDocument(session, unrelated), /different collection/);
});

test("a detail page can start a standalone session but cannot accept an unrelated detail", () => {
  const session = Session.create(detail("1"));
  assert.equal(Session.summarize(session).uniqueEntities, 1);
  assert.equal(Session.sameCollection(session, detail("2")), false);
});

test("entity identity prefers a stable identifier, then canonical URL", () => {
  assert.equal(Session.entityKey({ identifier: "stable", url: "https://example.com/url", "@id": "https://example.com/id" }), "stable");
  assert.equal(Session.entityKey({ url: "https://example.com/url", "@id": "https://example.com/id" }), "https://example.com/url");
  assert.equal(Session.entityKey({ "@id": "https://example.com/id" }), "https://example.com/id");
  assert.equal(Session.entityKey({ identifier: "3100001" }, "guru"), "guru:3100001");
});

test("rejects cross-adapter detail enrichment when bare identifiers collide", () => {
  const upworkEntity = entity("upwork", {
    identifier: "3100001",
    url: "https://www.upwork.com/jobs/~3100001",
    "@id": "https://www.upwork.com/jobs/~3100001"
  });
  const guruEntity = entity("guru", {
    identifier: "3100001",
    url: "https://www.guru.com/work/detail/3100001",
    "@id": "https://www.guru.com/work/detail/3100001"
  });
  const search = extraction(1, [upworkEntity], { adapter: "upwork", collectionKey: "upwork:jobs:search" });
  const foreignDetail = extraction(null, [guruEntity], {
    adapter: "guru", fidelity: "full", collectionKey: null, extractedAt: "2026-08-08T18:00:00.000Z"
  });
  foreignDetail.extraction.pageType = "ItemPage";
  foreignDetail.extraction.snapshotKey = "guru:job:3100001";
  foreignDetail.blocks[0].role = "primary";
  foreignDetail.blocks[0].arity = "one";

  const session = Session.create(search);
  assert.equal(Session.sameCollection(session, foreignDetail), false);
  assert.throws(() => Session.addDocument(session, foreignDetail), /different collection/);
  assert.notEqual(Session.entityKey(upworkEntity, "upwork"), Session.entityKey(guruEntity, "guru"));
});

test("adapter-scoped merge keys keep legacy mixed snapshots separate", () => {
  const upwork = extraction(1, [entity("upwork", { identifier: "3100001", title: "Upwork job" })], { adapter: "upwork" });
  const guru = extraction(2, [entity("guru", { identifier: "3100001", title: "Guru job" })], { adapter: "guru" });
  const session = Session.create(upwork);
  session.snapshots[guru.extraction.snapshotKey] = guru;
  const merged = Session.merge(session);
  assert.equal(merged.length, 2);
  assert.deepEqual(merged.map((item) => item.title), ["Upwork job", "Guru job"]);
});

test("higher fidelity wins conflicts while fields are unioned", () => {
  let session = Session.create(extraction(1, [entity("1", { name: "Summary", summaryOnly: true })]));
  session = Session.addDocument(session, extraction(2, [entity("1", { name: "Full", description: "Details" })], { fidelity: "full" }));
  const [merged] = Session.merge(session);
  assert.equal(merged.name, "Full");
  assert.equal(merged.description, "Details");
  assert.equal(merged.summaryOnly, true);
  assert.equal(merged["site2json:observations"].length, 2);
});

test("equal-fidelity conflicts are reported", () => {
  let session = Session.create(extraction(1, [entity("1", { name: "First" })]));
  session = Session.addDocument(session, extraction(2, [entity("1", { name: "Second" })]));
  const result = Session.mergeResult(session);
  assert.equal(result.entities[0].name, "Second");
  assert.deepEqual(result.warnings.map((warning) => warning.code), ["entity.equalFidelityConflict"]);
});

test("a finished session is immutable and finish is idempotent", () => {
  const session = Session.create(extraction(1, [entity("1")]));
  const finished = Session.finish(session, "2026-08-08T18:00:00.000Z");
  assert.equal(Session.isFinished(finished), true);
  assert.deepEqual(Session.finish(finished, "2026-08-08T20:00:00.000Z"), finished);
  assert.throws(() => Session.addDocument(finished, extraction(2, [entity("2")])), /already finished/);
});
