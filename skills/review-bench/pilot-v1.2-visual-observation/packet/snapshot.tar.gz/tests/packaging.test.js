"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");

const root = path.resolve(__dirname, "..");
const extension = path.join(root, "extension");

function filesBelow(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? filesBelow(target) : [target];
  });
}

test("the distributable extension contains no private adapter definitions or imperative adapters", () => {
  const relativeFiles = filesBelow(extension).map((file) => path.relative(extension, file));
  assert.equal(fs.existsSync(path.join(extension, "adapters")), false);
  assert.deepEqual(relativeFiles.filter((file) => /(?:^|\/)adapters?\//i.test(file) || /\.dsl\.(?:json|ya?ml)$/i.test(file)), []);
  assert.ok(fs.existsSync(path.join(root, "reference-adapters/upwork-search.dsl.json")));
  assert.ok(fs.existsSync(path.join(root, "reference-adapters/guru.dsl.json")));
  const exporterSource = fs.readFileSync(path.join(extension, "core/exporters.js"), "utf8");
  assert.doesNotMatch(exporterSource, /(?:upwork|guru):/i);
});
