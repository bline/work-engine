"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const FieldDiscovery = require("../extension/editor/field-discovery");
const SemanticCompositions = require("../extension/editor/semantic-compositions");
const SemanticRanking = require("../extension/editor/semantic-ranking");

function marketplaceObservations() {
  return [
    { selector: ".title > a", kind: "url", suggestedName: "url", evidence: { tag: "a", attribute: "href", href: "/work/1", classes: ["result-title"], context: "h2 result title" } },
    { selector: ".title", kind: "text", suggestedName: "title", evidence: { tag: "h2", classes: ["result-title"], text: "Build an API" } },
    { selector: ".posted", kind: "text", suggestedName: "posted", evidence: { tag: "span", classes: ["posted"], text: "Posted Dec 30, 2025" } },
    { selector: ".skills", kind: "text", suggestedName: "skills", multiple: true, evidence: { tag: "a", classes: ["skills"], text: "Python", multiple: true } },
    { selector: ".budget", kind: "text", suggestedName: "budget", evidence: { tag: "div", classes: ["budget"], text: "Fixed Price | $10k-$25k" } }
  ];
}

test("ranks semantic models from generic recurring evidence without choosing one", () => {
  const result = SemanticRanking.rank(marketplaceObservations(), { typeLimit: 8 });
  assert.equal(result.observationCount, 5);
  assert.equal(result.shapeSummary.URL, 1);
  assert.equal(result.shapeSummary.date, 1);
  assert.equal(result.shapeSummary.money, 1);
  assert.equal(result.compositions[0].id, "site2json:freelance-opportunity");
  const explanation = SemanticRanking.explain(marketplaceObservations(), SemanticCompositions.preset("site2json:freelance-opportunity"));
  assert.ok(explanation.mappings.some((item) => item.path === "listing.datePosted"));
  assert.ok(result.types.some((item) => item.id === "schema:JobPosting"));
  assert.equal(Object.prototype.hasOwnProperty.call(result, "selected"), false);
});

test("ranking explanations do not retain sampled page text", () => {
  const secret = "Private Client Name 9bf776";
  const result = SemanticRanking.rank([{ selector: ".name", kind: "text", suggestedName: "name", evidence: { tag: "span", classes: ["name"], text: secret } }], { typeLimit: 2 });
  assert.equal(JSON.stringify(result).includes(secret), false);
});

test("ranking can be bounded to plausible aggregate types for per-item analysis", () => {
  const result = SemanticRanking.rank(marketplaceObservations(), { allowedTypes: ["Person", "JobPosting"], typeLimit: 12 });
  assert.ok(result.types.length > 0);
  assert.ok(result.types.every((candidate) => ["schema:Person", "schema:JobPosting"].includes(candidate.id)));
});

test("invisible DOM type markers contribute root-type evidence without becoming fields", () => {
  const marker = {
    selector: '[data-type="Person"]', kind: "text", suggestedName: "type", selectorKind: "data",
    evidence: { tag: "article", classes: ["result"], text: "", value: "" }
  };
  const result = SemanticRanking.rank([marker], { allowedTypes: ["Person", "Product"], typeLimit: 2 });
  assert.equal(result.types[0].id, "schema:Person");
  assert.ok(result.types[0].evidence.some((item) => item.reasons.some((reason) => /names the item type/.test(reason))));
});

test("Guru marketplace evidence favors the freelance graph and does not make every type explain the same fields", () => {
  const html = fs.readFileSync(path.join(__dirname, "fixtures/guru-search-results.html"), "utf8");
  const dom = new JSDOM(html, { url: "https://www.guru.com/work/" });
  const discovery = FieldDiscovery.discover(dom.window.document, "li[data-id] > .jobRecord");
  const result = SemanticRanking.rank(discovery.candidates, { typeLimit: 12 });
  const freelance = result.compositions.find((candidate) => candidate.id === "site2json:freelance-opportunity");
  const jobPosting = result.types.find((candidate) => candidate.id === "schema:JobPosting");
  assert.ok(freelance.score > jobPosting.score);
  assert.ok(freelance.supportedNodes.length >= 3);
  assert.ok(new Set(result.types.map((candidate) => candidate.explained)).size > 1);
  assert.equal(result.types.some((candidate) => candidate.id === "schema:Vehicle"), false);
  dom.window.close();
});
