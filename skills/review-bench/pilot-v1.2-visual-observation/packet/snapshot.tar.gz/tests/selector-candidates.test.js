"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const SelectorCandidates = require("../extension/editor/selector-candidates");

function domFor(html) {
  return new JSDOM(html).window.document;
}

test("prefers a stable id over everything else", () => {
  const document = domFor(`
    <div>
      <article id="job-42" class="css-1a2b3c4d" data-test="job-tile">
        <h2 data-test="job-title">Title</h2>
      </article>
    </div>
  `);
  const element = document.querySelector("#job-42");
  const candidates = SelectorCandidates.generateCandidates(element, document);
  const best = SelectorCandidates.pickBest(candidates);
  assert.equal(best.selector, "#job-42");
  assert.equal(best.kind, "id");
  assert.equal(best.unique, true);
});

test("treats hash-like ids and classes as generated and skips them", () => {
  const document = domFor(`
    <div>
      <article id="ember4821" class="css-1a2b3c">
        <h2 data-test="job-title">Title</h2>
      </article>
    </div>
  `);
  const element = document.querySelector("article");
  const candidates = SelectorCandidates.generateCandidates(element, document);
  assert.equal(candidates.some((candidate) => candidate.kind === "id"), false);
  assert.equal(candidates.some((candidate) => candidate.kind === "class"), false);
  const best = SelectorCandidates.pickBest(candidates);
  assert.equal(best.kind, "fallback");
});

test("skips common CSS-in-JS and framework-generated class forms", () => {
  const generated = [
    "css-1ujsas3",
    "emotion-1abcde",
    "sc-aXZVg",
    "makeStyles-root-123",
    "jss123",
    "svelte-1a2b3c",
    "_title_ab12c_1",
    "Component_title__3X4bQ",
    "_ngcontent-ng-c1234567"
  ];
  for (const className of generated) {
    const document = domFor(`<article class="${className}">Result</article>`);
    const candidates = SelectorCandidates.generateCandidates(document.querySelector("article"), document);
    assert.equal(candidates.some((candidate) => candidate.kind === "class"), false, className);
  }
});

test("drops styled-components companion hashes but retains explicit semantic hooks", () => {
  const document = domFor(`<article class="sc-aXZVg jZdJPA result-card featured">Result</article>`);
  const element = document.querySelector("article");
  assert.deepEqual(SelectorCandidates.stableClassNames(element), ["result-card", "featured"]);
  const candidates = SelectorCandidates.generateCandidates(element, document);
  assert.equal(candidates[0].selector, ".result-card.featured");
  assert.equal(candidates.some((candidate) => /sc-aXZVg|jZdJPA/.test(candidate.selector)), false);
});

test("does not mistake normal BEM, camelCase, MUI, or utility classes for generated tokens", () => {
  const document = domFor(`<article class="jobRecord__title skillsList MuiButton-root md:grid-cols-2">Result</article>`);
  const element = document.querySelector("article");
  assert.deepEqual(SelectorCandidates.stableClassNames(element), ["jobRecord__title", "skillsList", "MuiButton-root", "md:grid-cols-2"]);
});

test("offers a verified readable prefix for a CSS Module class below stable selectors", () => {
  const document = domFor(`
    <div>
      <button class="Button__button__x7Ea9">One</button>
      <button class="Button__button__x7Ea9">Two</button>
    </div>
  `);
  const candidates = SelectorCandidates.generateCandidates(document.querySelector("button"), document);
  const derived = candidates.find((candidate) => candidate.kind === "derived");
  assert.ok(derived);
  assert.equal(derived.selector, 'button[class*="Button__button__"]');
  assert.equal(derived.matchCount, 2);
  assert.match(derived.note, /Fragile/);
  assert.equal(candidates.some((candidate) => candidate.selector.includes("x7Ea9")), false);
  assert.ok(candidates.indexOf(derived) < candidates.findIndex((candidate) => candidate.kind === "fallback"));
});

test("falls back to data-test attributes when no stable id exists", () => {
  const document = domFor(`
    <ul>
      <li class="css-9f8e7d"><span data-test="job-title">A</span></li>
      <li class="css-9f8e7d"><span data-test="job-title">B</span></li>
    </ul>
  `);
  const elements = document.querySelectorAll("[data-test='job-title']");
  const candidates = SelectorCandidates.generateCandidates(elements[0], document);
  const best = SelectorCandidates.pickBest(candidates);
  assert.equal(best.kind, "data");
  assert.equal(best.unique, false);
  assert.equal(best.matchCount, 2);
  assert.match(best.note, /Matches 2 elements/);
});

test("prefers aria role/label over unstable classes", () => {
  const document = domFor(`
    <div>
      <button class="btn-3f8a9c21b7" aria-label="Save job">Save</button>
    </div>
  `);
  const element = document.querySelector("button");
  const candidates = SelectorCandidates.generateCandidates(element, document);
  const best = SelectorCandidates.pickBest(candidates);
  assert.equal(best.kind, "aria");
  assert.equal(best.selector, '[aria-label="Save job"]');
});

test("uses a short stable class combination when nothing stronger is available", () => {
  const document = domFor(`
    <div>
      <p class="summary highlighted">Text</p>
    </div>
  `);
  const element = document.querySelector("p");
  const candidates = SelectorCandidates.generateCandidates(element, document);
  const best = SelectorCandidates.pickBest(candidates);
  assert.equal(best.kind, "class");
  assert.equal(best.selector, ".summary.highlighted");
});

test("offers individual stable classes as broader multiple-value candidates", () => {
  const document = domFor(`
    <div class="card">
      <div class="skillsList">
        <span class="skillsList__skill greyBackground">Category A</span>
        <span class="skillsList__skill greyBackground">Category B</span>
        <span class="skillsList__skill">Skill C</span>
        <span class="skillsList__skill">Skill D</span>
      </div>
    </div>
  `);
  const card = document.querySelector(".card");
  const selected = document.querySelector(".greyBackground");
  const candidates = SelectorCandidates.generateScopedCandidates(selected, card, document);
  assert.equal(candidates[0].selector, ".skillsList__skill.greyBackground");
  assert.equal(candidates.find((candidate) => candidate.selector === ".skillsList__skill").matchCount, 4);
  assert.equal(candidates.find((candidate) => candidate.selector === ".greyBackground").matchCount, 2);
  assert.equal(candidates.find((candidate) => candidate.selector === ".skillsList > .skillsList__skill").matchCount, 4);
});

test("anchors an unclassed field to a semantic BEM ancestor", () => {
  const document = domFor(`
    <li class="card">
      <div><h2 class="jobRecord__title jobRecord__title--changeVisited"><a href="/work/detail/1">A job</a></h2></div>
    </li>
  `);
  const card = document.querySelector(".card");
  const link = document.querySelector("a");
  const candidates = SelectorCandidates.generateScopedCandidates(link, card, document);
  assert.equal(candidates[0].selector, ".jobRecord__title.jobRecord__title--changeVisited > a");
  assert.equal(candidates[0].kind, "structure");
  assert.ok(candidates.some((candidate) => candidate.selector === ".jobRecord__title.jobRecord__title--changeVisited > a"));
});

test("positional fallback is always generated and flagged as fragile", () => {
  const document = domFor(`
    <ul>
      <li><span>One</span></li>
      <li><span>Two</span></li>
    </ul>
  `);
  const element = document.querySelectorAll("li")[1];
  const candidates = SelectorCandidates.generateCandidates(element, document);
  const fallback = candidates.find((candidate) => candidate.kind === "fallback");
  assert.ok(fallback);
  assert.match(fallback.selector, /nth-of-type/);
  assert.match(fallback.note, /Fragile/);
});

test("generateCandidates returns nothing for a non-element input", () => {
  assert.deepEqual(SelectorCandidates.generateCandidates(null, domFor("<div></div>")), []);
});

test("pickBest returns null when there are no candidates", () => {
  assert.equal(SelectorCandidates.pickBest([]), null);
});

test("scoped candidates report match counts relative to the scope root, not the whole document", () => {
  const document = domFor(`
    <ul>
      <li class="tile"><h2 data-test="title">A</h2></li>
      <li class="tile"><h2 data-test="title">B</h2></li>
    </ul>
  `);
  const tiles = document.querySelectorAll("li.tile");
  const title = tiles[0].querySelector("[data-test='title']");
  const scoped = SelectorCandidates.generateScopedCandidates(title, tiles[0], document);
  const best = SelectorCandidates.pickBest(scoped);
  assert.equal(best.kind, "data");
  assert.equal(best.matchCount, 1);
  assert.equal(best.unique, true);
});

test("scoped positional fallback does not include the scope root's own segment", () => {
  const document = domFor(`
    <li class="tile"><div><span>One</span><span>Two</span></div></li>
  `);
  const scopeRoot = document.querySelector("li.tile");
  const target = document.querySelectorAll("span")[1];
  const scoped = SelectorCandidates.generateScopedCandidates(target, scopeRoot, document);
  const fallback = scoped.find((candidate) => candidate.kind === "fallback");
  assert.ok(fallback);
  assert.doesNotMatch(fallback.selector, /^li/);
  assert.match(fallback.selector, /^div > span:nth-of-type\(2\)$/);
});

test("summarizeElement returns a compact plain-data description", () => {
  const document = domFor(`<article id="job-1" class="tile featured">Hello   world</article>`);
  const element = document.querySelector("article");
  assert.deepEqual(SelectorCandidates.summarizeElement(element), {
    tag: "article",
    id: "job-1",
    classes: ["tile", "featured"],
    text: "Hello world"
  });
});

test("summarizeElement returns null for a non-element", () => {
  assert.equal(SelectorCandidates.summarizeElement(null), null);
});

test("reports open and closed Shadow DOM boundaries while leaving light DOM unmarked", () => {
  const dom = new JSDOM("<!doctype html><job-card id='open'></job-card><job-card id='closed'></job-card><p>Light</p>");
  const document = dom.window.document;
  const openRoot = document.querySelector("#open").attachShadow({ mode: "open" });
  const openTitle = document.createElement("h2");
  openRoot.append(openTitle);
  const closedRoot = document.querySelector("#closed").attachShadow({ mode: "closed" });
  const closedTitle = document.createElement("h2");
  closedRoot.append(closedTitle);
  assert.deepEqual(SelectorCandidates.shadowBoundary(openTitle), {
    mode: "open", host: { tag: "job-card", id: "open", classes: [], text: "" }
  });
  assert.equal(SelectorCandidates.shadowBoundary(closedTitle).mode, "closed");
  assert.equal(SelectorCandidates.shadowBoundary(document.querySelector("p")), null);
  dom.window.close();
});
