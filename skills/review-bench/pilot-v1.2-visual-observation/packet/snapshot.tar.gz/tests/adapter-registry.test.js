"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const Registry = require("../extension/core/adapter-registry");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(path.join(root, "reference-adapters/upwork-search.dsl.json"));

test("local adapter entries hash exact source bytes and canonical definitions separately", async () => {
  const first = await Registry.createEntry(source, "upwork.json", { importedAt: "2026-08-09T01:00:00.000Z" });
  const reformatted = Buffer.concat([source, Buffer.from(" \n")]);
  const second = await Registry.createEntry(reformatted, "upwork-copy.json", { importedAt: "2026-08-09T02:00:00.000Z" });
  assert.equal(first.entry.id, "upwork");
  assert.equal(first.entry.source, "local-file");
  assert.notEqual(first.entry.sourceDigest, second.entry.sourceDigest);
  assert.equal(first.entry.definitionDigest, second.entry.definitionDigest);
  assert.deepEqual(Buffer.from(Registry.sourceBytes(first.entry)), source);
  assert.ok(first.summary.transforms.includes("parseProjectBudgetV1"));
  assert.deepEqual(first.summary.hosts, ["www.upwork.com"]);
});

test("local registry operations replace by adapter id and preserve explicit enablement", async () => {
  const { entry } = await Registry.createEntry(source, "upwork.json", { importedAt: "2026-08-09T01:00:00.000Z" });
  const replacement = { ...entry, importedAt: "2026-08-09T02:00:00.000Z" };
  assert.deepEqual(Registry.upsert([entry], replacement), [replacement]);
  const disabled = Registry.setEnabled([entry], "upwork", false);
  assert.equal(disabled[0].enabled, false);
  assert.deepEqual(Registry.enabledDefinitions(disabled), []);
  assert.deepEqual(Registry.enabledDefinitions([entry]), [entry.definition]);
  assert.deepEqual(Registry.remove([entry], "upwork"), []);
});

test("local entries may retain editor-only state without changing adapter source or definition digests", async () => {
  const source = new TextEncoder().encode(JSON.stringify(require("../reference-adapters/upwork-search.dsl.json")));
  const editorState = { blocks: [{ id: "jobs", composition: { id: "schema:JobPosting" } }] };
  const { entry } = await Registry.createEntry(source, "upwork.json", { editorState });
  assert.deepEqual(entry.editorState, editorState);
  editorState.blocks[0].id = "mutated";
  assert.equal(entry.editorState.blocks[0].id, "jobs", "registry entries must clone mutable editor state");
  assert.deepEqual(JSON.parse(new TextDecoder().decode(Registry.sourceBytes(entry))), require("../reference-adapters/upwork-search.dsl.json"));
});

test("the local registry persists under one extension storage key", async () => {
  const { entry } = await Registry.createEntry(source, "upwork.json");
  const state = {};
  const storage = {
    get: async () => ({ ...state }),
    set: async (value) => Object.assign(state, value)
  };
  await Registry.save([entry], storage);
  assert.deepEqual(await Registry.load(storage), [entry]);
  assert.deepEqual(Object.keys(state), [Registry.STORAGE_KEY]);
});
