"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { JSDOM } = require("jsdom");
const TransformCatalog = require("../extension/editor/transform-catalog");
const TransformPicker = require("../extension/editor/transform-picker");
const SemanticCompositions = require("../extension/editor/semantic-compositions");
const SchemaVocabulary = require("../extension/editor/schema-vocabulary");

const root = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(root, "extension/editor/table-panel.html"), "utf8");
const source = fs.readFileSync(path.join(root, "extension/editor/table-panel.js"), "utf8");

function loadPanel() {
  const dom = new JSDOM(html, { url: "chrome-extension://test/editor/table-panel.html?tabId=41", runScripts: "outside-only" });
  const { window } = dom;
  window.HTMLElement.prototype.scrollIntoView = function scrollIntoView() {};
  let messageListener;
  let disconnectListener;
  const sent = [];
  const port = {
    postMessage: (message) => { sent.push(message); },
    onMessage: { addListener: (listener) => { messageListener = listener; } },
    onDisconnect: { addListener: (listener) => { disconnectListener = listener; } }
  };
  window.chrome = { runtime: { connect: ({ name }) => { assert.equal(name, "site2json-table:41"); return port; } } };
  window.Site2JsonTransformCatalog = TransformCatalog;
  window.Site2JsonTransformPicker = TransformPicker;
  window.Site2JsonSemanticCompositions = SemanticCompositions;
  window.Site2JsonSchemaVocabulary = SchemaVocabulary;
  window.eval(source);
  return {
    dom, window, sent,
    receive: (message) => messageListener(message),
    disconnect: () => disconnectListener()
  };
}

test("renders fields vertically with every matched item available horizontally", () => {
  const { dom, window, receive, sent } = loadPanel();
  receive({ type: "relay-status", sidebarConnected: true });
  receive({
    type: "table-snapshot",
    snapshot: {
      pageUrl: "https://example.com/jobs", activeBlockId: "jobs", stale: false,
      blocks: [{ id: "jobs", name: "Jobs", schemaType: "JobPosting", matchCount: 7 }],
      activeBlock: {
        id: "jobs", name: "Jobs", schemaType: "JobPosting", scope: ".results > li", matchCount: 7,
        fields: [
          { key: ".title\u001fhref\u001furl", name: "url", label: "url", selector: ".title", attribute: "href", identity: true, unresolved: false },
          { key: ".code\u001f\u001ftext", name: "_unmapped_code_1", label: "_unmapped_code_1", selector: ".code", attribute: null, identity: false, unresolved: true }
        ]
      },
      rows: Array.from({ length: 7 }, (_unused, index) => ({
        index,
        values: { url: `https://example.com/jobs/${index + 1}`, _unmapped_code_1: index === 6 ? null : `C-${index + 1}` }
      }))
    }
  });
  const document = window.document;
  assert.deepEqual(Array.from(document.querySelectorAll("#table-body tr:not(.add-field-row) .field-label > span"), (node) => node.textContent), ["url identity", "_unmapped_code_1"]);
  assert.equal(document.querySelectorAll("#table-head th").length, 8, "every matched item should remain available for horizontal debugging");
  assert.deepEqual(Array.from(document.querySelectorAll("#table-head th:not(:first-child)"), (node) => node.textContent), ["1", "2", "3", "4", "5", "6", "7"]);
  assert.match(document.querySelectorAll(".field-coverage")[1].textContent, /6\/7 present · unmapped/);
  assert.ok(document.querySelector("#table-body td.unresolved"));
  assert.equal(document.querySelector("#table-head").textContent.includes("Item"), false);

  document.querySelector(".field-action.edit").click();
  assert.ok(sent.some((message) => message.command?.action === "edit-field" && message.command.identity));
  document.querySelector(".add-button").click();
  assert.ok(sent.some((message) => message.command?.action === "add-selected-field"));
  const firstValue = document.querySelectorAll("#table-body tr:not(.add-field-row) td")[1];
  firstValue.click();
  assert.ok(firstValue.classList.contains("pinned"));
  assert.ok(sent.some((message) => message.command?.action === "highlight" && message.command.target.rootIndex === 0));
  firstValue.dispatchEvent(new window.MouseEvent("dblclick", { bubbles: true }));
  assert.ok(sent.some((message) => message.command?.action === "scroll-to-target" && message.command.target.rootIndex === 0));
  receive({ type: "clear-pinned-state" });
  assert.equal(firstValue.classList.contains("pinned"), false);
  dom.window.close();
});

test("surfaces stale and disconnected editor state", () => {
  const { dom, window, receive, disconnect } = loadPanel();
  receive({ type: "relay-status", sidebarConnected: true });
  receive({ type: "table-snapshot", snapshot: { stale: true, blocks: [], rows: [] } });
  assert.ok(window.document.querySelector("#connection-status").classList.contains("stale"));
  disconnect();
  assert.ok(window.document.querySelector("#connection-status").classList.contains("error"));
  dom.window.close();
});

test("surfaces structural drift in Review and routes findings to their exact field", () => {
  const { dom, window, receive, sent } = loadPanel();
  const finding = {
    code: "field.selectorMissing", severity: "strong-warning", blockId: "jobs", blockName: "Jobs",
    variantEntityName: "JobPosting", variantLabel: "JobPosting", fieldKey: "title-key",
    title: "Jobs · JobPosting · title", message: "Selector coverage fell from 100% to 0%.",
    target: { withinSelector: ".job", selector: ".title" }
  };
  const snapshot = {
    pageUrl: "https://example.com/jobs", activeBlockId: "jobs", stale: false,
    blocks: [{ id: "jobs", name: "Jobs", schemaType: "JobPosting", matchCount: 2 }],
    activeBlock: { id: "jobs", name: "Jobs", schemaType: "JobPosting", scope: ".job", matchCount: 2,
      fields: [{ key: "title-key", name: "title", label: "title", selector: ".title", identity: false, unresolved: false }] },
    rows: [{ index: 0, values: { title: null } }, { index: 1, values: { title: null } }],
    driftReview: { status: "ready", findings: [finding], message: "1 structural finding · 1 strong warning." }
  };
  receive({ type: "relay-status", sidebarConnected: true });
  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot, editor: { hasValidDefinition: true, finish: { canCheckStructuralHealth: true } }, workflow: {
    current: "review", steps: [{ id: "review", status: "current" }]
  } });
  const document = window.document;
  assert.equal(document.querySelector("#drift-review").hidden, false);
  assert.match(document.querySelector("#drift-review-summary").textContent, /1 structural finding/);
  assert.match(document.querySelector(".drift-finding").textContent, /Jobs · JobPosting · title/);
  document.querySelector(".drift-finding").dispatchEvent(new window.MouseEvent("mouseenter"));
  assert.ok(sent.some((message) => message.command?.action === "preview-highlight" && message.command.target.selector === ".title"));
  document.querySelector(".drift-finding").click();
  assert.ok(sent.some((message) => message.command?.action === "open-structural-finding" && message.command.finding.fieldKey === "title-key"));
  document.querySelector("#drift-review-check").click();
  assert.ok(sent.some((message) => message.command?.action === "check-structural-health"));
  dom.window.close();
});

test("focuses the exact table cell represented by the current Elements selection", () => {
  const { dom, window, receive } = loadPanel();
  receive({ type: "relay-status", sidebarConnected: true });
  receive({
    type: "table-snapshot",
    snapshot: {
      pageUrl: "https://example.com/jobs", activeBlockId: "jobs", stale: false,
      blocks: [{ id: "jobs", name: "Jobs", schemaType: "JobPosting", matchCount: 2 }],
      activeBlock: { id: "jobs", name: "Jobs", schemaType: "JobPosting", scope: ".job", matchCount: 2,
        fields: [
          { key: "title-key", name: "title", label: "title", selector: ".title", identity: false, unresolved: false },
          { key: "second-key", name: "datePosted", label: "datePosted", selector: ".date", identity: false, unresolved: false }
        ] },
      rows: [
        { index: 0, values: { title: "First", datePosted: "2026-01-01" } },
        { index: 1, values: { title: "Second", datePosted: "2026-01-02" } }
      ]
    }
  });
  receive({ type: "selection-focus", focus: {
    ok: true, blockId: "jobs", rootIndex: 1, fieldMatches: [{ key: "title-key", mode: "exact" }], selected: { tag: "h2", text: "Second" }
  } });
  const row = window.document.querySelector("tr[data-field-key='title-key']");
  assert.ok(row.querySelector("[data-root-index='1']").classList.contains("elements-selection"));
  assert.equal(row.querySelector("td").classList.contains("elements-selection"), false, "the field label should not duplicate exact-cell selection focus");
  assert.match(window.document.querySelector("#connection-status").textContent, /title · item 2/);

  receive({ type: "selection-focus", focus: { ok: true, blockId: "jobs", rootIndex: 0, fieldMatches: [], selected: { tag: "span", text: "New" } } });
  assert.equal(window.document.querySelectorAll(".elements-selection").length, 0, "an unmapped leaf should not masquerade as a whole-item selection");
  assert.match(window.document.querySelector("#connection-status").textContent, /not mapped/);

  receive({ type: "selection-focus", focus: {
    ok: true, blockId: "jobs", rootIndex: 0, isScopeRoot: false,
    fieldMatches: [{ key: "title-key", mode: "contains-field" }, { key: "second-key", mode: "contains-field" }],
    selected: { tag: "div", text: "Mapped container" }
  } });
  assert.equal(window.document.querySelector("#table-head [data-root-index='0']").classList.contains("elements-selection"), false, "a mapped container is not the whole item");
  assert.ok(window.document.querySelector("tr[data-field-key='title-key'] [data-root-index='0']").classList.contains("elements-selection"));
  assert.ok(window.document.querySelector("tr[data-field-key='second-key'] [data-root-index='0']").classList.contains("elements-selection"));
  dom.window.close();
});

test("renders controller workflow state and obeys the exclusive editing lease", () => {
  const { dom, window, receive, sent } = loadPanel();
  receive({ type: "relay-status", sidebarConnected: true });
  receive({ type: "controller-state", lease: { owner: "sidebar" }, workflow: {
    current: "discover",
    steps: [
      { id: "structure", status: "complete" },
      { id: "semantics", status: "complete" },
      { id: "discover", status: "current" },
      { id: "review", status: "pending" },
      { id: "finish", status: "pending" }
    ]
  }, snapshot: null, selectionFocus: null });
  const document = window.document;
  assert.equal(document.querySelectorAll(".workflow-step").length, 5);
  assert.ok(document.querySelector(".workflow-step.current").textContent.includes("Discover"));
  assert.equal(document.querySelector("#lease-paused").hidden, false);
  document.querySelector("#resume-expanded-button").click();
  assert.ok(sent.some((message) => message.type === "lease-command" && message.owner === "expanded"));

  receive({ type: "controller-state", lease: { owner: "expanded" }, workflow: { current: "review", steps: [] }, snapshot: null, selectionFocus: null });
  assert.equal(document.querySelector("#lease-paused").hidden, true);
  dom.window.close();
});

test("creates a repeating block from the expanded Structure route", () => {
  const { dom, window, receive, sent } = loadPanel();
  const workflow = {
    current: "structure",
    steps: [
      { id: "structure", status: "current" }, { id: "semantics", status: "pending" },
      { id: "discover", status: "pending" }, { id: "review", status: "pending" }, { id: "finish", status: "pending" }
    ]
  };
  const base = {
    pageUrl: "https://example.com/jobs", activeBlockId: null, stale: false, blocks: [], activeBlock: null, rows: [],
    structure: {
      selection: { ok: true, summary: { tag: "li", id: null, classes: ["job"], text: "Example job" } },
      status: "Recommended scope matches 12 elements.", statusKind: "ready",
      proposals: [{ index: 0, tag: "li", selector: ".jobs > li", kind: "structure", matchCount: 12, selected: true, findings: [{ kind: "good", message: "All matches share one parent." }] }],
      pendingScope: null, blockName: "Results", schemaType: "Thing"
    }
  };
  receive({ type: "relay-status", sidebarConnected: true });
  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot: base, workflow, editor: { finish: { canInferRemaining: true, buildStatus: "" } } });
  const document = window.document;
  Array.from(document.querySelectorAll(".workflow-step")).find((button) => button.textContent === "Structure").click();
  assert.equal(document.querySelector("#structure-route").hidden, false);
  assert.match(document.querySelector("#structure-selection").textContent, /<li>.*\.job.*Example job/);
  assert.equal(document.querySelector("#structure-automatic").disabled, false);
  document.querySelector("#structure-automatic").click();
  assert.ok(sent.some((message) => message.command?.action === "infer-remaining"));
  assert.match(document.querySelector(".scope-proposal").textContent, /12 matches/);
  document.querySelector("#structure-single-item").checked = true;
  document.querySelector("#structure-infer").click();
  assert.ok(sent.some((message) => message.command?.action === "infer-scope" && message.command.allowSingle === true));
  document.querySelector("#structure-scan-page").click();
  assert.ok(sent.some((message) => message.command?.action === "find-page-scopes"));
  document.querySelector(".scope-proposal button").click();
  assert.ok(sent.some((message) => message.command?.action === "accept-scope" && message.command.selector === ".jobs > li"));

  receive({ type: "controller-state", lease: { owner: "expanded" }, workflow, editor: null, snapshot: {
    ...base,
    structure: { ...base.structure, proposals: [], pendingScope: { selector: ".jobs > li", matchCount: 12 }, schemaType: "JobPosting" }
  } });
  assert.equal(document.querySelector("#structure-block-form").hidden, false);
  document.querySelector("#structure-block-name").value = "Jobs";
  document.querySelector("#structure-schema-type").value = "JobPosting";
  document.querySelector("#structure-block-form").dispatchEvent(new window.Event("submit", { bubbles: true, cancelable: true }));
  assert.ok(sent.some((message) => message.command?.action === "create-block" && message.command.name === "Jobs" && message.command.schemaType === "JobPosting"));

  const composition = SemanticCompositions.singleType("JobPosting");
  receive({ type: "controller-state", lease: { owner: "expanded" }, workflow, editor: null, snapshot: {
    ...base,
    activeBlockId: "block-1",
    blocks: [{ id: "block-1", name: "Jobs", schemaType: "JobPosting", matchCount: 12, unresolvedCount: 0 }],
    activeBlock: {
      id: "block-1", name: "Jobs", schemaType: "JobPosting", scope: ".jobs > li", matchCount: 12,
      composition, compositionValidation: SemanticCompositions.validate(composition), semanticsReviewed: true,
      discovery: { includeUnmapped: true, canUndo: false, report: null }, fields: []
    },
    rows: [], structure: { ...base.structure, proposals: [], pendingScope: null }
  } });
  assert.equal(document.querySelector("#semantics-route").hidden, false, "successful creation should advance to Semantics");
  assert.equal(document.querySelector(".workflow-step.active").textContent, "Semantics");
  dom.window.close();
});

test("edits a field in the expanded workspace and returns to its table row", async () => {
  const { dom, window, receive, sent } = loadPanel();
  const snapshot = {
    pageUrl: "https://example.com/jobs", activeBlockId: "jobs", stale: false,
    blocks: [{ id: "jobs", name: "Jobs", schemaType: "JobPosting", matchCount: 2, unresolvedCount: 1 }],
    activeBlock: {
      id: "jobs", name: "Jobs", schemaType: "JobPosting", scope: ".job", matchCount: 2,
      fields: [
        { key: "identity", name: "canonicalUrl", label: "canonical URL", selector: ".title", attribute: "href", identity: true, required: true, unresolved: false },
        { key: "title-key", name: "title", label: "title", selector: ".title", identity: false, required: true, unresolved: true }
      ]
    },
    rows: [
      { index: 0, values: { canonicalUrl: "https://example.com/1", title: "First" } },
      { index: 1, values: { canonicalUrl: "https://example.com/2", title: null } }
    ]
  };
  receive({ type: "relay-status", sidebarConnected: true });
  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot, workflow: { current: "review", steps: [] }, editor: null });
  const document = window.document;
  assert.match(document.querySelector("#issue-summary").textContent, /1 unmapped/);
  assert.match(document.querySelector("#issue-summary").textContent, /1 required field incomplete/);
  document.querySelector("tr[data-field-key='title-key'] .field-action.edit").click();

  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot, workflow: { current: "review", steps: [] }, editor: {
    route: "field",
    fieldEditor: {
      key: "title-key", title: "Edit title", context: "Jobs · JobPosting", status: "Review this mapping.", statusKind: "ready",
      selector: ".title", selectorEvidence: "class · coverage 2/2", selectorCandidates: [{ selector: ".title", kind: "class", matchCount: 2 }],
      name: "title", nameCandidates: [{ name: "title", source: "schema", valueType: "Text", description: "Headline" }],
      kind: "text", attribute: "", multiple: false, identity: false, required: true,
      pipeline: ["text", "trim"], semanticStatus: "Schema.org JobPosting.title", semanticKind: "standard", customTerm: null,
      proposal: { summary: "Selected <h2>", selector: ".new-title", coverage: "Coverage 2/2" }, preview: "[\"First\", \"Second\"]", submitLabel: "Save field"
    }
  } });
  assert.equal(document.querySelector("#field-editor-route").hidden, false);
  assert.equal(document.querySelector("#review-route").hidden, true);
  assert.equal(document.querySelector("#field-selector").value, ".title");
  assert.deepEqual(Array.from(document.querySelectorAll("#field-pipeline .pipeline-step"), (node) => node.firstChild.textContent), ["text", "trim"]);
  assert.equal(document.querySelector("#selection-proposal").hidden, false);

  document.querySelector("#field-selector").value = ".job-title";
  document.querySelector("#field-selector").dispatchEvent(new window.Event("input", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 180));
  assert.ok(sent.some((message) => message.command?.action === "preview-field-form" && message.command.form.selector === ".job-title"));

  const transformSearch = document.querySelector("#transform-search");
  transformSearch.value = "text slice";
  transformSearch.dispatchEvent(new window.Event("input", { bubbles: true }));
  const textSlice = Array.from(document.querySelectorAll("#transform-options .suggestion-option"))
    .find((button) => /Slice text/.test(button.textContent));
  assert.ok(textSlice, "argument-bearing packaged transform should be searchable in the expanded editor");
  textSlice.click();
  assert.equal(document.querySelector("#transform-arguments").hidden, false);
  const argumentInputs = document.querySelectorAll("#transform-argument-fields [data-argument-index]");
  argumentInputs[0].value = "1";
  argumentInputs[1].value = "8";
  document.querySelector("#transform-arguments-save").click();
  assert.ok(Array.from(document.querySelectorAll("#field-pipeline .pipeline-step"), (node) => node.firstChild.textContent).includes("textSlice(1, 8)"));

  document.querySelector("#field-editor-form").dispatchEvent(new window.Event("submit", { bubbles: true, cancelable: true }));
  const save = sent.findLast((message) => message.command?.action === "save-field-form");
  assert.equal(save.command.form.selector, ".job-title");
  assert.deepEqual(save.command.form.pipeline, ["text", "trim", { name: "textSlice", args: [1, 8] }], "saving in the expanded view must preserve configured transform arguments");

  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot, workflow: { current: "review", steps: [] }, editor: { route: "review", fieldEditor: null } });
  assert.equal(document.querySelector("#review-route").hidden, false);
  assert.ok(document.querySelector("tr[data-field-key='title-key']").classList.contains("return-focus"));
  dom.window.close();
});

test("authors a semantic composition from the expanded workflow", () => {
  const { dom, window, receive, sent } = loadPanel();
  const composition = SemanticCompositions.singleType("JobPosting");
  const snapshot = {
    pageUrl: "https://example.com/jobs", activeBlockId: "jobs", stale: false,
    blocks: [{ id: "jobs", name: "Jobs", schemaType: "JobPosting", matchCount: 2, compositionValid: true, semanticsReviewed: true, compositionLabel: "JobPosting" }],
    activeBlock: {
      id: "jobs", name: "Jobs", schemaType: "JobPosting", scope: ".job", matchCount: 2,
      composition, compositionValidation: SemanticCompositions.validate(composition), semanticsReviewed: true, fields: []
    },
    rows: []
  };
  receive({ type: "relay-status", sidebarConnected: true });
  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot, editor: null, workflow: {
    current: "discover", steps: [
      { id: "structure", status: "complete" }, { id: "semantics", status: "complete" },
      { id: "discover", status: "current" }, { id: "review", status: "pending" }, { id: "finish", status: "pending" }
    ]
  } });
  const document = window.document;
  Array.from(document.querySelectorAll(".workflow-step")).find((button) => button.textContent === "Semantics").click();
  assert.equal(document.querySelector("#semantics-route").hidden, false);
  assert.ok(Array.from(document.querySelectorAll(".workflow-step")).find((button) => button.textContent === "Semantics").classList.contains("active"));
  assert.equal(Array.from(document.querySelectorAll(".workflow-step")).find((button) => button.textContent === "Semantics").getAttribute("aria-current"), "step");
  assert.match(document.querySelector("#model-current").textContent, /JobPosting · 1 node/);
  assert.equal(document.querySelectorAll(".composition-node").length, 1);

  document.querySelector("#related-type").value = "Organization";
  document.querySelector("#related-type").dispatchEvent(new window.Event("input", { bubbles: true }));
  assert.ok(Array.from(document.querySelectorAll("#related-property option"), (option) => option.value).includes("hiringOrganization"));
  document.querySelector("#related-property").value = "hiringOrganization";
  document.querySelector("#related-alias").value = "buyer";
  document.querySelector("#add-related-node").click();
  assert.ok(sent.some((message) => message.command?.action === "add-semantic-node" && message.command.alias === "buyer"));

  const modelSearch = document.querySelector("#model-search");
  modelSearch.value = "freelance";
  modelSearch.dispatchEvent(new window.Event("input", { bubbles: true }));
  const freelance = Array.from(document.querySelectorAll("#model-options .suggestion-option")).find((button) => /Freelance marketplace opportunity/.test(button.textContent));
  assert.ok(freelance);
  freelance.click();
  assert.ok(sent.some((message) => message.command?.action === "set-semantic-model" && message.command.modelId === "site2json:freelance-opportunity"));
  document.querySelector("#semantics-done").click();
  assert.ok(sent.some((message) => message.command?.action === "finish-semantics"));
  dom.window.close();
});

test("renders explainable model rankings and leaves selection explicit", () => {
  const { dom, window, receive, sent } = loadPanel();
  receive({ type: "relay-status", sidebarConnected: true });
  const composition = SemanticCompositions.singleType("Thing");
  const snapshot = {
    pageUrl: "https://example.com/jobs", activeBlockId: "jobs", stale: false,
    blocks: [{ id: "jobs", name: "Jobs", matchCount: 3, compositionValid: true, semanticsReviewed: false }],
    activeBlock: {
      id: "jobs", name: "Jobs", matchCount: 3, composition,
      compositionValidation: SemanticCompositions.validate(composition), semanticsReviewed: false, fields: [],
      semanticRanking: {
        status: "ready", sampledScopes: 3, totalScopes: 3, observationCount: 4,
        shapeSummary: { URL: 1, date: 1 },
        compositions: [{ id: "site2json:freelance-opportunity", label: "Freelance marketplace opportunity", kind: "composition", score: 20, explained: 3, total: 4, supportedNodes: [{ alias: "buyer" }], evidence: [{ observation: ".title", path: "listing.title" }] }],
        types: [{ id: "schema:JobPosting", label: "JobPosting", kind: "schema-type", score: 24, explained: 4, total: 4, evidence: [{ observation: ".posted", path: "listing.datePosted" }] }]
      }
    }, rows: []
  };
  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot, editor: null, workflow: {
    current: "semantics", steps: [{ id: "structure", status: "complete" }, { id: "semantics", status: "current" }, { id: "discover", status: "pending" }, { id: "review", status: "pending" }, { id: "finish", status: "pending" }]
  } });
  Array.from(window.document.querySelectorAll(".workflow-step")).find((button) => button.textContent === "Semantics").click();
  assert.match(window.document.querySelector("#model-ranking-status").textContent, /Observed 4 recurring values/);
  assert.deepEqual(Array.from(window.document.querySelectorAll(".model-ranking strong"), (node) => node.textContent), ["JobPosting", "Freelance marketplace opportunity"]);
  assert.match(Array.from(window.document.querySelectorAll(".model-ranking small"), (node) => node.textContent).join(" "), /supports 1 related concept/);
  assert.equal(sent.some((message) => message.command?.action === "set-semantic-model"), false);
  window.document.querySelector(".model-ranking").click();
  assert.ok(sent.some((message) => message.command?.action === "set-semantic-model" && message.command.modelId === "schema:JobPosting"));
  dom.window.close();
});

test("runs discovery and undo from the expanded workflow", () => {
  const { dom, window, receive, sent } = loadPanel();
  const composition = SemanticCompositions.singleType("JobPosting");
  const snapshot = {
    pageUrl: "https://example.com/jobs", activeBlockId: "jobs", stale: false,
    blocks: [{ id: "jobs", name: "Jobs", matchCount: 4, compositionValid: true, semanticsReviewed: true }],
    activeBlock: {
      id: "jobs", name: "Jobs", scope: ".job", matchCount: 4, schemaType: "JobPosting", composition,
      compositionValidation: SemanticCompositions.validate(composition), semanticsReviewed: true,
      discovery: { includeUnmapped: true, canUndo: true, report: { kind: "ready", message: "Scanned 4/4 items. Fields: added 3." } },
      fields: [
        { key: "identity", name: "canonicalUrl", identity: true, unresolved: false },
        { key: "title", name: "title", identity: false, unresolved: false },
        { key: "mystery", name: "_unmapped_1", identity: false, unresolved: true }
      ]
    }, rows: []
  };
  receive({ type: "relay-status", sidebarConnected: true });
  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot, editor: null, workflow: {
    current: "discover", steps: [{ id: "structure", status: "complete" }, { id: "semantics", status: "complete" }, { id: "discover", status: "current" }, { id: "review", status: "pending" }, { id: "finish", status: "pending" }]
  } });
  const document = window.document;
  Array.from(document.querySelectorAll(".workflow-step")).find((button) => button.textContent === "Discover").click();
  assert.equal(document.querySelector("#discover-route").hidden, false);
  assert.match(document.querySelector("#discover-report").textContent, /added 3/);
  assert.deepEqual(Array.from(document.querySelectorAll("#discover-counts strong"), (node) => node.textContent), ["3", "2", "1", "present"]);
  document.querySelector("#discover-run").click();
  assert.ok(sent.some((message) => message.command?.action === "discover-fields" && message.command.includeUnmapped === true));
  document.querySelector("#discover-undo").click();
  assert.ok(sent.some((message) => message.command?.action === "undo-discovery"));
  document.querySelector("#discover-review").click();
  assert.equal(document.querySelector("#review-route").hidden, false);
  dom.window.close();
});

test("validates, previews, saves, exports, and publishes from the expanded Finish route", () => {
  const { dom, window, receive, sent } = loadPanel();
  const composition = SemanticCompositions.singleType("JobPosting");
  const snapshot = {
    pageUrl: "https://example.com/jobs", activeBlockId: "jobs", stale: false,
    blocks: [{ id: "jobs", name: "Jobs", matchCount: 2, compositionValid: true, semanticsReviewed: true }],
    activeBlock: { id: "jobs", name: "Jobs", matchCount: 2, schemaType: "JobPosting", composition, compositionValidation: SemanticCompositions.validate(composition), fields: [] }, rows: []
  };
  receive({ type: "relay-status", sidebarConnected: true });
  receive({ type: "controller-state", lease: { owner: "expanded" }, snapshot, workflow: {
    current: "finish", steps: [{ id: "structure", status: "complete" }, { id: "semantics", status: "complete" }, { id: "discover", status: "complete" }, { id: "review", status: "complete" }, { id: "finish", status: "current" }]
  }, editor: { finish: {
    adapterId: "example", namespace: "https://example.com/#", pageId: "search", pageType: "SearchResultsPage",
    valid: true, canSave: true, canExport: true, canPublish: true, canCaptureFixture: true, canInferRemaining: true,
    buildStatus: "Adapter draft is valid.", buildStatusKind: "ready", draftStatus: "Draft saved locally.", draftStatusKind: "ready",
    preview: '{"entities":2}'
  } } });
  const document = window.document;
  Array.from(document.querySelectorAll(".workflow-step")).find((button) => button.textContent === "Finish").click();
  assert.equal(document.querySelector("#finish-route").hidden, false);
  assert.equal(document.querySelector("#finish-adapter-id").value, "example");
  assert.match(document.querySelector("#finish-build-status").textContent, /valid/);
  assert.equal(document.querySelector("#finish-preview-wrap").hidden, false);
  document.querySelector("#finish-adapter-id").value = "renamed";
  document.querySelector("#finish-adapter-id").dispatchEvent(new window.Event("change", { bubbles: true }));
  assert.ok(sent.some((message) => message.command?.action === "update-finish-metadata" && message.command.metadata.adapterId === "renamed"));
  for (const [selector, action] of [["#finish-build", "build-draft"], ["#finish-refresh-baseline", "refresh-structural-baseline"], ["#finish-capture-fixture", "capture-fixture"], ["#finish-preview", "preview-extraction"], ["#finish-save", "save-draft"], ["#finish-export", "export-draft"], ["#finish-publish", "publish-draft"]]) {
    document.querySelector(selector).click();
    assert.ok(sent.some((message) => message.command?.action === action), `${action} was not sent`);
  }
  dom.window.close();
});
