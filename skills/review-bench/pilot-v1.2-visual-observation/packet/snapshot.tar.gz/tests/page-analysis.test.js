"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const PageAnalysis = require("../extension/authoring/page-analysis");

function candidate(index) {
  return { selector: `.results > li.kind-${index}`, tag: "li", matchCount: 10 - index, score: 100 - index, observations: [{ suggestedName: "title" }] };
}

test("Page Analysis coalesces a high-confidence leading pass by page revision", async () => {
  let scans = 0;
  const analyzed = [];
  const candidates = [candidate(0), candidate(1)];
  const service = PageAnalysis.create({
    findScopes: async () => {
      scans += 1;
      return { ok: true, pageUrl: "https://example.test/jobs", evidenceCount: 20, durationMs: 37.4, confidence: "high", margin: 18, candidates, chosen: candidates[0] };
    },
    analyzeScope: async (item) => {
      analyzed.push(item.selector);
      return { recommendation: { schemaType: "JobPosting", confidence: "high" }, variantAnalysis: { status: "ready", mixed: false, candidates: [] } };
    }
  });
  const context = { pageUrl: "https://example.test/jobs", frame: "top", revision: 4 };
  const first = service.start({ key: "tab|top|jobs|4", context });
  const second = service.start({ key: "tab|top|jobs|4", context });
  assert.equal(first, second);
  const report = await second.complete();
  assert.equal(scans, 1);
  assert.deepEqual(analyzed, [candidates[0].selector]);
  assert.equal(report.complete, true);
  assert.equal(report.structuralDurationMs, 37.4);
  assert.equal(report.decision.status, "accepted");
  assert.equal(report.candidates[0].analysis.recommendation.schemaType, "JobPosting");
});

test("manual consumers can use a progressive leader while complete consumers await the bounded set", async () => {
  const analyzed = [];
  const candidates = [candidate(0), candidate(1), candidate(2), candidate(3)];
  const service = PageAnalysis.create({
    candidateLimit: 3,
    findScopes: async () => ({ ok: true, evidenceCount: 12, confidence: "medium", margin: 3, candidates, chosen: candidates[0] }),
    analyzeScope: async (item) => {
      analyzed.push(item.selector);
      return { recommendation: { schemaType: "Thing" } };
    }
  });
  const session = service.start({ key: "revision-1" });
  const leading = await session.leading();
  assert.equal(leading.status, "progressive");
  assert.equal(leading.complete, false);
  assert.deepEqual(analyzed, [candidates[0].selector]);
  const complete = await session.complete();
  assert.equal(complete.complete, true);
  assert.equal(complete.decision.status, "review");
  assert.deepEqual(analyzed, candidates.slice(0, 3).map((item) => item.selector));
});

test("a changed document revision creates a fresh analysis session", async () => {
  let scans = 0;
  const item = candidate(0);
  const service = PageAnalysis.create({
    findScopes: async () => {
      scans += 1;
      return { ok: true, confidence: "high", margin: 20, candidates: [item], chosen: item };
    },
    analyzeScope: async () => ({})
  });
  await service.start({ key: "page|revision-1" }).leading();
  await service.start({ key: "page|revision-2" }).leading();
  assert.equal(scans, 2);
});

test("a singleton requires high semantic confidence in addition to its structural margin", async () => {
  const detail = { selector: "article", tag: "article", matchCount: 1, singleton: true, score: 128, observations: [{ suggestedName: "headline" }] };
  const service = PageAnalysis.create({
    findScopes: async () => ({ ok: true, mode: "single", evidenceCount: 8, confidence: "high", margin: 22, candidates: [detail], chosen: detail }),
    analyzeScope: async () => ({ recommendation: { schemaType: "Article", confidence: "low" } })
  });
  const report = await service.start({ key: "uncertain-detail" }).complete();
  assert.equal(report.scopeMode, "single");
  assert.equal(report.decision.status, "review");
  assert.equal(report.decision.semanticAccepted, false);
  assert.equal(report.decision.accepted, false);
});

test("a structurally and semantically confident singleton is accepted as one item", async () => {
  const detail = { selector: "article", tag: "article", matchCount: 1, singleton: true, score: 128, observations: [{ suggestedName: "headline" }] };
  const service = PageAnalysis.create({
    findScopes: async () => ({ ok: true, mode: "single", evidenceCount: 8, confidence: "high", margin: 22, candidates: [detail], chosen: detail }),
    analyzeScope: async () => ({ recommendation: { schemaType: "Article", confidence: "high" } })
  });
  const report = await service.start({ key: "confident-detail" }).complete();
  assert.equal(report.scopeMode, "single");
  assert.equal(report.decision.status, "accepted");
  assert.equal(report.decision.semanticAccepted, true);
  assert.equal(report.candidates[0].matchCount, 1);
});
