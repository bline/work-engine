# Site2JSON Agent Instructions

These instructions apply to the entire repository.

`DESIGN_PRINCIPLES.md` is the canonical statement of the project's design
philosophy. Read it before making material product, architecture, interaction,
terminology, documentation, or presentation decisions. Apply its four equal
principles together:

- Truth
- Maintainability
- Explainability
- Aesthetics

Do not silently trade one principle away for another. When they appear to
conflict, treat the conflict as an unfinished design problem and look for a
solution that preserves what each principle protects.

## Truth

- Truth seeks correspondence with reality. Verification is one tool for getting
  there, not an end in itself.
- Direct observation, trustworthy testimony, established context, sound
  inference, memory, and prior evidence can all be legitimate inputs. The key
  questions are whether confidence matches the evidence and whether verification
  effort matches the stakes.
- Represent the real process and real state. Do not replace uncertainty,
  arbitration, fallbacks, variants, drift, provenance, or unresolved decisions
  with a simpler fiction.
- Keep observed evidence, inference, user decisions, confidence, alternatives,
  and unresolved state distinguishable in data structures and interfaces.
- Name controls and concepts after what they actually do. Prefer mechanism-level
  language that a user can understand over vague product language.
- Base visualizations, statuses, and motion on actual internal state or recorded
  events. Never animate a process the system did not perform.
- Do not overstate what a test, sample, score, preview, or successful extraction
  proves. Make scope and limitations explicit.

## Maintainability

- The smallest meaningful authored decision is the unit of user ownership.
  Editing one field, relationship, transform, override, or pin must not make the
  user responsible for unrelated inferred state.
- Preserve the distinction between inferred, reviewed, modified, pinned,
  automatically maintainable, and approval-required decisions.
- Let the system maintain untouched state automatically whenever it can do so
  safely. Do not turn users into janitors for automation.
- Keep code modular, legible, refactorable, and tested. Prefer shared primitives
  over parallel scoring, validation, rendering, or persistence systems.
- Keep runtime boundaries explicit. Do not accidentally move catalogs,
  authoring-only dependencies, raw DOM references, or other heavyweight state
  into compiled/runtime artifacts.
- Treat stale documentation as a defect. Update relevant documentation, tests,
  generated artifacts, schemas, provenance, and vocabulary when behavior or
  terminology changes.
- Preserve existing user work and unrelated working-tree changes. Make scoped,
  reversible edits and verify them in proportion to risk.

## Explainability

- Prefer direct correspondence between the rendered source page, semantic
  model, evidence, decisions, and extracted output. Use synchronized selection
  and highlighting when it materially reduces mental reconstruction.
- Make the interface teach through labels, spatial arrangement, meaningful
  icons, progressive disclosure, contextual help, and visible provenance.
- Explain errors and uncertainty with what happened, where it happened, why it
  happened, what model or evidence contributed, and what the user can do next.
- Keep consequential warnings and errors reviewable; do not rely on short-lived
  success-style messages for information that requires action.
- Put explanations near the decision they explain, while providing a persistent
  attention path when limited panel space can move the originating control out
  of view.
- Documentation should deepen and formalize understanding, not compensate for
  an interface that cannot explain itself.

## Aesthetics

- Treat the UI, architecture, code, terminology, documentation, repository
  organization, developer experience, demos, and public presentation as parts
  of one designed system.
- Use hierarchy, spacing, contrast, weight, composition, and restraint to reveal
  the machinery more clearly. Beauty must make truth easier to see.
- Use color to communicate meaning, motion to communicate real state or process,
  and layout to reveal relationships. Decorative treatment must not imply false
  confidence or conceal complexity.
- Keep interactions coherent across light and dark themes, narrow and wide side
  panels, ordinary and maximized workspaces, keyboard and pointer input, and
  progressive/advanced views where applicable.
- Prefer polished, reusable visual primitives over accumulating one-off styling.
  Keep iconography, status language, controls, surfaces, and spacing consistent.
- Internal design counts: pleasant, comprehensible architecture and tooling are
  part of long-term stewardship, not separate from product quality.

## Decision Protocol

Before implementing a material change, identify:

1. **Truth:** What was observed, inferred, decided, or left unresolved? What
   alternatives, provenance, and limitations must remain visible?
2. **Maintainability:** Who owns this decision after the change? Can the system
   continue maintaining everything the user did not explicitly take over?
3. **Explainability:** How will a person understand the correspondence between
   source, model, decision, and output? How will failure guide the next action?
4. **Aesthetics:** Does the form, language, interaction, code, and documentation
   make the relationship clearer and the system more coherent to inhabit?

Prefer changes that improve several principles simultaneously. A smaller label,
state-model, or layout correction can be stronger than a new feature when it
makes the mechanism more truthful, understandable, maintainable, and coherent.

## Intervention Notifications

- When work cannot continue without user intervention, use the available
  desktop notification command to say what needs attention.
- Keep the notification concise and actionable, and also explain the blocker in
  the conversation so the durable record remains complete.
- Do not send notifications for ordinary progress, successful completion, or
  situations that can be resolved autonomously.

## Chrome Debugger Recovery

- The extension test browser exposes Chrome DevTools Protocol on port `9222`.
- If that Chrome instance or its debugger connection becomes stuck, run
  `/home/bline/.local/bin/restart-debug-chrome` before asking the user to
  intervene.
- After restart, enumerate the targets at
  `http://127.0.0.1:9222/json/list`, identify the inspected page and the
  Site2JSON extension service worker, and reopen the side panel with
  `chrome.sidePanel.open({ tabId })` from the extension context using a CDP
  evaluation with `userGesture: true`. Then reconnect to the resulting
  `chrome-extension://.../editor/sidebar.html?tabId=...` target.
- Chrome may still require one real toolbar click despite the synthetic user
  gesture. Only in that case, use the intervention notification command and ask
  the user to open the Site2JSON side panel once.

## Completion Standard

A material change is not complete until, as applicable:

- the implementation represents the real state and preserves provenance;
- ownership and automatic-maintenance behavior remain granular;
- the normal path, uncertainty, and failure path explain themselves;
- terminology matches the mechanism and is consistent across interfaces;
- UI changes are visually inspected in the real extension at relevant layouts
  and themes, not inferred solely from source code;
- focused tests and the proportionate broader test suite pass;
- generated assets and their freshness checks are current;
- accessibility labels and keyboard behavior remain meaningful;
- documentation and screenshots/tours that describe the changed behavior are
  updated or explicitly identified as follow-up work; and
- the resulting code and interface feel like coherent parts of Site2JSON rather
  than isolated additions.
