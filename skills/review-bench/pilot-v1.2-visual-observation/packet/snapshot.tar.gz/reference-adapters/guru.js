(function initializeGuruAdapter(root, factory) {
  "use strict";
  const utils = root.Site2JsonUtils || (typeof require === "function" ? require("../extension/core/utils") : null);
  const adapter = factory(utils);
  root.Site2JsonAdapters ||= {};
  root.Site2JsonAdapters.Guru = adapter;
  if (typeof module === "object" && module.exports) module.exports = adapter;
})(typeof globalThis === "object" ? globalThis : this, function guruAdapterFactory(utils) {
  "use strict";

  const SEARCH_MONITOR = [
    "description",
    "guru:postedText",
    "guru:budget",
    "guru:quoteCount",
    "skills",
    "guru:category",
    "guru:employer.location",
    "guru:employer.totalSpend"
  ];
  const DETAIL_MONITOR = [
    "guru:postedText",
    "guru:budget",
    "guru:quoteCount",
    "skills",
    "guru:category",
    "guru:employer.location",
    "guru:employer.totalSpend",
    "guru:employer.feedbackPercent",
    "guru:employer.jobsPosted",
    "guru:employer.jobsPaid"
  ];

  function decodeSearchRoute(rawValue) {
    if (!rawValue) return null;
    try {
      const normalized = rawValue.replace(/-/g, "+").replace(/_/g, "/");
      const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
      const route = atob(padded);
      return route.startsWith("/d/jobs/") ? route : null;
    } catch {
      return null;
    }
  }

  function parseSearchRoute(route) {
    if (!route?.startsWith("/d/jobs/")) return null;
    const segments = route.split("/").filter(Boolean);
    const metadata = {
      route,
      category: null,
      subcategory: null,
      skillTermsOrdered: [],
      primarySkillTerm: null,
      additionalSkillTerms: [],
      employerMinimumSpend: null,
      maxQuotes: null,
      page: 1,
      unknownSegments: []
    };
    const recognized = new Set(["d", "jobs"]);
    for (let index = 2; index < segments.length; index += 1) {
      const key = segments[index].toLowerCase();
      const value = segments[index + 1];
      if (["c", "sc", "skill", "minspend", "maxquotes", "pg"].includes(key) && value !== undefined) {
        recognized.add(key);
        const decoded = decodeURIComponent(value);
        if (key === "c") metadata.category = decoded;
        if (key === "sc") metadata.subcategory = decoded;
        if (key === "skill") metadata.skillTermsOrdered.push(decoded);
        if (key === "minspend") metadata.employerMinimumSpend = Number.parseFloat(decoded) || null;
        if (key === "maxquotes") metadata.maxQuotes = Number.parseInt(decoded, 10) || null;
        if (key === "pg") metadata.page = Number.parseInt(decoded, 10) || 1;
        index += 1;
      } else if (!recognized.has(key)) {
        metadata.unknownSegments.push(decodeURIComponent(segments[index]));
      }
    }
    metadata.primarySkillTerm = metadata.skillTermsOrdered[0] || null;
    metadata.additionalSkillTerms = metadata.skillTermsOrdered.slice(1);
    return metadata;
  }

  function collectionRoute(route) {
    const segments = route.split("/").filter(Boolean);
    const stable = [];
    for (let index = 0; index < segments.length; index += 1) {
      if (segments[index].toLowerCase() === "pg" && segments[index + 1] !== undefined) {
        index += 1;
        continue;
      }
      stable.push(segments[index]);
    }
    return `/${stable.join("/")}/`;
  }

  function searchMetadata(pageUrl) {
    const route = decodeSearchRoute(pageUrl.searchParams.get("q"));
    if (!route) return null;
    const parsed = parseSearchRoute(route);
    return { ...parsed, collectionRoute: collectionRoute(route) };
  }

  function isSearchPage(url) {
    return url.pathname === "/work/" && Boolean(searchMetadata(url));
  }

  function isDetailPage(url) {
    return /^\/work\/detail\/\d+\/?$/i.test(url.pathname);
  }

  function match(url) {
    return url.protocol === "https:" && url.hostname === "www.guru.com" && (isSearchPage(url) || isDetailPage(url));
  }

  function selectText(root, selectors) {
    if (!root) return null;
    for (const selector of selectors) {
      const value = utils.textOf(root.querySelector(selector));
      if (value) return value;
    }
    return null;
  }

  function parseMoney(raw) {
    if (!raw) return null;
    const multiplier = /m\b/i.test(raw) ? 1_000_000 : /k\b/i.test(raw) ? 1_000 : 1;
    const value = Number.parseFloat(raw.replace(/[^\d.]/g, ""));
    return Number.isFinite(value) ? value * multiplier : null;
  }

  function parseBudget(rawValue) {
    const raw = utils.normalizeText(rawValue);
    if (!raw) return null;
    if (/fixed price or hourly/i.test(raw)) {
      return { type: "fixed_or_hourly", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: raw };
    }
    const range = raw.match(/\$\s*([\d,.]+\s*[kKmM]?)\s*(?:-|–|—|to)\s*\$?\s*([\d,.]+\s*[kKmM]?)/i);
    const under = raw.match(/Under\s+\$\s*([\d,.]+\s*[kKmM]?)/i);
    const over = raw.match(/(?:Over|Above)\s+\$\s*([\d,.]+\s*[kKmM]?)/i);
    const type = /hourly/i.test(raw) ? "hourly" : /fixed/i.test(raw) ? "fixed" : "unknown";
    if (range) return { type, minimum: parseMoney(range[1]), maximum: parseMoney(range[2]), amount: null, currency: "USD", raw_text: raw };
    if (under) return { type, minimum: null, maximum: parseMoney(under[1]), amount: null, currency: "USD", raw_text: raw };
    if (over) return { type, minimum: parseMoney(over[1]), maximum: null, amount: null, currency: "USD", raw_text: raw };
    return { type, minimum: null, maximum: null, amount: null, currency: "USD", raw_text: raw };
  }

  function parseInteger(raw) {
    const match = String(raw || "").match(/[\d,]+/);
    return match ? Number.parseInt(match[0].replace(/,/g, ""), 10) : null;
  }

  function parsePercent(raw) {
    const match = String(raw || "").match(/([\d.]+)\s*%/);
    return match ? Number.parseFloat(match[1]) : null;
  }

  function postedText(root) {
    const meta = selectText(root, [".jobRecord__meta", ".jobHeading__meta"]);
    const match = meta?.match(/Posted\s+(.+?)(?=\s*(?:·|\||Job ID:))/i);
    return match ? utils.normalizeText(match[1]) : null;
  }

  function quoteCount(root) {
    const meta = selectText(root, [".jobRecord__meta", ".jobHeading__meta"]);
    const match = meta?.match(/(\d+)\s+quotes?/i);
    return match ? Number.parseInt(match[1], 10) : null;
  }

  function searchSkills(card) {
    return [...card.querySelectorAll("a.skillsList__skill--hasHover")].map(utils.textOf).filter(Boolean);
  }

  function searchTaxonomy(card) {
    const category = selectText(card, ['.skillsList a[href*="/c/"] strong', '.skillsList a[href*="/c/"]']);
    const subcategory = selectText(card, ['.skillsList a[href*="/sc/"]']);
    return { category, subcategory };
  }

  function searchEmployer(card) {
    const root = card.querySelector(".module_avatar.freelancerAvatar");
    return {
      name: selectText(root, [".identityName strong"]),
      location: selectText(root, [".freelancerAvatar__subText strong"]),
      totalSpend: parseMoney(selectText(root, [".earnings__amount"])),
      feedbackPercent: parsePercent(selectText(root, [".feedback-score"]))
    };
  }

  function canonicalJobUrl(rawUrl, baseUrl) {
    try {
      const url = new URL(rawUrl, baseUrl);
      const match = url.pathname.match(/^\/work\/detail\/(\d+)\/?$/i);
      return match && url.hostname === "www.guru.com" ? `https://www.guru.com/work/detail/${match[1]}` : null;
    } catch {
      return null;
    }
  }

  function extractSearchEntity(card, pageUrl) {
    const id = card.getAttribute("data-id");
    const link = card.querySelector('.jobRecord__title a[href*="/work/detail/"]');
    const url = link && canonicalJobUrl(link.href, pageUrl);
    const title = utils.textOf(link);
    const description = selectText(card, [".jobRecord__desc"]);
    if (!id || !url || !title) return null;
    const taxonomy = searchTaxonomy(card);
    return {
      "@type": "JobPosting",
      "@id": url,
      identifier: id,
      url,
      title,
      description,
      skills: searchSkills(card),
      "guru:postedText": postedText(card),
      "guru:budget": parseBudget(selectText(card, [".jobRecord__budget"])),
      "guru:quoteCount": quoteCount(card),
      "guru:category": taxonomy.category,
      "guru:subcategory": taxonomy.subcategory,
      "guru:locationRequirement": selectText(card, [".jobLocations"]),
      "guru:employer": searchEmployer(card),
      "site2json:rawText": utils.textOf(card)
    };
  }

  function extractSearch(document, pageUrl) {
    const search = searchMetadata(pageUrl);
    const cards = [...document.querySelectorAll("li[data-id]")].filter((item) => item.querySelector(".jobRecord"));
    const extracted = cards.map((card) => extractSearchEntity(card, pageUrl)).filter(Boolean);
    const entities = [...new Map(extracted.map((entity) => [entity.identifier, entity])).values()];
    const warnings = [];
    if (cards.length > extracted.length) warnings.push({ code: "card.unrecognized", count: cards.length - extracted.length });
    if (extracted.length > entities.length) warnings.push({ code: "entity.duplicate", count: extracted.length - entities.length });
    return {
      pageType: "SearchResultsPage",
      pageTitle: document.title,
      language: document.documentElement.lang || null,
      collectionKey: `guru:jobs:${search.collectionRoute}`,
      snapshotKey: `guru:jobs:${search.collectionRoute}:page:${search.page}`,
      logicalPosition: search.page,
      page: { search },
      warnings,
      blocks: [{
        id: "search-results",
        entity: "JobPosting",
        arity: "many",
        role: "collection",
        fidelity: "summary",
        require: ["title", "url"],
        monitor: SEARCH_MONITOR,
        entities
      }]
    };
  }

  function statValue(root, label) {
    if (!root) return null;
    for (const row of root.querySelectorAll("tr")) {
      const cells = row.querySelectorAll("td");
      if (cells.length >= 2 && utils.textOf(cells[0]).toLowerCase() === label.toLowerCase()) return utils.textOf(cells[1]);
    }
    return null;
  }

  function detailEmployer(root) {
    const employer = root.querySelector(".jobDetails__employer");
    return {
      name: selectText(employer, [".avatarinfo p strong", ".identityName strong"]),
      location: selectText(employer, [".employer-location strong", ".avatarinfo span strong"]),
      totalSpend: parseMoney(statValue(employer, "Total Spend")),
      feedbackPercent: parsePercent(statValue(employer, "Feedback")),
      jobsPosted: parseInteger(statValue(employer, "Jobs Posted")),
      jobsPaid: parseInteger(statValue(employer, "Jobs Paid"))
    };
  }

  function detailTaxonomy(root) {
    const categoryRoot = root.querySelector(".jobDetails__category");
    if (!categoryRoot) return { category: null, subcategory: null, skills: [] };
    const text = selectText(categoryRoot, ["p"]);
    const parts = text?.split(/\s*>\s*/).map(utils.normalizeText) || [];
    return {
      category: selectText(categoryRoot, ["p strong"]) || parts[0] || null,
      subcategory: parts[1] || null,
      skills: [...categoryRoot.querySelectorAll("ul.skillsList .skillsList__skill")].map(utils.textOf).filter(Boolean)
    };
  }

  function extractDetail(document, pageUrl) {
    const root = document.querySelector(".jobDetails.view");
    if (!root) throw new Error("The Guru job detail region could not be located.");
    const id = pageUrl.pathname.match(/\/work\/detail\/(\d+)/i)?.[1] || null;
    const url = id ? `https://www.guru.com/work/detail/${id}` : null;
    const taxonomy = detailTaxonomy(root);
    const primaryText = [".jobHeading", ".jobDetails__summary", ".jobDetails__employer"].map((selector) => selectText(root, [selector])).filter(Boolean).join(" ");
    const entity = {
      "@type": "JobPosting",
      "@id": url,
      identifier: id,
      url,
      title: selectText(root, [".jobHeading__title"]),
      description: selectText(root, [".jobDetails__summary .jobDetails__description"]),
      skills: taxonomy.skills,
      "guru:postedText": postedText(root),
      "guru:budget": parseBudget(selectText(root, [".jobHeading__budget"])),
      "guru:quoteCount": quoteCount(root),
      "guru:category": taxonomy.category,
      "guru:subcategory": taxonomy.subcategory,
      "guru:locationRequirement": null,
      "guru:employer": detailEmployer(root),
      "site2json:rawText": primaryText
    };
    return {
      pageType: "ItemPage",
      pageTitle: document.title,
      language: document.documentElement.lang || null,
      collectionKey: null,
      snapshotKey: `guru:job:${id || pageUrl.href}`,
      logicalPosition: null,
      blocks: [{
        id: "job-detail",
        entity: "JobPosting",
        arity: "one",
        role: "primary",
        fidelity: "full",
        require: ["title", "url", "description"],
        monitor: DETAIL_MONITOR,
        entities: [entity]
      }]
    };
  }

  function extract(document, pageUrl) {
    return isDetailPage(pageUrl) ? extractDetail(document, pageUrl) : extractSearch(document, pageUrl);
  }

  return {
    id: "guru",
    version: 1,
    source: "bundled",
    context: { guru: "https://site2json.dev/ns/guru#" },
    match,
    extract,
    decodeSearchRoute,
    parseSearchRoute,
    parseBudget,
    searchMetadata
  };
});
