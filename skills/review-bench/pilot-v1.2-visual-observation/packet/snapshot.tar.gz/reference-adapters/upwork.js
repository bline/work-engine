(function initializeUpworkAdapter(root, factory) {
  "use strict";
  const utils = root.Site2JsonUtils || (typeof require === "function" ? require("../extension/core/utils") : null);
  const adapter = factory(utils);
  root.Site2JsonAdapters ||= {};
  root.Site2JsonAdapters.Upwork = adapter;
  if (typeof module === "object" && module.exports) module.exports = adapter;
})(typeof globalThis === "object" ? globalThis : this, function upworkAdapterFactory(utils) {
  "use strict";

  const JOB_LINK_PATH = /^\/(?:nx\/)?jobs\/(?:~[^/?#]+|[^/?#]+_[^/?#]+)\/?$/i;
  const SEARCH_MONITORED_FIELDS = [
    "description",
    "upwork:postedText",
    "upwork:budget",
    "upwork:experienceLevel",
    "skills",
    "upwork:client.payment_verified",
    "upwork:client.rating",
    "upwork:client.total_spend_text",
    "upwork:client.location",
    "upwork:activity.proposal_count_text"
  ];
  const DETAIL_MONITORED_FIELDS = [
    "upwork:postedText",
    "upwork:budget",
    "upwork:experienceLevel",
    "upwork:duration",
    "upwork:weeklyHours",
    "skills",
    "upwork:client.payment_verified",
    "upwork:client.rating",
    "upwork:client.total_spend_text",
    "upwork:client.location",
    "upwork:activity.proposal_count_text",
    "upwork:activity.interviewing",
    "upwork:activity.invites_sent",
    "upwork:connectCost"
  ];

  function isSearchPage(url) {
    return /\/search\/jobs\/?$/i.test(url.pathname) || /\/jobs\/search\/?$/i.test(url.pathname);
  }

  function isDetailPage(url) {
    return JOB_LINK_PATH.test(url.pathname);
  }

  function isPanelRoute(url) {
    return /^\/nx\/search\/jobs\/details\/(?:~[^/?#]+|[^/?#]+_[^/?#]+)\/?$/i.test(url.pathname);
  }

  function panelRoot(document) {
    return document.querySelector([
      '.air3-slider-job-details-slider[role="dialog"][aria-modal="true"]',
      '[data-test="air3-slider transition UpTransition"][role="dialog"]',
      '[data-test="UpCSliderBody"][slidername="job-details-slider"]',
      '[data-test-route*="modal-job-details"]'
    ].join(","));
  }

  function match(url) {
    return url.protocol === "https:" && url.hostname === "www.upwork.com" && (isSearchPage(url) || isDetailPage(url) || isPanelRoute(url));
  }

  function canonicalJobUrl(value, pageUrl) {
    try {
      const url = new URL(typeof value === "string" ? value : value.href, pageUrl);
      if (url.hostname !== "www.upwork.com" || !JOB_LINK_PATH.test(url.pathname)) return null;
      return `${url.origin}${url.pathname.replace(/\/$/, "")}`;
    } catch {
      return null;
    }
  }

  function searchTerm(document, pageUrl) {
    for (const parameter of ["q", "query", "search"]) {
      const value = utils.normalizeText(pageUrl.searchParams.get(parameter));
      if (value) return value;
    }
    for (const selector of [
      'input[data-test="search-input"]',
      'input[data-test*="search" i]',
      'input[name="q"]',
      'input[type="search"]'
    ]) {
      const value = utils.normalizeText(document.querySelector(selector)?.value);
      if (value) return value;
    }
    return null;
  }

  function searchParameters(pageUrl) {
    const parameters = {};
    const entries = [...pageUrl.searchParams.entries()].sort(([keyA, valueA], [keyB, valueB]) => (
      keyA.localeCompare(keyB) || valueA.localeCompare(valueB)
    ));
    for (const [key, value] of entries) {
      parameters[key] ||= [];
      parameters[key].push(value);
    }
    return parameters;
  }

  function searchDefinition(pageUrl) {
    const transient = new Set(["from_recent_search", "page", "per_page"]);
    const entries = [...pageUrl.searchParams.entries()]
      .filter(([key]) => !transient.has(key))
      .sort(([keyA, valueA], [keyB, valueB]) => keyA.localeCompare(keyB) || valueA.localeCompare(valueB));
    return new URLSearchParams(entries).toString();
  }

  function logicalPosition(pageUrl) {
    const page = Number.parseInt(pageUrl.searchParams.get("page") || "1", 10);
    return Number.isSafeInteger(page) && page > 0 ? page : 1;
  }

  function jobLinkIn(root, pageUrl) {
    return [...root.querySelectorAll("a[href]")].find((anchor) => canonicalJobUrl(anchor, pageUrl));
  }

  function candidateCards(document, pageUrl) {
    const selectors = [
      '[data-test="job-tile"]',
      '[data-test="JobTile"]',
      'article[data-test*="job" i]',
      "article.job-tile",
      '[data-ev-label="search_results_impression"]'
    ];
    const selected = [...document.querySelectorAll(selectors.join(","))];
    const fallback = [...document.querySelectorAll("a[href]")]
      .filter((anchor) => canonicalJobUrl(anchor, pageUrl))
      .map((anchor) => anchor.closest('article, section, li, [data-test="job-tile"], [data-test="JobTile"]'))
      .filter(Boolean);
    return [...new Set([...selected, ...fallback])].filter((card) => {
      if (!jobLinkIn(card, pageUrl)) return false;
      const links = [...card.querySelectorAll("a[href]")].filter((anchor) => canonicalJobUrl(anchor, pageUrl));
      return links.length <= 3;
    });
  }

  function selectText(root, selectors) {
    for (const selector of selectors) {
      const value = utils.textOf(root.querySelector(selector));
      if (value) return value;
    }
    return null;
  }

  function parseMoney(raw) {
    if (!raw) return null;
    const multiplier = /m\b/i.test(raw) ? 1_000_000 : /k\b/i.test(raw) ? 1_000 : 1;
    const value = Number.parseFloat(raw.replace(/[^\d.]/g, ""));
    return Number.isFinite(value) ? value * multiplier : null;
  }

  function parseBudget(rawText) {
    const hourly = rawText.match(/(?:Hourly\s*:?\s*)?\$\s*([\d,.]+)\s*(?:-|–|—|to)\s*\$?\s*([\d,.]+)(?:\s*\/\s*(?:hr|hour))?/i);
    if (hourly) {
      return { type: "hourly", minimum: parseMoney(hourly[1]), maximum: parseMoney(hourly[2]), amount: null, currency: "USD", raw_text: utils.normalizeText(hourly[0]) };
    }
    const hourlySingle = rawText.match(/(?:Hourly\s*:?\s*)\$\s*([\d,.]+)(?:\s*\/\s*(?:hr|hour))?/i);
    if (hourlySingle) {
      const amount = parseMoney(hourlySingle[1]);
      return { type: "hourly", minimum: amount, maximum: amount, amount: null, currency: "USD", raw_text: utils.normalizeText(hourlySingle[0]) };
    }
    const fixed = rawText.match(/(?:fixed[ -]price|est(?:imated)?\.?\s*budget|budget)\s*:?\s*\$\s*([\d,.]+\s*[kKmM]?)/i);
    if (fixed) return { type: "fixed", minimum: null, maximum: null, amount: parseMoney(fixed[1]), currency: "USD", raw_text: utils.normalizeText(fixed[0]) };
    if (/\bHourly\b/i.test(rawText)) return { type: "hourly", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: "Hourly" };
    return null;
  }

  function parseJobId(url) {
    try { return new URL(url).pathname.match(/~(\d+)/)?.[1] || null; } catch { return null; }
  }

  function firstMatch(rawText, patterns) {
    for (const pattern of patterns) {
      const matchResult = rawText.match(pattern);
      if (matchResult) return utils.normalizeText(matchResult[1] || matchResult[0]);
    }
    return null;
  }

  function labeledValue(root, label) {
    const normalizedLabel = label.toLowerCase();
    for (const element of root.querySelectorAll("span, strong, dt")) {
      if (utils.textOf(element).replace(/:\s*$/, "").toLowerCase() !== normalizedLabel) continue;
      const container = element.closest("li, div, section");
      const selected = container && selectText(container, [".value", '[data-test="value"]']);
      if (selected && selected !== utils.textOf(element)) return selected;
      let sibling = element.nextElementSibling;
      while (sibling) {
        const value = utils.textOf(sibling);
        if (value && !/more info/i.test(value)) return value;
        sibling = sibling.nextElementSibling;
      }
    }
    return null;
  }

  function parseRating(rawText) {
    const result = rawText.match(/(?:rating\s*)?([0-5](?:\.\d+)?)\s*(?:out of 5|of 5|stars?)/i);
    const value = result ? Number.parseFloat(result[1]) : null;
    return Number.isFinite(value) ? value : null;
  }

  function extractSkills(card) {
    const interfaceText = new Set(["doesn't match skills", "matches skills", "more", "show more"]);
    const skills = [...card.querySelectorAll('[data-test="token"], [data-test="attr-item"], [data-test="skill"], [data-test="Skill"], [data-test="skill-name"], .air3-token')]
      .map(utils.textOf)
      .filter((skill) => skill && skill.length <= 80 && !interfaceText.has(skill.toLowerCase()) && !/^\+\s*\d+$/.test(skill));
    return [...new Set(skills)];
  }

  function parseExperienceLevel(card, rawText) {
    const levels = new Map([["entry level", "Entry Level"], ["intermediate", "Intermediate"], ["expert", "Expert"]]);
    const selected = selectText(card, ['[data-test="experience-level"]', '[data-test="contractor-tier"]', '[data-test="job-type-label"]']);
    if (levels.has(selected?.toLowerCase())) return levels.get(selected.toLowerCase());
    const labeled = rawText.match(/Experience\s+Level\s*:?\s*(Entry Level|Intermediate|Expert)/i);
    if (labeled) return levels.get(labeled[1].toLowerCase());
    const reverseLabeled = rawText.match(/(Entry Level|Intermediate|Expert).{0,120}?Experience Level/i);
    if (reverseLabeled) return levels.get(reverseLabeled[1].toLowerCase());
    for (const element of card.querySelectorAll("span, small, strong, li")) {
      if (element.children.length === 0 && levels.has(utils.textOf(element).toLowerCase())) return levels.get(utils.textOf(element).toLowerCase());
    }
    return null;
  }

  function parseLocation(card, rawText) {
    const noise = /not in my preferred location|doesn't match skills|matches skills|job feedback|save job|show more/i;
    const clean = (value) => {
      const location = utils.normalizeText(value).replace(/^Location\s*:?\s*/i, "");
      return !location || location.length > 80 || noise.test(location) ? null : location;
    };
    const selected = clean(selectText(card, [
      '[data-test="client-country"]',
      '[data-test="client-location"]',
      '[data-test="client-location-text"]',
      '[data-qa="client-location"] strong'
    ]));
    if (selected) return selected;
    for (const element of card.querySelectorAll("span, small, strong, dt, div")) {
      if (utils.textOf(element).toLowerCase() !== "location") continue;
      let sibling = element.nextElementSibling;
      while (sibling) {
        const value = clean(utils.textOf(sibling));
        if (value) return value;
        sibling = sibling.nextElementSibling;
      }
    }
    const result = rawText.match(/\bLocation\s*:?\s*([A-Za-z][A-Za-z .,'()\-]{1,60}?)(?=\s+(?:Job Success|Payment|Proposals?|Jobs? posted|Member since|Hourly|Fixed|\$)|$)/i);
    return clean(result?.[1]);
  }

  function extractDescription(card, title) {
    const selected = selectText(card, [
      '[data-test="UpCLineClamp JobDescription"]', '[data-test="JobDescription"]',
      '[data-test="job-description-text"]', '[data-test*="job-description" i]',
      '[data-test*="description-text" i]', '[data-test^="Description"] p', ".job-description"
    ]);
    if (selected && selected !== title) return selected;
    return [...card.querySelectorAll("p")].map(utils.textOf)
      .filter((text) => text && text !== title && text.length >= 40)
      .sort((a, b) => b.length - a.length)[0] || null;
  }

  function extractJob(card, pageUrl, explicitUrl = null) {
    const link = jobLinkIn(card, pageUrl);
    const url = explicitUrl || (link && canonicalJobUrl(link, pageUrl));
    const title = selectText(card, [
      '[data-test="job-title"]',
      '[data-test="job-posting-title"]',
      '[data-test*="job-tile-title" i]',
      '[data-test*="job-title" i]',
      "h1",
      '[data-test="JobDetailsLoader"] h4',
      "h4",
      "h2",
      "h3"
    ]) || utils.textOf(link);
    const rawText = utils.textOf(card);
    if (!url || !title || !rawText) return null;
    const description = extractDescription(card, title);
    const postedText = selectText(card, ['[data-test*="pubilshed-date" i]', '[data-test*="published-date" i]', '[data-test*="posted" i]']) || firstMatch(rawText, [/(Posted\s+(?:today|yesterday|\d+\s+\w+\s+ago))/i]);
    const proposalCount = labeledValue(card, "Proposals") || firstMatch(rawText, [/Proposals?\s*:?\s*(Less than \d+|\d+\s*(?:to|-)\s*\d+|\d+\+)/i]);
    const interviewing = labeledValue(card, "Interviewing") || firstMatch(rawText, [/Interviewing\s*:?\s*(\d+)/i]);
    const invitesSent = labeledValue(card, "Invites sent") || firstMatch(rawText, [/Invites sent\s*:?\s*(\d+)/i]);
    const connects = firstMatch(rawText, [
      /Required Connects(?: to submit a proposal)?\s*:?\s*(\d+)/i,
      /Connects required\s*:?\s*(\d+)/i,
      /Connects\s*:\s*(\d+)/i
    ]);
    const totalSpend = firstMatch(rawText, [/(\$[\d,.]+\s*[kKmM]?\+?\s+(?:total\s+)?spent)/i]);
    const budgetText = selectText(card, ['[data-test="is-fixed-price"]', '[data-test="job-type-label"]']);
    const budget = (budgetText && parseBudget(budgetText)) || parseBudget(rawText) || ([...card.querySelectorAll(".description")].some((element) => utils.textOf(element).toLowerCase() === "hourly")
      ? { type: "hourly", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: "Hourly" }
      : null);
    return {
      "@type": "JobPosting",
      "@id": url,
      identifier: parseJobId(url),
      url,
      title,
      description,
      skills: extractSkills(card),
      "upwork:postedText": postedText,
      "upwork:budget": budget,
      "upwork:experienceLevel": parseExperienceLevel(card, rawText),
      "upwork:duration": firstMatch(rawText, [/(Less than 1 month|1 to 3 months|3 to 6 months|More than 6 months)/i]),
      "upwork:weeklyHours": firstMatch(rawText, [/(Less than 30 hrs?\/week|More than 30 hrs?\/week|\d+\+? hrs?\/week)/i]),
      "upwork:client": {
        payment_verified: /payment(?: method)? verified/i.test(rawText) ? true : /payment(?: method)? (?:not verified|unverified)/i.test(rawText) ? false : null,
        rating: parseRating(rawText),
        total_spend_text: totalSpend,
        location: parseLocation(card, rawText)
      },
      "upwork:activity": {
        proposal_count_text: proposalCount,
        interviewing: interviewing === null ? null : Number.parseInt(interviewing, 10),
        invites_sent: invitesSent === null ? null : Number.parseInt(invitesSent, 10)
      },
      "upwork:connectCost": connects === null ? null : Number.parseInt(connects, 10),
      "site2json:rawText": rawText
    };
  }

  function deduplicate(entities) {
    const seen = new Set();
    return entities.filter((entity) => {
      const key = entity.identifier || entity.url;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function extractSearch(document, pageUrl) {
    const cards = candidateCards(document, pageUrl);
    const extracted = cards.map((card) => extractJob(card, pageUrl)).filter(Boolean);
    const entities = deduplicate(extracted);
    const definition = searchDefinition(pageUrl);
    const term = searchTerm(document, pageUrl);
    const warnings = [];
    if (cards.length > extracted.length) warnings.push({ code: "card.unrecognized", count: cards.length - extracted.length });
    if (extracted.length > entities.length) warnings.push({ code: "entity.duplicate", count: extracted.length - entities.length });
    return {
      pageType: "SearchResultsPage",
      pageTitle: document.title,
      language: document.documentElement.lang || null,
      collectionKey: `upwork:jobs:${definition}`,
      snapshotKey: `upwork:jobs:${definition}:page:${logicalPosition(pageUrl)}`,
      logicalPosition: logicalPosition(pageUrl),
      page: { searchTerm: term, searchParameters: searchParameters(pageUrl), searchDefinition: definition },
      warnings,
      blocks: [{
        id: "search-results",
        entity: "JobPosting",
        arity: "many",
        role: "collection",
        fidelity: "summary",
        require: ["title", "url"],
        monitor: SEARCH_MONITORED_FIELDS,
        entities
      }]
    };
  }

  function extractDetail(document, pageUrl) {
    const root = document.querySelector([
      '[data-test="job-details"]',
      '[data-test="job-view"]',
      ".job-details-content",
      '[data-test="JobDetailsLoader"]'
    ].join(","));
    if (!root) throw new Error("The Upwork job detail region could not be located.");
    const url = canonicalJobUrl(pageUrl.href, pageUrl);
    const entity = url && extractJob(root, pageUrl, url);
    return {
      pageType: "ItemPage",
      pageTitle: document.title,
      language: document.documentElement.lang || null,
      collectionKey: null,
      snapshotKey: `upwork:job:${url || pageUrl.href}`,
      logicalPosition: null,
      blocks: [{
        id: "job-detail",
        entity: "JobPosting",
        arity: "one",
        role: "primary",
        fidelity: "full",
        require: ["title", "url", "description"],
        monitor: DETAIL_MONITORED_FIELDS,
        entities: entity ? [entity] : []
      }]
    };
  }

  function extractPanel(document, pageUrl, root) {
    const canonicalLink = root.querySelector('a[data-test*="slider-open-in-new-window"][href*="/jobs/"]');
    const url = canonicalLink && canonicalJobUrl(canonicalLink, pageUrl);
    const entity = url && extractJob(root, pageUrl, url);
    return {
      pageType: "ItemPage",
      pageTitle: entity?.title || document.title,
      language: document.documentElement.lang || null,
      collectionKey: null,
      snapshotKey: `upwork:job:${url || pageUrl.href}`,
      logicalPosition: null,
      page: { presentation: "overlay", sourcePageUrl: pageUrl.href },
      blocks: [{
        id: "job-detail-panel",
        entity: "JobPosting",
        arity: "one",
        role: "primary",
        fidelity: "full",
        require: ["title", "url", "description"],
        monitor: DETAIL_MONITORED_FIELDS,
        entities: entity ? [entity] : []
      }]
    };
  }

  function extract(document, pageUrl) {
    const panel = panelRoot(document);
    if (panel) return extractPanel(document, pageUrl, panel);
    return isDetailPage(pageUrl) ? extractDetail(document, pageUrl) : extractSearch(document, pageUrl);
  }

  return {
    id: "upwork",
    version: 1,
    source: "bundled",
    context: { upwork: "https://site2json.dev/ns/upwork#" },
    match,
    extract,
    parseBudget
  };
});
