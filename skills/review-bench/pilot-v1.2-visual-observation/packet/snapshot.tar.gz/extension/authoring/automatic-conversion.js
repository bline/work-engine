(function initializeAutomaticConversion(root, factory) {
  "use strict";
  const dsl = root.Site2JsonDsl || (typeof require === "function" ? require("../core/dsl") : null);
  const api = factory(dsl);
  root.Site2JsonAutomaticConversion = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function automaticConversionFactory(dsl) {
  "use strict";

  const CONFIDENCE = Object.freeze({ weak: 0, moderate: 1, strong: 2 });
  const OUTCOMES = Object.freeze({
    USE_EXISTING: "use-existing",
    DISABLED_EXISTING: "disabled-existing",
    PRESERVE_MANUAL_DRAFT: "preserve-manual-draft",
    RESUME_AUTOMATIC_DRAFT: "resume-automatic-draft",
    AUTHOR: "author",
    PUBLISH_AND_DOWNLOAD: "publish-and-download",
    DRAFT_AND_DOWNLOAD: "draft-and-download",
    DRAFT_AND_REVIEW: "draft-and-review"
  });

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function matches(definition, pageUrl) {
    if (!definition || !pageUrl) return false;
    try {
      const url = pageUrl instanceof URL ? pageUrl : new URL(pageUrl);
      return dsl.compile(definition).match(url, null);
    } catch {
      return false;
    }
  }

  function automaticAuthoring(editorState) {
    return editorState?.authoring?.origin === "automatic";
  }

  function samePage(left, right) {
    try {
      const leftUrl = left instanceof URL ? left : new URL(left);
      const rightUrl = right instanceof URL ? right : new URL(right);
      const path = (url) => url.pathname.length > 1 ? url.pathname.replace(/\/$/, "") : url.pathname;
      return leftUrl.protocol === rightUrl.protocol && leftUrl.hostname === rightUrl.hostname && path(leftUrl) === path(rightUrl);
    } catch {
      return false;
    }
  }

  function meaningfulDraft(draft) {
    return Boolean(
      draft?.workingDefinition
      || draft?.adapterId
      || draft?.editorState?.authoring
      || (Array.isArray(draft?.editorState?.blocks) && draft.editorState.blocks.length)
    );
  }

  function draftMatches(draft, pageUrl) {
    return meaningfulDraft(draft)
      && (matches(draft?.workingDefinition, pageUrl) || samePage(draft?.editorState?.pageUrl, pageUrl));
  }

  function resolveExisting({ entries = [], drafts = [], definitions = [] } = {}, pageUrl) {
    const published = [
      ...entries.map((entry) => ({
        id: entry.id || entry.definition?.adapter,
        enabled: entry.enabled !== false,
        definition: entry.definition,
        entry
      })),
      ...definitions.map((definition) => ({ id: definition?.adapter, enabled: true, definition, entry: null }))
    ].filter((candidate) => matches(candidate.definition, pageUrl));

    const enabled = published.find((candidate) => candidate.enabled);
    if (enabled) return { outcome: OUTCOMES.USE_EXISTING, id: enabled.id, entry: enabled.entry, definition: enabled.definition };

    const disabled = published.find((candidate) => !candidate.enabled);
    if (disabled) return { outcome: OUTCOMES.DISABLED_EXISTING, id: disabled.id, entry: disabled.entry, definition: disabled.definition };

    const draft = drafts.find((candidate) => draftMatches(candidate, pageUrl));
    if (draft && automaticAuthoring(draft.editorState)) {
      return { outcome: OUTCOMES.RESUME_AUTOMATIC_DRAFT, id: draft.adapterId || draft.workingDefinition?.adapter || null, draft };
    }
    if (draft) return { outcome: OUTCOMES.PRESERVE_MANUAL_DRAFT, id: draft.adapterId || draft.workingDefinition?.adapter || null, draft };
    return { outcome: OUTCOMES.AUTHOR };
  }

  function automaticMetadata({
    generatorVersion,
    generatedAt = new Date().toISOString(),
    reviewStatus = "unreviewed",
    confidence = null
  } = {}) {
    if (typeof generatorVersion !== "string" || !generatorVersion.trim()) throw new Error("Automatic authoring requires a generator version.");
    if (reviewStatus !== "unreviewed" && reviewStatus !== "reviewed") throw new Error("Unknown automatic adapter review status.");
    return {
      origin: "automatic",
      generatorVersion: generatorVersion.trim(),
      generatedAt,
      reviewStatus,
      ...(confidence ? { confidence: clone(confidence) } : {})
    };
  }

  function tagDraft(draft, metadata) {
    if (!draft?.id) throw new Error("A draft is required for automatic authoring metadata.");
    if (metadata?.origin !== "automatic") throw new Error("Automatic authoring metadata is required.");
    return {
      ...draft,
      editorState: {
        ...(clone(draft.editorState) || {}),
        authoring: clone(metadata)
      }
    };
  }

  function blockShape(kind) {
    if (kind === "collection") return Object.freeze({ arity: "many", role: "collection", fidelity: "summary" });
    if (kind === "primary") return Object.freeze({ arity: "one", role: "primary", fidelity: "full" });
    throw new Error(`Unknown automatic page shape: ${kind}`);
  }

  function level(signal, name) {
    const value = typeof signal === "string" ? signal : signal?.confidence;
    if (!Object.hasOwn(CONFIDENCE, value)) throw new Error(`${name} confidence must be weak, moderate, or strong.`);
    return CONFIDENCE[value];
  }

  function decideOutcome(signals = {}, { minimumConfidence = "moderate" } = {}) {
    if (minimumConfidence !== "moderate" && minimumConfidence !== "strong") {
      throw new Error("Automatic run confidence must be moderate or strong.");
    }
    const evaluated = [
      ["scope", level(signals.scope, "Scope")],
      ["scope margin", level(signals.scopeMargin, "Scope margin")],
      ["semantics", level(signals.semantics, "Semantic model")],
      ...(signals.variants ? [["variant classification", level(signals.variants, "Variant classification")]] : []),
      ["fields", level(signals.fields, "Field mapping")],
      ["extraction", level(signals.extraction, "Extraction")]
    ];
    const minimum = CONFIDENCE[minimumConfidence];
    const belowThreshold = evaluated.filter(([, value]) => value < minimum).map(([name]) => name);
    if (belowThreshold.length) {
      return {
        outcome: OUTCOMES.DRAFT_AND_REVIEW,
        publish: false,
        download: false,
        minimumConfidence,
        reasons: belowThreshold.map((name) => `${name} confidence is below the ${minimumConfidence} run threshold`)
      };
    }
    const notStrong = evaluated.filter(([, value]) => value < CONFIDENCE.strong).map(([name]) => name);
    if (notStrong.length) {
      return {
        outcome: OUTCOMES.DRAFT_AND_DOWNLOAD,
        publish: false,
        download: true,
        minimumConfidence,
        reasons: notStrong.map((name) => `${name} confidence is not strong enough for publication`)
      };
    }
    return { outcome: OUTCOMES.PUBLISH_AND_DOWNLOAD, publish: true, download: true, minimumConfidence, reasons: [] };
  }

  return Object.freeze({
    CONFIDENCE,
    OUTCOMES,
    automaticMetadata,
    blockShape,
    decideOutcome,
    matches,
    meaningfulDraft,
    resolveExisting,
    tagDraft
  });
});
