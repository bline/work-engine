(function initializeFieldMappingEvidence(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonFieldMappingEvidence = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function fieldMappingEvidenceFactory() {
  "use strict";

  const VERSION = 1;
  const SYNTHETIC_NAMES = new Set(["date", "field", "image", "url"]);
  const FORBIDDEN_DIRECT_URL = /\b(?:apply|avatar|category|client|company|employer|profile|skill|tag|navigation|menu)\b/;
  const SAME_AS_CONTEXT = /\b(?:sameas|same as|social|profile)\b/;
  const MONTH_DATE = /\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:\s*,)?\s+\d{4}\b/i;
  const ISO_DATE = /^\d{4}-\d{2}-\d{2}(?:[T\s].*)?$/;
  const TERM_ALIASES = Object.freeze({
    title: ["title", "heading"], headline: ["headline", "title", "heading"], name: ["name"],
    description: ["description", "desc", "summary", "body"], articleBody: ["article body", "body", "content"],
    datePosted: ["date posted", "posted", "date"], datePublished: ["date published", "published", "date"],
    validThrough: ["valid through", "deadline", "expires"], skills: ["skills", "skill", "tag"],
    baseSalary: ["base salary", "salary", "compensation", "wage"], price: ["price", "cost", "amount"],
    priceCurrency: ["price currency", "currency"], hiringOrganization: ["hiring organization", "employer", "company", "client", "organization"],
    jobLocation: ["job location", "location", "country", "city"], url: ["url", "canonical", "permalink", "link"],
    identifier: ["identifier", "uuid", "guid", "sku", "code"], image: ["image", "photo", "avatar"],
    sameAs: ["sameas", "same as", "social", "profile"]
  });

  function localName(value) {
    return String(value || "").split(/[#:/.]/).filter(Boolean).at(-1) || "field";
  }

  function normalized(value) {
    return String(value || "").replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  }

  function tokens(value) {
    return new Set(normalized(value).split(" ").filter(Boolean));
  }

  function stableEvidence(candidate) {
    const evidence = candidate?.evidence || {};
    const suggested = normalized(candidate?.suggestedName);
    return normalized([
      candidate?.selector, evidence.id, ...(evidence.classes || []), evidence.context,
      suggested && !SYNTHETIC_NAMES.has(suggested) ? suggested : ""
    ].join(" "));
  }

  function aliasesForName(name) {
    const local = localName(name);
    return TERM_ALIASES[local] || [normalized(local)];
  }

  function aliases(term) {
    const leaf = term.leafName || localName(term.name);
    const authored = term.authoringProfile || term.vocabularyTerm?.authoringProfile || {};
    return [...new Set([
      normalized(leaf), ...(TERM_ALIASES[leaf] || []), ...(term.aliases || []),
      ...(term.evidenceAliases || []), ...(term.vocabularyTerm?.evidenceAliases || []), ...(authored.aliases || [])
    ].map(normalized).filter(Boolean))];
  }

  function phrasePresent(haystack, phrase, haystackTokens = null) {
    if (!phrase) return false;
    const words = phrase.split(" ").filter(Boolean);
    if (words.length === 1) return (haystackTokens || tokens(haystack)).has(words[0]);
    return ` ${haystack} `.includes(` ${phrase} `);
  }

  function lexicalEvidence(candidate, term) {
    const haystack = stableEvidence(candidate);
    const haystackTokens = tokens(haystack);
    const authored = term.authoringProfile || term.vocabularyTerm?.authoringProfile || {};
    const negative = [...(term.negativeAliases || []), ...(authored.negativeAliases || [])]
      .map(normalized).find((alias) => phrasePresent(haystack, alias, haystackTokens));
    if (negative) return {
      signal: { kind: "lexical-conflict", strength: "strong", reason: `Stable DOM evidence matches the negative alias “${negative}”.` },
      score: -12,
      parentMatched: false
    };
    const leaf = normalized(term.leafName || localName(term.name));
    const matching = aliases(term).filter((alias) => phrasePresent(haystack, alias, haystackTokens));
    const parents = String(term.name || "").split(".").slice(0, -1);
    const parent = parents.find((segment) => aliasesForName(segment)
      .some((alias) => phrasePresent(haystack, normalized(alias), haystackTokens))) || null;
    if (!matching.length) return {
      signal: parent ? {
        kind: "lexical",
        strength: "moderate",
        reason: `Stable DOM evidence matches the ${parent} relationship context.`
      } : null,
      score: parent ? 4 : parents.length ? -4 : 0,
      parentMatched: Boolean(parent)
    };
    const exact = phrasePresent(haystack, leaf, haystackTokens);
    return {
      signal: {
        kind: "lexical",
        strength: exact ? "strong" : "moderate",
        reason: parent
          ? `Stable DOM evidence names ${leaf} in ${parent} context.`
          : exact ? `Stable DOM evidence names ${leaf}.` : `Stable DOM evidence matches ${matching[0]}.`
      },
      score: (exact ? 8 : 4) + (parent ? 2 : parents.length ? -4 : 0),
      parentMatched: Boolean(parent)
    };
  }

  function sampleValues(candidate) {
    const flattened = (candidate?.sampleValues || []).flat(Infinity).filter((value) => value !== null && value !== undefined && String(value).trim());
    if (flattened.length) return flattened.map(String).slice(0, 20);
    const evidence = candidate?.evidence || {};
    return [evidence.value, evidence.href, evidence.src, evidence.text]
      .filter((value) => value !== null && value !== undefined && String(value).trim()).map(String).slice(0, 20);
  }

  function valueEvidence(candidate, term) {
    const values = sampleValues(candidate);
    const valueType = term.valueType || term.ranges?.[0] || term.vocabularyTerm?.valueType || "Text";
    const combined = values.join(" ");
    const authored = term.authoringProfile || term.vocabularyTerm?.authoringProfile || {};
    const expectedShapes = new Set([...(term.expectedShapes || []), ...(authored.expectedShapes || [])]);
    const units = [...new Set([...(term.units || []), ...(authored.units || [])].map((unit) => String(unit).trim()).filter(Boolean))];
    const shapeMatches = {
      text: () => values.length > 0,
      url: () => candidate?.kind === "url" || Boolean(candidate?.evidence?.href || candidate?.evidence?.src),
      date: () => values.some((value) => ISO_DATE.test(value.trim()) || MONTH_DATE.test(value)),
      datetime: () => values.some((value) => /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(value.trim())),
      integer: () => values.length > 0 && values.every((value) => /^[-+]?\d+$/.test(value.trim().replace(/,/g, ""))),
      number: () => values.length > 0 && values.every((value) => /^[-+]?\d[\d,]*(?:\.\d+)?$/.test(value.trim())),
      boolean: () => values.length > 0 && values.every((value) => /^(?:true|false|yes|no)$/i.test(value.trim())),
      currency: () => /(?:[$€£]|\b(?:usd|eur|gbp)\b)/i.test(combined),
      percentage: () => /\d+(?:\.\d+)?\s*%/.test(combined)
    };
    let matches = false;
    if (valueType === "URL") matches = candidate?.kind === "url" || Boolean(candidate?.evidence?.href || candidate?.evidence?.src);
    else if (valueType === "Date") matches = values.some((value) => ISO_DATE.test(value.trim()) || MONTH_DATE.test(value));
    else if (valueType === "DateTime") matches = values.some((value) => /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(value.trim()));
    else if (valueType === "Boolean") matches = values.length > 0 && values.every((value) => /^(?:true|false|yes|no)$/i.test(value.trim()));
    else if (valueType === "Integer") matches = values.length > 0 && values.every((value) => /^[-+]?\d+$/.test(value.trim().replace(/,/g, "")));
    else if (valueType === "Number") matches = values.length > 0 && values.every((value) => {
      const text = value.trim();
      if (ISO_DATE.test(text) || MONTH_DATE.test(text)) return false;
      return /^(?:[$€£]\s*)?[-+]?\d[\d,]*(?:\.\d+)?(?:\s*%|\s*(?:usd|eur|gbp))?$/i.test(text);
    });
    else if (valueType === "Object") {
      matches = (term.transform || term.normalization || []).some((step) => String(step?.name || step).startsWith("parse"))
        && /(?:[$€£]|\b(?:usd|eur|gbp)\b|\d+(?:\.\d+)?\s*%)/i.test(combined);
    }
    const matchedShape = [...expectedShapes].find((shape) => shapeMatches[shape]?.());
    const matchedUnit = units.find((unit) => new RegExp(`(?:^|[^a-z0-9])${unit.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?:$|[^a-z0-9])`, "i").test(combined));
    if (!matches && !matchedShape && !matchedUnit) return null;
    const details = [matches ? `${valueType} range` : null, matchedShape ? `${matchedShape} shape` : null, matchedUnit ? `${matchedUnit} unit` : null].filter(Boolean);
    return { kind: "value", strength: "strong", reason: `Observed values match the expected ${details.join(", ")}.` };
  }

  function structureEvidence(candidate, term) {
    const evidence = candidate?.evidence || {};
    const attribute = candidate?.attribute || evidence.attribute || null;
    const leaf = term.leafName || localName(term.name);
    const valueType = term.valueType || term.ranges?.[0] || term.vocabularyTerm?.valueType || "Text";
    const heading = /^h[1-6]$/.test(evidence.tag || "");
    let reason = null;
    if (valueType === "URL" && evidence.tag === "a" && attribute === "href") reason = "An anchor href supplies a URL value.";
    else if (leaf === "image" && evidence.tag === "img" && attribute === "src") reason = "An image src supplies rendered media.";
    else if (["title", "headline", "name"].includes(leaf) && heading) reason = "A rendered heading supports a label-like property.";
    else if (["datePosted", "datePublished"].includes(leaf) && (evidence.tag === "time" || attribute === "datetime")) reason = "A time element supplies explicit date structure.";
    return reason ? { kind: "structure", strength: "strong", reason } : null;
  }

  function populationEvidence(candidate, term) {
    const counts = candidate?.evidence?.matchCounts || [];
    const sampled = Number(candidate?.coverage?.sampled || counts.length || 0);
    const present = Number(candidate?.coverage?.present || counts.filter((count) => count > 0).length || 0);
    if (sampled < 2 || present / sampled < 0.75) return null;
    const expectedMany = term.cardinality === "many";
    const pipeline = term.transform || term.normalization || [];
    const collapsesStructuredValue = term.source === "extension" && (term.valueType || term.vocabularyTerm?.valueType) === "Object"
      && pipeline.some((step) => String(step?.name || step).startsWith("parse"));
    const cardinalityConsistent = counts.length === 0 || collapsesStructuredValue
      || (expectedMany ? candidate?.multiple && counts.filter((count) => count > 1).length >= Math.ceil(counts.length * 0.5) : counts.every((count) => count <= 1));
    if (!cardinalityConsistent) return null;
    return {
      kind: "population",
      strength: present === sampled ? "strong" : "moderate",
      reason: `${present}/${sampled} sampled items agree with ${expectedMany ? "multi-value" : "single-value"} cardinality.`
    };
  }

  function cardinalityFit(candidate, term) {
    const expected = term.cardinality || "one";
    const observed = candidate?.multiple ? "many" : "one";
    const pipeline = term.transform || term.normalization || [];
    const collapsesStructuredValue = term.source === "extension" && (term.valueType || term.vocabularyTerm?.valueType) === "Object"
      && pipeline.some((step) => String(step?.name || step).startsWith("parse"));
    return {
      source: "site2json-authoring-default",
      expected,
      observed,
      status: expected === observed || collapsesStructuredValue ? "compatible" : "conflict",
      collapsesStructuredValue
    };
  }

  function compatible(candidate, term) {
    const context = stableEvidence(candidate);
    const attribute = candidate?.attribute || candidate?.evidence?.attribute || null;
    const leaf = term.leafName || localName(term.name);
    const valueType = term.valueType || term.ranges?.[0] || term.vocabularyTerm?.valueType || "Text";
    if (candidate?.kind === "url" && ["href", "src"].includes(attribute) && valueType !== "URL") return false;
    if (leaf === "url" && (candidate?.multiple || candidate?.kind !== "url" || attribute !== "href" || candidate?.evidence?.tag !== "a")) return false;
    if (term.name === "url" && FORBIDDEN_DIRECT_URL.test(context)) return false;
    if (leaf === "image" && (candidate?.evidence?.tag !== "img" || attribute !== "src")) return false;
    if (leaf === "sameAs" && (!SAME_AS_CONTEXT.test(context) || /\b(?:apply|category|skill|tag|navigation|menu)\b/.test(context))) return false;
    return true;
  }

  function analyze(candidate, term) {
    const authoring = { cardinality: cardinalityFit(candidate, term) };
    if (!compatible(candidate, term)) return { compatible: false, score: 0, signals: [], parentMatched: false, authoring };
    const lexical = lexicalEvidence(candidate, term);
    const value = valueEvidence(candidate, term);
    const structure = structureEvidence(candidate, term);
    const population = populationEvidence(candidate, term);
    const signals = [lexical.signal, value, structure, population].filter(Boolean);
    const score = Math.max(0, lexical.score + (value ? 6 : 0) + (structure ? 8 : 0) + (population ? population.strength === "strong" ? 4 : 2 : 0));
    return { compatible: true, score, signals, parentMatched: lexical.parentMatched, authoring };
  }

  function rank(term, evidence = {}) {
    const attribute = evidence.attribute || (evidence.href ? "href" : evidence.src ? "src" : null);
    const candidate = {
      selector: "", suggestedName: "", attribute,
      kind: attribute === "href" || attribute === "src" ? "url" : "text",
      multiple: Boolean(evidence.multiple), evidence
    };
    return analyze(candidate, term).score;
  }

  return Object.freeze({ VERSION, analyze, compatible, rank });
});
