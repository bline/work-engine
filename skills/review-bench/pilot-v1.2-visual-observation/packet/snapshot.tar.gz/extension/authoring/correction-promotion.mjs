import propertyProfile from "../core/property-profile.mjs";

const GENERIC = new Set(["box", "card", "content", "data", "detail", "field", "item", "label", "meta", "record", "result", "root", "row", "text", "value", "wrapper"]);
const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

function words(value) {
  return String(value || "").replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase()
    .split(/[^a-z0-9]+/).filter((word) => word.length > 1 && !GENERIC.has(word) && !/\d/.test(word) && !/^[a-f0-9]{7,}$/.test(word));
}

export function reusableAlias(evidence = {}) {
  const sources = [evidence.id, ...(evidence.classes || [])];
  for (const source of sources) {
    const tokens = words(source).slice(0, 5);
    if (tokens.length && tokens.join(" ").length <= 80) return tokens.join(" ");
  }
  return null;
}

function profileSources(term) {
  return (term?.librarySources || []).filter((source) => source?.id && source?.profile);
}

function rankedAlternatives(prior) {
  const reported = prior?.globalArbitration?.selectedFrom;
  if (!Array.isArray(reported) || !reported.length) return [];
  return [...new Set(reported
    .map((item) => String(item || "").trim().toLowerCase())
    .filter(Boolean)
  )];
}

function isRankedAlternative(prior, candidateName) {
  const alternatives = rankedAlternatives(prior);
  if (!alternatives.length) return false;
  return alternatives.includes(String(candidateName || "").trim().toLowerCase());
}

export function proposal({ originalField, selectedTerm, evidence, adapterId = "unsaved-adapter", decisionId = "field-correction" } = {}) {
  const alias = reusableAlias(evidence || originalField?.evidence);
  if (!alias || !originalField?.corroboration) return null;
  const prior = originalField.corroboration;
  const selectedProperty = selectedTerm?.name || null;
  if (!selectedProperty || !isRankedAlternative(prior, selectedProperty)) return null;
  const changes = [];
  const positive = profileSources(selectedTerm)[0];
  if (positive && !(positive.profile.aliases || []).map((value) => value.toLowerCase()).includes(alias)) {
    changes.push({
      recordId: positive.id,
      termId: positive.termId || selectedProperty,
      expectedRevision: positive.revision,
      operation: "add-alias",
      value: alias
    });
  }
  if (prior.property && prior.property !== selectedProperty) {
    const negative = (prior.localKnowledge?.sources || []).find((source) => source?.id && source?.profile);
    if (negative && !(negative.profile.negativeAliases || []).map((value) => value.toLowerCase()).includes(alias)) {
      changes.push({
        recordId: negative.id,
        termId: negative.termId || prior.property,
        expectedRevision: negative.revision,
        operation: "add-negative-alias",
        value: alias
      });
    }
  }
  if (!changes.length) return null;
  return {
    version: 1,
    adapterId: String(adapterId || "unsaved-adapter").slice(0, 80),
    decisionId: String(decisionId || "field-correction").slice(0, 160),
    fromProperty: prior.property || null,
    toProperty: selectedProperty,
    profileInfluenced: Boolean(prior.localKnowledge?.material),
    changes
  };
}

function mergeChange(profile, change, correction) {
  const next = clone(profile || { version: 1, provenance: { source: "user" } });
  const key = change.operation === "add-alias" ? "aliases" : "negativeAliases";
  next[key] = [...new Set([...(next[key] || []), change.value])];
  const provenance = next.provenance || { source: "user" };
  next.provenance = {
    source: "user-correction",
    updatedAt: correction.updatedAt,
    corrections: [...(provenance.corrections || []), correction].slice(-20)
  };
  return propertyProfile.normalize(next);
}

export async function apply(service, value, { now = () => new Date().toISOString() } = {}) {
  if (!service?.getProperty || !service?.saveProperty) throw new Error("Semantic Library property updates are unavailable.");
  const proposalValue = clone(value);
  if (!proposalValue?.changes?.length) throw new Error("There is no reusable correction to save.");
  const grouped = new Map();
  for (const change of proposalValue.changes) {
    const list = grouped.get(change.recordId) || [];
    list.push(change);
    grouped.set(change.recordId, list);
  }
  const updates = [];
  for (const [recordId, changes] of grouped) {
    const record = await service.getProperty(recordId);
    const expected = changes[0].expectedRevision;
    if (expected !== null && expected !== undefined && Number(record.revision || 1) !== Number(expected)) {
      const error = new Error(`“${record.label || recordId}” changed after this decision. Reopen Review before saving reusable knowledge.`);
      error.code = "REVISION_CONFLICT";
      throw error;
    }
    let profile = record.definition?.authoringProfile || null;
    for (const change of changes) profile = mergeChange(profile, change, {
      adapterId: proposalValue.adapterId,
      decisionId: proposalValue.decisionId,
      operation: change.operation,
      value: change.value,
      updatedAt: now()
    });
    updates.push({
      property: { ...record, definition: { ...record.definition, authoringProfile: profile } },
      expectedRevision: record.revision || 1
    });
  }
  if (service.saveProperties) return service.saveProperties({ updates });
  if (updates.length > 1) throw new Error("This Semantic Library cannot save a multi-property correction atomically.");
  return [await service.saveProperty(updates[0])];
}
