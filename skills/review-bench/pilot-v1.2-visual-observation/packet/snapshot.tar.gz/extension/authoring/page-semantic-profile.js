(function initializePageSemanticProfile(root, factory) {
  "use strict";
  const compiler = root.Site2JsonSemanticAssignmentProfile || (typeof require === "function" ? require("./semantic-assignment-profile") : null);
  const api = factory(compiler);
  root.Site2JsonPageSemanticProfile = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function pageSemanticProfileFactory(defaultCompiler) {
  "use strict";

  const DEFAULT_TYPE_LIMIT = 16;
  const DEFAULT_COMPOSITION_LIMIT = 6;
  const DEFAULT_SCORE_RATIO = 0.9;

  function finiteOption(value, fallback) {
    if (value === undefined || value === null || value === "") return fallback;
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
  }

  function typeName(candidate) {
    return String(candidate?.schemaType || candidate?.id || "").replace(/^schema:/, "").trim();
  }

  function shortlist(ranked = {}, options = {}) {
    const typeLimit = Math.max(0, Math.min(finiteOption(options.typeLimit, DEFAULT_TYPE_LIMIT), 31));
    const compositionLimit = Math.max(0, finiteOption(options.compositionLimit, DEFAULT_COMPOSITION_LIMIT));
    const scoreRatio = Math.max(0, Math.min(finiteOption(options.scoreRatio, DEFAULT_SCORE_RATIO), 1));
    const leadingScore = Math.max(0, Number(ranked.types?.[0]?.score || 0));
    const entries = [];
    const seen = new Set();
    const explainedObservations = new Set();
    function evidenceKeys(candidate) {
      return (candidate?.evidence || []).map((item) => String(item?.observation || item?.selector || "").trim()).filter(Boolean);
    }
    function credible(candidate) {
      if (!entries.length) return true;
      if (Number(candidate?.score || 0) >= leadingScore * scoreRatio) return true;
      // A lower aggregate score can still represent a second population when
      // it explains evidence the stronger hypotheses do not. Repeated catalog
      // interpretations of the same evidence are not runtime candidates.
      return evidenceKeys(candidate).some((key) => !explainedObservations.has(key));
    }
    function add(type, candidate, reason) {
      const normalized = String(type || "").replace(/^schema:/, "").trim();
      if (!normalized || seen.has(normalized) || entries.length >= typeLimit || !credible(candidate)) return;
      seen.add(normalized);
      for (const key of evidenceKeys(candidate)) explainedObservations.add(key);
      entries.push(Object.freeze({
        type: normalized,
        source: candidate?.kind === "library-type" ? "local-vocabulary" : "schema.org",
        reason,
        score: Number(candidate?.score || 0),
        explained: Number(candidate?.explained || 0),
        total: Number(candidate?.total || ranked.observationCount || 0),
        evidence: Object.freeze((candidate?.evidence || []).map((item) => Object.freeze({ ...item })))
      }));
    }
    for (const candidate of ranked.types || []) add(typeName(candidate), candidate, "ranked-type");
    for (const candidate of (ranked.compositions || []).filter((item) => item.score > 0).slice(0, compositionLimit)) {
      for (const type of [candidate.schemaType, ...(candidate.rootTypes || []), ...(candidate.compositionRootTypes || [])]) {
        add(type, candidate, "ranked-composition-root");
      }
    }
    // Thing is an unresolved fallback, not evidence that the page was
    // classified as Thing. Runtime needs it so uncertainty stays explicit.
    if (!seen.has("Thing")) entries.push(Object.freeze({
      type: "Thing", source: "schema.org", reason: "unresolved-fallback",
      score: 0, explained: 0, total: Number(ranked.observationCount || 0), evidence: Object.freeze([])
    }));
    return Object.freeze(entries.slice(0, typeLimit + 1));
  }

  function build(observations, options = {}) {
    const inference = options.inference;
    const profileCompiler = options.compiler || defaultCompiler;
    if (!inference?.rank) throw new Error("Page semantic profiling requires the shared Semantic Library inference service.");
    if (!profileCompiler?.compile) throw new Error("Page semantic profiling requires the semantic assignment profile compiler.");
    const typeLimit = finiteOption(options.typeLimit, DEFAULT_TYPE_LIMIT);
    const compositionLimit = finiteOption(options.compositionLimit, DEFAULT_COMPOSITION_LIMIT);
    const scoreRatio = finiteOption(options.scoreRatio, DEFAULT_SCORE_RATIO);
    const ranked = inference.rank(observations || [], { typeLimit });
    const selected = shortlist(ranked, options);
    const candidateTypes = selected.map((entry) => entry.type);
    const library = inference.assignmentInputs?.(candidateTypes) || { types: [], properties: [] };
    const profile = profileCompiler.compile({
      candidateTypes,
      libraryTypes: library.types || [],
      libraryProperties: library.properties || []
    });
    return Object.freeze({
      version: 1,
      profile,
      shortlist: selected,
      ranking: ranked,
      provenance: Object.freeze({
        observationCount: Number(ranked.observationCount || 0),
        localTypeIds: Object.freeze((library.types || []).map((record) => record.id)),
        localPropertyIds: Object.freeze((library.properties || []).map((record) => record.id)),
        bounded: Object.freeze({
          typeLimit,
          compositionLimit,
          scoreRatio,
          truncated: Boolean(profile.bounded?.truncated)
        })
      })
    });
  }

  return Object.freeze({ DEFAULT_TYPE_LIMIT, DEFAULT_COMPOSITION_LIMIT, DEFAULT_SCORE_RATIO, shortlist, build });
});
