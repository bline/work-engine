(function initializeSemanticLibraryInference(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonSemanticLibraryInference = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticLibraryInferenceFactory() {
  "use strict";

  const PAGE_SIZE = 100;
  const LOCAL_TYPE_LIMIT = 32;
  const LOCAL_PATTERN_LIMIT = 16;
  const STOP = new Set(["and", "are", "card", "class", "content", "data", "detail", "field", "for", "from", "item", "label", "record", "result", "row", "text", "the", "type", "value", "with"]);
  const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  function words(value) {
    return String(value || "").replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase()
      .split(/[^a-z0-9]+/).filter((word) => word.length > 2 && !STOP.has(word) && !/^\d+$/.test(word));
  }

  function localName(value) {
    const parts = String(value || "").split(/[#:/.]/).filter(Boolean);
    return parts.at(-1) || "Term";
  }

  function canonical(record) {
    return String(record?.provenance?.canonicalUri || record?.definition?.canonicalUri || record?.canonicalUri || record?.termId || record?.patternId || record?.id || "").trim();
  }

  function identifierKey(value, vocabulary) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    if (vocabulary.typeInfo(raw)) return `schema:${raw}`;
    const schema = /^(?:https?:\/\/)?schema\.org\/([^/#]+)\/?$/i.exec(raw)?.[1];
    if (schema && vocabulary.typeInfo(schema)) return `schema:${schema}`;
    return raw.toLowerCase().replace(/\/$/, "");
  }

  function hash(value) {
    let result = 2166136261;
    for (const char of String(value)) {
      result ^= char.charCodeAt(0);
      result = Math.imul(result, 16777619);
    }
    return (result >>> 0).toString(36);
  }

  function canonicalValue(value) {
    if (Array.isArray(value)) return value.map(canonicalValue);
    if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonicalValue(value[key])]));
    return value;
  }

  function profileDigest(profile) {
    if (!profile) return null;
    return `s2jp1:${hash(JSON.stringify(canonicalValue(profile))).padStart(7, "0")}`;
  }

  function evidenceTokens(candidates) {
    const found = new Set();
    for (const candidate of candidates || []) {
      const evidence = candidate?.evidence || {};
      const rendered = String(evidence.text || evidence.value || "");
      const values = [candidate?.suggestedName, candidate?.selector, evidence.id, ...(evidence.classes || []), evidence.context];
      if (rendered.length <= 100) values.push(rendered);
      for (const token of values.flatMap(words)) found.add(token);
    }
    return found;
  }

  function sourceSummary(record) {
    const profile = clone(record.definition?.authoringProfile || null);
    return {
      id: record.id,
      termId: record.termId || record.patternId || record.id,
      canonicalUri: canonical(record) || null,
      source: clone(record.provenance?.source || { kind: "local", id: "semantic-library" }),
      bundle: clone(record.provenance?.bundle || null),
      importId: record.provenance?.importId || null,
      revision: Number.isSafeInteger(record.revision) ? record.revision : null,
      ...(profile ? { profile, profileDigest: profileDigest(profile) } : {})
    };
  }

  function create({ service, ranking, vocabulary } = {}) {
    if (!ranking?.rank || !vocabulary?.typeInfo) throw new Error("Semantic Library inference requires semantic ranking and Schema.org vocabulary APIs.");
    let loaded = false;
    let loading = null;
    let typeEntries = [];
    let patternEntries = [];
    let propertyEntries = [];
    let modelEntries = new Map();
    let typeByIdentifier = new Map();
    let tokenIndex = new Map();
    let propertyDomainIndex = new Map();
    let stats = { types: 0, properties: 0, patterns: 0, canonicalTypes: 0, canonicalProperties: 0 };

    async function summaries() {
      if (!service?.search) return [];
      const found = [];
      let cursor = null;
      do {
        const page = await service.search({ filters: { kindIds: ["customType", "property", "pattern"] }, pageSize: PAGE_SIZE, ...(cursor ? { cursor } : {}) });
        found.push(...(page.items || []));
        cursor = page.nextCursor || null;
      } while (cursor);
      return found;
    }

    async function hydrate(items) {
      const byKind = (kind) => items.filter((item) => item.kind === kind).map((item) => item.id);
      const typeIds = byKind("customType");
      const propertyIds = byKind("property");
      const patternIds = byKind("pattern");
      const types = [];
      const properties = [];
      const patterns = [];
      const length = Math.max(typeIds.length, propertyIds.length, patternIds.length);
      for (let offset = 0; offset < length; offset += PAGE_SIZE) {
        const [nextTypes, nextTerms, nextPatterns] = await Promise.all([
          service.getCustomTypes?.({ ids: typeIds.slice(offset, offset + PAGE_SIZE) }) || [],
          service.getTerms?.({ ids: propertyIds.slice(offset, offset + PAGE_SIZE) }) || [],
          service.getPatterns?.({ ids: patternIds.slice(offset, offset + PAGE_SIZE) }) || []
        ]);
        types.push(...nextTypes);
        properties.push(...nextTerms.filter((record) => record.definition?.kind === "relationship" || record.definition?.kind === "field"));
        patterns.push(...nextPatterns);
      }
      return { types, properties, patterns };
    }

    function groupRecords(records, kind) {
      const groups = new Map();
      for (const record of records) {
        const key = `${kind}:${identifierKey(canonical(record), vocabulary) || record.termId || record.patternId || record.id}`;
        const group = groups.get(key) || { key, records: [] };
        group.records.push(record);
        groups.set(key, group);
      }
      return [...groups.values()].map((group) => {
        return { ...group, record: group.records[0], sources: group.records.map(sourceSummary) };
      });
    }

    function schemaType(value, seen = new Set()) {
      const raw = String(value || "");
      if (vocabulary.typeInfo(raw)) return raw;
      const uriType = /^(?:https?:\/\/)?schema\.org\/([^/#]+)\/?$/i.exec(raw)?.[1];
      if (uriType && vocabulary.typeInfo(uriType)) return uriType;
      const entry = typeByIdentifier.get(identifierKey(raw, vocabulary));
      if (!entry || seen.has(entry.key)) return null;
      seen.add(entry.key);
      for (const parent of entry.record.definition?.supers || []) {
        const resolved = schemaType(parent, seen);
        if (resolved) return resolved;
      }
      return null;
    }

    function typeKeys(entry) {
      return new Set([
        ...entry.records.flatMap((record) => [record.id, record.termId, canonical(record)]),
        ...(entry.record.definition?.supers || [])
      ].map((value) => identifierKey(value, vocabulary)).filter(Boolean));
    }

    function ownTypeKeys(entry) {
      return new Set(entry.records.flatMap((record) => [record.id, record.termId, canonical(record)])
        .map((value) => identifierKey(value, vocabulary)).filter(Boolean));
    }

    function applicableProperties(typeEntryOrName) {
      const matchingType = typeof typeEntryOrName === "string" ? typeByIdentifier.get(identifierKey(typeEntryOrName, vocabulary)) : null;
      const keys = typeof typeEntryOrName === "string"
        ? (matchingType ? typeKeys(matchingType) : new Set([identifierKey(typeEntryOrName, vocabulary)]))
        : typeKeys(typeEntryOrName);
      const found = new Set();
      for (const key of keys) for (const property of propertyDomainIndex.get(key) || []) found.add(property);
      return [...found];
    }

    function inferenceProperty(entry) {
      const definition = entry.record.definition || {};
      return {
        name: entry.record.termId || entry.record.id,
        ranges: [...(definition.rangeIncludes || (definition.valueType ? [definition.valueType] : []))],
        valueType: definition.valueType || definition.rangeIncludes?.[0] || "Text",
        cardinality: definition.cardinality || "one",
        description: entry.record.description || definition.description || "",
        ...(definition.authoringProfile ? { authoringProfile: clone(definition.authoringProfile) } : {})
      };
    }

    function enrichNode(node) {
      const actualTypes = [...(node.types || [])];
      const localTypes = actualTypes.map((type) => typeByIdentifier.get(identifierKey(type, vocabulary))).filter(Boolean);
      const inferred = [...new Set(actualTypes.map((type) => schemaType(type) || (vocabulary.typeInfo(type) ? type : null)).filter(Boolean))];
      const relevantProperties = [...new Set([
        ...actualTypes.flatMap((type) => applicableProperties(type)),
        ...localTypes.flatMap((type) => applicableProperties(type))
      ])];
      return {
        ...clone(node),
        inferenceTypes: inferred.length ? inferred : ["Thing"],
        inferenceTypeNames: [...new Set(actualTypes.flatMap((type) => [type, localName(type)]))],
        inferenceProperties: relevantProperties.map(inferenceProperty)
      };
    }

    function typeComposition(entry) {
      const type = entry.record.termId || entry.record.id;
      const composition = {
        id: `library:type:${hash(entry.key)}`,
        label: entry.record.label || localName(type),
        description: entry.record.description || entry.record.definition?.description || "Local semantic type.",
        kind: "library-type",
        schemaType: type,
        librarySourceCount: entry.sources.length,
        root: "listing",
        nodes: { listing: enrichNode({ types: [type], expectation: "core", evidenceKeywords: [entry.record.label, localName(type), ...(entry.record.definition?.evidenceAliases || [])] }) },
        edges: [], priorities: { listing: [] }
      };
      entry.composition = composition;
      entry.modelId = composition.id;
      return composition;
    }

    function patternComposition(entry) {
      const record = entry.record;
      const composition = {
        id: `library:pattern:${hash(entry.key)}`,
        label: record.label,
        description: record.description || "Local semantic graph bundle.",
        kind: "library-pattern",
        librarySourceCount: entry.sources.length,
        root: record.root,
        nodes: Object.fromEntries(Object.entries(record.nodes || {}).map(([alias, node]) => [alias, enrichNode(node)])),
        edges: clone(record.edges || []),
        priorities: clone(record.priorities || {})
      };
      composition.schemaType = composition.nodes?.[composition.root]?.types?.[0] || "Thing";
      entry.composition = composition;
      entry.modelId = composition.id;
      return composition;
    }

    function indexEntry(entry, values) {
      entry.tokens = new Set(values.flatMap(words));
      for (const token of entry.tokens) {
        const bucket = tokenIndex.get(token) || new Set();
        bucket.add(entry);
        tokenIndex.set(token, bucket);
      }
    }

    function rebuild(records) {
      tokenIndex = new Map();
      propertyDomainIndex = new Map();
      modelEntries = new Map();
      typeByIdentifier = new Map();
      typeEntries = groupRecords(records.types, "type");
      propertyEntries = groupRecords(records.properties, "property");
      patternEntries = groupRecords(records.patterns, "pattern");
      for (const entry of typeEntries) {
        for (const identifier of entry.records.flatMap((record) => [record.id, record.termId, canonical(record)])) {
          const key = identifierKey(identifier, vocabulary);
          if (key && !typeByIdentifier.has(key)) typeByIdentifier.set(key, entry);
        }
      }
      for (const property of propertyEntries) {
        for (const domain of property.record.definition?.domainIncludes || []) {
          const key = identifierKey(domain, vocabulary);
          if (!key) continue;
          const bucket = propertyDomainIndex.get(key) || new Set();
          bucket.add(property);
          propertyDomainIndex.set(key, bucket);
        }
      }
      for (const entry of typeEntries) {
        const properties = applicableProperties(entry);
        typeComposition(entry);
        indexEntry(entry, [
          entry.record.label, entry.record.termId, entry.record.description,
          ...(entry.record.definition?.evidenceAliases || []),
          ...properties.flatMap((property) => [property.record.label, property.record.termId, ...(property.record.definition?.evidenceAliases || [])])
        ]);
        modelEntries.set(entry.modelId, entry);
      }
      for (const entry of patternEntries) {
        patternComposition(entry);
        indexEntry(entry, [
          entry.record.label, entry.record.patternId, entry.record.description,
          ...Object.entries(entry.record.nodes || {}).flatMap(([alias, node]) => [alias, ...(node.types || []), ...(node.evidenceKeywords || [])]),
          ...(entry.record.edges || []).map((edge) => edge.property)
        ]);
        modelEntries.set(entry.modelId, entry);
      }
      stats = {
        types: records.types.length,
        properties: records.properties.length,
        patterns: records.patterns.length,
        canonicalTypes: typeEntries.length,
        canonicalProperties: propertyEntries.length
      };
    }

    async function load({ force = false } = {}) {
      if (loaded && !force) return stats;
      if (loading && !force) return loading;
      loading = (async () => {
        const items = await summaries();
        rebuild(await hydrate(items));
        loaded = true;
        return clone(stats);
      })();
      try { return await loading; }
      finally { loading = null; }
    }

    function invalidate() { loaded = false; }

    function selectedEntries(candidates, allowedTypes = null) {
      if (Array.isArray(allowedTypes) && allowedTypes.length) {
        const requested = new Set(allowedTypes.map((type) => identifierKey(type, vocabulary)));
        return typeEntries.filter((entry) => [...typeKeys(entry)].some((key) => requested.has(key))).slice(0, LOCAL_TYPE_LIMIT);
      }
      const tokens = evidenceTokens(candidates);
      const scores = new Map();
      for (const token of tokens) for (const entry of tokenIndex.get(token) || []) scores.set(entry, (scores.get(entry) || 0) + 1);
      const ordered = [...scores].sort((left, right) => right[1] - left[1] || left[0].record.label.localeCompare(right[0].record.label));
      return ordered.filter(([entry]) => typeEntries.includes(entry)).slice(0, LOCAL_TYPE_LIMIT).map(([entry]) => entry);
    }

    function rank(candidates, options = {}) {
      const types = selectedEntries(candidates, options.allowedTypes);
      const patterns = Array.isArray(options.allowedTypes) && options.allowedTypes.length ? [] : (() => {
        const tokens = evidenceTokens(candidates);
        return patternEntries.map((entry) => [entry, [...entry.tokens].filter((token) => tokens.has(token)).length])
          .filter(([, score]) => score > 0)
          .sort((left, right) => right[1] - left[1] || left[0].record.label.localeCompare(right[0].record.label))
          .slice(0, LOCAL_PATTERN_LIMIT).map(([entry]) => entry);
      })();
      return ranking.rank(candidates, {
        ...options,
        additionalCompositions: [...types, ...patterns].map((entry) => entry.composition)
      });
    }

    function entryForModel(modelId) { return modelEntries.get(String(modelId || "")) || null; }
    function hasType(type) { return Boolean(vocabulary.typeInfo(type) || typeByIdentifier.has(identifierKey(type, vocabulary))); }

    function assignmentInputs(types = []) {
      const requested = new Set(types.map((type) => identifierKey(type, vocabulary)).filter(Boolean));
      // A requested Schema.org parent (especially the Thing fallback) must not
      // silently install every local subtype into the runtime profile. Only a
      // locally ranked type's own identity crosses this boundary; parent keys
      // remain useful for property lookup after that exact selection.
      const selectedTypes = typeEntries.filter((entry) => [...ownTypeKeys(entry)].some((key) => requested.has(key)));
      const selectedProperties = new Set(selectedTypes.flatMap((entry) => applicableProperties(entry)));
      return {
        types: clone(selectedTypes.map((entry) => entry.record)),
        properties: clone([...selectedProperties].map((entry) => entry.record))
      };
    }

    function termDefinition(record) {
      const definition = clone(record.definition || {});
      // Reusable inference profiles belong to the local Semantic Library, not
      // the executable adapter vocabulary.
      delete definition.authoringProfile;
      return {
        ...definition,
        description: definition.description || record.description || `Imported semantic term ${record.termId || record.id}.`,
        valueType: definition.valueType || record.termId || record.id,
        cardinality: definition.cardinality || "one",
        example: Object.hasOwn(definition, "example") ? definition.example : record.label || localName(record.termId || record.id),
        ...(canonical(record) ? { canonicalUri: canonical(record) } : {})
      };
    }

    function materialize(modelId, { adapterPrefix, existingTerms = {} } = {}) {
      const entry = entryForModel(modelId);
      if (!entry) return null;
      const prefix = String(adapterPrefix || "").trim();
      if (!prefix) throw new Error("Set the adapter id before applying a Semantic Library model.");
      const terms = clone(existingTerms || {});
      const definitions = new Map();
      for (const typeEntry of typeEntries) definitions.set(identifierKey(typeEntry.record.termId || typeEntry.record.id, vocabulary), typeEntry.record);
      for (const propertyEntry of propertyEntries) definitions.set(identifierKey(propertyEntry.record.termId || propertyEntry.record.id, vocabulary), propertyEntry.record);
      for (const [term, definition] of Object.entries(entry.record.terms || {})) definitions.set(identifierKey(term, vocabulary), { id: term, termId: term, label: localName(term), definition });
      const idMap = new Map();

      function localId(original) {
        if (vocabulary.typeInfo(original) || vocabulary.property?.("Thing", original)) return original;
        if (String(original).startsWith(`${prefix}:`) && terms[original]) return original;
        const key = identifierKey(original, vocabulary);
        if (idMap.has(key)) return idMap.get(key);
        const record = definitions.get(key);
        const definition = record ? termDefinition(record) : null;
        const canonicalUri = definition?.canonicalUri || "";
        const sameCanonical = canonicalUri && Object.entries(terms).find(([, candidate]) => candidate?.canonicalUri === canonicalUri)?.[0];
        if (sameCanonical) { idMap.set(key, sameCanonical); return sameCanonical; }
        const base = localName(record?.termId || original).replace(/[^A-Za-z0-9_-]/g, "") || "Term";
        let proposed = `${prefix}:${base}`;
        let suffix = 2;
        while (terms[proposed] && JSON.stringify(terms[proposed]) !== JSON.stringify(definition)) proposed = `${prefix}:${base}${suffix++}`;
        idMap.set(key, proposed);
        if (definition) terms[proposed] = definition;
        return proposed;
      }

      function materializeType(type, seen = new Set()) {
        if (vocabulary.typeInfo(type)) return type;
        const key = identifierKey(type, vocabulary);
        if (seen.has(key)) return localId(type);
        seen.add(key);
        const localized = localId(type);
        const record = definitions.get(key);
        if (record && terms[localized]?.supers) terms[localized].supers = terms[localized].supers.map((parent) => materializeType(parent, seen));
        if (terms[localized]) terms[localized].valueType = localized;
        return localized;
      }

      const composition = clone(entry.composition);
      for (const node of Object.values(composition.nodes || {})) {
        node.types = (node.types || []).map((type) => materializeType(type));
        delete node.inferenceTypes;
        delete node.inferenceTypeNames;
        delete node.inferenceProperties;
      }
      for (const edge of composition.edges || []) {
        const sourceTypes = entry.composition.nodes?.[edge.from]?.types || [];
        const schemaProperty = sourceTypes.some((type) => vocabulary.property?.(schemaType(type) || type, edge.property));
        if (!schemaProperty) edge.property = localId(edge.property);
      }
      for (const definition of Object.values(terms)) {
        if (definition.kind === "relationship") {
          definition.domainIncludes = (definition.domainIncludes || []).map((type) => materializeType(type));
          definition.rangeIncludes = (definition.rangeIncludes || []).map((type) => materializeType(type));
          if (definition.rangeIncludes.length) definition.valueType = definition.rangeIncludes[0];
        }
      }
      composition.id = entry.modelId;
      composition.kind = entry.record.nodes ? "composition" : "custom-type";
      composition.schemaType = composition.nodes?.[composition.root]?.types?.[0] || "Thing";
      delete composition.librarySourceCount;
      return {
        composition,
        customTerms: terms,
        schemaType: composition.schemaType,
        inferenceSchemaType: entry.composition.schemaType,
        sources: clone(entry.sources)
      };
    }

    function propertyScore(record, candidate) {
      const evidence = candidate?.evidence || {};
      const direct = new Set(words([candidate?.suggestedName, candidate?.selector, evidence.id, ...(evidence.classes || [])].join(" ")));
      const definition = record.definition || {};
      const profile = definition.authoringProfile || {};
      const hints = new Set(words([record.termId, record.label, ...(definition.evidenceAliases || []), ...(profile.aliases || [])].join(" ")));
      const negative = new Set(words((profile.negativeAliases || []).join(" ")));
      const overlaps = [...direct].filter((token) => hints.has(token));
      let score = Math.min(24, overlaps.length * 8);
      if ([...direct].some((token) => negative.has(token))) return 0;
      const normalizedSuggested = String(candidate?.suggestedName || "").replace(/[^a-z0-9]/gi, "").toLowerCase();
      const normalizedTerm = localName(record.termId || record.id).replace(/[^a-z0-9]/gi, "").toLowerCase();
      if (normalizedSuggested && normalizedSuggested === normalizedTerm) score = Math.max(score, 32);
      if ((candidate?.kind === "url" || evidence.href || evidence.src) && ["URL", "ImageObject"].includes(definition.valueType)) score += 6;
      if (candidate?.multiple && definition.cardinality === "many") score += 2;
      return score;
    }

    function propertyCandidate(entry, score, { adapterPrefix, existingTerms = {} } = {}) {
      const original = entry.record.termId || entry.record.id;
      const definition = termDefinition(entry.record);
      const authoringProfile = clone(entry.record.definition?.authoringProfile || null);
      const prefix = String(adapterPrefix || "").trim();
      const sameCanonical = definition.canonicalUri && Object.entries(existingTerms).find(([, term]) => term?.canonicalUri === definition.canonicalUri)?.[0];
      const base = localName(original).replace(/[^A-Za-z0-9_-]/g, "") || "field";
      let name = sameCanonical || (prefix ? `${prefix}:${base}` : original);
      let suffix = 2;
      while (existingTerms[name] && JSON.stringify(existingTerms[name]) !== JSON.stringify(definition)) {
        name = prefix ? `${prefix}:${base}${suffix++}` : `${original}${suffix++}`;
      }
      return {
        name,
        valueType: definition.valueType,
        cardinality: definition.cardinality,
        description: definition.description,
        evidenceAliases: [...(definition.evidenceAliases || [])],
        ...(authoringProfile ? { authoringProfile } : {}),
        score,
        source: "extension",
        vocabularyTerm: definition,
        librarySources: clone(entry.sources)
      };
    }

    function propertiesForType(type, options = {}) {
      return applicableProperties(type)
        .map((entry) => propertyCandidate(entry, 0, options))
        .sort((left, right) => left.name.localeCompare(right.name));
    }

    function propertySuggestions(type, candidate, { adapterPrefix, existingTerms = {} } = {}) {
      const matches = applicableProperties(type).map((entry) => ({ entry, score: propertyScore(entry.record, candidate) }))
        .filter(({ score }) => score > 0)
        .sort((left, right) => right.score - left.score || left.entry.record.label.localeCompare(right.entry.record.label));
      return matches.map(({ entry, score }) => propertyCandidate(entry, score, { adapterPrefix, existingTerms }));
    }

    return Object.freeze({
      hasType,
      assignmentInputs,
      invalidate,
      load,
      materialize,
      propertiesForType,
      propertySuggestions,
      rank,
      schemaFallback: (type) => schemaType(type) || (vocabulary.typeInfo(type) ? type : "Thing"),
      stats: () => clone(stats)
    });
  }

  return Object.freeze({ create });
});
