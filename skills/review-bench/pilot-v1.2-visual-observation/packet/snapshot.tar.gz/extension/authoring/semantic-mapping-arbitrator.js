(function initializeSemanticMappingArbitrator(root, factory) {
  "use strict";
  const corroborator = root.Site2JsonFieldMappingCorroborator || (typeof require === "function" ? require("./field-mapping-corroborator") : null);
  const api = factory(corroborator);
  root.Site2JsonSemanticMappingArbitrator = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticMappingArbitratorFactory(corroborator) {
  "use strict";

  if (!corroborator?.evaluate || !corroborator?.corroborate) throw new Error("Semantic mapping arbitration requires the field mapping corroborator.");

  const VERSION = 1;
  const DEFAULT_BEAM_WIDTH = 96;
  const DEFAULT_OPTION_LIMIT = 6;
  const EPSILON = 0.0001;
  const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  function pathRoot(name) {
    const segments = String(name || "").split(".");
    return segments.length > 1 ? segments[0] : null;
  }

  function semanticPrior(evaluated) {
    const prior = evaluated.term.semanticPrior || {};
    const validity = evaluated.term.catalogValidity || {};
    const salience = Math.max(0, Math.min(100, Number(prior.salience ?? evaluated.term.salience ?? 0))) / 30;
    const domainMatch = validity.domain?.match || "unscoped";
    const domain = domainMatch === "direct" ? 1 : domainMatch === "inherited" ? 0.5 : domainMatch === "declared-custom" ? 0.5 : 0;
    const relationship = validity.relationship ? 0.5 : 0;
    const cardinalityConflict = evaluated.authoring?.cardinality?.status === "conflict";
    const authoring = cardinalityConflict ? -8 : 0;
    return {
      total: salience + domain + relationship + authoring,
      salience,
      domain,
      domainMatch,
      relationship,
      authoring,
      cardinality: clone(evaluated.authoring?.cardinality || prior.cardinality || null)
    };
  }

  function optionValue(evaluated) {
    return (evaluated.adjustedScore - evaluated.minimum) + semanticPrior(evaluated).total;
  }

  function eligible(evaluated) {
    if (evaluated.score < evaluated.minimum) return false;
    return evaluated.signals.some((signal) => signal.kind !== "population");
  }

  function recordOptions(record, optionLimit) {
    const evaluated = corroborator.evaluate(record.candidate, record.suggestions || []);
    const local = corroborator.corroborate(record.candidate, record.suggestions || []);
    const seen = new Set();
    const options = [];
    for (const item of evaluated) {
      const name = String(item.term.name || "");
      if (!name || seen.has(name) || !eligible(item)) continue;
      seen.add(name);
      const locallyAccepted = Boolean(local.accepted && local.term?.name === name);
      options.push({
        ...item,
        name,
        family: pathRoot(name),
        locallyAccepted,
        localReport: locallyAccepted ? local.report : null,
        semanticPrior: semanticPrior(item),
        utility: optionValue(item)
      });
      if (options.length >= optionLimit) break;
    }
    return { ...record, evaluated, local, options };
  }

  function compareStates(left, right) {
    if (Math.abs(right.score - left.score) > EPSILON) return right.score - left.score;
    return left.signature.localeCompare(right.signature);
  }

  function stateSignature(choices) {
    return choices.map((choice) => choice?.name || "-").join("\u001f");
  }

  function extendState(state, recordIndex, option, expectedProperties, relationshipExpectations) {
    const choices = state.choices.slice();
    if (!option) {
      choices[recordIndex] = null;
      return { ...state, choices, signature: stateSignature(choices) };
    }
    if (state.used.has(option.name)) return null;
    const used = new Set(state.used);
    used.add(option.name);
    const families = new Map(state.families);
    const priorFamilyCount = option.family ? (families.get(option.family) || 0) : 0;
    if (option.family) families.set(option.family, priorFamilyCount + 1);
    const relationshipSupport = option.family ? priorFamilyCount * 3 : 0;
    const expectedSupport = expectedProperties.has(option.name) ? 1 : 0;
    const relationshipExpectation = option.family
      ? (relationshipExpectations.get(option.family) === "core" ? 4 : relationshipExpectations.has(option.family) ? 2 : 0)
      : 0;
    choices[recordIndex] = option;
    return {
      score: state.score + option.utility + relationshipSupport + expectedSupport + relationshipExpectation,
      choices,
      used,
      families,
      signature: stateSignature(choices)
    };
  }

  function finalScore(state) {
    let score = state.score;
    for (const count of state.families.values()) if (count === 1) score -= 2.5;
    return score;
  }

  function localReportFor(record, option) {
    if (option.localReport) return clone(option.localReport);
    const runner = record.evaluated.find((candidate) => candidate.term.name !== option.name && candidate.score >= candidate.minimum) || null;
    const margin = option.adjustedScore - Math.max(0, runner?.adjustedScore || 0);
    const semanticSignals = option.signals.filter((signal) => signal.kind !== "population");
    return {
      version: corroborator.VERSION,
      status: "uncertain",
      confidence: "weak",
      property: option.name,
      source: option.term.source || null,
      score: option.score,
      adjustedScore: option.adjustedScore,
      margin: Math.round(margin * 100) / 100,
      runnerUp: runner ? { property: runner.term.name, score: runner.score, adjustedScore: runner.adjustedScore } : null,
      signals: clone(option.signals),
      reasons: [
        ...(option.signals.length < 2 || (semanticSignals.length < 2 && !semanticSignals.some((signal) => signal.strength === "strong")) ? ["Fewer than two independent observed-evidence families support the mapping."] : []),
        ...(margin < 2 ? ["The local evidence alone does not have a safe margin over the runner-up."] : [])
      ]
    };
  }

  function counterfactualMargin(states, best, recordIndex) {
    const selected = best.choices[recordIndex]?.name || null;
    const alternative = states.find((state) => (state.choices[recordIndex]?.name || null) !== selected);
    return alternative ? best.score - alternative.score : best.score;
  }

  function withoutLocalProfile(term) {
    if (!term?.authoringProfile) return clone(term);
    const baseline = term.profileBaseline || {};
    const next = clone(term);
    delete next.authoringProfile;
    delete next.profileBaseline;
    delete next.negativeAliases;
    delete next.expectedShapes;
    delete next.units;
    delete next.examples;
    next.aliases = clone(baseline.aliases || []);
    next.cardinality = baseline.cardinality || next.cardinality;
    next.normalization = clone(baseline.normalization || next.normalization || []);
    next.salience = baseline.salience ?? next.salience;
    if (next.semanticPrior) {
      next.semanticPrior.salience = next.salience;
      next.semanticPrior.cardinality = { value: next.cardinality, source: "site2json-authoring-default" };
    }
    return next;
  }

  function counterfactualRecords(records) {
    return records.map((record) => ({
      ...record,
      suggestions: (record.suggestions || []).map(withoutLocalProfile)
    }));
  }

  function arbitrate(records = [], {
    existingPropertyNames = [],
    expectedProperties = [],
    relationshipExpectations = {},
    beamWidth = DEFAULT_BEAM_WIDTH,
    optionLimit = DEFAULT_OPTION_LIMIT,
    _counterfactual = false
  } = {}) {
    const prepared = records.map((record) => recordOptions(record, optionLimit));
    const expected = new Set(expectedProperties);
    const expectedRelationships = new Map(Object.entries(relationshipExpectations || {}));
    const initiallyUsed = new Set(existingPropertyNames);
    let states = [{ score: 0, choices: Array(records.length).fill(null), used: initiallyUsed, families: new Map(), signature: "" }];
    const order = prepared.map((record, index) => ({ record, index }))
      .sort((left, right) => (right.record.options[0]?.utility || 0) - (left.record.options[0]?.utility || 0) || left.index - right.index);

    for (const { record, index } of order) {
      const next = [];
      for (const state of states) {
        next.push(extendState(state, index, null, expected, expectedRelationships));
        for (const option of record.options) {
          const extended = extendState(state, index, option, expected, expectedRelationships);
          if (extended) next.push(extended);
        }
      }
      states = next.sort(compareStates).slice(0, Math.max(2, beamWidth));
    }

    states = states.map((state) => ({ ...state, score: finalScore(state) })).sort(compareStates);
    const best = states[0] || { score: 0, choices: Array(records.length).fill(null), families: new Map() };
    const runner = states[1] || null;
    const assignmentMargin = best.score - (runner?.score || 0);
    const assignments = prepared.map((record, index) => {
      const option = best.choices[index];
      if (!option) {
        const report = clone(record.local?.report || null);
        if (report) {
          report.globalArbitration = {
            version: VERSION,
            assignmentScore: Math.round(best.score * 100) / 100,
            assignmentMargin: Math.round(assignmentMargin * 100) / 100,
            fieldMargin: 0,
            relationshipFamily: null,
            relationshipSupport: 0,
            expectedSupport: 0,
            relationshipExpectation: 0,
            semanticPrior: null,
            catalogValidity: null,
            selectedFrom: record.options.map((candidate) => candidate.name)
          };
        }
        return { candidate: record.candidate, accepted: false, term: null, local: record.local, report };
      }
      const familyCount = option.family ? (best.families.get(option.family) || 0) : 0;
      const relationshipSupport = option.family ? (familyCount > 1 ? Math.min(6, (familyCount - 1) * 3) : -2.5) : 0;
      const expectedSupport = expected.has(option.name) ? 1 : 0;
      const relationshipExpectation = option.family
        ? (expectedRelationships.get(option.family) === "core" ? 4 : expectedRelationships.has(option.family) ? 2 : 0)
        : 0;
      const fieldMargin = counterfactualMargin(states, best, index);
      const graphSupported = relationshipSupport >= 3 || expectedSupport > 0 || relationshipExpectation > 0;
      const substantiveSignals = option.signals.filter((signal) => signal.kind !== "population");
      const basicObservedSupport = option.signals.length >= 2 && substantiveSignals.length >= 1;
      const strongObservedSupport = option.signals.length >= 2
        && (substantiveSignals.length >= 2 || substantiveSignals.some((signal) => signal.strength === "strong"));
      const semanticPriorSupported = option.semanticPrior.total > 0 && fieldMargin >= 2;
      const cardinalityConflict = option.authoring?.cardinality?.status === "conflict";
      const accepted = !cardinalityConflict && (option.locallyAccepted
        || (graphSupported && basicObservedSupport && fieldMargin >= 2)
        || (semanticPriorSupported && strongObservedSupport && fieldMargin >= 2));
      const report = localReportFor(record, option);
      report.globalArbitration = {
        version: VERSION,
        assignmentScore: Math.round(best.score * 100) / 100,
        assignmentMargin: Math.round(assignmentMargin * 100) / 100,
        fieldMargin: Math.round(fieldMargin * 100) / 100,
        relationshipFamily: option.family,
        relationshipSupport,
        expectedSupport,
        relationshipExpectation,
        semanticPrior: clone(option.semanticPrior),
        catalogValidity: clone(option.term.catalogValidity || null),
        selectedFrom: record.options.map((candidate) => candidate.name)
      };
      if (accepted && !option.locallyAccepted) {
        report.status = "accepted";
        report.confidence = option.signals.filter((signal) => signal.strength === "strong").length >= 2
          && (relationshipSupport >= 3 || semanticPriorSupported) ? "strong" : "moderate";
        report.reasons = [];
        report.semanticSupport = {
          strength: relationshipSupport >= 3 ? "strong" : "moderate",
          reason: option.family
            ? `Related mappings jointly support the ${option.family} semantic relationship.`
            : `The ${option.semanticPrior.domainMatch} domain fit and authored property salience resolve otherwise equivalent observed evidence.`
        };
      }
      return {
        candidate: record.candidate,
        accepted,
        term: accepted ? { ...clone(option.term), corroboration: report } : null,
        local: record.local,
        report
      };
    });

    const result = {
      version: VERSION,
      assignments,
      score: Math.round(best.score * 100) / 100,
      margin: Math.round(assignmentMargin * 100) / 100,
      alternatives: states.slice(1, 4).map((state) => ({ score: Math.round(state.score * 100) / 100, signature: state.signature })),
      summary: {
        candidates: records.length,
        accepted: assignments.filter((assignment) => assignment.accepted).length,
        unresolved: assignments.filter((assignment) => !assignment.accepted).length,
        relationshipFamilies: [...best.families.entries()].map(([name, count]) => ({ name, count }))
      }
    };
    if (!_counterfactual && records.some((record) => (record.suggestions || []).some((term) => term.authoringProfile))) {
      const counterfactual = arbitrate(counterfactualRecords(records), {
        existingPropertyNames,
        expectedProperties,
        relationshipExpectations,
        beamWidth,
        optionLimit,
        _counterfactual: true
      });
      for (const [index, assignment] of result.assignments.entries()) {
        const without = counterfactual.assignments[index];
        const selected = assignment.term?.name || assignment.report?.property || null;
        const baselineSelected = without?.term?.name || without?.report?.property || null;
        const contributing = [...new Map((records[index]?.suggestions || [])
          .flatMap((term) => term.authoringProfile ? (term.librarySources || []) : [])
          .filter((source) => source.profile)
          .map((source) => [`${source.id || source.termId}@${source.profileDigest || "profile"}`, source])).values()];
        const material = Boolean(contributing.length && (selected !== baselineSelected || assignment.accepted !== without?.accepted));
        assignment.report = assignment.report || {};
        assignment.report.localKnowledge = {
          version: 1,
          material,
          acceptedByAuthor: false,
          selectedProperty: selected,
          withoutProfile: {
            accepted: Boolean(without?.accepted),
            property: baselineSelected,
            confidence: without?.report?.confidence || null,
            score: without?.report?.adjustedScore ?? without?.report?.score ?? null
          },
          sources: clone(contributing)
        };
        if (material && assignment.accepted) {
          assignment.accepted = false;
          assignment.term = null;
          assignment.report.status = "profile-review-required";
          assignment.report.confidence = "review";
          assignment.report.reasons = [...new Set([
            ...(assignment.report.reasons || []),
            "Local reusable knowledge materially changed this decision; an author must review it before it can be accepted."
          ])];
        }
      }
      result.summary.accepted = result.assignments.filter((assignment) => assignment.accepted).length;
      result.summary.unresolved = result.assignments.length - result.summary.accepted;
      result.counterfactual = {
        score: counterfactual.score,
        margin: counterfactual.margin,
        signature: counterfactual.assignments.map((assignment) => assignment.term?.name || "-").join("\u001f")
      };
    }
    return result;
  }

  return Object.freeze({ DEFAULT_BEAM_WIDTH, DEFAULT_OPTION_LIMIT, VERSION, arbitrate });
});
