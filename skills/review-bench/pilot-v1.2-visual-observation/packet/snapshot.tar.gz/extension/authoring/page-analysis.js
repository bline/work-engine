(function initializePageAnalysis(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonPageAnalysis = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function pageAnalysisFactory() {
  "use strict";

  const CONFIDENCE = Object.freeze({ none: 0, low: 1, medium: 2, high: 3 });

  function confidenceAtLeast(actual, required) {
    return (CONFIDENCE[actual] || 0) >= (CONFIDENCE[required] || 0);
  }

  function create({
    findScopes,
    analyzeScope,
    now = () => Date.now(),
    candidateLimit = 3,
    minConfidence = "high",
    minMargin = 10,
    minSingletonSemanticConfidence = "high"
  } = {}) {
    if (typeof findScopes !== "function") throw new TypeError("Page Analysis requires findScopes().");
    if (typeof analyzeScope !== "function") throw new TypeError("Page Analysis requires analyzeScope().");
    const sessions = new Map();

    function structuralDecision(scan) {
      const accepted = Boolean(scan?.chosen)
        && confidenceAtLeast(scan.confidence, minConfidence)
        && Number(scan.margin || 0) >= minMargin;
      return {
        accepted,
        confidence: scan?.confidence || "none",
        margin: Number(scan?.margin || 0),
        thresholds: { minConfidence, minMargin }
      };
    }

    function automaticDecision(scan, candidate) {
      const structural = structuralDecision(scan);
      if (scan?.mode !== "single") return { ...structural, mode: "collection", semanticAccepted: true };
      const semanticConfidence = candidate?.analysis?.recommendation?.confidence || "none";
      const semanticAccepted = confidenceAtLeast(semanticConfidence, minSingletonSemanticConfidence);
      return {
        ...structural,
        accepted: structural.accepted && semanticAccepted,
        mode: "single",
        semanticAccepted,
        semanticConfidence,
        thresholds: { ...structural.thresholds, minSingletonSemanticConfidence }
      };
    }

    function createSession(key, context) {
      const listeners = new Set();
      const startedAt = now();
      let completionPromise = null;
      const report = {
        version: 1,
        key,
        context: { ...context },
        status: "running",
        complete: false,
        startedAt,
        durationMs: 0,
        pageUrl: context.pageUrl || null,
        evidenceCount: 0,
        structuralDurationMs: 0,
        structuralConfidence: "none",
        structuralMargin: 0,
        structuralArbitration: null,
        scopeMode: null,
        chosenSelector: null,
        candidates: [],
        decision: { status: "pending", complete: false, reason: "Scanning the rendered page." }
      };

      function emit() {
        report.durationMs = Math.max(0, now() - startedAt);
        for (const listener of listeners) {
          try { listener(report); } catch { /* A view listener cannot abort shared analysis. */ }
        }
      }

      async function analyzeCandidate(index) {
        const candidate = report.candidates[index];
        if (!candidate || candidate.analysis) return candidate;
        candidate.analysis = await analyzeScope(candidate, { index, key, context: report.context });
        emit();
        return candidate;
      }

      const leadingPromise = (async () => {
        try {
          const scan = await findScopes({ key, context: report.context });
          if (!scan?.ok) throw new Error(scan?.message || "Could not scan the rendered page.");
          report.pageUrl = scan.pageUrl || report.pageUrl;
          report.evidenceCount = Number(scan.evidenceCount || 0);
          report.structuralDurationMs = Number(scan.durationMs || 0);
          report.structuralConfidence = scan.confidence || "none";
          report.structuralMargin = Number(scan.margin || 0);
          report.structuralArbitration = scan.arbitration ? { ...scan.arbitration } : null;
          report.scopeMode = scan.mode || "collection";
          report.chosenSelector = scan.chosen?.selector || null;
          report.candidates = (scan.candidates || []).map((candidate) => ({ ...candidate }));
          if (!report.candidates.length || !report.chosenSelector) {
            report.status = "complete";
            report.complete = true;
            report.decision = { status: "review", complete: true, reason: "No repeated evidence scope met the minimum structural requirements." };
            emit();
            return report;
          }
          const leadingIndex = Math.max(0, report.candidates.findIndex((candidate) => candidate.selector === report.chosenSelector));
          await analyzeCandidate(leadingIndex);
          const decision = automaticDecision(scan, report.candidates[leadingIndex]);
          if (decision.accepted) {
            report.status = "complete";
            report.complete = true;
            report.decision = { ...decision, status: "accepted", complete: true, reason: decision.mode === "single"
              ? "The singleton detail root cleared both the configured structural and semantic thresholds."
              : "The leading boundary cleared the configured structural confidence and margin." };
          } else {
            report.status = "progressive";
            report.decision = { ...decision, status: "pending", complete: false, reason: decision.mode === "single" && !decision.semanticAccepted
              ? "The detail boundary is structurally plausible, but its semantic type is not yet confident enough for automatic acceptance."
              : "The leading boundary is uncertain; bounded alternatives remain to be analyzed." };
          }
          emit();
          return report;
        } catch (error) {
          report.status = "error";
          report.complete = true;
          report.error = error instanceof Error ? error.message : String(error);
          report.decision = { status: "error", complete: true, reason: report.error };
          emit();
          throw error;
        }
      })();

      async function complete() {
        if (!completionPromise) completionPromise = (async () => {
          await leadingPromise;
          if (report.status === "error" || report.complete) return report;
          const bounded = Math.min(Math.max(1, candidateLimit), report.candidates.length);
          for (let index = 0; index < bounded; index += 1) await analyzeCandidate(index);
          report.status = "complete";
          report.complete = true;
          report.decision = {
            ...automaticDecision({ mode: report.scopeMode, chosen: report.chosenSelector ? {} : null, confidence: report.structuralConfidence, margin: report.structuralMargin }, report.candidates.find((candidate) => candidate.selector === report.chosenSelector)),
            status: "review",
            complete: true,
            reason: `The leading boundary did not clear the configured threshold after ${bounded} bounded candidate${bounded === 1 ? "" : "s"} were analyzed.`
          };
          emit();
          return report;
        })();
        return completionPromise;
      }

      return Object.freeze({
        key,
        context: report.context,
        leading: () => leadingPromise,
        complete,
        prefetch: complete,
        snapshot: () => report,
        subscribe(listener) {
          if (typeof listener !== "function") return () => {};
          listeners.add(listener);
          listener(report);
          return () => listeners.delete(listener);
        }
      });
    }

    function start({ key, context = {}, force = false, onUpdate } = {}) {
      if (!key) throw new TypeError("Page Analysis requires a cache key.");
      if (force) sessions.delete(key);
      let session = sessions.get(key);
      if (!session) {
        session = createSession(key, context);
        sessions.set(key, session);
      }
      if (typeof onUpdate === "function") session.subscribe(onUpdate);
      return session;
    }

    function invalidate(key = null) {
      if (key === null) sessions.clear();
      else sessions.delete(key);
    }

    return Object.freeze({ start, invalidate, size: () => sessions.size });
  }

  return Object.freeze({ CONFIDENCE, confidenceAtLeast, create });
});
