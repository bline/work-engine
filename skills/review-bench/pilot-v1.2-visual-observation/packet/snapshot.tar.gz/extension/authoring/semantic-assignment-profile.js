(function initializeSemanticAssignmentProfile(root, factory) {
  "use strict";
  const vocabulary = root.Site2JsonSchemaVocabulary || (typeof require === "function" ? require("../editor/schema-vocabulary") : null);
  const api = factory(vocabulary);
  root.Site2JsonSemanticAssignmentProfile = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticAssignmentProfileFactory(vocabulary) {
  "use strict";

  if (!vocabulary?.propertiesFor) throw new Error("Semantic assignment profile compilation requires the packaged vocabulary.");

  const FORMAT = "site2json-semantic-assignment-profile";
  const VERSION = 1;
  const SCHEMA = "https://schema.org/";
  const MAX_TYPES = 32;
  const MAX_PROPERTIES = 512;
  const MAX_ROLE_CANDIDATES = 32;
  const MAX_COMPOSITIONS = 32;
  const MAX_COMPOSITION_EDGES = 128;
  const MAX_RELATIONSHIP_DEPTH = 8;
  const GENERIC_RELATIONSHIP_PROPERTIES = new Set(["alternateName", "description", "disambiguatingDescription", "name", "url"]);
  const RELATIONSHIP_MATERIALIZATION_RULES = Object.freeze({
    offers: Object.freeze({ Offer: Object.freeze(["price"]) })
  });
  const DEFAULT_ROLES = Object.freeze(["title", "heading", "url", "description", "date", "datePosted", "datePublished", "employmentType", "salary", "author", "price"]);
  const ROLE_ALIASES = Object.freeze({
    title: ["title", "name", "headline"],
    heading: ["heading", "title", "name", "headline"],
    url: ["url"],
    description: ["description", "article body", "summary"],
    date: ["date", "date posted", "date published", "upload date"],
    datePosted: ["date posted", "posted date"],
    datePublished: ["date published", "published date", "upload date"],
    employmentType: ["employment type", "job type"],
    salary: ["salary", "base salary", "compensation"],
    author: ["author", "creator", "byline"],
    price: ["price", "amount"]
  });

  function leaf(value) {
    return String(value || "").split(/[\/#:.]/).filter(Boolean).at(-1) || "";
  }

  function words(value) {
    return leaf(value).replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  }

  function unique(values) {
    return [...new Set((values || []).filter(Boolean))];
  }

  function stable(value) {
    if (Array.isArray(value)) return value.map(stable);
    if (!value || typeof value !== "object") return value;
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, stable(value[key])]));
  }

  function digest(value) {
    const input = JSON.stringify(stable(value));
    let hash = 0x811c9dc5;
    for (let index = 0; index < input.length; index += 1) {
      hash ^= input.charCodeAt(index);
      hash = Math.imul(hash, 0x01000193) >>> 0;
    }
    return `fnv1a32:${hash.toString(16).padStart(8, "0")}`;
  }

  function recordEntries(records) {
    if (Array.isArray(records)) return records.map((record) => [record.id || record.termId || record.definition?.canonicalUri, record]);
    return Object.entries(records || {});
  }

  function localTypes(records) {
    return recordEntries(records).map(([id, record]) => {
      const definition = record.definition || record;
      return {
        id,
        term: definition.canonicalUri || record.termId || id,
        label: record.label || leaf(id),
        supers: unique(definition.supers || []),
        record
      };
    }).filter((item) => item.id && item.term);
  }

  function localProperties(records) {
    return recordEntries(records).map(([id, record]) => {
      const definition = record.definition || record;
      return {
        id,
        term: definition.canonicalUri || record.termId || id,
        name: leaf(definition.canonicalUri || record.termId || id),
        domains: unique(definition.domainIncludes || []),
        ranges: unique(definition.rangeIncludes || (definition.valueType ? [definition.valueType] : [])),
        aliases: unique([...(definition.evidenceAliases || []), ...(definition.authoringProfile?.aliases || [])]),
        salience: Number(definition.authoringProfile?.salience || 60),
        kind: definition.kind || record.kind || "field",
        source: "local-vocabulary",
        record
      };
    }).filter((item) => item.id && item.term);
  }

  function requestedType(value, installedTypes) {
    if (typeof value === "object" && value?.term) return { requested: value.term, supplied: value };
    const requested = String(value || "");
    const local = installedTypes.find((item) => [item.id, item.term, item.label].includes(requested));
    if (local) return { requested, local };
    const name = leaf(requested);
    if (vocabulary.typeInfo(name)) return { requested, schema: name };
    return { requested, supplied: { term: requested, signals: {} } };
  }

  function schemaWeight(property, typeName) {
    const salience = vocabulary.propertySalience?.(property.name) || 40;
    const direct = property.domains.includes(typeName);
    const global = property.domains.includes("Thing");
    if (global) return 1;
    if (direct) return salience >= 75 ? 4 : salience >= 60 ? 3 : 2;
    return salience >= 75 ? 2 : 1;
  }

  function domainMatches(domains, type) {
    if (!domains.length) return true;
    return domains.some((domain) => domain === type.id || domain === type.term || domain === type.label || domain === leaf(type.term));
  }

  function roleScore(role, property) {
    const propertyWords = words(property.name || property.term);
    const propertyTokens = new Set(propertyWords.split(" "));
    const aliases = unique([propertyWords, ...(property.aliases || []).map(words)]);
    let best = 0;
    for (const alias of ROLE_ALIASES[role] || [words(role)]) {
      const normalized = words(alias);
      if (aliases.includes(normalized)) best = Math.max(best, normalized === words(role) ? 5 : 4);
      else if (normalized.split(" ").every((token) => propertyTokens.has(token))) best = Math.max(best, 3);
      else if (propertyWords.includes(normalized) || normalized.includes(propertyWords)) best = Math.max(best, 2);
    }
    return best;
  }

  function compactProperty(property) {
    return {
      term: property.term,
      name: property.name,
      domains: unique(property.domains),
      ranges: unique(property.ranges),
      aliases: unique(property.aliases),
      source: property.source
    };
  }

  function schemaRelationshipMaterializations(property) {
    // A mixed scalar/entity range already has a direct representation on the
    // parent (for example JobPosting.baseSalary). Do not reinterpret that
    // scalar as a child field merely because one alternate range is an entity.
    if ((property.ranges || []).some((range) => !vocabulary.isEntityType?.(range))) return [];
    const byRole = new Map();
    for (const targetType of property.entityRanges || []) {
      // Ontology reachability is not evidence of DOM containment. Only
      // reviewed relationship/target/leaf triples may invent a nested entity;
      // otherwise valid but implausible paths such as hasCertification ->
      // Certification.author would absorb unrelated nearby observations.
      const allowedProperties = RELATIONSHIP_MATERIALIZATION_RULES[property.name]?.[targetType] || [];
      if (!allowedProperties.length) continue;
      for (const targetProperty of vocabulary.propertiesFor(targetType)) {
        if (!allowedProperties.includes(targetProperty.name)) continue;
        if (targetProperty.supersededBy || GENERIC_RELATIONSHIP_PROPERTIES.has(targetProperty.name) || targetProperty.ranges.every((range) => vocabulary.isEntityType?.(range))) continue;
        for (const role of DEFAULT_ROLES) {
          const candidate = {
            term: `${SCHEMA}${targetProperty.name}`,
            name: targetProperty.name,
            ranges: [...targetProperty.ranges],
            source: "schema"
          };
          const score = roleScore(role, candidate);
          // Nested materialization is deliberately stricter than ordinary
          // field suggestion: the observed role must name the child property
          // exactly. This prevents generic titles from becoming, for example,
          // Product.colorSwatch -> ImageObject.headline.
          if (score < 5 || words(targetProperty.name) !== words(role)) continue;
          const compiled = {
            role,
            property: candidate.term,
            targetType: `${SCHEMA}${targetType}`,
            ranges: candidate.ranges,
            score,
            source: "schema"
          };
          if (!byRole.has(role)) byRole.set(role, []);
          byRole.get(role).push(compiled);
        }
      }
    }
    const materializations = [];
    for (const candidates of byRole.values()) {
      candidates.sort((left, right) => right.score - left.score || left.property.localeCompare(right.property) || left.targetType.localeCompare(right.targetType));
      const leading = candidates[0];
      const tied = candidates.some((candidate, index) => index > 0 && candidate.score === leading.score && (candidate.property !== leading.property || candidate.targetType !== leading.targetType));
      if (!tied) materializations.push(leading);
    }
    return materializations.sort((left, right) => left.role.localeCompare(right.role));
  }

  function canonicalType(value, installedTypes) {
    const requested = String(value || "");
    const local = installedTypes.find((type) => [type.id, type.term, type.label].includes(requested));
    if (local) return { term: local.term, name: local.id, source: "local-vocabulary" };
    const name = leaf(requested);
    if (vocabulary.typeInfo(name)) return { term: `${SCHEMA}${name}`, name, source: "schema" };
    return { term: requested, name: requested, source: "supplied" };
  }

  function compositionProperty(value, sourceType, installedProperties, relationshipOnly = false) {
    const requested = String(value || "");
    const local = installedProperties.find((property) => [property.id, property.term, property.name].includes(requested)
      && (!relationshipOnly || property.kind === "relationship")
      && domainMatches(property.domains, { id: sourceType.name, term: sourceType.term, label: leaf(sourceType.term) }));
    if (local) return local;
    if (sourceType.source !== "schema") return null;
    const property = vocabulary.property(sourceType.name, leaf(requested));
    if (!property || (relationshipOnly && !(property.ranges || []).some((range) => vocabulary.isEntityType?.(range)))) return null;
    return { id: property.name, term: `${SCHEMA}${property.name}`, name: property.name, ranges: [...property.ranges], source: "schema", kind: relationshipOnly ? "relationship" : "field" };
  }

  function compositionRules(compositions, installedTypes, installedProperties) {
    const byRootType = new Map();
    const propertyTerms = new Set();
    const typeTerms = new Set();
    let materializationCount = 0;
    let truncated = false;
    for (const composition of compositions) {
      const rootNode = composition?.nodes?.[composition.root];
      if (!rootNode || !Array.isArray(composition.edges)) continue;
      for (const rootTypeValue of rootNode.types || []) {
        const rootType = canonicalType(rootTypeValue, installedTypes);
        const rules = byRootType.get(rootType.term) || [];
        const edges = composition.edges.slice(0, MAX_COMPOSITION_EDGES);
        if (composition.edges.length > edges.length) truncated = true;
        const walk = (alias, sourceType, path, visited, pathWeight = Infinity) => {
          if (path.length >= MAX_RELATIONSHIP_DEPTH) {
            if (edges.some((candidate) => candidate.from === alias)) truncated = true;
            return;
          }
          for (const edge of edges.filter((candidate) => candidate.from === alias)) {
            if (visited.has(edge.to)) continue;
            const targetNode = composition.nodes?.[edge.to];
            // A multi-type node is a variant decision, not permission to pick
            // one nested type while compiling. It is handled by variant
            // classification rather than relationship materialization.
            if (!targetNode || targetNode.types?.length !== 1) continue;
            const targetType = canonicalType(targetNode.types[0], installedTypes);
            const relationship = compositionProperty(edge.property, sourceType, installedProperties, true);
            if (!relationship) continue;
            const step = { relationship: relationship.term, targetType: targetType.term };
            const nextPath = [...path, step];
            const weight = edge.expectation === "common" ? 4 : edge.expectation === "optional" ? 3 : 4;
            const nextWeight = Math.min(pathWeight, weight);
            const priorities = (composition.priorities?.[edge.to] || []).slice(0, MAX_PROPERTIES);
            if ((composition.priorities?.[edge.to] || []).length > priorities.length) truncated = true;
            for (const priority of priorities) {
              const property = compositionProperty(priority, targetType, installedProperties, false);
              if (!property || property.kind === "relationship") continue;
              if (materializationCount >= MAX_PROPERTIES) {
                truncated = true;
                continue;
              }
              rules.push({
                relationshipTerm: path[0]?.relationship || relationship.term,
                materializationWeight: nextWeight,
                materialization: {
                  role: property.name,
                  property: property.term,
                  targetType: targetType.term,
                  ranges: [...property.ranges],
                  score: 5,
                  source: "semantic-composition",
                  path: nextPath
                }
              });
              materializationCount += 1;
              propertyTerms.add(property.term);
              propertyTerms.add(relationship.term);
              for (const item of nextPath) typeTerms.add(item.targetType);
            }
            walk(edge.to, targetType, nextPath, new Set([...visited, edge.to]), nextWeight);
          }
        };
        walk(composition.root, rootType, [], new Set([composition.root]));
        byRootType.set(rootType.term, rules);
      }
    }
    return { byRootType, propertyTerms, typeTerms, materializationCount, truncated };
  }

  function mergeCompositionRules(type, rules = []) {
    for (const rule of rules) {
      let relationship = type.relationships.find((candidate) => candidate.term === rule.relationshipTerm);
      if (!relationship) {
        relationship = { term: rule.relationshipTerm, ranges: [], targetTypes: [], materializations: [], materializationWeight: 0, source: "semantic-composition" };
        type.relationships.push(relationship);
      }
      relationship.materializations ||= [];
      relationship.materializationWeight = Math.max(Number(relationship.materializationWeight || 0), rule.materializationWeight);
      const key = JSON.stringify([rule.materialization.role, rule.materialization.property, rule.materialization.path]);
      const existing = new Set(relationship.materializations.map((item) => JSON.stringify([item.role, item.property, item.path || [{ relationship: relationship.term, targetType: item.targetType }]])));
      if (!existing.has(key)) relationship.materializations.push(rule.materialization);
      type.signals[relationship.term] = Math.max(Number(type.signals[relationship.term] || 0), rule.materializationWeight);
    }
    type.relationships.sort((left, right) => left.term.localeCompare(right.term));
    for (const relationship of type.relationships) {
      relationship.materializations ||= [];
      relationship.materializations.sort((left, right) => left.role.localeCompare(right.role) || left.property.localeCompare(right.property));
    }
  }

  function compile(options = {}) {
    const roles = unique(options.roles?.length ? options.roles : DEFAULT_ROLES);
    const installedTypes = localTypes(options.libraryTypes);
    const installedProperties = localProperties(options.libraryProperties);
    const compositionInput = (Array.isArray(options.compositions) ? options.compositions : options.composition ? [options.composition] : []).filter(Boolean);
    const compositions = compositionInput.slice(0, MAX_COMPOSITIONS);
    const compositionTypes = compositions.flatMap((composition) => composition?.nodes?.[composition.root]?.types || []);
    const requestedInput = options.candidateTypes || options.types || (compositionTypes.length ? compositionTypes : ["Thing"]);
    const requested = requestedInput.slice(0, MAX_TYPES);
    let truncated = requestedInput.length > MAX_TYPES || compositionInput.length > MAX_COMPOSITIONS;
    const allProperties = new Map();

    const types = requested.map((entry) => {
      const resolved = requestedType(entry, installedTypes);
      if (resolved.schema) {
        const properties = vocabulary.propertiesFor(resolved.schema).filter((property) => !property.supersededBy);
        const signals = {};
        for (const property of properties) {
          const compiled = compactProperty({ ...property, term: `${SCHEMA}${property.name}`, source: "schema" });
          if (!allProperties.has(compiled.term) && allProperties.size >= MAX_PROPERTIES) {
            truncated = true;
            continue;
          }
          signals[compiled.term] = schemaWeight(property, resolved.schema);
          allProperties.set(compiled.term, compiled);
        }
        const relationships = vocabulary.relationshipProperties([resolved.schema]).map((property) => ({
          term: `${SCHEMA}${property.name}`,
          ranges: property.ranges.map((range) => `${SCHEMA}${range}`),
          targetTypes: property.entityRanges.map((range) => `${SCHEMA}${range}`),
          materializations: property.domains.includes(resolved.schema) ? schemaRelationshipMaterializations(property) : [],
          materializationWeight: property.domains.includes(resolved.schema) ? Math.max(3, schemaWeight(property, resolved.schema)) : 1,
          source: "schema"
        }));
        return { term: `${SCHEMA}${resolved.schema}`, label: resolved.schema, source: "schema", signals, relationships };
      }
      if (resolved.local) {
        const applicable = installedProperties.filter((property) => domainMatches(property.domains, resolved.local));
        const signals = {};
        const included = [];
        for (const property of applicable) {
          if (!allProperties.has(property.term) && allProperties.size >= MAX_PROPERTIES) {
            truncated = true;
            continue;
          }
          signals[property.term] = property.salience >= 75 ? 4 : property.salience >= 55 ? 3 : 2;
          allProperties.set(property.term, compactProperty(property));
          included.push(property);
        }
        const relationships = included.filter((property) => property.ranges.some((range) => installedTypes.some((type) => [type.id, type.term].includes(range)) || vocabulary.isEntityType?.(leaf(range))))
          .map((property) => ({ term: property.term, ranges: [...property.ranges], targetTypes: [...property.ranges], source: property.source }));
        return { term: resolved.local.term, label: resolved.local.label, source: "local-vocabulary", signals, relationships };
      }
      return { term: resolved.supplied.term, label: resolved.supplied.label || leaf(resolved.supplied.term), source: resolved.supplied.source || "supplied", signals: { ...(resolved.supplied.signals || {}) }, relationships: [...(resolved.supplied.relationships || [])] };
    });

    const authoredRules = compositionRules(compositions, installedTypes, installedProperties);
    truncated ||= authoredRules.truncated;
    for (const type of types) mergeCompositionRules(type, authoredRules.byRootType.get(type.term));

    const roleCandidates = {};
    for (const role of roles) {
      roleCandidates[role] = [...allProperties.values()].map((property) => ({ ...property, score: roleScore(role, property) }))
        .filter((property) => property.score > 0)
        .sort((left, right) => right.score - left.score || left.term.localeCompare(right.term))
        .slice(0, MAX_ROLE_CANDIDATES)
        .map((property) => ({ term: property.term, score: property.score, ranges: property.ranges, source: property.source }));
    }
    const provenance = {
      schemaCatalog: vocabulary.catalogVersion,
      schemaTypes: types.filter((type) => type.source === "schema").map((type) => type.term),
      localTypeIds: installedTypes.filter((type) => types.some((candidate) => candidate.term === type.term) || authoredRules.typeTerms.has(type.term)).map((type) => type.id),
      localPropertyIds: installedProperties.filter((property) => allProperties.has(property.term) || authoredRules.propertyTerms.has(property.term)).map((property) => property.id),
      compositionIds: compositions.map((composition) => composition.id).filter(Boolean)
    };
    const body = { format: FORMAT, version: VERSION, types, roleCandidates, provenance, bounded: { maxTypes: MAX_TYPES, maxProperties: MAX_PROPERTIES, maxMaterializations: MAX_PROPERTIES, maxCompositions: MAX_COMPOSITIONS, maxCompositionEdges: MAX_COMPOSITION_EDGES, maxRelationshipDepth: MAX_RELATIONSHIP_DEPTH, maxRoleCandidates: MAX_ROLE_CANDIDATES, typeCount: types.length, propertyCount: allProperties.size, materializationCount: authoredRules.materializationCount, truncated } };
    return Object.freeze({ ...body, digest: digest(body) });
  }

  return Object.freeze({ FORMAT, VERSION, DEFAULT_ROLES, MAX_TYPES, MAX_PROPERTIES, MAX_ROLE_CANDIDATES, MAX_COMPOSITIONS, MAX_COMPOSITION_EDGES, MAX_RELATIONSHIP_DEPTH, compile, digest });
});
