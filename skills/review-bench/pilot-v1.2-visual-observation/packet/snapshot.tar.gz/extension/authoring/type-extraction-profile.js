(function initializeTypeExtractionProfile(root, factory) {
  "use strict";
  const vocabulary = root.Site2JsonSchemaVocabulary || (typeof require === "function" ? require("../editor/schema-vocabulary") : null);
  const mappingEvidence = root.Site2JsonFieldMappingEvidence || (typeof require === "function" ? require("./field-mapping-evidence") : null);
  const api = factory(vocabulary, mappingEvidence);
  root.Site2JsonTypeExtractionProfile = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function typeExtractionProfileFactory(vocabulary, mappingEvidence) {
  "use strict";

  if (!vocabulary?.termsFor || !mappingEvidence?.analyze) throw new Error("Type extraction profiles require the vocabulary and shared evidence APIs.");

  const PROFILE_VERSION = 1;
  const MAX_PROPERTIES = 512;
  const SCALAR_TYPES = new Set(["Boolean", "Date", "DateTime", "Integer", "Number", "Text", "Time", "URL"]);
  const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  function localName(value) {
    return String(value || "").split(/[#:/.]/).filter(Boolean).at(-1) || "field";
  }

  function normalized(value) {
    return String(value || "").replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  }

  function aliases(name, definition = {}) {
    const authored = definition.authoringProfile || {};
    return [...new Set([
      localName(name),
      normalized(localName(name)),
      ...(definition.evidenceAliases || []),
      ...(authored.aliases || [])
    ].map((value) => String(value || "").trim()).filter(Boolean))];
  }

  function salience(term, schemaType) {
    const authored = term.authoringProfile || term.vocabularyTerm?.authoringProfile;
    if (Number.isInteger(authored?.salience)) return authored.salience;
    let score = vocabulary.propertySalience?.(term.name) || 40;
    if (term.supersededBy) score -= 40;
    return score;
  }

  function scalarCustomTerm(definition = {}) {
    if (definition.kind === "type") return false;
    if (definition.kind !== "relationship") return true;
    const ranges = definition.rangeIncludes || (definition.valueType ? [definition.valueType] : []);
    if (!ranges.length) return false;
    return ranges.some((range) => SCALAR_TYPES.has(range) || vocabulary.isDataType?.(range));
  }

  function appliesTo(definition, type, schemaType) {
    const domains = definition.domainIncludes || [];
    if (!domains.length) return true;
    return domains.some((domain) => domain === type || domain === schemaType || vocabulary.typeIs?.(schemaType, domain));
  }

  function profileProperty(term, schemaType, source = term.source || "schema", profileType = schemaType) {
    const definition = term.vocabularyTerm || term;
    const authoringProfile = clone(term.authoringProfile || definition.authoringProfile || null);
    const valueType = term.valueType || definition.valueType || definition.rangeIncludes?.[0] || term.ranges?.[0] || "Text";
    const baseAliases = aliases(term.name, { ...definition, authoringProfile: null });
    const baseCardinality = term.cardinality || definition.cardinality || "one";
    const baseNormalization = vocabulary.defaultPipeline(term, valueType === "URL" ? "url" : "text");
    const baseSalience = salience({ ...term, authoringProfile: null, vocabularyTerm: { ...definition, authoringProfile: null } }, schemaType);
    const cardinality = authoringProfile?.cardinality || baseCardinality;
    const domains = [...(term.domains || definition.domainIncludes || [])];
    const domainMatch = domains.includes(profileType) || domains.includes(schemaType)
      ? "direct"
      : domains.some((domain) => vocabulary.typeIs?.(schemaType, domain)) ? "inherited" : domains.length ? "declared-custom" : "unscoped";
    return {
      name: term.name,
      source,
      description: term.description || definition.description || "",
      domains,
      ranges: [...(term.ranges || definition.rangeIncludes || (valueType ? [valueType] : []))],
      valueType,
      cardinality,
      aliases: aliases(term.name, definition),
      negativeAliases: [...(authoringProfile?.negativeAliases || [])],
      expectedShapes: [...(authoringProfile?.expectedShapes || [])],
      units: [...(authoringProfile?.units || [])],
      examples: [...(authoringProfile?.examples || [])],
      normalization: authoringProfile?.normalization?.length
        ? [...authoringProfile.normalization]
        : vocabulary.defaultPipeline(term, valueType === "URL" ? "url" : "text"),
      salience: salience({ ...term, authoringProfile }, schemaType),
      ...(authoringProfile ? { authoringProfile } : {}),
      ...(authoringProfile ? { profileBaseline: {
        aliases: baseAliases,
        cardinality: baseCardinality,
        normalization: baseNormalization,
        salience: baseSalience
      } } : {}),
      catalogValidity: {
        authority: source === "schema" ? "schema.org" : "local-vocabulary",
        domain: { status: "valid", match: domainMatch, declared: domains },
        range: { status: "declared", declared: [...(term.ranges || definition.rangeIncludes || (valueType ? [valueType] : []))] },
        ...(term.relationship ? { relationship: clone(term.relationship) } : {})
      },
      semanticPrior: {
        salience: salience({ ...term, authoringProfile }, schemaType),
        cardinality: { value: cardinality, source: "site2json-authoring-default" }
      },
      ...(term.leafName ? { leafName: term.leafName } : {}),
      ...(term.vocabularyTerm ? { vocabularyTerm: clone(term.vocabularyTerm) } : {}),
      ...(term.librarySources ? { librarySources: clone(term.librarySources) } : {})
    };
  }

  function propertyKey(term) {
    const canonical = term.vocabularyTerm?.canonicalUri || "";
    return `${term.source}\u001f${canonical || term.name}`;
  }

  function build(type, {
    schemaType = type,
    libraryProperties = [],
    customTerms = {}
  } = {}) {
    const resolvedSchemaType = vocabulary.typeInfo(schemaType) ? schemaType : "Thing";
    const typeDefinition = vocabulary.typeInfo(resolvedSchemaType);
    const schema = vocabulary.termsFor(resolvedSchemaType)
      .filter((term) => !term.supersededBy)
      .map((term) => profileProperty(term, resolvedSchemaType, "schema", type));
    const installed = libraryProperties.map((term) => profileProperty(term, resolvedSchemaType, "extension", type));
    const local = Object.entries(customTerms)
      .filter(([, definition]) => scalarCustomTerm(definition) && appliesTo(definition, type, resolvedSchemaType))
      .map(([name, definition]) => profileProperty({ name, ...definition, vocabularyTerm: definition }, resolvedSchemaType, "extension", type));
    const byKey = new Map();
    for (const property of [...schema, ...installed, ...local]) {
      const key = propertyKey(property);
      if (!byKey.has(key)) byKey.set(key, property);
    }
    const compareProperties = (left, right) => right.salience - left.salience || left.name.localeCompare(right.name);
    const available = [...byKey.values()];
    const extensions = available.filter((property) => property.source === "extension").sort(compareProperties);
    const schemaProperties = available.filter((property) => property.source === "schema").sort(compareProperties);
    const properties = [...extensions.slice(0, MAX_PROPERTIES), ...schemaProperties.slice(0, Math.max(0, MAX_PROPERTIES - extensions.length))]
      .slice(0, MAX_PROPERTIES)
      .sort(compareProperties);
    return {
      version: PROFILE_VERSION,
      type,
      schemaType: resolvedSchemaType,
      label: localName(type),
      description: typeDefinition?.description || "Locally installed semantic type.",
      properties,
      summary: {
        total: properties.length,
        schema: properties.filter((property) => property.source === "schema").length,
        extension: properties.filter((property) => property.source === "extension").length,
        bounded: byKey.size > MAX_PROPERTIES
      }
    };
  }

  function suggestions(profile, candidate, {
    adapterPrefix = "",
    allowInferredExtensions = false,
    librarySuggestions = []
  } = {}) {
    if (!profile?.properties) return [];
    const libraryByName = new Map(librarySuggestions.map((term) => [term.name, term]));
    const ranked = profile.properties.map((property) => {
      const library = libraryByName.get(property.name);
      const suggestion = { ...clone(property), ...(library || {}) };
      const score = mappingEvidence.analyze(candidate, suggestion).score;
      return { ...suggestion, score, scoreSource: "shared-observed-evidence" };
    });
    if (allowInferredExtensions && adapterPrefix) {
      ranked.push(...vocabulary.suggestions(profile.schemaType, candidate?.evidence || {}, { adapterPrefix })
        .filter((term) => term.source === "extension")
        .map((term) => ({ ...term, score: mappingEvidence.analyze(candidate, term).score, scoreSource: "shared-observed-evidence" })));
    }
    return ranked.sort((left, right) => right.score - left.score || right.salience - left.salience || left.name.localeCompare(right.name));
  }

  return Object.freeze({ MAX_PROPERTIES, PROFILE_VERSION, build, suggestions });
});
