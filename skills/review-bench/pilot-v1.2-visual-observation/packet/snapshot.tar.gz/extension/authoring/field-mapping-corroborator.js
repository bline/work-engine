(function initializeFieldMappingCorroborator(root, factory) {
  "use strict";
  const mappingEvidence = root.Site2JsonFieldMappingEvidence || (typeof require === "function" ? require("./field-mapping-evidence") : null);
  const api = factory(mappingEvidence);
  root.Site2JsonFieldMappingCorroborator = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function fieldMappingCorroboratorFactory(mappingEvidence) {
  "use strict";

  if (!mappingEvidence?.analyze) throw new Error("Field mapping corroboration requires the shared observed-evidence analyzer.");

  const VERSION = 3;
  const MINIMUM_EVIDENCE_SCORE = 8;
  const CONFIDENCE = Object.freeze({ weak: 0, moderate: 1, strong: 2 });
  const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  function evaluatedCandidate(candidate, term) {
    const observed = mappingEvidence.analyze(candidate, term);
    if (!observed.compatible) return null;
    return {
      term,
      score: observed.score,
      adjustedScore: observed.score,
      minimum: MINIMUM_EVIDENCE_SCORE,
      signals: observed.signals,
      authoring: observed.authoring,
      evidenceVersion: mappingEvidence.VERSION
    };
  }

  function evaluate(candidate, suggestions = []) {
    return suggestions.map((term) => evaluatedCandidate(candidate, term)).filter(Boolean)
      .sort((left, right) => right.adjustedScore - left.adjustedScore
        || Number(right.term.semanticPrior?.salience || 0) - Number(left.term.semanticPrior?.salience || 0)
        || String(left.term.name).localeCompare(String(right.term.name)));
  }

  function corroborate(candidate, suggestions = []) {
    const evaluated = evaluate(candidate, suggestions);
    const winner = evaluated[0] || null;
    const runner = evaluated.find((item, index) => index > 0 && item.score >= item.minimum) || null;
    const margin = winner ? winner.adjustedScore - Math.max(0, runner?.adjustedScore || 0) : 0;
    const substantiveSignals = winner?.signals.filter((signal) => signal.kind !== "population") || [];
    const enoughSignals = (winner?.signals.length || 0) >= 2
      && (substantiveSignals.length >= 2 || substantiveSignals.some((signal) => signal.strength === "strong"));
    const clearsScore = Boolean(winner && winner.score >= winner.minimum);
    const clearsMargin = margin >= 2;
    const cardinalityConflict = winner?.authoring?.cardinality?.status === "conflict";
    let confidence = "weak";
    if (clearsScore && enoughSignals && clearsMargin && !cardinalityConflict) {
      confidence = margin >= 4 && winner.signals.filter((signal) => signal.strength === "strong").length >= 2 ? "strong" : "moderate";
    }
    const accepted = CONFIDENCE[confidence] >= CONFIDENCE.moderate;
    const report = {
      version: VERSION,
      status: accepted ? "accepted" : "uncertain",
      confidence,
      property: winner?.term.name || null,
      source: winner?.term.source || null,
      score: winner?.score || 0,
      adjustedScore: winner?.adjustedScore || 0,
      margin: Math.round(margin * 100) / 100,
      runnerUp: runner ? { property: runner.term.name, score: runner.score, adjustedScore: runner.adjustedScore } : null,
      signals: clone(winner?.signals || []),
      observedEvidence: winner ? { version: winner.evidenceVersion, score: winner.score, signals: clone(winner.signals) } : null,
      catalogValidity: clone(winner?.term.catalogValidity || null),
      semanticPrior: clone(winner?.term.semanticPrior || null),
      authoring: clone(winner?.authoring || null),
      reasons: [
        ...(!clearsScore ? [`The observed evidence did not clear the ${MINIMUM_EVIDENCE_SCORE}-point mapping threshold.`] : []),
        ...(!enoughSignals ? ["Fewer than two independent observed-evidence families support the mapping."] : []),
        ...(!clearsMargin ? ["The observed evidence does not have a safe margin over the runner-up."] : []),
        ...(cardinalityConflict ? ["Observed multiplicity conflicts with Site2JSON's editable cardinality default; this is an authoring-policy conflict, not a Schema.org constraint."] : [])
      ]
    };
    return {
      accepted,
      confidence,
      report,
      term: accepted && winner ? { ...clone(winner.term), corroboration: report } : null
    };
  }

  return Object.freeze({ CONFIDENCE, MINIMUM_EVIDENCE_SCORE, VERSION, corroborate, evaluate });
});
