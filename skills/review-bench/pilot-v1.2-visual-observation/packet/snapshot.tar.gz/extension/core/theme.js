"use strict";

(function initializeTheme(global) {
  const STORAGE_KEY = "site2json.appearance";
  const VALID_THEMES = new Set(["system", "light", "dark"]);

  function normalize(value) {
    return VALID_THEMES.has(value) ? value : "system";
  }

  function resolved(theme, media = global.matchMedia?.("(prefers-color-scheme: dark)")) {
    const preference = normalize(theme);
    return preference === "system" ? (media?.matches ? "dark" : "light") : preference;
  }

  function apply(theme) {
    const preference = normalize(theme);
    const root = global.document?.documentElement;
    if (!root) return preference;
    root.dataset.themePreference = preference;
    root.dataset.theme = resolved(preference);
    root.style.colorScheme = root.dataset.theme;
    if (typeof global.CustomEvent === "function") {
      global.dispatchEvent?.(new global.CustomEvent("site2json-theme-change", { detail: { preference, theme: root.dataset.theme } }));
    }
    return preference;
  }

  function cached() {
    try { return normalize(global.localStorage?.getItem(STORAGE_KEY)); }
    catch (_error) { return "system"; }
  }

  async function load() {
    let preference = cached();
    try {
      if (global.chrome?.storage?.local) {
        const stored = await global.chrome.storage.local.get(STORAGE_KEY);
        preference = normalize(stored?.[STORAGE_KEY] || preference);
      }
    } catch (_error) {
      // The synchronous cache and system preference remain a safe fallback.
    }
    try { global.localStorage?.setItem(STORAGE_KEY, preference); } catch (_error) {}
    apply(preference);
    return preference;
  }

  async function save(theme) {
    const preference = apply(theme);
    try { global.localStorage?.setItem(STORAGE_KEY, preference); } catch (_error) {}
    if (global.chrome?.storage?.local) await global.chrome.storage.local.set({ [STORAGE_KEY]: preference });
    return preference;
  }

  const media = global.matchMedia?.("(prefers-color-scheme: dark)");
  const onSystemChange = () => {
    if (normalize(global.document?.documentElement?.dataset?.themePreference) === "system") apply("system");
  };
  media?.addEventListener?.("change", onSystemChange);
  global.chrome?.storage?.onChanged?.addListener?.((changes, area) => {
    if (area === "local" && changes?.[STORAGE_KEY]) {
      const preference = normalize(changes[STORAGE_KEY].newValue);
      try { global.localStorage?.setItem(STORAGE_KEY, preference); } catch (_error) {}
      apply(preference);
    }
  });

  apply(cached());
  global.Site2JsonTheme = { STORAGE_KEY, normalize, resolved, apply, load, save };
  if (typeof module === "object" && module.exports) module.exports = global.Site2JsonTheme;
  load();
})(globalThis);
