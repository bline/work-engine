(function initializeSemanticLibraryService(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonSemanticLibrary = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticLibraryServiceFactory() {
  "use strict";

  const CONTRACT_VERSION = 1;
  const MAX_PAGE_SIZE = 100;
  const MAX_FACET_VALUES = 20;
  const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  class SemanticLibraryError extends Error {
    constructor(code, message, details = null) {
      super(message);
      this.name = "SemanticLibraryError";
      this.code = code;
      if (details !== null) this.details = clone(details);
    }
  }

  function fail(code, message, details = null) {
    throw new SemanticLibraryError(code, message, details);
  }

  function pageSize(value) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) return 25;
    return Math.max(1, Math.min(MAX_PAGE_SIZE, Math.floor(parsed)));
  }

  function decodeCursor(value) {
    if (!value) return 0;
    const match = /^v1:(\d+)$/.exec(String(value));
    if (!match) fail("INVALID_CURSOR", "The library continuation cursor is invalid.");
    return Number(match[1]);
  }

  function page(items, request = {}, total = items.length) {
    const start = decodeCursor(request.cursor);
    const size = pageSize(request.pageSize);
    const selected = items.slice(start, start + size);
    const nextOffset = start + selected.length;
    return {
      items: clone(selected),
      nextCursor: nextOffset < total ? `v1:${nextOffset}` : null,
      total
    };
  }

  function unsupported(feature) {
    return fail("NOT_SUPPORTED", `${feature} is not supported by this Semantic Library implementation.`, { feature });
  }

  function createLegacyToolboxService({ toolboxApi, bundleApi = null, storage = null, now = () => new Date().toISOString(), implementation = "legacy-toolbox" } = {}) {
    if (!toolboxApi?.load || !toolboxApi?.save || !toolboxApi?.normalize) {
      fail("INVALID_CONFIGURATION", "The legacy Semantic Library adapter requires the semantic toolbox API.");
    }

    let mutationTail = Promise.resolve();
    const memoryImports = new Map();
    const importRepository = storage?.semanticImports || Object.freeze({
      async commit(toolbox, manifest) {
        await write(toolbox);
        memoryImports.set(manifest.id, clone(manifest));
        return clone(manifest);
      },
      async get(id) { return clone(memoryImports.get(String(id || "")) || null); },
      async list() { return [...memoryImports.values()].map(clone).sort((left, right) => String(right.completedAt || "").localeCompare(String(left.completedAt || ""))); }
    });

    function mutate(operation) {
      const pending = mutationTail.then(operation, operation);
      mutationTail = pending.catch(() => undefined);
      return pending;
    }

    async function read() {
      return toolboxApi.load(storage || undefined);
    }

    async function write(value) {
      return toolboxApi.save(value, storage || undefined);
    }

    function targetRef(value) {
      if (!value || typeof value !== "object" || Array.isArray(value)) return null;
      const kind = String(value.kind || "");
      const id = String(value.id || "").trim();
      if (!["schemaType", "customType", "pattern", "vocabulary", "term", "property"].includes(kind) || !id) return null;
      return { kind, id };
    }

    function targetKey(value) {
      const normalized = targetRef(value);
      return normalized ? `${normalized.kind}\u001f${normalized.id}` : null;
    }

    function revisionOf(record) {
      return record ? Number(record.revision) || 1 : 0;
    }

    function assertRevision(kind, id, record, expectedRevision) {
      if (expectedRevision === undefined || expectedRevision === null) return;
      const actualRevision = revisionOf(record);
      if (Number(expectedRevision) !== actualRevision) {
        fail("REVISION_CONFLICT", `The ${kind} changed since it was opened.`, {
          id, expectedRevision: Number(expectedRevision), actualRevision
        });
      }
    }

    function stamp(candidate, existing) {
      const timestamp = now();
      candidate.revision = revisionOf(existing) + 1;
      candidate.createdAt = existing?.createdAt || timestamp;
      candidate.updatedAt = timestamp;
      return candidate;
    }

    async function getCapabilities() {
      return {
        contractVersion: CONTRACT_VERSION,
        implementation,
        features: {
          favorites: true,
          patterns: true,
          tags: true,
          sourceCategories: true,
          customTypes: true,
          collections: true,
          vocabularies: false,
          imports: true,
          provenance: true,
          portableBundles: Boolean(bundleApi?.create && bundleApi?.validate)
        },
        limits: { maxPageSize: MAX_PAGE_SIZE, maxFacetValues: MAX_FACET_VALUES, maxFavorites: 40 }
      };
    }

    async function listFavorites() {
      return clone((await read()).favorites);
    }

    async function addFavorite(request = {}) {
      return mutate(async () => {
        const current = await read();
        const next = toolboxApi.addFavorite(current, request.favorite, Number.isInteger(request.index) ? request.index : null);
        return clone((await write(next)).favorites);
      });
    }

    async function removeFavorite(request = {}) {
      return mutate(async () => {
        const current = await read();
        const next = toolboxApi.removeFavorite(current, request.favorite);
        return clone((await write(next)).favorites);
      });
    }

    function tagSummary(tag, toolbox) {
      const count = Object.values(toolbox.tagAssignments || {}).filter((ids) => ids.includes(tag.id)).length;
      return { ...clone(tag), assignmentCount: count };
    }

    async function listTags(request = {}) {
      const toolbox = await read();
      const terms = String(request.query || "").toLowerCase().split(/\s+/).filter(Boolean);
      const tags = Object.values(toolbox.tags || {})
        .filter((tag) => terms.every((term) => `${tag.label} ${tag.description || ""}`.toLowerCase().includes(term)))
        .sort((left, right) => left.label.localeCompare(right.label) || left.id.localeCompare(right.id))
        .map((tag) => tagSummary(tag, toolbox));
      return page(tags, request, tags.length);
    }

    async function getTag(id) {
      const tag = (await read()).tags?.[String(id || "")];
      if (!tag) fail("NOT_FOUND", `Semantic Library tag “${id}” was not found.`, { kind: "tag", id });
      return clone(tag);
    }

    async function getTags(request = {}) {
      const ids = Array.isArray(request.ids) ? request.ids.map(String) : [];
      const tags = (await read()).tags || {};
      return ids.map((id) => tags[id]).filter(Boolean).map(clone);
    }

    async function saveTag(request = {}) {
      return mutate(async () => {
        const current = await read();
        const candidate = clone(request.tag);
        const id = String(candidate?.id || "").trim();
        const label = String(candidate?.label || "").trim();
        if (!id || !label) fail("VALIDATION_ERROR", "A tag id and label are required.");
        const existing = current.tags?.[id] || null;
        assertRevision("tag", id, existing, request.expectedRevision);
        stamp(candidate, existing);
        const next = clone(current);
        next.tags[id] = candidate;
        const stored = await write(next);
        if (!stored.tags?.[id]) fail("VALIDATION_ERROR", "The Semantic Library tag is invalid.");
        return clone(stored.tags[id]);
      });
    }

    async function deleteTag(request = {}) {
      return mutate(async () => {
        const current = await read();
        const id = String(request.id || "");
        const existing = current.tags?.[id];
        if (!existing) fail("NOT_FOUND", `Semantic Library tag “${id}” was not found.`, { kind: "tag", id });
        assertRevision("tag", id, existing, request.expectedRevision);
        const next = clone(current);
        delete next.tags[id];
        for (const [key, ids] of Object.entries(next.tagAssignments || {})) {
          const remaining = ids.filter((tagId) => tagId !== id);
          if (remaining.length) next.tagAssignments[key] = remaining;
          else delete next.tagAssignments[key];
        }
        await write(next);
        return { id, deleted: true };
      });
    }

    async function getTagAssignments(request = {}) {
      const targets = Array.isArray(request.targets) ? request.targets.map(targetRef).filter(Boolean) : [];
      const assignments = (await read()).tagAssignments || {};
      return targets.map((target) => ({ target, tagIds: clone(assignments[targetKey(target)] || []) }));
    }

    async function assignTags(request = {}) {
      return mutate(async () => {
        const targets = Array.isArray(request.targets) ? request.targets.map(targetRef).filter(Boolean) : [];
        if (!targets.length) fail("VALIDATION_ERROR", "At least one Semantic Library item is required for tag assignment.");
        const current = await read();
        const tagIds = [...new Set((Array.isArray(request.tagIds) ? request.tagIds : []).map(String))];
        const missing = tagIds.filter((id) => !current.tags?.[id]);
        if (missing.length) fail("VALIDATION_ERROR", "One or more assigned tags do not exist.", { missingTagIds: missing });
        const mode = request.mode || "replace";
        if (!["add", "remove", "replace"].includes(mode)) fail("VALIDATION_ERROR", "Tag assignment mode must be add, remove, or replace.");
        const next = clone(current);
        next.tagAssignments ||= {};
        const results = [];
        for (const target of targets) {
          const key = targetKey(target);
          const present = new Set(next.tagAssignments[key] || []);
          if (mode === "replace") { present.clear(); for (const id of tagIds) present.add(id); }
          else if (mode === "add") for (const id of tagIds) present.add(id);
          else for (const id of tagIds) present.delete(id);
          const assigned = [...present];
          if (assigned.length) next.tagAssignments[key] = assigned;
          else delete next.tagAssignments[key];
          results.push({ target, tagIds: assigned });
        }
        await write(next);
        return clone(results);
      });
    }

    function collectionSummary(collection) {
      return {
        id: collection.id,
        label: collection.label,
        description: collection.description || "",
        memberCount: (collection.members || []).length,
        revision: revisionOf(collection),
        createdAt: collection.createdAt,
        updatedAt: collection.updatedAt
      };
    }

    async function listCollections(request = {}) {
      const terms = String(request.query || "").toLowerCase().split(/\s+/).filter(Boolean);
      const collections = Object.values((await read()).collections || {})
        .filter((collection) => terms.every((term) => `${collection.label} ${collection.description || ""}`.toLowerCase().includes(term)))
        .sort((left, right) => left.label.localeCompare(right.label) || left.id.localeCompare(right.id))
        .map(collectionSummary);
      return page(collections, request, collections.length);
    }

    async function getCollection(id) {
      const collection = (await read()).collections?.[String(id || "")];
      if (!collection) fail("NOT_FOUND", `Semantic Library collection “${id}” was not found.`, { kind: "collection", id });
      return clone(collection);
    }

    async function getCollections(request = {}) {
      const ids = Array.isArray(request.ids) ? request.ids.map(String) : [];
      const collections = (await read()).collections || {};
      return ids.map((id) => collections[id]).filter(Boolean).map(clone);
    }

    async function saveCollection(request = {}) {
      return mutate(async () => {
        const current = await read();
        const candidate = clone(request.collection);
        const id = String(candidate?.id || "").trim();
        const label = String(candidate?.label || "").trim();
        if (!id || !label) fail("VALIDATION_ERROR", "A collection id and label are required.");
        const existing = current.collections?.[id] || null;
        assertRevision("collection", id, existing, request.expectedRevision);
        stamp(candidate, existing);
        const next = clone(current);
        next.collections[id] = candidate;
        const stored = await write(next);
        if (!stored.collections?.[id]) fail("VALIDATION_ERROR", "The Semantic Library collection is invalid.");
        return clone(stored.collections[id]);
      });
    }

    async function updateCollectionMembers(request = {}) {
      return mutate(async () => {
        const current = await read();
        const id = String(request.id || "");
        const existing = current.collections?.[id];
        if (!existing) fail("NOT_FOUND", `Semantic Library collection “${id}” was not found.`, { kind: "collection", id });
        assertRevision("collection", id, existing, request.expectedRevision);
        const members = Array.isArray(request.members) ? request.members.map(targetRef).filter(Boolean) : [];
        const mode = request.mode || "replace";
        if (!["add", "remove", "replace"].includes(mode)) fail("VALIDATION_ERROR", "Collection membership mode must be add, remove, or replace.");
        const byKey = new Map((existing.members || []).map((member) => [targetKey(member), member]));
        if (mode === "replace") byKey.clear();
        if (mode === "remove") for (const member of members) byKey.delete(targetKey(member));
        else for (const member of members) byKey.set(targetKey(member), member);
        const candidate = stamp({ ...clone(existing), members: [...byKey.values()] }, existing);
        const next = clone(current);
        next.collections[id] = candidate;
        const stored = await write(next);
        return clone(stored.collections[id]);
      });
    }

    async function deleteCollection(request = {}) {
      return mutate(async () => {
        const current = await read();
        const id = String(request.id || "");
        const existing = current.collections?.[id];
        if (!existing) fail("NOT_FOUND", `Semantic Library collection “${id}” was not found.`, { kind: "collection", id });
        assertRevision("collection", id, existing, request.expectedRevision);
        const next = clone(current);
        delete next.collections[id];
        await write(next);
        return { id, deleted: true };
      });
    }

    function requestedKinds(request = {}) {
      return Array.isArray(request.kinds) && request.kinds.length ? request.kinds : ["pattern", "customType", "property"];
    }

    function matchingRecords(toolbox, request = {}) {
      const kinds = requestedKinds(request);
      const terms = String(request.query || "").toLowerCase().split(/\s+/).filter(Boolean);
      const records = [];
      if (kinds.includes("pattern")) for (const record of Object.values(toolbox.patterns || {})) records.push({ kind: "pattern", record });
      if (kinds.includes("customType")) for (const record of Object.values(toolbox.customTypes || {})) records.push({ kind: "customType", record });
      if (kinds.includes("property")) for (const record of Object.values(toolbox.properties || {})) records.push({ kind: "property", record });
      return records
        .filter(({ record }) => terms.every((term) => `${record.label} ${record.description || ""} ${record.termId || record.id} ${record.provenance?.canonicalUri || ""} ${record.provenance?.bundle?.label || ""}`.toLowerCase().includes(term)))
        .sort((left, right) => left.record.label.localeCompare(right.record.label) || left.record.id.localeCompare(right.record.id));
    }

    function collectionIdsForTarget(toolbox, target) {
      const key = targetKey(target);
      return Object.values(toolbox.collections || {})
        .filter((collection) => (collection.members || []).some((member) => targetKey(member) === key))
        .map((collection) => collection.id);
    }

    function sourceCategories(record) {
      return (Array.isArray(record.provenance?.categories) ? record.provenance.categories : []).map((category) => {
        if (category && typeof category === "object") {
          const id = String(category.id || category.label || "").trim();
          return id ? { id, label: String(category.label || id), source: clone(category.source || record.provenance?.source || null) } : null;
        }
        const id = String(category || "").trim();
        return id ? { id, label: id, source: clone(record.provenance?.source || null) } : null;
      }).filter(Boolean);
    }

    function commonSummary(kind, record, toolbox) {
      const target = { kind, id: record.id };
      return {
        kind,
        id: record.id,
        label: record.label,
        description: record.description || "",
        revision: Number(record.revision) || 1,
        source: clone(record.provenance?.source || { kind: "local", id: "semantic-library" }),
        bundle: clone(record.provenance?.bundle || null),
        sourceCategories: sourceCategories(record),
        tagIds: clone(toolbox.tagAssignments?.[targetKey(target)] || []),
        collectionIds: collectionIdsForTarget(toolbox, target)
      };
    }

    function patternSummary(pattern, toolbox) {
      return {
        ...commonSummary("pattern", pattern, toolbox),
        nodeCount: Object.keys(pattern.nodes || {}).length,
        relationshipCount: (pattern.edges || []).length
      };
    }

    function customTypeSummary(customType, toolbox) {
      return {
        ...commonSummary("customType", customType, toolbox),
        termId: customType.termId || customType.id,
        nodeCount: 1,
        relationshipCount: 0
      };
    }

    function propertySummary(property, toolbox) {
      return {
        ...commonSummary("property", property, toolbox),
        termId: property.termId || property.id,
        domainIncludes: clone(property.definition?.domainIncludes || []),
        rangeIncludes: clone(property.definition?.rangeIncludes || [])
      };
    }

    function recordSummary(candidate, toolbox) {
      if (candidate.kind === "customType") return customTypeSummary(candidate.record, toolbox);
      if (candidate.kind === "property") return propertySummary(candidate.record, toolbox);
      return patternSummary(candidate.record, toolbox);
    }

    function searchFacets(summaries, toolbox) {
      const tagCounts = new Map();
      const collectionCounts = new Map();
      const sourceCategoryCounts = new Map();
      const sourceCategoryLabels = new Map();
      const kindCounts = new Map();
      for (const summary of summaries) {
        kindCounts.set(summary.kind, (kindCounts.get(summary.kind) || 0) + 1);
        for (const id of summary.tagIds) tagCounts.set(id, (tagCounts.get(id) || 0) + 1);
        for (const id of summary.collectionIds) collectionCounts.set(id, (collectionCounts.get(id) || 0) + 1);
        for (const category of summary.sourceCategories) {
          sourceCategoryCounts.set(category.id, (sourceCategoryCounts.get(category.id) || 0) + 1);
          sourceCategoryLabels.set(category.id, category.label);
        }
      }
      const group = (items) => ({ items: items.slice(0, MAX_FACET_VALUES), total: items.length });
      const sortFacets = (items) => items.sort((left, right) => right.count - left.count || left.label.localeCompare(right.label));
      return {
        kinds: group(sortFacets([...kindCounts].map(([id, count]) => ({ id, label: id === "pattern" ? "Graph bundles" : id === "property" ? "Properties" : "Custom types", count })))),
        sources: group(sortFacets([...summaries.reduce((counts, summary) => {
          const id = String(summary.source?.id || summary.source?.kind || "local");
          const current = counts.get(id) || { id, label: summary.source?.label || (id === "local" ? "Local" : id), count: 0 };
          current.count += 1;
          counts.set(id, current);
          return counts;
        }, new Map()).values()])),
        tags: group(sortFacets([...tagCounts].map(([id, count]) => ({ id, label: toolbox.tags?.[id]?.label || id, count })))),
        collections: group(sortFacets([...collectionCounts].map(([id, count]) => ({ id, label: toolbox.collections?.[id]?.label || id, count })))),
        sourceCategories: group(sortFacets([...sourceCategoryCounts].map(([id, count]) => ({ id, label: sourceCategoryLabels.get(id) || id, count }))))
      };
    }

    async function search(request = {}) {
      const toolbox = await read();
      const pool = matchingRecords(toolbox, request).map((candidate) => recordSummary(candidate, toolbox));
      const filters = request.filters && typeof request.filters === "object" ? request.filters : request;
      const kindIds = [...new Set((Array.isArray(filters.kindIds) ? filters.kindIds : []).map(String))];
      const tagIds = [...new Set((Array.isArray(filters.tagIds) ? filters.tagIds : []).map(String))];
      const collectionIds = [...new Set((Array.isArray(filters.collectionIds) ? filters.collectionIds : []).map(String))];
      const sourceCategoryIds = [...new Set((Array.isArray(filters.sourceCategoryIds) ? filters.sourceCategoryIds : []).map(String))];
      const matches = pool.filter((summary) => (
        (!kindIds.length || kindIds.includes(summary.kind)) &&
        tagIds.every((id) => summary.tagIds.includes(id)) &&
        collectionIds.every((id) => summary.collectionIds.includes(id)) &&
        sourceCategoryIds.every((id) => summary.sourceCategories.some((category) => category.id === id))
      ));
      return { ...page(matches, request, matches.length), facets: searchFacets(pool, toolbox) };
    }

    async function listPatterns(request = {}) {
      return search({ ...request, kinds: ["pattern"] });
    }

    async function getPatterns(request = {}) {
      const ids = Array.isArray(request.ids) ? request.ids.map(String) : [];
      const patterns = (await read()).patterns || {};
      return ids.map((id) => patterns[id]).filter(Boolean).map(clone);
    }

    async function getPattern(id) {
      const pattern = (await read()).patterns?.[String(id || "")];
      if (!pattern) fail("NOT_FOUND", `Semantic pattern “${id}” was not found.`, { kind: "pattern", id });
      return clone(pattern);
    }

    async function listCustomTypes(request = {}) {
      return search({ ...request, kinds: ["customType"] });
    }

    async function getCustomTypes(request = {}) {
      const ids = Array.isArray(request.ids) ? request.ids.map(String) : [];
      const records = (await read()).customTypes || {};
      return ids.map((id) => records[id]).filter(Boolean).map(clone);
    }

    async function getCustomType(id) {
      const record = (await read()).customTypes?.[String(id || "")];
      if (!record) fail("NOT_FOUND", `Custom semantic type “${id}” was not found.`, { kind: "customType", id });
      return clone(record);
    }

    async function getTerms(request = {}) {
      const ids = Array.isArray(request.ids) ? request.ids.map(String) : [];
      const current = await read();
      return ids.map((id) => current.customTypes?.[id] || current.properties?.[id]).filter(Boolean).map(clone);
    }

    async function getProperty(id) {
      const record = (await read()).properties?.[String(id || "")];
      if (!record) fail("NOT_FOUND", `Semantic property “${id}” was not found.`, { kind: "property", id });
      return clone(record);
    }

    async function saveProperty(request = {}) {
      return mutate(async () => {
        const current = await read();
        const candidate = clone(request.property);
        if (!candidate || typeof candidate !== "object") fail("VALIDATION_ERROR", "A semantic property is required.");
        const existing = current.properties?.[String(candidate.id || "")] || null;
        assertRevision("property", candidate.id, existing, request.expectedRevision);
        stamp(candidate, existing);
        const next = toolboxApi.addProperty(current, candidate);
        const saved = next.properties?.[String(candidate.id || "")];
        if (!saved) fail("VALIDATION_ERROR", "The semantic property is invalid.");
        await write(next);
        return clone(saved);
      });
    }

    async function saveProperties(request = {}) {
      return mutate(async () => {
        const updates = Array.isArray(request.updates) ? request.updates : [];
        if (!updates.length || updates.length > 20) fail("VALIDATION_ERROR", "Between 1 and 20 semantic property updates are required.");
        const current = await read();
        const ids = updates.map((update) => String(update.property?.id || ""));
        if (ids.some((id) => !id) || new Set(ids).size !== ids.length) fail("VALIDATION_ERROR", "Semantic property updates require unique ids.");
        for (const update of updates) {
          const existing = current.properties?.[String(update.property.id)] || null;
          if (!existing) fail("NOT_FOUND", `Semantic property “${update.property.id}” was not found.`, { kind: "property", id: update.property.id });
          assertRevision("property", update.property.id, existing, update.expectedRevision);
        }
        let next = clone(current);
        const saved = [];
        for (const update of updates) {
          const existing = current.properties[String(update.property.id)];
          const candidate = stamp(clone(update.property), existing);
          next = toolboxApi.addProperty(next, candidate);
          const stored = next.properties?.[String(candidate.id)];
          if (!stored) fail("VALIDATION_ERROR", "A semantic property update is invalid.", { id: candidate.id });
          saved.push(clone(stored));
        }
        await write(next);
        return saved;
      });
    }

    async function deleteProperty(request = {}) {
      return mutate(async () => {
        const current = await read();
        const id = String(request.id || "");
        const existing = current.properties?.[id];
        if (!existing) fail("NOT_FOUND", `Semantic property “${id}” was not found.`, { kind: "property", id });
        assertRevision("property", id, existing, request.expectedRevision);
        const next = toolboxApi.removeProperty(current, id);
        const deletedTarget = { kind: "property", id };
        delete next.tagAssignments[targetKey(deletedTarget)];
        for (const [collectionId, collection] of Object.entries(next.collections || {})) {
          if (!(collection.members || []).some((member) => targetKey(member) === targetKey(deletedTarget))) continue;
          next.collections[collectionId] = stamp({ ...clone(collection), members: collection.members.filter((member) => targetKey(member) !== targetKey(deletedTarget)) }, collection);
        }
        await write(next);
        return { id, deleted: true };
      });
    }

    async function saveCustomType(request = {}) {
      return mutate(async () => {
        const current = await read();
        const candidate = clone(request.customType);
        if (!candidate || typeof candidate !== "object") fail("VALIDATION_ERROR", "A custom semantic type is required.");
        const existing = current.customTypes?.[String(candidate.id || "")] || null;
        assertRevision("custom type", candidate.id, existing, request.expectedRevision);
        stamp(candidate, existing);
        const next = toolboxApi.addCustomType(current, candidate);
        const saved = next.customTypes?.[String(candidate.id || "")];
        if (!saved) fail("VALIDATION_ERROR", "The custom semantic type is invalid.");
        await write(next);
        return clone(saved);
      });
    }

    async function deleteCustomType(request = {}) {
      return mutate(async () => {
        const current = await read();
        const id = String(request.id || "");
        const existing = current.customTypes?.[id];
        if (!existing) fail("NOT_FOUND", `Custom semantic type “${id}” was not found.`, { kind: "customType", id });
        assertRevision("custom type", id, existing, request.expectedRevision);
        const next = toolboxApi.removeCustomType(current, id);
        next.favorites = next.favorites.filter((favorite) => favorite.kind !== "customType" || favorite.id !== id);
        const deletedTarget = { kind: "customType", id };
        delete next.tagAssignments[targetKey(deletedTarget)];
        for (const [collectionId, collection] of Object.entries(next.collections || {})) {
          if (!(collection.members || []).some((member) => targetKey(member) === targetKey(deletedTarget))) continue;
          next.collections[collectionId] = stamp({
            ...clone(collection),
            members: collection.members.filter((member) => targetKey(member) !== targetKey(deletedTarget))
          }, collection);
        }
        await write(next);
        return { id, deleted: true };
      });
    }

    async function savePattern(request = {}) {
      return mutate(async () => {
        const current = await read();
        const candidate = clone(request.pattern);
        if (!candidate || typeof candidate !== "object") fail("VALIDATION_ERROR", "A semantic pattern is required.");
        const existing = current.patterns?.[String(candidate.id || "")] || null;
        if (request.expectedRevision !== undefined && request.expectedRevision !== null) {
          const actualRevision = existing ? Number(existing.revision) || 1 : 0;
          if (Number(request.expectedRevision) !== actualRevision) {
            fail("REVISION_CONFLICT", "The semantic pattern changed since it was opened.", {
              id: candidate.id, expectedRevision: Number(request.expectedRevision), actualRevision
            });
          }
        }
        const timestamp = now();
        candidate.revision = existing ? (Number(existing.revision) || 1) + 1 : 1;
        candidate.createdAt = existing?.createdAt || timestamp;
        candidate.updatedAt = timestamp;
        const next = toolboxApi.addPattern(current, candidate);
        const saved = next.patterns?.[String(candidate.id || "")];
        if (!saved) fail("VALIDATION_ERROR", "The semantic pattern is invalid.");
        await write(next);
        return clone(saved);
      });
    }

    async function deletePattern(request = {}) {
      return mutate(async () => {
        const current = await read();
        const id = String(request.id || "");
        const existing = current.patterns?.[id];
        if (!existing) fail("NOT_FOUND", `Semantic pattern “${id}” was not found.`, { kind: "pattern", id });
        if (request.expectedRevision !== undefined && request.expectedRevision !== null) {
          const actualRevision = Number(existing.revision) || 1;
          if (Number(request.expectedRevision) !== actualRevision) {
            fail("REVISION_CONFLICT", "The semantic pattern changed since it was opened.", {
              id, expectedRevision: Number(request.expectedRevision), actualRevision
            });
          }
        }
        const next = toolboxApi.removePattern(current, id);
        next.favorites = next.favorites.filter((favorite) => favorite.kind !== "pattern" || favorite.id !== id);
        const deletedTarget = { kind: "pattern", id };
        delete next.tagAssignments[targetKey(deletedTarget)];
        for (const [collectionId, collection] of Object.entries(next.collections || {})) {
          if (!(collection.members || []).some((member) => targetKey(member) === targetKey(deletedTarget))) continue;
          next.collections[collectionId] = stamp({
            ...clone(collection),
            members: collection.members.filter((member) => targetKey(member) !== targetKey(deletedTarget))
          }, collection);
        }
        await write(next);
        return { id, deleted: true };
      });
    }

    const importPlans = new Map();
    let importSequence = 0;

    function importId() {
      const uuid = globalThis.crypto?.randomUUID?.();
      return `import:${uuid || `${Date.now().toString(36)}-${(++importSequence).toString(36)}`}`;
    }

    function requireBundleApi() {
      if (!bundleApi?.create || !bundleApi?.validate) unsupported("Portable semantic bundles");
      return bundleApi;
    }

    function publicProvenance(value) {
      if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
      const result = clone(value);
      delete result.importId;
      delete result.bundle;
      delete result.revision;
      delete result.createdAt;
      delete result.updatedAt;
      return Object.keys(result).length ? result : undefined;
    }

    function portableType(record) {
      const provenance = publicProvenance(record.provenance);
      const canonicalUri = record.provenance?.canonicalUri || record.definition?.canonicalUri || "";
      return {
        termId: record.termId || record.id,
        label: record.label,
        description: record.description,
        ...(canonicalUri ? { canonicalUri } : {}),
        definition: clone(record.definition),
        ...(provenance ? { provenance } : {})
      };
    }

    function portablePattern(record) {
      const provenance = publicProvenance(record.provenance);
      return {
        patternId: record.patternId || record.id,
        label: record.label,
        description: record.description || "",
        root: record.root,
        nodes: clone(record.nodes),
        edges: clone(record.edges),
        terms: clone(record.terms || {}),
        ...(provenance ? { provenance } : {})
      };
    }

    function storedRecord(toolbox, reference) {
      if (reference.kind === "customType") return toolbox.customTypes?.[reference.id] || null;
      if (reference.kind === "property") return toolbox.properties?.[reference.id] || null;
      if (reference.kind === "pattern") return toolbox.patterns?.[reference.id] || null;
      return null;
    }

    async function exportBundle(request = {}) {
      const portable = requireBundleApi();
      const toolbox = await read();
      let manifest = null;
      let references = [];
      let label = String(request.name || "").trim();
      let description = String(request.description || "").trim();
      let importIdValue = String(request.importId || "").trim();
      const requestedTargets = (Array.isArray(request.targets) ? request.targets : request.target ? [request.target] : []).map(targetRef).filter(Boolean);
      if (!importIdValue && request.includeOwningPackage !== false && requestedTargets.length === 1) {
        importIdValue = String(storedRecord(toolbox, requestedTargets[0])?.provenance?.importId || "");
      }
      if (importIdValue) {
        manifest = await importRepository.get(importIdValue);
        if (!manifest) fail("NOT_FOUND", `Import “${importIdValue}” was not found.`, { kind: "importJob", id: importIdValue });
        references = (manifest.records || []).map(targetRef).filter(Boolean);
        label ||= manifest.label || "Imported semantic package";
        description ||= "A portable copy of a Semantic Library import package.";
      } else if (request.collectionId) {
        const collection = toolbox.collections?.[String(request.collectionId)];
        if (!collection) fail("NOT_FOUND", `Semantic Library collection “${request.collectionId}” was not found.`, { kind: "collection", id: request.collectionId });
        references = (collection.members || []).map(targetRef).filter(Boolean);
        label ||= collection.label;
        description ||= collection.description || "A portable Semantic Library collection.";
      } else {
        references = requestedTargets;
      }
      const unique = new Map(references.map((reference) => [targetKey(reference), reference]));
      const records = [...unique.values()].map((reference) => ({ reference, record: storedRecord(toolbox, reference) })).filter((entry) => entry.record);
      if (!records.length) fail("VALIDATION_ERROR", "Choose at least one custom type, property, or graph bundle to export.");
      label ||= records.length === 1 ? records[0].record.label : "Site2JSON semantic bundle";
      description ||= records.length === 1 ? records[0].record.description || "" : "Reusable semantic records exported from Site2JSON.";
      const provenance = manifest ? {
        source: "site2json-semantic-library",
        ...(manifest.requested ? { requested: clone(manifest.requested) } : {}),
        ...(manifest.snapshot ? { snapshot: clone(manifest.snapshot) } : {})
      } : undefined;
      return portable.create({
        name: label,
        description,
        createdAt: now(),
        ...(provenance ? { provenance } : {}),
        types: records.filter(({ reference }) => reference.kind === "customType").map(({ record }) => portableType(record)),
        properties: records.filter(({ reference }) => reference.kind === "property").map(({ record }) => portableType(record)),
        patterns: records.filter(({ reference }) => reference.kind === "pattern").map(({ record }) => portablePattern(record))
      });
    }

    async function planBundleImport(request = {}) {
      const portable = requireBundleApi();
      const bundle = portable.validate(request.bundle);
      const accepted = { customTypes: [], properties: [], patterns: [] };
      for (const [recordIndex, record] of bundle.records.types.entries()) {
        const candidate = {
          id: record.termId,
          termId: record.termId,
          label: record.label,
          description: record.description,
          definition: clone(record.definition),
          provenance: { ...clone(record.provenance || {}), ...(record.canonicalUri ? { canonicalUri: record.canonicalUri } : {}) }
        };
        const validation = toolboxApi.addCustomType(toolboxApi.normalize(null), candidate);
        const normalized = validation.customTypes?.[candidate.id];
        if (!normalized) fail("VALIDATION_ERROR", `Portable type ${recordIndex + 1} is not valid for this Semantic Library.`);
        accepted.customTypes.push(normalized);
      }
      for (const [recordIndex, record] of bundle.records.properties.entries()) {
        const candidate = {
          id: record.termId,
          termId: record.termId,
          label: record.label,
          description: record.description,
          definition: clone(record.definition),
          provenance: { ...clone(record.provenance || {}), ...(record.canonicalUri ? { canonicalUri: record.canonicalUri } : {}) }
        };
        const validation = toolboxApi.addProperty(toolboxApi.normalize(null), candidate);
        const normalized = validation.properties?.[candidate.id];
        if (!normalized) fail("VALIDATION_ERROR", `Portable property ${recordIndex + 1} is not valid for this Semantic Library.`);
        accepted.properties.push(normalized);
      }
      for (const [recordIndex, record] of bundle.records.patterns.entries()) {
        const candidate = {
          id: record.patternId,
          patternId: record.patternId,
          label: record.label,
          description: record.description,
          root: record.root,
          nodes: clone(record.nodes),
          edges: clone(record.edges),
          terms: clone(record.terms),
          provenance: clone(record.provenance || {})
        };
        const validation = toolboxApi.addPattern(toolboxApi.normalize(null), candidate);
        const normalized = validation.patterns?.[candidate.id];
        if (!normalized) fail("VALIDATION_ERROR", `Portable graph bundle ${recordIndex + 1} is not valid for this Semantic Library.`);
        accepted.patterns.push(normalized);
      }
      const planId = `bundle-plan:${Date.now().toString(36)}-${(++importSequence).toString(36)}`;
      const plan = {
        id: planId,
        source: "portable-bundle",
        label: bundle.bundle.name,
        requested: { kind: "portableBundle", format: bundle.format, version: bundle.version },
        snapshot: clone(bundle.bundle.provenance || null),
        records: accepted,
        counts: { customTypes: accepted.customTypes.length, properties: accepted.properties.length, patterns: accepted.patterns.length, skipped: 0, collisions: 0 },
        skipped: [],
        collisions: [],
        warnings: [],
        createdAt: now()
      };
      importPlans.set(planId, plan);
      return clone(plan);
    }

    async function planImport(request = {}) {
      const proposal = request.proposal;
      if (!proposal || proposal.source !== "semantic-catalog" || !proposal.records || typeof proposal.records !== "object") {
        fail("VALIDATION_ERROR", "A semantic catalog import proposal is required.");
      }
      const accepted = { customTypes: [], properties: [], patterns: [] };
      const skipped = [];
      const collisions = [];
      for (const [bucket, add] of [
        ["customTypes", toolboxApi.addCustomType],
        ["properties", toolboxApi.addProperty]
      ]) {
        const seen = new Map();
        for (const raw of Array.isArray(proposal.records[bucket]) ? proposal.records[bucket] : []) {
          const id = String(raw?.id || "").trim();
          if (!id) fail("VALIDATION_ERROR", `An imported ${bucket === "customTypes" ? "type" : "property"} is missing its identifier.`);
          const validation = add(toolboxApi.normalize(null), raw);
          const normalized = validation[bucket]?.[id];
          if (!normalized) fail("VALIDATION_ERROR", `Imported semantic record “${id}” is invalid.`);
          const termId = normalized.termId || id;
          const canonicalUri = normalized.provenance?.canonicalUri || normalized.definition?.canonicalUri || null;
          if (!/^https?:\/\/\S+$/.test(String(canonicalUri || ""))) {
            fail("VALIDATION_ERROR", `Imported semantic record “${termId}” needs a canonical HTTP(S) URI before it can enter a package.`);
          }
          if (seen.has(termId)) {
            const previous = seen.get(termId);
            if (previous.canonicalUri === canonicalUri && JSON.stringify(previous.record) === JSON.stringify(normalized)) {
              skipped.push({ kind: bucket === "customTypes" ? "customType" : "property", id: termId, reason: "duplicate-in-package" });
            } else {
              collisions.push({ kind: bucket === "customTypes" ? "customType" : "property", id: termId, reason: "conflicting-package-definition" });
            }
            continue;
          }
          seen.set(termId, { canonicalUri, record: normalized });
          accepted[bucket].push(normalized);
        }
      }
      const planId = `import-plan:${Date.now().toString(36)}-${(++importSequence).toString(36)}`;
      const plan = {
        id: planId,
        label: String(proposal.label || "Semantic catalog import"),
        requested: clone(proposal.requested || null),
        snapshot: clone(proposal.snapshot || null),
        records: accepted,
        counts: { customTypes: accepted.customTypes.length, properties: accepted.properties.length, skipped: skipped.length, collisions: collisions.length },
        skipped,
        collisions,
        warnings: clone(proposal.warnings || []),
        createdAt: now()
      };
      importPlans.set(planId, plan);
      return clone(plan);
    }

    async function startImport(request = {}) {
      const plan = importPlans.get(String(request.planId || ""));
      if (!plan) fail("NOT_FOUND", "The import preview expired. Preview the catalog item again.", { kind: "importPlan", id: request.planId });
      if (plan.collisions.length) fail("IMPORT_COLLISION", "The import has unresolved identifier collisions.", { collisions: plan.collisions });
      return mutate(async () => {
        let next = await read();
        const id = importId();
        const startedAt = now();
        const importedRecords = [];
        const bundle = { id, label: plan.label, requested: clone(plan.requested), snapshot: clone(plan.snapshot) };
        for (const [index, record] of plan.records.customTypes.entries()) {
          const termId = record.termId || record.id;
          const candidate = stamp({
            ...clone(record),
            id: `${id}:customType:${index + 1}`,
            termId,
            provenance: { ...clone(record.provenance || {}), importId: id, bundle }
          }, null);
          next = toolboxApi.addCustomType(next, candidate);
          const saved = next.customTypes[candidate.id];
          importedRecords.push({ kind: "customType", id: saved.id, termId: saved.termId, revision: revisionOf(saved), canonicalUri: saved.provenance?.canonicalUri || null });
        }
        for (const [index, record] of plan.records.properties.entries()) {
          const termId = record.termId || record.id;
          const candidate = stamp({
            ...clone(record),
            id: `${id}:property:${index + 1}`,
            termId,
            provenance: { ...clone(record.provenance || {}), importId: id, bundle }
          }, null);
          next = toolboxApi.addProperty(next, candidate);
          const saved = next.properties[candidate.id];
          importedRecords.push({ kind: "property", id: saved.id, termId: saved.termId, revision: revisionOf(saved), canonicalUri: saved.provenance?.canonicalUri || null });
        }
        for (const [index, record] of (plan.records.patterns || []).entries()) {
          const patternId = record.patternId || record.id;
          const candidate = stamp({
            ...clone(record),
            id: `${id}:pattern:${index + 1}`,
            patternId,
            provenance: { ...clone(record.provenance || {}), importId: id, bundle }
          }, null);
          next = toolboxApi.addPattern(next, candidate);
          const saved = next.patterns[candidate.id];
          importedRecords.push({ kind: "pattern", id: saved.id, patternId: saved.patternId, revision: revisionOf(saved) });
        }
        const job = {
          id,
          planId: plan.id,
          label: plan.label,
          requested: clone(plan.requested),
          snapshot: clone(plan.snapshot),
          status: "completed",
          counts: clone(plan.counts),
          records: importedRecords,
          skipped: clone(plan.skipped),
          warnings: clone(plan.warnings),
          startedAt,
          completedAt: now()
        };
        await importRepository.commit(next, job);
        importPlans.delete(plan.id);
        return clone(job);
      });
    }

    async function getImportJob(id) {
      const job = await importRepository.get(String(id || ""));
      if (!job) fail("NOT_FOUND", `Import job “${id}” was not found.`, { kind: "importJob", id });
      return clone(job);
    }

    function importSummary(manifest) {
      return {
        id: manifest.id,
        label: manifest.label,
        status: manifest.status,
        requested: clone(manifest.requested || null),
        snapshot: clone(manifest.snapshot || null),
        counts: clone(manifest.counts || {}),
        startedAt: manifest.startedAt,
        completedAt: manifest.completedAt,
        undo: clone(manifest.undo || null)
      };
    }

    async function listImports(request = {}) {
      const manifests = (await importRepository.list()).map(importSummary);
      return page(manifests, request, manifests.length);
    }

    function removeImportedTargets(toolbox, targets) {
      const next = clone(toolbox);
      const targetKeys = new Set(targets.map(targetKey));
      for (const target of targets) {
        if (target.kind === "customType") delete next.customTypes[target.id];
        else if (target.kind === "property") delete next.properties[target.id];
        else if (target.kind === "pattern") delete next.patterns[target.id];
        delete next.tagAssignments[targetKey(target)];
      }
      next.favorites = next.favorites.filter((favorite) => !targetKeys.has(targetKey(favorite)));
      for (const [collectionId, collection] of Object.entries(next.collections || {})) {
        const members = (collection.members || []).filter((member) => !targetKeys.has(targetKey(member)));
        if (members.length === (collection.members || []).length) continue;
        next.collections[collectionId] = stamp({ ...clone(collection), members }, collection);
      }
      return toolboxApi.normalize(next);
    }

    async function undoImport(request = {}) {
      const id = String(request.id || request.importId || "");
      if (!id) fail("VALIDATION_ERROR", "An import identifier is required.");
      return mutate(async () => {
        const manifest = await importRepository.get(id);
        if (!manifest) fail("NOT_FOUND", `Import “${id}” was not found.`, { kind: "importJob", id });
        if (manifest.status === "undone") fail("ALREADY_UNDONE", "This import has already been undone.", { id });
        if (manifest.status !== "completed") fail("NOT_CANCELLABLE", "Only completed imports can be undone.", { id, status: manifest.status });
        const current = await read();
        const removable = [];
        const retained = [];
        const missing = [];
        for (const reference of manifest.records || []) {
          const record = storedRecord(current, reference);
          if (!record) missing.push({ kind: reference.kind, id: reference.id, reason: "already-missing" });
          else if (record.provenance?.importId !== id || revisionOf(record) !== Number(reference.revision || 1)) {
            retained.push({ kind: reference.kind, id: reference.id, reason: "modified-after-import" });
          } else removable.push({ kind: reference.kind, id: reference.id });
        }
        const next = removeImportedTargets(current, removable);
        const undone = {
          ...clone(manifest),
          status: "undone",
          undo: { completedAt: now(), removed: removable, retained, missing }
        };
        await importRepository.commit(next, undone);
        return clone(undone);
      });
    }

    async function cancelImport(request = {}) {
      const job = await importRepository.get(String(request.id || request.jobId || ""));
      if (!job) fail("NOT_FOUND", "The import job was not found.", { kind: "importJob", id: request.id || request.jobId });
      if (job.status === "completed") fail("NOT_CANCELLABLE", "Completed imports cannot be cancelled.");
      fail("NOT_CANCELLABLE", "This import is not cancellable.");
    }

    return Object.freeze({
      getCapabilities,
      listFavorites,
      addFavorite,
      removeFavorite,
      listTags,
      getTag,
      getTags,
      saveTag,
      deleteTag,
      getTagAssignments,
      assignTags,
      search,
      listPatterns,
      getPatterns,
      getPattern,
      savePattern,
      deletePattern,
      listCustomTypes,
      getCustomTypes,
      getCustomType,
      saveCustomType,
      deleteCustomType,
      getTerms,
      getProperty,
      saveProperty,
      saveProperties,
      deleteProperty,
      getVocabulary: async () => unsupported("Vocabulary packages"),
      listVocabularyTerms: async () => unsupported("Vocabulary packages"),
      resolveSubgraph: async () => unsupported("Semantic subgraph resolution"),
      listCollections,
      getCollection,
      getCollections,
      saveCollection,
      updateCollectionMembers,
      deleteCollection,
      planImport,
      planBundleImport,
      startImport,
      exportBundle,
      getImportJob,
      listImports,
      undoImport,
      cancelImport
    });
  }

  function createIndexedDbToolboxService({ toolboxApi, bundleApi = null, indexedDbApi, indexedDB, legacyStorage = null, dbName, now } = {}) {
    if (!indexedDbApi?.createStorage) fail("INVALID_CONFIGURATION", "The IndexedDB Semantic Library service requires the IndexedDB repository API.");
    const storage = indexedDbApi.createStorage({ indexedDB, toolboxApi, legacyStorage, ...(dbName ? { dbName } : {}), ...(now ? { now } : {}) });
    return createLegacyToolboxService({ toolboxApi, bundleApi, storage, ...(now ? { now } : {}), implementation: "indexeddb-toolbox" });
  }

  return Object.freeze({ CONTRACT_VERSION, MAX_FACET_VALUES, MAX_PAGE_SIZE, SemanticLibraryError, createIndexedDbToolboxService, createLegacyToolboxService });
});
