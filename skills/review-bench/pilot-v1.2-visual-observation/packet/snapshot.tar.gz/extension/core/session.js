(function initializeSession(root, factory) {
  "use strict";
  const utils = root.Site2JsonUtils || (typeof require === "function" ? require("./utils") : null);
  const api = factory(utils);
  root.Site2JsonSession = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function sessionFactory(utils) {
  "use strict";

  const SESSION_VERSION = 1;
  const FIDELITY = { summary: 1, full: 2 };

  function includedBlocks(document) {
    return document.blocks.filter((block) => block.role === "primary" || block.role === "collection");
  }

  function entitiesIn(document) {
    return includedBlocks(document).flatMap((block) => block.entities.map((entity) => ({ entity, block })));
  }

  function entityKey(entity, adapter = null) {
    const identity = entity.identifier || entity.url || entity["@id"] || null;
    return identity && adapter ? `${adapter}:${identity}` : identity;
  }

  function sessionAdapter(session) {
    return session?.adapter || documents(session)[0]?.extraction.adapter || null;
  }

  function sessionAdapterVersion(session) {
    return session?.adapterVersion ?? documents(session)[0]?.extraction.adapterVersion ?? null;
  }

  function create(document) {
    return addDocument({
      sessionVersion: SESSION_VERSION,
      state: "collecting",
      startedAt: document.extraction.extractedAt,
      lastExtractionAt: document.extraction.extractedAt,
      adapter: document.extraction.adapter,
      adapterVersion: document.extraction.adapterVersion ?? null,
      collectionKey: document.extraction.collectionKey,
      snapshots: {}
    }, document);
  }

  function primaryEnrichmentMatches(session, document) {
    const blocks = includedBlocks(document);
    if (blocks.length === 0 || blocks.some((block) => block.role !== "primary")) return false;
    const existingKeys = new Set(documents(session).flatMap((snapshot) => (
      entitiesIn(snapshot).map(({ entity }) => entityKey(entity, snapshot.extraction.adapter)).filter(Boolean)
    )));
    const incomingKeys = entitiesIn(document).map(({ entity }) => entityKey(entity, document.extraction.adapter)).filter(Boolean);
    return incomingKeys.length > 0 && incomingKeys.every((key) => existingKeys.has(key));
  }

  function sameCollection(session, document) {
    if (!session || !document?.extraction) return false;
    const adapter = sessionAdapter(session);
    if (adapter && adapter !== document.extraction.adapter) return false;
    const adapterVersion = sessionAdapterVersion(session);
    if (adapterVersion !== null && document.extraction.adapterVersion !== undefined && adapterVersion !== document.extraction.adapterVersion) return false;
    if (documents(session).length === 0) return session.collectionKey === document.extraction.collectionKey;
    if (session.collectionKey !== null && session.collectionKey === document.extraction.collectionKey) return true;
    return primaryEnrichmentMatches(session, document);
  }

  function addDocument(session, document) {
    if (!session) return create(document);
    if (isFinished(session)) throw new Error("This extraction session is already finished.");
    if (!sameCollection(session, document)) throw new Error("This page belongs to a different collection.");
    const next = utils.clone(session);
    if (next.adapterVersion === undefined) next.adapterVersion = document.extraction.adapterVersion ?? null;
    next.snapshots[document.extraction.snapshotKey] = utils.clone(document);
    next.lastExtractionAt = document.extraction.extractedAt;
    return next;
  }

  function documents(session) {
    return Object.values(session?.snapshots || {}).sort((a, b) => {
      const positionA = a.extraction.logicalPosition ?? Number.MAX_SAFE_INTEGER;
      const positionB = b.extraction.logicalPosition ?? Number.MAX_SAFE_INTEGER;
      return positionA - positionB || a.extraction.extractedAt.localeCompare(b.extraction.extractedAt);
    });
  }

  function summarize(session) {
    const snapshots = documents(session);
    const keys = new Set();
    let observations = 0;
    for (const document of snapshots) {
      for (const { entity } of entitiesIn(document)) {
        const key = entityKey(entity, document.extraction.adapter);
        if (key) keys.add(key);
        observations += 1;
      }
    }
    const positions = snapshots.map((document) => document.extraction.logicalPosition).filter(Number.isSafeInteger);
    const missingPositions = [];
    if (positions.length > 0) {
      const captured = new Set(positions);
      for (let position = 1; position <= Math.max(...positions); position += 1) {
        if (!captured.has(position)) missingPositions.push(position);
      }
    }
    return {
      snapshots: snapshots.length,
      positions,
      missingPositions,
      entityObservations: observations,
      uniqueEntities: keys.size,
      duplicateObservations: observations - keys.size
    };
  }

  function mergeValue(existing, incoming, preferIncoming) {
    if (existing === undefined || existing === null || existing === "") return utils.clone(incoming);
    if (incoming === undefined || incoming === null || incoming === "") return utils.clone(existing);
    if (Array.isArray(existing) && Array.isArray(incoming)) {
      const values = [...existing, ...incoming];
      return values.filter((value, index) => values.findIndex((candidate) => JSON.stringify(candidate) === JSON.stringify(value)) === index);
    }
    if (typeof existing === "object" && typeof incoming === "object" && !Array.isArray(existing) && !Array.isArray(incoming)) {
      const result = {};
      for (const key of new Set([...Object.keys(existing), ...Object.keys(incoming)])) {
        result[key] = mergeValue(existing[key], incoming[key], preferIncoming);
      }
      return result;
    }
    return utils.clone(preferIncoming ? incoming : existing);
  }

  function mergeResult(session) {
    const merged = new Map();
    const warnings = [];
    for (const document of documents(session)) {
      for (const { entity, block } of entitiesIn(document)) {
        const key = entityKey(entity, document.extraction.adapter);
        if (!key) {
          warnings.push({ code: "entity.identityMissing", extractionId: document.extraction.id });
          continue;
        }
        const current = merged.get(key);
        const observation = { extractionId: document.extraction.id, fidelity: block.fidelity, extractedAt: document.extraction.extractedAt };
        if (!current) {
          merged.set(key, { entity: utils.clone(entity), fidelity: block.fidelity, extractedAt: document.extraction.extractedAt, observations: [observation] });
          continue;
        }
        const incomingRank = FIDELITY[block.fidelity];
        const currentRank = FIDELITY[current.fidelity];
        const preferIncoming = incomingRank > currentRank || (incomingRank === currentRank && document.extraction.extractedAt >= current.extractedAt);
        if (JSON.stringify(current.entity) !== JSON.stringify(entity) && incomingRank === currentRank) {
          warnings.push({ code: "entity.equalFidelityConflict", entity: key, extractionId: document.extraction.id });
        }
        current.entity = mergeValue(current.entity, entity, preferIncoming);
        if (preferIncoming) {
          current.fidelity = block.fidelity;
          current.extractedAt = document.extraction.extractedAt;
        }
        current.observations.push(observation);
      }
    }
    return {
      entities: [...merged.values()].map((entry) => ({
        ...entry.entity,
        "site2json:observations": entry.observations
      })),
      warnings
    };
  }

  function merge(session) {
    return mergeResult(session).entities;
  }

  function isFinished(session) {
    return session?.state === "finished" && typeof session.finishedAt === "string";
  }

  function finish(session, finishedAt = new Date().toISOString()) {
    if (!session || documents(session).length === 0) throw new Error("The extraction session has no pages.");
    if (isFinished(session)) return utils.clone(session);
    if (Number.isNaN(Date.parse(finishedAt))) throw new Error("The finish timestamp is invalid.");
    const next = utils.clone(session);
    next.state = "finished";
    next.finishedAt = finishedAt;
    return next;
  }

  function isStale(session, now = new Date(), maximumAgeHours = 4) {
    const started = Date.parse(session?.startedAt);
    return Number.isFinite(started) && now.valueOf() - started > maximumAgeHours * 60 * 60 * 1000;
  }

  return { SESSION_VERSION, addDocument, create, documents, entityKey, finish, isFinished, isStale, merge, mergeResult, sameCollection, summarize, sessionAdapterVersion };
});
