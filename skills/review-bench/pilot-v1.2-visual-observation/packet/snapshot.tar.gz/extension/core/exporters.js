(function initializeExporters(root, factory) {
  "use strict";
  const utils = root.Site2JsonUtils || (typeof require === "function" ? require("./utils") : null);
  const api = factory(utils);
  root.Site2JsonExporters = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function exportersFactory(utils) {
  "use strict";

  const BASE_CONTEXT = {
    "@vocab": "https://schema.org/",
    site2json: "https://site2json.dev/ns/"
  };
  const FORMAT_VERSION = 1;

  function includedBlocks(document) {
    return document.blocks.filter((block) => block.role === "primary" || block.role === "collection");
  }

  function graphFor(document) {
    const blocks = includedBlocks(document);
    const entities = blocks.flatMap((block) => block.entities);
    const context = { ...BASE_CONTEXT, ...(document.context || {}) };
    if (document.extraction.pageType === "SearchResultsPage") {
      return {
        "@context": context,
        "@type": "SearchResultsPage",
        url: document.extraction.pageUrl,
        name: document.extraction.pageTitle,
        mainEntity: {
          "@type": "ItemList",
          numberOfItems: entities.length,
          itemListElement: utils.clone(entities)
        }
      };
    }
    return {
      "@context": context,
      "@type": document.extraction.pageType || "WebPage",
      url: document.extraction.pageUrl,
      name: document.extraction.pageTitle,
      mainEntity: entities.length === 1 ? utils.clone(entities[0]) : utils.clone(entities)
    };
  }

  function jsonLd(document) {
    return { extraction: { formatVersion: FORMAT_VERSION, ...utils.clone(document.extraction) }, graph: graphFor(document) };
  }

  function sessionState(session, sessionApi) {
    const merged = sessionApi.mergeResult(session);
    const documents = sessionApi.documents(session);
    const summary = sessionApi.summarize(session);
    const extractionWarnings = documents.flatMap((document) => document.extraction.warnings.map((warning) => ({
      ...warning,
      extractionId: document.extraction.id
    })));
    return {
      documents,
      entities: merged.entities,
      summary,
      warnings: [...extractionWarnings, ...merged.warnings]
    };
  }

  function sessionExtraction(session, state) {
    const first = state.documents[0];
    return {
      formatVersion: FORMAT_VERSION,
      source: "site2json-session",
      extractedAt: session.finishedAt || session.lastExtractionAt,
      adapter: first.extraction.adapter,
      adapterVersion: session.adapterVersion ?? first.extraction.adapterVersion ?? null,
      extractorVersions: [...new Set(state.documents.map((document) => document.extraction.extractorVersion).filter(Boolean))],
      startedAt: session.startedAt,
      finishedAt: session.finishedAt || null,
      collectionKey: session.collectionKey,
      snapshots: state.documents.map((document) => utils.clone(document.extraction)),
      summary: {
        snapshots: state.summary.snapshots,
        positions: state.summary.positions,
        missingPositions: state.summary.missingPositions,
        entityObservations: state.summary.entityObservations,
        duplicateObservations: state.summary.duplicateObservations,
        entitiesExported: state.entities.length,
        warnings: state.warnings.length
      },
      warnings: utils.clone(state.warnings)
    };
  }

  function jsonLdSession(session, sessionApi) {
    const state = sessionState(session, sessionApi);
    if (state.documents.length === 0) throw new Error("The extraction session has no pages.");
    const first = state.documents[0];
    const context = Object.assign({}, BASE_CONTEXT, ...state.documents.map((document) => document.context || {}));
    return {
      extraction: sessionExtraction(session, state),
      graph: {
        "@context": context,
        "@type": first.extraction.pageType === "SearchResultsPage" ? "SearchResultsPage" : "CollectionPage",
        url: first.extraction.pageUrl,
        name: first.extraction.pageTitle,
        mainEntity: {
          "@type": "ItemList",
          numberOfItems: state.entities.length,
          itemListElement: utils.clone(state.entities)
        }
      }
    };
  }

  function compactName(value) {
    return value
      .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
      .replace(/[^A-Za-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "")
      .toLowerCase();
  }

  function present(value) {
    return value !== undefined && value !== null && value !== "";
  }

  function add(result, key, value) {
    if (key && present(value)) result[key] = utils.clone(value);
  }

  function compactEntity(entity, options = {}) {
    const result = {};
    const job = entity["@type"] === "JobPosting";
    const consumed = new Set(["@type", "@id"]);
    if (job) {
      add(result, "id", entity.identifier || entity["@id"]);
      add(result, "url", entity.url || entity["@id"]);
      add(result, "title", entity.title || entity.name);
      add(result, "description_excerpt", entity.description);
      add(result, "skills", entity.skills);
      for (const key of ["identifier", "url", "title", "name", "description", "skills"]) consumed.add(key);
    } else {
      add(result, "id", entity["@id"]);
    }

    const extensions = new Map();
    for (const [key, value] of Object.entries(entity)) {
      if (consumed.has(key) || !present(value)) continue;
      const colon = key.indexOf(":");
      if (colon < 0) {
        add(result, job ? compactName(key) : key.replace(/^@/, ""), value);
        continue;
      }
      const prefix = key.slice(0, colon);
      if (prefix === "site2json") continue;
      const projected = compactName(key.slice(colon + 1));
      if (!extensions.has(projected)) extensions.set(projected, []);
      extensions.get(projected).push({ key, value });
    }

    for (const [projected, candidates] of extensions) {
      if (candidates.length === 1 && !Object.hasOwn(result, projected)) {
        add(result, projected, candidates[0].value);
      } else {
        result.extension_fields ||= {};
        for (const candidate of candidates) result.extension_fields[candidate.key] = utils.clone(candidate.value);
      }
    }

    if (options.includeRawText) add(result, "raw_text", entity["site2json:rawText"]);
    if (!Array.isArray(options.fields)) return result;
    const selected = new Set(options.fields);
    return Object.fromEntries(Object.entries(result).filter(([key]) => selected.has(key)));
  }

  function compact(document, options = {}) {
    const blocks = includedBlocks(document);
    const entities = blocks.flatMap((block) => block.entities);
    const key = entities.length > 0 && entities.every((entity) => entity["@type"] === "JobPosting") ? "jobs" : "entities";
    return {
      format_version: FORMAT_VERSION,
      source: "site2json",
      extracted_at: document.extraction.extractedAt,
      adapter: document.extraction.adapter,
      adapter_version: document.extraction.adapterVersion ?? null,
      extractor_version: document.extraction.extractorVersion ?? null,
      page: {
        url: document.extraction.pageUrl,
        title: document.extraction.pageTitle,
        type: document.extraction.pageType,
        collection_key: document.extraction.collectionKey,
        logical_position: document.extraction.logicalPosition,
        ...utils.clone(document.extraction.page || {})
      },
      summary: {
        entities_exported: entities.length,
        complete: document.extraction.quality.complete,
        required_field_coverage: document.extraction.quality.requiredFieldCoverage,
        monitored_field_coverage: document.extraction.quality.monitoredFieldCoverage,
        warnings: document.extraction.warnings.length
      },
      warnings: utils.clone(document.extraction.warnings),
      [key]: entities.map((entity) => compactEntity(entity, options))
    };
  }

  function compactSession(session, sessionApi, options = {}) {
    const state = sessionState(session, sessionApi);
    if (state.documents.length === 0) throw new Error("The extraction session has no pages.");
    const first = state.documents[0];
    const entities = state.entities;
    const key = entities.length > 0 && entities.every((entity) => entity["@type"] === "JobPosting") ? "jobs" : "entities";
    return {
      format_version: FORMAT_VERSION,
      source: "site2json-session",
      extracted_at: session.finishedAt || session.lastExtractionAt,
      adapter: first.extraction.adapter,
      adapter_version: session.adapterVersion ?? first.extraction.adapterVersion ?? null,
      extractor_versions: [...new Set(state.documents.map((document) => document.extraction.extractorVersion).filter(Boolean))],
      page: {
        url: first.extraction.pageUrl,
        title: first.extraction.pageTitle,
        type: first.extraction.pageType,
        collection_key: session.collectionKey,
        ...utils.clone(first.extraction.page || {})
      },
      session: {
        started_at: session.startedAt,
        finished_at: session.finishedAt || null,
        positions: state.summary.positions,
        missing_positions: state.summary.missingPositions,
        entity_observations: state.summary.entityObservations,
        duplicate_observations: state.summary.duplicateObservations
      },
      summary: { entities_exported: entities.length, snapshots: state.summary.snapshots, warnings: state.warnings.length },
      warnings: utils.clone(state.warnings),
      [key]: entities.map((entity) => compactEntity(entity, options))
    };
  }

  return { FORMAT_VERSION, compact, compactEntity, compactSession, graphFor, jsonLd, jsonLdSession };
});
