(function initializeModel(root, factory) {
  "use strict";
  const utils = root.Site2JsonUtils || (typeof require === "function" ? require("./utils") : null);
  const api = factory(utils);
  root.Site2JsonModel = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function modelFactory(utils) {
  "use strict";

  const EXTRACTOR_VERSION = "0.1.0";
  const ROLES = new Set(["primary", "collection", "related", "navigation"]);
  const FIDELITIES = new Set(["summary", "full"]);

  function validateBlock(block) {
    if (!block || typeof block !== "object") throw new Error("An adapter returned an invalid block.");
    if (!ROLES.has(block.role)) throw new Error(`Unknown block role: ${block.role}`);
    if (!FIDELITIES.has(block.fidelity)) throw new Error(`Unknown block fidelity: ${block.fidelity}`);
    if (!Array.isArray(block.entities)) throw new Error("A block must contain an entities array.");
    if (block.arity !== "one" && block.arity !== "many") throw new Error(`Unknown block arity: ${block.arity}`);
    if (block.arity === "one" && block.entities.length > 1) throw new Error("A block with arity one returned multiple entities.");
    for (const key of ["require", "monitor"]) {
      if (block[key] !== undefined && (!Array.isArray(block[key]) || block[key].some((field) => typeof field !== "string"))) {
        throw new Error(`A block's ${key} value must be an array of field paths.`);
      }
    }
    for (const entity of block.entities) {
      if (!entity || typeof entity !== "object" || typeof entity["@type"] !== "string") {
        throw new Error("Every extracted entity must have an @type.");
      }
    }
    return block;
  }

  function fieldValue(entity, path) {
    return path.split(".").reduce((value, segment) => value?.[segment], entity);
  }

  function fieldPresent(entity, path) {
    const value = fieldValue(entity, path);
    if (value === null || value === undefined || value === "") return false;
    if (Array.isArray(value)) return value.length > 0;
    return true;
  }

  function fieldCoverage(blocks, key) {
    let possible = 0;
    let present = 0;
    for (const block of blocks) {
      for (const entity of block.entities) {
        for (const field of block[key] || []) {
          possible += 1;
          if (fieldPresent(entity, field)) present += 1;
        }
      }
    }
    return possible === 0 ? 1 : present / possible;
  }

  function requiredFieldCoverage(blocks) {
    return fieldCoverage(blocks, "require");
  }

  function monitoredFieldCoverage(blocks) {
    return fieldCoverage(blocks, "monitor");
  }

  function assemble(adapter, observation, pageUrl) {
    const blocks = observation.blocks.map(validateBlock);
    const requiredCoverage = requiredFieldCoverage(blocks);
    const monitoredCoverage = monitoredFieldCoverage(blocks);
    const warnings = [...(observation.warnings || [])];
    for (const block of blocks) {
      const fields = new Set([...(block.require || []), ...(block.monitor || [])]);
      for (const field of fields) {
        const count = block.entities.filter((entity) => !fieldPresent(entity, field)).length;
        if (count > 0) warnings.push({ code: "field.missing", field, count, block: block.id });
      }
    }

    const extractedAt = observation.extractedAt || new Date().toISOString();
    const extraction = {
      id: utils.identifier("r"),
      extractorVersion: EXTRACTOR_VERSION,
      adapter: adapter.id,
      adapterVersion: adapter.version,
      adapterSource: adapter.source || "bundled",
      extractedAt,
      pageUrl,
      pageTitle: observation.pageTitle || "",
      pageType: observation.pageType,
      language: observation.language || null,
      page: utils.clone(observation.page || {}),
      collectionKey: observation.collectionKey === undefined ? pageUrl : observation.collectionKey,
      snapshotKey: observation.snapshotKey || pageUrl,
      logicalPosition: observation.logicalPosition ?? null,
      blocks: blocks.map((block) => ({
        id: block.id,
        entity: block.entity,
        role: block.role,
        arity: block.arity,
        fidelity: block.fidelity,
        count: block.entities.length
      })),
      warnings,
      quality: {
        complete: requiredCoverage === 1,
        requiredFieldCoverage: Number(requiredCoverage.toFixed(4)),
        monitoredFieldCoverage: Number(monitoredCoverage.toFixed(4))
      }
    };

    return {
      extraction,
      context: utils.clone({ ...(adapter.context || {}), ...(observation.context || {}) }),
      blocks: utils.clone(blocks)
    };
  }

  function extract(adapters, document, location) {
    const pageUrl = location.href;
    const adapter = adapters.find((candidate) => candidate.match(new URL(pageUrl), document));
    if (!adapter) return { ok: false, reason: "unsupported" };
    const observation = adapter.extract(document, new URL(pageUrl));
    if (!observation || observation.blocks.every((block) => block.entities.length === 0)) {
      return { ok: false, reason: "empty", adapter: adapter.id, warnings: utils.clone(observation?.warnings || []) };
    }
    return { ok: true, document: assemble(adapter, observation, pageUrl) };
  }

  return { EXTRACTOR_VERSION, assemble, extract, fieldPresent, monitoredFieldCoverage, requiredFieldCoverage, validateBlock };
});
