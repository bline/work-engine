(function initializeUtils(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonUtils = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function utilsFactory() {
  "use strict";

  function clone(value) {
    if (typeof structuredClone === "function") return structuredClone(value);
    return JSON.parse(JSON.stringify(value));
  }

  function normalizeText(value) {
    return (value || "").replace(/\s+/g, " ").trim();
  }

  function textOf(node) {
    return normalizeText(node?.innerText || node?.textContent || "");
  }

  function canonicalUrl(rawUrl, baseUrl, { stripQuery = false } = {}) {
    try {
      const url = new URL(rawUrl, baseUrl);
      url.hash = "";
      if (stripQuery) url.search = "";
      if (url.pathname !== "/") url.pathname = url.pathname.replace(/\/$/, "");
      return url.href;
    } catch {
      return null;
    }
  }

  function identifier(prefix = "r") {
    const random = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    return `${prefix}_${random}`;
  }

  return { canonicalUrl, clone, identifier, normalizeText, textOf };
});
