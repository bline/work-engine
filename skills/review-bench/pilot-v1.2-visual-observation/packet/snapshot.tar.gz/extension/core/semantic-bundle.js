(function initializeSemanticBundle(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonSemanticBundle = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticBundleFactory() {
  "use strict";

  const FORMAT = "site2json-semantic-bundle";
  const VERSION = 1;
  const SCHEMA_ID = "https://site2json.dev/schemas/semantic-bundle-v1.schema.json";
  const FILE_EXTENSION = ".site2json.json.gz";
  const MAX_COMPRESSED_BYTES = 16 * 1024 * 1024;
  const MAX_DECOMPRESSED_BYTES = 64 * 1024 * 1024;
  const MAX_RECORDS = 25000;
  const MAX_DEPTH = 40;
  const encoder = new TextEncoder();
  const decoder = new TextDecoder("utf-8", { fatal: true });

  class SemanticBundleError extends Error {
    constructor(code, message, details = null) {
      super(message);
      this.name = "SemanticBundleError";
      this.code = code;
      if (details !== null) this.details = details;
    }
  }

  function fail(code, message, details = null) {
    throw new SemanticBundleError(code, message, details);
  }

  function ownObject(value, path) {
    if (!value || typeof value !== "object" || Array.isArray(value)) fail("VALIDATION_ERROR", `${path} must be an object.`);
    return value;
  }

  function cleanString(value, path, { required = false, max = 500 } = {}) {
    if (value === undefined || value === null) {
      if (required) fail("VALIDATION_ERROR", `${path} is required.`);
      return "";
    }
    if (typeof value !== "string") fail("VALIDATION_ERROR", `${path} must be a string.`);
    const result = value.trim();
    if (required && !result) fail("VALIDATION_ERROR", `${path} cannot be empty.`);
    if (result.length > max) fail("VALIDATION_ERROR", `${path} cannot exceed ${max} characters.`);
    return result;
  }

  function assertOnly(value, allowed, path) {
    for (const key of Object.keys(value)) {
      if (["__proto__", "prototype", "constructor"].includes(key)) fail("UNSAFE_CONTENT", `${path} contains a reserved property name.`, { path, key });
      if (!allowed.has(key)) fail("VALIDATION_ERROR", `${path}.${key} is not part of semantic bundle version ${VERSION}.`, { path, key });
    }
  }

  function safeJson(value, path = "value", depth = 0) {
    if (depth > MAX_DEPTH) fail("UNSAFE_CONTENT", `${path} is nested too deeply.`);
    if (value === null || typeof value === "string" || typeof value === "boolean") return value;
    if (typeof value === "number") {
      if (!Number.isFinite(value)) fail("UNSAFE_CONTENT", `${path} contains a non-finite number.`);
      return value;
    }
    if (Array.isArray(value)) return value.map((item, index) => safeJson(item, `${path}[${index}]`, depth + 1));
    if (!value || typeof value !== "object") fail("UNSAFE_CONTENT", `${path} contains an unsupported value.`);
    const result = {};
    for (const [key, item] of Object.entries(value)) {
      if (["__proto__", "prototype", "constructor"].includes(key)) fail("UNSAFE_CONTENT", `${path} contains a reserved property name.`, { path, key });
      result[key] = safeJson(item, `${path}.${key}`, depth + 1);
    }
    return result;
  }

  function optionalUri(value, path) {
    if (value === undefined || value === null || value === "") return "";
    const uri = cleanString(value, path, { max: 2048 });
    if (!/^https?:\/\/\S+$/i.test(uri)) fail("VALIDATION_ERROR", `${path} must be an HTTP(S) URI.`);
    return uri;
  }

  function normalizeTerm(value, index, kind) {
    const path = `records.${kind === "type" ? "types" : "properties"}[${index}]`;
    const source = ownObject(value, path);
    assertOnly(source, new Set(["termId", "label", "description", "canonicalUri", "definition", "provenance"]), path);
    const termId = cleanString(source.termId, `${path}.termId`, { required: true, max: 500 });
    const label = cleanString(source.label, `${path}.label`, { required: true, max: 160 });
    const description = cleanString(source.description, `${path}.description`, { required: true, max: 500 });
    const definition = safeJson(ownObject(source.definition, `${path}.definition`), `${path}.definition`);
    const expectedKind = kind === "type" ? "type" : "relationship";
    if (definition.kind !== expectedKind) fail("VALIDATION_ERROR", `${path}.definition.kind must be “${expectedKind}”.`);
    cleanString(definition.description, `${path}.definition.description`, { required: true, max: 500 });
    if (kind === "type" && definition.valueType !== termId) {
      fail("VALIDATION_ERROR", `${path}.definition.valueType must match termId.`);
    }
    const canonicalUri = optionalUri(source.canonicalUri || definition.canonicalUri, `${path}.canonicalUri`);
    const normalized = { termId, label, description, ...(canonicalUri ? { canonicalUri } : {}), definition };
    if (source.provenance !== undefined) normalized.provenance = safeJson(ownObject(source.provenance, `${path}.provenance`), `${path}.provenance`);
    return normalized;
  }

  function normalizePattern(value, index) {
    const path = `records.patterns[${index}]`;
    const source = ownObject(value, path);
    assertOnly(source, new Set(["patternId", "label", "description", "root", "nodes", "edges", "terms", "provenance"]), path);
    const patternId = cleanString(source.patternId, `${path}.patternId`, { required: true, max: 500 });
    const label = cleanString(source.label, `${path}.label`, { required: true, max: 160 });
    const description = cleanString(source.description, `${path}.description`, { max: 500 });
    const rootId = cleanString(source.root, `${path}.root`, { required: true, max: 500 });
    const nodes = safeJson(ownObject(source.nodes, `${path}.nodes`), `${path}.nodes`);
    if (!nodes[rootId]) fail("VALIDATION_ERROR", `${path}.root must identify a node in the pattern.`);
    if (!Array.isArray(source.edges)) fail("VALIDATION_ERROR", `${path}.edges must be an array.`);
    const edges = safeJson(source.edges, `${path}.edges`);
    for (const [edgeIndex, edge] of edges.entries()) {
      if (!edge || typeof edge !== "object" || Array.isArray(edge)) fail("VALIDATION_ERROR", `${path}.edges[${edgeIndex}] must be an object.`);
      if (!nodes[edge.from] || !nodes[edge.to]) fail("VALIDATION_ERROR", `${path}.edges[${edgeIndex}] must connect nodes in this pattern.`);
      cleanString(edge.property, `${path}.edges[${edgeIndex}].property`, { required: true, max: 500 });
    }
    const terms = source.terms === undefined ? {} : safeJson(ownObject(source.terms, `${path}.terms`), `${path}.terms`);
    const normalized = { patternId, label, description, root: rootId, nodes, edges, terms };
    if (source.provenance !== undefined) normalized.provenance = safeJson(ownObject(source.provenance, `${path}.provenance`), `${path}.provenance`);
    return normalized;
  }

  function validate(value) {
    const source = ownObject(value, "bundle");
    assertOnly(source, new Set(["$schema", "format", "version", "bundle", "records"]), "bundle");
    if (source.$schema !== SCHEMA_ID) fail("UNSUPPORTED_SCHEMA", `This bundle uses an unsupported schema: ${source.$schema || "missing"}`);
    if (source.format !== FORMAT) fail("UNSUPPORTED_FORMAT", `Expected format “${FORMAT}”.`);
    if (source.version !== VERSION) fail("UNSUPPORTED_VERSION", `Semantic bundle version ${source.version} is not supported.`, { supported: [VERSION] });

    const metadata = ownObject(source.bundle, "bundle.bundle");
    assertOnly(metadata, new Set(["name", "description", "createdAt", "provenance"]), "bundle.bundle");
    const name = cleanString(metadata.name, "bundle.bundle.name", { required: true, max: 160 });
    const description = cleanString(metadata.description, "bundle.bundle.description", { max: 500 });
    const createdAt = cleanString(metadata.createdAt, "bundle.bundle.createdAt", { required: true, max: 40 });
    if (!Number.isFinite(Date.parse(createdAt))) fail("VALIDATION_ERROR", "bundle.bundle.createdAt must be an ISO-compatible date-time.");
    const normalizedMetadata = { name, ...(description ? { description } : {}), createdAt };
    if (metadata.provenance !== undefined) normalizedMetadata.provenance = safeJson(ownObject(metadata.provenance, "bundle.bundle.provenance"), "bundle.bundle.provenance");

    const records = ownObject(source.records, "bundle.records");
    assertOnly(records, new Set(["types", "properties", "patterns"]), "bundle.records");
    for (const bucket of ["types", "properties", "patterns"]) {
      if (!Array.isArray(records[bucket])) fail("VALIDATION_ERROR", `bundle.records.${bucket} must be an array.`);
    }
    const total = records.types.length + records.properties.length + records.patterns.length;
    if (!total) fail("VALIDATION_ERROR", "A semantic bundle must contain at least one record.");
    if (total > MAX_RECORDS) fail("RECORD_LIMIT", `This bundle contains ${total} records; the limit is ${MAX_RECORDS}.`, { total, limit: MAX_RECORDS });
    const types = records.types.map((record, index) => normalizeTerm(record, index, "type"));
    const properties = records.properties.map((record, index) => normalizeTerm(record, index, "property"));
    const patterns = records.patterns.map(normalizePattern);
    const identities = new Set();
    for (const [kind, list, key] of [["type", types, "termId"], ["property", properties, "termId"], ["pattern", patterns, "patternId"]]) {
      for (const record of list) {
        const identity = `${kind}\u001f${record[key]}`;
        if (identities.has(identity)) fail("DUPLICATE_RECORD", `The bundle contains more than one ${kind} named “${record[key]}”.`, { kind, id: record[key] });
        identities.add(identity);
      }
    }
    return {
      $schema: SCHEMA_ID,
      format: FORMAT,
      version: VERSION,
      bundle: normalizedMetadata,
      records: { types, properties, patterns }
    };
  }

  function create({ name, description = "", createdAt = new Date().toISOString(), provenance, types = [], properties = [], patterns = [] } = {}) {
    return validate({
      $schema: SCHEMA_ID,
      format: FORMAT,
      version: VERSION,
      bundle: { name, ...(description ? { description } : {}), createdAt, ...(provenance ? { provenance } : {}) },
      records: { types, properties, patterns }
    });
  }

  function serialize(value) {
    return `${JSON.stringify(validate(value), null, 2)}\n`;
  }

  function bytes(value) {
    if (value instanceof Uint8Array) return value;
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    fail("INVALID_INPUT", "Semantic bundle input must be bytes.");
  }

  async function collect(stream, limit, code) {
    const reader = stream.getReader();
    const chunks = [];
    let length = 0;
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        const chunk = bytes(value);
        length += chunk.byteLength;
        if (length > limit) {
          await reader.cancel();
          fail(code, `Semantic bundle data exceeds the ${Math.floor(limit / (1024 * 1024))} MiB safety limit.`, { limit });
        }
        chunks.push(chunk);
      }
    } catch (error) {
      if (error instanceof SemanticBundleError) throw error;
      fail("INVALID_GZIP", `The compressed semantic bundle could not be read: ${error.message}`);
    }
    const output = new Uint8Array(length);
    let offset = 0;
    for (const chunk of chunks) { output.set(chunk, offset); offset += chunk.byteLength; }
    return output;
  }

  async function encode(value, options = {}) {
    const input = encoder.encode(serialize(value));
    if (input.byteLength > (options.maxDecompressedBytes || MAX_DECOMPRESSED_BYTES)) {
      fail("DECOMPRESSED_SIZE_LIMIT", "The semantic bundle is too large to export.", { size: input.byteLength });
    }
    const CompressionStreamImpl = options.CompressionStreamImpl || globalThis.CompressionStream;
    if (!CompressionStreamImpl) fail("COMPRESSION_UNAVAILABLE", "This browser cannot create gzip semantic bundles.");
    const compressed = await collect(new Blob([input]).stream().pipeThrough(new CompressionStreamImpl("gzip")), options.maxCompressedBytes || MAX_COMPRESSED_BYTES, "COMPRESSED_SIZE_LIMIT");
    return compressed;
  }

  async function decode(value, options = {}) {
    const input = bytes(value);
    const maxCompressedBytes = options.maxCompressedBytes || MAX_COMPRESSED_BYTES;
    const maxDecompressedBytes = options.maxDecompressedBytes || MAX_DECOMPRESSED_BYTES;
    if (input.byteLength > maxCompressedBytes) fail("COMPRESSED_SIZE_LIMIT", "The compressed semantic bundle is too large to import.", { size: input.byteLength, limit: maxCompressedBytes });
    let decoded = input;
    if (input[0] === 0x1f && input[1] === 0x8b) {
      const DecompressionStreamImpl = options.DecompressionStreamImpl || globalThis.DecompressionStream;
      if (!DecompressionStreamImpl) fail("DECOMPRESSION_UNAVAILABLE", "This browser cannot read gzip semantic bundles.");
      decoded = await collect(new Blob([input]).stream().pipeThrough(new DecompressionStreamImpl("gzip")), maxDecompressedBytes, "DECOMPRESSED_SIZE_LIMIT");
    } else if (input.byteLength > maxDecompressedBytes) {
      fail("DECOMPRESSED_SIZE_LIMIT", "The semantic bundle is too large to import.", { size: input.byteLength, limit: maxDecompressedBytes });
    }
    let parsed;
    try {
      parsed = JSON.parse(decoder.decode(decoded));
    } catch (error) {
      fail("INVALID_JSON", `The semantic bundle is not valid UTF-8 JSON: ${error.message}`);
    }
    return validate(parsed);
  }

  function suggestedFilename(name) {
    const stem = String(name || "semantic-bundle").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "semantic-bundle";
    return `${stem}${FILE_EXTENSION}`;
  }

  return Object.freeze({
    FILE_EXTENSION,
    FORMAT,
    MAX_COMPRESSED_BYTES,
    MAX_DECOMPRESSED_BYTES,
    MAX_RECORDS,
    SCHEMA_ID,
    VERSION,
    SemanticBundleError,
    create,
    decode,
    encode,
    serialize,
    suggestedFilename,
    validate
  });
});
