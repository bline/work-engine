export const VERSION = 1;
export const VALUE_SHAPES = Object.freeze(["text", "url", "date", "datetime", "integer", "number", "boolean", "currency", "percentage"]);
const SHAPE_SET = new Set(VALUE_SHAPES);
export const MAX_LIST_ITEMS = 40;
export const MAX_ITEM_LENGTH = 160;

function corrections(value) {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value)) throw new TypeError("Correction provenance must be a list.");
  return value.slice(-20).map((item) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) throw new TypeError("Correction provenance entries must be objects.");
    const operation = String(item.operation || "");
    if (!new Set(["add-alias", "add-negative-alias"]).has(operation)) throw new TypeError("Correction provenance has an unsupported operation.");
    return {
      adapterId: String(item.adapterId || "unsaved-adapter").slice(0, 80),
      decisionId: String(item.decisionId || "field-correction").slice(0, 160),
      operation,
      value: String(item.value || "").slice(0, MAX_ITEM_LENGTH),
      updatedAt: String(item.updatedAt || "").slice(0, 40)
    };
  });
}

function strings(value, name, { lower = false } = {}) {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value)) throw new TypeError(`${name} must be a list.`);
  const result = [];
  const seen = new Set();
  for (const candidate of value) {
    if (typeof candidate !== "string") throw new TypeError(`${name} entries must be text.`);
    const item = (lower ? candidate.toLowerCase() : candidate).trim();
    if (!item || seen.has(item)) continue;
    if (item.length > MAX_ITEM_LENGTH) throw new TypeError(`${name} entries cannot exceed ${MAX_ITEM_LENGTH} characters.`);
    seen.add(item);
    result.push(item);
    if (result.length >= MAX_LIST_ITEMS) break;
  }
  return result;
}

function normalization(value) {
  const transforms = globalThis.Site2JsonTransforms || null;
  const pipeline = strings(value, "Recommended transforms");
  for (const name of pipeline) if (!transforms?.has?.(name)) throw new TypeError(`Unknown packaged transform “${name}”.`);
  if (pipeline.length) transforms.validatePipeline(pipeline);
  return pipeline;
}

export function normalize(value) {
  if (value === undefined || value === null) return null;
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError("The property profile must be an object.");
  const aliases = strings(value.aliases, "Aliases");
  const negativeAliases = strings(value.negativeAliases, "Negative aliases");
  const expectedShapes = strings(value.expectedShapes, "Expected shapes", { lower: true });
  const invalidShapes = expectedShapes.filter((shape) => !SHAPE_SET.has(shape));
  if (invalidShapes.length) throw new TypeError(`Unknown expected value shape “${invalidShapes[0]}”.`);
  const units = strings(value.units, "Expected units");
  const recommended = normalization(value.normalization);
  const examples = strings(value.examples, "Examples");
  const cardinality = value.cardinality === undefined || value.cardinality === "" ? null : String(value.cardinality);
  if (cardinality && !["one", "many"].includes(cardinality)) throw new TypeError("Profile cardinality must be one or many.");
  const salience = value.salience === undefined || value.salience === "" ? null : Number(value.salience);
  if (salience !== null && (!Number.isInteger(salience) || salience < 0 || salience > 100)) throw new TypeError("Profile salience must be a whole number from 0 to 100.");
  const provenance = value.provenance && typeof value.provenance === "object" && !Array.isArray(value.provenance)
    ? {
        source: String(value.provenance.source || "user").slice(0, 80),
        ...(value.provenance.updatedAt ? { updatedAt: String(value.provenance.updatedAt).slice(0, 40) } : {}),
        ...(value.provenance.corrections?.length ? { corrections: corrections(value.provenance.corrections) } : {})
      }
    : { source: "user" };
  return {
    version: VERSION,
    ...(aliases.length ? { aliases } : {}),
    ...(negativeAliases.length ? { negativeAliases } : {}),
    ...(expectedShapes.length ? { expectedShapes } : {}),
    ...(units.length ? { units } : {}),
    ...(recommended.length ? { normalization: recommended } : {}),
    ...(cardinality ? { cardinality } : {}),
    ...(salience !== null ? { salience } : {}),
    ...(examples.length ? { examples } : {}),
    provenance
  };
}

export function isEmpty(value) {
  const profile = normalize(value);
  return !profile || !Object.keys(profile).some((key) => !["version", "provenance"].includes(key));
}

const propertyProfile = Object.freeze({ MAX_ITEM_LENGTH, MAX_LIST_ITEMS, VALUE_SHAPES, VERSION, isEmpty, normalize });

export default propertyProfile;
