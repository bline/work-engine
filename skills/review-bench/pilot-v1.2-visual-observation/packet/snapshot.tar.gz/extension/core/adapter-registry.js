(function initializeAdapterRegistry(root, factory) {
  "use strict";
  const dsl = root.Site2JsonDsl || (typeof require === "function" ? require("./dsl") : null);
  const yamlParser = root.Site2JsonYamlParser || (typeof require === "function" ? require("../../lib/yaml-parser") : null);
  const api = factory(dsl, yamlParser);
  root.Site2JsonAdapterRegistry = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function adapterRegistryFactory(dsl, yamlParser) {
  "use strict";

  const STORAGE_KEY = "site2jsonLocalAdapters";
  const MAX_ADAPTER_BYTES = 512_000;

  function canonicalValue(value) {
    if (Array.isArray(value)) return value.map(canonicalValue);
    if (value && typeof value === "object") {
      return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonicalValue(value[key])]));
    }
    return value;
  }

  function canonicalStringify(value) {
    return JSON.stringify(canonicalValue(value));
  }

  function bytesOf(value) {
    if (value instanceof Uint8Array) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    throw new Error("Adapter source must be raw file bytes.");
  }

  async function sha256(bytes) {
    const cryptoApi = globalThis.crypto;
    if (!cryptoApi?.subtle) throw new Error("SHA-256 is not available in this environment.");
    const digest = new Uint8Array(await cryptoApi.subtle.digest("SHA-256", bytesOf(bytes)));
    return `sha256:${[...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
  }

  function base64Encode(bytes) {
    const source = bytesOf(bytes);
    let binary = "";
    for (let offset = 0; offset < source.length; offset += 0x8000) {
      binary += String.fromCharCode(...source.subarray(offset, Math.min(offset + 0x8000, source.length)));
    }
    if (typeof btoa === "function") return btoa(binary);
    if (typeof Buffer === "function") return Buffer.from(source).toString("base64");
    throw new Error("Base64 encoding is not available in this environment.");
  }

  function base64Decode(encoded) {
    if (typeof encoded !== "string") throw new Error("Stored adapter source is invalid.");
    const binary = typeof atob === "function" ? atob(encoded) : typeof Buffer === "function" ? Buffer.from(encoded, "base64").toString("binary") : null;
    if (binary === null) throw new Error("Base64 decoding is not available in this environment.");
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  }

  function collectPipelines(value, pipelines = []) {
    if (Array.isArray(value)) {
      for (const item of value) collectPipelines(item, pipelines);
      return pipelines;
    }
    if (!value || typeof value !== "object") return pipelines;
    for (const [key, item] of Object.entries(value)) {
      if ((key === "transform" || key === "aggregate") && Array.isArray(item)) pipelines.push(item);
      else collectPipelines(item, pipelines);
    }
    return pipelines;
  }

  function requiredTransforms(definition) {
    const names = new Set();
    for (const pipeline of collectPipelines(definition)) {
      for (const step of pipeline) names.add(typeof step === "string" ? step : step.name);
    }
    return [...names].sort();
  }

  function summarize(entry) {
    return {
      id: entry.id,
      version: entry.definition.version,
      hosts: [...entry.definition.hosts],
      pageTypes: [...new Set(entry.definition.pages.map((page) => page.pageType))].sort(),
      transforms: requiredTransforms(entry.definition),
      sourceName: entry.sourceName,
      sourceDigest: entry.sourceDigest,
      definitionDigest: entry.definitionDigest,
      enabled: entry.enabled,
      importedAt: entry.importedAt
    };
  }

  async function createEntry(rawBytes, sourceName, { importedAt = new Date().toISOString(), enabled = true, editorState = null } = {}) {
    const bytes = bytesOf(rawBytes);
    if (bytes.byteLength === 0) throw new Error("The selected adapter file is empty.");
    if (bytes.byteLength > MAX_ADAPTER_BYTES) throw new Error(`Adapter files may not exceed ${MAX_ADAPTER_BYTES} bytes.`);
    let sourceText;
    try {
      sourceText = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } catch {
      throw new Error("Adapter files must be valid UTF-8.");
    }
    const parser = yamlParser || globalThis.Site2JsonYamlParser;
    if (!parser?.parse) throw new Error("The packaged YAML parser is unavailable.");
    const parsed = parser.parse(sourceText);
    const definition = dsl.validateDefinition(parsed);
    const canonicalBytes = new TextEncoder().encode(canonicalStringify(definition));
    const entry = {
      id: definition.adapter,
      source: "local-file",
      sourceName: typeof sourceName === "string" && sourceName ? sourceName : `${definition.adapter}.yaml`,
      importedAt,
      enabled: Boolean(enabled),
      dslVersion: definition.dslVersion,
      sourceDigest: await sha256(bytes),
      definitionDigest: await sha256(canonicalBytes),
      sourceBase64: base64Encode(bytes),
      definition,
      ...(editorState ? { editorState: JSON.parse(JSON.stringify(editorState)) } : {})
    };
    return { entry, summary: summarize(entry) };
  }

  function sourceBytes(entry) {
    return base64Decode(entry.sourceBase64);
  }

  function normalizeEntries(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((entry) => entry && entry.source === "local-file" && typeof entry.id === "string" && entry.definition);
  }

  async function load(storage = chrome.storage.local) {
    const stored = await storage.get(STORAGE_KEY);
    return normalizeEntries(stored[STORAGE_KEY]);
  }

  async function save(entries, storage = chrome.storage.local) {
    await storage.set({ [STORAGE_KEY]: normalizeEntries(entries) });
  }

  function upsert(entries, entry) {
    const normalized = normalizeEntries(entries);
    const index = normalized.findIndex((candidate) => candidate.id === entry.id);
    if (index < 0) return [...normalized, entry];
    const next = [...normalized];
    next[index] = entry;
    return next;
  }

  function setEnabled(entries, id, enabled) {
    return normalizeEntries(entries).map((entry) => entry.id === id ? { ...entry, enabled: Boolean(enabled) } : entry);
  }

  function remove(entries, id) {
    return normalizeEntries(entries).filter((entry) => entry.id !== id);
  }

  function enabledDefinitions(entries) {
    return normalizeEntries(entries).filter((entry) => entry.enabled).map((entry) => entry.definition);
  }

  return {
    MAX_ADAPTER_BYTES,
    STORAGE_KEY,
    canonicalStringify,
    createEntry,
    enabledDefinitions,
    load,
    remove,
    requiredTransforms,
    save,
    setEnabled,
    sha256,
    sourceBytes,
    summarize,
    upsert
  };
});
