(function initializeSemanticToolbox(root, factory) {
  "use strict";
  const propertyProfile = root.Site2JsonPropertyProfile || (typeof require === "function" ? require("./property-profile") : null);
  const api = factory(propertyProfile);
  root.Site2JsonSemanticToolbox = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticToolboxFactory(propertyProfile) {
  "use strict";

  const STORAGE_KEY = "site2json.semanticToolbox";
  const VERSION = 6;
  const DEFAULT_FAVORITES = Object.freeze(["Person", "Organization", "JobPosting", "Article", "Product", "Place"]);
  const clone = (value) => JSON.parse(JSON.stringify(value));

  function item(value) {
    if (!value || typeof value !== "object") return null;
    if (!["schemaType", "customType", "pattern", "toolkit"].includes(value.kind)) return null;
    const id = String(value.id || "").trim();
    if (!id || id.length > 160) return null;
    return { kind: value.kind, id };
  }

  function patternRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const id = String(value.id || "").trim();
    const label = String(value.label || "").trim();
    if (!id || id.length > 160 || !label || label.length > 160) return null;
    if (!value.root || typeof value.root !== "string") return null;
    if (!value.nodes || typeof value.nodes !== "object" || Array.isArray(value.nodes) || !value.nodes[value.root]) return null;
    if (!Array.isArray(value.edges)) return null;
    const patternId = String(value.patternId || id).trim();
    if (!patternId || patternId.length > 500) return null;
    const record = {
      id, patternId, label,
      description: typeof value.description === "string" ? value.description.slice(0, 500) : "",
      root: value.root,
      nodes: clone(value.nodes),
      edges: clone(value.edges),
      terms: value.terms && typeof value.terms === "object" && !Array.isArray(value.terms) ? clone(value.terms) : {}
    };
    if (Number.isInteger(value.revision) && value.revision > 0) record.revision = value.revision;
    if (typeof value.createdAt === "string") record.createdAt = value.createdAt;
    if (typeof value.updatedAt === "string") record.updatedAt = value.updatedAt;
    if (value.provenance && typeof value.provenance === "object" && !Array.isArray(value.provenance)) record.provenance = clone(value.provenance);
    return record;
  }

  function customTypeRecord(value, fallbackId = "") {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const definition = value.definition && typeof value.definition === "object" && !Array.isArray(value.definition)
      ? value.definition
      : value;
    const id = String(value.id || fallbackId || definition.valueType || "").trim();
    const termId = String(value.termId || definition.valueType || id).trim();
    const label = String(value.label || termId.split(":").at(-1) || "").trim();
    const description = String(value.description || definition.description || "").trim();
    if (!id || id.length > 500 || !termId || termId.length > 500 || !label || label.length > 160 || !description) return null;
    const record = {
      id,
      termId,
      label,
      description: description.slice(0, 500),
      definition: {
        ...clone(definition),
        kind: "type",
        description: description.slice(0, 500),
        valueType: termId
      }
    };
    if (Number.isInteger(value.revision) && value.revision > 0) record.revision = value.revision;
    if (typeof value.createdAt === "string") record.createdAt = value.createdAt;
    if (typeof value.updatedAt === "string") record.updatedAt = value.updatedAt;
    if (value.provenance && typeof value.provenance === "object" && !Array.isArray(value.provenance)) record.provenance = clone(value.provenance);
    return record;
  }

  function propertyRecord(value, fallbackId = "") {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const definition = value.definition && typeof value.definition === "object" && !Array.isArray(value.definition) ? value.definition : value;
    const id = String(value.id || fallbackId || "").trim();
    const termId = String(value.termId || id).trim();
    const label = String(value.label || termId.split(":").at(-1) || "").trim();
    const description = String(value.description || definition.description || "").trim();
    if (!id || id.length > 500 || !termId || termId.length > 500 || !label || label.length > 160 || !description) return null;
    const normalizedDefinition = {
      ...clone(definition),
      kind: "relationship",
      description: description.slice(0, 500)
    };
    try {
      const profile = propertyProfile?.normalize?.(definition.authoringProfile);
      if (profile && !propertyProfile.isEmpty(profile)) normalizedDefinition.authoringProfile = profile;
      else delete normalizedDefinition.authoringProfile;
    } catch {
      return null;
    }
    const record = {
      id,
      termId,
      label,
      description: description.slice(0, 500),
      definition: normalizedDefinition
    };
    if (Number.isInteger(value.revision) && value.revision > 0) record.revision = value.revision;
    if (typeof value.createdAt === "string") record.createdAt = value.createdAt;
    if (typeof value.updatedAt === "string") record.updatedAt = value.updatedAt;
    if (value.provenance && typeof value.provenance === "object" && !Array.isArray(value.provenance)) record.provenance = clone(value.provenance);
    return record;
  }

  function tagRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const id = String(value.id || "").trim();
    const label = String(value.label || "").trim();
    if (!id || id.length > 160 || !label || label.length > 160) return null;
    const record = {
      id,
      label,
      description: typeof value.description === "string" ? value.description.slice(0, 500) : ""
    };
    if (typeof value.color === "string" && /^#[0-9a-f]{6}$/i.test(value.color)) record.color = value.color.toLowerCase();
    if (Number.isInteger(value.revision) && value.revision > 0) record.revision = value.revision;
    if (typeof value.createdAt === "string") record.createdAt = value.createdAt;
    if (typeof value.updatedAt === "string") record.updatedAt = value.updatedAt;
    return record;
  }

  function libraryRef(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    if (!["schemaType", "customType", "pattern", "vocabulary", "term", "property"].includes(value.kind)) return null;
    const id = String(value.id || "").trim();
    if (!id || id.length > 500) return null;
    return { kind: value.kind, id };
  }

  function collectionRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const id = String(value.id || "").trim();
    const label = String(value.label || "").trim();
    if (!id || id.length > 160 || !label || label.length > 160) return null;
    const members = [];
    const seen = new Set();
    for (const candidate of Array.isArray(value.members) ? value.members : []) {
      const member = libraryRef(candidate);
      const key = member && `${member.kind}\u001f${member.id}`;
      if (!member || seen.has(key)) continue;
      seen.add(key);
      members.push(member);
    }
    const record = {
      id,
      label,
      description: typeof value.description === "string" ? value.description.slice(0, 500) : "",
      members
    };
    if (Number.isInteger(value.revision) && value.revision > 0) record.revision = value.revision;
    if (typeof value.createdAt === "string") record.createdAt = value.createdAt;
    if (typeof value.updatedAt === "string") record.updatedAt = value.updatedAt;
    return record;
  }

  function normalize(value) {
    const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const favorites = [];
    const seen = new Set();
    for (const candidate of Array.isArray(source.favorites) ? source.favorites : DEFAULT_FAVORITES.map((id) => ({ kind: "schemaType", id }))) {
      const normalized = item(candidate);
      const key = normalized && `${normalized.kind}\u001f${normalized.id}`;
      if (!normalized || seen.has(key)) continue;
      seen.add(key);
      favorites.push(normalized);
      if (favorites.length >= 40) break;
    }
    const sourcePatterns = source.patterns && typeof source.patterns === "object" && !Array.isArray(source.patterns) ? source.patterns : {};
    const patterns = {};
    for (const [patternKey, candidate] of Object.entries(sourcePatterns)) {
      const record = patternRecord(candidate);
      if (record && record.id === patternKey) patterns[patternKey] = record;
    }
    const sourceTags = source.tags && typeof source.tags === "object" && !Array.isArray(source.tags) ? source.tags : {};
    const tags = {};
    for (const [tagKey, candidate] of Object.entries(sourceTags)) {
      const record = tagRecord(candidate);
      if (record && record.id === tagKey) tags[tagKey] = record;
    }
    const sourceCollections = source.collections && typeof source.collections === "object" && !Array.isArray(source.collections) ? source.collections : {};
    const collections = {};
    for (const [collectionKey, candidate] of Object.entries(sourceCollections)) {
      const record = collectionRecord(candidate);
      if (record && record.id === collectionKey) collections[collectionKey] = record;
    }
    const sourceAssignments = source.tagAssignments && typeof source.tagAssignments === "object" && !Array.isArray(source.tagAssignments) ? source.tagAssignments : {};
    const tagAssignments = {};
    for (const [targetKey, candidate] of Object.entries(sourceAssignments)) {
      if (typeof targetKey !== "string" || !targetKey.includes("\u001f") || !Array.isArray(candidate)) continue;
      const assigned = [...new Set(candidate.map(String).filter((id) => tags[id]))];
      if (assigned.length) tagAssignments[targetKey] = assigned;
    }
    const sourceCustomTypes = source.customTypes && typeof source.customTypes === "object" && !Array.isArray(source.customTypes) ? source.customTypes : {};
    const customTypes = {};
    for (const [typeKey, candidate] of Object.entries(sourceCustomTypes)) {
      const record = customTypeRecord(candidate, typeKey);
      if (record && record.id === typeKey) customTypes[typeKey] = record;
    }
    const sourceProperties = source.properties && typeof source.properties === "object" && !Array.isArray(source.properties) ? source.properties : {};
    const properties = {};
    for (const [propertyKey, candidate] of Object.entries(sourceProperties)) {
      const record = propertyRecord(candidate, propertyKey);
      if (record && record.id === propertyKey) properties[propertyKey] = record;
    }
    return {
      version: VERSION,
      favorites,
      customTypes,
      properties,
      patterns,
      tags,
      tagAssignments,
      collections,
      toolkits: source.toolkits && typeof source.toolkits === "object" && !Array.isArray(source.toolkits) ? clone(source.toolkits) : {}
    };
  }

  function defaultStorage(storage) {
    return storage || (typeof chrome === "object" ? chrome.storage?.local : null);
  }

  async function load(storage = null) {
    const target = defaultStorage(storage);
    if (!target?.get) return normalize(null);
    const stored = await target.get(STORAGE_KEY);
    return normalize(stored[STORAGE_KEY]);
  }

  async function save(toolbox, storage = null) {
    const normalized = normalize(toolbox);
    const target = defaultStorage(storage);
    if (!target?.set) return normalized;
    await target.set({ [STORAGE_KEY]: normalized });
    return normalized;
  }

  function addFavorite(toolbox, favorite, index = null) {
    const next = normalize(toolbox);
    const normalized = item(favorite);
    if (!normalized) return next;
    next.favorites = next.favorites.filter((entry) => entry.kind !== normalized.kind || entry.id !== normalized.id);
    const target = Number.isInteger(index) ? Math.max(0, Math.min(index, next.favorites.length)) : next.favorites.length;
    next.favorites.splice(target, 0, normalized);
    return normalize(next);
  }

  function removeFavorite(toolbox, favorite) {
    const normalized = item(favorite);
    const next = normalize(toolbox);
    if (!normalized) return next;
    next.favorites = next.favorites.filter((entry) => entry.kind !== normalized.kind || entry.id !== normalized.id);
    return next;
  }

  function addPattern(toolbox, pattern) {
    const next = normalize(toolbox);
    const record = patternRecord(pattern);
    if (!record) return next;
    next.patterns[record.id] = record;
    return normalize(next);
  }

  function removePattern(toolbox, id) {
    const next = normalize(toolbox);
    delete next.patterns[String(id || "")];
    return next;
  }

  function addCustomType(toolbox, customType) {
    const next = normalize(toolbox);
    const record = customTypeRecord(customType);
    if (!record) return next;
    next.customTypes[record.id] = record;
    return normalize(next);
  }

  function removeCustomType(toolbox, id) {
    const next = normalize(toolbox);
    delete next.customTypes[String(id || "")];
    return next;
  }

  function addProperty(toolbox, property) {
    const next = normalize(toolbox);
    const record = propertyRecord(property);
    if (!record) return next;
    next.properties[record.id] = record;
    return normalize(next);
  }

  function removeProperty(toolbox, id) {
    const next = normalize(toolbox);
    delete next.properties[String(id || "")];
    return next;
  }

  return Object.freeze({ STORAGE_KEY, VERSION, DEFAULT_FAVORITES, addCustomType, addFavorite, addPattern, addProperty, load, normalize, removeCustomType, removeFavorite, removePattern, removeProperty, save });
});
