(function initializeAutomaticSettings(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonAutomaticSettings = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function automaticSettingsFactory() {
  "use strict";

  const STORAGE_KEY = "site2jsonAutomaticSettings";
  const LEVELS = Object.freeze(["moderate", "strong"]);
  const DEFAULTS = Object.freeze({ minimumConfidence: "strong" });

  function normalize(value = {}) {
    const minimumConfidence = LEVELS.includes(value?.minimumConfidence)
      ? value.minimumConfidence
      : DEFAULTS.minimumConfidence;
    return { minimumConfidence };
  }

  function label(value) {
    return value === "moderate" ? "Moderate" : "High";
  }

  async function load(storage = globalThis.chrome?.storage?.local) {
    if (!storage?.get) return normalize();
    const stored = await storage.get(STORAGE_KEY);
    return normalize(stored?.[STORAGE_KEY]);
  }

  async function save(settings, storage = globalThis.chrome?.storage?.local) {
    const normalized = normalize(settings);
    if (!storage?.set) throw new Error("Automatic inference settings storage is unavailable.");
    await storage.set({ [STORAGE_KEY]: normalized });
    return normalized;
  }

  return Object.freeze({ DEFAULTS, LEVELS, STORAGE_KEY, label, load, normalize, save });
});
