// Generated compatibility bridge from property-profile.mjs. Remove after the final classic consumer migrates.
var Site2JsonPropertyProfile = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // extension/core/property-profile.mjs
  var property_profile_exports = {};
  __export(property_profile_exports, {
    MAX_ITEM_LENGTH: () => MAX_ITEM_LENGTH,
    MAX_LIST_ITEMS: () => MAX_LIST_ITEMS,
    VALUE_SHAPES: () => VALUE_SHAPES,
    VERSION: () => VERSION,
    default: () => property_profile_default,
    isEmpty: () => isEmpty,
    normalize: () => normalize
  });
  var VERSION = 1;
  var VALUE_SHAPES = Object.freeze(["text", "url", "date", "datetime", "integer", "number", "boolean", "currency", "percentage"]);
  var SHAPE_SET = new Set(VALUE_SHAPES);
  var MAX_LIST_ITEMS = 40;
  var MAX_ITEM_LENGTH = 160;
  function corrections(value) {
    if (value === void 0 || value === null) return [];
    if (!Array.isArray(value)) throw new TypeError("Correction provenance must be a list.");
    return value.slice(-20).map((item) => {
      if (!item || typeof item !== "object" || Array.isArray(item)) throw new TypeError("Correction provenance entries must be objects.");
      const operation = String(item.operation || "");
      if (!(/* @__PURE__ */ new Set(["add-alias", "add-negative-alias"])).has(operation)) throw new TypeError("Correction provenance has an unsupported operation.");
      return {
        adapterId: String(item.adapterId || "unsaved-adapter").slice(0, 80),
        decisionId: String(item.decisionId || "field-correction").slice(0, 160),
        operation,
        value: String(item.value || "").slice(0, MAX_ITEM_LENGTH),
        updatedAt: String(item.updatedAt || "").slice(0, 40)
      };
    });
  }
  function strings(value, name, { lower = false } = {}) {
    if (value === void 0 || value === null) return [];
    if (!Array.isArray(value)) throw new TypeError(`${name} must be a list.`);
    const result = [];
    const seen = /* @__PURE__ */ new Set();
    for (const candidate of value) {
      if (typeof candidate !== "string") throw new TypeError(`${name} entries must be text.`);
      const item = (lower ? candidate.toLowerCase() : candidate).trim();
      if (!item || seen.has(item)) continue;
      if (item.length > MAX_ITEM_LENGTH) throw new TypeError(`${name} entries cannot exceed ${MAX_ITEM_LENGTH} characters.`);
      seen.add(item);
      result.push(item);
      if (result.length >= MAX_LIST_ITEMS) break;
    }
    return result;
  }
  function normalization(value) {
    const transforms = globalThis.Site2JsonTransforms || null;
    const pipeline = strings(value, "Recommended transforms");
    for (const name of pipeline) if (!transforms?.has?.(name)) throw new TypeError(`Unknown packaged transform \u201C${name}\u201D.`);
    if (pipeline.length) transforms.validatePipeline(pipeline);
    return pipeline;
  }
  function normalize(value) {
    if (value === void 0 || value === null) return null;
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError("The property profile must be an object.");
    const aliases = strings(value.aliases, "Aliases");
    const negativeAliases = strings(value.negativeAliases, "Negative aliases");
    const expectedShapes = strings(value.expectedShapes, "Expected shapes", { lower: true });
    const invalidShapes = expectedShapes.filter((shape) => !SHAPE_SET.has(shape));
    if (invalidShapes.length) throw new TypeError(`Unknown expected value shape \u201C${invalidShapes[0]}\u201D.`);
    const units = strings(value.units, "Expected units");
    const recommended = normalization(value.normalization);
    const examples = strings(value.examples, "Examples");
    const cardinality = value.cardinality === void 0 || value.cardinality === "" ? null : String(value.cardinality);
    if (cardinality && !["one", "many"].includes(cardinality)) throw new TypeError("Profile cardinality must be one or many.");
    const salience = value.salience === void 0 || value.salience === "" ? null : Number(value.salience);
    if (salience !== null && (!Number.isInteger(salience) || salience < 0 || salience > 100)) throw new TypeError("Profile salience must be a whole number from 0 to 100.");
    const provenance = value.provenance && typeof value.provenance === "object" && !Array.isArray(value.provenance) ? {
      source: String(value.provenance.source || "user").slice(0, 80),
      ...value.provenance.updatedAt ? { updatedAt: String(value.provenance.updatedAt).slice(0, 40) } : {},
      ...value.provenance.corrections?.length ? { corrections: corrections(value.provenance.corrections) } : {}
    } : { source: "user" };
    return {
      version: VERSION,
      ...aliases.length ? { aliases } : {},
      ...negativeAliases.length ? { negativeAliases } : {},
      ...expectedShapes.length ? { expectedShapes } : {},
      ...units.length ? { units } : {},
      ...recommended.length ? { normalization: recommended } : {},
      ...cardinality ? { cardinality } : {},
      ...salience !== null ? { salience } : {},
      ...examples.length ? { examples } : {},
      provenance
    };
  }
  function isEmpty(value) {
    const profile = normalize(value);
    return !profile || !Object.keys(profile).some((key) => !["version", "provenance"].includes(key));
  }
  var propertyProfile = Object.freeze({ MAX_ITEM_LENGTH, MAX_LIST_ITEMS, VALUE_SHAPES, VERSION, isEmpty, normalize });
  var property_profile_default = propertyProfile;
  return __toCommonJS(property_profile_exports);
})();
globalThis.Site2JsonPropertyProfile = Site2JsonPropertyProfile; if (typeof module === "object" && module.exports) { globalThis.Site2JsonTransforms ||= require("./transforms"); module.exports = Site2JsonPropertyProfile; }
