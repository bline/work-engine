(function initializeYamlPolicy(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonYamlPolicy = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function yamlPolicyFactory() {
  "use strict";

  const MAX_DOCUMENT_BYTES = 512_000;

  function create(YAML) {
    function rejectUnsupportedNode(node) {
      if (!node) return;
      if (YAML.isAlias(node)) throw new Error("YAML aliases are not allowed.");
      if (node.anchor) throw new Error("YAML anchors are not allowed.");
      if (YAML.isPair(node)) {
        if (!YAML.isScalar(node.key) || typeof node.key.value !== "string") throw new Error("YAML mapping keys must be strings.");
        if (node.key.value === "<<") throw new Error("YAML merge keys are not allowed.");
        rejectUnsupportedNode(node.key);
        rejectUnsupportedNode(node.value);
        return;
      }
      if (YAML.isMap(node) || YAML.isSeq(node)) {
        for (const item of node.items) rejectUnsupportedNode(item);
      }
    }

    function assertNormalizedData(value) {
      if (value === null || typeof value === "string" || typeof value === "boolean") return;
      if (typeof value === "number" && Number.isFinite(value)) return;
      if (Array.isArray(value)) {
        for (const item of value) assertNormalizedData(item);
        return;
      }
      if (value && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype) {
        for (const [key, item] of Object.entries(value)) {
          if (["__proto__", "prototype", "constructor"].includes(key)) throw new Error(`Unsafe YAML mapping key: ${key}`);
          assertNormalizedData(item);
        }
        return;
      }
      throw new Error("YAML must contain only finite JSON-compatible data values.");
    }

    function parse(text) {
      if (typeof text !== "string") throw new Error("Adapter YAML must be text.");
      if (new TextEncoder().encode(text).length > MAX_DOCUMENT_BYTES) throw new Error(`Adapter YAML exceeds ${MAX_DOCUMENT_BYTES} bytes.`);
      const documents = YAML.parseAllDocuments(text, {
        schema: "core",
        merge: false,
        uniqueKeys: true,
        prettyErrors: false
      });
      if (documents.length !== 1) throw new Error("An adapter file must contain exactly one YAML document.");
      const document = documents[0];
      const diagnostics = [...document.errors, ...document.warnings];
      if (diagnostics.length) throw new Error(`Invalid adapter YAML: ${diagnostics[0].message}`);
      rejectUnsupportedNode(document.contents);
      const value = document.toJS({ maxAliasCount: 0, mapAsMap: false });
      assertNormalizedData(value);
      return value;
    }

    function stringify(value) {
      assertNormalizedData(value);
      const text = YAML.stringify(value, {
        aliasDuplicateObjects: false,
        lineWidth: 0,
        schema: "core"
      });
      if (new TextEncoder().encode(text).length > MAX_DOCUMENT_BYTES) throw new Error(`Adapter YAML exceeds ${MAX_DOCUMENT_BYTES} bytes.`);
      // Keep generated files inside the exact same inert-data policy as imports.
      parse(text);
      return text;
    }

    return { MAX_DOCUMENT_BYTES, parse, stringify };
  }

  return { MAX_DOCUMENT_BYTES, create };
});
