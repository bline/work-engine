(function initializeSemanticCatalog(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonSemanticCatalog = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticCatalogFactory() {
  "use strict";

  const LOVPORTAL_SPARQL_URL = "https://sparql.lovportal.lirmm.fr/sparql/";
  const LOVPORTAL_ONTOLOGY_GRAPH = "http://data.bioontology.org/metadata/Ontology";
  const LOVPORTAL_SUBMISSION_GRAPH = "http://data.bioontology.org/metadata/OntologySubmission";
  const LOVPORTAL_CATEGORY_GRAPH = "http://data.bioontology.org/metadata/Category";
  const METADATA_CACHE_KEY = "site2json.semanticCatalogMetadata.v1";
  const METADATA_CACHE_VERSION = 1;
  const DEFAULT_METADATA_CACHE_TTL = 24 * 60 * 60 * 1000;
  const MAX_PAGE_SIZE = 50;
  const MAX_REMOTE_SEARCH_RESULTS = 500;
  const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  class SemanticCatalogError extends Error {
    constructor(code, message, details = null) {
      super(message);
      this.name = "SemanticCatalogError";
      this.code = code;
      if (details) this.details = clone(details);
    }
  }

  function boundedText(value, limit = 500) {
    return typeof value === "string" ? value.trim().slice(0, limit) : "";
  }

  function uniqueStrings(values, limit = 100) {
    return [...new Set((Array.isArray(values) ? values : []).map((value) => boundedText(value, 1500)).filter(Boolean))].slice(0, limit);
  }

  function localName(prefixedName, uri) {
    const prefixed = boundedText(prefixedName, 500);
    if (prefixed.includes(":")) return prefixed.slice(prefixed.indexOf(":") + 1);
    return boundedText(uri, 1500).split(/[\/#]/).filter(Boolean).at(-1) || prefixed || "Term";
  }

  function createRequester({ fetchImpl, timeoutMs, cacheTtlMs }) {
    if (typeof fetchImpl !== "function") throw new SemanticCatalogError("INVALID_CONFIGURATION", "Semantic catalog browsing requires a fetch implementation.");
    const cache = new Map();
    async function request(url, { signal = null, accept = "application/json" } = {}) {
      const key = String(url);
      const cached = cache.get(key);
      if (cached && Date.now() - cached.at < cacheTtlMs) return clone(cached.value);
      const controller = new AbortController();
      const abort = () => controller.abort(signal?.reason);
      if (signal?.aborted) abort();
      else signal?.addEventListener?.("abort", abort, { once: true });
      const timer = setTimeout(() => controller.abort(new Error("timeout")), timeoutMs);
      try {
        const response = await fetchImpl(key, { signal: controller.signal, headers: { Accept: accept } });
        if (!response?.ok) throw new SemanticCatalogError("CATALOG_HTTP_ERROR", `The semantic catalog returned HTTP ${response?.status || "error"}.`, { status: response?.status || 0, url: key });
        const value = await response.json();
        cache.set(key, { at: Date.now(), value: clone(value) });
        return value;
      } catch (error) {
        if (error instanceof SemanticCatalogError) throw error;
        if (controller.signal.aborted) throw new SemanticCatalogError(signal?.aborted ? "CANCELLED" : "CATALOG_TIMEOUT", signal?.aborted ? "Semantic catalog request cancelled." : "The semantic catalog took too long to respond.", { url: key });
        throw new SemanticCatalogError("CATALOG_UNAVAILABLE", `The semantic catalog could not be reached: ${error.message}`, { url: key });
      } finally {
        clearTimeout(timer);
        signal?.removeEventListener?.("abort", abort);
      }
    }
    return { request, clearCache: () => cache.clear() };
  }

  const RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type";
  const RDFS_LABEL = "http://www.w3.org/2000/01/rdf-schema#label";
  const RDFS_COMMENT = "http://www.w3.org/2000/01/rdf-schema#comment";
  const RDFS_SUBCLASS = "http://www.w3.org/2000/01/rdf-schema#subClassOf";
  const RDFS_DOMAIN = "http://www.w3.org/2000/01/rdf-schema#domain";
  const RDFS_RANGE = "http://www.w3.org/2000/01/rdf-schema#range";
  const RDFS_CLASS = "http://www.w3.org/2000/01/rdf-schema#Class";
  const OWL_CLASS = "http://www.w3.org/2002/07/owl#Class";
  const PREF_LABEL = "http://data.bioontology.org/metadata/def/prefLabel";
  const PREFIX_IRI = "http://data.bioontology.org/metadata/prefixIRI";
  const METADATA_ONTOLOGY = "http://data.bioontology.org/metadata/ontology";
  const METADATA_SUBMISSION_ID = "http://data.bioontology.org/metadata/submissionId";
  const METADATA_GROUP = "http://data.bioontology.org/metadata/group";
  const METADATA_ACRONYM = "http://data.bioontology.org/metadata/acronym";
  const METADATA_NAME = "http://data.bioontology.org/metadata/name";
  const METADATA_DESCRIPTION = "http://data.bioontology.org/metadata/description";
  const OMV_ACRONYM = "http://omv.ontoware.org/2005/05/ontology#acronym";
  const OMV_NAME = "http://omv.ontoware.org/2005/05/ontology#name";
  const OMV_DOMAIN = "http://omv.ontoware.org/2005/05/ontology#hasDomain";
  const OMV_URI = "http://omv.ontoware.org/2005/05/ontology#URI";
  const OMV_DESCRIPTION = "http://omv.ontoware.org/2005/05/ontology#description";
  const VANN_NAMESPACE = "http://purl.org/vocab/vann/preferredNamespaceUri";
  const RDF_PROPERTY = "http://www.w3.org/1999/02/22-rdf-syntax-ns#Property";
  const OWL_OBJECT_PROPERTY = "http://www.w3.org/2002/07/owl#ObjectProperty";
  const OWL_DATATYPE_PROPERTY = "http://www.w3.org/2002/07/owl#DatatypeProperty";
  const OWL_ANNOTATION_PROPERTY = "http://www.w3.org/2002/07/owl#AnnotationProperty";

  function sparqlIri(value) {
    const uri = boundedText(value, 1500);
    if (!/^https?:\/\/[^<>\s]+$/.test(uri)) throw new SemanticCatalogError("INVALID_TERM", "Catalog terms must use an absolute HTTP(S) URI.");
    return `<${uri}>`;
  }

  function sparqlText(value) {
    return JSON.stringify(boundedText(value, 1500));
  }

  function bindings(value) {
    return Array.isArray(value?.results?.bindings) ? value.results.bindings : [];
  }

  function graphSubmission(graph) {
    const match = /\/ontologies\/([^/]+)\/submissions\/(\d+)$/.exec(graph);
    return match ? { acronym: decodeURIComponent(match[1]), submissionId: Number(match[2]) } : null;
  }

  function createLovPortalEnrichment({ request, endpoint = LOVPORTAL_SPARQL_URL }) {
    async function query(text, signal = null) {
      const url = new URL(endpoint);
      url.searchParams.set("query", text);
      url.searchParams.set("format", "application/sparql-results+json");
      return request(url, { signal, accept: "application/sparql-results+json" });
    }

    async function findSnapshot(term, signal) {
      if (term?.snapshot?.graph && graphSubmission(term.snapshot.graph)) return clone(term.snapshot);
      const acronym = boundedText(term?.vocabulary?.acronym || term?.vocabulary?.prefix, 160).replace(/[^A-Za-z0-9_-]/g, "");
      const value = await query(`SELECT DISTINCT ?g WHERE { GRAPH ?g { ${sparqlIri(term.uri)} ?p ?o } ${acronym ? `FILTER(CONTAINS(UCASE(STR(?g)), "/${acronym.toUpperCase()}/SUBMISSIONS/"))` : ""} } LIMIT 100`, signal);
      const candidates = bindings(value).map((row) => boundedText(row.g?.value, 1500)).map((graph) => ({ graph, parsed: graphSubmission(graph) })).filter((item) => item.parsed);
      candidates.sort((left, right) => right.parsed.submissionId - left.parsed.submissionId);
      if (!candidates.length) throw new SemanticCatalogError("ENRICHMENT_NOT_FOUND", `${term.prefixedName} was not found in a versioned LovPortal graph.`, { uri: term.uri });
      return { graph: candidates[0].graph, ...candidates[0].parsed };
    }

    async function findVocabularySnapshot(vocabulary, signal) {
      if (vocabulary?.snapshot?.graph && graphSubmission(vocabulary.snapshot.graph)) return clone(vocabulary.snapshot);
      const acronym = boundedText(vocabulary?.acronym || vocabulary?.prefix, 160).replace(/[^A-Za-z0-9_-]/g, "");
      if (!acronym) throw new SemanticCatalogError("INVALID_VOCABULARY", "A vocabulary acronym is required.");
      const ontology = boundedText(vocabulary?.catalogUri, 1500) || `http://data.bioontology.org/ontologies/${acronym.toUpperCase()}`;
      const value = await query(`SELECT DISTINCT ?submission ?submissionId ?namespace ?uri ?description ?released WHERE { GRAPH <${LOVPORTAL_SUBMISSION_GRAPH}> {
        ?submission <${METADATA_ONTOLOGY}> ${sparqlIri(ontology)} ; <${METADATA_SUBMISSION_ID}> ?submissionId .
        OPTIONAL { ?submission <${VANN_NAMESPACE}> ?namespace }
        OPTIONAL { ?submission <${OMV_URI}> ?uri }
        OPTIONAL { ?submission <${OMV_DESCRIPTION}> ?description }
        OPTIONAL { ?submission <http://data.bioontology.org/metadata/released> ?released }
      } } ORDER BY DESC(xsd:integer(?submissionId)) LIMIT 1`, signal);
      const row = bindings(value)[0];
      const graph = boundedText(row?.submission?.value, 1500);
      const parsed = graphSubmission(graph);
      if (!parsed) throw new SemanticCatalogError("ENRICHMENT_NOT_FOUND", `${acronym} was not found in a versioned LovPortal graph.`, { acronym });
      return {
        graph, ...parsed,
        namespace: boundedText(row.namespace?.value, 1500),
        canonicalUri: boundedText(row.uri?.value, 1500),
        description: boundedText(row.description?.value, 1000),
        released: boundedText(row.released?.value, 100)
      };
    }

    function vocabularyTermWhere(vocabulary, queryText = "") {
      const prefix = boundedText(vocabulary?.prefix, 160).replace(/[^A-Za-z0-9_-]/g, "");
      const namespace = boundedText(vocabulary?.snapshot?.namespace || vocabulary?.namespace, 1500);
      const text = boundedText(queryText, 200).toLowerCase();
      return `?term a ?classKind ; <${PREFIX_IRI}> ?prefixed .
        VALUES ?classKind { <${OWL_CLASS}> <${RDFS_CLASS}> }
        ${namespace ? `FILTER(STRSTARTS(STR(?term), ${sparqlText(namespace)}))` : `FILTER(STRSTARTS(LCASE(STR(?prefixed)), ${sparqlText(`${prefix.toLowerCase()}:`)}))`}
        OPTIONAL { ?term <${PREF_LABEL}> ?searchLabel }
        ${text ? `FILTER(CONTAINS(LCASE(CONCAT(STR(?prefixed), " ", COALESCE(STR(?searchLabel), ""))), ${sparqlText(text)}))` : ""}`;
    }

    function termsFromRows(rows, vocabulary, snapshot) {
      const terms = new Map();
      for (const row of rows) {
        const uri = boundedText(row.term?.value, 1500);
        if (!uri) continue;
        const rawPrefixed = boundedText(row.prefixed?.value, 500);
        const prefixedName = rawPrefixed ? (rawPrefixed.includes(":") ? rawPrefixed : `${vocabulary.prefix}:${rawPrefixed}`) : `${vocabulary.prefix}:${localName("", uri)}`;
        const term = terms.get(uri) || {
          kind: "catalogTerm", termType: "class", uri, prefixedName,
          label: boundedText(row.label?.value, 160) || localName(prefixedName, uri),
          description: boundedText(row.comment?.value, 1000), vocabulary: { prefix: vocabulary.prefix },
          tags: uniqueStrings(vocabulary.tags, 40), parents: [], snapshot: clone(snapshot),
          provenance: clone(vocabulary.provenance || {})
        };
        if (!term.description && row.comment?.value) term.description = boundedText(row.comment.value, 1000);
        if (row.parent?.type === "uri") term.parents.push(row.parent.value);
        term.parents = uniqueStrings(term.parents);
        terms.set(uri, term);
      }
      return [...terms.values()];
    }

    async function browseVocabulary(vocabulary, { query: queryText = "", page = 1, pageSize = 25, signal = null, snapshot: suppliedSnapshot = null } = {}) {
      const snapshot = suppliedSnapshot || await findVocabularySnapshot(vocabulary, signal);
      const graph = sparqlIri(snapshot.graph);
      const selectedPage = Math.max(1, Number(page) || 1);
      const selectedSize = Math.max(1, Math.min(MAX_PAGE_SIZE, Number(pageSize) || 25));
      const where = vocabularyTermWhere(vocabulary, queryText);
      const countValue = await query(`SELECT (COUNT(DISTINCT ?term) AS ?total) WHERE { GRAPH ${graph} { ${where} } }`, signal);
      const total = Number(bindings(countValue)[0]?.total?.value) || 0;
      const value = await query(`SELECT DISTINCT ?term ?prefixed ?label ?comment ?parent WHERE {
        GRAPH ${graph} {
          { SELECT DISTINCT ?term ?prefixed WHERE { ${where} } ORDER BY LCASE(STR(?prefixed)) LIMIT ${selectedSize} OFFSET ${(selectedPage - 1) * selectedSize} }
          OPTIONAL { ?term <${PREF_LABEL}> ?label }
          OPTIONAL { ?term <${RDFS_COMMENT}> ?comment FILTER(LANG(?comment) = "" || LANGMATCHES(LANG(?comment), "en")) }
          OPTIONAL { ?term <${RDFS_SUBCLASS}> ?parent FILTER(ISIRI(?parent)) }
        }
      } ORDER BY LCASE(STR(?prefixed))`, signal);
      return { items: termsFromRows(bindings(value), vocabulary, snapshot), total, page: selectedPage, pageSize: selectedSize, snapshot: clone(snapshot) };
    }

    async function resolveVocabularyTerms(vocabulary, selectedTerms, { includeAncestors = true, signal = null, snapshot: suppliedSnapshot = null } = {}) {
      const selected = (Array.isArray(selectedTerms) ? selectedTerms : []).map((term) => boundedText(term?.uri || term, 1500)).filter((uri) => /^https?:\/\/\S+$/.test(uri));
      if (!selected.length) throw new SemanticCatalogError("EMPTY_SELECTION", "Select at least one vocabulary class to import.");
      if (selected.length > 25) throw new SemanticCatalogError("SELECTION_TOO_LARGE", "Import at most 25 explicitly selected classes at a time.");
      const snapshot = suppliedSnapshot || selectedTerms[0]?.snapshot || await findVocabularySnapshot(vocabulary, signal);
      const graph = sparqlIri(snapshot.graph);
      const namespace = boundedText(snapshot.namespace || vocabulary.namespace, 1500);
      let uris = selected;
      if (includeAncestors) {
        const seen = new Set(selected);
        let frontier = selected;
        for (let depth = 0; depth < 12 && frontier.length && seen.size < 100; depth += 1) {
          const parents = await query(`SELECT DISTINCT ?term WHERE { GRAPH ${graph} {
            VALUES ?child { ${frontier.map(sparqlIri).join(" ")} }
            ?child <${RDFS_SUBCLASS}> ?term .
            ?term <${PREFIX_IRI}> ?prefixed . ${namespace ? `FILTER(STRSTARTS(STR(?term), ${sparqlText(namespace)}))` : `FILTER(STRSTARTS(LCASE(STR(?prefixed)), ${sparqlText(`${vocabulary.prefix.toLowerCase()}:`)}))`}
          } } LIMIT 100`, signal);
          const next = uniqueStrings(bindings(parents).map((row) => row.term?.value), 100).filter((uri) => !seen.has(uri));
          next.forEach((uri) => seen.add(uri));
          frontier = next;
        }
        uris = [...seen].slice(0, 100);
      }
      const details = await query(`SELECT DISTINCT ?term ?prefixed ?label ?comment ?parent WHERE { GRAPH ${graph} {
        VALUES ?term { ${uris.map(sparqlIri).join(" ")} }
        ?term <${PREFIX_IRI}> ?prefixed .
        OPTIONAL { ?term <${PREF_LABEL}> ?label }
        OPTIONAL { ?term <${RDFS_COMMENT}> ?comment FILTER(LANG(?comment) = "" || LANGMATCHES(LANG(?comment), "en")) }
        OPTIONAL { ?term <${RDFS_SUBCLASS}> ?parent FILTER(ISIRI(?parent)) }
      } } ORDER BY LCASE(STR(?prefixed))`, signal);
      return { terms: termsFromRows(bindings(details), vocabulary, snapshot), snapshot, selectedCount: selected.length };
    }

    async function resolveVocabularyProperties(vocabulary, terms, snapshot, { signal = null, propertyLimit = 100 } = {}) {
      const uris = uniqueStrings((Array.isArray(terms) ? terms : []).map((term) => term.uri), 100);
      if (!uris.length) return [];
      const graph = sparqlIri(snapshot.graph);
      const selectedValues = uris.map(sparqlIri).join(" ");
      const value = await query(`SELECT DISTINCT ?property ?predicate ?value WHERE { GRAPH ${graph} {
        VALUES ?selected { ${selectedValues} }
        { ?property <${RDFS_DOMAIN}> ?selected } UNION { ?property <${RDFS_RANGE}> ?selected }
        ?property ?predicate ?value .
        FILTER(?predicate IN (<${RDFS_LABEL}>, <${RDFS_COMMENT}>, <${PREF_LABEL}>, <${PREFIX_IRI}>, <${RDFS_DOMAIN}>, <${RDFS_RANGE}>))
      } } LIMIT ${Math.max(20, Math.min(1200, Number(propertyLimit) * 12 || 1200))}`, signal);
      const properties = new Map();
      for (const row of bindings(value)) {
        const uri = boundedText(row.property?.value, 1500);
        if (!uri) continue;
        const property = properties.get(uri) || { uri, domains: [], ranges: [] };
        const predicate = row.predicate?.value;
        const result = row.value?.value;
        if ((predicate === PREFIX_IRI || predicate === PREF_LABEL || predicate === RDFS_LABEL) && !property[predicate === PREFIX_IRI ? "prefixedName" : "label"]) property[predicate === PREFIX_IRI ? "prefixedName" : "label"] = result;
        else if (predicate === RDFS_COMMENT && !property.description) property.description = result;
        else if (predicate === RDFS_DOMAIN && row.value?.type === "uri") property.domains.push(result);
        else if (predicate === RDFS_RANGE && row.value?.type === "uri") property.ranges.push(result);
        properties.set(uri, property);
        if (properties.size >= propertyLimit) break;
      }
      return [...properties.values()].map((property) => ({
        ...property,
        prefixedName: boundedText(property.prefixedName, 500) || `${vocabulary.prefix}:${localName("", property.uri)}`,
        label: boundedText(property.label, 160) || localName(property.prefixedName, property.uri),
        description: boundedText(property.description, 1000) || `Relationship declared by ${vocabulary.prefix}.`,
        domains: uniqueStrings(property.domains), ranges: uniqueStrings(property.ranges)
      }));
    }

    async function enrichTerm(term, { signal = null, propertyLimit = 80 } = {}) {
      const snapshot = await findSnapshot(term, signal);
      const graph = sparqlIri(snapshot.graph);
      const iri = sparqlIri(term.uri);
      const value = await query(`SELECT DISTINCT ?direction ?subject ?predicate ?object WHERE {
        GRAPH ${graph} {
          { BIND("term" AS ?direction) BIND(${iri} AS ?subject) ${iri} ?predicate ?object }
          UNION
          { BIND("property" AS ?direction) ?subject ?predicate ${iri} BIND(${iri} AS ?object) FILTER(?predicate IN (<${RDFS_DOMAIN}>, <${RDFS_RANGE}>)) }
        }
      } LIMIT ${Math.max(20, Math.min(400, Number(propertyLimit) * 5 || 400))}`, signal);
      const rows = bindings(value);
      const statements = rows.filter((row) => row.direction?.value === "term");
      const firstLiteral = (...predicates) => statements.find((row) => predicates.includes(row.predicate?.value) && ["literal", "typed-literal"].includes(row.object?.type))?.object?.value || "";
      const prefixedName = boundedText(firstLiteral(PREFIX_IRI), 500) || term.prefixedName;
      const parents = uniqueStrings(statements.filter((row) => row.predicate?.value === RDFS_SUBCLASS && row.object?.type === "uri").map((row) => row.object.value));
      const propertiesByUri = new Map();
      for (const row of rows.filter((candidate) => candidate.direction?.value === "property")) {
        const uri = boundedText(row.subject?.value, 1500);
        if (!uri || propertiesByUri.size >= propertyLimit) continue;
        const property = propertiesByUri.get(uri) || { uri, domains: [], ranges: [] };
        if (row.predicate?.value === RDFS_DOMAIN) property.domains.push(term.uri);
        else property.ranges.push(term.uri);
        propertiesByUri.set(uri, property);
      }
      const propertyUris = [...propertiesByUri.keys()];
      if (propertyUris.length) {
        const details = await query(`SELECT DISTINCT ?property ?predicate ?value WHERE { GRAPH ${graph} { VALUES ?property { ${propertyUris.map(sparqlIri).join(" ")} } ?property ?predicate ?value FILTER(?predicate IN (<${RDFS_LABEL}>, <${RDFS_COMMENT}>, <${PREF_LABEL}>, <${PREFIX_IRI}>, <${RDFS_DOMAIN}>, <${RDFS_RANGE}>)) } } LIMIT ${Math.min(800, propertyUris.length * 12)}`, signal);
        for (const row of bindings(details)) {
          const property = propertiesByUri.get(row.property?.value);
          if (!property) continue;
          const predicate = row.predicate?.value;
          const result = row.value?.value;
          if ((predicate === PREFIX_IRI || predicate === PREF_LABEL || predicate === RDFS_LABEL) && !property[predicate === PREFIX_IRI ? "prefixedName" : "label"]) property[predicate === PREFIX_IRI ? "prefixedName" : "label"] = result;
          else if (predicate === RDFS_COMMENT && !property.description) property.description = result;
          else if (predicate === RDFS_DOMAIN && row.value?.type === "uri") property.domains.push(result);
          else if (predicate === RDFS_RANGE && row.value?.type === "uri") property.ranges.push(result);
        }
      }
      let properties = [...propertiesByUri.values()].map((property) => ({
        ...property,
        prefixedName: boundedText(property.prefixedName, 500) || `${term.vocabulary.prefix}:${localName("", property.uri)}`,
        label: boundedText(property.label, 160) || localName(property.prefixedName, property.uri),
        description: boundedText(property.description, 1000) || `Relationship declared for ${term.prefixedName}.`,
        domains: uniqueStrings(property.domains),
        ranges: uniqueStrings(property.ranges)
      }));
      if (term.termType === "property") {
        properties = [{
          uri: term.uri,
          prefixedName,
          label: boundedText(firstLiteral(PREF_LABEL, RDFS_LABEL), 160) || term.label,
          description: boundedText(firstLiteral(RDFS_COMMENT), 1000) || term.description || `Imported ${prefixedName} property.`,
          domains: uniqueStrings(statements.filter((row) => row.predicate?.value === RDFS_DOMAIN && row.object?.type === "uri").map((row) => row.object.value)),
          ranges: uniqueStrings(statements.filter((row) => row.predicate?.value === RDFS_RANGE && row.object?.type === "uri").map((row) => row.object.value))
        }];
      }
      return {
        term: {
          ...clone(term), prefixedName, label: boundedText(firstLiteral(PREF_LABEL, RDFS_LABEL), 160) || term.label,
          description: boundedText(firstLiteral(RDFS_COMMENT), 1000) || term.description,
          parents
        },
        properties,
        snapshot: { ...snapshot, endpoint, retrievedAt: new Date().toISOString() }
      };
    }
    return Object.freeze({ browseVocabulary, enrichTerm, findSnapshot, findVocabularySnapshot, resolveVocabularyProperties, resolveVocabularyTerms, query });
  }

  function createLovPortalDiscovery({ enrichment, storage = null, cacheTtlMs = DEFAULT_METADATA_CACHE_TTL, now = () => Date.now() } = {}) {
    let memoryIndex = null;
    let indexPromise = null;

    async function readStoredIndex() {
      if (!storage?.get) return null;
      try {
        const value = await storage.get(METADATA_CACHE_KEY);
        const cached = value?.[METADATA_CACHE_KEY];
        if (cached?.version !== METADATA_CACHE_VERSION || !Array.isArray(cached.vocabularies) || !Array.isArray(cached.categories)) return null;
        if (now() - Number(cached.storedAt || 0) >= cacheTtlMs) return null;
        return cached;
      } catch { return null; }
    }

    async function writeStoredIndex(index) {
      if (!storage?.set) return;
      try { await storage.set({ [METADATA_CACHE_KEY]: clone(index) }); } catch { /* The in-memory catalog remains usable. */ }
    }

    function resourceName(uri) {
      const tail = boundedText(uri, 1500).split("/").filter(Boolean).at(-1) || "";
      try { return decodeURIComponent(tail.replace(/\+/g, " ")); } catch { return tail; }
    }

    async function fetchIndex(signal) {
      const [ontologyValue, categoryValue, submissionValue] = await Promise.all([
        enrichment.query(`SELECT DISTINCT ?ontology ?acronym ?name ?category ?group WHERE { GRAPH <${LOVPORTAL_ONTOLOGY_GRAPH}> {
          ?ontology a <http://data.bioontology.org/metadata/Ontology> ; <${OMV_ACRONYM}> ?acronym ; <${OMV_NAME}> ?name .
          OPTIONAL { ?ontology <${OMV_DOMAIN}> ?category }
          OPTIONAL { ?ontology <${METADATA_GROUP}> ?group }
        } } ORDER BY LCASE(STR(?name))`, signal),
        enrichment.query(`SELECT DISTINCT ?category ?acronym ?name ?description WHERE { GRAPH <${LOVPORTAL_CATEGORY_GRAPH}> {
          ?category a <http://data.bioontology.org/metadata/Category> .
          OPTIONAL { ?category <${METADATA_ACRONYM}> ?acronym }
          OPTIONAL { ?category <${METADATA_NAME}> ?name }
          OPTIONAL { ?category <${METADATA_DESCRIPTION}> ?description }
        } } ORDER BY LCASE(STR(?name))`, signal),
        enrichment.query(`SELECT DISTINCT ?submission ?ontology ?submissionId ?namespace ?uri ?description ?released WHERE { GRAPH <${LOVPORTAL_SUBMISSION_GRAPH}> {
          { SELECT ?ontology (MAX(xsd:integer(?candidateId)) AS ?latestId) WHERE {
            ?candidate <${METADATA_ONTOLOGY}> ?ontology ; <${METADATA_SUBMISSION_ID}> ?candidateId
          } GROUP BY ?ontology }
          ?submission <${METADATA_ONTOLOGY}> ?ontology ; <${METADATA_SUBMISSION_ID}> ?submissionId .
          FILTER(xsd:integer(?submissionId) = ?latestId)
          OPTIONAL { ?submission <${VANN_NAMESPACE}> ?namespace }
          OPTIONAL { ?submission <${OMV_URI}> ?uri }
          OPTIONAL { ?submission <${OMV_DESCRIPTION}> ?description }
          OPTIONAL { ?submission <http://data.bioontology.org/metadata/released> ?released }
        } }`, signal)
      ]);
      const categories = new Map();
      for (const row of bindings(categoryValue)) {
        const uri = boundedText(row.category?.value, 1500);
        if (!uri) continue;
        categories.set(uri, {
          id: uri, acronym: boundedText(row.acronym?.value, 160) || resourceName(uri),
          label: boundedText(row.name?.value, 160) || resourceName(uri),
          description: boundedText(row.description?.value, 1000), count: 0
        });
      }
      const snapshots = new Map();
      for (const row of bindings(submissionValue)) {
        const ontology = boundedText(row.ontology?.value, 1500);
        const graph = boundedText(row.submission?.value, 1500);
        const parsed = graphSubmission(graph);
        if (!ontology || !parsed) continue;
        snapshots.set(ontology, {
          graph, ...parsed, endpoint: LOVPORTAL_SPARQL_URL,
          namespace: boundedText(row.namespace?.value, 1500), canonicalUri: boundedText(row.uri?.value, 1500),
          description: boundedText(row.description?.value, 1000), released: boundedText(row.released?.value, 100)
        });
      }
      const records = new Map();
      for (const row of bindings(ontologyValue)) {
        const catalogUri = boundedText(row.ontology?.value, 1500);
        const acronym = boundedText(row.acronym?.value, 160);
        if (!catalogUri || !acronym) continue;
        const record = records.get(catalogUri) || {
          kind: "catalogVocabulary", catalogUri, acronym, prefix: acronym.toLowerCase(),
          label: boundedText(row.name?.value, 160) || acronym, description: "", uri: catalogUri,
          tags: [], categoryIds: [], groups: [], languages: [], score: 0,
          provenance: {
            curator: { id: "lov", label: "Linked Open Vocabularies", url: "https://lov.linkeddata.es/dataset/lov" },
            discoveredThrough: { id: "lovportal-sparql", url: LOVPORTAL_SPARQL_URL }
          }
        };
        const categoryUri = boundedText(row.category?.value, 1500);
        if (categoryUri && !record.categoryIds.includes(categoryUri)) record.categoryIds.push(categoryUri);
        const groupUri = boundedText(row.group?.value, 1500);
        if (groupUri && !record.groups.includes(resourceName(groupUri))) record.groups.push(resourceName(groupUri));
        records.set(catalogUri, record);
      }
      for (const record of records.values()) {
        const snapshot = snapshots.get(record.catalogUri);
        if (snapshot) {
          record.snapshot = snapshot;
          record.uri = snapshot.canonicalUri || record.catalogUri;
          record.namespace = snapshot.namespace;
          record.description = snapshot.description;
        }
        record.tags = record.categoryIds.map((id) => categories.get(id)?.label || resourceName(id));
        for (const id of record.categoryIds) if (categories.has(id)) categories.get(id).count += 1;
      }
      return {
        version: METADATA_CACHE_VERSION, storedAt: now(),
        vocabularies: [...records.values()].sort((left, right) => left.label.localeCompare(right.label)),
        categories: [...categories.values()].filter((category) => category.count > 0).sort((left, right) => left.label.localeCompare(right.label))
      };
    }

    async function loadIndex({ signal = null, force = false } = {}) {
      if (!force && memoryIndex && now() - memoryIndex.storedAt < cacheTtlMs) return clone(memoryIndex);
      if (!force && indexPromise) return clone(await indexPromise);
      indexPromise = (async () => {
        if (!force) {
          const stored = await readStoredIndex();
          if (stored) { memoryIndex = stored; return stored; }
        }
        const fetched = await fetchIndex(signal);
        await writeStoredIndex(fetched);
        memoryIndex = fetched;
        return fetched;
      })();
      try { return clone(await indexPromise); }
      finally { indexPromise = null; }
    }

    function textScore(record, queryText) {
      const query = queryText.toLowerCase();
      if (!query) return 1;
      const prefix = record.prefix.toLowerCase();
      const label = record.label.toLowerCase();
      if (prefix === query || label === query) return 100;
      if (prefix.startsWith(query) || label.startsWith(query)) return 80;
      if (`${prefix} ${label}`.includes(query)) return 60;
      if (`${record.description} ${record.tags.join(" ")} ${record.groups.join(" ")}`.toLowerCase().includes(query)) return 30;
      return 0;
    }

    async function listCategories({ signal = null, force = false } = {}) {
      const index = await loadIndex({ signal, force });
      return { items: index.categories, total: index.categories.length, cachedAt: new Date(index.storedAt).toISOString() };
    }

    async function searchVocabularies({ query: queryText = "", category = "", page = 1, pageSize = 15, signal = null } = {}) {
      const index = await loadIndex({ signal });
      const text = boundedText(queryText, 300).toLowerCase();
      const categoryId = boundedText(category, 1500);
      const matched = index.vocabularies.map((record) => ({ ...record, score: textScore(record, text) }))
        .filter((record) => record.score > 0 && (!categoryId || record.categoryIds.includes(categoryId)))
        .sort((left, right) => right.score - left.score || left.label.localeCompare(right.label));
      const selectedPage = Math.max(1, Number(page) || 1);
      const selectedSize = Math.max(1, Math.min(MAX_PAGE_SIZE, Number(pageSize) || 15));
      const start = (selectedPage - 1) * selectedSize;
      return {
        items: clone(matched.slice(start, start + selectedSize)), total: matched.length, page: selectedPage, pageSize: selectedSize,
        facets: { categories: { buckets: index.categories.map((item) => ({ key: item.id, label: item.label, doc_count: item.count })) } },
        cachedAt: new Date(index.storedAt).toISOString()
      };
    }

    function searchTokens(queryText) {
      const tokens = boundedText(queryText, 300).normalize("NFKC").match(/[\p{L}\p{N}_-]+/gu) || [];
      if (!tokens.length) throw new SemanticCatalogError("INVALID_QUERY", "Enter a class or property name to search LovPortal.");
      return tokens.slice(-4).map((token) => token.toLowerCase());
    }

    async function searchTerms({ query: queryText, types = ["class", "property"], page = 1, pageSize = 20, signal = null } = {}) {
      const index = await loadIndex({ signal });
      const byAcronym = new Map(index.vocabularies.map((record) => [record.acronym.toLowerCase(), record]));
      const selectedTypes = [...new Set((Array.isArray(types) ? types : [types]).filter((type) => type === "class" || type === "property"))];
      if (!selectedTypes.length) throw new SemanticCatalogError("INVALID_QUERY", "Choose classes, properties, or both.");
      const kindUris = [];
      if (selectedTypes.includes("class")) kindUris.push(OWL_CLASS, RDFS_CLASS);
      if (selectedTypes.includes("property")) kindUris.push(RDF_PROPERTY, OWL_OBJECT_PROPERTY, OWL_DATATYPE_PROPERTY, OWL_ANNOTATION_PROPERTY);
      const tokens = searchTokens(queryText);
      const expression = tokens.map((token) => `'${token}*'`).join(" AND ");
      const uriFilter = tokens.map((token) => `CONTAINS(LCASE(STR(?term)), ${sparqlText(token)})`).join(" && ");
      const value = await enrichment.query(`SELECT DISTINCT ?g ?term ?kind ?prefLabel ?rdfsLabel ?prefixed ?searchText ?ftScore WHERE { GRAPH ?g {
        ?term a ?kind . VALUES ?kind { ${kindUris.map(sparqlIri).join(" ")} }
        OPTIONAL { ?term <${PREF_LABEL}> ?prefLabel }
        OPTIONAL { ?term <${RDFS_LABEL}> ?rdfsLabel }
        OPTIONAL { ?term <${PREFIX_IRI}> ?prefixed }
        {
          ?term ?searchPredicate ?searchText .
          VALUES ?searchPredicate { <${PREF_LABEL}> <${RDFS_LABEL}> <${PREFIX_IRI}> }
          ?searchText bif:contains ${sparqlText(expression)} OPTION (score ?ftScore)
        }
        UNION { FILTER(${uriFilter}) }
      } } ORDER BY DESC(?ftScore) LIMIT ${MAX_REMOTE_SEARCH_RESULTS}`, signal);
      const queryLower = boundedText(queryText, 300).toLowerCase();
      const candidates = [];
      for (const row of bindings(value)) {
        const graph = boundedText(row.g?.value, 1500);
        const parsed = graphSubmission(graph);
        const uri = boundedText(row.term?.value, 1500);
        const label = boundedText(row.prefLabel?.value || row.rdfsLabel?.value || row.searchText?.value || row.label?.value, 160) || localName("", uri);
        if (!parsed || !uri || !label) continue;
        const vocabulary = byAcronym.get(parsed.acronym.toLowerCase());
        if (vocabulary?.snapshot?.graph && vocabulary.snapshot.graph !== graph) continue;
        const propertyKinds = new Set([RDF_PROPERTY, OWL_OBJECT_PROPERTY, OWL_DATATYPE_PROPERTY, OWL_ANNOTATION_PROPERTY]);
        const termType = propertyKinds.has(row.kind?.value) ? "property" : "class";
        const vocabularyPrefix = vocabulary?.prefix || parsed.acronym.toLowerCase();
        const rawPrefixed = boundedText(row.prefixed?.value, 500);
        const prefixedName = rawPrefixed ? (rawPrefixed.includes(":") ? rawPrefixed : `${vocabularyPrefix}:${rawPrefixed}`) : `${vocabularyPrefix}:${localName("", uri)}`;
        const local = localName(prefixedName, uri).toLowerCase();
        const owner = Boolean(vocabulary?.namespace && uri.startsWith(vocabulary.namespace));
        const lexical = label.toLowerCase() === queryLower || local === queryLower ? 100 : label.toLowerCase().startsWith(queryLower) || local.startsWith(queryLower) ? 70 : 40;
        candidates.push({
          kind: "catalogTerm", termType, uri, prefixedName, label, description: "",
          vocabulary: { prefix: vocabulary?.prefix || parsed.acronym.toLowerCase(), acronym: parsed.acronym, label: vocabulary?.label || parsed.acronym },
          tags: clone(vocabulary?.tags || []), metrics: { occurrencesInVocabularies: 0, occurrencesInDatasets: 0, reusedByVocabularies: 0, reusedByDatasets: 0 },
          score: lexical + (owner ? 20 : 0) + (Number(row.ftScore?.value) || 0), snapshot: clone(vocabulary?.snapshot || { graph, ...parsed, endpoint: LOVPORTAL_SPARQL_URL }),
          provenance: {
            curator: { id: "lov", label: "Linked Open Vocabularies", url: "https://lov.linkeddata.es/dataset/lov" },
            discoveredThrough: { id: "lovportal-sparql", url: LOVPORTAL_SPARQL_URL }
          }, owner
        });
      }
      const deduped = new Map();
      for (const term of candidates.sort((left, right) => right.score - left.score || left.label.localeCompare(right.label))) {
        const key = `${term.termType}\u001f${term.uri}`;
        if (!deduped.has(key)) deduped.set(key, term);
      }
      const terms = [...deduped.values()];
      const selectedPage = Math.max(1, Number(page) || 1);
      const selectedSize = Math.max(1, Math.min(MAX_PAGE_SIZE, Number(pageSize) || 20));
      const start = (selectedPage - 1) * selectedSize;
      return { items: clone(terms.slice(start, start + selectedSize)), total: terms.length, page: selectedPage, pageSize: selectedSize, capped: bindings(value).length >= MAX_REMOTE_SEARCH_RESULTS };
    }

    function clearMetadataCache() {
      memoryIndex = null;
      indexPromise = null;
      if (storage?.remove) return storage.remove(METADATA_CACHE_KEY).catch?.(() => undefined);
      if (storage?.set) return storage.set({ [METADATA_CACHE_KEY]: null }).catch?.(() => undefined);
      return undefined;
    }

    return Object.freeze({ clearMetadataCache, listCategories, loadIndex, searchTerms, searchVocabularies });
  }

  function importedProvenance(term, snapshot) {
    return {
      source: { id: "lov", label: "Linked Open Vocabularies", url: "https://lov.linkeddata.es/dataset/lov" },
      retrievedThrough: { id: "lovportal-sparql", label: "LovPortal SPARQL", url: snapshot.endpoint },
      canonicalUri: term.uri,
      vocabulary: { prefix: term.vocabulary.prefix, acronym: snapshot.acronym, graph: snapshot.graph, submissionId: snapshot.submissionId },
      categories: term.tags.map((label) => ({ id: `lov:${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`, label, source: { id: "lov" } })),
      retrievedAt: snapshot.retrievedAt
    };
  }

  function buildImportProposal(enriched, { includeProperties = true } = {}) {
    const { term, snapshot } = enriched;
    const provenance = importedProvenance(term, snapshot);
    const customTypes = term.termType === "class" ? [{
      id: term.prefixedName,
      label: term.label,
      description: term.description || `Imported ${term.prefixedName} class.`,
      definition: {
        kind: "type", description: term.description || `Imported ${term.prefixedName} class.`, valueType: term.prefixedName,
        cardinality: "one", example: term.label, canonicalUri: term.uri, ...(term.parents.length ? { supers: term.parents } : {})
      },
      provenance
    }] : [];
    const properties = (includeProperties || term.termType === "property") ? enriched.properties.map((property) => ({
      id: property.prefixedName,
      label: property.label,
      description: property.description,
      definition: {
        kind: "relationship", description: property.description, valueType: property.ranges[0] || "Thing", cardinality: "one", example: property.label,
        canonicalUri: property.uri, domainIncludes: property.domains.length ? property.domains : [term.uri], rangeIncludes: property.ranges.length ? property.ranges : ["Thing"]
      },
      provenance: { ...clone(provenance), canonicalUri: property.uri }
    })) : [];
    return {
      source: "semantic-catalog",
      label: `Import ${term.prefixedName}`,
      requested: { kind: term.termType, id: term.prefixedName, canonicalUri: term.uri },
      records: { customTypes, properties },
      snapshot: clone(snapshot),
      warnings: enriched.properties.length >= 80 ? ["Related properties were capped at 80 for this import preview."] : []
    };
  }

  function buildVocabularyImportProposal(vocabulary, resolved, properties = []) {
    const { terms, snapshot, selectedCount } = resolved;
    const customTypes = terms.map((term) => ({
      id: term.prefixedName,
      label: term.label,
      description: term.description || `Imported ${term.prefixedName} class.`,
      definition: {
        kind: "type", description: term.description || `Imported ${term.prefixedName} class.`, valueType: term.prefixedName,
        cardinality: "one", example: term.label, canonicalUri: term.uri, ...(term.parents.length ? { supers: term.parents } : {})
      },
      provenance: importedProvenance(term, snapshot)
    }));
    const propertyRecords = properties.map((property) => ({
      id: property.prefixedName,
      label: property.label,
      description: property.description,
      definition: {
        kind: "relationship", description: property.description, valueType: property.ranges[0] || "Thing", cardinality: "one", example: property.label,
        canonicalUri: property.uri, domainIncludes: property.domains.length ? property.domains : terms.map((term) => term.uri), rangeIncludes: property.ranges.length ? property.ranges : ["Thing"]
      },
      provenance: { ...importedProvenance(terms[0], snapshot), canonicalUri: property.uri }
    }));
    return {
      source: "semantic-catalog",
      label: `Import ${vocabulary.prefix} vocabulary selection`,
      requested: { kind: "vocabularySubset", id: vocabulary.prefix, canonicalUri: vocabulary.uri, selectedCount },
      records: { customTypes, properties: propertyRecords },
      snapshot: clone(snapshot),
      hierarchy: { selectedCount, includedAncestorCount: Math.max(0, terms.length - selectedCount) },
      warnings: terms.length >= 100 ? ["The connected hierarchy was capped at 100 classes."] : []
    };
  }

  function create({
    fetchImpl = globalThis.fetch, timeoutMs = 30000, cacheTtlMs = 5 * 60 * 1000,
    metadataCacheTtlMs = DEFAULT_METADATA_CACHE_TTL, storage = globalThis.chrome?.storage?.local || null,
    lovPortalEndpoint = LOVPORTAL_SPARQL_URL
  } = {}) {
    const requester = createRequester({ fetchImpl, timeoutMs, cacheTtlMs });
    const enrichment = createLovPortalEnrichment({ request: requester.request, endpoint: lovPortalEndpoint });
    const discovery = createLovPortalDiscovery({ enrichment, storage, cacheTtlMs: metadataCacheTtlMs });
    return Object.freeze({
      searchTerms: discovery.searchTerms,
      searchVocabularies: discovery.searchVocabularies,
      listCategories: discovery.listCategories,
      enrichTerm: enrichment.enrichTerm,
      async planTermImport(term, options = {}) { return buildImportProposal(await enrichment.enrichTerm(term, options), options); },
      browseVocabulary: enrichment.browseVocabulary,
      async planVocabularyImport(vocabulary, selectedTerms, options = {}) {
        const resolved = await enrichment.resolveVocabularyTerms(vocabulary, selectedTerms, options);
        const properties = options.includeProperties === false ? [] : await enrichment.resolveVocabularyProperties(vocabulary, resolved.terms, resolved.snapshot, options);
        return buildVocabularyImportProposal(vocabulary, resolved, properties);
      },
      clearCache() { requester.clearCache(); return discovery.clearMetadataCache(); }
    });
  }

  return Object.freeze({
    DEFAULT_METADATA_CACHE_TTL, LOVPORTAL_SPARQL_URL, METADATA_CACHE_KEY, SemanticCatalogError,
    buildImportProposal, buildVocabularyImportProposal, create, createLovPortalDiscovery,
    createLovPortalEnrichment
  });
});
