(function initializeDsl(root, factory) {
  "use strict";
  const utils = root.Site2JsonUtils || (typeof require === "function" ? require("./utils") : null);
  const transforms = root.Site2JsonTransforms || (typeof require === "function" ? require("./transforms") : null);
  const variantClassifier = root.Site2JsonVariantClassifier || (typeof require === "function" ? require("./variant-classifier") : null);
  const api = factory(utils, transforms, variantClassifier);
  root.Site2JsonDsl = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function dslFactory(utils, transforms, variantClassifier) {
  "use strict";

  const DSL_VERSION = 1;
  const TOP_LEVEL_KEYS = new Set(["adapter", "version", "dslVersion", "namespace", "vocabulary", "hosts", "entities", "pages", "authoring"]);
  const AUTHORING_KEYS = new Set(["version", "knowledge", "decisions"]);
  const AUTHORING_KNOWLEDGE_KEYS = new Set(["id", "kind", "term", "revision", "digest", "provenance", "profile"]);
  const AUTHORING_DECISION_KEYS = new Set(["id", "page", "block", "entity", "field", "property", "status", "confidence", "acceptedByAuthor", "knowledgeRefs", "report"]);
  const VOCABULARY_KEYS = new Set(["terms"]);
  const TERM_KEYS = new Set(["description", "valueType", "cardinality", "example", "kind", "domainIncludes", "rangeIncludes", "evidenceAliases", "supers", "canonicalUri"]);
  const ENTITY_KEYS = new Set(["schemaType", "identity", "fields"]);
  const IDENTITY_KEYS = new Set(["field", "canonicalUrl"]);
  const BINDING_KEYS = new Set(["selectors", "source", "transform", "multiple", "aggregate"]);
  const PAGE_KEYS = new Set(["id", "match", "pageType", "metadata", "fixture", "blocks"]);
  const MATCH_KEYS = new Set(["host", "path", "assert", "url"]);
  const PATH_KEYS = new Set(["mode", "value"]);
  const PAGE_METADATA_KEYS = new Set(["pageTitle", "collectionKey", "snapshotKey", "logicalPosition", "page"]);
  const PAGE_BINDING_KEYS = new Set(["source", "value", "transform"]);
  const FIXTURE_KEYS = new Set(["format", "source", "digest", "bytes", "capturedAt"]);
  const BLOCK_KEYS = new Set(["entity", "scope", "arity", "role", "fidelity", "fields", "require", "monitor", "variants", "variantSlots", "structuralBaseline"]);
  const VARIANTS_KEYS = new Set(["fallback", "candidates", "minScore", "minMargin"]);
  const VARIANT_CANDIDATE_KEYS = new Set(["entity", "signals", "evidence"]);
  const VARIANT_SIGNAL_KEYS = new Set(["field", "kind", "weight"]);
  const VARIANT_EVIDENCE_KEYS = new Set(["selector", "field", "attribute", "equals", "weight"]);
  const VARIANT_SLOT_KEYS = new Set(["path", "fallback", "candidates", "minScore", "minMargin"]);
  const STRUCTURAL_BASELINE_KEYS = new Set(["version", "scope", "variants", "variantSlots"]);
  const STRUCTURAL_SLOT_KEYS = new Set(["sampleSize", "counts"]);
  const STRUCTURAL_SCOPE_KEYS = new Set(["typical", "minimum"]);
  const STRUCTURAL_VARIANT_KEYS = new Set(["sampleSize", "shapes", "fields", "evidence"]);
  const STRUCTURAL_SHAPE_KEYS = new Set(["fingerprint", "frequency"]);
  const STRUCTURAL_FIELD_KEYS = new Set(["coverage", "matchesPerItem"]);
  const STRUCTURAL_EVIDENCE_KEYS = new Set(["candidate", "rule", "coverage"]);
  const ROLES = new Set(["primary", "collection", "related", "navigation"]);
  const FIDELITIES = new Set(["summary", "full"]);
  const VARIANT_SIGNAL_KINDS = new Set(["field", "identity", "relationship"]);

  if (!variantClassifier?.classify) throw new Error("The variant classifier is unavailable.");

  function isRecord(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
  }

  function isDataValue(value) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return true;
    if (typeof value === "number") return Number.isFinite(value);
    if (Array.isArray(value)) return value.every(isDataValue);
    if (isRecord(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null)) return Object.values(value).every(isDataValue);
    return false;
  }

  function rejectUnknown(value, allowed, label) {
    if (!isRecord(value)) throw new Error(`${label} must be an object.`);
    const unknown = Object.keys(value).find((key) => !allowed.has(key));
    if (unknown) throw new Error(`Unknown ${label} key: ${unknown}`);
  }

  function stringArray(value, label, { allowEmpty = false } = {}) {
    if (!Array.isArray(value) || (!allowEmpty && value.length === 0) || value.some((item) => typeof item !== "string" || !item)) {
      throw new Error(`${label} must be ${allowEmpty ? "an" : "a non-empty"} array of strings.`);
    }
  }

  function boundedInert(value, label, maximum = 100000) {
    if (!isDataValue(value)) throw new Error(`${label} must contain inert data only.`);
    if (JSON.stringify(value).length > maximum) throw new Error(`${label} is too large.`);
  }

  function boundedString(value, label, maximum = 512) {
    if (typeof value !== "string" || !value || value.length > maximum) throw new Error(`${label} must be a non-empty string no longer than ${maximum} characters.`);
  }

  function validateAuthoring(authoring) {
    rejectUnknown(authoring, AUTHORING_KEYS, "authoring");
    if (authoring.version !== 1) throw new Error("authoring.version must be 1.");
    if (!Array.isArray(authoring.knowledge) || authoring.knowledge.length > 256) throw new Error("authoring.knowledge must be a bounded array.");
    if (!Array.isArray(authoring.decisions) || authoring.decisions.length > 2048) throw new Error("authoring.decisions must be a bounded array.");
    const knowledgeIds = new Set();
    for (const [index, item] of authoring.knowledge.entries()) {
      const label = `authoring.knowledge[${index}]`;
      rejectUnknown(item, AUTHORING_KNOWLEDGE_KEYS, label);
      boundedString(item.id, `${label}.id`);
      if (knowledgeIds.has(item.id)) throw new Error(`Duplicate authoring knowledge id: ${item.id}`);
      knowledgeIds.add(item.id);
      if (item.kind !== "property-profile") throw new Error(`${label}.kind is not supported.`);
      boundedString(item.term, `${label}.term`);
      if (item.revision !== null && item.revision !== undefined && (!Number.isSafeInteger(item.revision) || item.revision < 0)) throw new Error(`${label}.revision must be a non-negative integer or null.`);
      boundedString(item.digest, `${label}.digest`, 128);
      boundedInert(item.provenance, `${label}.provenance`, 20000);
      boundedInert(item.profile, `${label}.profile`, 50000);
    }
    const decisionIds = new Set();
    for (const [index, item] of authoring.decisions.entries()) {
      const label = `authoring.decisions[${index}]`;
      rejectUnknown(item, AUTHORING_DECISION_KEYS, label);
      for (const key of ["id", "page", "block", "entity", "field", "property", "status", "confidence"]) boundedString(item[key], `${label}.${key}`);
      if (decisionIds.has(item.id)) throw new Error(`Duplicate authoring decision id: ${item.id}`);
      decisionIds.add(item.id);
      if (typeof item.acceptedByAuthor !== "boolean") throw new Error(`${label}.acceptedByAuthor must be a boolean.`);
      stringArray(item.knowledgeRefs, `${label}.knowledgeRefs`, { allowEmpty: true });
      const missing = item.knowledgeRefs.find((id) => !knowledgeIds.has(id));
      if (missing) throw new Error(`${label}.knowledgeRefs references unknown knowledge ${missing}.`);
      boundedInert(item.report, `${label}.report`, 100000);
    }
    boundedInert(authoring, "authoring", 400000);
  }

  function validateBinding(binding, label) {
    rejectUnknown(binding, BINDING_KEYS, label);
    if (binding.selectors === undefined && binding.source === undefined) throw new Error(`${label} requires selectors or a packaged source.`);
    if (binding.selectors !== undefined) stringArray(binding.selectors, `${label}.selectors`);
    if (binding.source !== undefined && binding.source !== "scope" && binding.source !== "pageUrl") throw new Error(`${label}.source is not available.`);
    transforms.validatePipeline(binding.transform || []);
    if (binding.multiple !== undefined && typeof binding.multiple !== "boolean") throw new Error(`${label}.multiple must be a boolean.`);
    if (binding.aggregate !== undefined) {
      if (binding.multiple !== true) throw new Error(`${label}.aggregate requires multiple: true.`);
      transforms.validatePipeline(binding.aggregate);
    }
  }

  function identityFieldName(entity) {
    return typeof entity?.identity?.field === "string" ? entity.identity.field : null;
  }

  function identityBinding(entity) {
    const field = identityFieldName(entity);
    return field ? entity?.fields?.[field] : entity?.identity?.canonicalUrl;
  }

  function validateFieldPath(path, label) {
    if (typeof path !== "string" || !path || path.split(".").some((segment) => !segment || ["__proto__", "prototype", "constructor"].includes(segment))) {
      throw new Error(`${label} is not a safe field path.`);
    }
  }

  function validatePageBinding(binding, label) {
    rejectUnknown(binding, PAGE_BINDING_KEYS, label);
    if (!["pageUrl", "pageTitle", "language", "primaryEntityTitle", "primaryEntityUrl", "literal"].includes(binding.source)) throw new Error(`${label}.source is not available.`);
    if (binding.source === "literal") {
      if (!Object.hasOwn(binding, "value") || !isDataValue(binding.value)) throw new Error(`${label}.value must be inert data.`);
    } else if (Object.hasOwn(binding, "value")) {
      throw new Error(`${label}.value is only valid for the literal source.`);
    }
    transforms.validatePipeline(binding.transform || []);
  }

  function validatePageMetadata(metadata, label) {
    rejectUnknown(metadata, PAGE_METADATA_KEYS, label);
    for (const key of ["pageTitle", "collectionKey", "snapshotKey", "logicalPosition"]) {
      if (metadata[key] !== undefined) validatePageBinding(metadata[key], `${label}.${key}`);
    }
    if (metadata.page !== undefined) {
      if (!isRecord(metadata.page)) throw new Error(`${label}.page must be an object.`);
      for (const [field, binding] of Object.entries(metadata.page)) {
        validateFieldPath(field, `${label}.page field ${field}`);
        validatePageBinding(binding, `${label}.page.${field}`);
      }
    }
  }

  function validateFixture(fixture, label) {
    rejectUnknown(fixture, FIXTURE_KEYS, label);
    if (fixture.format !== "site2json-scrubbed-html-v1") throw new Error(`${label}.format is not supported.`);
    if (typeof fixture.source !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,159}\.html$/.test(fixture.source) || fixture.source.includes("..")) throw new Error(`${label}.source must be a safe HTML filename.`);
    if (typeof fixture.digest !== "string" || !/^sha256:[a-f0-9]{64}$/.test(fixture.digest)) throw new Error(`${label}.digest must be a SHA-256 digest.`);
    if (!Number.isSafeInteger(fixture.bytes) || fixture.bytes < 1 || fixture.bytes > 500000) throw new Error(`${label}.bytes must be an integer from 1 to 500000.`);
    if (typeof fixture.capturedAt !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(fixture.capturedAt) || Number.isNaN(Date.parse(fixture.capturedAt))) throw new Error(`${label}.capturedAt must be an ISO UTC timestamp.`);
  }

  function validateVariantCandidate(candidate, definition, candidateLabel) {
    rejectUnknown(candidate, VARIANT_CANDIDATE_KEYS, candidateLabel);
    if (!definition.entities[candidate.entity]) throw new Error(`${candidateLabel} references unknown entity ${candidate.entity}.`);
    if (!Array.isArray(candidate.signals) || candidate.signals.length > 64) throw new Error(`${candidateLabel}.signals must be an array containing no more than 64 compiled signals.`);
    for (const [signalIndex, signal] of candidate.signals.entries()) {
      const signalLabel = `${candidateLabel}.signals[${signalIndex}]`;
      rejectUnknown(signal, VARIANT_SIGNAL_KEYS, signalLabel);
      validateFieldPath(signal.field, `${signalLabel}.field`);
      if (!VARIANT_SIGNAL_KINDS.has(signal.kind)) throw new Error(`${signalLabel}.kind must be field, identity, or relationship.`);
      if (!Number.isSafeInteger(signal.weight) || signal.weight < 1 || signal.weight > 100) throw new Error(`${signalLabel}.weight must be an integer from 1 to 100.`);
    }
    if (!Array.isArray(candidate.evidence) || candidate.evidence.length > 32) throw new Error(`${candidateLabel}.evidence must be an array containing no more than 32 rules.`);
    if (!candidate.signals.length && !candidate.evidence.length) throw new Error(`${candidateLabel} requires at least one compiled signal or explicit evidence rule.`);
    for (const [ruleIndex, rule] of candidate.evidence.entries()) {
      const ruleLabel = `${candidateLabel}.evidence[${ruleIndex}]`;
      rejectUnknown(rule, VARIANT_EVIDENCE_KEYS, ruleLabel);
      const hasSelector = typeof rule.selector === "string" && Boolean(rule.selector);
      const hasField = typeof rule.field === "string" && Boolean(rule.field);
      if (hasSelector === hasField) throw new Error(`${ruleLabel} requires exactly one selector or field.`);
      if (hasField) validateFieldPath(rule.field, `${ruleLabel}.field`);
      const hasAttribute = typeof rule.attribute === "string" && Boolean(rule.attribute);
      const hasEquals = typeof rule.equals === "string";
      if (hasAttribute !== hasEquals) throw new Error(`${ruleLabel}.attribute and .equals must be provided together.`);
      if (hasField && hasAttribute) throw new Error(`${ruleLabel} field evidence cannot include an attribute comparison.`);
      if (hasAttribute && (!/^[A-Za-z_][\w:.-]*$/.test(rule.attribute) || rule.equals.length > 512)) throw new Error(`${ruleLabel} requires a safe attribute name and an equality value no longer than 512 characters.`);
      if (!Number.isSafeInteger(rule.weight) || rule.weight < 1 || rule.weight > 100) throw new Error(`${ruleLabel}.weight must be an integer from 1 to 100.`);
    }
  }

  function validateVariants(variants, definition, block, label) {
    rejectUnknown(variants, VARIANTS_KEYS, label);
    if (variants.fallback !== block.entity) throw new Error(`${label}.fallback must equal the block entity ${block.entity}.`);
    if (!Array.isArray(variants.candidates) || variants.candidates.length < 1 || variants.candidates.length > 5) {
      throw new Error(`${label}.candidates must contain between 1 and 5 candidate entities.`);
    }
    const seen = new Set();
    for (const [index, candidate] of variants.candidates.entries()) {
      const candidateLabel = `${label}.candidates[${index}]`;
      validateVariantCandidate(candidate, definition, candidateLabel);
      if (candidate.entity === variants.fallback) throw new Error(`${candidateLabel} must not repeat the fallback entity.`);
      if (seen.has(candidate.entity)) throw new Error(`${label} contains duplicate candidate entity ${candidate.entity}.`);
      seen.add(candidate.entity);
    }
    for (const key of ["minScore", "minMargin"]) {
      if (!Number.isSafeInteger(variants[key]) || variants[key] < 0 || variants[key] > 1000) throw new Error(`${label}.${key} must be a non-negative integer no greater than 1000.`);
    }
  }

  function validateVariantSlots(slots, definition, label) {
    if (!Array.isArray(slots) || slots.length < 1 || slots.length > 8) throw new Error(`${label} must contain between 1 and 8 nested variant slots.`);
    const paths = new Set();
    for (const [index, slot] of slots.entries()) {
      const slotLabel = `${label}[${index}]`;
      rejectUnknown(slot, VARIANT_SLOT_KEYS, slotLabel);
      validateFieldPath(slot.path, `${slotLabel}.path`);
      if (paths.has(slot.path)) throw new Error(`${label} contains duplicate path ${slot.path}.`);
      paths.add(slot.path);
      if (!definition.entities[slot.fallback]) throw new Error(`${slotLabel}.fallback references unknown entity ${slot.fallback}.`);
      if (!Array.isArray(slot.candidates) || slot.candidates.length < 1 || slot.candidates.length > 5) throw new Error(`${slotLabel}.candidates must contain between 1 and 5 candidate entities.`);
      const candidateEntities = new Set();
      for (const [candidateIndex, candidate] of slot.candidates.entries()) {
        const candidateLabel = `${slotLabel}.candidates[${candidateIndex}]`;
        validateVariantCandidate(candidate, definition, candidateLabel);
        if (candidate.entity === slot.fallback || candidateEntities.has(candidate.entity)) throw new Error(`${candidateLabel} must reference a unique non-fallback entity.`);
        candidateEntities.add(candidate.entity);
      }
      for (const key of ["minScore", "minMargin"]) if (!Number.isSafeInteger(slot[key]) || slot[key] < 0 || slot[key] > 1000) throw new Error(`${slotLabel}.${key} must be a non-negative integer no greater than 1000.`);
    }
  }

  function boundedRatio(value, label) {
    if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 1) throw new Error(`${label} must be a finite number from 0 to 1.`);
  }

  function validateStructuralBaseline(baseline, definition, block, label) {
    rejectUnknown(baseline, STRUCTURAL_BASELINE_KEYS, label);
    if (baseline.version !== 1) throw new Error(`${label}.version must be 1.`);
    rejectUnknown(baseline.scope, STRUCTURAL_SCOPE_KEYS, `${label}.scope`);
    for (const key of ["typical", "minimum"]) {
      if (!Number.isSafeInteger(baseline.scope[key]) || baseline.scope[key] < 0 || baseline.scope[key] > 100000) throw new Error(`${label}.scope.${key} must be an integer from 0 to 100000.`);
    }
    if (baseline.scope.minimum > baseline.scope.typical) throw new Error(`${label}.scope.minimum cannot exceed .typical.`);
    if (!isRecord(baseline.variants) || Object.keys(baseline.variants).length < 1 || Object.keys(baseline.variants).length > 6) {
      throw new Error(`${label}.variants must contain between 1 and 6 entity profiles.`);
    }
    const allowedEntities = new Set([block.entity, ...(block.variants?.candidates || []).map((candidate) => candidate.entity)]);
    for (const [entityName, profile] of Object.entries(baseline.variants)) {
      const profileLabel = `${label}.variants.${entityName}`;
      if (!allowedEntities.has(entityName) || !definition.entities[entityName]) throw new Error(`${profileLabel} is not an entity used by this block.`);
      rejectUnknown(profile, STRUCTURAL_VARIANT_KEYS, profileLabel);
      if (!Number.isSafeInteger(profile.sampleSize) || profile.sampleSize < 1 || profile.sampleSize > 100000) throw new Error(`${profileLabel}.sampleSize must be an integer from 1 to 100000.`);
      if (!Array.isArray(profile.shapes) || profile.shapes.length < 1 || profile.shapes.length > 16) throw new Error(`${profileLabel}.shapes must contain between 1 and 16 profiles.`);
      const fingerprints = new Set();
      for (const [index, shape] of profile.shapes.entries()) {
        rejectUnknown(shape, STRUCTURAL_SHAPE_KEYS, `${profileLabel}.shapes[${index}]`);
        if (typeof shape.fingerprint !== "string" || !/^s2j1:[a-f0-9]{16}$/.test(shape.fingerprint)) throw new Error(`${profileLabel}.shapes[${index}].fingerprint is invalid.`);
        if (fingerprints.has(shape.fingerprint)) throw new Error(`${profileLabel}.shapes contains a duplicate fingerprint.`);
        fingerprints.add(shape.fingerprint);
        boundedRatio(shape.frequency, `${profileLabel}.shapes[${index}].frequency`);
      }
      const frequencyTotal = profile.shapes.reduce((sum, shape) => sum + shape.frequency, 0);
      if (frequencyTotal < 0.999 || frequencyTotal > 1.001) throw new Error(`${profileLabel}.shapes frequencies must total 1.`);
      if (!isRecord(profile.fields) || Object.keys(profile.fields).length > 256) throw new Error(`${profileLabel}.fields must be a bounded object.`);
      const entityFields = new Set(["canonicalUrl", ...Object.keys(definition.entities[entityName].fields)]);
      for (const [field, stats] of Object.entries(profile.fields)) {
        if (!entityFields.has(field)) throw new Error(`${profileLabel}.fields.${field} is not declared by ${entityName}.`);
        rejectUnknown(stats, STRUCTURAL_FIELD_KEYS, `${profileLabel}.fields.${field}`);
        boundedRatio(stats.coverage, `${profileLabel}.fields.${field}.coverage`);
        if (!Array.isArray(stats.matchesPerItem) || stats.matchesPerItem.length !== 2 || stats.matchesPerItem.some((count) => !Number.isSafeInteger(count) || count < 0 || count > 10000) || stats.matchesPerItem[0] > stats.matchesPerItem[1]) {
          throw new Error(`${profileLabel}.fields.${field}.matchesPerItem must be an ordered pair of bounded integers.`);
        }
      }
      if (!Array.isArray(profile.evidence) || profile.evidence.length > 160) throw new Error(`${profileLabel}.evidence must be a bounded array.`);
      for (const [index, stats] of profile.evidence.entries()) {
        rejectUnknown(stats, STRUCTURAL_EVIDENCE_KEYS, `${profileLabel}.evidence[${index}]`);
        if (typeof stats.candidate !== "string" || !allowedEntities.has(stats.candidate)) throw new Error(`${profileLabel}.evidence[${index}].candidate is invalid.`);
        const candidate = block.variants?.candidates?.find((item) => item.entity === stats.candidate);
        if (!candidate || !Number.isSafeInteger(stats.rule) || stats.rule < 0 || stats.rule >= candidate.evidence.length) throw new Error(`${profileLabel}.evidence[${index}].rule is invalid.`);
        boundedRatio(stats.coverage, `${profileLabel}.evidence[${index}].coverage`);
      }
    }
    if (baseline.variantSlots !== undefined) {
      if (!isRecord(baseline.variantSlots) || Object.keys(baseline.variantSlots).length > 16) throw new Error(`${label}.variantSlots must be a bounded object.`);
      const slotsByPath = new Map((block.variantSlots || []).map((slot) => [slot.path, slot]));
      for (const [path, profile] of Object.entries(baseline.variantSlots)) {
        const profileLabel = `${label}.variantSlots.${path}`;
        const slot = slotsByPath.get(path);
        if (!slot) throw new Error(`${profileLabel} does not reference a variant slot used by this block.`);
        rejectUnknown(profile, STRUCTURAL_SLOT_KEYS, profileLabel);
        if (!Number.isSafeInteger(profile.sampleSize) || profile.sampleSize < 1 || profile.sampleSize > 100000) throw new Error(`${profileLabel}.sampleSize must be an integer from 1 to 100000.`);
        if (!isRecord(profile.counts)) throw new Error(`${profileLabel}.counts must be an object.`);
        const allowed = new Set([slot.fallback, ...slot.candidates.map((candidate) => candidate.entity)]);
        for (const [entityName, count] of Object.entries(profile.counts)) {
          if (!allowed.has(entityName) || !Number.isSafeInteger(count) || count < 0 || count > profile.sampleSize) throw new Error(`${profileLabel}.counts.${entityName} is invalid.`);
        }
      }
    }
  }

  function validateVocabulary(vocabulary, adapter) {
    rejectUnknown(vocabulary, VOCABULARY_KEYS, "vocabulary");
    if (!isRecord(vocabulary.terms)) throw new Error("vocabulary.terms must be an object.");
    for (const [term, definition] of Object.entries(vocabulary.terms)) {
      if (!term.startsWith(`${adapter}:`) || term.includes(".")) throw new Error(`Vocabulary term ${term} must use the adapter prefix and cannot be a nested field path.`);
      rejectUnknown(definition, TERM_KEYS, `vocabulary term ${term}`);
      if (typeof definition.description !== "string" || !definition.description.trim()) throw new Error(`Vocabulary term ${term}.description must be non-empty.`);
      if (typeof definition.valueType !== "string" || !definition.valueType) throw new Error(`Vocabulary term ${term}.valueType must be non-empty.`);
      if (!new Set(["one", "many"]).has(definition.cardinality)) throw new Error(`Vocabulary term ${term}.cardinality must be one or many.`);
      if (!Object.hasOwn(definition, "example") || !isDataValue(definition.example)) throw new Error(`Vocabulary term ${term}.example must be inert data.`);
      if (definition.kind !== undefined && !new Set(["field", "relationship", "type"]).has(definition.kind)) throw new Error(`Vocabulary term ${term}.kind must be field, relationship, or type.`);
      if (definition.canonicalUri !== undefined && (typeof definition.canonicalUri !== "string" || !/^https?:\/\/\S+$/.test(definition.canonicalUri))) throw new Error(`Vocabulary term ${term}.canonicalUri must be an absolute HTTP(S) URI.`);
      for (const key of ["domainIncludes", "rangeIncludes", "evidenceAliases", "supers"]) {
        if (definition[key] !== undefined) stringArray(definition[key], `Vocabulary term ${term}.${key}`);
      }
      if (definition.kind === "relationship" && (!definition.domainIncludes?.length || !definition.rangeIncludes?.length)) {
        throw new Error(`Vocabulary relationship ${term} requires domainIncludes and rangeIncludes.`);
      }
    }
  }

  function validatePathRules(path, label) {
    if (!Array.isArray(path) || path.length === 0) throw new Error(`${label} must be a non-empty array of path rules.`);
    for (const [index, rule] of path.entries()) {
      rejectUnknown(rule, PATH_KEYS, `${label}[${index}]`);
      if (rule.mode !== "exact" && rule.mode !== "prefix") throw new Error(`${label}[${index}].mode must be exact or prefix.`);
      if (typeof rule.value !== "string" || !rule.value.startsWith("/") || rule.value.length > 512) {
        throw new Error(`${label}[${index}].value must be an absolute path of at most 512 characters.`);
      }
      if (rule.value.includes("\\") || /[?*+()[\]{}|^$]/.test(rule.value)) {
        throw new Error(`${label}[${index}].value must be a literal path, not a pattern.`);
      }
    }
  }

  function validateDefinition(definition) {
    rejectUnknown(definition, TOP_LEVEL_KEYS, "adapter");
    if (typeof definition.adapter !== "string" || !/^[a-z][a-z0-9-]*$/.test(definition.adapter)) throw new Error("adapter must be a lowercase identifier.");
    if (!Number.isSafeInteger(definition.version) || definition.version < 1) throw new Error("version must be a positive integer.");
    if (definition.dslVersion !== DSL_VERSION) throw new Error(`Unsupported dslVersion ${definition.dslVersion}; this extension supports ${DSL_VERSION}.`);
    if (typeof definition.namespace !== "string" || !definition.namespace) throw new Error("namespace must be a non-empty string.");
    if (definition.vocabulary !== undefined) validateVocabulary(definition.vocabulary, definition.adapter);
    if (definition.authoring !== undefined) validateAuthoring(definition.authoring);
    stringArray(definition.hosts, "hosts");
    if (!isRecord(definition.entities) || Object.keys(definition.entities).length === 0) throw new Error("entities must be a non-empty object.");

    for (const [entityName, entity] of Object.entries(definition.entities)) {
      rejectUnknown(entity, ENTITY_KEYS, `entity ${entityName}`);
      if (typeof entity.schemaType !== "string" || !entity.schemaType) throw new Error(`entity ${entityName}.schemaType must be a non-empty string.`);
      if (!isRecord(entity.fields)) throw new Error(`entity ${entityName}.fields must be an object.`);
      for (const [field, binding] of Object.entries(entity.fields)) {
        validateFieldPath(field, `entity ${entityName} field ${field}`);
        validateBinding(binding, `entity ${entityName}.fields.${field}`);
      }
      rejectUnknown(entity.identity, IDENTITY_KEYS, `entity ${entityName}.identity`);
      const referencedIdentity = identityFieldName(entity);
      const legacyIdentity = entity.identity.canonicalUrl;
      if (Boolean(referencedIdentity) === Boolean(legacyIdentity)) {
        throw new Error(`entity ${entityName}.identity requires exactly one field reference or legacy canonicalUrl binding.`);
      }
      if (referencedIdentity) {
        validateFieldPath(referencedIdentity, `entity ${entityName}.identity.field`);
        if (!Object.hasOwn(entity.fields, referencedIdentity)) throw new Error(`entity ${entityName}.identity.field references unknown field ${referencedIdentity}.`);
        if (entity.fields[referencedIdentity].multiple) throw new Error(`entity ${entityName}.identity field ${referencedIdentity} must be single-valued.`);
      } else {
        validateBinding(legacyIdentity, `entity ${entityName}.identity.canonicalUrl`);
      }
    }

    if (!Array.isArray(definition.pages) || definition.pages.length === 0) throw new Error("pages must be a non-empty array.");
    const pageIds = new Set();
    for (const page of definition.pages) {
      rejectUnknown(page, PAGE_KEYS, "page");
      if (typeof page.id !== "string" || !page.id) throw new Error("A page requires an id.");
      if (pageIds.has(page.id)) throw new Error(`Duplicate page id: ${page.id}`);
      pageIds.add(page.id);
      if (typeof page.pageType !== "string" || !page.pageType) throw new Error(`Page ${page.id} requires a pageType.`);
      rejectUnknown(page.match, MATCH_KEYS, `page ${page.id}.match`);
      stringArray(page.match.host, `page ${page.id}.match.host`);
      if (page.match.host.some((host) => !definition.hosts.includes(host))) throw new Error(`Page ${page.id} declares a host outside adapter.hosts.`);
      validatePathRules(page.match.path, `Page ${page.id}.match.path`);
      if (page.match.assert !== undefined && (typeof page.match.assert !== "string" || !page.match.assert)) throw new Error(`Page ${page.id}.match.assert must be a non-empty selector.`);
      if (page.match.url !== undefined) {
        validatePageBinding(page.match.url, `Page ${page.id}.match.url`);
        if (page.match.url.source !== "pageUrl") throw new Error(`Page ${page.id}.match.url must use the pageUrl source.`);
      }
      if (page.metadata !== undefined) validatePageMetadata(page.metadata, `Page ${page.id}.metadata`);
      if (page.fixture !== undefined) validateFixture(page.fixture, `Page ${page.id}.fixture`);
      if (!Array.isArray(page.blocks) || page.blocks.length === 0) throw new Error(`Page ${page.id}.blocks must be a non-empty array.`);
      for (const block of page.blocks) {
        rejectUnknown(block, BLOCK_KEYS, `page ${page.id} block`);
        if (!definition.entities[block.entity]) throw new Error(`Page ${page.id} references unknown entity ${block.entity}.`);
        if (typeof block.scope !== "string" || !block.scope) throw new Error(`Page ${page.id} block.scope must be a non-empty selector.`);
        if (block.arity !== "one" && block.arity !== "many") throw new Error(`Page ${page.id} block has invalid arity ${block.arity}.`);
        if (!ROLES.has(block.role)) throw new Error(`Page ${page.id} block has invalid role ${block.role}.`);
        if (!FIDELITIES.has(block.fidelity)) throw new Error(`Page ${page.id} block has invalid fidelity ${block.fidelity}.`);
        if (block.variants !== undefined) validateVariants(block.variants, definition, block, `Page ${page.id} block.variants`);
        if (block.variantSlots !== undefined) validateVariantSlots(block.variantSlots, definition, `Page ${page.id} block.variantSlots`);
        if (block.structuralBaseline !== undefined) validateStructuralBaseline(block.structuralBaseline, definition, block, `Page ${page.id} block.structuralBaseline`);
        if (block.fields !== undefined) {
          stringArray(block.fields, `Page ${page.id} block.fields`);
          const unknownField = block.fields.find((field) => !Object.hasOwn(definition.entities[block.entity].fields, field));
          if (unknownField) throw new Error(`Page ${page.id} block.fields references unknown field ${unknownField}.`);
        }
        for (const key of ["require", "monitor"]) {
          if (block[key] !== undefined) stringArray(block[key], `Page ${page.id} block.${key}`, { allowEmpty: true });
        }
      }
    }
    return utils.clone(definition);
  }

  function selectorParts(selector) {
    if (selector.startsWith("xpath:")) return { xpath: selector.slice("xpath:".length), selector: null, attribute: null };
    const match = selector.match(/^(.*)@([A-Za-z_][\w:.-]*)$/);
    return match ? { xpath: null, selector: match[1], attribute: match[2] } : { xpath: null, selector, attribute: null };
  }

  function xpathNodes(scope, expression, declaredSelector) {
    if (!expression) throw new Error(`Invalid selector: ${declaredSelector}`);
    const document = scope.ownerDocument || scope;
    const XPathResult = document.defaultView?.XPathResult;
    if (!document.evaluate || !XPathResult) throw new Error("XPath is not available in this document.");
    const scopedExpression = expression.startsWith("//") ? `.${expression}` : expression;
    try {
      const result = document.evaluate(scopedExpression, scope, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      return Array.from({ length: result.snapshotLength }, (_unused, index) => result.snapshotItem(index));
    } catch {
      throw new Error(`Invalid selector: ${declaredSelector}`);
    }
  }

  function selectedValues(scope, binding) {
    for (const declaredSelector of binding.selectors || []) {
      const parsed = selectorParts(declaredSelector);
      let nodes;
      if (parsed.xpath !== null) {
        nodes = xpathNodes(scope, parsed.xpath, declaredSelector);
      } else {
        try {
          nodes = [...scope.querySelectorAll(parsed.selector)];
        } catch {
          throw new Error(`Invalid selector: ${declaredSelector}`);
        }
      }
      if (nodes.length === 0) continue;
      const selected = binding.multiple ? nodes : nodes.slice(0, 1);
      return selected.map((node) => parsed.attribute ? node.getAttribute(parsed.attribute) : node);
    }
    if (binding.source === "scope") return [scope];
    if (binding.source === "pageUrl") return [binding.pageUrl];
    return [];
  }

  function extractBinding(scope, binding, context) {
    const values = selectedValues(scope, { ...binding, pageUrl: context.pageUrl })
      .map((value) => transforms.runPipeline(value, binding.transform || [], context))
      .filter((value) => value !== null && value !== undefined && value !== "");
    if (values.some((value) => !isDataValue(value))) throw new Error(`Binding ${context.binding || "value"} produced a non-data value; add a bundled transform.`);
    if (binding.multiple) {
      const unique = values.filter((value, index) => values.findIndex((candidate) => JSON.stringify(candidate) === JSON.stringify(value)) === index);
      if (binding.aggregate) {
        const aggregated = transforms.runPipeline(unique, binding.aggregate, context);
        if (!isDataValue(aggregated)) throw new Error(`Binding ${context.binding || "value"} aggregate produced a non-data value.`);
        return aggregated;
      }
      return unique;
    }
    return values[0] ?? null;
  }

  function setFieldPath(target, path, value) {
    const segments = path.split(".");
    let current = target;
    for (const segment of segments.slice(0, -1)) {
      if (current[segment] === undefined) current[segment] = {};
      if (!isRecord(current[segment])) throw new Error(`Field path ${path} conflicts with an existing scalar value.`);
      current = current[segment];
    }
    current[segments.at(-1)] = value;
  }

  function normalizeFieldPath(field) {
    return field === "canonicalUrl" ? "url" : field;
  }

  function extractEntity(scope, entityDefinition, context, selectedFields = null) {
    const identityField = identityFieldName(entityDefinition);
    const identity = extractBinding(scope, identityBinding(entityDefinition), { ...context, binding: identityField || "canonicalUrl" });
    if (!identity) return null;
    const entity = { "@type": entityDefinition.schemaType, "@id": identity };
    if (!identityField) entity.url = identity;
    for (const [field, binding] of Object.entries(entityDefinition.fields)) {
      if (!selectedFields || selectedFields.has(field) || field === identityField) {
        setFieldPath(entity, field, field === identityField ? identity : extractBinding(scope, binding, { ...context, binding: field }));
      }
    }
    return entity;
  }

  function extractedFieldPresent(entity, path) {
    const value = path.split(".").reduce((current, segment) => current?.[segment], entity);
    return value !== null && value !== undefined && value !== "" && (!Array.isArray(value) || value.length > 0);
  }

  function selectorEvidencePresent(scope, rule) {
    try {
      const matches = [...(rule.selector === ":scope" || scope.matches(rule.selector) ? [scope] : []), ...scope.querySelectorAll(rule.selector)];
      return rule.attribute ? matches.some((node) => node.getAttribute(rule.attribute) === rule.equals) : matches.length > 0;
    }
    catch { return false; }
  }

  function scoreVariantCandidates(scope, candidates, definition, context, selectedFields, thresholds) {
    const extracted = candidates.map((candidate) => {
      // block.fields belongs to the fallback entity. Each candidate has its
      // own independent field set, which is also its classification shape.
      const entity = extractEntity(scope, definition.entities[candidate.entity], context);
      return {
        entity,
        selected: candidate.entity,
        signals: candidate.signals.map((signal) => ({
          ...signal,
          matched: Boolean(entity && extractedFieldPresent(entity, signal.field))
        })),
        evidence: candidate.evidence.map((rule) => ({
          ...rule,
          matched: rule.selector
            ? selectorEvidencePresent(scope, rule)
            : Boolean(entity && extractedFieldPresent(entity, rule.field))
        }))
      };
    }).filter((candidate) => candidate.entity);
    const classificationFingerprint = structuralHash(extracted.map((candidate) => ({
      entity: candidate.selected,
      signals: candidate.signals.map((signal) => Boolean(signal.matched)),
      evidence: candidate.evidence.map((rule) => Boolean(rule.matched))
    })));
    const configurationDigest = structuralHash({
      fallback: thresholds.fallback || null,
      minScore: thresholds.minScore,
      minMargin: thresholds.minMargin,
      candidates: candidates.map((candidate) => ({
        entity: candidate.entity,
        signals: candidate.signals.map(({ field, kind, weight }) => ({ field, kind, weight })),
        evidence: candidate.evidence.map(({ selector, field, attribute, equals, weight }) => ({ selector, field, attribute, equals, weight }))
      })).sort((left, right) => left.entity.localeCompare(right.entity))
    });
    return { ...variantClassifier.classify(extracted, thresholds), classificationFingerprint, configurationDigest };
  }

  function extractVariantEntity(scope, block, definition, context, selectedFields) {
    if (!block.variants) return { entity: extractEntity(scope, definition.entities[block.entity], context, selectedFields), selected: block.entity, reason: "single" };
    const report = scoreVariantCandidates(scope, block.variants.candidates, definition, context, selectedFields, { ...block.variants, fallback: block.variants.fallback });
    if (report.accepted) return { ...report.winner, reason: report.reason, margin: report.margin, classification: report };
    const fallback = extractEntity(scope, definition.entities[block.variants.fallback], context, selectedFields);
    return {
      entity: fallback,
      selected: block.variants.fallback,
      reason: report.reason,
      score: report.score,
      margin: report.margin,
      candidates: report.candidates,
      classification: report
    };
  }

  function classifyVariant(scope, slot, definition, context) {
    const report = scoreVariantCandidates(scope, slot.candidates, definition, context, null, slot);
    if (report.accepted) return { ...report.winner, reason: report.reason, margin: report.margin, classification: report };
    return {
      entity: extractEntity(scope, definition.entities[slot.fallback], context),
      selected: slot.fallback,
      reason: report.reason,
      score: report.score,
      margin: report.margin,
      candidates: report.candidates,
      classification: report
    };
  }

  function applyNestedVariantSlots(scope, entity, block, definition, context) {
    if (!entity || !block.variantSlots?.length) return { entity, slots: [] };
    const slots = block.variantSlots.map((slot) => {
      const result = classifyVariant(scope, slot, definition, context);
      if (result.entity) setFieldPath(entity, slot.path, result.entity);
      return { path: slot.path, ...result };
    });
    return { entity, slots };
  }

  function structuralHash(value) {
    const input = JSON.stringify(value);
    let left = 0x811c9dc5;
    let right = 0x9e3779b9;
    for (let index = 0; index < input.length; index += 1) {
      const code = input.charCodeAt(index);
      left = Math.imul(left ^ code, 0x01000193);
      right = Math.imul(right ^ code, 0x85ebca6b);
      right ^= right >>> 13;
    }
    return `s2j1:${(left >>> 0).toString(16).padStart(8, "0")}${(right >>> 0).toString(16).padStart(8, "0")}`;
  }

  function bindingObservation(scope, binding) {
    for (const [selectorIndex, declaredSelector] of (binding.selectors || []).entries()) {
      const parsed = selectorParts(declaredSelector);
      let nodes;
      if (parsed.xpath !== null) nodes = xpathNodes(scope, parsed.xpath, declaredSelector);
      else {
        try {
          nodes = parsed.selector === ":scope"
            ? [scope]
            : [...scope.querySelectorAll(parsed.selector)];
        } catch {
          throw new Error(`Invalid selector: ${declaredSelector}`);
        }
      }
      if (nodes.length) {
        const usable = parsed.attribute ? nodes.filter((node) => node.hasAttribute?.(parsed.attribute)) : nodes;
        const tags = [...new Set(nodes.map((node) => node.tagName?.toLowerCase() || "node"))].sort();
        return { count: usable.length, selectorIndex, tags };
      }
    }
    if (binding.source === "scope") return { count: 1, selectorIndex: -1, tags: [scope.tagName?.toLowerCase() || "scope"] };
    if (binding.source === "pageUrl") return { count: 1, selectorIndex: -1, tags: ["page-url"] };
    return { count: 0, selectorIndex: -1, tags: [] };
  }

  function structuralRuleMatched(scope, rule, entityDefinition) {
    if (rule.selector) return selectorEvidencePresent(scope, rule);
    const binding = rule.field === "canonicalUrl"
      ? identityBinding(entityDefinition)
      : entityDefinition.fields[rule.field];
    return binding ? bindingObservation(scope, binding).count > 0 : false;
  }

  function roundRatio(value) {
    return Number(value.toFixed(4));
  }

  function structuralSnapshot(definition, page, document, pageUrl) {
    const context = { pageUrl: pageUrl.href, adapter: definition.adapter, pageId: page.id };
    return page.blocks.map((block, blockIndex) => {
      let scopes;
      try { scopes = [...document.querySelectorAll(block.scope)]; } catch { throw new Error(`Invalid block scope selector: ${block.scope}`); }
      const records = scopes.map((scope) => {
        const classified = extractVariantEntity(scope, block, definition, context, block.fields ? new Set(block.fields) : null);
        const nested = applyNestedVariantSlots(scope, classified.entity, block, definition, context);
        const entityName = classified.selected || block.entity;
        const entityDefinition = definition.entities[entityName] || definition.entities[block.entity];
        const bindings = [
          ...(identityFieldName(entityDefinition) ? [] : [["canonicalUrl", identityBinding(entityDefinition)]]),
          ...Object.entries(entityDefinition.fields)
        ].sort(([left], [right]) => left.localeCompare(right));
        const fields = Object.fromEntries(bindings.map(([name, binding]) => [name, bindingObservation(scope, binding)]));
        const evidence = (block.variants?.candidates || []).flatMap((candidate) => candidate.evidence.map((rule, ruleIndex) => ({
          candidate: candidate.entity,
          rule: ruleIndex,
          matched: structuralRuleMatched(scope, rule, definition.entities[candidate.entity])
        })));
        const shape = {
          tag: scope.tagName?.toLowerCase() || "unknown",
          fields: Object.entries(fields).map(([name, observation]) => [name, observation.selectorIndex, observation.count, observation.tags]),
          evidence: evidence.map((item) => [item.candidate, item.rule, Number(item.matched)])
        };
        return { entityName, fields, evidence, nestedSlots: nested.slots, fingerprint: structuralHash(shape) };
      });
      const variants = {};
      for (const entityName of [...new Set(records.map((record) => record.entityName))].sort()) {
        const items = records.filter((record) => record.entityName === entityName);
        const entityDefinition = definition.entities[entityName] || definition.entities[block.entity];
        const fieldNames = [...(identityFieldName(entityDefinition) ? [] : ["canonicalUrl"]), ...Object.keys(entityDefinition.fields)].sort();
        const shapeCounts = new Map();
        for (const item of items) shapeCounts.set(item.fingerprint, (shapeCounts.get(item.fingerprint) || 0) + 1);
        variants[entityName] = {
          sampleSize: items.length,
          shapes: [...shapeCounts.entries()]
            .sort(([left], [right]) => left.localeCompare(right))
            .slice(0, 16)
            .map(([fingerprint, count]) => ({ fingerprint, frequency: roundRatio(count / items.length) })),
          fields: Object.fromEntries(fieldNames.map((field) => {
            const counts = items.map((item) => item.fields[field]?.count || 0);
            return [field, {
              coverage: roundRatio(counts.filter((count) => count > 0).length / items.length),
              matchesPerItem: [Math.min(...counts), Math.max(...counts)]
            }];
          })),
          evidence: (block.variants?.candidates || []).flatMap((candidate) => candidate.evidence.map((_rule, ruleIndex) => ({
            candidate: candidate.entity,
            rule: ruleIndex,
            coverage: roundRatio(items.filter((item) => item.evidence.some((evidence) => evidence.candidate === candidate.entity && evidence.rule === ruleIndex && evidence.matched)).length / items.length)
          })))
        };
      }
      const variantSlots = Object.fromEntries((block.variantSlots || []).map((slot) => {
        const selections = records.map((record) => record.nestedSlots.find((item) => item.path === slot.path)?.selected).filter(Boolean);
        return [slot.path, {
          sampleSize: records.length,
          counts: Object.fromEntries([...new Set(selections)].sort().map((entityName) => [entityName, selections.filter((selected) => selected === entityName).length]))
        }];
      }));
      return {
        block: blockIndex,
        scopeCount: scopes.length,
        variants,
        variantSlots
      };
    });
  }

  function captureStructuralBaselines(definition, document, pageUrl) {
    const validated = validateDefinition(definition);
    const page = matchingPage(validated, pageUrl, document);
    if (!page) throw new Error(`No declarative page binding matched ${pageUrl.href}.`);
    return structuralSnapshot(validated, page, document, pageUrl).map((snapshot) => {
      if (!snapshot.scopeCount || !Object.keys(snapshot.variants).length) throw new Error(`Block ${snapshot.block + 1} has no rendered items to baseline.`);
      return {
        version: 1,
        scope: {
          typical: snapshot.scopeCount,
          minimum: Math.max(1, Math.floor(snapshot.scopeCount * 0.25))
        },
        variants: snapshot.variants,
        ...(Object.keys(snapshot.variantSlots).length ? { variantSlots: snapshot.variantSlots } : {})
      };
    });
  }

  function structuralFindings(definition, page, document, pageUrl) {
    if (!page.blocks.some((block) => block.structuralBaseline)) return [];
    const live = structuralSnapshot(definition, page, document, pageUrl);
    const findings = [];
    for (const [blockIndex, block] of page.blocks.entries()) {
      const baseline = block.structuralBaseline;
      if (!baseline) continue;
      const blockId = blockIndex === 0 ? page.id : `${page.id}:${blockIndex}`;
      const current = live[blockIndex];
      if (current.scopeCount === 0 && baseline.scope.typical > 0) {
        findings.push({ code: "scope.noMatches", severity: "error", count: 1, block: blockId, baseline: baseline.scope.typical, current: 0 });
        continue;
      }
      if (current.scopeCount < baseline.scope.minimum) {
        findings.push({ code: "scope.countDrift", severity: "warning", count: 1, block: blockId, baseline: baseline.scope.typical, current: current.scopeCount });
      }
      for (const [entityName, expectedProfile] of Object.entries(baseline.variants)) {
        if (!current.variants[entityName] && expectedProfile.sampleSize > 0) findings.push({
          code: "variant.classificationDrift", severity: "strong-warning", count: expectedProfile.sampleSize,
          block: blockId, variant: entityName, baseline: expectedProfile.sampleSize, current: 0
        });
      }
      for (const [path, expectedProfile] of Object.entries(baseline.variantSlots || {})) {
        const currentProfile = current.variantSlots[path];
        for (const [entityName, baselineCount] of Object.entries(expectedProfile.counts)) {
          if (baselineCount > 0 && !(currentProfile?.counts?.[entityName] > 0)) findings.push({
            code: "variant.classificationDrift", severity: "strong-warning", count: baselineCount,
            block: blockId, path, variant: entityName, baseline: baselineCount, current: 0
          });
        }
      }
      for (const [entityName, currentProfile] of Object.entries(current.variants)) {
        const expected = baseline.variants[entityName];
        if (!expected) {
          findings.push({ code: "shape.unknown", severity: "warning", count: currentProfile.sampleSize, block: blockId, variant: entityName });
          continue;
        }
        const knownShapes = new Set(expected.shapes.map((shape) => shape.fingerprint));
        const unknownFrequency = currentProfile.shapes.filter((shape) => !knownShapes.has(shape.fingerprint)).reduce((sum, shape) => sum + shape.frequency, 0);
        if (unknownFrequency > 0) findings.push({
          code: "shape.unknown",
          severity: unknownFrequency >= 0.8 ? "strong-warning" : "warning",
          count: Math.max(1, Math.round(currentProfile.sampleSize * unknownFrequency)),
          block: blockId,
          variant: entityName,
          frequency: roundRatio(unknownFrequency)
        });
        for (const [field, stats] of Object.entries(currentProfile.fields)) {
          const previous = expected.fields[field];
          if (!previous) continue;
          const required = field === "canonicalUrl"
            || field === identityFieldName(definition.entities[entityName])
            || (block.require || []).includes(field);
          if (previous.coverage > 0 && stats.coverage === 0) {
            findings.push({ code: "field.selectorMissing", severity: required ? "error" : "strong-warning", count: currentProfile.sampleSize, block: blockId, variant: entityName, field, baseline: previous.coverage, current: 0 });
            continue;
          }
          const coverageDrop = previous.coverage - stats.coverage;
          if (coverageDrop >= 0.2 || (previous.coverage >= 0.95 && stats.coverage < 0.8)) findings.push({
            code: "field.coverageDrift", severity: required ? "error" : "warning", count: 1, block: blockId, variant: entityName, field,
            baseline: previous.coverage, current: stats.coverage
          });
          if (stats.matchesPerItem[1] > previous.matchesPerItem[1] || (previous.matchesPerItem[0] > 0 && stats.matchesPerItem[0] < previous.matchesPerItem[0])) findings.push({
            code: "field.cardinalityDrift", severity: required ? "error" : "warning", count: 1, block: blockId, variant: entityName, field,
            baseline: previous.matchesPerItem, current: stats.matchesPerItem
          });
        }
        const evidenceByKey = new Map(currentProfile.evidence.map((item) => [`${item.candidate}:${item.rule}`, item]));
        for (const previous of expected.evidence) {
          const stats = evidenceByKey.get(`${previous.candidate}:${previous.rule}`);
          if (stats && previous.coverage >= 0.8 && stats.coverage <= 0.2) findings.push({
            code: "variant.evidenceDrift", severity: "strong-warning", count: 1, block: blockId, variant: entityName,
            candidate: previous.candidate, rule: previous.rule, baseline: previous.coverage, current: stats.coverage
          });
        }
      }
    }
    return findings.slice(0, 50);
  }

  function pageBindingValue(binding, document, pageUrl, blocks, context) {
    const primary = blocks.find((block) => block.role === "primary")?.entities[0] || null;
    const sources = {
      pageUrl: pageUrl.href,
      pageTitle: document.title,
      language: document.documentElement.lang || null,
      primaryEntityTitle: primary?.title || null,
      primaryEntityUrl: primary?.url || primary?.["@id"] || null,
      literal: binding.value
    };
    const value = transforms.runPipeline(sources[binding.source], binding.transform || [], context);
    if (!isDataValue(value)) throw new Error(`Binding ${context.binding || "page value"} produced a non-data value; add a bundled transform.`);
    return value;
  }

  function extractPageMetadata(page, document, pageUrl, blocks, context) {
    const metadata = page.metadata || {};
    const pageData = {};
    for (const [field, binding] of Object.entries(metadata.page || {})) {
      setFieldPath(pageData, field, pageBindingValue(binding, document, pageUrl, blocks, { ...context, binding: `page.${field}` }));
    }
    return {
      pageTitle: metadata.pageTitle ? pageBindingValue(metadata.pageTitle, document, pageUrl, blocks, { ...context, binding: "pageTitle" }) : null,
      collectionKey: metadata.collectionKey ? pageBindingValue(metadata.collectionKey, document, pageUrl, blocks, { ...context, binding: "collectionKey" }) : null,
      snapshotKey: metadata.snapshotKey ? pageBindingValue(metadata.snapshotKey, document, pageUrl, blocks, { ...context, binding: "snapshotKey" }) : pageUrl.href,
      logicalPosition: metadata.logicalPosition ? pageBindingValue(metadata.logicalPosition, document, pageUrl, blocks, { ...context, binding: "logicalPosition" }) : null,
      page: pageData
    };
  }

  function matchingPage(definition, url, document) {
    const normalizedPath = url.pathname.length > 1 ? url.pathname.replace(/\/$/, "") : url.pathname;
    return definition.pages.find((page) => (
      page.match.host.includes(url.hostname)
      && page.match.path.some((rule) => {
        const value = rule.value.length > 1 ? rule.value.replace(/\/$/, "") : rule.value;
        return rule.mode === "exact" ? normalizedPath === value : normalizedPath === value || normalizedPath.startsWith(`${value}/`);
      })
      && (!page.match.url || Boolean(pageBindingValue(page.match.url, document, url, [], { pageUrl: url.href, binding: "match.url" })))
      && (!page.match.assert || document.querySelector(page.match.assert))
    )) || null;
  }

  function pathPage(definition, url) {
    const normalizedPath = url.pathname.length > 1 ? url.pathname.replace(/\/$/, "") : url.pathname;
    return definition.pages.find((page) => page.match.host.includes(url.hostname) && page.match.path.some((rule) => {
      const value = rule.value.length > 1 ? rule.value.replace(/\/$/, "") : rule.value;
      return rule.mode === "exact" ? normalizedPath === value : normalizedPath === value || normalizedPath.startsWith(`${value}/`);
    }) && (!page.match.url || Boolean(transforms.runPipeline(url.href, page.match.url.transform || [], { pageUrl: url.href, binding: "match.url" })))) || null;
  }

  function compile(rawDefinition) {
    const definition = validateDefinition(rawDefinition);
    return {
      id: definition.adapter,
      version: definition.version,
      source: "declarative",
      context: { [definition.adapter]: definition.namespace },
      definition,
      match(url, document) {
        return url.protocol === "https:" && definition.hosts.includes(url.hostname) && Boolean(pathPage(definition, url));
      },
      extract(document, pageUrl) {
        const page = matchingPage(definition, pageUrl, document);
        if (!page) throw new Error(`No declarative page binding matched ${pageUrl.href}.`);
        const warnings = [];
        const context = { pageUrl: pageUrl.href, adapter: definition.adapter, pageId: page.id };
        const blocks = page.blocks.map((block, blockIndex) => {
          let scopes;
          try { scopes = [...document.querySelectorAll(block.scope)]; } catch { throw new Error(`Invalid block scope selector: ${block.scope}`); }
          if (block.arity === "one" && scopes.length > 1) throw new Error(`Page ${page.id} block ${block.entity} expected at most one scope but found ${scopes.length}.`);
          const selectedFields = block.fields ? new Set(block.fields) : null;
          const classified = scopes.map((scope) => {
            const result = extractVariantEntity(scope, block, definition, context, selectedFields);
            const nested = applyNestedVariantSlots(scope, result.entity, block, definition, context);
            return { ...result, entity: nested.entity, nestedSlots: nested.slots };
          });
          const entities = classified.map((result) => result.entity);
          const missingIdentities = entities.filter((entity) => !entity).length;
          const blockId = blockIndex === 0 ? page.id : `${page.id}:${blockIndex}`;
          if (missingIdentities) warnings.push({ code: "entity.identityMissing", count: missingIdentities, block: blockId });
          const ambiguous = classified.filter((result) => result.reason === "ambiguous").length;
          if (ambiguous) warnings.push({ code: "variant.ambiguous", count: ambiguous, block: blockId });
          for (const slot of block.variantSlots || []) {
            const nestedAmbiguous = classified.filter((result) => result.nestedSlots.some((item) => item.path === slot.path && item.reason === "ambiguous")).length;
            if (nestedAmbiguous) warnings.push({ code: "variant.ambiguous", count: nestedAmbiguous, block: blockId, path: slot.path });
          }
          const identified = entities.filter(Boolean);
          const unique = [...new Map(identified.map((entity) => [entity["@id"] || entity.url, entity])).values()];
          if (identified.length > unique.length) warnings.push({ code: "entity.duplicate", count: identified.length - unique.length, block: blockId });
          const variantCounts = block.variants ? Object.fromEntries([...new Set(classified.filter((result) => result.entity).map((result) => result.selected))].sort().map((entityName) => [entityName, classified.filter((result) => result.entity && result.selected === entityName).length])) : null;
          const variantSlots = (block.variantSlots || []).map((slot) => ({
            path: slot.path,
            counts: Object.fromEntries([...new Set(classified.map((result) => result.nestedSlots.find((item) => item.path === slot.path)?.selected).filter(Boolean))].sort().map((entityName) => [entityName, classified.filter((result) => result.nestedSlots.some((item) => item.path === slot.path && item.selected === entityName)).length])),
            ambiguous: classified.filter((result) => result.nestedSlots.some((item) => item.path === slot.path && item.reason === "ambiguous")).length
          }));
          return {
            id: blockId,
            entity: block.entity,
            arity: block.arity,
            role: block.role,
            fidelity: block.fidelity,
            require: (block.require || []).map(normalizeFieldPath),
            monitor: (block.monitor || []).map(normalizeFieldPath),
            ...(variantCounts ? { variants: { counts: variantCounts, ambiguous } } : {}),
            ...(variantSlots.length ? { variantSlots } : {}),
            entities: unique
          };
        });
        warnings.push(...structuralFindings(definition, page, document, pageUrl));
        const hasCollection = blocks.some((block) => block.role === "collection");
        const metadata = extractPageMetadata(page, document, pageUrl, blocks, context);
        if (hasCollection && !metadata.collectionKey) warnings.push({ code: "dsl.collectionIdentityUnavailable", count: 1, page: page.id });
        const observation = {
          pageType: page.pageType,
          pageTitle: metadata.pageTitle || document.title,
          language: document.documentElement.lang || null,
          collectionKey: metadata.collectionKey,
          snapshotKey: metadata.snapshotKey,
          logicalPosition: metadata.logicalPosition,
          blocks
        };
        if (page.metadata?.page !== undefined) observation.page = metadata.page;
        if (hasCollection || warnings.length) observation.warnings = warnings;
        return observation;
      }
    };
  }

  return { DSL_VERSION, applyNestedVariantSlots, captureStructuralBaselines, classifyVariant, compile, extractBinding, matchingPage, selectorParts, structuralFindings, validateDefinition };
});
