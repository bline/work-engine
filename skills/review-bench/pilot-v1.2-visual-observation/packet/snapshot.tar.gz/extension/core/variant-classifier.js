(function initializeVariantClassifier(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonVariantClassifier = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function variantClassifierFactory() {
  "use strict";

  const VERSION = 1;
  const round = (value) => Math.round(value * 100) / 100;

  function classify(candidates = [], { minScore = 0, minMargin = 0 } = {}) {
    const ranked = candidates.map((candidate) => {
      const signals = (candidate.signals || []).map((signal) => ({ ...signal, contribution: signal.matched ? signal.weight : 0 }));
      const evidence = (candidate.evidence || []).map((rule) => ({ ...rule, contribution: rule.matched ? rule.weight : 0 }));
      const shapeScore = signals.reduce((sum, signal) => sum + signal.contribution, 0);
      const evidenceScore = evidence.reduce((sum, rule) => sum + rule.contribution, 0);
      return {
        ...candidate,
        signals,
        evidence,
        shapeScore,
        evidenceScore,
        score: shapeScore + evidenceScore
      };
    }).sort((left, right) => right.score - left.score || String(left.selected).localeCompare(String(right.selected)));
    const winner = ranked[0] || null;
    const runnerUp = ranked[1] || null;
    const margin = winner ? winner.score - (runnerUp?.score || 0) : 0;
    const accepted = Boolean(winner && winner.score >= minScore && margin >= minMargin);
    const reason = accepted ? "candidate" : winner && winner.score >= minScore ? "ambiguous" : "fallback";
    return {
      version: VERSION,
      accepted,
      reason,
      winner,
      runnerUp,
      score: winner?.score || 0,
      margin: round(margin),
      thresholds: { minScore, minMargin },
      candidates: ranked.map((candidate) => ({
        entityName: candidate.entityName,
        schemaType: candidate.schemaType,
        selected: candidate.selected,
        score: candidate.score,
        shapeScore: candidate.shapeScore,
        evidenceScore: candidate.evidenceScore,
        signals: candidate.signals,
        evidence: candidate.evidence
      }))
    };
  }

  return Object.freeze({ VERSION, classify });
});
