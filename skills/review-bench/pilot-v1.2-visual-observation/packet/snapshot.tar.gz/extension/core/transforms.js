(function initializeTransforms(root, factory) {
  "use strict";
  const utils = root.Site2JsonUtils || (typeof require === "function" ? require("./utils") : null);
  const api = factory(utils);
  root.Site2JsonTransforms = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function transformsFactory(utils) {
  "use strict";

  function parsedUrl(value) {
    if (typeof value !== "string") return null;
    try { return new URL(value); } catch { return null; }
  }

  function normalizedParsingText(value) {
    if (typeof value !== "string") return null;
    if (value.length > 100_000) throw new Error("Parsing input exceeds 100000 characters.");
    return utils.normalizeText(value);
  }

  function parseMoney(raw) {
    if (!raw) return null;
    const multiplier = /m\b/i.test(raw) ? 1_000_000 : /k\b/i.test(raw) ? 1_000 : 1;
    const value = Number.parseFloat(raw.replace(/[^\d.]/g, ""));
    return Number.isFinite(value) ? value * multiplier : null;
  }

  function isoDate(year, month, day) {
    const numericYear = Number(year);
    const numericMonth = Number(month);
    const numericDay = Number(day);
    if (!Number.isSafeInteger(numericYear) || !Number.isSafeInteger(numericMonth) || !Number.isSafeInteger(numericDay)) return null;
    const date = new Date(Date.UTC(numericYear, numericMonth - 1, numericDay));
    if (date.getUTCFullYear() !== numericYear || date.getUTCMonth() !== numericMonth - 1 || date.getUTCDate() !== numericDay) return null;
    return `${String(numericYear).padStart(4, "0")}-${String(numericMonth).padStart(2, "0")}-${String(numericDay).padStart(2, "0")}`;
  }

  function decodedPathSegments(value) {
    if (typeof value !== "string" || !value.startsWith("/") || value.length > 16_384) return null;
    try {
      return value.split("/").filter(Boolean).map((segment) => decodeURIComponent(segment));
    } catch {
      return null;
    }
  }

  function keyedPathValues(value, key) {
    const segments = decodedPathSegments(value);
    if (!segments) return null;
    const values = [];
    for (let index = 0; index < segments.length - 1; index += 1) {
      if (segments[index].toLowerCase() === key.toLowerCase()) values.push(segments[index + 1]);
    }
    return values;
  }

  function pathWithoutPairs(value, excludedKeys) {
    const segments = decodedPathSegments(value);
    if (!segments) return null;
    const excluded = new Set(excludedKeys.map((key) => key.toLowerCase()));
    const retained = [];
    for (let index = 0; index < segments.length; index += 1) {
      if (excluded.has(segments[index].toLowerCase()) && segments[index + 1] !== undefined) {
        index += 1;
      } else {
        retained.push(segments[index]);
      }
    }
    return `/${retained.join("/")}/`;
  }

  function queryEntries(url, excluded = []) {
    const ignored = new Set(excluded);
    return [...url.searchParams.entries()]
      .filter(([key]) => !ignored.has(key))
      .sort(([keyA, valueA], [keyB, valueB]) => keyA.localeCompare(keyB) || valueA.localeCompare(valueB));
  }

  function queryDefinition(url, excluded = []) {
    return new URLSearchParams(queryEntries(url, excluded)).toString();
  }

  function positiveQueryInteger(url, parameter, fallback) {
    const value = Number.parseInt(url.searchParams.get(parameter) || String(fallback), 10);
    return Number.isSafeInteger(value) && value > 0 ? value : fallback;
  }

  function stringList(value) {
    return Array.isArray(value) && value.every((item) => typeof item === "string");
  }

  function pathTemplateMatches(pathname, template) {
    const pathSegments = pathname.replace(/^\/|\/$/g, "").split("/");
    const templateSegments = template.replace(/^\/|\/$/g, "").split("/");
    if (pathSegments.length !== templateSegments.length) return false;
    return templateSegments.every((expected, index) => {
      const marker = "{segment}";
      const markerIndex = expected.indexOf(marker);
      if (markerIndex < 0) return pathSegments[index] === expected;
      const prefix = expected.slice(0, markerIndex);
      const suffix = expected.slice(markerIndex + marker.length);
      return pathSegments[index].length > prefix.length + suffix.length
        && pathSegments[index].startsWith(prefix)
        && pathSegments[index].endsWith(suffix);
    });
  }

  function validPathTemplate(value) {
    if (typeof value !== "string" || !value.startsWith("/") || value.length > 512) return false;
    return value.split("/").every((segment) => {
      const withoutMarker = segment.replace("{segment}", "");
      return !withoutMarker.includes("{") && !withoutMarker.includes("}") && segment.indexOf("{segment}") === segment.lastIndexOf("{segment}");
    });
  }

  const definitions = Object.freeze({
    text: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        if (typeof value === "string") return utils.normalizeText(value);
        return value && typeof value === "object" ? utils.textOf(value) || null : null;
      }
    }),
    trim: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        return typeof value === "string" ? value.trim() || null : null;
      }
    }),
    collapseWhitespace: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        return typeof value === "string" ? utils.normalizeText(value) || null : null;
      }
    }),
    float: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        const selected = Number.parseFloat(String(value ?? "").replace(/,/g, ""));
        return Number.isFinite(selected) ? selected : null;
      }
    }),
    lowercase: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        return typeof value === "string" ? value.toLowerCase() : null;
      }
    }),
    textSlice: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 2,
      validateArguments: (args) => args.every((argument) => Number.isSafeInteger(argument) && Math.abs(argument) <= 100_000),
      run(value, args) {
        if (typeof value !== "string" || value.length > 100_000) return null;
        return value.slice(args[0], args[1]) || null;
      }
    }),
    int: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        const match = String(value ?? "").match(/[+-]?[\d,]+/);
        return match ? Number.parseInt(match[0].replace(/,/g, ""), 10) : null;
      }
    }),
    mapValues: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => args[0] && typeof args[0] === "object" && !Array.isArray(args[0]),
      run(value, args) {
        const key = String(value ?? "");
        return Object.hasOwn(args[0], key) ? args[0][key] : null;
      }
    }),
    arraySlice: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 2,
      validateArguments: (args) => args.every((argument) => Number.isSafeInteger(argument)),
      run(value, args) {
        return Array.isArray(value) ? value.slice(args[0], args[1]) : null;
      }
    }),
    joinLiteral: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string" && args[0].length <= 32,
      run(value, args) {
        return Array.isArray(value) ? value.filter((item) => typeof item === "string" && item).join(args[0]) || null : null;
      }
    }),
    stripLeadingLabel: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string" && args[0].length > 0,
      run(value, args) {
        if (typeof value !== "string") return null;
        const normalized = utils.normalizeText(value);
        if (!normalized.toLowerCase().startsWith(args[0].toLowerCase())) return normalized || null;
        return normalized.slice(args[0].length).replace(/^\s*:\s*/, "").trim() || null;
      }
    }),
    absoluteUrl: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value, _arguments, context) {
        if (typeof value !== "string" || !context?.pageUrl) return null;
        try {
          return new URL(value, context.pageUrl).href;
        } catch {
          return null;
        }
      }
    }),
    stripQuery: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        if (typeof value !== "string") return null;
        try {
          const url = new URL(value);
          url.search = "";
          return url.href;
        } catch {
          return null;
        }
      }
    }),
    urlLastPathSegment: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        const url = parsedUrl(value);
        return url?.pathname.split("/").filter(Boolean).at(-1) || null;
      }
    }),
    removePrefixLiteral: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string",
      run(value, args) {
        return typeof value === "string" && value.startsWith(args[0]) ? value.slice(args[0].length) || null : null;
      }
    }),
    removeOptionalPrefixLiteral: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string",
      run(value, args) {
        if (typeof value !== "string") return null;
        return value.startsWith(args[0]) ? value.slice(args[0].length) || null : value;
      }
    }),
    afterLastLiteral: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string" && args[0].length > 0,
      run(value, args) {
        if (typeof value !== "string") return null;
        const index = value.lastIndexOf(args[0]);
        return index >= 0 ? value.slice(index + args[0].length) || null : null;
      }
    }),
    afterOptionalLastLiteral: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string" && args[0].length > 0,
      run(value, args) {
        if (typeof value !== "string") return null;
        const index = value.lastIndexOf(args[0]);
        return index >= 0 ? value.slice(index + args[0].length) || null : value;
      }
    }),
    beforeOptionalFirstLiteral: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string" && args[0].length > 0,
      run(value, args) {
        if (typeof value !== "string") return null;
        const index = value.indexOf(args[0]);
        return index >= 0 ? value.slice(0, index) || null : value;
      }
    }),
    requireIncludesLiteral: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string" && args[0].length > 0,
      run(value, args) {
        return typeof value === "string" && value.includes(args[0]) ? value : null;
      }
    }),
    prefixLiteral: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string",
      run(value, args) {
        return value === null || value === undefined ? null : `${args[0]}${String(value)}`;
      }
    }),
    canonicalUrlForTemplates: Object.freeze({
      minimumArguments: 2,
      maximumArguments: 2,
      validateArguments: (args) => stringList(args[0]) && args[0].length > 0 && stringList(args[1]) && args[1].length > 0 && args[1].every(validPathTemplate),
      run(value, args) {
        const url = parsedUrl(value);
        if (!url || !args[0].includes(url.hostname) || !args[1].some((template) => pathTemplateMatches(url.pathname, template))) return null;
        return `${url.origin}${url.pathname.replace(/\/$/, "")}`;
      }
    }),
    leadingDigits: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        return typeof value === "string" ? value.match(/^\d+/)?.[0] || null : null;
      }
    }),
    base64UrlDecode: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        if (typeof value !== "string" || value.length > 16_384 || !/^[A-Za-z0-9_-]+={0,2}$/.test(value)) return null;
        try {
          const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
          return atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "="));
        } catch {
          return null;
        }
      }
    }),
    requirePathPrefix: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => stringList(args[0]) && args[0].length > 0,
      run(value, args) {
        const segments = decodedPathSegments(value);
        return segments && args[0].every((segment, index) => segments[index]?.toLowerCase() === segment.toLowerCase()) ? value : null;
      }
    }),
    pathSegmentValue: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string" && args[0].length > 0,
      run(value, args) {
        return keyedPathValues(value, args[0])?.[0] ?? null;
      }
    }),
    pathSegmentValues: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => typeof args[0] === "string" && args[0].length > 0,
      run(value, args) {
        return keyedPathValues(value, args[0]);
      }
    }),
    pathSegmentPositiveInteger: Object.freeze({
      minimumArguments: 2,
      maximumArguments: 2,
      validateArguments: (args) => typeof args[0] === "string" && Number.isSafeInteger(args[1]) && args[1] > 0,
      run(value, args) {
        const selected = Number.parseInt(keyedPathValues(value, args[0])?.[0] || String(args[1]), 10);
        return Number.isSafeInteger(selected) && selected > 0 ? selected : args[1];
      }
    }),
    pathWithoutSegmentPairs: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => stringList(args[0]),
      run(value, args) {
        return pathWithoutPairs(value, args[0]);
      }
    }),
    pathUnknownSegments: Object.freeze({
      minimumArguments: 2,
      maximumArguments: 2,
      validateArguments: (args) => stringList(args[0]) && stringList(args[1]),
      run(value, args) {
        const segments = decodedPathSegments(value);
        if (!segments) return null;
        const paired = new Set(args[0].map((key) => key.toLowerCase()));
        const literals = new Set(args[1].map((key) => key.toLowerCase()));
        const unknown = [];
        for (let index = 0; index < segments.length; index += 1) {
          const key = segments[index].toLowerCase();
          if (paired.has(key) && segments[index + 1] !== undefined) index += 1;
          else if (!literals.has(key)) unknown.push(segments[index]);
        }
        return unknown;
      }
    }),
    pathSnapshotKey: Object.freeze({
      minimumArguments: 4,
      maximumArguments: 4,
      validateArguments: (args) => typeof args[0] === "string" && stringList(args[1]) && typeof args[2] === "string" && Number.isSafeInteger(args[3]) && args[3] > 0,
      run(value, args) {
        const route = pathWithoutPairs(value, args[1]);
        if (!route) return null;
        const page = Number.parseInt(keyedPathValues(value, args[2])?.[0] || String(args[3]), 10);
        return `${args[0]}${route}:page:${Number.isSafeInteger(page) && page > 0 ? page : args[3]}`;
      }
    }),
    urlQueryFirst: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => stringList(args[0]) && args[0].length > 0,
      run(value, args) {
        const url = parsedUrl(value);
        if (!url) return null;
        for (const parameter of args[0]) {
          const selected = utils.normalizeText(url.searchParams.get(parameter));
          if (selected) return selected;
        }
        return null;
      }
    }),
    urlQueryParameters: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        const url = parsedUrl(value);
        if (!url) return null;
        const parameters = {};
        for (const [key, selected] of queryEntries(url)) {
          parameters[key] ||= [];
          parameters[key].push(selected);
        }
        return parameters;
      }
    }),
    urlQuerySorted: Object.freeze({
      minimumArguments: 1,
      maximumArguments: 1,
      validateArguments: (args) => stringList(args[0]),
      run(value, args) {
        const url = parsedUrl(value);
        return url ? queryDefinition(url, args[0]) : null;
      }
    }),
    urlQueryPositiveInteger: Object.freeze({
      minimumArguments: 2,
      maximumArguments: 2,
      validateArguments: (args) => typeof args[0] === "string" && Number.isSafeInteger(args[1]) && args[1] > 0,
      run(value, args) {
        const url = parsedUrl(value);
        return url ? positiveQueryInteger(url, args[0], args[1]) : null;
      }
    }),
    urlQueryCollectionKey: Object.freeze({
      minimumArguments: 2,
      maximumArguments: 2,
      validateArguments: (args) => typeof args[0] === "string" && stringList(args[1]),
      run(value, args) {
        const url = parsedUrl(value);
        return url ? `${args[0]}${queryDefinition(url, args[1])}` : null;
      }
    }),
    urlQuerySnapshotKey: Object.freeze({
      minimumArguments: 4,
      maximumArguments: 4,
      validateArguments: (args) => typeof args[0] === "string" && stringList(args[1]) && typeof args[2] === "string" && Number.isSafeInteger(args[3]) && args[3] > 0,
      run(value, args) {
        const url = parsedUrl(value);
        if (!url) return null;
        return `${args[0]}${queryDefinition(url, args[1])}:page:${positiveQueryInteger(url, args[2], args[3])}`;
      }
    }),
    parseProjectBudgetV1: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        const rawText = normalizedParsingText(value);
        if (!rawText) return null;
        if (/fixed price or hourly/i.test(rawText)) return { type: "fixed_or_hourly", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: rawText };
        const hourly = rawText.match(/(?:Hourly\s*:?\s*)?\$\s*([\d,.]+\s*[kKmM]?)\s*(?:-|–|—|to)\s*\$?\s*([\d,.]+\s*[kKmM]?)(?:\s*\/\s*(?:hr|hour))?/i);
        if (hourly) {
          const type = /fixed/i.test(rawText) ? "fixed" : "hourly";
          const isolated = /^(?:Hourly|Fixed)/i.test(rawText);
          return { type, minimum: parseMoney(hourly[1]), maximum: parseMoney(hourly[2]), amount: null, currency: "USD", raw_text: type === "fixed" || isolated ? rawText : utils.normalizeText(hourly[0]) };
        }
        const under = rawText.match(/Under\s+\$\s*([\d,.]+\s*[kKmM]?)/i);
        if (under) return { type: /fixed/i.test(rawText) ? "fixed" : "unknown", minimum: null, maximum: parseMoney(under[1]), amount: null, currency: "USD", raw_text: rawText };
        const over = rawText.match(/(?:Over|Above)\s+\$\s*([\d,.]+\s*[kKmM]?)/i);
        if (over) return { type: /hourly/i.test(rawText) ? "hourly" : /fixed/i.test(rawText) ? "fixed" : "unknown", minimum: parseMoney(over[1]), maximum: null, amount: null, currency: "USD", raw_text: rawText };
        const hourlySingle = rawText.match(/(?:Hourly\s*:?\s*)\$\s*([\d,.]+)(?:\s*\/\s*(?:hr|hour))?/i);
        if (hourlySingle) {
          const amount = parseMoney(hourlySingle[1]);
          return { type: "hourly", minimum: amount, maximum: amount, amount: null, currency: "USD", raw_text: utils.normalizeText(hourlySingle[0]) };
        }
        const fixed = rawText.match(/(?:fixed[ -]price|est(?:imated)?\.?\s*budget|budget)\s*:?\s*\$\s*([\d,.]+\s*[kKmM]?)/i);
        if (fixed) return { type: "fixed", minimum: null, maximum: null, amount: parseMoney(fixed[1]), currency: "USD", raw_text: utils.normalizeText(fixed[0]) };
        if (/\bHourly\b/i.test(rawText)) return { type: "hourly", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: "Hourly" };
        if (/\bFixed[ -]Price\b/i.test(rawText)) return { type: "fixed", minimum: null, maximum: null, amount: null, currency: "USD", raw_text: "Fixed Price" };
        return null;
      }
    }),
    parseRatingV1: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        const rawText = normalizedParsingText(value);
        const match = rawText?.match(/(?:rating\s*)?([0-5](?:\.\d+)?)\s*(?:out of 5|of 5|stars?)/i);
        const rating = match ? Number.parseFloat(match[1]) : null;
        return Number.isFinite(rating) ? rating : null;
      }
    }),
    parseMoneyV1: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        return parseMoney(normalizedParsingText(value));
      }
    }),
    parseEnglishDateV1: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        const rawText = normalizedParsingText(value);
        if (!rawText) return null;
        const iso = rawText.match(/(?:^|\D)(\d{4})-(\d{2})-(\d{2})(?:\D|$)/);
        if (iso) return isoDate(iso[1], iso[2], iso[3]);
        const months = {
          jan: 1, january: 1, feb: 2, february: 2, mar: 3, march: 3, apr: 4, april: 4,
          may: 5, jun: 6, june: 6, jul: 7, july: 7, aug: 8, august: 8, sep: 9, sept: 9,
          september: 9, oct: 10, october: 10, nov: 11, november: 11, dec: 12, december: 12
        };
        const monthFirst = rawText.match(/\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:\s*,)?\s+(\d{4})\b/i);
        if (monthFirst) return isoDate(monthFirst[3], months[monthFirst[1].toLowerCase()], monthFirst[2]);
        const dayFirst = rawText.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?\s+(\d{4})\b/i);
        return dayFirst ? isoDate(dayFirst[3], months[dayFirst[2].toLowerCase()], dayFirst[1]) : null;
      }
    }),
    parsePercentV1: Object.freeze({
      minimumArguments: 0,
      maximumArguments: 0,
      run(value) {
        const rawText = normalizedParsingText(value);
        const match = rawText?.match(/([\d.]+)\s*%/);
        const selected = match ? Number.parseFloat(match[1]) : null;
        return Number.isFinite(selected) ? selected : null;
      }
    })
  });

  function argumentMetadata(name, label, type, description, options = {}) {
    return Object.freeze({ name, label, type, description, ...options });
  }

  function editorMetadata(category, label, description, input, output, keywords = [], argumentDefinitions = []) {
    return Object.freeze({
      category, label, description, input, output,
      keywords: Object.freeze(keywords),
      argumentDefinitions: Object.freeze(argumentDefinitions)
    });
  }

  // Inert, reviewed authoring metadata. This is packaged with the executable
  // transform rather than inferred from its name or supplied by adapter DSL.
  const editorDefinitions = Object.freeze({
    text: editorMetadata("Text", "Rendered text", "Read normalized text from a DOM node or text value.", "node or text", "text", ["content", "node", "string"]),
    trim: editorMetadata("Text", "Trim whitespace", "Remove whitespace at the beginning and end of text.", "text", "text", ["spaces", "cleanup"]),
    collapseWhitespace: editorMetadata("Text", "Collapse whitespace", "Normalize repeated whitespace inside rendered text.", "text", "text", ["spaces", "normalize", "cleanup"]),
    lowercase: editorMetadata("Text", "Lowercase text", "Convert text to lowercase.", "text", "text", ["case", "normalize"]),
    textSlice: editorMetadata("Text", "Slice text by position", "Keep a configured character range from text.", "text", "text", ["substring", "characters", "offset", "fixed width"], [
      argumentMetadata("start", "Start offset", "integer", "Zero-based starting character offset.", { minimum: -100000, maximum: 100000 }),
      argumentMetadata("end", "End offset", "integer", "Optional exclusive ending character offset.", { required: false, minimum: -100000, maximum: 100000 })
    ]),
    stripLeadingLabel: editorMetadata("Text", "Strip leading label", "Remove a configured label from the beginning of text.", "text", "text", ["prefix", "caption", "colon"], [argumentMetadata("label", "Leading label", "string", "Label to remove, matched without regard to case.", { allowEmpty: false })]),
    removePrefixLiteral: editorMetadata("Text", "Require and remove prefix", "Remove a configured literal prefix, returning missing when it is absent.", "text", "text", ["prefix", "literal", "strict"], [argumentMetadata("prefix", "Required prefix", "string", "Exact prefix that must be present.")]),
    removeOptionalPrefixLiteral: editorMetadata("Text", "Remove optional prefix", "Remove a configured literal prefix when present.", "text", "text", ["prefix", "literal"], [argumentMetadata("prefix", "Optional prefix", "string", "Exact prefix to remove when present.")]),
    afterLastLiteral: editorMetadata("Text", "Text after last delimiter", "Keep text after the last configured literal delimiter.", "text", "text", ["suffix", "delimiter", "split"], [argumentMetadata("delimiter", "Delimiter", "string", "Exact delimiter to find.", { allowEmpty: false })]),
    afterOptionalLastLiteral: editorMetadata("Text", "Text after optional delimiter", "Keep text after the last delimiter, or retain the original text.", "text", "text", ["suffix", "delimiter", "split"], [argumentMetadata("delimiter", "Delimiter", "string", "Exact optional delimiter to find.", { allowEmpty: false })]),
    beforeOptionalFirstLiteral: editorMetadata("Text", "Text before optional delimiter", "Keep text before the first delimiter, or retain the original text.", "text", "text", ["prefix", "delimiter", "split"], [argumentMetadata("delimiter", "Delimiter", "string", "Exact optional delimiter to find.", { allowEmpty: false })]),
    prefixLiteral: editorMetadata("Text", "Add literal prefix", "Prepend configured text to a value.", "any", "text", ["prefix", "concatenate"], [argumentMetadata("prefix", "Prefix", "string", "Text to prepend.")]),
    int: editorMetadata("Numbers", "Integer", "Parse the first signed integer from rendered text.", "text or number", "integer", ["count", "whole", "numeric"]),
    float: editorMetadata("Numbers", "Number", "Parse a decimal number from rendered text.", "text or number", "number", ["decimal", "numeric"]),
    leadingDigits: editorMetadata("Numbers", "Leading digits", "Read the run of digits at the beginning of text.", "text", "text", ["identifier", "number", "prefix"]),
    parseEnglishDateV1: editorMetadata("Dates and times", "English calendar date", "Find an absolute English or ISO calendar date and emit YYYY-MM-DD.", "text", "date", ["posted", "published", "deadline", "calendar", "iso"]),
    parseMoneyV1: editorMetadata("Money and rates", "Money amount", "Parse a numeric monetary amount, including k and m suffixes.", "text", "number", ["currency", "price", "cost", "dollars", "spend"]),
    parseProjectBudgetV1: editorMetadata("Money and rates", "Project budget", "Parse fixed, hourly, ranged, or open project budget text.", "text", "object", ["currency", "price", "rate", "hourly", "fixed", "budget"]),
    parsePercentV1: editorMetadata("Numbers", "Percentage", "Parse a percentage value from rendered text.", "text", "number", ["percent", "ratio", "feedback"]),
    parseRatingV1: editorMetadata("Numbers", "Five-star rating", "Parse a rating expressed on a five-star scale.", "text", "number", ["stars", "score", "review"]),
    absoluteUrl: editorMetadata("URLs", "Absolute URL", "Resolve a relative URL against the inspected page.", "text", "url", ["link", "href", "canonical"]),
    stripQuery: editorMetadata("URLs", "Remove query string", "Remove query parameters while preserving the URL fragment.", "url", "url", ["canonical", "tracking", "parameters"]),
    urlLastPathSegment: editorMetadata("URLs", "Last URL path segment", "Read the final non-empty segment from a URL path.", "url", "text", ["slug", "identifier", "path"]),
    canonicalUrlForTemplates: editorMetadata("URLs", "Canonical URL from templates", "Validate a URL against configured hosts and bounded path templates.", "url", "url", ["canonical", "host", "route", "identity"], [
      argumentMetadata("hosts", "Allowed hosts", "string-list", "One hostname per line.", { minimumItems: 1 }),
      argumentMetadata("templates", "Path templates", "string-list", "One bounded path template per line; use {segment} for one variable segment.", { minimumItems: 1 })
    ]),
    urlQueryParameters: editorMetadata("URL queries", "All query parameters", "Convert a URL query into a key-to-values record.", "url", "object", ["search", "parameters", "querystring"]),
    urlQueryFirst: editorMetadata("URL queries", "First query value", "Read the first populated value from configured query parameters.", "url", "text", ["search", "parameter", "fallback"], [argumentMetadata("parameters", "Parameter names", "string-list", "Query parameter names in fallback order, one per line.", { minimumItems: 1 })]),
    urlQuerySorted: editorMetadata("URL queries", "Sorted query string", "Create a deterministic query string excluding configured parameters.", "url", "text", ["search", "canonical", "parameters"], [argumentMetadata("excluded", "Excluded parameters", "string-list", "Query parameter names to omit, one per line.")]),
    urlQueryPositiveInteger: editorMetadata("URL queries", "Positive query integer", "Read a positive integer query parameter with a configured fallback.", "url", "integer", ["page", "pagination", "parameter"], [
      argumentMetadata("parameter", "Parameter name", "string", "Query parameter containing the integer.", { allowEmpty: false }),
      argumentMetadata("fallback", "Fallback value", "integer", "Positive value used when the parameter is absent or invalid.", { minimum: 1 })
    ]),
    urlQueryCollectionKey: editorMetadata("URL queries", "Query collection key", "Create a deterministic collection key from selected query parameters.", "url", "text", ["session", "dedupe", "search", "identity"], [
      argumentMetadata("prefix", "Key prefix", "string", "Text prepended to the deterministic query string."),
      argumentMetadata("excluded", "Excluded parameters", "string-list", "Query parameter names to omit, one per line.")
    ]),
    urlQuerySnapshotKey: editorMetadata("URL queries", "Query snapshot key", "Create a deterministic paginated snapshot key from a URL query.", "url", "text", ["session", "page", "pagination", "identity"], [
      argumentMetadata("prefix", "Key prefix", "string", "Text prepended to the snapshot key."),
      argumentMetadata("excluded", "Excluded parameters", "string-list", "Query parameter names to omit, one per line."),
      argumentMetadata("pageParameter", "Page parameter", "string", "Query parameter containing the page number.", { allowEmpty: false }),
      argumentMetadata("fallbackPage", "Fallback page", "integer", "Positive page used when the parameter is absent or invalid.", { minimum: 1 })
    ]),
    base64UrlDecode: editorMetadata("Encoding", "Base64 URL decode", "Decode bounded URL-safe Base64 text.", "text", "text", ["encoded", "route", "query"]),
    requirePathPrefix: editorMetadata("URL paths", "Require path prefix", "Require configured leading path segments.", "path", "path", ["guard", "route", "segments"], [argumentMetadata("segments", "Required segments", "string-list", "Leading path segments in order, one per line.", { minimumItems: 1 })]),
    pathSegmentValue: editorMetadata("URL paths", "First keyed path value", "Read the first value following a configured path key.", "path", "text", ["route", "segment", "parameter"], [argumentMetadata("key", "Segment key", "string", "Path segment whose following value should be read.", { allowEmpty: false })]),
    pathSegmentValues: editorMetadata("URL paths", "All keyed path values", "Read every value following a configured path key.", "path", "array", ["route", "segments", "skills"], [argumentMetadata("key", "Segment key", "string", "Path segment whose following values should be read.", { allowEmpty: false })]),
    pathSegmentPositiveInteger: editorMetadata("URL paths", "Positive path integer", "Read a positive keyed path integer with a configured fallback.", "path", "integer", ["page", "pagination", "segment"], [
      argumentMetadata("key", "Segment key", "string", "Path segment whose following value contains the integer.", { allowEmpty: false }),
      argumentMetadata("fallback", "Fallback value", "integer", "Positive fallback when the path value is absent or invalid.", { minimum: 1 })
    ]),
    pathWithoutSegmentPairs: editorMetadata("URL paths", "Remove keyed path pairs", "Remove configured key/value pairs from a path.", "path", "path", ["route", "canonical", "segments"], [argumentMetadata("keys", "Pair keys", "string-list", "Keys whose key/value pairs should be removed, one per line.")]),
    pathUnknownSegments: editorMetadata("URL paths", "Unknown path segments", "Report segments not explained by configured keys and literals.", "path", "array", ["guard", "route", "validation"], [
      argumentMetadata("pairedKeys", "Key/value keys", "string-list", "Segments that consume the following segment as a value."),
      argumentMetadata("literals", "Known literals", "string-list", "Standalone path segments that are expected.")
    ]),
    pathSnapshotKey: editorMetadata("URL paths", "Path snapshot key", "Create a deterministic paginated snapshot key from a keyed path.", "path", "text", ["session", "page", "pagination", "identity"], [
      argumentMetadata("prefix", "Key prefix", "string", "Text prepended to the snapshot key."),
      argumentMetadata("excludedKeys", "Excluded pair keys", "string-list", "Key/value pairs removed from the collection route."),
      argumentMetadata("pageKey", "Page key", "string", "Path key whose value contains the page number.", { allowEmpty: false }),
      argumentMetadata("fallbackPage", "Fallback page", "integer", "Positive fallback page.", { minimum: 1 })
    ]),
    requireIncludesLiteral: editorMetadata("Guards", "Require literal text", "Return missing unless text contains a configured literal value.", "text", "text", ["contains", "validate", "guard"], [argumentMetadata("literal", "Required text", "string", "Exact text that must occur in the input.", { allowEmpty: false })]),
    mapValues: editorMetadata("Collections", "Map values", "Replace a value using a configured static lookup record.", "scalar", "any", ["lookup", "enum", "normalize"], [argumentMetadata("mapping", "Lookup mapping", "object", "A JSON object mapping input strings to inert output values.")]),
    arraySlice: editorMetadata("Collections", "Slice array", "Keep a configured range of array elements.", "array", "array", ["subset", "range", "list"], [
      argumentMetadata("start", "Start index", "integer", "Zero-based starting array index."),
      argumentMetadata("end", "End index", "integer", "Optional exclusive ending array index.", { required: false })
    ]),
    joinLiteral: editorMetadata("Collections", "Join with delimiter", "Join string array values using a configured delimiter.", "array", "text", ["combine", "concatenate", "separator"], [argumentMetadata("delimiter", "Delimiter", "string", "Text inserted between values.", { maximumLength: 32 })])
  });

  for (const name of Object.keys(definitions)) {
    if (!editorDefinitions[name]) throw new Error(`Transform ${name} is missing packaged editor metadata.`);
    if (editorDefinitions[name].argumentDefinitions.length !== definitions[name].maximumArguments) {
      throw new Error(`Transform ${name} editor arguments do not match its packaged arity.`);
    }
  }

  function normalizeStep(step) {
    if (typeof step === "string" && step) return { name: step, arguments: [] };
    if (!step || typeof step !== "object" || Array.isArray(step)) throw new Error("A transform step must be a name or an object.");
    const keys = Object.keys(step);
    if (keys.some((key) => key !== "name" && key !== "args")) throw new Error(`Unknown transform step key: ${keys.find((key) => key !== "name" && key !== "args")}`);
    if (typeof step.name !== "string" || !step.name) throw new Error("A transform step requires a name.");
    if (step.args !== undefined && !Array.isArray(step.args)) throw new Error(`Transform ${step.name} args must be an array.`);
    return { name: step.name, arguments: step.args || [] };
  }

  function validateStep(step) {
    const normalized = normalizeStep(step);
    const definition = definitions[normalized.name];
    if (!definition) throw new Error(`Requires transform ${normalized.name}, which is not available.`);
    if (normalized.arguments.length < definition.minimumArguments || normalized.arguments.length > definition.maximumArguments) {
      throw new Error(`Transform ${normalized.name} received ${normalized.arguments.length} arguments; expected ${definition.minimumArguments === definition.maximumArguments ? definition.minimumArguments : `${definition.minimumArguments}-${definition.maximumArguments}`}.`);
    }
    const isStaticData = (value) => {
      if (value === null || typeof value === "string" || typeof value === "boolean") return true;
      if (typeof value === "number") return Number.isFinite(value);
      if (Array.isArray(value)) return value.every(isStaticData);
      if (value && typeof value === "object" && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null)) {
        return Object.keys(value).every((key) => key !== "__proto__" && key !== "constructor") && Object.values(value).every(isStaticData);
      }
      return false;
    };
    for (const argument of normalized.arguments) {
      if (!isStaticData(argument)) throw new Error(`Transform ${normalized.name} received an invalid static argument.`);
    }
    if (definition.validateArguments && !definition.validateArguments(normalized.arguments)) {
      throw new Error(`Transform ${normalized.name} received invalid arguments.`);
    }
    return normalized;
  }

  function validatePipeline(pipeline) {
    if (!Array.isArray(pipeline)) throw new Error("A transform pipeline must be an array.");
    return pipeline.map(validateStep);
  }

  function runPipeline(value, pipeline, context = {}) {
    let current = value;
    for (const step of validatePipeline(pipeline)) {
      if (current === null || current === undefined) return null;
      current = definitions[step.name].run(current, step.arguments, context);
    }
    return current === undefined ? null : current;
  }

  function requiredCapabilities(pipelines) {
    const names = new Set();
    for (const pipeline of pipelines) {
      for (const step of pipeline || []) names.add(normalizeStep(step).name);
    }
    return [...names].sort();
  }

  function capabilities() {
    return Object.keys(definitions).sort();
  }

  function capabilityDetails() {
    return capabilities().map((name) => Object.freeze({
      name,
      minimumArguments: definitions[name].minimumArguments,
      maximumArguments: definitions[name].maximumArguments,
      ...editorDefinitions[name]
    }));
  }

  function has(name) {
    return Object.hasOwn(definitions, name);
  }

  return { capabilities, capabilityDetails, has, normalizeStep, requiredCapabilities, runPipeline, validatePipeline };
});
