(function initializeSemanticLibraryIndexedDb(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonSemanticLibraryIndexedDb = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticLibraryIndexedDbFactory() {
  "use strict";

  const DATABASE_NAME = "site2json.semanticLibrary";
  const DATABASE_VERSION = 2;
  const META_STORE = "meta";
  const STATE_KEY = "state";
  const MIGRATION_KEY = "migration:chrome-storage-toolbox";
  const RECORD_STORES = Object.freeze(["customTypes", "properties", "patterns", "tags", "collections"]);
  const AUXILIARY_STORES = Object.freeze(["tagAssignments", "toolkits"]);
  const RESERVED_STORES = Object.freeze(["imports"]);
  const ALL_STORES = Object.freeze([META_STORE, ...RECORD_STORES, ...AUXILIARY_STORES, ...RESERVED_STORES]);
  const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  class SemanticLibraryIndexedDbError extends Error {
    constructor(code, message, details = null) {
      super(message);
      this.name = "SemanticLibraryIndexedDbError";
      this.code = code;
      if (details !== null) this.details = clone(details);
    }
  }

  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.addEventListener("success", () => resolve(request.result), { once: true });
      request.addEventListener("error", () => reject(request.error || new Error("IndexedDB request failed.")), { once: true });
    });
  }

  function transactionComplete(transaction) {
    return new Promise((resolve, reject) => {
      transaction.addEventListener("complete", () => resolve(), { once: true });
      transaction.addEventListener("abort", () => reject(transaction.error || new Error("IndexedDB transaction was aborted.")), { once: true });
      transaction.addEventListener("error", () => reject(transaction.error || new Error("IndexedDB transaction failed.")), { once: true });
    });
  }

  function requestedKey(keys, key) {
    if (keys === null || keys === undefined) return true;
    if (typeof keys === "string") return keys === key;
    if (Array.isArray(keys)) return keys.includes(key);
    return typeof keys === "object" && Object.hasOwn(keys, key);
  }

  function recordsById(records) {
    return Object.fromEntries((Array.isArray(records) ? records : []).filter((record) => record?.id).map((record) => [record.id, clone(record)]));
  }

  function assignmentObject(records) {
    return Object.fromEntries((Array.isArray(records) ? records : []).filter((record) => record?.id && Array.isArray(record.tagIds)).map((record) => [record.id, clone(record.tagIds)]));
  }

  function toolkitObject(records) {
    return Object.fromEntries((Array.isArray(records) ? records : []).filter((record) => record?.id).map((record) => [record.id, clone(record.value)]));
  }

  function equal(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
  }

  function createStorage({ indexedDB: factory, toolboxApi, legacyStorage = null, dbName = DATABASE_NAME, now = () => new Date().toISOString() } = {}) {
    if (!factory?.open) throw new SemanticLibraryIndexedDbError("INDEXEDDB_UNAVAILABLE", "IndexedDB is unavailable in this extension context.");
    if (!toolboxApi?.normalize || !toolboxApi?.STORAGE_KEY) throw new SemanticLibraryIndexedDbError("INVALID_CONFIGURATION", "The Semantic Library IndexedDB store requires the semantic toolbox API.");

    let databasePromise = null;
    let migrationPromise = null;

    function openDatabase() {
      if (databasePromise) return databasePromise;
      databasePromise = new Promise((resolve, reject) => {
        const request = factory.open(dbName, DATABASE_VERSION);
        request.addEventListener("upgradeneeded", () => {
          const database = request.result;
          if (!database.objectStoreNames.contains(META_STORE)) database.createObjectStore(META_STORE, { keyPath: "key" });
          for (const storeName of RECORD_STORES) {
            if (database.objectStoreNames.contains(storeName)) continue;
            const store = database.createObjectStore(storeName, { keyPath: "id" });
            store.createIndex("label", "label", { unique: false });
            store.createIndex("updatedAt", "updatedAt", { unique: false });
          }
          for (const storeName of [...AUXILIARY_STORES, ...RESERVED_STORES]) {
            if (!database.objectStoreNames.contains(storeName)) database.createObjectStore(storeName, { keyPath: "id" });
          }
          const imports = request.transaction.objectStore("imports");
          if (!imports.indexNames.contains("completedAt")) imports.createIndex("completedAt", "completedAt", { unique: false });
          if (!imports.indexNames.contains("status")) imports.createIndex("status", "status", { unique: false });
        });
        request.addEventListener("success", () => {
          const database = request.result;
          database.addEventListener("versionchange", () => database.close());
          resolve(database);
        }, { once: true });
        request.addEventListener("blocked", () => reject(new SemanticLibraryIndexedDbError("DATABASE_BLOCKED", "Another Site2JSON window is preventing the Semantic Library database from opening.")), { once: true });
        request.addEventListener("error", () => reject(new SemanticLibraryIndexedDbError("DATABASE_OPEN_FAILED", request.error?.message || "The Semantic Library database could not be opened.")), { once: true });
      });
      return databasePromise;
    }

    async function readDatabase(database) {
      const transaction = database.transaction([META_STORE, ...RECORD_STORES, ...AUXILIARY_STORES], "readonly");
      const completed = transactionComplete(transaction);
      const stateRequest = requestResult(transaction.objectStore(META_STORE).get(STATE_KEY));
      const migrationRequest = requestResult(transaction.objectStore(META_STORE).get(MIGRATION_KEY));
      const recordRequests = Object.fromEntries(RECORD_STORES.map((storeName) => [storeName, requestResult(transaction.objectStore(storeName).getAll())]));
      const assignmentRequest = requestResult(transaction.objectStore("tagAssignments").getAll());
      const toolkitRequest = requestResult(transaction.objectStore("toolkits").getAll());
      const [state, migration, assignments, toolkits, ...recordValues] = await Promise.all([
        stateRequest,
        migrationRequest,
        assignmentRequest,
        toolkitRequest,
        ...RECORD_STORES.map((storeName) => recordRequests[storeName])
      ]);
      await completed;
      const toolbox = {
        version: Number(state?.toolboxVersion) || toolboxApi.VERSION,
        favorites: clone(state?.favorites || []),
        ...Object.fromEntries(RECORD_STORES.map((storeName, index) => [storeName, recordsById(recordValues[index])])),
        tagAssignments: assignmentObject(assignments),
        toolkits: toolkitObject(toolkits)
      };
      return { toolbox: toolboxApi.normalize(toolbox), state: state || null, migration: migration || null };
    }

    function putSnapshot(transaction, toolbox) {
      for (const storeName of RECORD_STORES) {
        const store = transaction.objectStore(storeName);
        for (const record of Object.values(toolbox[storeName] || {})) store.put(clone(record));
      }
      const assignments = transaction.objectStore("tagAssignments");
      for (const [id, tagIds] of Object.entries(toolbox.tagAssignments || {})) assignments.put({ id, tagIds: clone(tagIds) });
      const toolkits = transaction.objectStore("toolkits");
      for (const [id, value] of Object.entries(toolbox.toolkits || {})) toolkits.put({ id, value: clone(value) });
    }

    async function initializeDatabase(database, toolbox, migration) {
      const normalized = toolboxApi.normalize(toolbox);
      const transaction = database.transaction([META_STORE, ...RECORD_STORES, ...AUXILIARY_STORES], "readwrite");
      const completed = transactionComplete(transaction);
      putSnapshot(transaction, normalized);
      transaction.objectStore(META_STORE).put({
        key: STATE_KEY,
        toolboxVersion: toolboxApi.VERSION,
        favorites: clone(normalized.favorites),
        generation: 1,
        updatedAt: now()
      });
      transaction.objectStore(META_STORE).put({ key: MIGRATION_KEY, ...migration });
      await completed;
    }

    async function markMigration(database, migration) {
      const transaction = database.transaction(META_STORE, "readwrite");
      const completed = transactionComplete(transaction);
      transaction.objectStore(META_STORE).put({ key: MIGRATION_KEY, ...migration });
      await completed;
    }

    async function ensureMigrated() {
      if (migrationPromise) return migrationPromise;
      migrationPromise = (async () => {
        const database = await openDatabase();
        const current = await readDatabase(database);
        if (current.migration?.status === "completed") return current.migration;
        let legacyValue;
        if (legacyStorage?.get) {
          const result = await legacyStorage.get(toolboxApi.STORAGE_KEY);
          legacyValue = result?.[toolboxApi.STORAGE_KEY];
        }
        const migratedAt = now();
        const migration = {
          status: "completed",
          databaseVersion: DATABASE_VERSION,
          sourceKey: toolboxApi.STORAGE_KEY,
          sourceHadData: Boolean(legacyValue),
          migratedAt
        };
        if (current.state) await markMigration(database, migration);
        else await initializeDatabase(database, toolboxApi.normalize(legacyValue), migration);
        if (legacyValue && legacyStorage?.remove) {
          try { await legacyStorage.remove(toolboxApi.STORAGE_KEY); }
          catch (_error) { /* The committed migration marker prevents replay; stale-source cleanup may safely retry later. */ }
        }
        return { key: MIGRATION_KEY, ...migration };
      })().catch((error) => {
        migrationPromise = null;
        if (error instanceof SemanticLibraryIndexedDbError) throw error;
        throw new SemanticLibraryIndexedDbError("MIGRATION_FAILED", `The Semantic Library could not migrate to IndexedDB: ${error.message}`);
      });
      return migrationPromise;
    }

    function syncRecords(store, current, next, wrap = (id, value) => value) {
      for (const id of Object.keys(current || {})) if (!Object.hasOwn(next || {}, id)) store.delete(id);
      for (const [id, value] of Object.entries(next || {})) {
        if (!Object.hasOwn(current || {}, id) || !equal(current[id], value)) store.put(clone(wrap(id, value)));
      }
    }

    async function writeToolbox(value, importManifest = null) {
      await ensureMigrated();
      const database = await openDatabase();
      const current = await readDatabase(database);
      const next = toolboxApi.normalize(value);
      const transaction = database.transaction([META_STORE, ...RECORD_STORES, ...AUXILIARY_STORES, ...(importManifest ? ["imports"] : [])], "readwrite");
      const completed = transactionComplete(transaction);
      for (const storeName of RECORD_STORES) syncRecords(transaction.objectStore(storeName), current.toolbox[storeName], next[storeName]);
      syncRecords(transaction.objectStore("tagAssignments"), current.toolbox.tagAssignments, next.tagAssignments, (id, tagIds) => ({ id, tagIds }));
      syncRecords(transaction.objectStore("toolkits"), current.toolbox.toolkits, next.toolkits, (id, toolkit) => ({ id, value: toolkit }));
      transaction.objectStore(META_STORE).put({
        key: STATE_KEY,
        toolboxVersion: toolboxApi.VERSION,
        favorites: clone(next.favorites),
        generation: (Number(current.state?.generation) || 0) + 1,
        updatedAt: now()
      });
      if (importManifest) transaction.objectStore("imports").put(clone(importManifest));
      await completed;
      return next;
    }

    async function listImports() {
      await ensureMigrated();
      const database = await openDatabase();
      const transaction = database.transaction("imports", "readonly");
      const completed = transactionComplete(transaction);
      const records = await requestResult(transaction.objectStore("imports").getAll());
      await completed;
      return clone(records).sort((left, right) => String(right.completedAt || right.startedAt || "").localeCompare(String(left.completedAt || left.startedAt || "")) || String(right.id).localeCompare(String(left.id)));
    }

    async function getImport(id) {
      await ensureMigrated();
      const database = await openDatabase();
      const transaction = database.transaction("imports", "readonly");
      const completed = transactionComplete(transaction);
      const record = await requestResult(transaction.objectStore("imports").get(String(id || "")));
      await completed;
      return clone(record || null);
    }

    async function commitImport(toolbox, manifest) {
      if (!manifest?.id) throw new SemanticLibraryIndexedDbError("INVALID_IMPORT", "An import manifest identifier is required.");
      await writeToolbox(toolbox, manifest);
      return clone(manifest);
    }

    async function get(keys) {
      if (!requestedKey(keys, toolboxApi.STORAGE_KEY)) return {};
      await ensureMigrated();
      const value = (await readDatabase(await openDatabase())).toolbox;
      return { [toolboxApi.STORAGE_KEY]: clone(value) };
    }

    async function set(values) {
      if (!values || !Object.hasOwn(values, toolboxApi.STORAGE_KEY)) return;
      await writeToolbox(values[toolboxApi.STORAGE_KEY]);
    }

    async function remove(keys) {
      if (!requestedKey(keys, toolboxApi.STORAGE_KEY)) return;
      await writeToolbox(toolboxApi.normalize(null));
    }

    async function diagnostics() {
      await ensureMigrated();
      const database = await openDatabase();
      const transaction = database.transaction(ALL_STORES, "readonly");
      const completed = transactionComplete(transaction);
      const countRequests = ALL_STORES.filter((name) => name !== META_STORE).map((storeName) => requestResult(transaction.objectStore(storeName).count()).then((count) => [storeName, count]));
      const stateRequest = requestResult(transaction.objectStore(META_STORE).get(STATE_KEY));
      const migrationRequest = requestResult(transaction.objectStore(META_STORE).get(MIGRATION_KEY));
      const [countEntries, state, migration] = await Promise.all([Promise.all(countRequests), stateRequest, migrationRequest]);
      await completed;
      const counts = Object.fromEntries(countEntries);
      return { dbName, databaseVersion: DATABASE_VERSION, generation: Number(state?.generation) || 0, counts, migration: clone(migration || null) };
    }

    async function close() {
      if (!databasePromise) return;
      const database = await databasePromise.catch(() => null);
      database?.close();
      databasePromise = null;
      migrationPromise = null;
    }

    async function deleteDatabase() {
      await close();
      await requestResult(factory.deleteDatabase(dbName));
    }

    const semanticImports = Object.freeze({ commit: commitImport, get: getImport, list: listImports });
    return Object.freeze({ close, deleteDatabase, diagnostics, get, remove, set, ready: ensureMigrated, dbName, semanticImports });
  }

  return Object.freeze({
    ALL_STORES,
    DATABASE_NAME,
    DATABASE_VERSION,
    MIGRATION_KEY,
    SemanticLibraryIndexedDbError,
    createStorage
  });
});
