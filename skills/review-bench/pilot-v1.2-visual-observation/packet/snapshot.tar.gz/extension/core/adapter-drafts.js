(function initializeAdapterDraftRegistry(root, factory) {
  "use strict";
  const dsl = root.Site2JsonDsl || (typeof require === "function" ? require("./dsl") : null);
  const registry = root.Site2JsonAdapterRegistry || (typeof require === "function" ? require("./adapter-registry") : null);
  const yamlParser = root.Site2JsonYamlParser || (typeof require === "function" ? require("../../lib/yaml-parser") : null);
  const api = factory(dsl, registry, yamlParser);
  root.Site2JsonAdapterDraftRegistry = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function adapterDraftRegistryFactory(dsl, registry, yamlParser) {
  "use strict";

  const STORAGE_KEY = "site2jsonAdapterDrafts";
  const ACTIVE_DRAFT_KEY = "site2jsonActiveAdapterDraft";
  const PUBLISH_LOCK = "site2json-adapter-publish";

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function draftId(adapterId) {
    return adapterId ? `adapter:${adapterId}` : `new:${crypto.randomUUID()}`;
  }

  function normalizeDrafts(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((draft) => draft && typeof draft.id === "string" && draft.status === "draft");
  }

  function createFromPublished(entry, { now = new Date().toISOString() } = {}) {
    if (!entry?.definition || !entry?.definitionDigest) throw new Error("A stored adapter is required to start an edit.");
    return {
      id: draftId(entry.id),
      status: "draft",
      adapterId: entry.id,
      sourceName: /\.ya?ml$/i.test(entry.sourceName || "") ? entry.sourceName : `${entry.id}.yaml`,
      baseDefinitionDigest: entry.definitionDigest,
      baseSourceDigest: entry.sourceDigest,
      baseDefinition: clone(entry.definition),
      workingDefinition: clone(entry.definition),
      editorState: clone(entry.editorState || null),
      createdAt: now,
      updatedAt: now
    };
  }

  function createNew({ id = draftId(null), now = new Date().toISOString(), pageUrl = null } = {}) {
    return {
      id,
      status: "draft",
      adapterId: null,
      sourceName: null,
      baseDefinitionDigest: null,
      baseSourceDigest: null,
      baseDefinition: null,
      workingDefinition: null,
      editorState: pageUrl ? { pageUrl } : null,
      createdAt: now,
      updatedAt: now
    };
  }

  function update(draft, { workingDefinition = draft.workingDefinition, editorState = draft.editorState, now = new Date().toISOString() } = {}) {
    if (!draft?.id) throw new Error("A draft is required.");
    const definition = workingDefinition ? clone(workingDefinition) : null;
    return {
      ...draft,
      adapterId: definition?.adapter || draft.adapterId || null,
      sourceName: draft.sourceName || (definition?.adapter ? `${definition.adapter}.yaml` : null),
      workingDefinition: definition,
      editorState: clone(editorState),
      updatedAt: now
    };
  }

  function upsert(drafts, draft) {
    const current = normalizeDrafts(drafts);
    const duplicateAdapter = draft.adapterId && current.find((candidate) => candidate.adapterId === draft.adapterId && candidate.id !== draft.id);
    if (duplicateAdapter) throw new Error(`A draft already exists for ${draft.adapterId}.`);
    const index = current.findIndex((candidate) => candidate.id === draft.id);
    if (index < 0) return [...current, draft];
    const next = [...current];
    next[index] = draft;
    return next;
  }

  function remove(drafts, id) {
    return normalizeDrafts(drafts).filter((draft) => draft.id !== id);
  }

  function forAdapter(drafts, adapterId) {
    return normalizeDrafts(drafts).find((draft) => draft.adapterId === adapterId) || null;
  }

  async function load(storage = chrome.storage.local) {
    const stored = await storage.get(STORAGE_KEY);
    return normalizeDrafts(stored[STORAGE_KEY]);
  }

  async function save(drafts, storage = chrome.storage.local) {
    await storage.set({ [STORAGE_KEY]: normalizeDrafts(drafts) });
  }

  async function activate(id, storage = chrome.storage.local) {
    await storage.set({ [ACTIVE_DRAFT_KEY]: id || null });
  }

  async function active(storage = chrome.storage.local) {
    const stored = await storage.get(ACTIVE_DRAFT_KEY);
    return typeof stored[ACTIVE_DRAFT_KEY] === "string" ? stored[ACTIVE_DRAFT_KEY] : null;
  }

  function serializeDefinition(definition, parser = yamlParser || globalThis.Site2JsonYamlParser) {
    const valid = dsl.validateDefinition(definition);
    if (!parser?.stringify) throw new Error("The packaged YAML serializer is unavailable.");
    return parser.stringify(valid);
  }

  async function publish(draft, _entries, _drafts, {
    storage = chrome.storage.local,
    parser = yamlParser || globalThis.Site2JsonYamlParser,
    now = new Date().toISOString(),
    lockManager = globalThis.navigator?.locks
  } = {}) {
    async function commit() {
      if (!draft?.workingDefinition) throw new Error("Build a valid adapter definition before publishing this draft.");
      const definition = dsl.validateDefinition(draft.workingDefinition);
      // The caller's lists are UI caches. Storage is authoritative at commit time.
      const latestEntries = await registry.load(storage);
      const latestDrafts = await load(storage);
      const current = latestEntries.find((entry) => entry.id === definition.adapter) || null;
      if (draft.baseDefinitionDigest) {
        if (!current || current.definitionDigest !== draft.baseDefinitionDigest) {
          throw new Error(`${definition.adapter} changed after this draft was created. Export the draft or discard it, then start from the current adapter.`);
        }
      } else if (current) {
        throw new Error(`${definition.adapter} already exists. Start an edit from the stored adapter instead of publishing this new draft.`);
      }
      const sourceText = serializeDefinition(definition, parser);
      const { entry } = await registry.createEntry(new TextEncoder().encode(sourceText), draft.sourceName || `${definition.adapter}.yaml`, {
        importedAt: now,
        enabled: current?.enabled ?? true,
        editorState: draft.editorState
      });
      const nextEntries = registry.upsert(latestEntries, entry);
      const nextDrafts = remove(latestDrafts, draft.id);
      await storage.set({
        [registry.STORAGE_KEY]: nextEntries,
        [STORAGE_KEY]: nextDrafts,
        [ACTIVE_DRAFT_KEY]: null
      });
      return { entry, entries: nextEntries, drafts: nextDrafts, sourceText };
    }
    return lockManager?.request ? lockManager.request(PUBLISH_LOCK, commit) : commit();
  }

  return {
    ACTIVE_DRAFT_KEY,
    PUBLISH_LOCK,
    STORAGE_KEY,
    active,
    activate,
    createFromPublished,
    createNew,
    forAdapter,
    load,
    normalizeDrafts,
    publish,
    remove,
    save,
    serializeDefinition,
    update,
    upsert
  };
});
