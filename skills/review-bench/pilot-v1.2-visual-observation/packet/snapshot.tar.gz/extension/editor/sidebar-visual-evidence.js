"use strict";
(function exposeVisualEvidence(root) {
  const observations = root.Site2JsonVisualEvidenceObservation || (typeof require === "function" ? require("../ir/visual-evidence-observation") : null);
  const clone = (value) => value == null ? value : JSON.parse(JSON.stringify(value));
  const normalizeTarget = (target, index) => ({
    id: String(target?.id || `target-${index + 1}`), kind: target?.kind === "type" ? "type" : "field",
    label: String(target?.label || target?.id || `Field ${index + 1}`), semanticId: target?.semanticId || null,
    semantic: clone(target?.semantic || null), resolution: target?.resolution === "unresolved" ? "unresolved" : "resolved",
    alternatives: clone(target?.alternatives || []), detectionRunId: target?.detectionRunId || null,
    currentEvidence: clone(target?.currentEvidence || null), repeatedGroup: clone(target?.repeatedGroup || null)
  });
  function create({ document, onPick, onCancel, onComplete, onBack, now = () => new Date().toISOString(), nextObservationId = () => `vo-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}` }) {
    const elements = Object.fromEntries(Object.entries({ section:"step-visual-evidence",back:"back-from-visual-evidence",caller:"visual-evidence-caller",progress:"visual-evidence-progress",target:"visual-evidence-target",provenance:"visual-evidence-provenance",status:"visual-evidence-status",list:"visual-evidence-fields",pick:"visual-evidence-pick",skip:"visual-evidence-skip",reselect:"visual-evidence-reselect",cancel:"visual-evidence-cancel",complete:"visual-evidence-complete" }).map(([key,id]) => [key, document.querySelector(`#${id}`)]));
    let session = null;
    const active = () => session?.targets?.[session.index] || null;
    const decision = (id) => session?.decisions?.[id] || null;
    function setStatus(kind, message) { elements.status.className = `status ${kind || ""}`.trim(); elements.status.textContent = message || ""; }
    function nextPending(from = 0) {
      for (let offset = 0; offset < session.targets.length; offset += 1) { const index = (from + offset) % session.targets.length; if (!decision(session.targets[index].id)) return index; }
      return Math.max(0, Math.min(from, session.targets.length - 1));
    }
    function render() {
      const target = active(); const resolved = session.targets.filter((item) => decision(item.id)).length;
      elements.caller.textContent = `From ${session.callerLabel}`; elements.progress.textContent = `${resolved} of ${session.targets.length} fields reviewed`;
      elements.target.textContent = target?.label || "No remaining field";
      elements.provenance.textContent = target?.currentEvidence ? "Automatic inference found evidence. Select the rendered page only if it is missing or wrong." : "Automatic inference did not establish page evidence for this target.";
      elements.list.replaceChildren();
      session.targets.forEach((item, index) => { const button = document.createElement("button"); const authored = decision(item.id); button.type="button"; button.className=`visual-evidence-field${index===session.index?" active":""}${authored?` state-${authored.status}`:" state-inferred"}`; button.textContent=`${item.label} · ${authored?.status === "authored" ? "authored" : authored?.status === "unresolved" ? "unresolved" : "automatic"}`; button.addEventListener("click",()=>{session.index=index;render();}); elements.list.append(button); });
      const authored = target && decision(target.id)?.status === "authored"; elements.reselect.hidden=!authored; elements.pick.hidden=Boolean(authored); elements.complete.disabled=resolved!==session.targets.length;
      setStatus(resolved===session.targets.length?"ready":"", resolved===session.targets.length ? "Every target has an authored or unresolved decision. Complete to return it to the caller." : "Move over the rendered page and choose evidence, or leave this field unresolved.");
    }
    async function pick() { const target=active(); if (!target) return; setStatus("loading",`Select rendered evidence for ${target.label}. Press Escape to return without changing it.`); await onPick?.(clone(target)); }
    function advance(){session.index=nextPending(session.index+1);render();}
    function record(selection){const target=active();if(!session||!target)return;const status=target.resolution==="unresolved"?"unresolved":"authored";session.decisions[target.id]=observations.observation({status,target,selection,context:session.context,observationId:nextObservationId(),authoredAt:now()});advance();}
    function skip(){const target=active();if(!target)return;session.decisions[target.id]=observations.observation({status:"unresolved",target,selection:null,context:session.context,observationId:nextObservationId(),authoredAt:now()});advance();}
    const result=(status)=>({kind:"visual-evidence-decisions",status,caller:session.caller,decisions:clone(session.decisions),targetOrder:session.targets.map((target)=>target.id)});
    function close(callback,status){if(!session)return;const output=result(status);session=null;elements.section.hidden=true;callback?.(output);}
    elements.pick?.addEventListener("click",()=>pick().catch((error)=>setStatus("error",error.message))); elements.reselect?.addEventListener("click",()=>pick().catch((error)=>setStatus("error",error.message))); elements.skip?.addEventListener("click",skip); elements.cancel?.addEventListener("click",()=>close(onCancel,"cancelled")); elements.back?.addEventListener("click",()=>close(onBack,"back")); elements.complete?.addEventListener("click",()=>close(onComplete,"completed"));
    return Object.freeze({open(invocation){const targets=(invocation?.targets||[]).map(normalizeTarget);if(!targets.length)throw new Error("Visual Evidence needs at least one semantic target.");session={caller:String(invocation.caller||"unknown"),callerLabel:String(invocation.callerLabel||invocation.caller||"the previous workspace"),context:clone(invocation.context||{}),targets,index:0,decisions:clone(invocation.decisions||{})};session.index=nextPending(0);elements.section.hidden=false;render();elements.back?.focus?.({preventScroll:true});},record,pickerCancelled(){if(session)setStatus("","Selection cancelled. The active field has not changed.");},isOpen:()=>Boolean(session),snapshot:()=>session?clone(session):null});
  }
  const api=Object.freeze({create,normalizeTarget}); root.Site2JsonVisualEvidence=api; if(typeof module==="object"&&module.exports)module.exports=api;
})(typeof globalThis === "object" ? globalThis : this);
