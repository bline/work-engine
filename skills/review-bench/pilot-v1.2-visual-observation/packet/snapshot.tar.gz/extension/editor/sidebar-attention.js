"use strict";

(function exposeSidebarAttention(root) {
  const instances = new WeakMap();

  function create({ document } = {}) {
    if (!document) return null;
    if (instances.has(document)) return instances.get(document);
    const button = document?.querySelector?.("#site2json-attention-button");
    const badge = document?.querySelector?.("#site2json-attention-count");
    const panel = document?.querySelector?.("#site2json-attention-panel");
    const list = document?.querySelector?.("#site2json-attention-list");
    const issues = new Map();
    const dismissed = new Set();
    const navigators = new Map();

    function visibleIssues() {
      return [...issues.values()].filter((issue) => !dismissed.has(issue.id));
    }

    function render() {
      if (!button || !panel || !list) return;
      const visible = visibleIssues();
      button.hidden = visible.length === 0;
      badge.textContent = String(visible.length);
      list.replaceChildren();
      for (const issue of visible) {
        const row = document.createElement("div");
        row.className = `site2json-attention-item ${issue.severity === "warning" ? "warning" : "error"}`;
        const visit = document.createElement("button");
        visit.type = "button";
        visit.className = "site2json-attention-visit";
        visit.textContent = issue.message;
        visit.title = "Go to where this happened";
        visit.addEventListener("click", () => {
          const navigate = navigators.get(issue.destination?.kind);
          navigate?.(issue.destination, issue);
          panel.hidden = true;
          button.setAttribute("aria-expanded", "false");
        });
        const dismiss = document.createElement("button");
        dismiss.type = "button";
        dismiss.className = "site2json-attention-dismiss";
        dismiss.setAttribute("aria-label", `Dismiss: ${issue.message}`);
        dismiss.textContent = "×";
        dismiss.addEventListener("click", () => {
          dismissed.add(issue.id);
          render();
        });
        row.append(visit, dismiss);
        list.append(row);
      }
      if (!visible.length) {
        panel.hidden = true;
        button.setAttribute("aria-expanded", "false");
      }
    }

    function sync(scope, nextIssues = []) {
      const nextIds = new Set(nextIssues.map((issue) => issue.id));
      for (const [id, issue] of issues) {
        if (issue.scope === scope && !nextIds.has(id)) {
          issues.delete(id);
          dismissed.delete(id);
        }
      }
      for (const issue of nextIssues) {
        if (!issue?.id || !issue?.message || !["error", "warning"].includes(issue.severity)) continue;
        issues.set(issue.id, { ...issue, scope });
      }
      render();
    }

    function resolve(id) {
      issues.delete(id);
      dismissed.delete(id);
      render();
    }

    function registerNavigator(kind, navigate) {
      if (kind && typeof navigate === "function") navigators.set(kind, navigate);
      return () => navigators.delete(kind);
    }

    button?.addEventListener("click", () => {
      panel.hidden = !panel.hidden;
      button.setAttribute("aria-expanded", String(!panel.hidden));
    });

    render();
    const instance = Object.freeze({ sync, resolve, registerNavigator });
    instances.set(document, instance);
    return instance;
  }

  const api = Object.freeze({ create });
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.Site2JsonAttention = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
