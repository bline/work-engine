"use strict";

(function exposeDetectionFirst(root) {
  const schemaTypeIcons = root.Site2JsonSchemaTypeIcons || (typeof require === "function" ? require("./schema-type-icons") : null);
  const visualEvidenceObservation = root.Site2JsonVisualEvidenceObservation || (typeof require === "function" ? require("../ir/visual-evidence-observation") : null);

  function leaf(value) {
    return String(value || "Thing").split(/[\/#:]/).filter(Boolean).pop() || "Thing";
  }

  function graphEntities(detection) {
    const output = detection?.output || detection?.compact || {};
    if (Array.isArray(output?.["@graph"])) return output["@graph"];
    return output && typeof output === "object" ? [output] : [];
  }

  function createIcon(document, type, className) {
    if (schemaTypeIcons?.createIcon) return schemaTypeIcons.createIcon(document, leaf(type), { className });
    const fallback = document.createElement("span");
    fallback.className = className;
    fallback.textContent = "●";
    return fallback;
  }

  function displayValue(value) {
    if (Array.isArray(value)) return value.map(displayValue).join(", ");
    if (value && typeof value === "object") return JSON.stringify(value);
    return String(value ?? "");
  }

  function create({ document, onDecision, onFocus, onClearFocus, onVisualEvidence, onManual, onRefresh, onContinue }) {
    const elements = {
      section: document.querySelector("#step-page-detection"),
      status: document.querySelector("#page-detection-status"),
      summary: document.querySelector("#page-detection-summary"),
      results: document.querySelector("#page-detection-results"),
      manual: document.querySelector("#use-manual-structure-button"),
      refresh: document.querySelector("#refresh-page-detection-button"),
      continueButton: document.querySelector("#review-detected-results-button")
    };
    let report = null;
    let decisions = {};

    function setStatus(kind, message) {
      elements.status.className = `status ${kind || ""}`.trim();
      elements.status.textContent = message || "";
    }

    function decisionFor(id) {
      return decisions[id]?.state || "undecided";
    }

    function updateSummary() {
      if (!report?.detection?.summary) {
        elements.summary.hidden = true;
        return;
      }
      const summary = report.detection.summary;
      const selected = report?.detection?.selected || [];
      const accepted = Object.values(decisions).filter((decision) => decision.state === "accepted").length;
      const rejected = Object.values(decisions).filter((decision) => decision.state === "rejected").length;
      const undecided = selected.filter((detection) => decisionFor(detection.id) === "undecided").length;
      elements.summary.hidden = false;
      elements.summary.replaceChildren();
      for (const text of [
        `${summary.selectedCount} detected group${summary.selectedCount === 1 ? "" : "s"}`,
        `${summary.entityCount} rendered result${summary.entityCount === 1 ? "" : "s"}`,
        `${accepted} accepted`,
        `${rejected} rejected`
      ]) {
        const item = document.createElement("span");
        item.textContent = text;
        elements.summary.append(item);
      }
      if (elements.continueButton) {
        elements.continueButton.hidden = false;
        elements.continueButton.disabled = accepted === 0 || undecided > 0;
      }
    }

    function updateStatus() {
      if (!report?.detection) return;
      const selected = report.detection.selected || [];
      const undecided = selected.filter((detection) => decisionFor(detection.id) === "undecided");
      const uncertain = undecided.filter((detection) => detection.status === "review").length;
      const duration = Number(report.detection.durationMs || 0) + Number(report?.survey?.durationMs || 0);
      if (undecided.length) {
        const uncertainty = uncertain
          ? ` ${uncertain} ${uncertain === 1 ? "is" : "are"} below automatic semantic confidence.`
          : "";
        setStatus("warning", `${undecided.length} detected group${undecided.length === 1 ? " awaits" : "s await"} review.${uncertainty} Detection sampled only the currently open page.`);
        return;
      }
      setStatus("ready", `All ${selected.length} detected group${selected.length === 1 ? " has" : "s have"} an explicit review decision. Detection sampled only the currently open page in ${Math.round(duration)} ms.`);
    }

    function choose(detection, nextState, control) {
      decisions = {
        ...decisions,
        [detection.id]: {
          state: nextState,
          detectedTypes: [...(detection.typeSignature || [])],
          reviewedAt: new Date().toISOString()
        }
      };
      control.closest(".detection-review-control")?.classList.remove("expanded");
      renderResults();
      onDecision?.(detection, decisions[detection.id], { ...decisions });
    }

    function reviewControl(detection) {
      const wrapper = document.createElement("div");
      const current = decisionFor(detection.id);
      wrapper.className = `detection-review-control state-${current}`;
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.className = "detection-review-toggle";
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", `${current === "undecided" ? "Review" : current} ${detection.typeSignature.map(leaf).join(" or ")} detection`);
      toggle.title = current === "undecided" ? "Review this detected group" : `Detection ${current}`;
      toggle.textContent = current === "accepted" ? "✓" : current === "rejected" ? "×" : "?";
      const choices = document.createElement("div");
      choices.className = "detection-review-choices";
      for (const [state, symbol, label] of [["accepted", "✓", "Accept"], ["rejected", "⌫", "Reject"], ["undecided", "?", "Leave undecided"]]) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `detection-review-choice ${state}`;
        button.textContent = symbol;
        button.title = label;
        button.setAttribute("aria-label", label);
        button.addEventListener("click", () => choose(detection, state, button));
        choices.append(button);
      }
      toggle.addEventListener("click", () => {
        const expanded = !wrapper.classList.contains("expanded");
        wrapper.classList.toggle("expanded", expanded);
        toggle.setAttribute("aria-expanded", String(expanded));
      });
      wrapper.append(toggle, choices);
      return wrapper;
    }

    function entityCard(detection, entity, entityIndex) {
      const card = document.createElement("article");
      const type = leaf(entity?.["@type"] || detection.typeSignature?.[0]);
      card.className = "detection-card";
      card.tabIndex = 0;
      const header = document.createElement("header");
      const icon = createIcon(document, type, "schema-type-icon detection-card-icon");
      const title = document.createElement("strong");
      title.textContent = type;
      header.append(icon, title);
      const fields = document.createElement("dl");
      fields.className = "detection-fields";
      const semanticTargets = visualEvidenceObservation?.detectionTargets?.(detection).filter((target) => target.entityIndex === entityIndex) || [];
      const displayedFields = semanticTargets.length
        ? semanticTargets.slice(0, 6).map((target) => [leaf(target.semantic.propertyTerm), target.currentEvidence?.value, target])
        : Object.entries(entity || {}).filter(([name]) => name !== "@type" && name !== "@context").slice(0, 6).map(([name, value]) => [name, value, null]);
      for (const [name, value, semanticTarget] of displayedFields) {
        const term = document.createElement("dt");
        term.textContent = name;
        const description = document.createElement("dd");
        const renderedValue = document.createElement("span");
        renderedValue.textContent = displayValue(value);
        description.title = displayValue(value);
        description.addEventListener("mouseenter", () => onFocus?.({ detectionId: detection.id, entityIndex, role: name }));
        description.addEventListener("mouseleave", () => onClearFocus?.());
        if (semanticTarget && onVisualEvidence) {
          const author = document.createElement("button");
          author.type = "button";
          author.className = "secondary compact detection-evidence-button";
          author.textContent = "Provide page evidence";
          author.setAttribute("aria-label", `Provide page evidence for ${semanticTarget.label}`);
          author.addEventListener("click", (event) => { event.stopPropagation(); onVisualEvidence({ caller: "detection", detectionId: detection.id, targets: [semanticTarget] }); });
          description.replaceChildren(renderedValue, author);
        } else description.replaceChildren(renderedValue);
        fields.append(term, description);
      }
      card.addEventListener("mouseenter", () => onFocus?.({ detectionId: detection.id, entityIndex }));
      card.addEventListener("mouseleave", () => onClearFocus?.());
      card.addEventListener("focus", () => onFocus?.({ detectionId: detection.id, entityIndex }));
      card.addEventListener("blur", () => onClearFocus?.());
      card.append(header, fields);
      return card;
    }

    function groupCard(detection) {
      const group = document.createElement("section");
      group.className = `detection-group state-${decisionFor(detection.id)}`;
      group.dataset.detectionId = detection.id;
      const heading = document.createElement("header");
      heading.className = "detection-group-heading";
      const identity = document.createElement("div");
      const repeat = document.createElement("span");
      repeat.className = "detection-repeat-glyph";
      repeat.textContent = detection.grouping?.entityCount > 1 ? "⟳" : "1";
      repeat.title = detection.grouping?.entityCount > 1 ? "Repeating structure" : "Single detected item";
      const label = document.createElement("div");
      const types = (detection.typeSignature || []).map(leaf);
      const name = document.createElement("strong");
      name.textContent = types.length ? types.join(" · ") : "Unresolved type";
      const meta = document.createElement("small");
      meta.textContent = `${detection.grouping?.entityCount || 0} item${detection.grouping?.entityCount === 1 ? "" : "s"} · ${detection.status === "review" ? "needs review" : "credible inference"}`;
      label.append(name, meta);
      identity.append(repeat, label);
      heading.append(identity, reviewControl(detection));
      const cards = document.createElement("div");
      cards.className = "detection-card-grid";
      const entities = graphEntities(detection);
      for (const [index, entity] of entities.slice(0, 6).entries()) cards.append(entityCard(detection, entity, index));
      if (entities.length > 6) {
        const more = document.createElement("div");
        more.className = "detection-more";
        more.textContent = `+ ${entities.length - 6} more detected result${entities.length - 6 === 1 ? "" : "s"}`;
        cards.append(more);
      }
      group.addEventListener("mouseenter", (event) => {
        if (event.target === group || event.target.closest(".detection-group-heading")) onFocus?.({ detectionId: detection.id });
      });
      group.addEventListener("mouseleave", () => onClearFocus?.());
      group.append(heading, cards);
      return group;
    }

    function renderResults() {
      elements.results.replaceChildren();
      const selected = report?.detection?.selected || [];
      for (const detection of selected) elements.results.append(groupCard(detection));
      if (!selected.length && report) {
        const empty = document.createElement("p");
        empty.className = "hint";
        empty.textContent = "No credible extraction was detected. You can still select the page structure manually.";
        elements.results.append(empty);
      }
      updateSummary();
      updateStatus();
    }

    elements.manual?.addEventListener("click", () => onManual?.());
    elements.refresh?.addEventListener("click", () => onRefresh?.());
    elements.continueButton?.addEventListener("click", () => {
      if (!onContinue || elements.continueButton.disabled) return;
      const next = onContinue({ report, decisions: { ...decisions } });
      if (next?.catch) next.catch((error) => setStatus("error", error.message || "Could not continue from detected groups."));
    });

    return Object.freeze({
      showLoading(message = "Detecting rendered structures, fields, and likely Schema.org types…") {
        elements.section.hidden = false;
        elements.refresh.disabled = true;
        elements.results.replaceChildren();
        elements.summary.hidden = true;
        setStatus("loading", message);
      },
      showError(message) {
        elements.section.hidden = false;
        elements.refresh.disabled = false;
        report = null;
        renderResults();
        setStatus("error", message);
      },
      render(nextReport, nextDecisions = {}) {
        report = nextReport;
        decisions = { ...nextDecisions };
        elements.section.hidden = false;
        elements.refresh.disabled = false;
        renderResults();
      },
      hide() { elements.section.hidden = true; },
      decisions: () => ({ ...decisions }),
      report: () => report
    });
  }

  const api = Object.freeze({ create, graphEntities, leaf });
  root.Site2JsonDetectionFirst = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
