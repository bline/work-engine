(function initializeSchemaVocabulary(root, factory) {
  "use strict";
  const schemaCatalog = root.Site2JsonSchemaCatalog || (typeof require === "function" ? require("./schema-catalog.generated") : null);
  const mappingEvidence = root.Site2JsonFieldMappingEvidence || (typeof require === "function" ? require("../authoring/field-mapping-evidence") : null);
  const api = factory(schemaCatalog, mappingEvidence);
  root.Site2JsonSchemaVocabulary = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function schemaVocabularyFactory(schemaCatalog, mappingEvidence) {
  "use strict";

  if (!schemaCatalog?.classes || !schemaCatalog?.properties) throw new Error("The packaged Schema.org catalog is unavailable.");
  if (!mappingEvidence?.rank) throw new Error("The shared field-mapping evidence analyzer is unavailable.");
  const MANY_DEFAULTS = new Set(["author", "employmentType", "image", "industry", "jobLocation", "sameAs", "skills"]);
  const RANGE_PREFERENCE = ["Text", "URL", "Date", "DateTime", "Number", "Integer", "Boolean"];
  const DATA_TYPE_ROOTS = new Set(["Boolean", "Date", "DateTime", "Number", "Text", "Time"]);
  const NON_ENTITY_ROOTS = new Set(["DataType", "Enumeration"]);
  const PROPERTY_SALIENCE = Object.freeze({
    url: 100, identifier: 98, name: 94, title: 94, headline: 92,
    description: 82, articleBody: 80, datePosted: 78, datePublished: 78,
    image: 70, author: 68, jobLocation: 66, hiringOrganization: 66,
    price: 64, baseSalary: 64, skills: 62
  });
  const propertyCache = new Map();

  function typeNames() { return Object.keys(schemaCatalog.classes); }
  function typeInfo(type) { return schemaCatalog.classes[type] ? { name: type, ...schemaCatalog.classes[type] } : null; }
  function propertySalience(name) {
    const leaf = String(name || "").split(/[#:/.]/).filter(Boolean).at(-1) || "field";
    return PROPERTY_SALIENCE[leaf] || 40;
  }

  function ancestors(type, found = new Set()) {
    if (!type || found.has(type) || !schemaCatalog.classes[type]) return found;
    found.add(type);
    for (const parent of schemaCatalog.classes[type].supers || []) ancestors(parent, found);
    return found;
  }

  function preferredRange(ranges) {
    for (const preferred of RANGE_PREFERENCE) if (ranges.includes(preferred)) return preferred;
    return ranges[0] || "Thing";
  }

  function isDataType(type) {
    return Array.from(ancestors(type)).some((candidate) => DATA_TYPE_ROOTS.has(candidate));
  }

  function typeIs(type, expected) {
    return ancestors(type).has(expected);
  }

  function isEntityType(type) {
    if (!schemaCatalog.classes[type] || isDataType(type)) return false;
    return !Array.from(ancestors(type)).some((candidate) => NON_ENTITY_ROOTS.has(candidate));
  }

  function nestedTypes(ranges) {
    // A Text/URL alternative means this property is normally scalar in the
    // editor. Do not manufacture paths such as description.description or
    // image.image merely because Schema.org also permits an object form.
    if (ranges.some((range) => Array.from(ancestors(range)).includes("Text"))) return [];
    const structured = ranges.filter((range) => schemaCatalog.classes[range] && !isDataType(range));
    // Do not union children from incompatible representations. Schema.org puts
    // the primary structured representation first (for example MonetaryAmount
    // before PriceSpecification on baseSalary).
    return structured.slice(0, 1);
  }

  function propertiesFor(type) {
    const resolvedType = schemaCatalog.classes[type] ? type : "Thing";
    if (propertyCache.has(resolvedType)) return propertyCache.get(resolvedType);
    const allowedDomains = ancestors(resolvedType);
    const properties = Object.entries(schemaCatalog.properties)
      .filter(([, definition]) => definition.domains.some((domain) => allowedDomains.has(domain)))
      .map(([name, definition]) => ({
        name,
        domains: [...definition.domains],
        ranges: [...definition.ranges],
        valueType: preferredRange(definition.ranges),
        cardinality: MANY_DEFAULTS.has(name) ? "many" : "one",
        description: definition.description,
        status: definition.status,
        ...(definition.supersededBy ? { supersededBy: definition.supersededBy } : {})
      }));
    propertyCache.set(resolvedType, properties);
    return properties;
  }

  function directProperty(type, name) {
    return propertiesFor(type).find((candidate) => candidate.name === name) || null;
  }

  function property(type, path) {
    const segments = String(path || "").split(".");
    let currentTypes = [type];
    let found = null;
    for (const segment of segments) {
      found = currentTypes.flatMap((currentType) => propertiesFor(currentType)).find((candidate) => candidate.name === segment) || null;
      if (!found) return null;
      currentTypes = nestedTypes(found.ranges);
    }
    return found ? { ...found, name: path, leafName: segments.at(-1), source: "schema" } : null;
  }

  function relationshipProperties(sourceTypes) {
    const found = new Map();
    for (const sourceType of sourceTypes || []) {
      for (const term of propertiesFor(sourceType)) {
        const entityRanges = term.ranges.filter(isEntityType);
        if (!entityRanges.length || term.supersededBy) continue;
        const current = found.get(term.name);
        if (!current) found.set(term.name, { ...term, entityRanges });
        else current.entityRanges = [...new Set([...current.entityRanges, ...entityRanges])];
      }
    }
    return Array.from(found.values()).sort((left, right) => left.name.localeCompare(right.name));
  }

  function relationshipTargetTypes(sourceTypes, propertyName) {
    const relationship = relationshipProperties(sourceTypes).find((candidate) => candidate.name === propertyName);
    if (!relationship) return [];
    const declared = relationship.entityRanges.filter(isEntityType);
    const descendants = typeNames().filter((type) => (
      isEntityType(type)
      && !declared.includes(type)
      && declared.some((range) => typeIs(type, range))
    ));
    return [...declared, ...descendants];
  }

  function schemaTerms(type) {
    const direct = propertiesFor(type).map((term) => ({ ...term, source: "schema" }));
    const nested = direct.flatMap((parent) => {
      const children = new Map();
      for (const range of nestedTypes(parent.ranges)) {
        for (const child of propertiesFor(range)) if (!children.has(child.name)) children.set(child.name, { child, range });
      }
      return Array.from(children.values(), ({ child, range }) => ({
        ...child,
        name: `${parent.name}.${child.name}`,
        leafName: child.name,
        source: "schema",
        description: `${parent.description} ${child.description}`,
        relationship: {
          property: parent.name,
          sourceType: type,
          declaredTargetTypes: [...nestedTypes(parent.ranges)],
          targetType: range,
          targetDomainMatch: child.domains.includes(range) ? "direct" : "inherited"
        }
      }));
    });
    return [...direct, ...nested];
  }

  function termsFor(type) {
    return schemaTerms(type).map((term) => ({
      ...term,
      domains: [...(term.domains || [])],
      ranges: [...(term.ranges || [])]
    }));
  }

  function scoreTerm(term, evidence = {}) {
    return mappingEvidence.rank(term, evidence);
  }

  const TOKEN_STOP_WORDS = new Set([
    "box", "card", "content", "data", "detail", "field", "item", "job", "label", "meta", "module", "record", "result", "row", "text", "value", "view"
  ]);

  function semanticTokens(evidence) {
    const source = [evidence?.id || "", ...(evidence?.classes || [])].join(" ")
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      .toLowerCase();
    return [...new Set(source.split(/[^a-z0-9]+/).filter((token) => token.length > 2 && !TOKEN_STOP_WORDS.has(token) && !/^\d+$/.test(token)))];
  }

  function valueShape(evidence) {
    const text = String(evidence?.text || "");
    if (/\b(?:budget|fixed[ -]?price|hourly|project price|rate range)\b/i.test(text) && /(?:[$€£]|\b(?:usd|eur|gbp)\b)/i.test(text)) {
      return {
        valueType: "Object",
        transform: ["text", "parseProjectBudgetV1"],
        termHints: ["budget", "rate", "price"],
        description: "An adapter-specific structured budget or rate range."
      };
    }
    if (/\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:\s*,)?\s+\d{4}\b/i.test(text)) {
      return { valueType: "Date", transform: ["text", "parseEnglishDateV1"], termHints: ["date", "posted", "published"], description: "An adapter-specific absolute calendar date." };
    }
    if (/\d+(?:\.\d+)?\s*%/.test(text)) {
      return { valueType: "Number", transform: ["text", "parsePercentV1"], termHints: ["percent", "percentage", "feedback"], description: "An adapter-specific percentage value." };
    }
    return null;
  }

  function inferredExtensionSuggestions(evidence, adapterPrefix, bestSchemaScore) {
    if (!adapterPrefix || bestSchemaScore >= 12) return [];
    const shape = valueShape(evidence);
    if (!shape) return [];
    const matchingTokens = semanticTokens(evidence).filter((token) => shape.termHints.includes(token));
    return matchingTokens.map((token, index) => ({
      name: `${adapterPrefix}:${token}`,
      valueType: shape.valueType,
      cardinality: "one",
      description: shape.description,
      score: 100 - index,
      source: "extension",
      transform: [...shape.transform],
      example: evidence?.text || ""
    }));
  }

  function suggestions(type, evidence = {}, { adapterPrefix = "" } = {}) {
    const schema = schemaTerms(type).map((term) => ({ ...term, score: scoreTerm(term, evidence) }));
    const bestSchemaScore = schema.reduce((best, term) => Math.max(best, term.score), 0);
    const terms = [...inferredExtensionSuggestions(evidence, adapterPrefix, bestSchemaScore), ...schema];
    return terms.map((term, index) => ({ ...term, index }))
      .sort((a, b) => b.score - a.score
        // A parent-only lexical match supports the relationship family but
        // does not identify one of its children. Prefer the direct property
        // until leaf evidence or graph arbitration distinguishes a child.
        || Number(a.name.includes(".")) - Number(b.name.includes("."))
        || propertySalience(b.name) - propertySalience(a.name)
        || a.index - b.index)
      .map(({ index: _index, ...term }) => term);
  }

  function defaultPipeline(term, kind = "text") {
    if (term?.transform) return [...term.transform];
    if (term?.normalization?.length) return [...term.normalization];
    if (kind === "url" || term?.valueType === "URL") return ["absoluteUrl", "stripQuery"];
    if (term?.valueType === "Date") return ["text", "parseEnglishDateV1"];
    if (term?.valueType === "Number") return ["text", "float"];
    return ["text", term?.name === "description" || term?.name === "articleBody" ? "collapseWhitespace" : "trim"];
  }

  return {
    catalogVersion: schemaCatalog.version,
    defaultPipeline,
    isDataType,
    isEntityType,
    propertiesFor,
    property,
    propertySalience,
    relationshipProperties,
    relationshipTargetTypes,
    scoreTerm,
    suggestions,
    termsFor,
    typeInfo,
    typeIs,
    typeNames
  };
});
