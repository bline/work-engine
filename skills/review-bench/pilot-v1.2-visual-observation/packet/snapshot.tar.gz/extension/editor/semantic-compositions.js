(function initializeSemanticCompositions(root, factory) {
  "use strict";
  const vocabulary = root.Site2JsonSchemaVocabulary || (typeof require === "function" ? require("./schema-vocabulary") : null);
  const api = factory(vocabulary);
  root.Site2JsonSemanticCompositions = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticCompositionsFactory(vocabulary) {
  "use strict";

  const EXPECTATIONS = Object.freeze(["core", "common", "optional"]);
  const ALIAS = /^[A-Za-z][A-Za-z0-9_-]*$/;
  const clone = (value) => JSON.parse(JSON.stringify(value));

  const packaged = Object.freeze([{
    id: "site2json:freelance-opportunity",
    label: "Freelance marketplace opportunity",
    kind: "composition",
    description: "A request for freelance services that may collect quotes or proposals.",
    keywords: ["freelance", "project", "contract", "bid", "quote", "proposal", "marketplace"],
    root: "listing",
    nodes: {
      listing: { types: ["JobPosting", "Demand"], description: "The request for work.", expectation: "core" },
      service: { types: ["Service"], description: "The work or capability being requested.", expectation: "common", evidenceKeywords: ["service", "skill", "category", "capability"] },
      buyer: { types: ["Organization"], description: "The organization offering the opportunity.", expectation: "common", evidenceKeywords: ["buyer", "employer", "client", "company", "organization", "profile", "identity", "avatar"] },
      buyerRating: { types: ["AggregateRating"], description: "Aggregate feedback about the buyer.", expectation: "optional", evidenceKeywords: ["rating", "feedback", "review", "score", "star"] },
      quotes: { types: ["AggregateOffer"], description: "Aggregate facts about responses.", expectation: "optional", evidenceKeywords: ["quote", "bid", "proposal", "response", "offer"] },
      quoteAction: { types: ["QuoteAction"], description: "The action through which a response can be submitted.", expectation: "optional", evidenceKeywords: ["quote", "bid", "proposal", "apply", "submit", "send"] }
    },
    edges: [
      { from: "listing", property: "itemOffered", to: "service", expectation: "common" },
      { from: "listing", property: "hiringOrganization", to: "buyer", expectation: "common" },
      { from: "buyer", property: "aggregateRating", to: "buyerRating", expectation: "optional" },
      { from: "service", property: "offers", to: "quotes", expectation: "optional" },
      { from: "listing", property: "potentialAction", to: "quoteAction", expectation: "optional" }
    ],
    priorities: {
      listing: ["title", "description", "datePosted", "validThrough", "skills", "priceSpecification"],
      service: ["name", "description", "category", "areaServed"],
      buyer: ["name", "address", "location"],
      buyerRating: ["ratingValue", "bestRating", "worstRating", "ratingCount"],
      quotes: ["offerCount", "lowPrice", "highPrice", "priceCurrency"],
      quoteAction: ["target"]
    }
  }]);

  function singleType(type) {
    if (!vocabulary.typeInfo(type)) throw new Error(`${type} is not a packaged Schema.org type.`);
    return {
      id: `schema:${type}`, label: type, kind: "schema-type", description: vocabulary.typeInfo(type).description || "Schema.org type.",
      root: "listing", nodes: { listing: { types: [type], expectation: "core" } }, edges: [], priorities: { listing: [] }
    };
  }

  function typeIs(type, expected, customTerms = {}, seen = new Set()) {
    if (type === expected) return true;
    if (seen.has(type)) return false;
    seen.add(type);
    const custom = customTerms[type];
    if (custom?.kind === "type") return (custom.supers || []).some((parent) => typeIs(parent, expected, customTerms, seen));
    if (vocabulary.typeIs) return vocabulary.typeIs(type, expected);
    return (vocabulary.typeInfo(type)?.supers || []).some((parent) => typeIs(parent, expected, customTerms, seen));
  }

  function edgeProperty(composition, edge, customTerms = {}) {
    const source = composition.nodes[edge.from];
    const schema = source?.types.map((type) => vocabulary.property(type, edge.property)).find(Boolean) || null;
    if (schema) return schema;
    const custom = customTerms[edge.property];
    if (!custom || custom.kind !== "relationship") return null;
    const available = (custom.domainIncludes || []).some((domain) => source?.types.some((type) => typeIs(type, domain, customTerms)));
    return available ? { name: edge.property, ranges: [...(custom.rangeIncludes || [])], description: custom.description, source: "extension" } : null;
  }

  function validate(value, customTerms = {}) {
    const errors = [];
    const warnings = [];
    const issues = [];
    function error(message, destination = null) {
      errors.push(message);
      if (destination) issues.push({ severity: "error", message, destination });
    }
    if (!value || typeof value !== "object" || Array.isArray(value)) return { ok: false, errors: ["Composition must be an object."], warnings };
    const nodes = value.nodes && typeof value.nodes === "object" && !Array.isArray(value.nodes) ? value.nodes : {};
    const aliases = Object.keys(nodes);
    if (!value.id || !value.label) errors.push("Composition id and label are required.");
    if (!aliases.length) errors.push("Composition needs at least one node.");
    if (!value.root || !nodes[value.root]) errors.push("Composition root must reference a node.");
    let coreCount = 0;
    for (const [alias, node] of Object.entries(nodes)) {
      if (!ALIAS.test(alias)) errors.push(`Node alias “${alias}” is invalid.`);
      if (!Array.isArray(node.types) || !node.types.length) errors.push(`Node ${alias} needs at least one type.`);
      for (const type of node.types || []) if (!vocabulary.typeInfo(type) && customTerms[type]?.kind !== "type") errors.push(`Node ${alias} uses unknown Schema.org type ${type}.`);
      if (!EXPECTATIONS.includes(node.expectation)) errors.push(`Node ${alias} has invalid expectation ${node.expectation}.`);
      if (node.evidenceKeywords !== undefined && (!Array.isArray(node.evidenceKeywords) || node.evidenceKeywords.length > 32 || node.evidenceKeywords.some((keyword) => typeof keyword !== "string" || !keyword.trim() || keyword.length > 64))) errors.push(`Node ${alias} has invalid evidenceKeywords.`);
      if (node.variants !== undefined) {
        const candidates = node.variants?.candidates;
        const destination = { kind: "semantic-graph", screen: "semantics", nodeAlias: alias, section: "variant-types", action: "edit-variant-slot" };
        if (alias === value.root) error("Use result variants for the root node; nested variant slots belong on relationship targets.", destination);
        if (node.variants?.fallback !== node.types?.[0]) error(`Node ${alias}'s variant fallback must equal its first type.`, destination);
        if (!Array.isArray(candidates) || candidates.length < 1 || candidates.length > 5) error(`Node ${alias} needs between 1 and 5 variant candidates.`, destination);
        const seen = new Set();
        for (const candidate of candidates || []) {
          if (!candidate?.type || seen.has(candidate.type) || node.types.includes(candidate.type)) error(`Node ${alias} has an invalid or duplicate variant type.`, { ...destination, candidateType: candidate?.type || null });
          seen.add(candidate?.type);
          if (!vocabulary.typeInfo(candidate?.type) && customTerms[candidate?.type]?.kind !== "type") error(`Node ${alias} uses unknown variant type ${candidate?.type}.`, { ...destination, candidateType: candidate?.type || null });
          if (candidate?.evidence !== undefined && !Array.isArray(candidate.evidence)) error(`Node ${alias} variant ${candidate?.type || "?"} has invalid evidence.`, { ...destination, candidateType: candidate?.type || null, action: "resolve-evidence" });
        }
        for (const key of ["minScore", "minMargin"]) if (!Number.isSafeInteger(node.variants?.[key]) || node.variants[key] < 0) error(`Node ${alias} has an invalid variant ${key}.`, destination);
      }
      if (node.expectation === "core") coreCount += 1;
    }
    if (coreCount !== 1 || nodes[value.root]?.expectation !== "core") errors.push("Composition must have exactly one core node, and it must be the root.");
    const edges = Array.isArray(value.edges) ? value.edges : [];
    const edgeKeys = new Set();
    for (const edge of edges) {
      if (!nodes[edge.from] || !nodes[edge.to]) errors.push(`Edge ${edge.from || "?"}.${edge.property || "?"} references a missing node.`);
      if (!edge.property) errors.push("Every edge needs a property.");
      if (!EXPECTATIONS.includes(edge.expectation)) errors.push(`Edge ${edge.from || "?"}.${edge.property || "?"} has invalid expectation ${edge.expectation}.`);
      const key = `${edge.from}\u001f${edge.property}\u001f${edge.to}`;
      if (edgeKeys.has(key)) errors.push(`Duplicate edge ${edge.from}.${edge.property} -> ${edge.to}.`);
      edgeKeys.add(key);
      const term = edgeProperty(value, edge, customTerms);
      if (nodes[edge.from] && edge.property && !term) errors.push(`${edge.property} is not available on node ${edge.from}'s types.`);
      if (term && nodes[edge.to] && !term.ranges.some((range) => nodes[edge.to].types.some((type) => typeIs(type, range, customTerms)))) {
        warnings.push(`${edge.from}.${edge.property} does not declare a range compatible with ${nodes[edge.to].types.join(" + ")}.`);
      }
      if (term && nodes[edge.to]?.variants) for (const candidate of nodes[edge.to].variants.candidates || []) {
        if (!term.ranges.some((range) => typeIs(candidate.type, range, customTerms))) errors.push(`${edge.from}.${edge.property} cannot contain variant type ${candidate.type}.`);
      }
    }
    if (nodes[value.root]) {
      const reached = new Set([value.root]);
      let changed = true;
      while (changed) {
        changed = false;
        for (const edge of edges) if (reached.has(edge.from) && !reached.has(edge.to)) { reached.add(edge.to); changed = true; }
      }
      for (const alias of aliases) if (!reached.has(alias)) errors.push(`Node ${alias} is disconnected from root ${value.root}.`);
    }
    return { ok: errors.length === 0, errors: [...new Set(errors)], warnings: [...new Set(warnings)], ...(issues.length ? { issues } : {}) };
  }

  function preset(id) {
    const found = packaged.find((candidate) => candidate.id === id);
    if (!found) throw new Error(`Unknown semantic composition ${id}.`);
    return clone(found);
  }

  function normalize(block) {
    const candidate = block?.composition ? clone(block.composition) : singleType(block?.schemaType || "Thing");
    const result = validate(candidate);
    return { composition: candidate, validation: result };
  }

  function choices(query = "") {
    const terms = String(query).trim().toLowerCase().split(/\s+/).filter(Boolean);
    const phrase = terms.join(" ");
    const compositions = packaged.filter((item) => terms.every((term) => [item.label, item.description, ...(item.keywords || [])].join(" ").toLowerCase().includes(term)))
      .map((item) => ({ id: item.id, label: item.label, kind: item.kind, description: item.description, nodeCount: Object.keys(item.nodes).length }));
    const types = vocabulary.typeNames().filter((type) => {
      const info = vocabulary.typeInfo(type);
      return terms.every((term) => `${type} ${info?.description || ""}`.toLowerCase().includes(term));
    }).sort((left, right) => {
      const rank = (type) => {
        const name = type.toLowerCase();
        if (!phrase) return 4;
        if (name === phrase) return 0;
        if (name.startsWith(phrase)) return 1;
        if (name.includes(phrase)) return 2;
        if (terms.every((term) => name.includes(term))) return 3;
        return 4;
      };
      return rank(left) - rank(right) || left.length - right.length || left.localeCompare(right);
    }).slice(0, 80).map((type) => ({ id: `schema:${type}`, label: type, kind: "schema-type", description: vocabulary.typeInfo(type)?.description || "Schema.org type.", nodeCount: 1 }));
    return { compositions, types };
  }

  function relationshipOptions(sourceTypes, targetType) {
    if (!targetType && vocabulary.relationshipProperties) {
      return vocabulary.relationshipProperties(sourceTypes).map((term) => ({
        property: term.name,
        description: term.description,
        ranges: term.ranges,
        entityRanges: term.entityRanges,
        domains: term.domains,
        status: term.status
      }));
    }
    const found = new Map();
    for (const sourceType of sourceTypes || []) {
      for (const term of vocabulary.propertiesFor(sourceType)) {
        if (!term.ranges.some((range) => typeIs(targetType, range))) continue;
        if (!found.has(term.name)) found.set(term.name, { property: term.name, description: term.description, ranges: term.ranges });
      }
    }
    return Array.from(found.values()).sort((left, right) => left.property.localeCompare(right.property));
  }

  function structuralRelationshipOptions(sourceTypes, targetType) {
    if (!targetType) return relationshipOptions(sourceTypes, targetType);
    const found = new Map();
    const intentionalContainment = new Set(["mainEntity", "mainEntityOfPage", "hasPart", "isPartOf", "item", "itemListElement"]);
    for (const sourceType of sourceTypes || []) {
      if (!vocabulary.typeInfo(sourceType)) continue;
      for (const term of vocabulary.propertiesFor(sourceType)) {
        // Thing is Schema.org's universal escape hatch. It makes properties
        // such as category/object/owner formally accept almost every entity,
        // but those links provide no useful structural protection in a visual
        // graph authoring gesture. Keep them in the explicit form editor while
        // requiring a more specific domain and range for drag connections.
        const hasSpecificDomain = term.domains.some((domain) => domain !== "Thing" && typeIs(sourceType, domain));
        const hasSpecificRange = term.ranges.some((range) => range !== "Thing" && typeIs(targetType, range))
          || (intentionalContainment.has(term.name) && term.ranges.some((range) => typeIs(targetType, range)));
        if (!hasSpecificDomain || !hasSpecificRange || term.supersededBy) continue;
        if (!found.has(term.name)) found.set(term.name, {
          property: term.name,
          description: term.description,
          ranges: term.ranges,
          domains: term.domains,
          status: term.status
        });
      }
    }
    return Array.from(found.values()).sort((left, right) => left.property.localeCompare(right.property));
  }

  function relationshipTargetTypes(sourceTypes, property) {
    return vocabulary.relationshipTargetTypes ? vocabulary.relationshipTargetTypes(sourceTypes, property) : [];
  }

  function typeDetails(type, customTerms = {}) {
    const schema = vocabulary.typeInfo(type);
    if (schema) return {
      name: type,
      description: schema.description || "Schema.org type.",
      supers: [...(schema.supers || [])],
      source: "Schema.org"
    };
    const custom = customTerms[type];
    if (custom?.kind !== "type") return null;
    return {
      name: type,
      description: custom.description || "Adapter-local semantic type.",
      supers: [...(custom.supers || [])],
      source: "Adapter vocabulary"
    };
  }

  function propertyReference(sourceTypes, customTerms = {}) {
    const found = new Map();
    const add = (term, sourceType, source = "Schema.org") => {
      const direct = (term.domains || []).includes(sourceType);
      const inheritedFrom = (term.domains || []).filter((domain) => domain !== sourceType && typeIs(sourceType, domain, customTerms));
      if (!direct && !inheritedFrom.length) return;
      const entityRanges = (term.ranges || []).filter((range) => vocabulary.isEntityType?.(range) || customTerms[range]?.kind === "type");
      const current = found.get(term.name);
      if (!current) {
        found.set(term.name, {
          property: term.name,
          description: term.description || "",
          ranges: [...new Set(term.ranges || [])],
          entityRanges: [...new Set(entityRanges)],
          direct,
          inheritedFrom: [...new Set(inheritedFrom)],
          source,
          status: term.status || ""
        });
        return;
      }
      current.direct ||= direct;
      current.ranges = [...new Set([...current.ranges, ...(term.ranges || [])])];
      current.entityRanges = [...new Set([...current.entityRanges, ...entityRanges])];
      current.inheritedFrom = [...new Set([...current.inheritedFrom, ...inheritedFrom])];
    };
    for (const sourceType of sourceTypes || []) {
      if (!vocabulary.typeInfo(sourceType)) continue;
      for (const term of vocabulary.propertiesFor(sourceType)) add(term, sourceType);
    }
    for (const [name, term] of Object.entries(customTerms || {})) {
      if (term?.kind !== "relationship") continue;
      for (const sourceType of sourceTypes || []) add({
        name,
        domains: term.domainIncludes || [],
        ranges: term.rangeIncludes || [],
        description: term.description || ""
      }, sourceType, "Adapter vocabulary");
    }
    return [...found.values()].sort((left, right) => (
      Number(right.direct) - Number(left.direct)
      || Number(Boolean(right.entityRanges.length)) - Number(Boolean(left.entityRanges.length))
      || left.property.localeCompare(right.property)
    ));
  }

  function removeEdge(value, index) {
    const next = clone(value);
    if (!Number.isInteger(index) || index < 0 || index >= next.edges.length) return next;
    next.edges.splice(index, 1);
    const reached = new Set([next.root]);
    let changed = true;
    while (changed) {
      changed = false;
      for (const edge of next.edges) if (reached.has(edge.from) && next.nodes[edge.to] && !reached.has(edge.to)) { reached.add(edge.to); changed = true; }
    }
    for (const alias of Object.keys(next.nodes)) if (!reached.has(alias)) delete next.nodes[alias];
    next.edges = next.edges.filter((edge) => next.nodes[edge.from] && next.nodes[edge.to]);
    return next;
  }

  function removeNode(value, alias) {
    const next = clone(value);
    if (alias === next.root || !Object.prototype.hasOwnProperty.call(next.nodes, alias)) return next;
    delete next.nodes[alias];
    next.edges = next.edges.filter((edge) => edge.from !== alias && edge.to !== alias);
    const reached = new Set([next.root]);
    let changed = true;
    while (changed) {
      changed = false;
      for (const edge of next.edges) if (reached.has(edge.from) && next.nodes[edge.to] && !reached.has(edge.to)) { reached.add(edge.to); changed = true; }
    }
    for (const candidate of Object.keys(next.nodes)) if (!reached.has(candidate)) delete next.nodes[candidate];
    next.edges = next.edges.filter((edge) => next.nodes[edge.from] && next.nodes[edge.to]);
    return next;
  }

  function isKnownType(type) {
    return Boolean(vocabulary.typeInfo(type));
  }

  return Object.freeze({
    EXPECTATIONS,
    choices,
    isKnownType,
    normalize,
    packaged: () => clone(packaged),
    preset,
    relationshipOptions,
    propertyReference,
    structuralRelationshipOptions,
    relationshipTargetTypes,
    removeEdge,
    removeNode,
    singleType,
    typeDetails,
    typeNames: () => vocabulary.typeNames(),
    validate
  });
});
