"use strict";

(function exposeSidebarSemanticGraph(root) {
  function create({
    document, getBlock, onAnalyze, onApply, onClear, onAddEvidence, onSelect = () => {},
    onRefreshClassification = async () => {}, onResolveEvidence = async () => {}, onAcceptFallback = async () => {}, onPickEvidence = async () => {},
    onPreviewItem = () => {}, onClearPreview = () => {}, onRevealItem = () => {}
  }) {
    const maxGraph = root.Site2JsonMaxGraph;
    const elements = {
      section: document.querySelector("#semantic-variants"),
      title: document.querySelector("#semantic-variants-title"),
      summary: document.querySelector("#semantic-variants-summary"),
      canvas: document.querySelector("#semantic-variant-graph"),
      status: document.querySelector("#semantic-variants-status"),
      analyze: document.querySelector("#analyze-variants-button"),
      apply: document.querySelector("#apply-variants-button"),
      addEvidence: document.querySelector("#add-variant-evidence-button"),
      clear: document.querySelector("#clear-variants-button"),
      review: document.querySelector("#variant-classification-review"),
      reviewSummary: document.querySelector("#variant-classification-summary"),
      reviewCounts: document.querySelector("#variant-classification-counts"),
      reviewIssues: document.querySelector("#variant-classification-issues"),
      refreshReview: document.querySelector("#refresh-variant-classification-button"),
      resolutionForm: document.querySelector("#variant-resolution-form"),
      resolutionTitle: document.querySelector("#variant-resolution-title"),
      resolutionBreakdown: document.querySelector("#variant-resolution-breakdown"),
      resolutionType: document.querySelector("#variant-resolution-type"),
      resolutionSelectEvidence: document.querySelector("#select-variant-resolution-evidence-button"),
      resolutionSave: document.querySelector("#save-variant-resolution-button"),
      resolutionAcceptFallback: document.querySelector("#accept-variant-fallback-button"),
      resolutionCancel: document.querySelector("#cancel-variant-resolution-button"),
      resolutionStatus: document.querySelector("#variant-resolution-status")
    };
    let graph = null;
    let selectedType = null;
    let resolvingRow = null;
    let resolvingContext = null;

    function themeColor(token, fallback) {
      return document.defaultView?.getComputedStyle?.(document.documentElement).getPropertyValue(token).trim() || fallback;
    }

    function graphTheme() {
      const dark = document.documentElement.dataset.theme === "dark";
      return {
        text: themeColor("--s2j-text", dark ? "#e8eaed" : "#171b12"),
        muted: themeColor("--s2j-text-muted", dark ? "#bdc1c6" : "#5c6354"),
        surface: themeColor("--s2j-surface", dark ? "#292a2d" : "#ffffff"),
        success: themeColor("--s2j-success", dark ? "#81c995" : "#1c6b3a"),
        successBg: themeColor("--s2j-success-bg", dark ? "#193322" : "#e6f3ea"),
        successBorder: themeColor("--s2j-success-border", dark ? "#3f6f4c" : "#a9d2b7"),
        warningBg: themeColor("--s2j-warning-bg", dark ? "#332b13" : "#fbf1d6"),
        warningBorder: themeColor("--s2j-warning-border", dark ? "#6b551f" : "#dfc77f"),
        edge: themeColor("--s2j-border-strong", dark ? "#5f6368" : "#b9c1ae")
      };
    }

    function setStatus(message, kind = "") {
      elements.status.textContent = message;
      elements.status.className = `hint ${kind}`.trim();
    }

    function destroyGraph() {
      graph?.destroy?.();
      graph = null;
      elements.canvas.replaceChildren();
    }

    function graphLabel(candidate) {
      const evidence = candidate.evidence?.length || 0;
      return `${candidate.schemaType}\n${candidate.count} item${candidate.count === 1 ? "" : "s"} · score ${candidate.averageScore}\n${evidence ? `${evidence} explicit evidence rule${evidence === 1 ? "" : "s"}` : "Shape evidence pending discovery"}`;
    }

    function classificationTypes(block) {
      const source = block?.variants?.candidates?.length ? block.variants.candidates : (block?.variantAnalysis?.candidates || []);
      return source
        .filter((candidate) => candidate.schemaType !== block.schemaType)
        .map((candidate) => ({ entityName: candidate.entityName, schemaType: candidate.schemaType, fallback: false }))
        .filter((candidate, index, all) => all.findIndex((item) => item.schemaType === candidate.schemaType) === index);
    }

    function closeResolver() {
      resolvingRow = null;
      resolvingContext = null;
      elements.resolutionForm.hidden = true;
      elements.resolutionStatus.textContent = "";
      onClearPreview();
    }

    function openResolver(block, row, context = {}) {
      resolvingRow = row;
      elements.review.hidden = false;
      resolvingContext = {
        kind: context.kind || "root",
        slotPath: context.slotPath || null,
        nodeAlias: context.nodeAlias || null,
        candidates: context.candidates || classificationTypes(block),
        rootIndex: context.rootIndex ?? row.rootIndex ?? row.index
      };
      elements.resolutionTitle.textContent = context.slotPath
        ? `Resolve ${context.slotPath} in result ${resolvingContext.rootIndex + 1}`
        : `Resolve result ${resolvingContext.rootIndex + 1}`;
      elements.resolutionType.replaceChildren();
      elements.resolutionBreakdown.replaceChildren();
      if (row.classification?.winner) {
        const decision = document.createElement("div");
        decision.className = "variant-resolution-score decision";
        const winner = document.createElement("strong");
        winner.textContent = `${row.classification.winner.schemaType || row.classification.winner.entityName || "Leading candidate"} leads`;
        const margin = document.createElement("span");
        const runnerUp = row.classification.runnerUp?.schemaType || row.classification.runnerUp?.entityName || "fallback";
        margin.textContent = `runner-up ${runnerUp} · margin ${row.classification.margin || 0}`;
        decision.append(winner, margin);
        elements.resolutionBreakdown.append(decision);
      }
      for (const candidate of (row.alternatives || []).slice(0, 5)) {
        const item = document.createElement("div");
        item.className = "variant-resolution-score";
        const name = document.createElement("strong");
        name.textContent = candidate.schemaType;
        const score = document.createElement("span");
        score.textContent = `total ${candidate.score || 0} · shape ${candidate.shapeScore || 0} · explicit evidence ${candidate.evidenceScore || 0}`;
        item.append(name, score);
        elements.resolutionBreakdown.append(item);
      }
      const types = resolvingContext.candidates;
      const suggested = context.candidateType || row.alternatives?.find((candidate) => types.some((type) => type.schemaType === candidate.schemaType))?.schemaType || types[0]?.schemaType;
      for (const type of types) {
        const option = document.createElement("option");
        option.value = type.schemaType;
        option.textContent = type.schemaType;
        option.selected = type.schemaType === suggested;
        elements.resolutionType.append(option);
      }
      elements.resolutionForm.hidden = false;
      elements.resolutionStatus.textContent = "";
      onRevealItem(resolvingContext.rootIndex);
      elements.resolutionType.focus();
    }

    function renderClassification(block) {
      const classification = block?.variantClassification;
      const canReview = Boolean(block && (block.variants?.candidates?.length || block.variantAnalysis?.mixed));
      elements.review.hidden = !canReview;
      if (!canReview) {
        closeResolver();
        return;
      }
      const loading = classification?.status === "loading";
      elements.refreshReview.disabled = loading;
      elements.reviewCounts.replaceChildren();
      elements.reviewIssues.replaceChildren();
      if (!classification || loading) {
        elements.reviewSummary.textContent = loading ? "Classifying rendered results…" : "Refresh to check the current evidence against every rendered result.";
        return;
      }
      if (classification.status === "error") {
        elements.reviewSummary.textContent = classification.message || "The rendered results could not be classified.";
        return;
      }
      elements.reviewSummary.textContent = `${classification.sampled}/${classification.total} rendered results checked · ${classification.ambiguousCount} ambiguous · ${classification.unclassifiedCount} use the fallback`;
      for (const count of classification.counts || []) {
        const badge = document.createElement("span");
        badge.className = "variant-count";
        badge.textContent = `${count.schemaType}${count.fallback ? " fallback" : ""}: ${count.count}`;
        elements.reviewCounts.append(badge);
      }
      for (const [label, count] of [["Ambiguous", classification.ambiguousCount], ["Unclassified", classification.unclassifiedCount]]) {
        if (!count) continue;
        const badge = document.createElement("span");
        badge.className = "variant-count warning";
        badge.textContent = `${label}: ${count}`;
        elements.reviewCounts.append(badge);
      }
      const issues = (classification.rows || []).filter((row) => row.status !== "classified");
      if (!issues.length) {
        const empty = document.createElement("small");
        empty.textContent = "Every rendered result has a deterministic type assignment.";
        elements.reviewIssues.append(empty);
      }
      for (const row of issues) {
        const item = document.createElement("div");
        item.className = "variant-issue";
        const title = document.createElement("strong");
        const alternatives = (row.alternatives || []).filter((candidate) => candidate.score > 0).slice(0, 2);
        title.textContent = row.status === "ambiguous"
          ? `Result ${row.index + 1} · ambiguous${alternatives.length ? `: ${alternatives.map((candidate) => `${candidate.schemaType} ${candidate.score}`).join(" / ")}` : ""}`
          : `Result ${row.index + 1} · unclassified → ${row.fallback.schemaType} fallback`;
        const resolve = document.createElement("button");
        resolve.type = "button";
        resolve.className = "secondary compact";
        resolve.textContent = row.status === "ambiguous" ? "Resolve" : "Assign type";
        resolve.addEventListener("click", () => openResolver(block, row));
        const example = document.createElement("small");
        example.textContent = row.label;
        item.append(title, resolve, example);
        item.addEventListener("mouseenter", () => onPreviewItem(row.index));
        item.addEventListener("mouseleave", onClearPreview);
        item.addEventListener("click", (event) => { if (event.target !== resolve) onRevealItem(row.index); });
        elements.reviewIssues.append(item);
      }
      if (resolvingRow && resolvingContext?.kind === "root" && !(classification.rows || []).some((row) => row.index === resolvingRow.index && row.status !== "classified")) closeResolver();
    }

    function renderGraph(block, analysis) {
      destroyGraph();
      if (!analysis || !maxGraph?.Graph) return;
      graph = new maxGraph.Graph(elements.canvas);
      graph.setCellsEditable(false);
      graph.setCellsMovable(false);
      graph.setCellsResizable(false);
      graph.setConnectable(false);
      graph.setPanning(true);
      graph.setHtmlLabels(false);
      const parent = graph.getDefaultParent();
      const width = Math.max(elements.canvas.clientWidth || 520, 320);
      const nodeWidth = Math.min(168, Math.max(126, (width - 42) / Math.max(analysis.candidates.length, 2)));
      const gap = 14;
      const colors = graphTheme();
      graph.batchUpdate(() => {
        const scope = graph.insertVertex({
          parent, value: `${block.name}\n${analysis.sampledItems} sampled items`, position: [18, 18], size: [Math.min(190, width - 36), 54],
          style: { rounded: true, fillColor: colors.success, strokeColor: colors.success, fontColor: document.documentElement.dataset.theme === "dark" ? "#102116" : "#ffffff", fontStyle: 1, whiteSpace: "wrap" }
        });
        analysis.candidates.forEach((candidate, index) => {
          const vertex = graph.insertVertex({
            parent, value: graphLabel(candidate), position: [18 + index * (nodeWidth + gap), 112], size: [nodeWidth, 74],
            style: {
              rounded: true, whiteSpace: "wrap", fontSize: 11,
              fontColor: colors.text,
              fillColor: candidate.schemaType === block.schemaType ? colors.successBg : colors.surface,
              strokeColor: candidate.schemaType === block.schemaType ? colors.successBorder : colors.edge,
              dashed: false
            }
          });
          vertex.variantCandidate = candidate;
          graph.insertEdge({ parent, source: scope, target: vertex, value: candidate.schemaType === block.schemaType ? "fallback" : "may emit", style: { strokeColor: colors.edge, fontColor: colors.muted, labelBackgroundColor: colors.surface, endArrow: "block" } });
        });
      });
      graph.getSelectionModel().addListener(maxGraph.InternalEvent.CHANGE, () => {
        const candidate = graph.getSelectionCell()?.variantCandidate;
        if (!candidate) return;
        selectedType = candidate.schemaType;
        elements.addEvidence.disabled = candidate.schemaType === block.schemaType;
        onSelect(candidate.schemaType);
        setStatus(candidate.evidence?.length
          ? `${candidate.schemaType} has ${candidate.evidence.length} explicit page rule${candidate.evidence.length === 1 ? "" : "s"}. Discovery will combine those rules with its field shape.`
          : `${candidate.schemaType} will first be classified from its discovered field shape. Explicit page evidence is only needed if candidates remain ambiguous.`,
        "ready");
      });
    }

    function render() {
      const block = getBlock();
      const analysis = block?.variantAnalysis;
      elements.section.hidden = !block;
      elements.analyze.disabled = !block || analysis?.status === "loading";
      elements.analyze.textContent = "Refresh item types";
      elements.clear.hidden = !block?.variants;
      elements.addEvidence.disabled = !block || !selectedType || selectedType === block.schemaType;
      if (!block) {
        destroyGraph();
        renderClassification(null);
        return;
      }
      renderClassification(block);
      if (!analysis || analysis.status === "loading") {
        destroyGraph();
        elements.canvas.hidden = true;
        elements.title.textContent = analysis?.status === "loading" ? "Analyzing each item…" : "One model for every item";
        elements.summary.textContent = "Analyze item by item to detect mixed result types.";
        elements.apply.disabled = true;
        setStatus(block.variants ? "This block already has saved variant rules." : "");
        return;
      }
      if (analysis.status === "error") {
        destroyGraph();
        elements.canvas.hidden = true;
        elements.title.textContent = "Item types could not be detected";
        elements.summary.textContent = analysis.message || "Refresh item types to try again.";
        elements.apply.disabled = true;
        setStatus("The semantic model is still editable; refresh when the rendered page is ready.", "warning");
        return;
      }
      const alternatives = analysis.candidates.filter((candidate) => candidate.schemaType !== block.schemaType);
      if (selectedType && !analysis.candidates.some((candidate) => candidate.schemaType === selectedType)) selectedType = null;
      const ready = alternatives;
      elements.canvas.hidden = !analysis.mixed;
      elements.title.textContent = analysis.mixed ? `${analysis.candidates.length} result types detected` : "One result type detected";
      const timing = Number.isFinite(analysis.durationMs) ? ` in ${analysis.durationMs < 1000 ? `${Math.round(analysis.durationMs)} ms` : `${(analysis.durationMs / 1000).toFixed(1)} s`}` : "";
      elements.summary.textContent = `${analysis.sampledItems} items sampled${timing} · ${analysis.ambiguousCount} ambiguous`;
      elements.apply.disabled = !analysis.mixed || ready.length === 0;
      if (analysis.mixed) {
        renderGraph(block, analysis);
        setStatus(`${ready.length} alternate type${ready.length === 1 ? " is" : "s are"} ready for field discovery. The selected model remains the fallback; ambiguous items will request explicit evidence afterward.`, "ready");
      } else {
        destroyGraph();
        setStatus(analysis.ambiguousCount
          ? `No deterministic alternate type was found. ${analysis.ambiguousCount} item${analysis.ambiguousCount === 1 ? " remains" : "s remain"} semantically ambiguous and will use ${block.schemaType} as the fallback.`
          : "The sample does not currently need variant rules.",
        analysis.ambiguousCount ? "warning" : "");
      }
    }

    async function run(operation) {
      try {
        await operation();
        render();
      } catch (error) {
        setStatus(error instanceof Error ? error.message : String(error), "error");
      }
    }

    elements.analyze.addEventListener("click", () => run(onAnalyze));
    elements.apply.addEventListener("click", () => run(onApply));
    elements.addEvidence.addEventListener("click", () => run(() => onAddEvidence(selectedType)));
    elements.clear.addEventListener("click", () => run(onClear));
    elements.refreshReview.addEventListener("click", () => run(onRefreshClassification));
    elements.resolutionSelectEvidence?.addEventListener("click", async () => {
      elements.resolutionStatus.className = "status";
      elements.resolutionStatus.textContent = "Select a distinguishing element inside the highlighted result. Press Escape to cancel.";
      try {
        await onPickEvidence(resolvingContext);
      } catch (error) {
        elements.resolutionStatus.className = "status error";
        elements.resolutionStatus.textContent = error instanceof Error ? error.message : String(error);
      }
    });
    elements.resolutionCancel.addEventListener("click", closeResolver);
    elements.resolutionAcceptFallback?.addEventListener("click", async () => {
      if (!resolvingRow) return;
      elements.resolutionAcceptFallback.disabled = true;
      elements.resolutionStatus.className = "status";
      elements.resolutionStatus.textContent = "Accepting this exact unresolved shape as fallback…";
      try {
        await onAcceptFallback({ ...resolvingContext, row: resolvingRow });
        closeResolver();
        render();
      } catch (error) {
        elements.resolutionStatus.className = "status error";
        elements.resolutionStatus.textContent = error instanceof Error ? error.message : String(error);
      } finally {
        elements.resolutionAcceptFallback.disabled = false;
      }
    });
    elements.resolutionForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!resolvingRow) return;
      elements.resolutionSave.disabled = true;
      elements.resolutionStatus.textContent = "Capturing the selected evidence and rescoring all results…";
      try {
        await onResolveEvidence({ ...resolvingContext, schemaType: elements.resolutionType.value });
        closeResolver();
        render();
      } catch (error) {
        elements.resolutionStatus.textContent = error instanceof Error ? error.message : String(error);
        elements.resolutionStatus.className = "status error";
      } finally {
        elements.resolutionSave.disabled = false;
      }
    });
    document.defaultView?.addEventListener?.("site2json-theme-change", render);
    return Object.freeze({ render, destroy: destroyGraph, elements, openResolver: (context) => {
      const block = getBlock();
      if (!block || !context?.row) return false;
      openResolver(block, context.row, context);
      return true;
    } });
  }

  const api = Object.freeze({ create });
  root.Site2JsonSidebarSemanticGraph = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
