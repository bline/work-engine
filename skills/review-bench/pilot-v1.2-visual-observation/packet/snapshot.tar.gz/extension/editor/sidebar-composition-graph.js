"use strict";

(function exposeSidebarCompositionGraph(root) {
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const jsonPreviewApi = root.Site2JsonJsonPreview || (typeof require === "function" ? require("./json-preview") : null);
  const schemaTypeIcons = root.Site2JsonSchemaTypeIcons || (typeof require === "function" ? require("./schema-type-icons") : null);
  const visualEvidenceObservation = root.Site2JsonVisualEvidenceObservation || (typeof require === "function" ? require("../ir/visual-evidence-observation") : null);

  function create({
    document, compositions, getBlock, getCustomTerms = () => ({}), onApply, onPreview = null, onFocus = null, onVisualEvidence = null,
    getAdapterPrefix = () => "",
    maxGraph: providedMaxGraph = null, toolboxApi: providedToolbox = null,
    libraryService: providedLibraryService = null, storage = null,
    attentionApi: providedAttentionApi
  }) {
    const maxGraph = providedMaxGraph || document.defaultView?.Site2JsonMaxGraph || root.Site2JsonMaxGraph;
    const toolboxApi = providedToolbox || document.defaultView?.Site2JsonSemanticToolbox || root.Site2JsonSemanticToolbox;
    const libraryApi = document.defaultView?.Site2JsonSemanticLibrary || root.Site2JsonSemanticLibrary;
    const toastApi = document.defaultView?.Site2JsonToast || root.Site2JsonToast;
    const toasts = toastApi?.create?.({ document });
    const attentionApi = providedAttentionApi === false ? null : (providedAttentionApi || document.defaultView?.Site2JsonAttention || root.Site2JsonAttention);
    const attention = attentionApi?.create?.({ document });
    const libraryService = providedLibraryService || (libraryApi?.createLegacyToolboxService && toolboxApi
      ? libraryApi.createLegacyToolboxService({ toolboxApi, storage })
      : null);
    const elements = {
      open: document.querySelector("#open-semantic-graph"),
      view: document.querySelector("#semantic-composition-graph-view"),
      close: document.querySelector("#close-semantic-graph"),
      canvas: document.querySelector("#semantic-composition-canvas"),
      favoritesDock: document.querySelector("#semantic-toolbox-favorites"),
      favorites: document.querySelector("#semantic-toolbox-favorite-list"),
      customTypeTool: document.querySelector("#semantic-toolbox-custom-type-tool"),
      trash: document.querySelector("#semantic-toolbox-trash"),
      search: document.querySelector("#semantic-toolbox-search-input"),
      searchResults: document.querySelector("#semantic-toolbox-search-results"),
      empty: document.querySelector("#semantic-graph-empty-selection"),
      nodeEditor: document.querySelector("#semantic-graph-node-editor"),
      nodeAlias: document.querySelector("#semantic-graph-node-alias"),
      nodeTypes: document.querySelector("#semantic-graph-node-types"),
      nodeExpectation: document.querySelector("#semantic-graph-node-expectation"),
      nodeVariantSlot: document.querySelector("#semantic-graph-node-variant-slot"),
      nodeVariantTypesLabel: document.querySelector("#semantic-graph-node-variant-types-label"),
      nodeVariantTypes: document.querySelector("#semantic-graph-node-variant-types"),
      addNodeVariantType: document.querySelector("#semantic-graph-add-variant-type"),
      nodeVariantTypeList: document.querySelector("#semantic-graph-node-variant-type-list"),
      typeDetails: document.querySelector("#semantic-graph-type-details-body"),
      propertyDetails: document.querySelector("#semantic-graph-properties"),
      propertyCount: document.querySelector("#semantic-graph-property-count"),
      propertySearch: document.querySelector("#semantic-graph-property-search"),
      propertyList: document.querySelector("#semantic-graph-property-list"),
      connectDetails: document.querySelector("#semantic-graph-connect-details"),
      updateNode: document.querySelector("#semantic-graph-update-node"),
      nodeUpdateStatus: document.querySelector("#semantic-graph-node-update-status"),
      removeNode: document.querySelector("#semantic-graph-remove-node"),
      relationProperty: document.querySelector("#semantic-graph-relation-property"),
      relationTarget: document.querySelector("#semantic-graph-relation-target"),
      newTypeLabel: document.querySelector("#semantic-graph-new-type-label"),
      newType: document.querySelector("#semantic-graph-new-type"),
      targetTypes: document.querySelector("#semantic-graph-target-types"),
      newAliasLabel: document.querySelector("#semantic-graph-new-alias-label"),
      newAlias: document.querySelector("#semantic-graph-new-alias"),
      relationExpectation: document.querySelector("#semantic-graph-relation-expectation"),
      addRelationship: document.querySelector("#semantic-graph-add-relationship"),
      cancelRelationship: document.querySelector("#semantic-graph-cancel-relationship"),
      createCustomRelationship: document.querySelector("#semantic-graph-create-custom-relationship"),
      customRelationshipEditor: document.querySelector("#semantic-graph-custom-relationship-editor"),
      customRelationshipSummary: document.querySelector("#semantic-graph-custom-relationship-summary"),
      customRelationshipTarget: document.querySelector("#semantic-graph-custom-relationship-target"),
      customRelationshipTerm: document.querySelector("#semantic-graph-custom-relationship-term"),
      customRelationshipDescription: document.querySelector("#semantic-graph-custom-relationship-description"),
      customRelationshipAliases: document.querySelector("#semantic-graph-custom-relationship-aliases"),
      customRelationshipExpectation: document.querySelector("#semantic-graph-custom-relationship-expectation"),
      saveCustomRelationship: document.querySelector("#semantic-graph-save-custom-relationship"),
      cancelCustomRelationship: document.querySelector("#semantic-graph-cancel-custom-relationship"),
      customConnectionCue: document.querySelector("#semantic-custom-connection-cue"),
      customTypeEditor: document.querySelector("#semantic-graph-custom-type-editor"),
      customTypeSummary: document.querySelector("#semantic-graph-custom-type-summary"),
      customTypeName: document.querySelector("#semantic-graph-custom-type-name"),
      customTypeDescription: document.querySelector("#semantic-graph-custom-type-description"),
      customTypeRelationship: document.querySelector("#semantic-graph-custom-type-relationship"),
      customTypeTarget: document.querySelector("#semantic-graph-custom-type-target"),
      customTypeRelationshipTerm: document.querySelector("#semantic-graph-custom-type-relationship-term"),
      customTypeRelationshipDescription: document.querySelector("#semantic-graph-custom-type-relationship-description"),
      saveCustomType: document.querySelector("#semantic-graph-save-custom-type"),
      cancelCustomType: document.querySelector("#semantic-graph-cancel-custom-type"),
      edgeEditor: document.querySelector("#semantic-graph-edge-editor"),
      edgeLabel: document.querySelector("#semantic-graph-edge-label"),
      edgeProperty: document.querySelector("#semantic-graph-edge-property"),
      edgeExpectation: document.querySelector("#semantic-graph-edge-expectation"),
      updateEdge: document.querySelector("#semantic-graph-update-edge"),
      edgeUpdateStatus: document.querySelector("#semantic-graph-edge-update-status"),
      removeEdge: document.querySelector("#semantic-graph-remove-edge"),
      status: document.querySelector("#semantic-graph-status"),
      autoLayout: document.querySelector("#semantic-graph-auto-layout"),
      layoutMode: document.querySelector("#semantic-graph-layout-mode"),
      autoLayoutStatus: document.querySelector("#semantic-graph-auto-layout-status"),
      center: document.querySelector("#semantic-graph-center"),
      maximize: document.querySelector("#semantic-graph-maximize"),
      layoutAuthoring: document.querySelector("#semantic-graph-layout-authoring"),
      layoutCompare: document.querySelector("#semantic-graph-layout-compare"),
      livePreview: document.querySelector("#semantic-graph-live-preview"),
      livePreviewSummary: document.querySelector("#semantic-graph-live-preview-summary"),
      livePreviewStatus: document.querySelector("#semantic-graph-live-preview-status"),
      liveReviewCount: document.querySelector("#semantic-graph-live-review-count"),
      liveReviewEmpty: document.querySelector("#semantic-graph-live-review-empty"),
      liveReviewList: document.querySelector("#semantic-graph-live-review-list"),
      livePreviewOutput: document.querySelector("#semantic-graph-live-preview-output"),
      livePreviewFormats: [...document.querySelectorAll("[data-live-preview-format]")],
      refreshLivePreview: document.querySelector("#semantic-graph-refresh-live-preview"),
      closeLivePreview: document.querySelector("#semantic-graph-close-live-preview"),
      savePattern: document.querySelector("#semantic-graph-save-pattern"),
      savePatternEditor: document.querySelector("#semantic-graph-save-pattern-editor"),
      savePatternSummary: document.querySelector("#semantic-graph-save-pattern-summary"),
      savePatternName: document.querySelector("#semantic-graph-save-pattern-name"),
      savePatternDescription: document.querySelector("#semantic-graph-save-pattern-description"),
      confirmSavePattern: document.querySelector("#semantic-graph-confirm-save-pattern"),
      cancelSavePattern: document.querySelector("#semantic-graph-cancel-save-pattern"),
      apply: document.querySelector("#semantic-graph-apply"),
      cancel: document.querySelector("#semantic-graph-cancel")
    };
    let graph = null;
    let graphVertices = new Map();
    let graphEdges = new Map();
    let working = null;
    let workingCustomTerms = null;
    let selected = null;
    let pendingConnection = null;
    let keyboardConnection = null;
    let customConnection = null;
    let customTypeConnection = null;
    let patternSelection = new Set();
    let customDwell = null;
    let customDwellTimer = null;
    let activeDragItem = null;
    let toolboxDragHoverAlias = null;
    let selectedPropertyReference = [];
    let open = false;
    let previewRequest = 0;
    let focusRequest = 0;
    let lastLivePreview = null;
    let liveReviewOverlay = { findings: {}, reports: {} };
    let liveReviewStale = false;
    let liveReviewFocus = null;
    let maximized = false;
    const LIVE_PREVIEW_FORMAT_KEY = "site2json.semanticGraphLivePreviewFormat";

    function savedLivePreviewFormat() {
      try {
        const value = document.defaultView?.localStorage?.getItem(LIVE_PREVIEW_FORMAT_KEY);
        return ["markup", "compact", "jsonld"].includes(value) ? value : "jsonld";
      } catch (_error) {
        return "jsonld";
      }
    }

    let livePreviewFormat = savedLivePreviewFormat();

    function previewValue(preview, format = livePreviewFormat) {
      if (preview?.formats && Object.prototype.hasOwnProperty.call(preview.formats, format)) return preview.formats[format];
      return preview?.output ?? null;
    }

    function edgeFocusId(edge) {
      return edge ? `${edge.from}\u001f${edge.property}\u001f${edge.to}` : null;
    }

    function selectedFocusEntry() {
      if (!lastLivePreview?.focusIndex || !selected) return null;
      if (selected.kind === "node") return lastLivePreview.focusIndex.aliases?.[selected.alias] || null;
      if (selected.kind === "edge") return lastLivePreview.focusIndex.edges?.[edgeFocusId(working?.edges?.[selected.index])] || null;
      return null;
    }

    function reviewFocusEntry() {
      if (!lastLivePreview?.reviewIndex || !liveReviewFocus || liveReviewStale) return null;
      const entries = liveReviewFocus.kind === "entity"
        ? lastLivePreview.reviewIndex.entities
        : lastLivePreview.reviewIndex.fields;
      return (entries || []).find((entry) => (liveReviewFocus.kind === "entity" ? entry.entityId : entry.nodeId) === liveReviewFocus.id) || null;
    }

    function previewPathAliases(format = livePreviewFormat) {
      const result = {};
      for (const [alias, entry] of Object.entries(lastLivePreview?.focusIndex?.aliases || {})) {
        for (const path of entry.formats?.[format] || []) (result[path] ||= []).push(alias);
      }
      return result;
    }

    function updateLiveFocusStatus(entry = selectedFocusEntry()) {
      const base = elements.livePreviewStatus.dataset.previewSummary || elements.livePreviewStatus.textContent;
      if (!lastLivePreview || !selected || !entry || entry.nodeIds?.length) {
        elements.livePreviewStatus.textContent = base;
        return;
      }
      const subject = selected.kind === "node"
        ? `“${selected.alias}”`
        : `the “${working?.edges?.[selected.index]?.property || "selected"}” relationship`;
      elements.livePreviewStatus.textContent = `${base} No live data was assigned to ${subject} in this preview.`;
    }

    function reviewTermLabel(term) {
      return String(term || "Unresolved").replace(/^https?:\/\/schema\.org\//, "").split(/[\/#]/).filter(Boolean).pop() || "Unresolved";
    }

    function reviewDecisionCount() {
      return Object.keys(liveReviewOverlay.findings).length + Object.keys(liveReviewOverlay.reports).length;
    }

    function reviewCandidates(item, kind, query = "") {
      const candidates = new Map((item.candidates || []).filter((candidate) => candidate.term).map((candidate) => [candidate.term, candidate]));
      if (kind === "type") {
        for (const choice of compositions.choices(query).types) candidates.set(`https://schema.org/${choice.label}`, { term: `https://schema.org/${choice.label}` });
        for (const [term, definition] of Object.entries(workingCustomTerms || {})) {
          if (definition?.kind === "type") candidates.set(definition.canonicalUri || term, { term: definition.canonicalUri || term });
        }
      }
      return [...candidates.values()];
    }

    async function applyLiveReview(kind, item, input, unresolved = false) {
      if (!lastLivePreview || liveReviewStale) {
        elements.livePreviewStatus.textContent = "This preview is stale. Refresh it before applying another correction.";
        return;
      }
      const term = input.value.trim();
      if (!unresolved && !term) {
        input.setCustomValidity("Choose a term or mark this decision unresolved.");
        input.reportValidity();
        return;
      }
      input.setCustomValidity("");
      if (kind === "type") {
        liveReviewOverlay.reports[item.entityId] = unresolved || term === "https://schema.org/Thing"
          ? { entityId: item.entityId, status: "unresolved", accepted: false, selected: "https://schema.org/Thing" }
          : { entityId: item.entityId, status: "accepted", accepted: true, selected: term };
      } else {
        liveReviewOverlay.findings[item.nodeId] = unresolved
          ? { nodeId: item.nodeId, status: "unresolved" }
          : { nodeId: item.nodeId, status: "assigned", term };
      }
      liveReviewFocus = { kind: kind === "type" ? "entity" : "field", id: kind === "type" ? item.entityId : item.nodeId };
      await previewLiveData({ resetReview: false });
    }

    async function focusLiveReview(kind, item, { reveal = true, restoreFocus = false } = {}) {
      if (!lastLivePreview || liveReviewStale) return;
      liveReviewFocus = { kind, id: kind === "entity" ? item.entityId : item.nodeId };
      const request = ++focusRequest;
      renderLivePreview();
      if (restoreFocus) [...elements.liveReviewList.querySelectorAll(".semantic-live-review-card")]
        .find((card) => card.dataset.reviewKind === kind && card.dataset.reviewId === liveReviewFocus.id)
        ?.focus({ preventScroll: true });
      if (!onFocus || !lastLivePreview.previewId) return;
      try {
        const result = await onFocus({
          previewId: lastLivePreview.previewId,
          kind: "review",
          reviewKind: kind,
          reviewId: liveReviewFocus.id,
          reveal
        });
        if (request !== focusRequest || !result?.ok) return;
        elements.livePreviewOutput.dataset.focusNodeCount = String(result.nodeIds?.length || 0);
        elements.livePreviewOutput.dataset.focusSourceCount = String(result.sourceCount || 0);
        const base = elements.livePreviewStatus.dataset.previewSummary || elements.livePreviewStatus.textContent;
        elements.livePreviewStatus.textContent = result.sourceCount
          ? base
          : `${base} No rendered source is linked to this review decision in the current preview.`;
      } catch (_error) {
        // Review highlighting remains useful if the inspected page navigated
        // or closed after this preview was generated.
      }
    }

    function renderLiveReview() {
      if (!elements.liveReviewList) return;
      const entities = lastLivePreview?.reviewIndex?.entities || [];
      const fields = lastLivePreview?.reviewIndex?.fields || [];
      const items = [
        ...entities.map((item) => ({ kind: "type", item })),
        ...fields.map((item) => ({ kind: "field", item }))
      ];
      elements.liveReviewList.replaceChildren();
      elements.liveReviewEmpty.hidden = Boolean(items.length);
      const decisions = reviewDecisionCount();
      elements.liveReviewCount.textContent = decisions ? `${decisions} user ${decisions === 1 ? "decision" : "decisions"}` : `${items.length} inferred decisions`;
      for (const { kind, item } of items) {
        const id = kind === "type" ? item.entityId : item.nodeId;
        const authored = kind === "type" ? liveReviewOverlay.reports[id] : liveReviewOverlay.findings[id];
        const card = document.createElement("article");
        card.className = `semantic-live-review-card ${item.status === "unresolved" ? "unresolved" : "resolved"}${authored ? " modified" : ""}`;
        const reviewKind = kind === "type" ? "entity" : "field";
        const focused = liveReviewFocus?.kind === reviewKind && liveReviewFocus.id === id;
        card.classList.toggle("selected", focused);
        card.tabIndex = 0;
        card.dataset.reviewKind = reviewKind;
        card.dataset.reviewId = id;
        card.setAttribute("role", "group");
        card.setAttribute("aria-label", `${kind === "type" ? "Entity type" : "Field mapping"} review for ${id}. Press Enter or Space to focus its source.`);
        card.setAttribute("aria-current", focused ? "true" : "false");
        const selectReview = () => focusLiveReview(reviewKind, item, { restoreFocus: true });
        card.addEventListener("click", (event) => {
          if (!event.target.closest(".semantic-live-review-controls")) selectReview();
        });
        card.addEventListener("keydown", (event) => {
          if (event.target !== card || !["Enter", " "].includes(event.key)) return;
          event.preventDefault();
          selectReview();
        });
        const heading = document.createElement("div");
        heading.className = "semantic-live-review-card-heading";
        const title = document.createElement("strong");
        title.textContent = kind === "type"
          ? `Entity type · ${item.status === "unresolved" ? "Unresolved" : reviewTermLabel(item.selected)}`
          : `${item.role} · ${reviewTermLabel(item.term)}`;
        const state = document.createElement("span");
        state.className = "semantic-live-review-state";
        state.textContent = authored ? "User decision" : item.status === "unresolved" ? "Unresolved inference" : "Inferred";
        heading.append(title, state);
        const context = document.createElement("p");
        context.className = "hint semantic-live-review-context";
        context.textContent = kind === "type"
          ? `${id}${item.status === "unresolved" ? " · fallback Thing" : ""}${Number.isFinite(item.margin) ? ` · margin ${Number(item.margin).toFixed(2)}` : ""}`
          : `${id}${item.value !== undefined ? ` · observed “${String(item.value).slice(0, 80)}”` : ""}`;
        const controls = document.createElement("div");
        controls.className = "semantic-live-review-controls";
        const input = document.createElement("input");
        const list = document.createElement("datalist");
        list.id = `semantic-live-review-${kind}-${Math.random().toString(36).slice(2)}`;
        input.type = "search";
        input.setAttribute("list", list.id);
        input.setAttribute("aria-label", kind === "type" ? `Type for ${id}` : `Property for ${id}`);
        input.placeholder = kind === "type" ? "Search or enter a type term" : "Choose or enter a property term";
        input.value = kind === "type" ? (item.selected || "") : (item.term || "");
        const populate = () => list.replaceChildren(...reviewCandidates(item, kind, input.value).slice(0, 80).map((candidate) => {
          const option = document.createElement("option");
          option.value = candidate.term;
          option.label = reviewTermLabel(candidate.term);
          return option;
        }));
        populate();
        if (kind === "type") input.addEventListener("input", populate);
        const apply = document.createElement("button");
        apply.type = "button";
        apply.className = "secondary compact";
        apply.textContent = "Use term";
        apply.addEventListener("click", () => applyLiveReview(kind, item, input));
        const unresolved = document.createElement("button");
        unresolved.type = "button";
        unresolved.className = "secondary compact";
        unresolved.textContent = "Mark unresolved";
        unresolved.addEventListener("click", () => applyLiveReview(kind, item, input, true));
        controls.append(input, list, apply, unresolved);
        card.append(heading, context, controls);
        elements.liveReviewList.append(card);
      }
    }

    function renderLivePreview() {
      elements.livePreviewFormats.forEach((button) => {
        const active = button.dataset.livePreviewFormat === livePreviewFormat;
        button.classList.toggle("selected", active);
        button.setAttribute("aria-pressed", String(active));
      });
      const value = previewValue(lastLivePreview);
      if (jsonPreviewApi?.render) jsonPreviewApi.render(elements.livePreviewOutput, value, document.defaultView?.Site2JsonPrism || root.Site2JsonPrism, {
        highlightPaths: (reviewFocusEntry() || selectedFocusEntry())?.formats?.[livePreviewFormat] || [],
        pathAliases: previewPathAliases(),
        onFocus(aliases) {
          const alias = aliases.find((candidate) => working?.nodes?.[candidate]);
          if (alias) selectNode(alias);
        }
      });
      else elements.livePreviewOutput.textContent = JSON.stringify(value, null, 2);
      elements.livePreviewOutput.dataset.format = livePreviewFormat;
      renderLiveReview();
    }

    function setLivePreviewFormat(format) {
      if (!["markup", "compact", "jsonld"].includes(format)) return;
      livePreviewFormat = format;
      try { document.defaultView?.localStorage?.setItem(LIVE_PREVIEW_FORMAT_KEY, format); }
      catch (_error) { /* Format switching still works when storage is unavailable. */ }
      renderLivePreview();
    }

    function setWorkspaceLayout(layout) {
      const next = layout === "compare" ? "compare" : "authoring";
      elements.view.dataset.workspaceLayout = next;
      elements.layoutAuthoring?.setAttribute("aria-pressed", String(next === "authoring"));
      elements.layoutCompare?.setAttribute("aria-pressed", String(next === "compare"));
    }

    function setLivePreviewOpen(value) {
      elements.livePreview.hidden = !value;
      elements.view.classList.toggle("live-preview-open", value);
    }

    function setMaximized(value) {
      maximized = Boolean(value && open);
      elements.view.classList.toggle("maximized", maximized);
      document.body.classList.toggle("semantic-graph-maximized", maximized);
      elements.maximize.setAttribute("aria-pressed", String(maximized));
      elements.maximize.setAttribute("aria-label", maximized ? "Restore graph editor" : "Maximize graph editor");
      elements.maximize.querySelector(".icon-maximize").hidden = maximized;
      elements.maximize.querySelector(".icon-restore").hidden = !maximized;
      elements.maximize.title = maximized
        ? "Restore the graph editor inside the Semantics screen"
        : "Fill the side panel with the graph editor";
      if (maximized) (document.defaultView?.requestAnimationFrame || document.defaultView?.setTimeout)?.(() => centerGraph(), 0);
    }

    async function focusLiveSelection({ reveal = true } = {}) {
      const request = ++focusRequest;
      const entry = selectedFocusEntry();
      renderLivePreview();
      updateLiveFocusStatus(entry);
      if (!onFocus || !lastLivePreview?.previewId) return;
      try {
        const edge = selected?.kind === "edge" ? working?.edges?.[selected.index] : null;
        const result = await onFocus(entry ? {
          previewId: lastLivePreview.previewId,
          kind: selected.kind,
          alias: selected.kind === "node" ? selected.alias : null,
          focusId: selected.kind === "edge" ? edgeFocusId(edge) : selected.alias,
          reveal
        } : { previewId: lastLivePreview.previewId, alias: null, reveal: false });
        if (request !== focusRequest || !result?.ok) return;
        elements.livePreviewOutput.dataset.focusNodeCount = String(result.nodeIds?.length || 0);
        elements.livePreviewOutput.dataset.focusSourceCount = String(result.sourceCount || 0);
      } catch (_error) {
        // The editor selection remains useful when its inspected page has
        // navigated or closed since this preview was generated.
      }
    }

    setWorkspaceLayout("authoring");
    renderLivePreview();

    function themeColor(token, fallback) {
      const view = document.defaultView;
      return view?.getComputedStyle?.(document.documentElement).getPropertyValue(token).trim() || fallback;
    }

    function graphTheme() {
      const dark = document.documentElement.dataset.theme === "dark";
      return {
        text: themeColor("--s2j-text", dark ? "#e8eaed" : "#171b12"),
        muted: themeColor("--s2j-text-muted", dark ? "#bdc1c6" : "#5c6354"),
        surface: themeColor("--s2j-surface", dark ? "#292a2d" : "#ffffff"),
        success: themeColor("--s2j-success", dark ? "#81c995" : "#1c6b3a"),
        successBg: themeColor("--s2j-success-bg", dark ? "#193322" : "#e6f3ea"),
        successBorder: themeColor("--s2j-success-border", dark ? "#3f6f4c" : "#a9d2b7"),
        warning: themeColor("--s2j-warning", dark ? "#fdd663" : "#8a5d00"),
        warningBg: themeColor("--s2j-warning-bg", dark ? "#332b13" : "#fbf1d6"),
        warningBorder: themeColor("--s2j-warning-border", dark ? "#6b551f" : "#dfc77f"),
        custom: themeColor("--s2j-custom", dark ? "#d7aefb" : "#7245a4"),
        edge: themeColor("--s2j-border-strong", dark ? "#5f6368" : "#b9c1ae")
      };
    }
    let toolbox = toolboxApi?.normalize?.(null) || { version: 3, favorites: [], customTypes: {}, patterns: {}, tags: {}, tagAssignments: {}, collections: {}, toolkits: {} };
    let toolboxLoaded = false;
    let searchTimer = null;
    let searchGeneration = 0;
    let dockLeaveTimer = null;
    const nodePositions = new Map();
    const DRAG_TYPE = "application/x-site2json-semantic-tool";
    const CUSTOM_DWELL_MS = 650;
    const CONNECT_HANDLE = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 18 18'%3E%3Ccircle cx='9' cy='9' r='8' fill='%23176b3a' stroke='%23fff' stroke-width='1.5'/%3E%3Cpath d='M5 9h7m-2.5-2.5L12 9l-2.5 2.5' fill='none' stroke='%23fff' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E";

    function setStatus(kind, message) {
      if (attention) {
        if (kind === "error" && message) {
          const destination = validationDestination(message);
          attention.sync("semantic-graph-action", [{
            id: `graph:action:${message}`,
            severity: "error",
            message,
            destination
          }]);
          if (destination.section === "variant-types" && destination.nodeAlias === selected?.alias) {
            elements.nodeVariantTypesLabel.classList.add("attention-invalid");
            elements.nodeVariantTypes.setAttribute("aria-invalid", "true");
          }
          elements.status.className = "status";
          elements.status.textContent = "";
          return;
        }
        attention.sync("semantic-graph-action", []);
      }
      elements.status.className = `status ${kind || ""}`.trim();
      elements.status.textContent = message;
    }

    function setInspectorStatus(element, kind = "", message = "") {
      if (!element) return;
      element.className = `status semantic-inspector-status ${kind}`.trim();
      element.textContent = message;
    }

    function confirm(message, fallbackElement = null) {
      if (toasts?.success?.(message)) {
        if (fallbackElement) setInspectorStatus(fallbackElement, "", "");
        return;
      }
      setInspectorStatus(fallbackElement, "ready", message);
    }

    function validation() {
      return working ? compositions.validate(working, workingCustomTerms || getCustomTerms()) : { ok: false, errors: ["No semantic composition is open."], warnings: [] };
    }

    function validationDestination(message) {
      const alias = message.match(/^Node\s+([^\s]+)/)?.[1]
        || message.match(/^([^\.\s]+)\.[^\s]+/)?.[1]
        || (selected?.kind === "node" ? selected.alias : null)
        || working?.root;
      const section = /variant|evidence/i.test(message) ? "variant-types" : "node-settings";
      return { kind: "semantic-graph", nodeAlias: alias, section };
    }

    function syncValidationAttention(result) {
      if (!attention) return false;
      const structured = new Map((result.issues || []).map((issue) => [issue.message, issue]));
      const entries = [
        ...result.errors.map((message, index) => {
          const issue = structured.get(message);
          return { id: `graph:error:${index}:${message}`, severity: "error", message, destination: issue?.destination || validationDestination(message) };
        }),
        ...result.warnings.map((message, index) => {
          const issue = structured.get(message);
          return { id: `graph:warning:${index}:${message}`, severity: "warning", message, destination: issue?.destination || validationDestination(message) };
        })
      ];
      attention.sync("semantic-graph-validation", entries);
      const selectedHasVariantError = selected?.kind === "node" && entries.some((entry) => entry.destination.nodeAlias === selected.alias && entry.destination.section === "variant-types");
      elements.nodeVariantTypesLabel.classList.toggle("attention-invalid", selectedHasVariantError);
      elements.nodeVariantTypes.setAttribute("aria-invalid", String(selectedHasVariantError));
      return true;
    }

    function validateWorking() {
      const result = validation();
      elements.apply.disabled = !result.ok;
      if (syncValidationAttention(result)) setStatus("", "");
      else if (!result.ok) setStatus("error", result.errors.join(" "));
      else if (result.warnings.length) setStatus("loading", result.warnings.join(" "));
      else setStatus("ready", "Valid connected semantic graph. Apply when it represents the page correctly.");
      return result;
    }

    function suggestedAlias(type) {
      const stem = String(type || "node").replace(/^[^A-Za-z]+/, "");
      const base = stem ? `${stem[0].toLowerCase()}${stem.slice(1)}` : "node";
      if (!working.nodes[base]) return base;
      let suffix = 2;
      while (working.nodes[`${base}${suffix}`]) suffix += 1;
      return `${base}${suffix}`;
    }

    function graphLevels() {
      const levels = new Map([[working.root, 0]]);
      let changed = true;
      while (changed) {
        changed = false;
        for (const edge of working.edges) {
          if (!levels.has(edge.from)) continue;
          const level = levels.get(edge.from) + 1;
          if (!levels.has(edge.to) || level < levels.get(edge.to)) {
            levels.set(edge.to, level);
            changed = true;
          }
        }
      }
      for (const alias of Object.keys(working.nodes)) if (!levels.has(alias)) levels.set(alias, 0);
      return levels;
    }

    function isCustomTypeNode(node) {
      return node.types.some((type) => workingCustomTerms?.[type]?.kind === "type");
    }

    function nodeLabel(alias, node) {
      const custom = isCustomTypeNode(node) ? " · custom" : "";
      const variants = node.variants?.candidates?.length ? `<span class="semantic-graph-node-variants">↳ ${escapeHtml(node.variants.candidates.map((candidate) => candidate.type).join(" | "))}</span>` : "";
      const type = node.types.find((candidate) => compositions.isKnownType(candidate)) || node.types[0] || "Thing";
      const icon = isCustomTypeNode(node)
        ? '<span class="semantic-graph-node-custom-icon" aria-hidden="true">+</span>'
        : `<svg class="schema-type-icon semantic-graph-node-icon" aria-hidden="true"><use href="${schemaTypeIcons.spriteHref(type)}"></use></svg>`;
      return `<div class="semantic-graph-node-label">${icon}<span class="semantic-graph-node-copy"><strong>${escapeHtml(alias)}${alias === working.root ? " · root" : ""}${escapeHtml(custom)}</strong><span>${escapeHtml(node.types.join(" + "))}</span>${variants}<span>${escapeHtml(node.expectation)}</span></span></div>`;
    }

    function escapeHtml(value) {
      return String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
    }

    function graphPositions(levels) {
      const aliases = Object.keys(working.nodes);
      const width = elements.canvas.clientWidth || 520;
      if (width >= 620) {
        const rows = new Map();
        return new Map(aliases.map((alias) => {
          const level = levels.get(alias) || 0;
          const row = rows.get(level) || 0;
          rows.set(level, row + 1);
          return [alias, nodePositions.get(alias) || [22 + level * 224, 24 + row * 146]];
        }));
      }
      const nodeWidth = 166;
      const gap = 18;
      const columns = Math.max(1, Math.floor((width - 28 + gap) / (nodeWidth + gap)));
      const grouped = new Map();
      for (const alias of aliases) {
        const level = levels.get(alias) || 0;
        if (!grouped.has(level)) grouped.set(level, []);
        grouped.get(level).push(alias);
      }
      const layout = new Map();
      let top = 24;
      for (const level of [...grouped.keys()].sort((left, right) => left - right)) {
        const group = grouped.get(level);
        group.forEach((alias, index) => {
          if (!layout.has(alias)) layout.set(alias, nodePositions.get(alias) || [18 + (index % columns) * (nodeWidth + gap), top + Math.floor(index / columns) * 138]);
        });
        top += Math.ceil(group.length / columns) * 138 + 42;
      }
      return new Map(aliases.map((alias) => [alias, layout.get(alias)]));
    }

    function typeFamily(type) {
      if (/(?:Person|Organization|Audience|Contact|Profile)/i.test(type)) return "entity";
      if (/(?:Article|Creative|Media|Image|Video|Book|Review|Comment)/i.test(type)) return "creative";
      if (/(?:Place|Address|Geo|Location)/i.test(type)) return "place";
      if (/(?:Product|Offer|Service|Demand|Job|Occupation)/i.test(type)) return "product";
      if (/(?:Action|Event)/i.test(type)) return "action";
      return "entity";
    }

    function dragPayload(event, item, favoriteIndex = null) {
      const payload = JSON.stringify({ ...item, ...(Number.isInteger(favoriteIndex) ? { favoriteIndex } : {}) });
      event.dataTransfer?.setData(DRAG_TYPE, payload);
      event.dataTransfer?.setData("text/plain", item.id);
      if (event.dataTransfer) event.dataTransfer.effectAllowed = "copyMove";
      if (Number.isInteger(favoriteIndex)) elements.trash.hidden = false;
      activeDragItem = item;
    }

    function readDrag(event) {
      try {
        const value = event.dataTransfer?.getData(DRAG_TYPE);
        return value ? JSON.parse(value) : null;
      } catch { return null; }
    }

    function hasToolDrag(event) {
      return Array.from(event.dataTransfer?.types || []).includes(DRAG_TYPE);
    }

    function clearDropIndicators() {
      for (const tile of elements.favorites.querySelectorAll(".drop-before, .drop-after")) tile.classList.remove("drop-before", "drop-after");
    }

    function favoriteDropSide(tile, event) {
      const bounds = tile.getBoundingClientRect();
      const horizontal = document.defaultView?.getComputedStyle(elements.favorites).flexDirection === "row";
      return horizontal ? event.clientX >= bounds.left + bounds.width / 2 : event.clientY >= bounds.top + bounds.height / 2;
    }

    function favoriteDropIndex(payload, targetIndex, after) {
      let boundary = targetIndex + (after ? 1 : 0);
      if (Number.isInteger(payload.favoriteIndex) && payload.favoriteIndex < boundary) boundary -= 1;
      return boundary;
    }

    function indicateFavoriteGap(event) {
      const tiles = Array.from(elements.favorites.querySelectorAll(".semantic-toolbox-tile"));
      if (!tiles.length) return;
      const horizontal = document.defaultView?.getComputedStyle(elements.favorites).flexDirection === "row";
      const coordinate = horizontal ? event.clientX : event.clientY;
      const targetIndex = tiles.findIndex((tile) => {
        const bounds = tile.getBoundingClientRect();
        return coordinate < (horizontal ? bounds.left + bounds.width / 2 : bounds.top + bounds.height / 2);
      });
      clearDropIndicators();
      if (targetIndex < 0) tiles.at(-1).classList.add("drop-after");
      else tiles[targetIndex].classList.add("drop-before");
    }

    function indicatedFavoriteIndex(payload) {
      const tiles = Array.from(elements.favorites.querySelectorAll(".semantic-toolbox-tile"));
      const marker = tiles.find((tile) => tile.classList.contains("drop-before") || tile.classList.contains("drop-after"));
      if (!marker) return null;
      return favoriteDropIndex(payload, tiles.indexOf(marker), marker.classList.contains("drop-after"));
    }

    function toolboxItemLabel(item) {
      if (item.kind === "pattern") return item.label || toolbox.patterns?.[item.id]?.label || item.id;
      if (item.kind === "customType") return item.label || toolbox.customTypes?.[item.id]?.label || item.id;
      return item.id;
    }

    function toolboxItemBundle(item) {
      if (item.kind !== "customType") return "";
      return item.bundle?.label || toolbox.customTypes?.[item.id]?.provenance?.bundle?.label || "";
    }

    function activateToolboxItem(item) {
      if (item.kind === "pattern") { insertPattern(toolbox.patterns?.[item.id]); return; }
      if (item.kind === "customType") { addCustomTypeNode(toolbox.customTypes?.[item.id]); return; }
      addTypeNode(item.id);
    }

    function toolboxTile(item, { favoriteIndex = null } = {}) {
      const tile = document.createElement("div");
      const label = toolboxItemLabel(item);
      tile.className = "semantic-toolbox-tile";
      tile.dataset.kind = item.kind;
      tile.dataset.id = item.id;
      tile.dataset.family = item.kind === "pattern" ? "pattern" : item.kind === "customType" ? "custom" : typeFamily(item.id);
      tile.draggable = true;
      tile.tabIndex = 0;
      tile.setAttribute("role", "button");
      tile.title = `Drag ${label} into the graph${Number.isInteger(favoriteIndex) ? " or reorder this favorite" : " or into Favorites"}.`;
      const glyph = document.createElement("span");
      glyph.className = "semantic-toolbox-glyph";
      if (item.kind === "schemaType") glyph.append(schemaTypeIcons.createIcon(document, item.id));
      else glyph.textContent = item.kind === "pattern" ? "◈" : "+";
      const labelEl = document.createElement("span");
      labelEl.className = "semantic-toolbox-tile-label";
      labelEl.textContent = label;
      tile.append(glyph, labelEl);
      const bundle = toolboxItemBundle(item);
      if (bundle) {
        const bundleEl = document.createElement("small");
        bundleEl.className = "semantic-toolbox-tile-bundle";
        bundleEl.textContent = bundle;
        tile.append(bundleEl);
      }
      if (!Number.isInteger(favoriteIndex)) {
        const pin = document.createElement("button");
        pin.type = "button";
        pin.className = "semantic-toolbox-remove semantic-toolbox-pin";
        pin.textContent = "+";
        pin.title = `Pin ${label} to favorites`;
        pin.addEventListener("click", (event) => { event.stopPropagation(); pinFavorite(item); });
        tile.append(pin);
      }
      tile.addEventListener("dragstart", (event) => dragPayload(event, item, favoriteIndex));
      tile.addEventListener("dragend", () => { hideTrash(); activeDragItem = null; clearToolboxDragHover(); });
      tile.addEventListener("click", () => activateToolboxItem(item));
      tile.addEventListener("keydown", (event) => {
        if (Number.isInteger(favoriteIndex) && (event.key === "Delete" || event.key === "Backspace")) {
          event.preventDefault();
          removeFavorite(item);
        } else if (event.key === "Enter" || event.key === " ") { event.preventDefault(); activateToolboxItem(item); }
      });
      if (Number.isInteger(favoriteIndex)) {
        tile.addEventListener("dragover", (event) => {
          if (!hasToolDrag(event)) return;
          event.preventDefault();
          event.stopPropagation();
          elements.favoritesDock.classList.add("toolbox-drop-active");
          clearDropIndicators();
          tile.classList.add(favoriteDropSide(tile, event) ? "drop-after" : "drop-before");
        });
        tile.addEventListener("dragleave", () => tile.classList.remove("drop-before", "drop-after"));
        tile.addEventListener("drop", (event) => {
          event.preventDefault();
          event.stopPropagation();
          const payload = readDrag(event);
          const after = tile.classList.contains("drop-after");
          elements.favoritesDock.classList.remove("toolbox-drop-active");
          clearDropIndicators();
          if (payload) pinFavorite(payload, favoriteDropIndex(payload, favoriteIndex, after));
        });
      }
      return tile;
    }

    function renderFavorites() {
      elements.favorites.replaceChildren();
      for (const [index, item] of (toolbox.favorites || []).entries()) elements.favorites.append(toolboxTile(item, { favoriteIndex: index }));
    }

    async function persistToolbox(next) {
      toolbox = toolboxApi?.normalize?.(next) || next;
      renderFavorites();
      try {
        if (toolboxApi?.save) toolbox = await toolboxApi.save(toolbox, storage || undefined);
      } catch (error) {
        setStatus("error", `The graph changed, but favorites could not be saved: ${error.message}`);
      }
    }

    async function pinFavorite(item, index = null) {
      if (!["schemaType", "customType", "pattern"].includes(item.kind)) return;
      if (!libraryService?.addFavorite && !toolboxApi) return;
      if (libraryService?.addFavorite) {
        try {
          toolbox.favorites = await libraryService.addFavorite({ favorite: item, index });
          await hydrateFavoritePatterns();
          renderFavorites();
        } catch (error) {
          setStatus("error", `The favorite could not be saved: ${error.message}`);
        }
        return;
      }
      persistToolbox(toolboxApi.addFavorite(toolbox, item, index));
    }

    async function removeFavorite(item) {
      if (!libraryService?.removeFavorite && !toolboxApi) return;
      if (libraryService?.removeFavorite) {
        try {
          toolbox.favorites = await libraryService.removeFavorite({ favorite: item });
          renderFavorites();
        } catch (error) {
          setStatus("error", `The favorite could not be removed: ${error.message}`);
        }
        return;
      }
      persistToolbox(toolboxApi.removeFavorite(toolbox, item));
    }

    function hideTrash() {
      clearTimeout(dockLeaveTimer);
      elements.trash.hidden = true;
      elements.trash.classList.remove("toolbox-drop-active");
      elements.favoritesDock.classList.remove("toolbox-drop-active");
      elements.canvas.classList.remove("toolbox-drop-active");
      clearDropIndicators();
    }

    function matchingPatterns(query) {
      const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
      return Object.values(toolbox.patterns || {}).filter((pattern) => terms.every((term) => `${pattern.label} ${pattern.description || ""}`.toLowerCase().includes(term)));
    }

    function matchingCustomTypes(query) {
      const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
      return Object.values(toolbox.customTypes || {}).filter((record) => terms.every((term) => `${record.label} ${record.description || ""} ${record.termId || record.id} ${record.provenance?.bundle?.label || ""}`.toLowerCase().includes(term)));
    }

    async function renderSearch() {
      const generation = ++searchGeneration;
      const query = elements.search.value.trim();
      if (!query) { elements.searchResults.replaceChildren(); return; }
      const choices = compositions.choices(query).types.slice(0, 24);
      let patterns = matchingPatterns(query).slice(0, 12);
      let customTypes = matchingCustomTypes(query).slice(0, 12);
      if (libraryService?.search) {
        try {
          const result = await libraryService.search({ query, kinds: ["pattern", "customType"], pageSize: 24 });
          const patternItems = result.items.filter((item) => item.kind === "pattern");
          const customTypeItems = result.items.filter((item) => item.kind === "customType");
          const [records, typeRecords] = await Promise.all([
            libraryService.getPatterns({ ids: patternItems.map((item) => item.id) }),
            libraryService.getCustomTypes({ ids: customTypeItems.map((item) => item.id) })
          ]);
          if (generation !== searchGeneration || query !== elements.search.value.trim()) return;
          for (const record of records) toolbox.patterns[record.id] = record;
          for (const record of typeRecords) toolbox.customTypes[record.id] = record;
          patterns = patternItems;
          customTypes = customTypeItems;
        } catch (error) {
          if (generation !== searchGeneration) return;
          setStatus("error", `The Semantic Library could not be searched: ${error.message}`);
        }
      }
      elements.searchResults.replaceChildren();
      if (!choices.length && !patterns.length && !customTypes.length) {
        const empty = document.createElement("div");
        empty.className = "semantic-toolbox-search-empty";
        empty.textContent = "No Schema.org types, custom types, or graph bundles match that search.";
        elements.searchResults.append(empty);
        return;
      }
      for (const choice of choices) elements.searchResults.append(toolboxTile({ kind: "schemaType", id: choice.label }));
      for (const customType of customTypes) elements.searchResults.append(toolboxTile({ kind: "customType", id: customType.id, label: customType.label, bundle: customType.bundle }));
      for (const pattern of patterns) elements.searchResults.append(toolboxTile({ kind: "pattern", id: pattern.id, label: pattern.label }));
    }

    function addTypeNode(type, point = null) {
      if (!working || !type) return null;
      try { compositions.singleType(type); } catch (error) { setStatus("error", error.message); return null; }
      const alias = suggestedAlias(type);
      working.nodes[alias] = { types: [type], expectation: "optional" };
      if (point) nodePositions.set(alias, point);
      rerender({ kind: "node", alias });
      setStatus("error", `${type} was added as ${alias}. Connect it to the root graph before applying.`);
      return alias;
    }

    function addCustomTypeNode(record, point = null) {
      if (!working || !record?.id || !record.definition) return null;
      const adapterPrefix = String(getAdapterPrefix() || "").trim();
      const canonicalUri = record.definition.canonicalUri || record.provenance?.canonicalUri || "";
      const imported = Boolean(canonicalUri) && !record.id.startsWith(`${adapterPrefix}:`);
      const existingCanonical = imported && Object.entries(workingCustomTerms || {}).find(([, definition]) => definition?.canonicalUri === canonicalUri);
      const semanticId = record.termId || record.id;
      const importedName = `${String(record.provenance?.vocabulary?.prefix || semanticId.split(":")[0] || "External")} ${record.label || semanticId.split(":").at(-1)}`
        .replace(/[^A-Za-z0-9]+/g, " ").trim().split(/\s+/).map((part) => part ? part[0].toUpperCase() + part.slice(1) : "").join("") || "ImportedType";
      const termId = existingCanonical?.[0] || (imported ? `${adapterPrefix}:${importedName}` : record.id);
      if (imported && !adapterPrefix) {
        setStatus("error", "Set the adapter id before adding an imported semantic type.");
        return null;
      }
      const localDefinition = imported ? {
        ...clone(record.definition),
        valueType: termId,
        supers: (record.definition.supers || []).map((parent) => /^https?:\/\/(?:www\.)?schema\.org\//.test(parent) ? parent.split("/").at(-1) : parent)
      } : clone(record.definition);
      const existing = workingCustomTerms?.[termId];
      if (existing && JSON.stringify(existing) !== JSON.stringify(localDefinition)) {
        if (!existingCanonical) {
          setStatus("error", `${termId} is already defined with a different meaning in this draft.`);
          return null;
        }
      }
      if (existingCanonical && JSON.stringify(existing) !== JSON.stringify(localDefinition)) {
        setStatus("error", `${canonicalUri} is already materialized with a different meaning in this draft.`);
        return null;
      }
      const alias = suggestedAlias(record.label || record.id.split(":").at(-1));
      workingCustomTerms[termId] = existing || localDefinition;
      working.nodes[alias] = { types: [termId], expectation: "optional" };
      if (point) nodePositions.set(alias, point);
      rerender({ kind: "node", alias });
      setStatus("error", `${record.label || record.id} was added as ${termId} (${alias}). Connect it to the root graph before applying.`);
      return alias;
    }

    function pointBesideTarget(targetAlias, fallback) {
      const targetCell = graphVertices.get(targetAlias);
      const geometry = targetCell?.getGeometry?.() || targetCell?.geometry;
      const position = targetCell?.position;
      const x = Number.isFinite(geometry?.x) ? geometry.x : Number.isFinite(position?.[0]) ? position[0] : null;
      const y = Number.isFinite(geometry?.y) ? geometry.y : Number.isFinite(position?.[1]) ? position[1] : null;
      if (x === null || y === null) return fallback;
      const occupied = Array.from(graphVertices.values(), (cell) => {
        const cellGeometry = cell.getGeometry?.() || cell.geometry;
        const cellPosition = cell.position;
        return [
          Number.isFinite(cellGeometry?.x) ? cellGeometry.x : cellPosition?.[0],
          Number.isFinite(cellGeometry?.y) ? cellGeometry.y : cellPosition?.[1]
        ];
      });
      const candidates = [
        [x + 184, y], [Math.max(8, x - 184), y], [x, y + 104], [x, Math.max(8, y - 104)],
        [x + 184, y + 104], [Math.max(8, x - 184), y + 104]
      ];
      return candidates.find(([candidateX, candidateY]) => !occupied.some(([otherX, otherY]) => (
        Number.isFinite(otherX) && Number.isFinite(otherY)
        && Math.abs(candidateX - otherX) < 150 && Math.abs(candidateY - otherY) < 64
      ))) || candidates[2];
    }

    function uniqueAlias(base, taken) {
      if (!working.nodes[base] && !taken.has(base)) return base;
      let suffix = 2;
      while (working.nodes[`${base}${suffix}`] || taken.has(`${base}${suffix}`)) suffix += 1;
      return `${base}${suffix}`;
    }

    function insertPattern(record, { point = null, lockedTarget = null } = {}) {
      if (!working || !record) return null;
      const aliasMap = {};
      const takenAliases = new Set();
      for (const alias of Object.keys(record.nodes)) {
        const mapped = uniqueAlias(alias, takenAliases);
        aliasMap[alias] = mapped;
        takenAliases.add(mapped);
      }
      const nextTerms = clone(workingCustomTerms);
      for (const [term, definition] of Object.entries(record.terms || {})) {
        const existing = nextTerms[term];
        if (existing && JSON.stringify(existing) !== JSON.stringify(definition)) {
          setStatus("error", `${term} is already defined with a different meaning in this draft. Resolve the conflict before inserting “${record.label}”.`);
          return null;
        }
        nextTerms[term] = existing || clone(definition);
      }
      const next = clone(working);
      for (const [alias, node] of Object.entries(record.nodes)) {
        const inserted = clone(node);
        if (alias === record.root && inserted.expectation === "core") inserted.expectation = "common";
        next.nodes[aliasMap[alias]] = inserted;
      }
      for (const edge of record.edges) next.edges.push({ ...clone(edge), from: aliasMap[edge.from], to: aliasMap[edge.to] });
      const rootAlias = aliasMap[record.root];
      if (point) nodePositions.set(rootAlias, point);
      working = next;
      workingCustomTerms = nextTerms;
      rerender({ kind: "node", alias: rootAlias });
      if (lockedTarget && working.nodes[lockedTarget] && lockedTarget !== rootAlias) {
        const options = connectionOptions(lockedTarget, rootAlias);
        if (options.length === 1) { addConnectedEdge(lockedTarget, rootAlias, options[0]); return rootAlias; }
        if (options.length > 1) { beginRelationshipChoice(lockedTarget, rootAlias, options); return rootAlias; }
      }
      const nodeCount = Object.keys(record.nodes).length;
      setStatus("error", `“${record.label}” was added as ${rootAlias} (${nodeCount} node${nodeCount === 1 ? "" : "s"}). Connect it to the root graph before applying.`);
      return rootAlias;
    }

    async function hydrateFavoritePatterns() {
      const patternIds = (toolbox.favorites || []).filter((favorite) => favorite.kind === "pattern").map((favorite) => favorite.id);
      const customTypeIds = (toolbox.favorites || []).filter((favorite) => favorite.kind === "customType").map((favorite) => favorite.id);
      const [patterns, customTypes] = await Promise.all([
        patternIds.length && libraryService?.getPatterns ? libraryService.getPatterns({ ids: patternIds }) : [],
        customTypeIds.length && libraryService?.getCustomTypes ? libraryService.getCustomTypes({ ids: customTypeIds }) : []
      ]);
      for (const record of patterns) toolbox.patterns[record.id] = record;
      for (const record of customTypes) toolbox.customTypes[record.id] = record;
    }

    async function loadToolbox() {
      if (libraryService?.listFavorites) {
        try {
          toolbox = toolboxApi?.normalize?.(null) || { version: 3, favorites: [], customTypes: {}, patterns: {}, tags: {}, tagAssignments: {}, collections: {}, toolkits: {} };
          toolbox.favorites = await libraryService.listFavorites();
          await hydrateFavoritePatterns();
        } catch {
          toolbox = toolboxApi?.normalize?.(null) || toolbox;
        }
        toolboxLoaded = true;
        renderFavorites();
        return;
      }
      if (!toolboxApi?.load) { toolboxLoaded = true; renderFavorites(); return; }
      try { toolbox = await toolboxApi.load(storage || undefined); }
      catch { toolbox = toolboxApi.normalize(null); }
      toolboxLoaded = true;
      renderFavorites();
    }

    function connectionOptions(fromAlias, toAlias) {
      const source = working?.nodes?.[fromAlias];
      const target = working?.nodes?.[toAlias];
      if (!source || !target || fromAlias === toAlias) return [];
      const knownSourceTypes = source.types.filter((type) => compositions.isKnownType(type));
      if (!knownSourceTypes.length) return [];
      const found = new Map();
      for (const type of target.types) {
        const options = compositions.structuralRelationshipOptions
          ? compositions.structuralRelationshipOptions(knownSourceTypes, type)
          : compositions.relationshipOptions(knownSourceTypes, type);
        for (const option of options) {
          if (!working.edges.some((edge) => edge.from === fromAlias && edge.property === option.property && edge.to === toAlias)) {
            found.set(option.property, option);
          }
        }
      }
      return Array.from(found.values()).sort((left, right) => left.property.localeCompare(right.property));
    }

    function typeConnectionOptions(sourceTypes, targetTypes) {
      const knownSourceTypes = (sourceTypes || []).filter((type) => compositions.isKnownType(type));
      if (!knownSourceTypes.length) return [];
      const found = new Map();
      for (const targetType of targetTypes || []) {
        const options = compositions.structuralRelationshipOptions
          ? compositions.structuralRelationshipOptions(knownSourceTypes, targetType)
          : compositions.relationshipOptions(knownSourceTypes, targetType);
        for (const option of options) found.set(option.property, option);
      }
      return Array.from(found.values());
    }

    function draggedTypesConnectionOptions(types, alias) {
      const target = working?.nodes?.[alias];
      if (!target || !types?.length) return [];
      // A toolbox tile dropped on a graph node becomes that node's child.
      // Reversing the direction here made almost any pair look compatible and
      // produced surprising parentage after the drop.
      return typeConnectionOptions(target.types, types);
    }

    function draggedItemTypes(item) {
      if (item.kind === "schemaType") return [item.id];
      if (item.kind === "customType") return [item.id];
      if (item.kind === "pattern") {
        const pattern = toolbox.patterns?.[item.id];
        return pattern ? pattern.nodes[pattern.root]?.types || [] : [];
      }
      return [];
    }

    function connectionDomNodes(alias) {
      const state = graph?.getView?.().getState?.(graphVertices.get(alias));
      return [state?.shape?.node, state?.text?.node].filter(Boolean);
    }

    function clearCustomDwell() {
      clearTimeout(customDwellTimer);
      customDwellTimer = null;
      if (customDwell?.to) for (const node of connectionDomNodes(customDwell.to)) {
        node.classList.remove("semantic-connect-custom-pending", "semantic-connect-custom-ready");
      }
      customDwell = null;
      elements.customConnectionCue.hidden = true;
      elements.customConnectionCue.classList.remove("dwell-progress", "dwell-ready", "choice-ready");
    }

    function positionCustomCue(alias) {
      const target = connectionDomNodes(alias)[0]?.getBoundingClientRect?.();
      const workspace = elements.customConnectionCue.offsetParent?.getBoundingClientRect?.();
      if (!target || !workspace) return;
      elements.customConnectionCue.style.left = `${target.left - workspace.left + target.width / 2}px`;
      elements.customConnectionCue.style.top = `${target.top - workspace.top - 5}px`;
    }

    function showRelationshipChoiceCue(alias, optionCount) {
      elements.customConnectionCue.hidden = false;
      elements.customConnectionCue.classList.add("choice-ready");
      elements.customConnectionCue.querySelector("strong").textContent = `Choose relationship (${optionCount})`;
      positionCustomCue(alias);
    }

    function trackCustomDwell(from, to) {
      if (!from || !to || from === to || connectionOptions(from, to).length) return clearCustomDwell();
      if (customDwell?.from === from && customDwell?.to === to) return;
      clearCustomDwell();
      customDwell = { from, to, ready: false };
      for (const node of connectionDomNodes(to)) node.classList.add("semantic-connect-custom-pending");
      elements.customConnectionCue.hidden = false;
      elements.customConnectionCue.classList.add("dwell-progress");
      elements.customConnectionCue.querySelector("strong").textContent = "Hold for custom relationship";
      positionCustomCue(to);
      customDwellTimer = setTimeout(() => {
        if (!customDwell || customDwell.from !== from || customDwell.to !== to) return;
        customDwell.ready = true;
        for (const node of connectionDomNodes(to)) {
          node.classList.remove("semantic-connect-custom-pending");
          node.classList.add("semantic-connect-custom-ready");
        }
        elements.customConnectionCue.classList.remove("dwell-progress");
        elements.customConnectionCue.classList.add("dwell-ready");
        elements.customConnectionCue.querySelector("strong").textContent = "+ relationship";
        setStatus("loading", `Release to define a custom relationship from ${from} to ${to}.`);
      }, CUSTOM_DWELL_MS);
    }

    function clearToolboxDragHover() {
      if (toolboxDragHoverAlias) for (const node of connectionDomNodes(toolboxDragHoverAlias)) node.classList.remove("semantic-connect-valid", "semantic-connect-choice", "semantic-connect-invalid");
      toolboxDragHoverAlias = null;
      clearCustomDwell();
    }

    function updateToolboxDragHover(event) {
      if (!activeDragItem || !["schemaType", "customType", "customTypeTool", "pattern"].includes(activeDragItem.kind)) return clearToolboxDragHover();
      const alias = connectionAliasAtPoint(event);
      if (alias === toolboxDragHoverAlias) return;
      clearToolboxDragHover();
      toolboxDragHoverAlias = alias;
      if (!alias) return;
      if (activeDragItem.kind === "customTypeTool") {
        for (const node of connectionDomNodes(alias)) node.classList.add("semantic-connect-invalid");
        return;
      }
      const optionCount = draggedTypesConnectionOptions(draggedItemTypes(activeDragItem), alias).length;
      const stateClass = optionCount === 1 ? "semantic-connect-valid" : optionCount > 1 ? "semantic-connect-choice" : "semantic-connect-invalid";
      for (const node of connectionDomNodes(alias)) node.classList.add(stateClass);
      if (optionCount > 1) showRelationshipChoiceCue(alias, optionCount);
      else if (!optionCount) trackCustomDwell("__toolbox-drag__", alias);
    }

    function connectionAliasAtPoint(event) {
      const pointer = event?.changedTouches?.[0] || event?.touches?.[0] || event;
      if (!Number.isFinite(pointer?.clientX) || !Number.isFinite(pointer?.clientY)) return null;
      for (const alias of graphVertices.keys()) {
        if (connectionDomNodes(alias).some((node) => {
          const bounds = node.getBoundingClientRect?.();
          return bounds && pointer.clientX >= bounds.left && pointer.clientX <= bounds.right
            && pointer.clientY >= bounds.top && pointer.clientY <= bounds.bottom;
        })) return alias;
      }
      return null;
    }

    function clearConnectionHighlights() {
      clearCustomDwell();
      for (const alias of graphVertices.keys()) {
        for (const node of connectionDomNodes(alias)) node.classList.remove("semantic-connect-valid", "semantic-connect-choice", "semantic-connect-invalid", "semantic-connect-keyboard-target", "semantic-connect-custom-pending", "semantic-connect-custom-ready");
      }
    }

    function showConnectionTargets(fromAlias, activeAlias = null) {
      clearConnectionHighlights();
      for (const alias of graphVertices.keys()) {
        const optionCount = connectionOptions(fromAlias, alias).length;
        for (const node of connectionDomNodes(alias)) {
          node.classList.add(optionCount === 1 ? "semantic-connect-valid" : optionCount > 1 ? "semantic-connect-choice" : "semantic-connect-invalid");
          if (alias === activeAlias) node.classList.add("semantic-connect-keyboard-target");
        }
      }
    }

    function cancelKeyboardConnection({ restoreStatus = true } = {}) {
      keyboardConnection = null;
      clearConnectionHighlights();
      if (restoreStatus && working) validateWorking();
    }

    function addConnectedEdge(from, to, option) {
      pendingConnection = null;
      working.edges.push({
        from, property: option.property, to,
        expectation: working.nodes[to].expectation === "optional" ? "optional" : "common"
      });
      rerender({ kind: "edge", index: working.edges.length - 1 });
    }

    function beginRelationshipChoice(from, to, options) {
      pendingConnection = { from, to, options };
      renderGraph();
      validateWorking();
      selectNode(from, { preservePending: true });
      elements.connectDetails.open = true;
      setStatus("loading", `${options.length} valid relationships connect ${from} to ${to}. Choose one in the inspector.`);
      elements.relationProperty.focus({ preventScroll: false });
      elements.connectDetails.scrollIntoView?.({ behavior: "smooth", block: "nearest", inline: "nearest" });
    }

    function handleConnection(from, to) {
      cancelKeyboardConnection({ restoreStatus: false });
      const options = connectionOptions(from, to);
      if (!options.length) {
        setStatus("error", `No unused Schema.org relationship connects ${from} to ${to}.`);
        return;
      }
      if (options.length === 1) addConnectedEdge(from, to, options[0]);
      else beginRelationshipChoice(from, to, options);
    }

    function customRelationshipName(to) {
      const prefix = String(getAdapterPrefix() || "").trim();
      const stem = String(to || "relationship").replace(/^[^A-Za-z]+/, "").replace(/[^A-Za-z0-9_-]+/g, "-");
      return `${prefix || "adapter"}:${stem ? stem[0].toLowerCase() + stem.slice(1) : "relationship"}`;
    }

    function updateCustomRelationshipSummary() {
      if (!customConnection) return;
      const to = elements.customRelationshipTarget.value;
      const target = working.nodes[to];
      elements.customRelationshipSummary.textContent = `${customConnection.from} → ${to || "choose target"}${target ? ` · ${target.types.join(" + ")}` : ""}`;
      elements.saveCustomRelationship.disabled = !to || !elements.customRelationshipTerm.value.trim() || !elements.customRelationshipDescription.value.trim();
    }

    function beginCustomRelationship(from, to = null) {
      cancelKeyboardConnection({ restoreStatus: false });
      clearCustomDwell();
      if (!working?.nodes?.[from]) return;
      const targets = Object.keys(working.nodes).filter((alias) => alias !== from);
      if (!targets.length) return setStatus("error", "Add another node before creating a custom relationship.");
      customConnection = { from, lockedTarget: to || null };
      selected = { kind: "node", alias: from };
      elements.empty.hidden = true;
      elements.nodeEditor.hidden = true;
      elements.edgeEditor.hidden = true;
      elements.customRelationshipEditor.hidden = false;
      elements.customRelationshipTarget.replaceChildren();
      for (const alias of targets) {
        const option = document.createElement("option");
        option.value = alias;
        option.textContent = `${alias} · ${working.nodes[alias].types.join(" + ")}`;
        elements.customRelationshipTarget.append(option);
      }
      if (to && targets.includes(to)) elements.customRelationshipTarget.value = to;
      elements.customRelationshipTarget.disabled = Boolean(to);
      elements.customRelationshipTerm.value = customRelationshipName(elements.customRelationshipTarget.value);
      elements.customRelationshipDescription.value = "";
      elements.customRelationshipAliases.value = elements.customRelationshipTarget.value;
      elements.customRelationshipExpectation.value = working.nodes[elements.customRelationshipTarget.value]?.expectation === "optional" ? "optional" : "common";
      updateCustomRelationshipSummary();
      setStatus("loading", `Define the adapter-local relationship from ${from} to ${elements.customRelationshipTarget.value}.`);
      elements.customRelationshipTerm.focus({ preventScroll: true });
    }

    function cancelCustomRelationship({ restoreStatus = true } = {}) {
      const from = customConnection?.from;
      customConnection = null;
      elements.customRelationshipEditor.hidden = true;
      if (from && working?.nodes?.[from]) selectNode(from);
      else clearSelection();
      if (restoreStatus) validateWorking();
    }

    function saveCustomRelationship() {
      if (!customConnection) return;
      const from = customConnection.from;
      const to = elements.customRelationshipTarget.value;
      const property = elements.customRelationshipTerm.value.trim();
      const prefix = String(getAdapterPrefix() || "").trim();
      if (!prefix) return setStatus("error", "Set the adapter id before creating custom vocabulary.");
      if (!property.startsWith(`${prefix}:`) || !/^[a-z][a-z0-9-]*:[A-Za-z][A-Za-z0-9_-]*$/.test(property)) {
        return setStatus("error", `Custom relationships must use the adapter prefix, for example ${prefix}:editor.`);
      }
      const description = elements.customRelationshipDescription.value.trim();
      if (!description) return setStatus("error", "Describe what the custom relationship means.");
      if (working.edges.some((edge) => edge.from === from && edge.property === property && edge.to === to)) {
        return setStatus("error", `${property} already connects ${from} to ${to}.`);
      }
      const aliases = elements.customRelationshipAliases.value.split(",").map((value) => value.trim()).filter(Boolean);
      const sourceTypes = working.nodes[from].types;
      const targetTypes = working.nodes[to].types;
      const definition = {
        description,
        valueType: targetTypes[0],
        cardinality: "one",
        example: aliases[0] || to || targetTypes[0],
        kind: "relationship",
        domainIncludes: [...new Set(sourceTypes)],
        rangeIncludes: [...new Set(targetTypes)],
        evidenceAliases: [...new Set([property.split(":").at(-1), ...aliases])]
      };
      const existing = workingCustomTerms[property];
      if (existing && (existing.kind !== "relationship" || JSON.stringify(existing.domainIncludes || []) !== JSON.stringify(definition.domainIncludes) || JSON.stringify(existing.rangeIncludes || []) !== JSON.stringify(definition.rangeIncludes))) {
        return setStatus("error", `${property} is already defined with a different meaning in this draft.`);
      }
      const next = clone(working);
      const nextTerms = clone(workingCustomTerms);
      nextTerms[property] = existing || definition;
      next.edges.push({ from, property, to, expectation: elements.customRelationshipExpectation.value });
      const result = compositions.validate(next, nextTerms);
      if (!result.ok) return setStatus("error", result.errors.join(" "));
      customConnection = null;
      elements.customRelationshipEditor.hidden = true;
      working = next;
      workingCustomTerms = nextTerms;
      rerender({ kind: "edge", index: working.edges.length - 1 });
      setStatus("ready", `Added ${property}. It will be saved with the graph when you apply.`);
    }

    let customTypeTermEdited = false;

    function updateCustomTypeSummary() {
      if (!customTypeConnection) return;
      const name = elements.customTypeName.value.trim();
      const prefix = String(getAdapterPrefix() || "").trim() || "adapter";
      elements.customTypeSummary.textContent = name ? `${prefix}:${name}` : "Create custom type";
      const relationshipReady = !customTypeConnection.lockedTarget
        || (elements.customTypeRelationshipTerm.value.trim() && elements.customTypeRelationshipDescription.value.trim());
      elements.saveCustomType.disabled = !name || !elements.customTypeDescription.value.trim() || !relationshipReady;
    }

    function beginCustomType({ point = null, lockedTarget = null } = {}) {
      cancelKeyboardConnection({ restoreStatus: false });
      clearCustomDwell();
      if (!working) return;
      customTypeConnection = { point, lockedTarget };
      customTypeTermEdited = false;
      clearSelection();
      elements.customTypeEditor.hidden = false;
      elements.customTypeName.value = "";
      elements.customTypeDescription.value = "";
      elements.customTypeRelationship.hidden = !lockedTarget;
      elements.customTypeTarget.replaceChildren();
      elements.customTypeRelationshipTerm.value = "";
      elements.customTypeRelationshipDescription.value = "";
      if (lockedTarget && working.nodes[lockedTarget]) {
        const option = document.createElement("option");
        option.value = lockedTarget;
        option.textContent = `${lockedTarget} · ${working.nodes[lockedTarget].types.join(" + ")}`;
        elements.customTypeTarget.append(option);
        elements.customTypeTarget.value = lockedTarget;
      }
      updateCustomTypeSummary();
      setStatus("loading", lockedTarget ? `Name the new type to connect to ${lockedTarget}.` : "Name the new adapter-local type.");
      elements.customTypeName.focus({ preventScroll: true });
    }

    function cancelCustomType({ restoreStatus = true } = {}) {
      customTypeConnection = null;
      elements.customTypeEditor.hidden = true;
      clearSelection();
      if (restoreStatus) validateWorking();
    }

    async function saveCustomType() {
      if (!customTypeConnection) return;
      const name = elements.customTypeName.value.trim();
      const prefix = String(getAdapterPrefix() || "").trim();
      if (!prefix) return setStatus("error", "Set the adapter id before creating custom vocabulary.");
      const termId = `${prefix}:${name}`;
      if (!/^[a-z][a-z0-9-]*:[A-Za-z][A-Za-z0-9_-]*$/.test(termId)) {
        return setStatus("error", `Custom types must use the adapter prefix, for example ${prefix}:Editor.`);
      }
      const description = elements.customTypeDescription.value.trim();
      if (!description) return setStatus("error", "Describe what the custom type represents.");
      const existingTypeTerm = workingCustomTerms[termId];
      if (existingTypeTerm && existingTypeTerm.kind !== "type") {
        return setStatus("error", `${termId} is already defined with a different meaning in this draft.`);
      }
      const lockedTarget = customTypeConnection.lockedTarget;
      let relationshipProperty = null;
      let relationshipDescription = "";
      if (lockedTarget) {
        if (!working.nodes[lockedTarget]) return setStatus("error", "The target node no longer exists.");
        relationshipProperty = elements.customTypeRelationshipTerm.value.trim();
        if (!relationshipProperty.startsWith(`${prefix}:`) || !/^[a-z][a-z0-9-]*:[A-Za-z][A-Za-z0-9_-]*$/.test(relationshipProperty)) {
          return setStatus("error", `Custom relationships must use the adapter prefix, for example ${prefix}:editor.`);
        }
        relationshipDescription = elements.customTypeRelationshipDescription.value.trim();
        if (!relationshipDescription) return setStatus("error", "Describe what the relationship to the target means.");
      }

      const alias = suggestedAlias(name);
      const nextTerms = clone(workingCustomTerms);
      const typeDefinition = existingTypeTerm || { description, valueType: termId, cardinality: "one", example: name, kind: "type" };
      nextTerms[termId] = typeDefinition;
      const next = clone(working);
      next.nodes[alias] = { types: [termId], expectation: "optional" };
      if (customTypeConnection.point) nodePositions.set(alias, customTypeConnection.point);

      if (lockedTarget) {
        const targetTypes = working.nodes[lockedTarget].types;
        const relDefinition = {
          description: relationshipDescription, valueType: termId, cardinality: "one", example: alias,
          kind: "relationship", domainIncludes: [...new Set(targetTypes)], rangeIncludes: [termId],
          evidenceAliases: [relationshipProperty.split(":").at(-1)]
        };
        const existingRelTerm = nextTerms[relationshipProperty];
        if (existingRelTerm && (existingRelTerm.kind !== "relationship" || JSON.stringify(existingRelTerm.domainIncludes || []) !== JSON.stringify(relDefinition.domainIncludes) || JSON.stringify(existingRelTerm.rangeIncludes || []) !== JSON.stringify(relDefinition.rangeIncludes))) {
          return setStatus("error", `${relationshipProperty} is already defined with a different meaning in this draft.`);
        }
        nextTerms[relationshipProperty] = existingRelTerm || relDefinition;
        next.edges.push({ from: lockedTarget, property: relationshipProperty, to: alias, expectation: "optional" });
      }

      if (lockedTarget) {
        const result = compositions.validate(next, nextTerms);
        if (!result.ok) return setStatus("error", result.errors.join(" "));
      }
      const reusableType = { id: termId, label: name, description, definition: typeDefinition };
      try {
        if (libraryService?.saveCustomType) {
          const saved = await libraryService.saveCustomType({ customType: reusableType, expectedRevision: 0 });
          toolbox.customTypes[saved.id] = saved;
        } else if (toolboxApi?.addCustomType) {
          toolbox = toolboxApi.addCustomType(toolbox, reusableType);
          if (toolboxApi.save) toolbox = await toolboxApi.save(toolbox, storage || undefined);
        }
      } catch (error) {
        return setStatus("error", `Could not save ${termId} to the Semantic Library: ${error.message}`);
      }
      customTypeConnection = null;
      elements.customTypeEditor.hidden = true;
      working = next;
      workingCustomTerms = nextTerms;
      rerender({ kind: "node", alias });
      if (lockedTarget) setStatus("ready", `Added ${termId} as ${alias}, connected to ${lockedTarget}, and saved the type to the Semantic Library. Apply the graph to keep this connection.`);
      else setStatus("error", `${termId} was saved to the Semantic Library and added as ${alias}. Connect it to the root graph before applying.`);
    }

    function beginKeyboardConnection() {
      if (selected?.kind !== "node") return setStatus("error", "Select a source node before starting a connection.");
      const targets = Object.keys(working.nodes).filter((alias) => alias !== selected.alias);
      if (!targets.length) return setStatus("error", `${selected.alias} has no other nodes to connect.`);
      keyboardConnection = { from: selected.alias, targets, index: 0 };
      showConnectionTargets(keyboardConnection.from, targets[0]);
      moveKeyboardTarget(0);
    }

    function moveKeyboardTarget(direction) {
      if (!keyboardConnection) return;
      const count = keyboardConnection.targets.length;
      keyboardConnection.index = (keyboardConnection.index + direction + count) % count;
      const target = keyboardConnection.targets[keyboardConnection.index];
      showConnectionTargets(keyboardConnection.from, target);
      setStatus("loading", connectionOptions(keyboardConnection.from, target).length
        ? `Connecting from ${keyboardConnection.from} to ${target}. Press Enter to continue.`
        : `Connecting from ${keyboardConnection.from}: ${target} has no Schema.org relationship. Press Enter to create a custom relationship.`);
    }

    function destroyGraph() {
      cancelKeyboardConnection({ restoreStatus: false });
      clearCustomDwell();
      graph?.destroy?.();
      graph = null;
      graphVertices = new Map();
      graphEdges = new Map();
      elements.canvas.replaceChildren();
    }

    function captureViewport() {
      if (!graph) return null;
      const view = graph.getView?.();
      const translate = view?.getTranslate?.() || view?.translate;
      return {
        scale: Number(view?.getScale?.() ?? view?.scale),
        translateX: Number(translate?.x),
        translateY: Number(translate?.y),
        scrollLeft: elements.canvas.scrollLeft,
        scrollTop: elements.canvas.scrollTop
      };
    }

    function restoreViewport(viewport) {
      if (!graph || !viewport) return;
      const view = graph.getView?.();
      if (Number.isFinite(viewport.scale)) {
        if (typeof view?.scaleAndTranslate === "function" && Number.isFinite(viewport.translateX) && Number.isFinite(viewport.translateY)) {
          view.scaleAndTranslate(viewport.scale, viewport.translateX, viewport.translateY);
        } else {
          view?.setScale?.(viewport.scale);
          if (Number.isFinite(viewport.translateX) && Number.isFinite(viewport.translateY)) {
            view?.setTranslate?.(viewport.translateX, viewport.translateY);
          }
        }
      }
      elements.canvas.scrollLeft = viewport.scrollLeft;
      elements.canvas.scrollTop = viewport.scrollTop;
    }

    function renderGraph() {
      destroyGraph();
      if (!working || !maxGraph?.Graph) {
        setStatus("error", "The graph renderer is unavailable. The form editor remains available.");
        return;
      }
      graph = new maxGraph.Graph(elements.canvas);
      graph.setCellsEditable(false);
      graph.setCellsResizable(false);
      graph.setCellsMovable(true);
      graph.setConnectable(true);
      graph.setAllowDanglingEdges?.(false);
      graph.setPanning(true);
      graph.setHtmlLabels(true);
      const parent = graph.getDefaultParent();
      const levels = graphLevels();
      const positions = graphPositions(levels);
      graphVertices = new Map();
      graphEdges = new Map();
      const colors = graphTheme();
      graph.batchUpdate(() => {
        for (const [alias, node] of Object.entries(working.nodes)) {
          const rootNode = alias === working.root;
          const customNode = !rootNode && isCustomTypeNode(node);
          const vertex = graph.insertVertex({
            parent,
            value: nodeLabel(alias, node),
            position: positions.get(alias),
            size: [166, 72],
            style: {
              rounded: true, whiteSpace: "wrap", fontSize: 11, fontStyle: rootNode ? 1 : 0,
              fontColor: rootNode ? (document.documentElement.dataset.theme === "dark" ? "#102116" : "#ffffff") : colors.text,
              fillColor: rootNode ? colors.success : node.expectation === "optional" ? colors.warningBg : colors.successBg,
              strokeColor: rootNode ? colors.success : customNode ? colors.custom : node.expectation === "optional" ? colors.warningBorder : colors.successBorder,
              dashed: customNode
            }
          });
          vertex.semanticNodeAlias = alias;
          graphVertices.set(alias, vertex);
        }
        working.edges.forEach((edge, index) => {
          const cell = graph.insertEdge({
            parent, source: graphVertices.get(edge.from), target: graphVertices.get(edge.to), value: edge.property,
            style: {
              rounded: true, edgeStyle: "orthogonalEdgeStyle", orthogonalLoop: true, jettySize: 20,
              strokeColor: colors.edge, fontColor: colors.muted, endArrow: "block",
              fontSize: 10, labelBackgroundColor: colors.surface, labelBorderColor: colors.edge, labelPadding: 4
            }
          });
          cell.semanticEdgeIndex = index;
          graphEdges.set(index, cell);
          if (cell.geometry && maxGraph.Point) {
            const direction = index % 2 ? -1 : 1;
            cell.geometry.offset = new maxGraph.Point(direction * (28 + Math.floor(index / 2) * 10), -8);
          }
        });
        if (pendingConnection && graphVertices.has(pendingConnection.from) && graphVertices.has(pendingConnection.to)) {
          const preview = graph.insertEdge({
            parent,
            source: graphVertices.get(pendingConnection.from),
            target: graphVertices.get(pendingConnection.to),
            value: `${pendingConnection.options.length} relationship choices`,
            style: {
              rounded: true, edgeStyle: "orthogonalEdgeStyle", orthogonalLoop: true, jettySize: 20,
              dashed: true, strokeWidth: 2, strokeColor: colors.warning, fontColor: colors.warning, endArrow: "block",
              fontSize: 10, labelBackgroundColor: colors.warningBg, labelBorderColor: colors.warningBorder, labelPadding: 4
            }
          });
          preview.semanticPendingConnection = true;
          if (preview.geometry && maxGraph.Point) preview.geometry.offset = new maxGraph.Point(20, 0);
        }
      });
      graph.getSelectionModel().addListener(maxGraph.InternalEvent.CHANGE, () => {
        const cell = graph.getSelectionCell?.();
        if (cell?.semanticNodeAlias) selectNode(cell.semanticNodeAlias);
        else if (Number.isInteger(cell?.semanticEdgeIndex)) selectEdge(cell.semanticEdgeIndex);
        else clearSelection();
        // maxGraph's SVG cells are not focusable controls. Keep keyboard
        // shortcuts attached to the graph after a pointer selection instead
        // of leaving focus on whichever sidebar button was used previously.
        if (cell) elements.canvas.focus({ preventScroll: true });
      });
      const connectionHandler = graph.getPlugin?.("ConnectionHandler");
      if (connectionHandler) {
        connectionHandler.connectImage = { src: CONNECT_HANDLE, width: 18, height: 18 };
        connectionHandler.setCreateTarget?.(false);
        connectionHandler.validateConnection = (source, target) => {
          const from = source?.semanticNodeAlias;
          const to = target?.semanticNodeAlias;
          return from && to && connectionOptions(from, to).length
            ? null
            : `No unused Schema.org relationship connects ${from || "that source"} to ${to || "that target"}.`;
        };
        connectionHandler.getIconPosition = (icon, state) => ({
          x: state.x + state.width - icon.bounds.width / 2,
          y: state.y + state.height / 2 - icon.bounds.height / 2
        });
        const nativeMouseMove = connectionHandler.mouseMove?.bind(connectionHandler);
        if (nativeMouseMove) connectionHandler.mouseMove = (sender, mouseEvent) => {
          nativeMouseMove(sender, mouseEvent);
          if (!connectionHandler.isConnecting?.() || !connectionHandler.previous) return clearCustomDwell();
          const from = connectionHandler.previous.cell?.semanticNodeAlias;
          const to = mouseEvent?.getCell?.()?.semanticNodeAlias
            || connectionAliasAtPoint(mouseEvent?.getEvent?.());
          trackCustomDwell(from, to);
        };
        const nativeMouseUp = connectionHandler.mouseUp?.bind(connectionHandler);
        if (nativeMouseUp) connectionHandler.mouseUp = (sender, mouseEvent) => {
          const releasedAlias = mouseEvent?.getCell?.()?.semanticNodeAlias
            || connectionAliasAtPoint(mouseEvent?.getEvent?.());
          if (customDwell?.ready && releasedAlias === customDwell.to) {
            const { from, to } = customDwell;
            clearCustomDwell();
            connectionHandler.reset?.();
            mouseEvent?.consume?.();
            beginCustomRelationship(from, to);
            return;
          }
          // maxGraph can lose currentState when an SVG label receives the final
          // event. Restore the rendered target before its native release logic
          // validates and tears down the preview.
          if (connectionHandler.isConnecting?.() && connectionHandler.previous) {
            const alias = mouseEvent?.getCell?.()?.semanticNodeAlias
              || connectionAliasAtPoint(mouseEvent?.getEvent?.());
            const target = graphVertices.get(alias);
            if (target) {
              connectionHandler.currentState = graph.getView().getState(target);
              connectionHandler.error = connectionHandler.validateConnection(connectionHandler.previous.cell, target);
            }
          }
          nativeMouseUp(sender, mouseEvent);
        };
        connectionHandler.connect = (source, target, event, dropTarget) => {
          const from = source?.semanticNodeAlias;
          const to = target?.semanticNodeAlias
            || dropTarget?.semanticNodeAlias
            || connectionAliasAtPoint(event);
          if (from && to) handleConnection(from, to);
          else setStatus("error", `Drop the connector from ${from || "the source"} on a highlighted compatible node.`);
        };
        connectionHandler.addListener?.(maxGraph.InternalEvent.START, (_sender, event) => {
          clearCustomDwell();
          const alias = event.getProperty?.("state")?.cell?.semanticNodeAlias;
          if (alias) {
            showConnectionTargets(alias);
            setStatus("loading", `Connecting from ${alias}. Drop on a highlighted compatible node.`);
          }
        });
        connectionHandler.addListener?.(maxGraph.InternalEvent.RESET, () => clearConnectionHighlights());
      }
      graph.validationAlert = (message) => setStatus("error", message);
      graph.addListener?.(maxGraph.InternalEvent.MOVE_CELLS, (_sender, event) => {
        for (const cell of event.getProperty?.("cells") || []) {
          const geometry = cell.getGeometry?.() || cell.geometry || cell.position;
          if (cell.semanticNodeAlias && Number.isFinite(geometry?.x) && Number.isFinite(geometry?.y)) {
            nodePositions.set(cell.semanticNodeAlias, [geometry.x, geometry.y]);
          }
        }
      });
    }

    function centerGraph() {
      if (!graph) return;
      const fit = graph.getPlugin?.("fit");
      if (fit?.fitCenter) {
        fit.maxFitScale = 1;
        fit.fitCenter({ margin: 18 });
      } else {
        graph.zoomActual?.();
        elements.canvas.scrollLeft = Math.max(0, (elements.canvas.scrollWidth - elements.canvas.clientWidth) / 2);
        elements.canvas.scrollTop = Math.max(0, (elements.canvas.scrollHeight - elements.canvas.clientHeight) / 2);
      }
      validateWorking();
    }

    function autoArrange() {
      if (!graph || !working) return;
      const mode = elements.layoutMode?.value || "hierarchical";
      const Layout = {
        hierarchical: maxGraph.HierarchicalLayout,
        tree: maxGraph.CompactTreeLayout,
        organic: maxGraph.FastOrganicLayout,
        circle: maxGraph.CircleLayout
      }[mode];
      if (typeof Layout !== "function") return setInspectorStatus(elements.autoLayoutStatus, "error", `The ${mode} layout is unavailable in this build.`);
      try {
        const layout = mode === "hierarchical"
          ? new Layout(graph, "west", true)
          : mode === "tree"
            ? new Layout(graph, true, false)
            : new Layout(graph);
        if (mode === "hierarchical") {
          layout.intraCellSpacing = 34;
          layout.interRankCellSpacing = 78;
          layout.interHierarchySpacing = 52;
        } else if (mode === "tree") {
          layout.levelDistance = 58;
          layout.nodeDistance = 28;
        } else if (mode === "organic") {
          layout.forceConstant = Math.max(90, Math.min(180, Object.keys(working.nodes).length * 12));
        }
        graph.batchUpdate(() => layout.execute(graph.getDefaultParent()));
        for (const [alias, cell] of graphVertices) {
          const geometry = cell.getGeometry?.() || cell.geometry || cell.position;
          if (Number.isFinite(geometry?.x) && Number.isFinite(geometry?.y)) nodePositions.set(alias, [geometry.x, geometry.y]);
        }
        centerGraph();
        const label = elements.layoutMode?.selectedOptions?.[0]?.textContent || mode;
        confirm(`${label} layout applied.`, elements.autoLayoutStatus);
      } catch (error) {
        setInspectorStatus(elements.autoLayoutStatus, "error", error instanceof Error ? error.message : String(error));
      }
    }

    function clearSelection() {
      selected = null;
      pendingConnection = null;
      customConnection = null;
      elements.empty.hidden = false;
      elements.nodeEditor.hidden = true;
      elements.edgeEditor.hidden = true;
      elements.customRelationshipEditor.hidden = true;
      updateSavePatternButton();
      if (lastLivePreview) focusLiveSelection({ reveal: false });
    }

    function targetTypes() {
      const source = working?.nodes?.[selected?.alias];
      return source && elements.relationProperty.value
        ? compositions.relationshipTargetTypes(source.types, elements.relationProperty.value)
        : [];
    }

    function updateConnectionTargets() {
      if (selected?.kind !== "node") return;
      const types = targetTypes();
      const allowed = new Set(types);
      elements.targetTypes.replaceChildren();
      for (const type of types) {
        const option = document.createElement("option");
        option.value = type;
        elements.targetTypes.append(option);
      }
      const previous = elements.relationTarget.value;
      elements.relationTarget.replaceChildren();
      const create = document.createElement("option");
      create.value = "__new__";
      create.textContent = "Create a new node…";
      elements.relationTarget.append(create);
      for (const [alias, node] of Object.entries(working.nodes)) {
        if (alias === selected.alias || !node.types.some((type) => allowed.has(type))) continue;
        const option = document.createElement("option");
        option.value = alias;
        option.textContent = `${alias} · ${node.types.join(" + ")}`;
        elements.relationTarget.append(option);
      }
      if ([...elements.relationTarget.options].some((option) => option.value === previous)) elements.relationTarget.value = previous;
      if (pendingConnection?.from === selected.alias && [...elements.relationTarget.options].some((option) => option.value === pendingConnection.to)) {
        elements.relationTarget.value = pendingConnection.to;
      }
      const isNew = elements.relationTarget.value === "__new__";
      elements.newTypeLabel.hidden = !isNew;
      elements.newAliasLabel.hidden = !isNew;
      if (isNew && !allowed.has(elements.newType.value)) {
        elements.newType.value = types[0] || "";
        elements.newAlias.value = suggestedAlias(elements.newType.value);
      }
      elements.addRelationship.disabled = !elements.relationProperty.value || (isNew && (!elements.newType.value.trim() || !elements.newAlias.value.trim()));
    }

    function populateRelationships() {
      const source = working.nodes[selected.alias];
      const previous = elements.relationProperty.value;
      const options = pendingConnection?.from === selected.alias
        ? pendingConnection.options
        : compositions.relationshipOptions(source.types);
      elements.relationProperty.replaceChildren();
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "Choose a relationship…";
      elements.relationProperty.append(placeholder);
      for (const relation of options) {
        const option = document.createElement("option");
        option.value = relation.property;
        option.textContent = `${relation.property} → ${(relation.entityRanges || relation.ranges).join(" | ")}`;
        option.title = relation.description;
        elements.relationProperty.append(option);
      }
      if (options.some((option) => option.property === previous)) elements.relationProperty.value = previous;
      else if (pendingConnection?.from === selected.alias && options.length) elements.relationProperty.value = options[0].property;
      updateConnectionTargets();
    }

    function renderTypeDetails(node) {
      elements.typeDetails.replaceChildren();
      for (const type of node.types) {
        const details = compositions.typeDetails?.(type, workingCustomTerms || {}) || {
          name: type, description: "No local description is available for this type.", supers: [], source: "Unknown vocabulary"
        };
        const item = document.createElement("article");
        item.className = "semantic-type-detail";
        const heading = document.createElement("div");
        heading.className = "semantic-type-detail-heading";
        const name = document.createElement("strong");
        name.textContent = details.name;
        const source = document.createElement("span");
        source.className = "semantic-property-badge";
        source.textContent = details.source;
        heading.append(name, source);
        const description = document.createElement("p");
        description.textContent = details.description;
        item.append(heading, description);
        if (details.supers.length) {
          const supers = document.createElement("small");
          supers.textContent = `Extends ${details.supers.join(", ")}`;
          item.append(supers);
        }
        elements.typeDetails.append(item);
      }
    }

    function propertyOrigin(reference) {
      if (reference.direct) return "Direct";
      return reference.inheritedFrom.length ? `From ${reference.inheritedFrom.join(", ")}` : "Inherited";
    }

    function chooseReferencedRelationship(property) {
      if (selected?.kind !== "node") return;
      const available = [...elements.relationProperty.options].some((option) => option.value === property);
      if (!available) return;
      elements.relationProperty.value = property;
      elements.connectDetails.open = true;
      updateConnectionTargets();
      elements.relationProperty.focus({ preventScroll: true });
      elements.connectDetails.scrollIntoView?.({ block: "nearest" });
    }

    function renderPropertyReference() {
      if (selected?.kind !== "node") return;
      const query = elements.propertySearch.value.trim().toLowerCase();
      const visible = selectedPropertyReference.filter((reference) => !query || [
        reference.property, reference.description, ...reference.ranges, ...reference.inheritedFrom
      ].join(" ").toLowerCase().includes(query));
      elements.propertyCount.textContent = query ? `${visible.length}/${selectedPropertyReference.length}` : String(selectedPropertyReference.length);
      elements.propertyList.replaceChildren();
      if (!visible.length) {
        const empty = document.createElement("p");
        empty.className = "semantic-property-empty";
        empty.textContent = "No available properties match this filter.";
        elements.propertyList.append(empty);
        return;
      }
      const groups = [
        ["Relationships", visible.filter((reference) => reference.entityRanges.length)],
        ["Values", visible.filter((reference) => !reference.entityRanges.length)]
      ];
      for (const [label, references] of groups) {
        if (!references.length) continue;
        const group = document.createElement("section");
        group.className = "semantic-property-group";
        const heading = document.createElement("h4");
        heading.textContent = `${label} (${references.length})`;
        group.append(heading);
        for (const reference of references) {
          const row = document.createElement("article");
          row.className = "semantic-property-row";
          const main = document.createElement("div");
          main.className = "semantic-property-main";
          const name = document.createElement("strong");
          name.textContent = reference.property;
          const range = document.createElement("small");
          range.textContent = reference.ranges.join(" · ") || "Thing";
          main.append(name, range);
          if (reference.description) {
            const description = document.createElement("p");
            description.textContent = reference.description;
            description.title = reference.description;
            main.append(description);
          }
          const actions = document.createElement("div");
          actions.className = "semantic-property-actions";
          const origin = document.createElement("span");
          origin.className = `semantic-property-badge${reference.direct ? " direct" : ""}`;
          origin.textContent = propertyOrigin(reference);
          actions.append(origin);
          if (reference.source !== "Schema.org") {
            const source = document.createElement("span");
            source.className = "semantic-property-badge custom";
            source.textContent = reference.source;
            actions.append(source);
          }
          const connected = working.edges.some((edge) => edge.from === selected.alias && edge.property === reference.property);
          const available = reference.entityRanges.length && [...elements.relationProperty.options].some((option) => option.value === reference.property);
          if (connected) {
            const state = document.createElement("span");
            state.className = "semantic-property-badge connected";
            state.textContent = "Connected";
            actions.append(state);
          } else if (available) {
            const connect = document.createElement("button");
            connect.type = "button";
            connect.className = "secondary compact semantic-property-connect";
            connect.textContent = "Connect";
            connect.addEventListener("click", () => chooseReferencedRelationship(reference.property));
            actions.append(connect);
          }
          if (!reference.entityRanges.length && onVisualEvidence) {
            const evidence = document.createElement("button"); evidence.type = "button"; evidence.className = "secondary compact semantic-property-evidence"; evidence.textContent = "Provide page evidence";
            evidence.setAttribute("aria-label", `Provide page evidence for ${selected.alias}.${reference.property}`);
            evidence.addEventListener("click", () => onVisualEvidence({ caller: "graph", targets: [visualEvidenceObservation.graphTarget(working, selected.alias, reference)] }));
            actions.append(evidence);
          }
          row.append(main, actions);
          group.append(row);
        }
        elements.propertyList.append(group);
      }
    }

    function populateNodeReference(node) {
      renderTypeDetails(node);
      selectedPropertyReference = compositions.propertyReference?.(node.types, workingCustomTerms || {}) || [];
      renderPropertyReference();
    }

    function selectedVariantTypes() {
      return [...elements.nodeVariantTypeList.querySelectorAll(".semantic-variant-type-chip")].map((chip) => chip.dataset.type);
    }

    function renderVariantTypes(types = []) {
      elements.nodeVariantTypeList.replaceChildren();
      for (const type of [...new Set(types)].slice(0, 5)) {
        const chip = document.createElement("span");
        chip.className = "semantic-variant-type-chip";
        chip.dataset.type = type;
        chip.append(document.createTextNode(type));
        const remove = document.createElement("button");
        remove.type = "button";
        remove.setAttribute("aria-label", `Remove ${type}`);
        remove.textContent = "×";
        remove.addEventListener("click", () => chip.remove());
        chip.append(remove);
        elements.nodeVariantTypeList.append(chip);
      }
    }

    function addVariantTypesFromInput(fallbackTypes = null) {
      const requested = elements.nodeVariantTypes.value.split(",").map((value) => value.trim()).filter(Boolean);
      if (!requested.length) return true;
      const fallback = fallbackTypes || working?.nodes?.[selected?.alias]?.types || [];
      const next = [...new Set([...selectedVariantTypes(), ...requested])].filter((type) => !fallback.includes(type));
      if (next.length > 5) {
        setStatus("error", "Choose between 1 and 5 non-fallback variant types.");
        return false;
      }
      const validateType = (type) => {
        if (workingCustomTerms?.[type]?.kind === "type") return;
        compositions.singleType(type);
      };
      try { for (const type of requested) validateType(type); }
      catch (error) {
        setStatus("error", error.message);
        return false;
      }
      renderVariantTypes(next);
      elements.nodeVariantTypes.value = "";
      setStatus("loading", `${next.length} variant type${next.length === 1 ? "" : "s"} selected. Update the node to save them.`);
      return true;
    }

    function selectNode(alias, { preservePending = false } = {}) {
      const node = working?.nodes?.[alias];
      if (!node) return clearSelection();
      liveReviewFocus = null;
      if (!preservePending) pendingConnection = null;
      selected = { kind: "node", alias };
      elements.empty.hidden = true;
      elements.edgeEditor.hidden = true;
      elements.customRelationshipEditor.hidden = true;
      elements.nodeEditor.hidden = false;
      setInspectorStatus(elements.nodeUpdateStatus);
      elements.nodeAlias.textContent = `${alias}${alias === working.root ? " · root" : ""}`;
      elements.nodeTypes.value = node.types.join(", ");
      elements.nodeExpectation.value = node.expectation;
      elements.nodeExpectation.disabled = alias === working.root;
      elements.nodeVariantSlot.checked = Boolean(node.variants?.candidates?.length);
      elements.nodeVariantSlot.disabled = alias === working.root;
      elements.nodeVariantTypesLabel.hidden = !elements.nodeVariantSlot.checked;
      elements.nodeVariantTypes.value = "";
      renderVariantTypes((node.variants?.candidates || []).map((candidate) => candidate.type));
      elements.removeNode.hidden = alias === working.root;
      elements.createCustomRelationship.disabled = Object.keys(working.nodes).length < 2;
      populateRelationships();
      populateNodeReference(node);
      validateWorking();
      updateSavePatternButton();
      const cell = graphVertices.get(alias);
      if (!preservePending && cell && graph?.getSelectionCell?.() !== cell) graph?.setSelectionCell?.(cell);
      if (lastLivePreview) focusLiveSelection();
    }

    function selectEdge(index) {
      const edge = working?.edges?.[index];
      if (!edge) return clearSelection();
      liveReviewFocus = null;
      pendingConnection = null;
      selected = { kind: "edge", index };
      elements.empty.hidden = true;
      elements.nodeEditor.hidden = true;
      elements.edgeEditor.hidden = false;
      elements.customRelationshipEditor.hidden = true;
      setInspectorStatus(elements.edgeUpdateStatus);
      elements.edgeLabel.textContent = `${edge.from} — ${edge.property} → ${edge.to}`;
      const source = working.nodes[edge.from];
      const target = working.nodes[edge.to];
      const choices = new Map([[edge.property, { property: edge.property }]]);
      for (const type of target.types) for (const option of compositions.relationshipOptions(source.types, type)) choices.set(option.property, option);
      elements.edgeProperty.replaceChildren(...[...choices.values()].sort((left, right) => left.property.localeCompare(right.property)).map((choice) => {
        const option = document.createElement("option");
        option.value = choice.property;
        option.textContent = choice.property;
        return option;
      }));
      elements.edgeProperty.value = edge.property;
      elements.edgeExpectation.value = edge.expectation;
      updateSavePatternButton();
      if (lastLivePreview) focusLiveSelection({ reveal: false });
      const cell = graphEdges.get(index);
      if (cell && graph?.getSelectionCell?.() !== cell) graph?.setSelectionCell?.(cell);
    }

    function updateSavePatternButton() {
      elements.savePattern.disabled = patternSelection.size === 0 && selected?.kind !== "node";
    }

    function togglePatternSelection(alias) {
      if (patternSelection.has(alias)) patternSelection.delete(alias);
      else patternSelection.add(alias);
      for (const node of connectionDomNodes(alias)) node.classList.toggle("semantic-pattern-selected", patternSelection.has(alias));
      updateSavePatternButton();
    }

    function reapplyPatternSelection() {
      for (const alias of [...patternSelection]) {
        if (!working.nodes[alias]) { patternSelection.delete(alias); continue; }
        for (const node of connectionDomNodes(alias)) node.classList.add("semantic-pattern-selected");
      }
      updateSavePatternButton();
    }

    function patternSubgraph() {
      const aliases = patternSelection.size
        ? [...patternSelection].filter((alias) => working.nodes[alias])
        : selected?.kind === "node" && working.nodes[selected.alias]
          ? [selected.alias]
          : [];
      if (!aliases.length) return null;
      const selectedSet = new Set(aliases);
      const queue = [working.root];
      const visited = new Set();
      let root = aliases[0];
      while (queue.length) {
        const alias = queue.shift();
        if (visited.has(alias)) continue;
        visited.add(alias);
        if (selectedSet.has(alias)) { root = alias; break; }
        for (const edge of working.edges) if (edge.from === alias) queue.push(edge.to);
      }
      const nodes = {};
      for (const alias of aliases) nodes[alias] = clone(working.nodes[alias]);
      const edges = working.edges.filter((edge) => selectedSet.has(edge.from) && selectedSet.has(edge.to)).map(clone);
      const terms = {};
      for (const node of Object.values(nodes)) for (const type of node.types) if (workingCustomTerms?.[type]?.kind === "type") terms[type] = clone(workingCustomTerms[type]);
      for (const edge of edges) if (workingCustomTerms?.[edge.property]?.kind === "relationship") terms[edge.property] = clone(workingCustomTerms[edge.property]);
      return { root, nodes, edges, terms };
    }

    function beginSavePattern() {
      const subgraph = patternSubgraph();
      if (!subgraph) return;
      elements.empty.hidden = true;
      elements.nodeEditor.hidden = true;
      elements.edgeEditor.hidden = true;
      elements.customRelationshipEditor.hidden = true;
      elements.customTypeEditor.hidden = true;
      elements.savePatternEditor.hidden = false;
      elements.savePatternName.value = "";
      elements.savePatternDescription.value = "";
      const nodeCount = Object.keys(subgraph.nodes).length;
      elements.savePatternSummary.textContent = `${nodeCount} node${nodeCount === 1 ? "" : "s"}, ${subgraph.edges.length} relationship${subgraph.edges.length === 1 ? "" : "s"} selected, rooted at ${subgraph.root}.`;
      setStatus("loading", "Name the pattern to save it to your toolbox.");
      elements.savePatternName.focus({ preventScroll: true });
    }

    function cancelSavePattern() {
      elements.savePatternEditor.hidden = true;
      clearSelection();
      validateWorking();
    }

    async function confirmSavePattern() {
      const subgraph = patternSubgraph();
      const label = elements.savePatternName.value.trim();
      if (!subgraph || !label) return setStatus("error", "Name the pattern before saving it.");
      if (!libraryService?.savePattern && !toolboxApi?.addPattern) return setStatus("error", "The Semantic Library is unavailable.");
      const id = `pattern:${label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "pattern"}-${Date.now().toString(36)}`;
      const record = { id, label, description: elements.savePatternDescription.value.trim(), ...subgraph };
      try {
        if (libraryService?.savePattern) {
          const saved = await libraryService.savePattern({ pattern: record, expectedRevision: 0 });
          toolbox.patterns[saved.id] = saved;
        } else {
          toolbox = toolboxApi.addPattern(toolbox, record);
          if (toolboxApi.save) toolbox = await toolboxApi.save(toolbox, storage || undefined);
        }
      } catch (error) {
        return setStatus("error", `Could not save the pattern: ${error.message}`);
      }
      elements.savePatternEditor.hidden = true;
      patternSelection.clear();
      updateSavePatternButton();
      setStatus("ready", `Saved “${label}” to your toolbox patterns.`);
    }

    function rerender(selection = null, { preserveViewport = true } = {}) {
      const viewport = preserveViewport ? captureViewport() : null;
      renderGraph();
      restoreViewport(viewport);
      reapplyPatternSelection();
      validateWorking();
      if (selection?.kind === "node" && working.nodes[selection.alias]) selectNode(selection.alias);
      else if (selection?.kind === "edge" && working.edges[selection.index]) selectEdge(selection.index);
      else clearSelection();
      if (!elements.livePreview.hidden) {
        liveReviewStale = true;
        liveReviewFocus = null;
        elements.livePreviewStatus.textContent = "The graph changed. This preview and its review decisions are stale; refresh to re-parse before editing them.";
        renderLiveReview();
      }
    }

    async function previewLiveData({ resetReview = liveReviewStale } = {}) {
      if (!onPreview || !working) return;
      const result = validateWorking();
      if (!result.ok) return;
      if (resetReview) liveReviewOverlay = { findings: {}, reports: {} };
      liveReviewStale = false;
      const request = ++previewRequest;
      elements.refreshLivePreview.disabled = true;
      setLivePreviewOpen(true);
      elements.livePreviewSummary.textContent = "Parsing the current page…";
      elements.livePreviewStatus.textContent = "Compiling this graph into a bounded profile, then running V2 against the rendered page.";
      delete elements.livePreviewStatus.dataset.previewSummary;
      lastLivePreview = null;
      elements.livePreviewOutput.textContent = "";
      try {
        const preview = await onPreview(clone(working), clone(workingCustomTerms || getCustomTerms()), clone(liveReviewOverlay));
        if (request !== previewRequest) return;
        const summary = preview.summary || {};
        elements.livePreviewSummary.textContent = `${summary.entityCount || 0} parsed ${summary.entityCount === 1 ? "entity" : "entities"}`;
        elements.livePreviewStatus.textContent = `${summary.assignedFieldCount || 0} fields assigned · ${summary.unresolvedFieldCount || 0} unresolved · ${preview.durationMs ?? 0} ms · profile ${preview.profileDigest || "unversioned"}`;
        elements.livePreviewStatus.dataset.previewSummary = elements.livePreviewStatus.textContent;
        lastLivePreview = preview;
        renderLivePreview();
        const reviewEntry = reviewFocusEntry();
        if (reviewEntry) await focusLiveReview(liveReviewFocus.kind, reviewEntry, { restoreFocus: true });
        else await focusLiveSelection();
      } catch (error) {
        if (request !== previewRequest) return;
        elements.livePreviewSummary.textContent = "Live preview stopped";
        elements.livePreviewStatus.textContent = error instanceof Error ? error.message : String(error);
        lastLivePreview = null;
        elements.livePreviewOutput.textContent = "";
        renderLiveReview();
      } finally {
        if (request === previewRequest) {
          elements.refreshLivePreview.disabled = false;
        }
      }
    }

    function closeLivePreview() {
      previewRequest += 1;
      focusRequest += 1;
      if (lastLivePreview?.previewId && onFocus) Promise.resolve(onFocus({ previewId: lastLivePreview.previewId, alias: null, reveal: false })).catch(() => {});
      setLivePreviewOpen(false);
      elements.refreshLivePreview.disabled = false;
      liveReviewOverlay = { findings: {}, reports: {} };
      liveReviewStale = false;
      liveReviewFocus = null;
      renderLiveReview();
      setWorkspaceLayout("authoring");
    }

    async function selectWorkspaceLayout(layout) {
      if (layout === "compare") {
        setWorkspaceLayout("compare");
        if (elements.livePreview.hidden) await previewLiveData();
        return;
      }
      if (!elements.livePreview.hidden) closeLivePreview();
      else setWorkspaceLayout("authoring");
    }

    function openEditor() {
      const composition = getBlock()?.composition;
      if (!composition) return;
      working = clone(composition);
      workingCustomTerms = clone(getCustomTerms());
      selected = null;
      patternSelection = new Set();
      previewRequest += 1;
      focusRequest += 1;
      setLivePreviewOpen(false);
      lastLivePreview = null;
      liveReviewOverlay = { findings: {}, reports: {} };
      liveReviewStale = false;
      liveReviewFocus = null;
      elements.livePreviewOutput.textContent = "";
      renderLiveReview();
      open = true;
      nodePositions.clear();
      elements.view.hidden = false;
      document.querySelector("#semantic-selection-view").hidden = true;
      document.querySelector("#semantic-advanced-view").hidden = true;
      rerender({ kind: "node", alias: working.root }, { preserveViewport: false });
      if (!toolboxLoaded) loadToolbox();
      else renderFavorites();
      setTimeout(() => elements.close.focus({ preventScroll: true }), 0);
    }

    function navigateAttention(destination) {
      document.querySelector('[data-workflow-step="semantics"]')?.click();
      root.setTimeout(() => {
        if (!open) openEditor();
        if (destination?.nodeAlias && working?.nodes?.[destination.nodeAlias]) selectNode(destination.nodeAlias);
        const target = destination?.section === "variant-types" ? elements.nodeVariantTypesLabel : elements.nodeEditor;
        const nodeSettings = document.querySelector("#semantic-graph-node-settings");
        if (nodeSettings) nodeSettings.open = true;
        target?.scrollIntoView?.({ block: "center", behavior: "smooth" });
        target?.classList.add("attention-target-pulse");
        root.setTimeout(() => target?.classList.remove("attention-target-pulse"), 950);
        (destination?.section === "variant-types" ? elements.nodeVariantTypes : elements.nodeTypes)?.focus?.({ preventScroll: true });
      }, 0);
    }
    attention?.registerNavigator?.("semantic-graph", navigateAttention);

    function closeEditor({ applied = false } = {}) {
      attention?.sync?.("semantic-graph-validation", []);
      attention?.sync?.("semantic-graph-action", []);
      open = false;
      previewRequest += 1;
      focusRequest += 1;
      setMaximized(false);
      if (lastLivePreview?.previewId && onFocus) Promise.resolve(onFocus({ previewId: lastLivePreview.previewId, alias: null, reveal: false })).catch(() => {});
      working = null;
      workingCustomTerms = null;
      selected = null;
      patternSelection = new Set();
      lastLivePreview = null;
      liveReviewOverlay = { findings: {}, reports: {} };
      liveReviewStale = false;
      liveReviewFocus = null;
      renderLiveReview();
      destroyGraph();
      hideTrash();
      elements.view.hidden = true;
      document.querySelector("#semantic-selection-view").hidden = false;
      if (!applied) setStatus("", "");
      setTimeout(() => elements.open.focus({ preventScroll: true }), 0);
    }

    function updateNode() {
      if (selected?.kind !== "node") return;
      const types = [...new Set(elements.nodeTypes.value.split(",").map((value) => value.trim()).filter(Boolean))];
      if (!types.length) return setStatus("error", "A node needs at least one Schema.org type.");
      const validateType = (type) => {
        if (workingCustomTerms?.[type]?.kind === "type") return;
        compositions.singleType(type);
      };
      try { for (const type of types) validateType(type); }
      catch (error) { return setStatus("error", error.message); }
      const nextNode = clone(working.nodes[selected.alias]);
      nextNode.types = types;
      nextNode.expectation = selected.alias === working.root ? "core" : elements.nodeExpectation.value;
      if (selected.alias !== working.root && elements.nodeVariantSlot.checked) {
        if (!addVariantTypesFromInput(types)) return;
        const candidateTypes = selectedVariantTypes().filter((type) => !types.includes(type));
        if (!candidateTypes.length || candidateTypes.length > 5) return setStatus("error", "Choose between 1 and 5 non-fallback variant types.");
        try { for (const type of candidateTypes) validateType(type); }
        catch (error) { return setStatus("error", error.message); }
        const analysis = getBlock()?.variantAnalysis;
        const candidates = candidateTypes.map((type) => {
          const analyzed = analysis?.candidates?.find((candidate) => candidate.schemaType === type);
          return { type, evidence: clone(analyzed?.evidence || []) };
        });
        nextNode.variants = {
          fallback: types[0],
          candidates,
          minScore: analysis?.thresholds?.minScore ?? 6,
          minMargin: analysis?.thresholds?.minMargin ?? 2
        };
      } else delete nextNode.variants;
      working.nodes[selected.alias] = nextNode;
      rerender(selected);
      if (validation().ok) {
        confirm(`${selected.alias} was updated.`, elements.nodeUpdateStatus);
        validateWorking();
      }
    }

    function removeSelectedNode() {
      if (selected?.kind !== "node" || selected.alias === working.root) return;
      working = compositions.removeNode(working, selected.alias);
      rerender({ kind: "node", alias: working.root });
    }

    function removeSelectedEdge() {
      if (selected?.kind !== "edge") return;
      working = compositions.removeEdge(working, selected.index);
      rerender({ kind: "node", alias: working.root });
    }

    function updateSelectedEdge() {
      if (selected?.kind !== "edge") return;
      const next = clone(working);
      const edge = next.edges[selected.index];
      edge.property = elements.edgeProperty.value;
      edge.expectation = elements.edgeExpectation.value;
      const result = compositions.validate(next, workingCustomTerms || getCustomTerms());
      if (!result.ok) return setStatus("error", result.errors.join(" "));
      working = next;
      rerender({ kind: "edge", index: selected.index });
      confirm(`Updated to ${edge.from}.${edge.property} → ${edge.to}.`, elements.edgeUpdateStatus);
      validateWorking();
    }

    function addRelationship() {
      if (selected?.kind !== "node") return;
      const source = selected.alias;
      const property = elements.relationProperty.value;
      if (!property) return;
      const next = clone(working);
      let target = elements.relationTarget.value;
      if (target === "__new__") {
        target = elements.newAlias.value.trim();
        const type = elements.newType.value.trim();
        if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(target)) return setStatus("error", "Node aliases must start with a letter and contain only letters, numbers, _ or -.");
        if (next.nodes[target]) return setStatus("error", `Node alias ${target} already exists.`);
        try { compositions.singleType(type); } catch (error) { return setStatus("error", error.message); }
        next.nodes[target] = { types: [type], expectation: elements.relationExpectation.value };
      }
      next.edges.push({ from: source, property, to: target, expectation: elements.relationExpectation.value });
      const result = compositions.validate(next, getCustomTerms());
      if (!result.ok) return setStatus("error", result.errors.join(" "));
      pendingConnection = null;
      working = next;
      elements.connectDetails.open = false;
      rerender({ kind: "node", alias: target });
      confirm(`Connected ${source}.${property} → ${target}.`, elements.nodeUpdateStatus);
      validateWorking();
    }

    function cancelRelationshipDraft() {
      if (selected?.kind !== "node") return;
      const selection = { kind: "node", alias: selected.alias };
      const hadPendingPreview = Boolean(pendingConnection);
      pendingConnection = null;
      elements.relationProperty.value = "";
      elements.connectDetails.open = false;
      if (hadPendingPreview) rerender(selection);
      else {
        populateRelationships();
        validateWorking();
      }
    }

    async function apply() {
      const result = validateWorking();
      if (!result.ok) return;
      elements.apply.disabled = true;
      try {
        await onApply(clone(working), clone(workingCustomTerms));
        closeEditor({ applied: true });
      } catch (error) {
        setStatus("error", error instanceof Error ? error.message : String(error));
        elements.apply.disabled = false;
      }
    }

    function render() {
      elements.open.disabled = !getBlock()?.composition || !maxGraph?.Graph;
      if (open && !getBlock()?.composition) closeEditor();
      else if (open) {
        elements.view.hidden = false;
        document.querySelector("#semantic-selection-view").hidden = true;
        document.querySelector("#semantic-advanced-view").hidden = true;
      }
    }

    elements.open.addEventListener("click", openEditor);
    elements.close.addEventListener("click", () => closeEditor());
    elements.cancel.addEventListener("click", () => closeEditor());
    elements.apply.addEventListener("click", apply);
    elements.autoLayout?.addEventListener("click", autoArrange);
    elements.center.addEventListener("click", centerGraph);
    elements.maximize?.addEventListener("click", () => setMaximized(!maximized));
    elements.layoutAuthoring?.addEventListener("click", () => selectWorkspaceLayout("authoring"));
    elements.layoutCompare?.addEventListener("click", () => selectWorkspaceLayout("compare"));
    elements.refreshLivePreview?.addEventListener("click", () => previewLiveData());
    elements.closeLivePreview?.addEventListener("click", closeLivePreview);
    elements.livePreviewFormats.forEach((button) => button.addEventListener("click", () => setLivePreviewFormat(button.dataset.livePreviewFormat)));
    elements.savePattern.addEventListener("click", beginSavePattern);
    elements.confirmSavePattern.addEventListener("click", confirmSavePattern);
    elements.cancelSavePattern.addEventListener("click", cancelSavePattern);
    elements.canvas.addEventListener("mousedown", (event) => {
      if (!(event.ctrlKey || event.metaKey || event.shiftKey)) return;
      const alias = connectionAliasAtPoint(event);
      if (!alias) return;
      event.preventDefault();
      event.stopPropagation();
      togglePatternSelection(alias);
    }, true);
    elements.updateNode.addEventListener("click", updateNode);
    elements.nodeVariantSlot.addEventListener("change", () => {
      elements.nodeVariantTypesLabel.hidden = !elements.nodeVariantSlot.checked;
      if (elements.nodeVariantSlot.checked && !selectedVariantTypes().length) {
        renderVariantTypes((getBlock()?.variantAnalysis?.candidates || [])
          .map((candidate) => candidate.schemaType)
          .filter((type) => !working.nodes[selected?.alias]?.types?.includes(type))
          .slice(0, 5));
      }
    });
    elements.addNodeVariantType.addEventListener("click", addVariantTypesFromInput);
    elements.nodeVariantTypes.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== ",") return;
      event.preventDefault();
      addVariantTypesFromInput();
    });
    elements.removeNode.addEventListener("click", removeSelectedNode);
    elements.removeEdge.addEventListener("click", removeSelectedEdge);
    elements.updateEdge.addEventListener("click", updateSelectedEdge);
    elements.relationProperty.addEventListener("change", updateConnectionTargets);
    elements.propertySearch.addEventListener("input", renderPropertyReference);
    elements.relationTarget.addEventListener("change", updateConnectionTargets);
    elements.newType.addEventListener("input", () => { elements.newAlias.value = suggestedAlias(elements.newType.value.trim()); updateConnectionTargets(); });
    elements.newAlias.addEventListener("input", updateConnectionTargets);
    elements.addRelationship.addEventListener("click", addRelationship);
    elements.cancelRelationship.addEventListener("click", cancelRelationshipDraft);
    elements.createCustomRelationship.addEventListener("click", () => {
      if (selected?.kind === "node") beginCustomRelationship(selected.alias);
    });
    elements.customRelationshipTarget.addEventListener("change", () => {
      elements.customRelationshipTerm.value = customRelationshipName(elements.customRelationshipTarget.value);
      elements.customRelationshipAliases.value = elements.customRelationshipTarget.value;
      updateCustomRelationshipSummary();
    });
    elements.customRelationshipTerm.addEventListener("input", updateCustomRelationshipSummary);
    elements.customRelationshipDescription.addEventListener("input", updateCustomRelationshipSummary);
    elements.saveCustomRelationship.addEventListener("click", saveCustomRelationship);
    elements.cancelCustomRelationship.addEventListener("click", () => cancelCustomRelationship());
    elements.customTypeName.addEventListener("input", () => {
      if (customTypeConnection?.lockedTarget && !customTypeTermEdited) {
        const name = elements.customTypeName.value.trim().replace(/[^A-Za-z0-9_-]+/g, "");
        const prefix = String(getAdapterPrefix() || "").trim() || "adapter";
        elements.customTypeRelationshipTerm.value = name ? `${prefix}:${name[0].toLowerCase()}${name.slice(1)}` : "";
      }
      updateCustomTypeSummary();
    });
    elements.customTypeDescription.addEventListener("input", updateCustomTypeSummary);
    elements.customTypeRelationshipTerm.addEventListener("input", () => { customTypeTermEdited = true; updateCustomTypeSummary(); });
    elements.customTypeRelationshipDescription.addEventListener("input", updateCustomTypeSummary);
    elements.saveCustomType.addEventListener("click", saveCustomType);
    elements.cancelCustomType.addEventListener("click", () => cancelCustomType());
    elements.customTypeTool.addEventListener("dragstart", (event) => {
      const payload = { kind: "customTypeTool", id: "customTypeTool" };
      event.dataTransfer?.setData(DRAG_TYPE, JSON.stringify(payload));
      event.dataTransfer?.setData("text/plain", "Custom type");
      if (event.dataTransfer) event.dataTransfer.effectAllowed = "copy";
      activeDragItem = payload;
    });
    elements.customTypeTool.addEventListener("dragend", () => { activeDragItem = null; clearToolboxDragHover(); });
    elements.customTypeTool.addEventListener("click", () => beginCustomType());
    elements.customTypeTool.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") { event.preventDefault(); beginCustomType(); }
    });
    elements.search.addEventListener("input", () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(renderSearch, 80);
    });
    elements.canvas.addEventListener("dragover", (event) => {
      if (!hasToolDrag(event)) return;
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
      elements.canvas.classList.add("toolbox-drop-active");
      updateToolboxDragHover(event);
    });
    elements.canvas.addEventListener("pointerdown", () => elements.canvas.focus({ preventScroll: true }));
    elements.canvas.addEventListener("dragleave", () => {
      elements.canvas.classList.remove("toolbox-drop-active");
      clearToolboxDragHover();
    });
    elements.canvas.addEventListener("drop", (event) => {
      event.preventDefault();
      elements.canvas.classList.remove("toolbox-drop-active");
      const hadToolDrag = hasToolDrag(event);
      try {
        const item = readDrag(event);
        activeDragItem = null;
        const targetAlias = toolboxDragHoverAlias || connectionAliasAtPoint(event);
        const bounds = elements.canvas.getBoundingClientRect();
        const pointerPoint = [Math.max(8, event.clientX - bounds.left - 83), Math.max(8, event.clientY - bounds.top - 36)];
        const point = targetAlias ? pointBesideTarget(targetAlias, pointerPoint) : pointerPoint;
        if (item?.kind === "customTypeTool") {
          clearToolboxDragHover();
          beginCustomType({ point, lockedTarget: targetAlias || null });
          return;
        }
        if (item?.kind === "pattern") {
          clearToolboxDragHover();
          insertPattern(toolbox.patterns?.[item.id], { point, lockedTarget: targetAlias || null });
          return;
        }
        if (item?.kind !== "schemaType" && item?.kind !== "customType") {
          clearToolboxDragHover();
          if (hadToolDrag) setStatus("error", "The drop could not be read. Try dragging the tile again.");
          return;
        }
        const dwellReady = Boolean(targetAlias) && customDwell?.ready && customDwell.to === targetAlias;
        clearToolboxDragHover();
        const alias = item.kind === "customType" ? addCustomTypeNode(toolbox.customTypes?.[item.id], point) : addTypeNode(item.id, point);
        if (!alias || !targetAlias || targetAlias === alias) return;
        const options = connectionOptions(targetAlias, alias);
        if (options.length === 1) addConnectedEdge(targetAlias, alias, options[0]);
        else if (options.length > 1) beginRelationshipChoice(targetAlias, alias, options);
        else if (dwellReady) beginCustomRelationship(targetAlias, alias);
      } catch (error) {
        activeDragItem = null;
        clearToolboxDragHover();
        setStatus("error", `Drop failed: ${error.message}`);
      }
    });
    elements.favoritesDock.addEventListener("dragenter", (event) => {
      if (!hasToolDrag(event)) return;
      clearTimeout(dockLeaveTimer);
      elements.favoritesDock.classList.add("toolbox-drop-active");
    });
    elements.favoritesDock.addEventListener("dragover", (event) => {
      if (!hasToolDrag(event)) return;
      event.preventDefault();
      clearTimeout(dockLeaveTimer);
      elements.favoritesDock.classList.add("toolbox-drop-active");
      if (!event.target.closest?.(".semantic-toolbox-tile")) indicateFavoriteGap(event);
    });
    elements.favoritesDock.addEventListener("dragleave", (event) => {
      if (event.relatedTarget && elements.favoritesDock.contains(event.relatedTarget)) return;
      clearTimeout(dockLeaveTimer);
      dockLeaveTimer = setTimeout(() => elements.favoritesDock.classList.remove("toolbox-drop-active"), 30);
    });
    elements.favoritesDock.addEventListener("drop", (event) => {
      event.preventDefault();
      clearTimeout(dockLeaveTimer);
      elements.favoritesDock.classList.remove("toolbox-drop-active");
      const item = readDrag(event);
      const index = item ? indicatedFavoriteIndex(item) : null;
      clearDropIndicators();
      if (item) pinFavorite(item, index);
    });
    elements.trash.addEventListener("dragover", (event) => {
      if (!hasToolDrag(event)) return;
      event.preventDefault();
      event.stopPropagation();
      if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
      elements.trash.classList.add("toolbox-drop-active");
    });
    elements.trash.addEventListener("dragleave", () => elements.trash.classList.remove("toolbox-drop-active"));
    elements.trash.addEventListener("drop", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const item = readDrag(event);
      if (Number.isInteger(item?.favoriteIndex)) removeFavorite(item);
      hideTrash();
    });
    elements.view.addEventListener("keydown", (event) => {
      if (!open || event.defaultPrevented) return;
      const tag = event.target?.tagName?.toLowerCase();
      const editing = event.target?.isContentEditable || ["input", "select", "textarea", "button"].includes(tag);
      if (editing && event.key === "Escape" && elements.connectDetails.contains(event.target)) {
        event.preventDefault();
        cancelRelationshipDraft();
        elements.canvas.focus({ preventScroll: true });
        return;
      }
      if (editing) return;
      if (keyboardConnection) {
        if (event.key === "Escape") {
          event.preventDefault();
          cancelKeyboardConnection();
        } else if (event.key === "Tab" || ["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp"].includes(event.key)) {
          event.preventDefault();
          moveKeyboardTarget(event.shiftKey || event.key === "ArrowLeft" || event.key === "ArrowUp" ? -1 : 1);
        } else if (event.key === "Enter") {
          event.preventDefault();
          const { from, targets, index } = keyboardConnection;
          const to = targets[index];
          if (connectionOptions(from, to).length) handleConnection(from, to);
          else beginCustomRelationship(from, to);
        }
        return;
      }
      if (event.key === "c" || event.key === "C") {
        event.preventDefault();
        beginKeyboardConnection();
      } else if (event.key === "Delete" || event.key === "Backspace") {
        if (!selected) return;
        event.preventDefault();
        if (selected.kind === "node" && selected.alias === working.root) return setStatus("error", "The root node cannot be removed.");
        selected.kind === "node" ? removeSelectedNode() : removeSelectedEdge();
      } else if (event.key === "f" || event.key === "F" || event.key === "Home") {
        event.preventDefault();
        centerGraph();
      } else if (event.key === "Escape") {
        event.preventDefault();
        pendingConnection = null;
        graph?.clearSelection?.();
        clearSelection();
      }
    });

    loadToolbox();
    document.defaultView?.addEventListener?.("site2json-theme-change", () => { if (open && working) renderGraph(); });
    return Object.freeze({
      render,
      open: openEditor,
      close: closeEditor,
      refreshLivePreview: () => previewLiveData({ resetReview: false }),
      destroy: destroyGraph,
      elements
    });
  }

  const api = Object.freeze({ create });
  root.Site2JsonSidebarCompositionGraph = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
