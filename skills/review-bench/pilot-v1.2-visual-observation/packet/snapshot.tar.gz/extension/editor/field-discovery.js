(function initializeFieldDiscovery(root, factory) {
  "use strict";
  const selectors = root.Site2JsonSelectorCandidates || (typeof require === "function" ? require("./selector-candidates") : null);
  const api = factory(selectors);
  root.Site2JsonFieldDiscovery = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function fieldDiscoveryFactory(selectors) {
  "use strict";

  const SKIP_TAGS = new Set(["button", "input", "noscript", "option", "path", "script", "select", "style", "svg", "template", "textarea", "use"]);
  const GENERIC_TOKENS = new Set(["box", "card", "content", "data", "detail", "field", "item", "job", "label", "meta", "module", "record", "result", "row", "text", "value", "view"]);
  const KIND_RANK = new Map([["id", 0], ["data", 1], ["aria", 2], ["class", 3], ["structure", 4], ["derived", 5], ["fallback", 6]]);

  function normalizedText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function sourceKey(field) {
    return [field.source || field.selector || "", field.attribute || "", field.kind || "text"].join("\u001f");
  }

  function contextFor(element, scopeRoot) {
    const parts = [];
    for (let current = element, depth = 0; current && current !== scopeRoot && depth < 4; current = current.parentElement, depth += 1) {
      parts.push(`${current.tagName.toLowerCase()} ${selectors.stableId(current)} ${selectors.stableClassNames(current).join(" ")}`.trim());
    }
    return parts.join(" ");
  }

  function semanticTokens(element) {
    const attributes = [
      selectors.stableId(element),
      selectors.stableClassNames(element).join(" "),
      element.getAttribute?.("data-test") || "",
      element.getAttribute?.("data-testid") || "",
      element.getAttribute?.("itemprop") || "",
      element.getAttribute?.("name") || "",
      element.getAttribute?.("aria-label") || ""
    ].join(" ").replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase();
    return [...new Set(attributes.split(/[^a-z0-9]+/).filter((token) => token.length > 2 && !GENERIC_TOKENS.has(token) && !/^\d+$/.test(token)))];
  }

  function suggestedName(element, attribute) {
    if (attribute === "href") return "url";
    if (attribute === "src") return "image";
    if (attribute === "datetime") return "date";
    const tokens = semanticTokens(element);
    if (!tokens.length) return "field";
    return tokens.slice(-3).map((token, index) => index ? `${token[0].toUpperCase()}${token.slice(1)}` : token).join("");
  }

  function eligible(element) {
    const tag = element.tagName.toLowerCase();
    return !SKIP_TAGS.has(tag) && !element.hidden && element.getAttribute("aria-hidden") !== "true";
  }

  function hasOwnText(element) {
    return Array.from(element.childNodes || []).some((node) => node.nodeType === 3 && normalizedText(node.nodeValue).length > 1);
  }

  function textCandidate(element) {
    const text = normalizedText(element.textContent);
    if (!text || text.length > 2000) return false;
    const children = element.children?.length || 0;
    // A small wrapper with a semantic hook can be the meaningful value even
    // when all of its text is inside child spans (for example a project budget
    // containing a type and range). Keeping the wrapper lets transforms see
    // the complete value and avoids manufacturing a multi-value field from
    // its presentation children.
    return children === 0 || (children <= 5 && (hasOwnText(element) || semanticTokens(element).length > 0));
  }

  function candidateValues(scopes, selector, attribute) {
    const values = [];
    const counts = [];
    const rawCounts = [];
    for (const scope of scopes) {
      let nodes;
      try { nodes = Array.from(scope.querySelectorAll(selector)); } catch { return null; }
      rawCounts.push(nodes.length);
      const current = nodes.map((node) => normalizedText(attribute ? node.getAttribute(attribute) : node.textContent)).filter(Boolean);
      counts.push(current.length);
      values.push(current);
    }
    return { values, counts, rawCounts, coverage: values.filter((current) => current.length).length };
  }

  function bestSelector(element, scopeRoot, scopes, document, attribute = null) {
    const candidates = selectors.generateScopedCandidates(element, scopeRoot, document);
    const evaluated = candidates.map((candidate, index) => {
      const result = candidateValues(scopes, candidate.selector, attribute);
      // An attribute selector must not broaden an <a href> or <img src> into
      // wrappers that merely share its class. Otherwise a single-valued field
      // can read the first incompatible node and become missing everywhere.
      if (attribute && result && result.rawCounts.some((count, scopeIndex) => count !== result.counts[scopeIndex])) return null;
      return result ? { candidate, index, coverage: result.coverage, population: result.counts.reduce((sum, count) => sum + count, 0) } : null;
    }).filter(Boolean);
    evaluated.sort((left, right) => (
      right.coverage - left.coverage
      || (KIND_RANK.get(left.candidate.kind) ?? 9) - (KIND_RANK.get(right.candidate.kind) ?? 9)
      || right.population - left.population
      || left.index - right.index
    ));
    return evaluated[0]?.candidate || null;
  }

  function descriptor(element, scopeRoot, scopes, document, attribute = null) {
    const picked = bestSelector(element, scopeRoot, scopes, document, attribute);
    if (!picked) return null;
    const sampled = candidateValues(scopes, picked.selector, attribute);
    if (!sampled || sampled.coverage < Math.min(2, scopes.length)) return null;
    const nonzeroCounts = sampled.counts.filter(Boolean);
    const multiple = nonzeroCounts.some((count) => count > 1);
    const firstValue = sampled.values.find((values) => values.length)?.[0] || "";
    const kind = ["href", "src"].includes(attribute) ? "url" : "text";
    const elementSummary = {
      ...selectors.summarizeElement(element),
      id: selectors.stableId(element) || null,
      classes: selectors.stableClassNames(element)
    };
    return {
      selector: picked.selector,
      attribute,
      kind,
      multiple,
      suggestedName: suggestedName(element, attribute),
      evidence: {
        ...elementSummary,
        attribute,
        text: attribute ? elementSummary.text : firstValue,
        value: firstValue,
        context: contextFor(element, scopeRoot),
        href: attribute === "href" ? firstValue : null,
        src: attribute === "src" ? firstValue : null,
        multiple,
        matchCounts: sampled.counts
      },
      coverage: { present: sampled.coverage, sampled: scopes.length },
      sampleValues: sampled.values.slice(0, 5).map((values) => multiple ? values : (values[0] ?? null)),
      selectorKind: picked.kind
    };
  }

  function discoverFromScopes(document, allScopes, { sampleLimit = 100, elementLimit = 400 } = {}) {
    const scopes = allScopes.slice(0, sampleLimit);
    const root = scopes[0];
    const elements = Array.from(root.querySelectorAll("*")).filter(eligible).slice(0, elementLimit);
    const found = [];
    for (const element of elements) {
      const tag = element.tagName.toLowerCase();
      if (textCandidate(element)) found.push(descriptor(element, root, scopes, document));
      if (tag === "a" && element.hasAttribute("href") && !/^(?:#|javascript:)/i.test(element.getAttribute("href"))) found.push(descriptor(element, root, scopes, document, "href"));
      if (tag === "img" && element.hasAttribute("src") && !/^data:/i.test(element.getAttribute("src"))) found.push(descriptor(element, root, scopes, document, "src"));
      if (tag === "img" && normalizedText(element.getAttribute("alt"))) found.push(descriptor(element, root, scopes, document, "alt"));
      if (tag === "time" && element.hasAttribute("datetime")) found.push(descriptor(element, root, scopes, document, "datetime"));
    }
    const bySource = new Map();
    for (const candidate of found.filter(Boolean)) {
      const key = sourceKey(candidate);
      if (!bySource.has(key)) bySource.set(key, candidate);
    }
    const byValues = new Map();
    for (const candidate of bySource.values()) {
      const signature = `${candidate.kind}\u001f${candidate.attribute || ""}\u001f${JSON.stringify(candidate.sampleValues)}`;
      const current = byValues.get(signature);
      const candidateRank = KIND_RANK.get(candidate.selectorKind) ?? 9;
      const currentRank = KIND_RANK.get(current?.selectorKind) ?? 9;
      if (!current || candidateRank < currentRank || (candidateRank === currentRank && candidate.selector.length < current.selector.length)) {
        byValues.set(signature, candidate);
      }
    }
    return { ok: true, totalScopes: allScopes.length, sampledScopes: scopes.length, truncated: elements.length === elementLimit, candidates: Array.from(byValues.values()) };
  }

  function discover(document, scopeSelector, options = {}) {
    let allScopes;
    try { allScopes = Array.from(document.querySelectorAll(scopeSelector)); } catch { return { ok: false, reason: "invalid-scope" }; }
    if (!allScopes.length) return { ok: false, reason: "no-scope" };
    return discoverFromScopes(document, allScopes, options);
  }

  function cssEscapeToken(value, document) {
    const view = document?.defaultView || (typeof globalThis === "object" ? globalThis : undefined);
    if (view?.CSS && typeof view.CSS.escape === "function") return view.CSS.escape(value);
    return String(value).replace(/([^a-zA-Z0-9_-])/g, "\\$1").replace(/^(\d)/, "\\3$1 ");
  }

  function cssEscapeAttributeValue(value) {
    return String(value).replace(/\\/g, "\\\\").replace(/"/g, "\\\"");
  }

  function evenlySample(items, limit) {
    if (items.length <= limit) return items.slice();
    if (limit <= 1) return items.slice(0, 1);
    const sampled = [];
    for (let index = 0; index < limit; index += 1) {
      sampled.push(items[Math.round(index * (items.length - 1) / (limit - 1))]);
    }
    return sampled;
  }

  // Variant inference only needs semantic evidence, not publication-ready
  // field selectors. Building and evaluating the complete selector candidate
  // set for every descendant in every item made analysis scale poorly. This
  // deliberately chooses one stable hook and queries it once.
  function fastSelector(element, scopeRoot, document) {
    const id = selectors.stableId(element);
    if (id) return { selector: `#${cssEscapeToken(id, document)}`, kind: "id" };
    const attributes = Array.from(element.attributes || []).filter((attribute) => (
      ((attribute.name.startsWith("data-") && !attribute.name.startsWith("data-v-") && !attribute.name.startsWith("data-react"))
        || ["itemprop", "itemtype"].includes(attribute.name))
      && attribute.value
      && !selectors.looksGenerated(attribute.value)
    ));
    const priority = ["data-type", "data-kind", "data-test", "data-testid", "data-test-id", "data-qa", "data-cy", "data-automation-id", "itemtype", "itemprop"];
    attributes.sort((left, right) => {
      const leftRank = priority.indexOf(left.name);
      const rightRank = priority.indexOf(right.name);
      return (leftRank < 0 ? priority.length : leftRank) - (rightRank < 0 ? priority.length : rightRank);
    });
    if (attributes[0]) return { selector: `[${attributes[0].name}="${cssEscapeAttributeValue(attributes[0].value)}"]`, kind: "data" };
    const ariaLabel = element.getAttribute?.("aria-label");
    if (ariaLabel) return { selector: `[aria-label="${cssEscapeAttributeValue(ariaLabel)}"]`, kind: "aria" };
    const role = element.getAttribute?.("role");
    if (role) return { selector: `${element.tagName.toLowerCase()}[role="${cssEscapeAttributeValue(role)}"]`, kind: "aria" };
    const classes = selectors.stableClassNames(element);
    if (classes.length) return { selector: classes.slice(0, 2).map((name) => `.${cssEscapeToken(name, document)}`).join(""), kind: "class" };

    const segments = [];
    for (let node = element, depth = 0; node && node !== scopeRoot && depth < 4; node = node.parentElement, depth += 1) {
      const parent = node.parentElement;
      let segment = node.tagName.toLowerCase();
      if (parent) {
        const siblings = Array.from(parent.children).filter((sibling) => sibling.tagName === node.tagName);
        if (siblings.length > 1) segment += `:nth-of-type(${siblings.indexOf(node) + 1})`;
      }
      segments.unshift(segment);
    }
    return { selector: segments.join(" > "), kind: "fallback" };
  }

  function semanticMarker(element) {
    return Array.from(element.attributes || []).some((attribute) => (
      ["itemprop", "itemtype", "role", "aria-label"].includes(attribute.name)
      || (attribute.name.startsWith("data-") && !attribute.name.startsWith("data-v-") && !attribute.name.startsWith("data-react"))
    ) && attribute.value && !selectors.looksGenerated(attribute.value));
  }

  function fastDescriptor(element, scopeRoot, document, attribute = null) {
    const picked = fastSelector(element, scopeRoot, document);
    if (!picked?.selector) return null;
    let nodes;
    try {
      nodes = [
        ...(scopeRoot.matches?.(picked.selector) ? [scopeRoot] : []),
        ...scopeRoot.querySelectorAll(picked.selector)
      ];
    } catch { return null; }
    if (!nodes.length) return null;
    const values = nodes.map((node) => normalizedText(attribute ? node.getAttribute(attribute) : node.textContent)).filter(Boolean);
    const firstValue = values[0] || "";
    const multiple = nodes.length > 1;
    const elementSummary = {
      ...selectors.summarizeElement(element),
      id: selectors.stableId(element) || null,
      classes: selectors.stableClassNames(element)
    };
    return {
      selector: picked.selector,
      attribute,
      kind: ["href", "src"].includes(attribute) ? "url" : "text",
      multiple,
      suggestedName: suggestedName(element, attribute),
      evidence: {
        ...elementSummary,
        attribute,
        text: attribute ? firstValue : (firstValue || elementSummary.text),
        value: firstValue,
        context: contextFor(element, scopeRoot),
        href: attribute === "href" ? firstValue : null,
        src: attribute === "src" ? firstValue : null,
        multiple,
        matchCounts: [nodes.length]
      },
      coverage: { present: 1, sampled: 1 },
      sampleValues: [multiple ? values : (firstValue || null)],
      selectorKind: picked.kind
    };
  }

  function discoverItemEvidence(document, scope, { elementLimit = 160 } = {}) {
    const elements = [scope, ...scope.querySelectorAll("*")].filter(eligible).slice(0, elementLimit);
    const found = [];
    for (const element of elements) {
      const tag = element.tagName.toLowerCase();
      if (textCandidate(element) || semanticMarker(element)) found.push(fastDescriptor(element, scope, document));
      if (tag === "a" && element.hasAttribute("href") && !/^(?:#|javascript:)/i.test(element.getAttribute("href"))) found.push(fastDescriptor(element, scope, document, "href"));
      if (tag === "img" && element.hasAttribute("src") && !/^data:/i.test(element.getAttribute("src"))) found.push(fastDescriptor(element, scope, document, "src"));
      if (tag === "img" && normalizedText(element.getAttribute("alt"))) found.push(fastDescriptor(element, scope, document, "alt"));
      if (tag === "time" && element.hasAttribute("datetime")) found.push(fastDescriptor(element, scope, document, "datetime"));
    }
    const candidates = new Map();
    for (const candidate of found.filter(Boolean)) {
      const key = sourceKey(candidate);
      if (!candidates.has(key)) candidates.set(key, candidate);
    }
    return { ok: true, sampledScopes: 1, truncated: elements.length === elementLimit, candidates: Array.from(candidates.values()) };
  }

  function discoverItems(document, scopeSelector, { itemLimit = 50, elementLimit = 400, fast = false } = {}) {
    let allScopes;
    try { allScopes = Array.from(document.querySelectorAll(scopeSelector)); } catch { return { ok: false, reason: "invalid-scope" }; }
    if (!allScopes.length) return { ok: false, reason: "no-scope" };
    const sampled = fast ? evenlySample(allScopes, itemLimit) : allScopes.slice(0, itemLimit);
    return {
      ok: true,
      totalScopes: allScopes.length,
      sampledScopes: sampled.length,
      items: sampled.map((scope) => ({
        index: allScopes.indexOf(scope),
        ...(fast ? discoverItemEvidence(document, scope, { elementLimit }) : discoverFromScopes(document, [scope], { sampleLimit: 1, elementLimit }))
      }))
    };
  }

  function safeUnmappedName(base, used) {
    const clean = String(base || "field").replace(/[^A-Za-z0-9_]/g, "") || "field";
    const stem = `_unmapped_${clean[0].toLowerCase()}${clean.slice(1)}`;
    let suffix = 1;
    let name = `${stem}_${suffix}`;
    while (used.has(name)) name = `${stem}_${++suffix}`;
    return name;
  }

  function identityCandidate(candidates) {
    const ranked = (candidates || []).filter((candidate) => (
      candidate.attribute === "href"
      && candidate.kind === "url"
      && candidate.evidence?.tag === "a"
      && !candidate.multiple
      && candidate.coverage?.present === candidate.coverage?.sampled
    )).map((candidate) => {
      const context = `${candidate.selector} ${candidate.evidence?.context || ""}`.toLowerCase();
      let score = 0;
      if (/\b(?:title|headline)\b|\bh[1-6]\b/.test(context)) score += 12;
      if (/\b(?:apply|avatar|category|client|company|employer|profile|skill|tag)\b/.test(context)) score -= 8;
      if (candidate.evidence?.text) score += 2;
      return { candidate, score };
    }).sort((left, right) => right.score - left.score || left.candidate.selector.length - right.candidate.selector.length);
    return ranked[0]?.score >= 10 ? ranked[0].candidate : null;
  }

  function identityFieldCandidate(fields) {
    const ranked = (fields || []).filter((field) => (
      !field.unresolved
      && !field.multiple
      && ["url", "identifier"].includes(field.name)
    )).map((field) => {
      const evidence = field.evidence || {};
      const context = `${field.selector || ""} ${evidence.context || ""}`.toLowerCase();
      const counts = evidence.matchCounts || [];
      const samples = (field.sampleValues || []).flat().filter(Boolean);
      let score = field.name === "url" ? 30 : 22;
      if (field.name === "url" && evidence.tag === "a" && evidence.attribute === "href") score += 16;
      if (/\b(?:title|headline)\b|\bh[1-6]\b/.test(context)) score += 12;
      if (/\b(?:apply|avatar|category|client|company|employer|profile|skill|tag|navigation|menu)\b/.test(context)) score -= 24;
      if (counts.length && counts.every((count) => count === 1)) score += 8;
      if (samples.length > 1 && new Set(samples).size === samples.length) score += 8;
      return { field, score };
    }).sort((left, right) => right.score - left.score || left.field.selector.length - right.field.selector.length);
    return ranked[0]?.score >= 38 ? ranked[0].field : null;
  }

  function candidateStrength(candidate) {
    const counts = candidate.evidence?.matchCounts || [];
    return (candidate.multiple ? 1000 : 0) + counts.reduce((sum, count) => sum + count, 0) - (KIND_RANK.get(candidate.selectorKind) ?? 9);
  }

  function mappingStrength(candidate, term = null) {
    const report = term?.corroboration || candidate?.corroboration || null;
    if (!report) return candidateStrength(candidate);
    const confidence = report.confidence === "strong" ? 2 : report.confidence === "moderate" ? 1 : 0;
    return confidence * 100000 + Number(report.adjustedScore || report.score || 0) * 100 + candidateStrength(candidate);
  }

  function vocabularyTerm(term) {
    if (term?.source !== "extension") return null;
    if (term.vocabularyTerm && typeof term.vocabularyTerm === "object") return JSON.parse(JSON.stringify(term.vocabularyTerm));
    return {
      description: term.description,
      valueType: term.valueType,
      cardinality: term.cardinality,
      example: term.example
    };
  }

  function corroboration(term) {
    return term?.corroboration && typeof term.corroboration === "object" ? JSON.parse(JSON.stringify(term.corroboration)) : null;
  }

  function isDescendantSelector(selector, containerSelector) {
    if (!selector || !containerSelector || selector === containerSelector) return false;
    return selector.startsWith(`${containerSelector} `) || selector.startsWith(`${containerSelector}>`);
  }

  function reconcile(existingFields, candidates, resolve, { includeUnmapped = true } = {}) {
    const fields = existingFields.map((field) => ({ ...field }));
    const bySource = new Map(fields.map((field, index) => [sourceKey(field), index]));
    const usedNames = new Set(fields.map((field) => field.name));
    const summary = { added: 0, upgraded: 0, unchanged: 0, skipped: 0, unresolved: 0, pruned: 0 };
    const structuredClaims = [];
    const prunedSources = new Set();
    for (const candidate of candidates) {
      const key = sourceKey(candidate);
      const claimed = structuredClaims.find((claim) => isDescendantSelector(candidate.selector, claim));
      if (claimed) {
        const existingIndex = bySource.get(key);
        const existing = existingIndex === undefined ? null : fields[existingIndex];
        if (existing?.locked || (existing && existing.provenance !== "discovery")) summary.unchanged += 1;
        else if (existing?.unresolved) prunedSources.add(key);
        else summary.skipped += 1;
        continue;
      }
      const term = resolve(candidate) || null;
      if (term?.source === "extension" && term.score >= 90 && term.valueType === "Object") structuredClaims.push(candidate.selector);
      const existingIndex = bySource.get(key);
      if (existingIndex !== undefined) {
        const current = fields[existingIndex];
        if (current.locked || !current.unresolved || !term || (usedNames.has(term.name) && term.name !== current.name)) {
          summary.unchanged += 1;
          continue;
        }
        usedNames.delete(current.name);
        fields[existingIndex] = {
          ...current,
          name: term.name,
          transform: term.transform,
          multiple: term.cardinality === "many" && candidate.multiple,
          unresolved: false,
          semanticSource: term.source || "schema",
          coverage: candidate.coverage,
          sampleValues: candidate.sampleValues,
          ...(corroboration(term) ? { corroboration: corroboration(term) } : {}),
          ...(vocabularyTerm(term) ? { vocabularyTerm: vocabularyTerm(term) } : {})
        };
        usedNames.add(term.name);
        summary.upgraded += 1;
        continue;
      }
      if (!term && !includeUnmapped) {
        summary.skipped += 1;
        continue;
      }
      const name = term?.name || safeUnmappedName(candidate.suggestedName, usedNames);
      if (usedNames.has(name)) {
        const duplicateIndex = fields.findIndex((field) => field.name === name && field.provenance === "discovery" && !field.locked);
        const duplicate = duplicateIndex >= 0 ? fields[duplicateIndex] : null;
        if (term && duplicate && mappingStrength(candidate, term) > mappingStrength(duplicate)) {
          bySource.delete(sourceKey(duplicate));
          fields[duplicateIndex] = {
            ...duplicate,
            selector: candidate.selector,
            attribute: candidate.attribute,
            kind: candidate.kind,
            multiple: term.cardinality === "many" && candidate.multiple,
            transform: term.transform,
            semanticSource: term.source || "schema",
            ...(vocabularyTerm(term) ? { vocabularyTerm: vocabularyTerm(term) } : {}),
            sourceKey: key,
            evidence: candidate.evidence,
            coverage: candidate.coverage,
            sampleValues: candidate.sampleValues,
            selectorKind: candidate.selectorKind,
            ...(corroboration(term) ? { corroboration: corroboration(term) } : {})
          };
          bySource.set(key, duplicateIndex);
          summary.upgraded += 1;
          continue;
        }
        summary.skipped += 1;
        continue;
      }
      const field = {
        name,
        selector: candidate.selector,
        attribute: candidate.attribute,
        kind: candidate.kind,
        multiple: term ? term.cardinality === "many" && candidate.multiple : candidate.multiple,
        transform: term?.transform || (candidate.kind === "url" ? ["absoluteUrl", "stripQuery"] : ["text", "trim"]),
        provenance: "discovery",
        locked: false,
        unresolved: !term,
        semanticSource: term?.source || (term ? "schema" : "unmapped"),
        ...(vocabularyTerm(term) ? { vocabularyTerm: vocabularyTerm(term) } : {}),
        sourceKey: key,
        evidence: candidate.evidence,
        coverage: candidate.coverage,
        sampleValues: candidate.sampleValues,
        selectorKind: candidate.selectorKind,
        ...(corroboration(term) || corroboration(candidate) ? { corroboration: corroboration(term) || corroboration(candidate) } : {})
      };
      fields.push(field);
      bySource.set(key, fields.length - 1);
      usedNames.add(name);
      summary.added += 1;
      if (!term) summary.unresolved += 1;
    }
    if (prunedSources.size) {
      summary.pruned = prunedSources.size;
      return { fields: fields.filter((field) => !prunedSources.has(sourceKey(field))), summary };
    }
    return { fields, summary };
  }

  return { discover, discoverFromScopes, discoverItems, identityCandidate, identityFieldCandidate, reconcile, sourceKey, suggestedName };
});
