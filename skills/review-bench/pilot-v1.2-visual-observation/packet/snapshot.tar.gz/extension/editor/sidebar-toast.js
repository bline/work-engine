"use strict";

(function exposeSidebarToast(root) {
  const DEFAULT_DURATION = 2600;

  function create({ document, duration = DEFAULT_DURATION } = {}) {
    const region = document?.querySelector?.("#site2json-toast-region");

    function success(message, options = {}) {
      if (!region || !message) return false;
      const toast = document.createElement("div");
      toast.className = "site2json-toast site2json-toast-success";
      toast.textContent = String(message);
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-atomic", "true");
      region.append(toast);
      while (region.children.length > 3) region.firstElementChild?.remove();

      const timeout = Number.isFinite(options.duration) ? options.duration : duration;
      const dismiss = () => {
        if (!toast.isConnected) return;
        toast.classList.add("leaving");
        root.setTimeout(() => toast.remove(), 160);
      };
      toast.addEventListener("click", dismiss, { once: true });
      root.setTimeout(dismiss, Math.max(500, timeout));
      return true;
    }

    // Intentionally expose success only. Errors, warnings, decisions, and
    // progress must remain visible beside the interface that needs attention.
    return Object.freeze({ success });
  }

  const api = Object.freeze({ create });
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.Site2JsonToast = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
