"use strict";

(function exposeSidebarSemanticLibrary(root) {
  function create({ document, service, catalog: providedCatalog = null, bundleApi: providedBundleApi = null, onLibraryChange = null }) {
    const catalogApi = document.defaultView?.Site2JsonSemanticCatalog || root.Site2JsonSemanticCatalog;
    const catalog = providedCatalog || (catalogApi?.create ? catalogApi.create({ fetchImpl: document.defaultView?.fetch || root.fetch }) : null);
    const bundleApi = providedBundleApi || document.defaultView?.Site2JsonSemanticBundle || root.Site2JsonSemanticBundle;
    const elements = {
      home: document.querySelector("#semantic-library-home"),
      search: document.querySelector("#semantic-library-search"),
      status: document.querySelector("#semantic-library-status"),
      results: document.querySelector("#semantic-library-results"),
      empty: document.querySelector("#semantic-library-empty"),
      loadMore: document.querySelector("#semantic-library-load-more"),
      count: document.querySelector("#semantic-library-result-count"),
      kindFacets: document.querySelector("#semantic-library-kind-facets"),
      tagFacets: document.querySelector("#semantic-library-tag-facets"),
      collectionFacets: document.querySelector("#semantic-library-collection-facets"),
      categoryFacets: document.querySelector("#semantic-library-category-facets"),
      clearFilters: document.querySelector("#semantic-library-clear-filters"),
      selectItems: document.querySelector("#semantic-library-select-items"),
      bulkActions: document.querySelector("#semantic-library-bulk-actions"),
      selectionCount: document.querySelector("#semantic-library-selection-count"),
      exportSelected: document.querySelector("#semantic-library-export-selected"),
      clearSelection: document.querySelector("#semantic-library-clear-selection"),
      layout: document.querySelector("#semantic-library-home .semantic-library-layout"),
      detailEmpty: document.querySelector("#semantic-library-detail-empty"),
      detail: document.querySelector("#semantic-library-detail"),
      detailKind: document.querySelector("#semantic-library-detail-kind"),
      detailName: document.querySelector("#semantic-library-detail-name"),
      detailDescription: document.querySelector("#semantic-library-detail-description"),
      detailMeta: document.querySelector("#semantic-library-detail-meta"),
      detailCategories: document.querySelector("#semantic-library-detail-categories"),
      propertyProfile: document.querySelector("#semantic-library-property-profile"),
      profileAliases: document.querySelector("#semantic-library-profile-aliases"),
      profileNegativeAliases: document.querySelector("#semantic-library-profile-negative-aliases"),
      profileShapes: document.querySelector("#semantic-library-profile-shapes"),
      profileUnits: document.querySelector("#semantic-library-profile-units"),
      profileCardinality: document.querySelector("#semantic-library-profile-cardinality"),
      profileSalience: document.querySelector("#semantic-library-profile-salience"),
      profileNormalization: document.querySelector("#semantic-library-profile-normalization"),
      profileExamples: document.querySelector("#semantic-library-profile-examples"),
      savePattern: document.querySelector("#semantic-library-save-pattern"),
      duplicatePattern: document.querySelector("#semantic-library-duplicate-pattern"),
      deletePattern: document.querySelector("#semantic-library-delete-pattern"),
      exportBundle: document.querySelector("#semantic-library-export-bundle"),
      assignedTags: document.querySelector("#semantic-library-assigned-tags"),
      tagInput: document.querySelector("#semantic-library-tag-input"),
      tagOptions: document.querySelector("#semantic-library-tag-options"),
      addTag: document.querySelector("#semantic-library-add-tag"),
      assignedCollections: document.querySelector("#semantic-library-assigned-collections"),
      collectionInput: document.querySelector("#semantic-library-collection-input"),
      collectionOptions: document.querySelector("#semantic-library-collection-options"),
      addCollection: document.querySelector("#semantic-library-add-collection")
      ,openImport: document.querySelector("#semantic-library-open-import")
      ,openHistory: document.querySelector("#semantic-library-open-history")
      ,openFile: document.querySelector("#semantic-library-open-file")
      ,fileInput: document.querySelector("#semantic-library-file")
      ,filePanel: document.querySelector("#semantic-library-file-import")
      ,closeFile: document.querySelector("#semantic-library-close-file")
      ,fileStatus: document.querySelector("#semantic-library-file-status")
      ,filePreview: document.querySelector("#semantic-library-file-preview")
      ,fileTitle: document.querySelector("#semantic-library-file-title")
      ,fileDescription: document.querySelector("#semantic-library-file-description")
      ,fileMeta: document.querySelector("#semantic-library-file-meta")
      ,fileWarning: document.querySelector("#semantic-library-file-warning")
      ,confirmFile: document.querySelector("#semantic-library-confirm-file")
      ,chooseFile: document.querySelector("#semantic-library-choose-file")
      ,closeImport: document.querySelector("#semantic-library-close-import")
      ,closeHistory: document.querySelector("#semantic-library-close-history")
      ,localBrowser: document.querySelector("#semantic-library-local-browser")
      ,importPanel: document.querySelector("#semantic-library-import")
      ,historyPanel: document.querySelector("#semantic-library-history")
      ,historyStatus: document.querySelector("#semantic-library-history-status")
      ,historyList: document.querySelector("#semantic-library-history-list")
      ,historyEmpty: document.querySelector("#semantic-library-history-empty")
      ,catalogSearch: document.querySelector("#semantic-library-catalog-search")
      ,catalogSearchLabel: document.querySelector("#semantic-library-catalog-search-label")
      ,catalogTermKind: document.querySelector("#semantic-library-catalog-term-kind")
      ,catalogSubmit: document.querySelector("#semantic-library-catalog-submit")
      ,modeTerms: document.querySelector("#semantic-library-mode-terms")
      ,modeVocabularies: document.querySelector("#semantic-library-mode-vocabularies")
      ,catalogStatus: document.querySelector("#semantic-library-catalog-status")
      ,catalogCategories: document.querySelector("#semantic-library-catalog-categories")
      ,catalogCategoryList: document.querySelector("#semantic-library-catalog-category-list")
      ,catalogResults: document.querySelector("#semantic-library-catalog-results")
      ,catalogPagination: document.querySelector("#semantic-library-catalog-pagination")
      ,catalogPrevious: document.querySelector("#semantic-library-catalog-previous")
      ,catalogNext: document.querySelector("#semantic-library-catalog-next")
      ,catalogPage: document.querySelector("#semantic-library-catalog-page")
      ,vocabularyBrowser: document.querySelector("#semantic-library-vocabulary-browser")
      ,vocabularyTitle: document.querySelector("#semantic-library-vocabulary-title")
      ,vocabularyDescription: document.querySelector("#semantic-library-vocabulary-description")
      ,vocabularyBack: document.querySelector("#semantic-library-vocabulary-back")
      ,vocabularySearch: document.querySelector("#semantic-library-vocabulary-search")
      ,vocabularySubmit: document.querySelector("#semantic-library-vocabulary-submit")
      ,vocabularyStatus: document.querySelector("#semantic-library-vocabulary-status")
      ,vocabularyTerms: document.querySelector("#semantic-library-vocabulary-terms")
      ,vocabularyPrevious: document.querySelector("#semantic-library-vocabulary-previous")
      ,vocabularyNext: document.querySelector("#semantic-library-vocabulary-next")
      ,vocabularyPage: document.querySelector("#semantic-library-vocabulary-page")
      ,vocabularySelection: document.querySelector("#semantic-library-vocabulary-selection")
      ,previewVocabulary: document.querySelector("#semantic-library-preview-vocabulary")
      ,importPreview: document.querySelector("#semantic-library-import-preview")
      ,importTitle: document.querySelector("#semantic-library-import-title")
      ,importDescription: document.querySelector("#semantic-library-import-description")
      ,importMeta: document.querySelector("#semantic-library-import-meta")
      ,importAncestorsOption: document.querySelector("#semantic-library-import-ancestors-option")
      ,importAncestors: document.querySelector("#semantic-library-import-ancestors")
      ,importProperties: document.querySelector("#semantic-library-import-properties")
      ,importWarning: document.querySelector("#semantic-library-import-warning")
      ,confirmImport: document.querySelector("#semantic-library-confirm-import")
      ,cancelPreview: document.querySelector("#semantic-library-cancel-preview")
    };
    const filters = { kindIds: new Set(), tagIds: new Set(), collectionIds: new Set(), sourceCategoryIds: new Set() };
    const filterLabels = new Map();
    let items = [];
    let nextCursor = null;
    let totalMatches = 0;
    let selected = null;
    let selectedRecord = null;
    let selectedTags = [];
    let selectedCollections = [];
    let searchGeneration = 0;
    let searchTimer = null;
    let selectionMode = false;
    const selectedTargets = new Map();
    let suggestionTimer = null;
    let catalogGeneration = 0;
    let catalogAbort = null;
    let catalogMode = "term";
    let selectedCatalogCategory = "";
    let catalogPage = 1;
    let catalogTotal = 0;
    let catalogSelection = null;
    let selectedVocabulary = null;
    let vocabularySnapshot = null;
    let vocabularyPage = 1;
    let vocabularyTotal = 0;
    const notifyLibraryChange = () => { if (typeof onLibraryChange === "function") onLibraryChange(); };
    const selectedVocabularyTerms = new Map();
    let importProposal = null;
    let importPlan = null;
    let fileBundle = null;
    let fileImportPlan = null;
    let fileImportName = "";

    function setStatus(kind, message) {
      elements.status.className = `status ${kind || ""}`.trim();
      elements.status.textContent = message || "";
    }

    function slug(value, fallback) {
      return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || fallback;
    }

    function listValue(value) {
      return (value || []).join(", ");
    }

    function parsedList(value) {
      return [...new Set(String(value || "").split(/[\n,]/).map((item) => item.trim()).filter(Boolean))];
    }

    function profileFromForm() {
      const profile = {
        aliases: parsedList(elements.profileAliases.value),
        negativeAliases: parsedList(elements.profileNegativeAliases.value),
        expectedShapes: parsedList(elements.profileShapes.value).map((value) => value.toLowerCase()),
        units: parsedList(elements.profileUnits.value),
        normalization: parsedList(elements.profileNormalization.value),
        cardinality: elements.profileCardinality.value || undefined,
        salience: elements.profileSalience.value === "" ? undefined : Number(elements.profileSalience.value),
        examples: parsedList(elements.profileExamples.value),
        provenance: { source: "user", updatedAt: new Date().toISOString() }
      };
      const populated = [profile.aliases, profile.negativeAliases, profile.expectedShapes, profile.units, profile.normalization, profile.examples]
        .some((value) => value.length) || profile.cardinality !== undefined || profile.salience !== undefined;
      return populated ? profile : null;
    }

    function renderPropertyProfile() {
      const isProperty = selected?.kind === "property";
      elements.propertyProfile.hidden = !isProperty;
      if (!isProperty) return;
      const profile = selectedRecord?.definition?.authoringProfile || {};
      elements.profileAliases.value = listValue(profile.aliases);
      elements.profileNegativeAliases.value = listValue(profile.negativeAliases);
      elements.profileShapes.value = listValue(profile.expectedShapes);
      elements.profileUnits.value = listValue(profile.units);
      elements.profileCardinality.value = profile.cardinality || "";
      elements.profileSalience.value = Number.isInteger(profile.salience) ? String(profile.salience) : "";
      elements.profileNormalization.value = listValue(profile.normalization);
      elements.profileExamples.value = listValue(profile.examples);
    }

    function target() {
      return selected ? { kind: selected.kind, id: selected.id } : null;
    }

    function selectionKey(value) {
      return value ? `${value.kind}\u001f${value.id}` : "";
    }

    function updateSelectionControls() {
      const count = selectedTargets.size;
      elements.selectItems.textContent = selectionMode ? "Done selecting" : "Select items";
      elements.selectItems.classList.toggle("selected", selectionMode);
      elements.bulkActions.hidden = !selectionMode;
      elements.selectionCount.textContent = `${count} selected`;
      elements.exportSelected.disabled = count === 0;
      elements.clearSelection.disabled = count === 0;
    }

    function activeFilterCount() {
      return Object.values(filters).reduce((count, values) => count + values.size, 0);
    }

    function renderFacetGroup(container, group, filterName) {
      container.replaceChildren();
      const values = group?.items || [];
      const selectedIds = filters[filterName];
      const byId = new Map(values.map((facet) => [facet.id, facet]));
      for (const id of selectedIds) if (!byId.has(id)) byId.set(id, { id, label: filterLabels.get(id) || id, count: null });
      for (const facet of byId.values()) {
        filterLabels.set(facet.id, facet.label);
        const button = document.createElement("button");
        button.type = "button";
        button.className = `semantic-library-facet${selectedIds.has(facet.id) ? " selected" : ""}`;
        button.dataset.filter = filterName;
        button.dataset.id = facet.id;
        button.textContent = facet.count === null ? facet.label : `${facet.label} ${facet.count}`;
        button.addEventListener("click", () => {
          if (selectedIds.has(facet.id)) selectedIds.delete(facet.id);
          else selectedIds.add(facet.id);
          refresh();
        });
        container.append(button);
      }
      container.parentElement.hidden = byId.size === 0;
    }

    function renderFacets(facets = {}) {
      renderFacetGroup(elements.kindFacets, facets.kinds, "kindIds");
      renderFacetGroup(elements.tagFacets, facets.tags, "tagIds");
      renderFacetGroup(elements.collectionFacets, facets.collections, "collectionIds");
      renderFacetGroup(elements.categoryFacets, facets.sourceCategories, "sourceCategoryIds");
      elements.clearFilters.hidden = activeFilterCount() === 0;
    }

    function resultRow(item) {
      const row = document.createElement("div");
      row.className = `semantic-library-result-row${selectionMode ? " selecting" : ""}`;
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.hidden = !selectionMode;
      checkbox.checked = selectedTargets.has(selectionKey(item));
      checkbox.setAttribute("aria-label", `Select ${item.label}`);
      checkbox.addEventListener("change", () => {
        const key = selectionKey(item);
        if (checkbox.checked) selectedTargets.set(key, { kind: item.kind, id: item.id, label: item.label });
        else selectedTargets.delete(key);
        updateSelectionControls();
      });
      const button = document.createElement("button");
      button.type = "button";
      button.className = `semantic-library-result${selected?.id === item.id ? " selected" : ""}`;
      button.dataset.kind = item.kind;
      button.dataset.id = item.id;
      const heading = document.createElement("span");
      heading.className = "semantic-library-result-heading";
      const kind = document.createElement("small");
      kind.textContent = item.kind === "pattern" ? "Graph bundle" : item.kind === "customType" ? "Custom type" : item.kind === "property" ? "Property" : item.kind;
      const label = document.createElement("strong");
      label.textContent = item.label;
      heading.append(kind, label);
      const description = document.createElement("span");
      description.className = "semantic-library-result-description";
      description.textContent = item.description || "No description";
      const meta = document.createElement("span");
      meta.className = "semantic-library-result-meta";
      const bundle = item.bundle?.label ? ` · ${item.bundle.label}` : "";
      meta.textContent = item.kind === "customType"
        ? `${item.termId || item.id}${bundle}${item.tagIds?.length ? ` · ${item.tagIds.length} tags` : ""}`
        : item.kind === "property"
          ? `${item.termId || item.id}${bundle} · ${(item.domainIncludes || []).length} domains · ${(item.rangeIncludes || []).length} ranges`
        : `${item.nodeCount || 0} nodes · ${item.relationshipCount || 0} relationships${item.tagIds?.length ? ` · ${item.tagIds.length} tags` : ""}`;
      button.append(heading, description, meta);
      button.addEventListener("click", () => selectItem(item));
      row.append(checkbox, button);
      return row;
    }

    function renderResults(total) {
      elements.results.replaceChildren(...items.map(resultRow));
      elements.count.textContent = String(total || 0);
      elements.empty.hidden = items.length > 0;
      elements.layout.classList.toggle("empty", items.length === 0);
      elements.detailEmpty.parentElement.hidden = items.length === 0;
      elements.loadMore.hidden = !nextCursor;
      updateSelectionControls();
    }

    function toggleSelectionMode() {
      if (selectionMode) selectedTargets.clear();
      selectionMode = !selectionMode;
      renderResults(totalMatches);
    }

    function clearMultiSelection() {
      selectedTargets.clear();
      renderResults(totalMatches);
    }

    async function refresh({ append = false } = {}) {
      if (!service?.search) return setStatus("error", "The Semantic Library service is unavailable.");
      const generation = ++searchGeneration;
      if (!append) { items = []; nextCursor = null; totalMatches = 0; }
      setStatus("loading", append ? "Loading more library items…" : "Searching the Semantic Library…");
      try {
        const result = await service.search({
          query: elements.search.value.trim(),
          filters: Object.fromEntries(Object.entries(filters).map(([key, values]) => [key, [...values]])),
          pageSize: 30,
          ...(append && nextCursor ? { cursor: nextCursor } : {})
        });
        if (generation !== searchGeneration) return;
        items = append ? [...items, ...result.items] : result.items;
        nextCursor = result.nextCursor;
        totalMatches = result.total;
        renderFacets(result.facets);
        renderResults(result.total);
        setStatus("ready", `${result.total} matching library item${result.total === 1 ? "" : "s"}.`);
      } catch (error) {
        if (generation !== searchGeneration) return;
        setStatus("error", error.message);
      }
    }

    function chip(record, onRemove) {
      const element = document.createElement("span");
      element.className = "semantic-library-chip";
      const label = document.createElement("span");
      label.textContent = record.label || record.id;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "×";
      remove.title = `Remove ${record.label || record.id}`;
      remove.addEventListener("click", onRemove);
      element.append(label, remove);
      return element;
    }

    function renderAssignments() {
      elements.assignedTags.replaceChildren(...selectedTags.map((tag) => chip(tag, () => removeTag(tag))));
      elements.assignedCollections.replaceChildren(...selectedCollections.map((collection) => chip(collection, () => removeCollection(collection))));
      elements.assignedTags.classList.toggle("empty", selectedTags.length === 0);
      elements.assignedCollections.classList.toggle("empty", selectedCollections.length === 0);
    }

    async function selectItem(summary) {
      selected = summary;
      renderResults(totalMatches);
      elements.detailEmpty.hidden = true;
      elements.detail.hidden = false;
      setStatus("loading", `Opening ${summary.label}…`);
      try {
        selectedRecord = summary.kind === "customType"
          ? await service.getCustomType(summary.id)
          : summary.kind === "property"
            ? (service.getProperty ? await service.getProperty(summary.id) : (await service.getTerms({ ids: [summary.id] }))[0])
            : await service.getPattern(summary.id);
        const assignments = await service.getTagAssignments({ targets: [target()] });
        const tagIds = assignments[0]?.tagIds || [];
        const collectionIds = summary.collectionIds || [];
        [selectedTags, selectedCollections] = await Promise.all([
          service.getTags({ ids: tagIds }),
          service.getCollections({ ids: collectionIds })
        ]);
        elements.detailKind.textContent = summary.kind === "pattern" ? "Graph bundle" : summary.kind === "property" ? "Property" : "Custom type";
        elements.detailName.value = selectedRecord.label;
        elements.detailDescription.value = selectedRecord.description || "";
        elements.detailMeta.textContent = summary.kind === "customType"
          ? `${selectedRecord.termId || selectedRecord.id}${summary.bundle?.label ? ` · ${summary.bundle.label}` : ""} · revision ${selectedRecord.revision || 1}`
          : summary.kind === "property"
            ? `${selectedRecord.termId || selectedRecord.id}${summary.bundle?.label ? ` · ${summary.bundle.label}` : ""} · ${(selectedRecord.definition?.domainIncludes || []).length} domains · ${(selectedRecord.definition?.rangeIncludes || []).length} ranges · revision ${selectedRecord.revision || 1}`
          : `${Object.keys(selectedRecord.nodes || {}).length} nodes · ${(selectedRecord.edges || []).length} relationships · revision ${selectedRecord.revision || 1}`;
        elements.detailCategories.replaceChildren(...(summary.sourceCategories || []).map((category) => {
          const badge = document.createElement("span");
          badge.className = "semantic-library-category";
          badge.textContent = category.label;
          badge.title = "Imported source category";
          return badge;
        }));
        elements.detailCategories.hidden = !(summary.sourceCategories || []).length;
        elements.exportBundle.textContent = selectedRecord.provenance?.importId ? "Export package" : "Export bundle";
        renderPropertyProfile();
        renderAssignments();
        setStatus("ready", `${summary.label} is ready to manage.`);
      } catch (error) {
        setStatus("error", error.message);
      }
    }

    async function savePattern() {
      if (!selectedRecord) return;
      try {
        const label = elements.detailName.value.trim();
        const description = elements.detailDescription.value.trim();
        if (selected.kind === "customType") {
          selectedRecord = await service.saveCustomType({
            customType: { ...selectedRecord, label, description, definition: { ...selectedRecord.definition, description } },
            expectedRevision: selectedRecord.revision || 1
          });
        } else if (selected.kind === "property") {
          const authoringProfile = profileFromForm();
          const definition = { ...selectedRecord.definition, description };
          if (authoringProfile) definition.authoringProfile = authoringProfile;
          else delete definition.authoringProfile;
          selectedRecord = await service.saveProperty({
            property: { ...selectedRecord, label, description, definition },
            expectedRevision: selectedRecord.revision || 1
          });
        } else {
          selectedRecord = await service.savePattern({
            pattern: { ...selectedRecord, label, description },
            expectedRevision: selectedRecord.revision || 1
          });
        }
        notifyLibraryChange();
        setStatus("ready", `Saved “${selectedRecord.label}”.`);
        await refresh();
        const summary = items.find((item) => item.kind === selected.kind && item.id === selectedRecord.id);
        if (summary) await selectItem(summary);
      } catch (error) {
        setStatus("error", error.message);
      }
    }

    async function duplicatePattern() {
      if (!selectedRecord) return;
      const label = `${selectedRecord.label} copy`;
      const namespace = selectedRecord.provenance?.importId ? "custom" : selectedRecord.id.includes(":") ? selectedRecord.id.slice(0, selectedRecord.id.indexOf(":")) : "custom";
      const id = selected.kind === "customType"
        ? `${namespace}:${slug(label, "copy").replace(/(^|-)([a-z])/g, (_match, _separator, letter) => letter.toUpperCase())}${Date.now().toString(36)}`
        : selected.kind === "property"
          ? `custom:${slug(label, "property").replace(/(^|-)([a-z])/g, (_match, _separator, letter) => letter.toUpperCase())}${Date.now().toString(36)}`
        : `pattern:${slug(label, "copy")}-${Date.now().toString(36)}`;
      const duplicate = { ...selectedRecord, id, label };
      delete duplicate.termId;
      if (selected.kind === "customType") duplicate.definition = { ...duplicate.definition, valueType: id };
      if (duplicate.provenance?.importId) {
        duplicate.provenance = { ...duplicate.provenance };
        delete duplicate.provenance.importId;
        delete duplicate.provenance.bundle;
      }
      delete duplicate.revision;
      delete duplicate.createdAt;
      delete duplicate.updatedAt;
      try {
        const saved = selected.kind === "customType"
          ? await service.saveCustomType({ customType: duplicate, expectedRevision: 0 })
          : selected.kind === "property"
            ? await service.saveProperty({ property: duplicate, expectedRevision: 0 })
          : await service.savePattern({ pattern: duplicate, expectedRevision: 0 });
        notifyLibraryChange();
        elements.search.value = saved.label;
        for (const values of Object.values(filters)) values.clear();
        await refresh();
        const summary = items.find((item) => item.kind === selected.kind && item.id === saved.id);
        if (summary) await selectItem(summary);
        setStatus("ready", `Created “${saved.label}”.`);
      } catch (error) {
        setStatus("error", error.message);
      }
    }

    async function deletePattern() {
      if (!selectedRecord || !document.defaultView.confirm(`Delete “${selectedRecord.label}” from the Semantic Library?`)) return;
      try {
        selectedTargets.delete(selectionKey(selected));
        if (selected.kind === "customType") await service.deleteCustomType({ id: selectedRecord.id, expectedRevision: selectedRecord.revision || 1 });
        else if (selected.kind === "property") await service.deleteProperty({ id: selectedRecord.id, expectedRevision: selectedRecord.revision || 1 });
        else await service.deletePattern({ id: selectedRecord.id, expectedRevision: selectedRecord.revision || 1 });
        notifyLibraryChange();
        selected = null;
        selectedRecord = null;
        selectedTags = [];
        selectedCollections = [];
        elements.detail.hidden = true;
        elements.detailEmpty.hidden = false;
        await refresh();
        setStatus("ready", "The saved pattern was deleted.");
      } catch (error) {
        setStatus("error", error.message);
      }
    }

    function setFileStatus(kind, message) {
      elements.fileStatus.className = `status ${kind || ""}`.trim();
      elements.fileStatus.textContent = message || "";
    }

    function showFilePanel() {
      elements.localBrowser.hidden = true;
      elements.importPanel.hidden = true;
      elements.historyPanel.hidden = true;
      elements.filePanel.hidden = false;
      elements.openFile.hidden = true;
      elements.openImport.hidden = true;
      elements.openHistory.hidden = true;
    }

    function resetFilePreview() {
      fileBundle = null;
      fileImportPlan = null;
      fileImportName = "";
      elements.filePreview.hidden = true;
      elements.fileWarning.hidden = true;
      elements.fileWarning.textContent = "";
      elements.fileMeta.replaceChildren();
      elements.confirmFile.disabled = true;
    }

    function chooseBundleFile() {
      if (!bundleApi?.decode || !service?.planBundleImport) {
        setStatus("error", "Portable semantic bundles are unavailable in this build.");
        return;
      }
      elements.fileInput.click();
    }

    async function previewBundleFile(file) {
      showFilePanel();
      resetFilePreview();
      fileImportName = String(file?.name || "semantic bundle");
      setFileStatus("loading", `Validating ${fileImportName}…`);
      try {
        if (!file?.arrayBuffer) throw new Error("Choose a readable Site2JSON semantic bundle file.");
        fileBundle = await bundleApi.decode(new Uint8Array(await file.arrayBuffer()));
        fileImportPlan = await service.planBundleImport({ bundle: fileBundle });
        const counts = fileImportPlan.counts;
        elements.fileTitle.textContent = fileBundle.bundle.name;
        elements.fileDescription.textContent = fileBundle.bundle.description || "No bundle description was provided.";
        elements.fileMeta.replaceChildren(
          ...metaPair("File", fileImportName),
          ...metaPair("Format", `Site2JSON semantic bundle v${fileBundle.version}`),
          ...metaPair("Created", new Date(fileBundle.bundle.createdAt).toLocaleString()),
          ...metaPair("Types", String(counts.customTypes || 0)),
          ...metaPair("Properties", String(counts.properties || 0)),
          ...metaPair("Graph bundles", String(counts.patterns || 0)),
          ...metaPair("Local ownership", "A new package will be created; existing packages are unchanged")
        );
        elements.filePreview.hidden = false;
        elements.confirmFile.disabled = false;
        setFileStatus("ready", "Preview complete. Nothing has been saved yet.");
        return fileImportPlan;
      } catch (error) {
        resetFilePreview();
        setFileStatus("error", error.message);
        throw error;
      }
    }

    function closeFilePanel() {
      resetFilePreview();
      elements.fileInput.value = "";
      elements.filePanel.hidden = true;
      elements.localBrowser.hidden = false;
      elements.openFile.hidden = false;
      elements.openImport.hidden = false;
      elements.openHistory.hidden = false;
      refresh();
    }

    async function confirmFileImport() {
      if (!fileImportPlan) return;
      elements.confirmFile.disabled = true;
      setFileStatus("loading", `Importing ${fileImportPlan.label}…`);
      try {
        const job = await service.startImport({ planId: fileImportPlan.id });
        notifyLibraryChange();
        const importedName = fileBundle.bundle.name;
        const imported = Number(job.counts.customTypes || 0) + Number(job.counts.properties || 0) + Number(job.counts.patterns || 0);
        closeFilePanel();
        elements.search.value = importedName;
        await refresh();
        setStatus("ready", `Imported ${imported} record${imported === 1 ? "" : "s"} as a new local package.`);
      } catch (error) {
        elements.confirmFile.disabled = false;
        setFileStatus("error", error.message);
      }
    }

    async function downloadPortableBundle(bundle) {
      const compressed = await bundleApi.encode(bundle);
      const view = document.defaultView;
      const url = view.URL.createObjectURL(new view.Blob([compressed], { type: "application/gzip" }));
      const link = document.createElement("a");
      link.href = url;
      link.download = bundleApi.suggestedFilename(bundle.bundle.name);
      link.hidden = true;
      document.body.append(link);
      link.click();
      const filename = link.download;
      link.remove();
      view.URL.revokeObjectURL(url);
      return filename;
    }

    async function exportSelectedBundle() {
      if (!selectedRecord || !bundleApi?.encode || !service?.exportBundle) return;
      elements.exportBundle.disabled = true;
      setStatus("loading", `Preparing ${selectedRecord.provenance?.importId ? "package" : "bundle"} export…`);
      try {
        const bundle = await service.exportBundle({ target: target() });
        const filename = await downloadPortableBundle(bundle);
        setStatus("ready", `Exported “${bundle.bundle.name}” as ${filename}.`);
      } catch (error) {
        setStatus("error", error.message);
      } finally {
        elements.exportBundle.disabled = false;
      }
    }

    async function exportMultiSelection() {
      if (!selectedTargets.size || !bundleApi?.encode || !service?.exportBundle) return;
      const targets = [...selectedTargets.values()].map(({ kind, id }) => ({ kind, id }));
      elements.exportSelected.disabled = true;
      setStatus("loading", `Preparing ${targets.length} selected record${targets.length === 1 ? "" : "s"}…`);
      try {
        const bundle = await service.exportBundle({
          targets,
          includeOwningPackage: false,
          ...(targets.length > 1 ? { name: `${targets.length} selected semantic records` } : {})
        });
        const filename = await downloadPortableBundle(bundle);
        setStatus("ready", `Exported ${targets.length} selected record${targets.length === 1 ? "" : "s"} as ${filename}.`);
      } catch (error) {
        setStatus("error", error.message);
      } finally {
        elements.exportSelected.disabled = selectedTargets.size === 0;
      }
    }

    async function findOrCreateTag(label) {
      const found = await service.listTags({ query: label, pageSize: 20 });
      const existing = found.items.find((tag) => tag.label.toLowerCase() === label.toLowerCase() || tag.id === label);
      if (existing) return existing;
      return service.saveTag({ tag: { id: `tag:${slug(label, "tag")}-${Date.now().toString(36)}`, label }, expectedRevision: 0 });
    }

    async function addTag() {
      const label = elements.tagInput.value.trim();
      if (!label || !selected) return;
      try {
        const tag = await findOrCreateTag(label);
        await service.assignTags({ targets: [target()], tagIds: [tag.id], mode: "add" });
        elements.tagInput.value = "";
        await refresh();
        const summary = items.find((item) => item.id === selected.id) || selected;
        await selectItem(summary);
      } catch (error) {
        setStatus("error", error.message);
      }
    }

    async function removeTag(tag) {
      try {
        await service.assignTags({ targets: [target()], tagIds: [tag.id], mode: "remove" });
        selectedTags = selectedTags.filter((candidate) => candidate.id !== tag.id);
        renderAssignments();
        await refresh();
      } catch (error) {
        setStatus("error", error.message);
      }
    }

    async function findOrCreateCollection(label) {
      const found = await service.listCollections({ query: label, pageSize: 20 });
      const existing = found.items.find((collection) => collection.label.toLowerCase() === label.toLowerCase() || collection.id === label);
      if (existing) return service.getCollection(existing.id);
      return service.saveCollection({
        collection: { id: `collection:${slug(label, "collection")}-${Date.now().toString(36)}`, label, members: [] },
        expectedRevision: 0
      });
    }

    async function addCollection() {
      const label = elements.collectionInput.value.trim();
      if (!label || !selected) return;
      try {
        const collection = await findOrCreateCollection(label);
        await service.updateCollectionMembers({
          id: collection.id,
          members: [target()],
          mode: "add",
          expectedRevision: collection.revision || 1
        });
        elements.collectionInput.value = "";
        await refresh();
        const summary = items.find((item) => item.id === selected.id) || selected;
        await selectItem(summary);
      } catch (error) {
        setStatus("error", error.message);
      }
    }

    async function removeCollection(collection) {
      try {
        await service.updateCollectionMembers({
          id: collection.id,
          members: [target()],
          mode: "remove",
          expectedRevision: collection.revision || 1
        });
        selectedCollections = selectedCollections.filter((candidate) => candidate.id !== collection.id);
        renderAssignments();
        await refresh();
      } catch (error) {
        setStatus("error", error.message);
      }
    }

    async function renderSuggestions(kind) {
      const isTag = kind === "tag";
      const input = isTag ? elements.tagInput : elements.collectionInput;
      const datalist = isTag ? elements.tagOptions : elements.collectionOptions;
      const query = input.value.trim();
      if (!query) return datalist.replaceChildren();
      try {
        const result = isTag
          ? await service.listTags({ query, pageSize: 12 })
          : await service.listCollections({ query, pageSize: 12 });
        datalist.replaceChildren(...result.items.map((record) => {
          const option = document.createElement("option");
          option.value = record.label;
          option.label = record.id;
          return option;
        }));
      } catch { datalist.replaceChildren(); }
    }

    function scheduleSuggestions(kind) {
      clearTimeout(suggestionTimer);
      suggestionTimer = setTimeout(() => renderSuggestions(kind), 100);
    }

    function setCatalogStatus(kind, message) {
      elements.catalogStatus.className = `status ${kind || ""}`.trim();
      elements.catalogStatus.textContent = message || "";
    }

    function closeImportPreview() {
      catalogGeneration += 1;
      catalogAbort?.abort();
      catalogAbort = null;
      catalogSelection = null;
      importProposal = null;
      importPlan = null;
      elements.importPreview.hidden = true;
      elements.importAncestorsOption.hidden = true;
      elements.importProperties.closest("label").hidden = false;
      elements.vocabularyBrowser.hidden = !selectedVocabulary;
      elements.catalogResults.hidden = Boolean(selectedVocabulary);
      elements.catalogPagination.hidden = Boolean(selectedVocabulary) || catalogTotal === 0;
      elements.confirmImport.disabled = false;
      elements.importWarning.hidden = true;
    }

    function setCatalogMode(mode) {
      catalogMode = mode === "vocabulary" ? "vocabulary" : "term";
      catalogPage = 1;
      catalogTotal = 0;
      selectedVocabulary = null;
      vocabularySnapshot = null;
      vocabularyPage = 1;
      vocabularyTotal = 0;
      selectedVocabularyTerms.clear();
      selectedCatalogCategory = "";
      closeImportPreview();
      elements.catalogResults.replaceChildren();
      elements.vocabularyBrowser.hidden = true;
      elements.catalogPagination.hidden = true;
      elements.modeTerms.classList.toggle("selected", catalogMode === "term");
      elements.modeVocabularies.classList.toggle("selected", catalogMode === "vocabulary");
      elements.modeTerms.setAttribute("aria-selected", String(catalogMode === "term"));
      elements.modeVocabularies.setAttribute("aria-selected", String(catalogMode === "vocabulary"));
      elements.catalogSearchLabel.textContent = catalogMode === "term" ? "Search terms" : "Search vocabularies";
      elements.catalogSearch.placeholder = catalogMode === "term" ? "Person, event, invoice…" : "Time, commerce, geography…";
      elements.catalogTermKind.hidden = catalogMode !== "term";
      elements.catalogCategories.hidden = catalogMode !== "vocabulary";
      if (catalogMode === "vocabulary") loadCatalogCategories();
      setCatalogStatus("", catalogMode === "term" ? "Find an individual class to import." : "Find a vocabulary, then select a bounded hierarchy from its pinned snapshot.");
    }

    async function loadCatalogCategories() {
      if (!catalog?.listCategories) return elements.catalogCategories.hidden = true;
      try {
        const result = await catalog.listCategories();
        elements.catalogCategoryList.replaceChildren(...result.items.map((category) => {
          const button = document.createElement("button");
          button.type = "button";
          button.className = `semantic-library-facet${selectedCatalogCategory === category.id ? " selected" : ""}`;
          button.textContent = `${category.label} ${category.count}`;
          button.addEventListener("click", () => {
            selectedCatalogCategory = selectedCatalogCategory === category.id ? "" : category.id;
            loadCatalogCategories();
            searchCatalog({ page: 1 });
          });
          return button;
        }));
        elements.catalogCategories.hidden = false;
      } catch (error) {
        elements.catalogCategories.hidden = true;
        setCatalogStatus("error", `Cached categories are unavailable: ${error.message}`);
      }
    }

    function openImport() {
      if (!catalog) return setStatus("error", "The external semantic catalog is unavailable.");
      elements.localBrowser.hidden = true;
      elements.filePanel.hidden = true;
      elements.historyPanel.hidden = true;
      elements.importPanel.hidden = false;
      elements.openImport.hidden = true;
      elements.openHistory.hidden = true;
      elements.openFile.hidden = true;
      setCatalogMode(catalogMode);
      setCatalogStatus("", "Remote services are used only while browsing and previewing. Imported records stay local.");
      setTimeout(() => elements.catalogSearch.focus({ preventScroll: true }), 0);
    }

    function closeImport() {
      closeImportPreview();
      elements.importPanel.hidden = true;
      elements.localBrowser.hidden = false;
      elements.openImport.hidden = false;
      elements.openHistory.hidden = false;
      elements.openFile.hidden = false;
      elements.catalogResults.replaceChildren();
      elements.vocabularyTerms.replaceChildren();
      refresh();
    }

    function setHistoryStatus(kind, message) {
      elements.historyStatus.className = `status ${kind || ""}`.trim();
      elements.historyStatus.textContent = message || "";
    }

    function historyItem(manifest) {
      const article = document.createElement("article");
      article.className = `semantic-library-history-item${manifest.status === "undone" ? " undone" : ""}`;
      article.dataset.importId = manifest.id;
      const content = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = manifest.label || manifest.requested?.id || "Vocabulary import";
      const details = document.createElement("p");
      const imported = Number(manifest.counts?.customTypes || 0) + Number(manifest.counts?.properties || 0) + Number(manifest.counts?.patterns || 0);
      const date = manifest.completedAt ? new Date(manifest.completedAt).toLocaleString() : "Unknown date";
      const removed = manifest.undo?.removed?.length || 0;
      const retained = manifest.undo?.retained?.length || 0;
      details.textContent = manifest.status === "undone"
        ? `${date} · Undone · ${removed} removed${retained ? ` · ${retained} edited record${retained === 1 ? "" : "s"} retained` : ""}`
        : `${date} · ${imported} record${imported === 1 ? "" : "s"} imported${manifest.counts?.skipped ? ` · ${manifest.counts.skipped} duplicate package entr${manifest.counts.skipped === 1 ? "y" : "ies"} skipped` : ""}`;
      content.append(title, details);
      const undo = document.createElement("button");
      undo.type = "button";
      undo.className = manifest.status === "undone" ? "secondary compact" : "secondary danger compact";
      undo.textContent = manifest.status === "undone" ? "Undone" : "Undo import";
      undo.disabled = manifest.status === "undone";
      undo.addEventListener("click", async () => {
        undo.disabled = true;
        setHistoryStatus("loading", `Undoing ${title.textContent}…`);
        try {
          const result = await service.undoImport({ id: manifest.id });
          notifyLibraryChange();
          const removedCount = result.undo?.removed?.length || 0;
          const retainedCount = result.undo?.retained?.length || 0;
          setHistoryStatus("ready", `Removed ${removedCount} unchanged imported record${removedCount === 1 ? "" : "s"}.${retainedCount ? ` Preserved ${retainedCount} record${retainedCount === 1 ? "" : "s"} edited after import.` : ""}`);
          await Promise.all([refresh(), refreshHistory({ preserveStatus: true })]);
        } catch (error) {
          undo.disabled = false;
          setHistoryStatus("error", error.message);
        }
      });
      article.append(content, undo);
      return article;
    }

    async function refreshHistory({ preserveStatus = false } = {}) {
      if (!preserveStatus) setHistoryStatus("loading", "Loading import history…");
      try {
        const result = await service.listImports({ pageSize: 100 });
        elements.historyList.replaceChildren(...result.items.map(historyItem));
        elements.historyEmpty.hidden = result.items.length > 0;
        if (!preserveStatus) setHistoryStatus("ready", `${result.total} recorded import${result.total === 1 ? "" : "s"}.`);
      } catch (error) {
        setHistoryStatus("error", error.message);
      }
    }

    function openHistory() {
      closeImportPreview();
      elements.localBrowser.hidden = true;
      elements.filePanel.hidden = true;
      elements.importPanel.hidden = true;
      elements.historyPanel.hidden = false;
      elements.openImport.hidden = true;
      elements.openHistory.hidden = true;
      elements.openFile.hidden = true;
      refreshHistory();
    }

    function closeHistory() {
      elements.historyPanel.hidden = true;
      elements.localBrowser.hidden = false;
      elements.openImport.hidden = false;
      elements.openHistory.hidden = false;
      elements.openFile.hidden = false;
      refresh();
    }

    function catalogResult(term) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "semantic-library-catalog-result";
      const body = document.createElement("span");
      const label = document.createElement("strong");
      label.textContent = `${term.prefixedName} · ${term.label}`;
      const meta = document.createElement("small");
      meta.textContent = `${term.termType === "property" ? "Property" : "Class"} · ${term.vocabulary.label || term.vocabulary.prefix} · ${(term.tags || []).join(", ") || "No source category"}`;
      body.append(label, meta);
      button.append(body);
      button.addEventListener("click", () => previewCatalogTerm(term));
      return button;
    }

    function vocabularyResult(vocabulary) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "semantic-library-catalog-result vocabulary";
      const body = document.createElement("span");
      const label = document.createElement("strong");
      label.textContent = `${vocabulary.prefix} · ${vocabulary.label}`;
      const meta = document.createElement("small");
      meta.textContent = `${(vocabulary.tags || []).join(", ") || "No source category"}${vocabulary.languages?.length ? ` · ${vocabulary.languages.slice(0, 3).join(", ")}` : ""}`;
      body.append(label, meta);
      button.append(body);
      button.addEventListener("click", () => openVocabulary(vocabulary));
      return button;
    }

    function renderCatalogPagination(result) {
      catalogTotal = result.total;
      catalogPage = result.page || catalogPage;
      const pageSize = result.pageSize || 15;
      const totalPages = Math.max(1, Math.ceil(result.total / pageSize));
      elements.catalogPagination.hidden = result.total <= pageSize;
      elements.catalogPrevious.disabled = catalogPage <= 1;
      elements.catalogNext.disabled = catalogPage >= totalPages;
      elements.catalogPage.textContent = `Page ${catalogPage} of ${totalPages}`;
    }

    async function searchCatalog({ page = 1 } = {}) {
      const query = elements.catalogSearch.value.trim();
      if (!query && catalogMode === "term") return setCatalogStatus("error", "Enter a class or property name to search LovPortal.");
      closeImportPreview();
      const ownedGeneration = ++catalogGeneration;
      catalogAbort = new AbortController();
      elements.catalogSubmit.disabled = true;
      elements.catalogResults.replaceChildren();
      catalogPage = page;
      const termKind = elements.catalogTermKind.value;
      const termTypes = termKind === "both" ? ["class", "property"] : [termKind];
      const subject = catalogMode === "term" ? `${termKind === "both" ? "terms" : `${termKind}s`}` : "vocabularies";
      setCatalogStatus("loading", query ? `Searching LovPortal for ${subject} matching “${query}”…` : `Browsing LovPortal vocabularies${selectedCatalogCategory ? " in this category" : ""}…`);
      try {
        const result = catalogMode === "term"
          ? await catalog.searchTerms({ query, types: termTypes, page, pageSize: 20, signal: catalogAbort.signal })
          : await catalog.searchVocabularies({ query, category: selectedCatalogCategory, page, pageSize: 15, signal: catalogAbort.signal });
        if (ownedGeneration !== catalogGeneration) return;
        elements.catalogResults.hidden = false;
        elements.catalogResults.replaceChildren(...result.items.map(catalogMode === "term" ? catalogResult : vocabularyResult));
        renderCatalogPagination(result);
        setCatalogStatus("ready", `${result.total}${result.capped ? "+" : ""} matching ${catalogMode === "term" ? `term${result.total === 1 ? "" : "s"}` : `vocabular${result.total === 1 ? "y" : "ies"}`}; showing ${result.items.length}. Select one to ${catalogMode === "term" ? "build an exact import preview" : "browse its versioned classes"}.`);
      } catch (error) {
        if (ownedGeneration !== catalogGeneration || error.code === "CANCELLED") return;
        setCatalogStatus("error", error.message);
      } finally {
        if (ownedGeneration === catalogGeneration) elements.catalogSubmit.disabled = false;
      }
    }

    function setVocabularyStatus(kind, message) {
      elements.vocabularyStatus.className = `status ${kind || ""}`.trim();
      elements.vocabularyStatus.textContent = message || "";
    }

    function renderVocabularySelection() {
      const count = selectedVocabularyTerms.size;
      elements.vocabularySelection.textContent = count ? `${count} class${count === 1 ? "" : "es"} selected across all viewed pages.` : "No classes selected.";
      elements.previewVocabulary.disabled = count === 0;
    }

    function vocabularyTermRow(term) {
      const label = document.createElement("label");
      label.className = "semantic-library-vocabulary-term";
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = selectedVocabularyTerms.has(term.uri);
      const body = document.createElement("span");
      const title = document.createElement("strong");
      title.textContent = `${term.prefixedName} · ${term.label}`;
      const detail = document.createElement("small");
      detail.textContent = term.parents?.length ? `${term.parents.length} declared parent${term.parents.length === 1 ? "" : "s"}` : "No declared parent in this snapshot";
      body.append(title, detail);
      label.append(checkbox, body);
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) selectedVocabularyTerms.set(term.uri, term);
        else selectedVocabularyTerms.delete(term.uri);
        renderVocabularySelection();
      });
      return label;
    }

    async function loadVocabularyPage({ page = 1 } = {}) {
      if (!selectedVocabulary) return;
      const generation = ++catalogGeneration;
      catalogAbort?.abort();
      catalogAbort = new AbortController();
      vocabularyPage = page;
      elements.vocabularySubmit.disabled = true;
      setVocabularyStatus("loading", `Reading ${selectedVocabulary.prefix} submission${vocabularySnapshot ? ` ${vocabularySnapshot.submissionId}` : ""}…`);
      try {
        const result = await catalog.browseVocabulary(selectedVocabulary, {
          query: elements.vocabularySearch.value.trim(), page, pageSize: 25, signal: catalogAbort.signal,
          ...(vocabularySnapshot ? { snapshot: vocabularySnapshot } : {})
        });
        if (generation !== catalogGeneration) return;
        vocabularySnapshot = result.snapshot;
        vocabularyTotal = result.total;
        const totalPages = Math.max(1, Math.ceil(result.total / result.pageSize));
        vocabularyPage = result.page;
        elements.vocabularyTerms.replaceChildren(...result.items.map(vocabularyTermRow));
        elements.vocabularyPrevious.disabled = vocabularyPage <= 1;
        elements.vocabularyNext.disabled = vocabularyPage >= totalPages;
        elements.vocabularyPage.textContent = `Page ${vocabularyPage} of ${totalPages}`;
        setVocabularyStatus("ready", `${result.total} class${result.total === 1 ? "" : "es"} in ${result.snapshot.acronym} submission ${result.snapshot.submissionId}; selections persist across pages.`);
        renderVocabularySelection();
      } catch (error) {
        if (generation !== catalogGeneration || error.code === "CANCELLED") return;
        elements.vocabularyTerms.replaceChildren();
        setVocabularyStatus("error", error.message);
      } finally {
        if (generation === catalogGeneration) elements.vocabularySubmit.disabled = false;
      }
    }

    async function openVocabulary(vocabulary) {
      selectedVocabulary = vocabulary;
      vocabularySnapshot = null;
      vocabularyPage = 1;
      vocabularyTotal = 0;
      selectedVocabularyTerms.clear();
      elements.catalogResults.hidden = true;
      elements.catalogPagination.hidden = true;
      elements.vocabularyBrowser.hidden = false;
      elements.vocabularyTitle.textContent = `${vocabulary.prefix} · ${vocabulary.label}`;
      elements.vocabularyDescription.textContent = vocabulary.description || "No vocabulary description was published.";
      elements.vocabularySearch.value = "";
      renderVocabularySelection();
      await loadVocabularyPage({ page: 1 });
    }

    function closeVocabulary() {
      catalogGeneration += 1;
      catalogAbort?.abort();
      catalogAbort = null;
      selectedVocabulary = null;
      vocabularySnapshot = null;
      selectedVocabularyTerms.clear();
      elements.vocabularyBrowser.hidden = true;
      elements.catalogResults.hidden = false;
      elements.catalogPagination.hidden = catalogTotal <= 15;
      setCatalogStatus("ready", "Choose a vocabulary to browse its versioned classes.");
    }

    function metaPair(label, value) {
      const term = document.createElement("dt");
      term.textContent = label;
      const detail = document.createElement("dd");
      detail.textContent = value;
      return [term, detail];
    }

    async function previewCatalogTerm(term) {
      catalogSelection = term;
      const generation = ++catalogGeneration;
      catalogAbort?.abort();
      catalogAbort = new AbortController();
      elements.catalogResults.hidden = true;
      elements.vocabularyBrowser.hidden = true;
      elements.importPreview.hidden = false;
      elements.importAncestorsOption.hidden = true;
      elements.importProperties.closest("label").hidden = term.termType === "property";
      elements.importTitle.textContent = term.prefixedName;
      elements.importDescription.textContent = "Reading the versioned ontology graph…";
      elements.importMeta.replaceChildren();
      elements.confirmImport.disabled = true;
      elements.importWarning.hidden = true;
      setCatalogStatus("loading", `Enriching ${term.prefixedName} from LovPortal…`);
      try {
        importProposal = await catalog.planTermImport(term, { includeProperties: elements.importProperties.checked, signal: catalogAbort.signal });
        if (generation !== catalogGeneration) return;
        importPlan = await service.planImport({ proposal: importProposal });
        const record = importProposal.records.customTypes[0] || importProposal.records.properties[0];
        const parents = record?.definition?.supers || [];
        elements.importTitle.textContent = `${term.prefixedName} · ${record?.label || term.label}`;
        elements.importDescription.textContent = record?.description || `No description was published for this ${term.termType}.`;
        elements.importMeta.replaceChildren(
          ...metaPair("Snapshot", `${importProposal.snapshot.acronym} submission ${importProposal.snapshot.submissionId}`),
          ...metaPair("Canonical URI", term.uri),
          ...(term.termType === "class" ? metaPair("Parent types", parents.length ? parents.join(", ") : "None declared") : []),
          ...metaPair("Will add", `${importPlan.counts.customTypes} type · ${importPlan.counts.properties} related properties`),
          ...metaPair("Package duplicates", String(importPlan.counts.skipped))
        );
        const warnings = [...(importPlan.warnings || []), ...(importPlan.collisions || []).map((collision) => `${collision.id} conflicts with a local record.`)];
        elements.importWarning.textContent = warnings.join(" ");
        elements.importWarning.hidden = warnings.length === 0;
        elements.confirmImport.disabled = importPlan.counts.collisions > 0 || (importPlan.counts.customTypes + importPlan.counts.properties === 0);
        setCatalogStatus("ready", "Preview complete. Nothing has been saved yet.");
      } catch (error) {
        if (generation !== catalogGeneration || error.code === "CANCELLED") return;
        importProposal = null;
        importPlan = null;
        elements.importDescription.textContent = "The import preview could not be completed.";
        elements.importWarning.textContent = error.message;
        elements.importWarning.hidden = false;
        setCatalogStatus("error", error.message);
      }
    }

    async function previewVocabularySelection() {
      if (!selectedVocabulary || !selectedVocabularyTerms.size) return;
      catalogSelection = { kind: "vocabulary", label: selectedVocabulary.label, id: selectedVocabulary.prefix };
      const generation = ++catalogGeneration;
      catalogAbort?.abort();
      catalogAbort = new AbortController();
      elements.vocabularyBrowser.hidden = true;
      elements.importPreview.hidden = false;
      elements.importAncestorsOption.hidden = false;
      elements.importProperties.closest("label").hidden = false;
      elements.importTitle.textContent = `${selectedVocabulary.prefix} selection`;
      elements.importDescription.textContent = "Resolving the selected hierarchy from the pinned ontology graph…";
      elements.importMeta.replaceChildren();
      elements.confirmImport.disabled = true;
      elements.importWarning.hidden = true;
      setCatalogStatus("loading", `Resolving ${selectedVocabularyTerms.size} selected ${selectedVocabulary.prefix} classes…`);
      try {
        importProposal = await catalog.planVocabularyImport(selectedVocabulary, [...selectedVocabularyTerms.values()], {
          includeAncestors: elements.importAncestors.checked,
          includeProperties: elements.importProperties.checked,
          snapshot: vocabularySnapshot,
          signal: catalogAbort.signal
        });
        if (generation !== catalogGeneration) return;
        importPlan = await service.planImport({ proposal: importProposal });
        const hierarchy = importProposal.hierarchy || { selectedCount: selectedVocabularyTerms.size, includedAncestorCount: 0 };
        elements.importTitle.textContent = `${selectedVocabulary.prefix} · ${selectedVocabulary.label}`;
        elements.importDescription.textContent = selectedVocabulary.description || "Selected classes from this vocabulary snapshot.";
        elements.importMeta.replaceChildren(
          ...metaPair("Snapshot", `${importProposal.snapshot.acronym} submission ${importProposal.snapshot.submissionId}`),
          ...metaPair("Selected", `${hierarchy.selectedCount} class${hierarchy.selectedCount === 1 ? "" : "es"}`),
          ...metaPair("Connected parents", String(hierarchy.includedAncestorCount)),
          ...metaPair("Will add", `${importPlan.counts.customTypes} types · ${importPlan.counts.properties} related properties`),
          ...metaPair("Package duplicates", String(importPlan.counts.skipped))
        );
        const warnings = [...(importPlan.warnings || []), ...(importPlan.collisions || []).map((collision) => `${collision.id} conflicts with a local record.`)];
        elements.importWarning.textContent = warnings.join(" ");
        elements.importWarning.hidden = warnings.length === 0;
        elements.confirmImport.disabled = importPlan.counts.collisions > 0 || (importPlan.counts.customTypes + importPlan.counts.properties === 0);
        setCatalogStatus("ready", "Package preview complete. Nothing has been saved yet.");
      } catch (error) {
        if (generation !== catalogGeneration || error.code === "CANCELLED") return;
        importProposal = null;
        importPlan = null;
        elements.importDescription.textContent = "The package preview could not be completed.";
        elements.importWarning.textContent = error.message;
        elements.importWarning.hidden = false;
        setCatalogStatus("error", error.message);
      }
    }

    async function confirmImport() {
      if (!importPlan) return;
      elements.confirmImport.disabled = true;
      setCatalogStatus("loading", `Importing ${importPlan.label}…`);
      try {
        const job = await service.startImport({ planId: importPlan.id });
        notifyLibraryChange();
        const importedName = catalogSelection?.label || importPlan.requested?.id || "imported type";
        closeImport();
        elements.search.value = importedName;
        await refresh();
        setStatus("ready", `Imported ${job.counts.customTypes} type${job.counts.customTypes === 1 ? "" : "s"} and ${job.counts.properties} related properties from the pinned LovPortal snapshot.`);
      } catch (error) {
        elements.confirmImport.disabled = false;
        setCatalogStatus("error", error.message);
      }
    }

    function open() {
      elements.home.hidden = false;
      refresh();
      setTimeout(() => elements.search.focus({ preventScroll: true }), 0);
    }

    function close() {
      elements.home.hidden = true;
      searchGeneration += 1;
      selectionMode = false;
      selectedTargets.clear();
      updateSelectionControls();
    }

    function rebuildImportPreview() {
      if (selectedVocabulary && selectedVocabularyTerms.size) previewVocabularySelection();
      else if (catalogSelection) previewCatalogTerm(catalogSelection);
    }

    elements.search.addEventListener("input", () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => refresh(), 120);
    });
    elements.loadMore.addEventListener("click", () => refresh({ append: true }));
    elements.clearFilters.addEventListener("click", () => {
      for (const values of Object.values(filters)) values.clear();
      refresh();
    });
    elements.selectItems.addEventListener("click", toggleSelectionMode);
    elements.clearSelection.addEventListener("click", clearMultiSelection);
    elements.exportSelected.addEventListener("click", exportMultiSelection);
    elements.savePattern.addEventListener("click", savePattern);
    elements.duplicatePattern.addEventListener("click", duplicatePattern);
    elements.deletePattern.addEventListener("click", deletePattern);
    elements.exportBundle.addEventListener("click", exportSelectedBundle);
    elements.addTag.addEventListener("click", addTag);
    elements.tagInput.addEventListener("input", () => scheduleSuggestions("tag"));
    elements.tagInput.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); addTag(); } });
    elements.addCollection.addEventListener("click", addCollection);
    elements.collectionInput.addEventListener("input", () => scheduleSuggestions("collection"));
    elements.collectionInput.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); addCollection(); } });
    elements.openImport.addEventListener("click", openImport);
    elements.openHistory.addEventListener("click", openHistory);
    elements.openFile.addEventListener("click", chooseBundleFile);
    elements.fileInput.addEventListener("change", () => {
      const file = elements.fileInput.files?.[0];
      if (file) previewBundleFile(file).catch(() => undefined);
    });
    elements.closeFile.addEventListener("click", closeFilePanel);
    elements.chooseFile.addEventListener("click", chooseBundleFile);
    elements.confirmFile.addEventListener("click", confirmFileImport);
    elements.closeImport.addEventListener("click", closeImport);
    elements.closeHistory.addEventListener("click", closeHistory);
    elements.modeTerms.addEventListener("click", () => setCatalogMode("term"));
    elements.modeVocabularies.addEventListener("click", () => setCatalogMode("vocabulary"));
    elements.catalogSubmit.addEventListener("click", searchCatalog);
    elements.catalogSearch.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); searchCatalog(); } });
    elements.catalogPrevious.addEventListener("click", () => searchCatalog({ page: Math.max(1, catalogPage - 1) }));
    elements.catalogNext.addEventListener("click", () => searchCatalog({ page: catalogPage + 1 }));
    elements.vocabularyBack.addEventListener("click", closeVocabulary);
    elements.vocabularySubmit.addEventListener("click", () => loadVocabularyPage({ page: 1 }));
    elements.vocabularySearch.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); loadVocabularyPage({ page: 1 }); } });
    elements.vocabularyPrevious.addEventListener("click", () => loadVocabularyPage({ page: Math.max(1, vocabularyPage - 1) }));
    elements.vocabularyNext.addEventListener("click", () => loadVocabularyPage({ page: vocabularyPage + 1 }));
    elements.previewVocabulary.addEventListener("click", previewVocabularySelection);
    elements.cancelPreview.addEventListener("click", closeImportPreview);
    elements.importAncestors.addEventListener("change", rebuildImportPreview);
    elements.importProperties.addEventListener("change", rebuildImportPreview);
    elements.confirmImport.addEventListener("click", confirmImport);

    return Object.freeze({ open, close, refresh, previewBundleFile, exportSelectedBundle, elements });
  }

  const api = Object.freeze({ create });
  root.Site2JsonSidebarSemanticLibrary = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
