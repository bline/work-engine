"use strict";

(function exposeEditorController(root) {
  const STEPS = ["structure", "semantics", "discover", "review", "finish"];
  const TRANSIENT_COMMANDS = new Set(["preview-highlight", "clear-preview", "preview-field-form"]);

  function deriveWorkflow(snapshot = {}) {
    const blocks = snapshot.blocks || [];
    const activeBlock = snapshot.activeBlock || null;
    const fields = activeBlock?.fields || [];
    const unresolved = fields.filter((field) => field.unresolved).length;
    const hasIdentity = fields.some((field) => field.identity);
    const semanticsReady = blocks.length > 0 && blocks.every((block) => block.compositionValid !== false && block.semanticsReviewed !== false);
    const inferenceReviewReady = Boolean(snapshot.inferenceReviewReady && blocks.length);
    const statuses = {
      structure: blocks.length ? "complete" : "current",
      semantics: semanticsReady ? "complete" : (inferenceReviewReady ? "attention" : (blocks.length ? "current" : "pending")),
      discover: semanticsReady ? (fields.length ? "complete" : "current") : (inferenceReviewReady ? "complete" : "pending"),
      review: inferenceReviewReady ? "current" : (semanticsReady && fields.length && unresolved === 0 && hasIdentity ? "complete" : (semanticsReady && fields.length ? "current" : "pending")),
      finish: snapshot.validDefinition ? "complete" : (semanticsReady && fields.length && unresolved === 0 && hasIdentity ? "current" : "pending")
    };
    const current = STEPS.find((step) => statuses[step] === "current") || (snapshot.validDefinition ? "finish" : "structure");
    return { steps: STEPS.map((id) => ({ id, status: statuses[id] })), current, unresolved };
  }

  function create({ port, now = () => Date.now(), leaseTimeout = 35_000, commandTimeout = 30_000, setTimer = setInterval, clearTimer = clearInterval } = {}) {
    let snapshot = null;
    let editor = null;
    let selectionFocus = null;
    let revision = 0;
    let commandSequence = 0;
    let pendingCommand = null;
    let lastCommandResult = null;
    let editorSource = { sessionId: null, revision: -1 };
    let lease = { owner: "sidebar", claimedAt: now(), lastSeenAt: now() };

    function stateMessage() {
      return {
        type: "controller-state",
        revision,
        lease: { owner: lease.owner },
        snapshot,
        editor,
        selectionFocus,
        pendingCommand,
        lastCommandResult,
        workflow: deriveWorkflow(snapshot || {})
      };
    }

    function publish() {
      try { port.postMessage(stateMessage()); } catch { /* The editor host may be closing. */ }
    }

    function claim(owner) {
      if (owner !== "sidebar" && owner !== "expanded") return;
      lease = { owner, claimedAt: now(), lastSeenAt: now() };
      revision += 1;
      publish();
    }

    function receive(message) {
      if (message?.type === "table-snapshot") {
        snapshot = { ...message.snapshot, validDefinition: Boolean(message.validDefinition) };
        revision += 1;
        publish();
      } else if (message?.type === "editor-snapshot") {
        const sessionId = String(message.sessionId || "legacy");
        const sourceRevision = Number(message.revision);
        if (editorSource.sessionId !== sessionId || (Number.isInteger(sourceRevision) && sourceRevision >= editorSource.revision)) {
          editorSource = { sessionId, revision: Number.isInteger(sourceRevision) ? sourceRevision : editorSource.revision + 1 };
          editor = message.editor || null;
          revision += 1;
          publish();
        }
      } else if (message?.type === "selection-focus") {
        selectionFocus = message.focus || null;
        revision += 1;
        publish();
      } else if (message?.type === "surface-connected" && message.surface === "expanded") {
        claim("expanded");
      } else if (message?.type === "surface-disconnected" && message.surface === "expanded") {
        if (lease.owner === "expanded") claim("sidebar");
      } else if (message?.type === "surface-disconnected" && message.surface === "sidebar") {
        if (pendingCommand) {
          lastCommandResult = { id: pendingCommand.id, ok: false, error: "The Elements editor disconnected before the action completed." };
          pendingCommand = null;
          revision += 1;
          publish();
        }
      } else if (message?.type === "lease-command") {
        claim(message.owner);
      } else if (message?.type === "editor-command") {
        const expectedSurface = lease.owner === "expanded" ? "expanded" : "sidebar";
        if (message.sourceSurface !== expectedSurface || !message.command?.action) {
          port.postMessage({
            type: "command-rejected",
            reason: message.sourceSurface !== expectedSurface ? "inactive-surface" : "invalid-command"
          });
          return;
        }
        if (TRANSIENT_COMMANDS.has(message.command.action)) {
          port.postMessage({ type: "execute-command", commandId: `transient:${++commandSequence}`, command: message.command });
          return;
        }
        if (pendingCommand) {
          port.postMessage({ type: "command-rejected", reason: "command-pending" });
          return;
        }
        pendingCommand = {
          id: `${revision + 1}:${++commandSequence}`,
          action: message.command.action,
          sourceSurface: message.sourceSurface,
          startedAt: now()
        };
        lastCommandResult = null;
        revision += 1;
        publish();
        port.postMessage({ type: "execute-command", commandId: pendingCommand.id, command: message.command });
      } else if (message?.type === "command-result" && message.commandId === pendingCommand?.id) {
        lastCommandResult = { id: message.commandId, ok: Boolean(message.ok), error: message.error || null };
        pendingCommand = null;
        revision += 1;
        publish();
      } else if (message?.type === "workspace-heartbeat" && lease.owner === "expanded") {
        lease.lastSeenAt = now();
      } else if (message?.type === "controller-request-state") {
        publish();
      }
    }

    port.onMessage.addListener(receive);
    const timer = setTimer(() => {
      if (lease.owner === "expanded" && now() - lease.lastSeenAt > leaseTimeout) claim("sidebar");
      if (pendingCommand && now() - pendingCommand.startedAt > commandTimeout) {
        lastCommandResult = { id: pendingCommand.id, ok: false, error: "The editor action timed out." };
        pendingCommand = null;
        revision += 1;
        publish();
      }
    }, Math.min(5_000, leaseTimeout, commandTimeout));
    publish();

    return {
      receive,
      snapshot: stateMessage,
      dispose() { clearTimer(timer); try { port.disconnect?.(); } catch { /* Already disconnected. */ } }
    };
  }

  const api = { STEPS, TRANSIENT_COMMANDS, deriveWorkflow, create };
  root.Site2JsonEditorController = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
