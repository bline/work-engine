(function initializeSchemaTypeIcons(root, factory) {
  "use strict";
  const mappings = root.Site2JsonSchemaTypeIconMappings || (typeof require === "function" ? require("./schema-type-icons.generated") : null);
  const catalog = root.Site2JsonSchemaCatalog || (typeof require === "function" ? require("./schema-catalog.generated") : null);
  const api = factory(mappings, catalog);
  root.Site2JsonSchemaTypeIcons = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function schemaTypeIconsFactory(mappings, catalog) {
  "use strict";

  if (!mappings?.Thing || !catalog?.classes) throw new Error("The generated Schema.org icon map or catalog is unavailable.");

  const PRIORITY = Object.freeze({
    Thing: -100,
    CreativeWork: 10,
    Organization: 10,
    LocalBusiness: 20,
    Place: 10,
    Action: 10,
    Event: 10,
    Product: 10
  });
  const cache = new Map();

  function normalizeType(type) {
    const source = String(type || "").trim();
    const schemaMatch = source.match(/^(?:https?:\/\/schema\.org\/|schema:)([^/#]+)$/i);
    if (schemaMatch) return schemaMatch[1];
    return /^[A-Za-z][A-Za-z0-9]*$/.test(source) ? source : null;
  }

  function resolution(type) {
    const normalized = normalizeType(type);
    if (!normalized || !catalog.classes[normalized]) {
      return Object.freeze({ requestedType: String(type || ""), matchedType: "Thing", icon: mappings.Thing, distance: null, source: "fallback" });
    }
    if (cache.has(normalized)) return cache.get(normalized);
    const visited = new Set([normalized]);
    let frontier = [normalized];
    let distance = 0;
    while (frontier.length) {
      const matched = frontier.filter((candidate) => mappings[candidate]).sort((left, right) => (
        (PRIORITY[right] || 0) - (PRIORITY[left] || 0) || left.localeCompare(right)
      ));
      if (matched.length) {
        const matchedType = matched[0];
        const answer = Object.freeze({
          requestedType: normalized,
          matchedType,
          icon: mappings[matchedType],
          distance,
          source: distance === 0 ? "explicit" : "inherited"
        });
        cache.set(normalized, answer);
        return answer;
      }
      const next = [];
      for (const candidate of frontier) {
        for (const parent of catalog.classes[candidate]?.supers || []) {
          if (!visited.has(parent)) { visited.add(parent); next.push(parent); }
        }
      }
      frontier = next;
      distance += 1;
    }
    const fallback = Object.freeze({ requestedType: normalized, matchedType: "Thing", icon: mappings.Thing, distance: null, source: "fallback" });
    cache.set(normalized, fallback);
    return fallback;
  }

  function spriteHref(type, prefix = "../vendor/fontawesome-solid.svg") {
    return `${prefix}#${resolution(type).icon}`;
  }

  function createIcon(document, type, { className = "schema-type-icon", spritePrefix = "../vendor/fontawesome-solid.svg" } = {}) {
    const result = resolution(type);
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
    svg.setAttribute("class", className);
    svg.setAttribute("aria-hidden", "true");
    svg.dataset.iconSource = result.source;
    svg.dataset.iconType = result.matchedType;
    use.setAttribute("href", `${spritePrefix}#${result.icon}`);
    svg.append(use);
    return svg;
  }

  return Object.freeze({ mappings, normalizeType, resolution, spriteHref, createIcon });
});
