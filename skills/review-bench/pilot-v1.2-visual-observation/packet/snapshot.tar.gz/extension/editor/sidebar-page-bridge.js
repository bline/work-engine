"use strict";

(function exposeSidebarPageBridge(root) {
  // These functions are serialized and evaluated in the inspected page. They
  // must remain self-contained and may use only page globals and packaged
  // Site2Json* globals injected by bridge.js.
  function bridgeReadSelection() {
    "use strict";
    try {
      const el = typeof $0 !== "undefined" && $0 ? $0 : (globalThis.__site2jsonSelectedElement || null);
      if (!el) return { ok: false, reason: "no-selection", pageUrl: location.href };
      return { ok: true, summary: Site2JsonSelectorCandidates.summarizeElement(el), href: typeof el.getAttribute === "function" ? el.getAttribute("href") : null, pageUrl: location.href, shadowBoundary: Site2JsonSelectorCandidates.shadowBoundary(el) };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeInferScope(args) {
    "use strict";
    try {
      const el = typeof $0 !== "undefined" && $0 ? $0 : (globalThis.__site2jsonSelectedElement || null);
      if (!el) return { ok: false, reason: "no-selection" };
      const shadowBoundary = Site2JsonSelectorCandidates.shadowBoundary(el);
      if (shadowBoundary) return { ok: false, reason: "shadow-boundary", shadowBoundary };
      const result = args?.allowSingle === true
        ? Site2JsonEvidenceScope.findSingleton(document, { selectedElement: el, candidateLimit: 10, includeObservations: false })
        : Site2JsonScopeInference.inferRepeatingScope(el, document);
      const levels = result.levels.map((level) => ({ depth: level.depth, tag: level.tagName, best: level.best ? { selector: level.best.selector, kind: level.best.kind, matchCount: level.best.matchCount, siblingMatchCount: level.best.siblingMatchCount, parentCount: level.best.parentCount, findings: level.best.findings, note: level.best.note } : null }));
      return { ok: true, mode: result.mode, picked: Site2JsonSelectorCandidates.summarizeElement(el), levels, chosen: result.chosen };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeFindEvidenceScopes() {
    "use strict";
    try {
      const started = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      const result = Site2JsonEvidenceScope.find(document, { candidateLimit: 8 });
      const finished = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      return { ...result, pageUrl: location.href, durationMs: Math.round((finished - started) * 10) / 10 };
    }
    catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgePageAnalysisContext() {
    "use strict";
    try {
      const key = "__site2jsonPageAnalysisContext";
      let state = globalThis[key];
      if (!state || state.document !== document) {
        state?.observer?.disconnect?.();
        state = { document, revision: 0, observer: null };
        const belongsToSite2Json = (node) => {
          const element = node?.nodeType === 1 ? node : node?.parentElement;
          return Boolean(element?.closest?.("#__site2json-page-highlights, [id^='__site2json-highlight-']"));
        };
        state.observer = new MutationObserver((records) => {
          const relevant = records.some((record) => {
            if (belongsToSite2Json(record.target)) return false;
            const changed = [...(record.addedNodes || []), ...(record.removedNodes || [])];
            return !changed.length || changed.some((node) => !belongsToSite2Json(node));
          });
          if (relevant) state.revision += 1;
        });
        state.observer.observe(document, { attributes: true, childList: true, characterData: true, subtree: true });
        globalThis[key] = state;
      }
      return { ok: true, pageUrl: location.href, frameUrl: location.href, revision: state.revision };
    } catch (error) {
      return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) };
    }
  }

  function bridgeHighlightSelector(args) {
    "use strict";
    try {
      const channel = args.channel === "pinned" ? "pinned" : "transient";
      window.__site2jsonHighlightTokens ||= { transient: 0, pinned: 0 };
      if (Number.isSafeInteger(args.token) && args.token < window.__site2jsonHighlightTokens[channel]) return { ok: true, stale: true, matchCount: 0, shown: 0 };
      if (Number.isSafeInteger(args.token)) window.__site2jsonHighlightTokens[channel] = args.token;
      if (globalThis.Site2JsonPageHighlighter) {
        return globalThis.Site2JsonPageHighlighter.setGroup({
          id: channel,
          selector: args.selector,
          withinSelector: args.withinSelector,
          rootIndex: args.rootIndex,
          matchIndex: args.matchIndex,
          color: channel === "pinned" ? "blue" : "green",
          numbered: true
        });
      }
      window.__site2jsonHighlightCleanups ||= {};
      if (typeof window.__site2jsonHighlightCleanups[channel] === "function") window.__site2jsonHighlightCleanups[channel]();
      let roots = args.withinSelector ? Array.from(document.querySelectorAll(args.withinSelector)) : [document];
      if (Number.isSafeInteger(args.rootIndex)) roots = roots[args.rootIndex] ? [roots[args.rootIndex]] : [];
      let matches = args.withinSelector ? roots.flatMap((scope) => args.selector ? Array.from(scope.querySelectorAll(args.selector)) : [scope]) : Array.from(document.querySelectorAll(args.selector));
      matches = Array.from(new Set(matches));
      if (Number.isSafeInteger(args.matchIndex)) matches = matches[args.matchIndex] ? [matches[args.matchIndex]] : [];
      const host = document.createElement("div");
      host.id = `__site2json-highlight-${channel}`;
      Object.assign(host.style, { position: "fixed", inset: "0", pointerEvents: "none", zIndex: channel === "pinned" ? "2147483645" : "2147483647" });
      const shadow = host.attachShadow({ mode: "closed" });
      const style = document.createElement("style");
      const border = channel === "pinned" ? "#2463a7" : "#18a558";
      const fill = channel === "pinned" ? "rgba(36,99,167,.12)" : "rgba(24,165,88,.12)";
      style.textContent = `.box{position:fixed;box-sizing:border-box;border:2px solid ${border};background:${fill};border-radius:3px;box-shadow:0 0 0 1px rgba(255,255,255,.8) inset}.badge{position:absolute;left:-2px;top:-18px;padding:1px 4px;border-radius:3px 3px 0 0;background:${border};color:#fff;font:10px/16px system-ui,sans-serif}`;
      shadow.append(style);
      document.documentElement.append(host);
      function draw() {
        for (const box of Array.from(shadow.querySelectorAll(".box"))) box.remove();
        matches.slice(0, 200).forEach((node, index) => {
          const rect = node.getBoundingClientRect();
          if (rect.width <= 0 || rect.height <= 0 || rect.bottom < 0 || rect.top > window.innerHeight) return;
          const box = document.createElement("div");
          box.className = "box";
          Object.assign(box.style, { left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px` });
          const badge = document.createElement("span");
          badge.className = "badge";
          badge.textContent = String(index + 1);
          box.append(badge);
          shadow.append(box);
        });
      }
      const refresh = () => { window.requestAnimationFrame(draw); };
      window.addEventListener("scroll", refresh, true);
      window.addEventListener("resize", refresh);
      window.__site2jsonHighlightCleanups[channel] = () => { window.removeEventListener("scroll", refresh, true); window.removeEventListener("resize", refresh); host.remove(); delete window.__site2jsonHighlightCleanups[channel]; };
      draw();
      return { ok: true, matchCount: matches.length, shown: Math.min(matches.length, 200) };
    } catch (error) { return { ok: false, message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeRevealTarget(args) {
    "use strict";
    try {
      function matchesWithin(scope, selector) {
        if (!selector) return [scope];
        if (!selector.startsWith("xpath:")) return Array.from(scope.querySelectorAll(selector));
        const expression = selector.slice("xpath:".length);
        if (!expression) return [];
        const scopedExpression = expression.startsWith("//") ? `.${expression}` : expression;
        const result = document.evaluate(scopedExpression, scope, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        return Array.from({ length: result.snapshotLength }, (_item, index) => result.snapshotItem(index));
      }
      let roots = args.withinSelector ? Array.from(document.querySelectorAll(args.withinSelector)) : [document];
      if (Number.isSafeInteger(args.rootIndex)) roots = roots[args.rootIndex] ? [roots[args.rootIndex]] : [];
      let matches = args.withinSelector ? roots.flatMap((scope) => matchesWithin(scope, args.selector)) : matchesWithin(document, args.selector);
      matches = Array.from(new Set(matches));
      const index = Number.isSafeInteger(args.matchIndex) ? args.matchIndex : 0;
      const node = matches[index] || null;
      if (!node) return { ok: false, reason: "no-match" };
      if (args.scrollIntoView && typeof node.scrollIntoView === "function") node.scrollIntoView({ behavior: "auto", block: "center", inline: "nearest" });
      if (typeof inspect === "function") inspect(node);
      return { ok: true, matchCount: matches.length, revealedIndex: index };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeClearHighlights(args) {
    "use strict";
    if (args?.channel) {
      window.__site2jsonHighlightTokens ||= { transient: 0, pinned: 0 };
      if (Number.isSafeInteger(args.token) && args.token < window.__site2jsonHighlightTokens[args.channel]) return { ok: true, stale: true };
      if (Number.isSafeInteger(args.token)) window.__site2jsonHighlightTokens[args.channel] = args.token;
    }
    if (globalThis.Site2JsonPageHighlighter) {
      if (args?.channel) globalThis.Site2JsonPageHighlighter.clearGroup(args.channel);
      else globalThis.Site2JsonPageHighlighter.clearAll();
      return { ok: true };
    }
    const cleanups = window.__site2jsonHighlightCleanups || {};
    if (args?.channel) {
      if (typeof cleanups[args.channel] === "function") cleanups[args.channel]();
    } else for (const cleanup of Object.values(cleanups)) if (typeof cleanup === "function") cleanup();
    return { ok: true };
  }

  function bridgeAcceptScope(args) {
    "use strict";
    try {
      const matches = Array.from(document.querySelectorAll(args.selector));
      if (!matches.length) return { ok: false, reason: "no-match" };
      window.__site2jsonScopeSelector = args.selector;
      window.__site2jsonScopeRoot = matches[0];
      return { ok: true, matchCount: matches.length, sample: Site2JsonSelectorCandidates.summarizeElement(matches[0]), pageUrl: location.href };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeAddFieldCandidate() {
    "use strict";
    try {
      const el = typeof $0 !== "undefined" && $0 ? $0 : (globalThis.__site2jsonSelectedElement || null);
      const scopeSelector = window.__site2jsonScopeSelector || null;
      if (!scopeSelector) return { ok: false, reason: "no-scope" };
      if (!el) return { ok: false, reason: "no-selection" };
      const shadowBoundary = Site2JsonSelectorCandidates.shadowBoundary(el);
      if (shadowBoundary) return { ok: false, reason: "shadow-boundary", shadowBoundary };
      const scopeRoot = typeof el.closest === "function" ? el.closest(scopeSelector) : null;
      if (!scopeRoot) return { ok: false, reason: "outside-scope" };
      if (scopeRoot === el) return { ok: false, reason: "is-scope-root" };
      const candidates = Site2JsonSelectorCandidates.generateScopedCandidates(el, scopeRoot, document);
      const context = [];
      for (let current = el.parentElement, depth = 0; current && current !== scopeRoot && depth < 4; current = current.parentElement, depth += 1) context.push(`${current.tagName.toLowerCase()} ${Site2JsonSelectorCandidates.stableId(current)} ${Site2JsonSelectorCandidates.stableClassNames(current).join(" ")}`.trim());
      return { ok: true, element: { ...Site2JsonSelectorCandidates.summarizeElement(el), id: Site2JsonSelectorCandidates.stableId(el) || null, classes: Site2JsonSelectorCandidates.stableClassNames(el), context: context.join(" ") }, href: typeof el.getAttribute === "function" ? el.getAttribute("href") : null, src: typeof el.getAttribute === "function" ? el.getAttribute("src") : null, candidates: candidates.map((candidate) => ({ selector: candidate.selector, kind: candidate.kind, matchCount: candidate.matchCount, unique: candidate.unique, note: candidate.note })) };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeLocateSelection(args) {
    "use strict";
    try {
      const selected = typeof $0 !== "undefined" && $0 ? $0 : (globalThis.__site2jsonSelectedElement || null);
      if (!selected) return { ok: false, reason: "no-selection" };
      const summary = Site2JsonSelectorCandidates.summarizeElement(selected);
      function matchesWithin(scope, selector) {
        if (!selector) return [];
        if (!selector.startsWith("xpath:")) return Array.from(scope.querySelectorAll(selector));
        const expression = selector.slice("xpath:".length);
        if (!expression) return [];
        const scoped = expression.startsWith("//") ? `.${expression}` : expression;
        const result = document.evaluate(scoped, scope, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        return Array.from({ length: result.snapshotLength }, (_item, index) => result.snapshotItem(index));
      }
      for (const block of args.blocks || []) {
        const roots = Array.from(document.querySelectorAll(block.scope));
        const rootIndex = roots.findIndex((scope) => scope === selected || scope.contains(selected));
        if (rootIndex < 0) continue;
        const scope = roots[rootIndex];
        const fieldMatches = [];
        for (const field of block.fields || []) {
          const nodes = matchesWithin(scope, field.selector);
          let mode = null;
          let matchIndex = nodes.findIndex((node) => node === selected);
          if (matchIndex >= 0) mode = "exact";
          if (!mode) { matchIndex = nodes.findIndex((node) => typeof node.contains === "function" && node.contains(selected)); if (matchIndex >= 0) mode = "inside-field"; }
          if (!mode) { matchIndex = nodes.findIndex((node) => typeof selected.contains === "function" && selected.contains(node)); if (matchIndex >= 0) mode = "contains-field"; }
          if (mode) fieldMatches.push({ key: field.key, mode, matchIndex });
        }
        const modeRank = { exact: 0, "inside-field": 1, "contains-field": 2 };
        fieldMatches.sort((left, right) => modeRank[left.mode] - modeRank[right.mode]);
        return { ok: true, blockId: block.id, rootIndex, isScopeRoot: scope === selected, fieldMatches, selected: summary };
      }
      return { ok: false, reason: "outside-scope", selected: summary };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeDiscoverFields(args) {
    "use strict";
    try {
      if (!args.variantTarget || !args.variants?.candidates?.length) return Site2JsonFieldDiscovery.discover(document, args.scopeSelector, { sampleLimit: 100, elementLimit: 400 });
      const allScopes = Array.from(document.querySelectorAll(args.scopeSelector));
      if (!allScopes.length) return { ok: false, reason: "no-scope" };
      function present(value) { return value !== null && value !== undefined && value !== "" && (!Array.isArray(value) || value.length > 0); }
      function selectorMatched(scope, rule) {
        const matches = [...(rule.selector === ":scope" || scope.matches(rule.selector) ? [scope] : []), ...scope.querySelectorAll(rule.selector)];
        return rule.attribute ? matches.some((node) => node.getAttribute(rule.attribute) === rule.equals) : matches.length > 0;
      }
      function fieldMatched(scope, candidate, name) {
        const field = name === "canonicalUrl"
          ? (candidate.identity || (candidate.fields || []).find((item) => item.name === candidate.identityField))
          : (candidate.fields || []).find((item) => item.name === name);
        if (!field) return false;
        const selector = field.attribute ? `${field.selector}@${field.attribute}` : field.selector;
        const binding = field.source ? { source: field.source, transform: field.transform } : { selectors: [selector], transform: field.transform };
        return present(Site2JsonDsl.extractBinding(scope, { ...binding, ...(field.multiple ? { multiple: true } : {}) }, { pageUrl: location.href }));
      }
      function selectedEntity(scope) {
        const ranked = args.variants.candidates.map((candidate) => ({
          entityName: candidate.entityName,
          score: candidate.evidence.reduce((score, rule) => score + ((rule.selector ? selectorMatched(scope, rule) : fieldMatched(scope, candidate, rule.field)) ? rule.weight : 0), 0)
        })).sort((left, right) => right.score - left.score || left.entityName.localeCompare(right.entityName));
        const first = ranked[0];
        const margin = first ? first.score - (ranked[1]?.score || 0) : 0;
        return first && first.score >= args.variants.minScore && margin >= args.variants.minMargin ? first.entityName : args.fallbackEntity;
      }
      const scopes = allScopes.filter((scope) => selectedEntity(scope) === args.variantTarget);
      if (!scopes.length) return { ok: false, reason: "no-variant-scopes", totalScopes: 0, blockTotalScopes: allScopes.length };
      return { ...Site2JsonFieldDiscovery.discoverFromScopes(document, scopes, { sampleLimit: 100, elementLimit: 400 }), blockTotalScopes: allScopes.length };
    }
    catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeDiscoverVariantItems(args) {
    "use strict";
    try {
      const started = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      const result = Site2JsonFieldDiscovery.discoverItems(document, args.scopeSelector, {
        itemLimit: Number.isSafeInteger(args.itemLimit) ? args.itemLimit : 50,
        elementLimit: Number.isSafeInteger(args.elementLimit) ? args.elementLimit : 400,
        fast: args.fast === true
      });
      const finished = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      return { ...result, durationMs: Math.round((finished - started) * 10) / 10 };
    }
    catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeCaptureVariantEvidence(args) {
    "use strict";
    try {
      const el = typeof $0 !== "undefined" && $0 ? $0 : (globalThis.__site2jsonSelectedElement || null);
      if (!el) return { ok: false, reason: "no-selection", message: "Select an element that identifies this result type." };
      const scope = typeof el.closest === "function" ? el.closest(args.scopeSelector) : null;
      if (!scope) return { ok: false, reason: "outside-scope", message: "The selected element is outside this extraction block." };
      if (Number.isSafeInteger(args.rootIndex)) {
        const scopes = Array.from(document.querySelectorAll(args.scopeSelector));
        if (scopes[args.rootIndex] !== scope) return { ok: false, reason: "wrong-item", message: `Select identifying evidence inside result ${args.rootIndex + 1}.` };
      }
      const candidates = scope === el ? [] : Site2JsonSelectorCandidates.generateScopedCandidates(el, scope, document);
      const selector = scope === el ? ":scope" : (candidates.find((candidate) => candidate.kind !== "fallback") || candidates[0])?.selector;
      if (!selector) return { ok: false, reason: "no-selector", message: "A stable selector could not be derived from this element." };
      const attributes = Array.from(el.attributes || [])
        .filter((attribute) => attribute.value && attribute.value.length <= 128)
        .map((attribute) => ({ name: attribute.name, value: attribute.value }));
      const preferred = [
        ...attributes.filter((attribute) => attribute.name.startsWith("data-") && /(type|kind|entity|category|role)/i.test(attribute.name)),
        ...attributes.filter((attribute) => ["itemtype", "role", "aria-label", "alt", "title"].includes(attribute.name))
      ][0] || null;
      const rule = preferred
        ? { selector, attribute: preferred.name, equals: preferred.value, weight: 10 }
        : { selector, weight: 10 };
      return {
        ok: true,
        rule,
        label: preferred ? `${selector} where ${preferred.name} equals “${preferred.value}”` : `${selector} is present`,
        element: Site2JsonSelectorCandidates.summarizeElement(el)
      };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeClassifyVariantItems(args) {
    "use strict";
    try {
      const scopes = Array.from(document.querySelectorAll(args.scopeSelector));
      const candidates = args.variants?.candidates || [];
      const indexedCandidates = candidates.map((candidate) => ({
        ...candidate,
        fieldMap: new Map((candidate.fields || []).map((field) => [field.name, field]))
      }));
      function valueFor(scope, field) {
        if (!field) return null;
        const selector = field.attribute ? `${field.selector}@${field.attribute}` : field.selector;
        const transform = field.transform || (field.kind === "url" ? ["absoluteUrl", "stripQuery"] : ["text", "trim"]);
        const binding = field.source ? { source: field.source, transform } : { selectors: [selector], transform };
        return Site2JsonDsl.extractBinding(scope, { ...binding, ...(field.multiple ? { multiple: true } : {}) }, { pageUrl: location.href });
      }
      function present(value) {
        return value !== null && value !== undefined && value !== "" && (!Array.isArray(value) || value.length > 0);
      }
      function rulePresent(scope, candidate, rule) {
        if (rule.selector) {
          const matches = [...(rule.selector === ":scope" || scope.matches(rule.selector) ? [scope] : []), ...scope.querySelectorAll(rule.selector)];
          return rule.attribute ? matches.some((node) => node.getAttribute(rule.attribute) === rule.equals) : matches.length > 0;
        }
        const field = rule.field === "canonicalUrl"
          ? (candidate.identity || candidate.fieldMap.get(candidate.identityField))
          : candidate.fieldMap.get(rule.field);
        return present(valueFor(scope, field));
      }
      const rows = scopes.slice(0, 200).map((scope, index) => {
        const report = Site2JsonVariantClassifier.classify(indexedCandidates.map((candidate) => ({
          entityName: candidate.entityName,
          schemaType: candidate.schemaType,
          selected: candidate.entityName,
          signals: (candidate.signals || []).map((signal) => {
            const field = candidate.fieldMap.get(signal.field);
            return { ...signal, matched: present(valueFor(scope, field)) };
          }),
          evidence: (candidate.evidence || []).map((rule) => ({ ...rule, matched: rulePresent(scope, candidate, rule) }))
        })), args.variants || {});
        const first = report.winner ? {
          entityName: report.winner.entityName,
          schemaType: report.winner.schemaType,
          score: report.winner.score,
          shapeScore: report.winner.shapeScore,
          evidenceScore: report.winner.evidenceScore
        } : null;
        const margin = report.margin;
        const ambiguous = report.reason === "ambiguous";
        const classified = report.accepted;
        const text = String(scope.innerText || scope.textContent || "").replace(/\s+/g, " ").trim().slice(0, 120);
        return {
          index,
          label: text || `${scope.tagName.toLowerCase()} result`,
          status: ambiguous ? "ambiguous" : classified ? "classified" : "unclassified",
          winner: classified ? { ...first, margin } : null,
          fallback: { entityName: args.fallbackEntity, schemaType: args.schemaType },
          alternatives: report.candidates.slice(0, 3).map((candidate) => {
            return { entityName: candidate.entityName || candidate.selected, schemaType: candidate.schemaType, score: candidate.score, shapeScore: candidate.shapeScore, evidenceScore: candidate.evidenceScore, margin: candidate.selected === first?.entityName ? margin : undefined };
          }),
          classification: report
        };
      });
      const countMap = new Map([[args.fallbackEntity, { entityName: args.fallbackEntity, schemaType: args.schemaType, count: 0, fallback: true }]]);
      for (const candidate of candidates) countMap.set(candidate.entityName, { entityName: candidate.entityName, schemaType: candidate.schemaType, count: 0, fallback: false });
      for (const row of rows) {
        const entityName = row.winner?.entityName || args.fallbackEntity;
        const count = countMap.get(entityName);
        if (count) count.count += 1;
      }
      return {
        ok: true,
        total: scopes.length,
        sampled: rows.length,
        counts: Array.from(countMap.values()),
        ambiguousCount: rows.filter((row) => row.status === "ambiguous").length,
        unclassifiedCount: rows.filter((row) => row.status === "unclassified").length,
        rows
      };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeClassifyNestedVariantSlots(args) {
    "use strict";
    try {
      const scopes = Array.from(document.querySelectorAll(args.scopeSelector)).slice(0, 200);
      const slots = (args.slots || []).slice(0, 16).map((entry) => {
        const { slot, definition } = entry.runtime;
        const rows = scopes.map((scope, rootIndex) => {
          const result = Site2JsonDsl.classifyVariant(scope, slot, definition, { pageUrl: location.href });
          const report = result.classification;
          const label = String(scope.innerText || scope.textContent || "").replace(/\s+/g, " ").trim().slice(0, 120);
          return {
            rootIndex,
            slotPath: slot.path,
            label: label || `result ${rootIndex + 1}`,
            status: report?.reason === "ambiguous" ? "ambiguous" : report?.accepted ? "classified" : "unclassified",
            winner: report?.accepted ? {
              entityName: result.selected,
              schemaType: definition.entities[result.selected]?.schemaType,
              score: result.score,
              margin: result.margin,
              shapeScore: report.winner?.shapeScore || 0,
              evidenceScore: report.winner?.evidenceScore || 0
            } : null,
            fallback: { entityName: slot.fallback, schemaType: definition.entities[slot.fallback]?.schemaType },
            alternatives: (report?.candidates || []).slice(0, 5).map((candidate) => ({
              ...candidate,
              entityName: candidate.entityName || candidate.selected,
              schemaType: definition.entities[candidate.entityName || candidate.selected]?.schemaType
            })),
            classification: report
          };
        });
        const counts = new Map([[slot.fallback, { entityName: slot.fallback, schemaType: definition.entities[slot.fallback]?.schemaType, count: 0, fallback: true }]]);
        for (const candidate of slot.candidates) counts.set(candidate.entity, { entityName: candidate.entity, schemaType: definition.entities[candidate.entity]?.schemaType, count: 0, fallback: false });
        for (const row of rows) counts.get(row.winner?.entityName || slot.fallback).count += 1;
        return {
          path: slot.path,
          nodeAlias: entry.nodeAlias || null,
          sampled: rows.length,
          total: scopes.length,
          ambiguousCount: rows.filter((row) => row.status === "ambiguous").length,
          unclassifiedCount: rows.filter((row) => row.status === "unclassified").length,
          counts: Array.from(counts.values()),
          rows
        };
      });
      return { ok: true, sampled: scopes.length, total: scopes.length, slots };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgePreviewField(args) {
    "use strict";
    try {
      const scopeSelector = window.__site2jsonScopeSelector;
      if (!scopeSelector) return { ok: false, reason: "no-scope" };
      const allScopes = Array.from(document.querySelectorAll(scopeSelector));
      const scopes = Array.isArray(args.rootIndexes)
        ? args.rootIndexes.map((index) => allScopes[index]).filter(Boolean)
        : allScopes;
      const declaredSelector = args.attribute ? `${args.selector}@${args.attribute}` : args.selector;
      const binding = args.source
        ? { source: args.source, transform: args.transform, ...(args.multiple ? { multiple: true } : {}) }
        : { selectors: [declaredSelector], transform: args.transform, ...(args.multiple ? { multiple: true } : {}) };
      let present = 0;
      const values = [];
      const matchCounts = [];
      for (const scope of scopes.slice(0, 5)) {
        matchCounts.push(args.source ? 1 : scope.querySelectorAll(args.selector).length);
        const value = Site2JsonDsl.extractBinding(scope, binding, { pageUrl: location.href });
        if (value !== null && value !== undefined && (!Array.isArray(value) || value.length > 0)) present += 1;
        values.push(value);
      }
      return { ok: true, values, matchCounts, coverage: { present, sampled: Math.min(scopes.length, 5), total: scopes.length } };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeBuildBlockTable(args) {
    "use strict";
    try {
      const scopes = Array.from(document.querySelectorAll(args.scopeSelector));
      function valueFor(scope, field) {
        const selector = field.attribute ? `${field.selector}@${field.attribute}` : field.selector;
        const transform = field.transform || (field.kind === "url" ? ["absoluteUrl", "stripQuery"] : ["text", "trim"]);
        const binding = field.source ? { source: field.source, transform } : { selectors: [selector], transform };
        return Site2JsonDsl.extractBinding(scope, { ...binding, ...(field.multiple ? { multiple: true } : {}) }, { pageUrl: location.href });
      }
      function present(value) {
        return value !== null && value !== undefined && value !== "" && (!Array.isArray(value) || value.length > 0);
      }
      function classify(scope, values) {
        if (!args.variants?.candidates?.length) return null;
        const ranked = args.variants.candidates.map((candidate) => ({
          entityName: candidate.entityName,
          schemaType: candidate.schemaType,
          score: candidate.evidence.reduce((score, rule) => {
            if (rule.selector) {
              const matches = [...(rule.selector === ":scope" || scope.matches(rule.selector) ? [scope] : []), ...scope.querySelectorAll(rule.selector)];
              const matched = rule.attribute ? matches.some((node) => node.getAttribute(rule.attribute) === rule.equals) : matches.length > 0;
              return score + (matched ? rule.weight : 0);
            }
            const evidenceField = rule.field === "canonicalUrl"
              ? (candidate.identity || (candidate.fields || []).find((field) => field.name === candidate.identityField))
              : (candidate.fields || []).find((field) => field.name === rule.field);
            return score + (evidenceField && present(valueFor(scope, evidenceField)) ? rule.weight : 0);
          }, 0)
        })).sort((left, right) => right.score - left.score || left.schemaType.localeCompare(right.schemaType));
        const first = ranked[0] || null;
        const margin = first ? first.score - (ranked[1]?.score || 0) : 0;
        const selected = first && first.score >= args.variants.minScore && margin >= args.variants.minMargin;
        return {
          winner: { entityName: selected ? first.entityName : args.fallbackEntity, schemaType: selected ? first.schemaType : args.schemaType, score: selected ? first.score : 0, margin },
          ambiguous: Boolean(first && first.score >= args.variants.minScore && margin < args.variants.minMargin),
          alternatives: ranked.slice(0, 3)
        };
      }
      const columns = args.fields.map((field) => ({ ...field, identity: Boolean(field.identity || field.name === args.identityField) }));
      const rows = scopes.map((scope, index) => {
        const values = Object.fromEntries(columns.map((field) => [field.name, valueFor(scope, field)]));
        return { index, values, variant: classify(scope, values) };
      }).filter((row) => !args.variantTarget || row.variant?.winner?.entityName === args.variantTarget).slice(0, 200);
      return { ok: true, total: rows.length, blockTotal: scopes.length, rows };
    } catch (error) { return { ok: false, message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgePreviewExtraction(args) {
    "use strict";
    try {
      const adapter = Site2JsonDsl.compile(args.definition);
      const url = new URL(location.href);
      if (!adapter.match(url, document)) return { ok: false, reason: "no-match" };
      return { ok: true, observation: adapter.extract(document, url) };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgePreviewSemanticDomV2(args) {
    "use strict";
    try {
      if (!globalThis.Site2JsonIrPipeline?.infer) throw new Error("The V2 semantic-DOM runtime is unavailable on this page.");
      if (!globalThis.Site2JsonIrV2ReviewSurface?.derive || !globalThis.Site2JsonIrV2ReviewSurface?.buildEvidence) {
        throw new Error("The V2 review surface runtime is unavailable on this page.");
      }
      const started = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      const result = globalThis.Site2JsonIrPipeline.infer(document, args?.plan || {}, {
        profile: args?.profile || null,
        variants: args?.variants || {}
      });
      const finished = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      const overlay = args?.overlay || {};
      const evidence = globalThis.Site2JsonIrV2ReviewSurface.buildEvidence({
        tree: result.tree,
        findings: result.semantics.findings,
        reports: result.semantics.reports,
        grouping: result.grouping?.winner ? {
          id: result.grouping.winner.id,
          kind: result.grouping.winner.kind,
          score: result.grouping.winner.score,
          axes: result.grouping.winner.axes,
          hardValid: result.grouping.winner.hardValid,
          evidence: result.grouping.winner.evidence,
          entityCount: result.grouping.winner.sources?.length || 0
        } : null,
        output: result.output,
        validation: result.validation
      });
      const effective = globalThis.Site2JsonIrV2ReviewSurface.derive(evidence, overlay);
      const graph = effective.output?.data?.["@graph"] || [];
      const previewId = `v2:${Date.now().toString(36)}:${Math.random().toString(36).slice(2, 10)}`;
      const leaf = (value) => String(value || "").replace(/^https?:\/\/schema\.org\//, "").split(/[\/#:]/).filter(Boolean).pop() || "";
      const pointer = (value) => String(value).replace(/~/g, "~0").replace(/\//g, "~1");
      const canonicalType = (value) => {
        const term = String(value || "").trim();
        if (!term) return "";
        if (/^schema:/i.test(term)) return `https://schema.org/${term.slice(term.indexOf(":") + 1)}`;
        if (/^https?:\/\/schema\.org\//i.test(term)) return `https://schema.org/${term.replace(/^https?:\/\/schema\.org\//i, "")}`;
        if (/^schema\.org\//i.test(term)) return `https://${term}`;
        // Bare names in graph nodes are Schema.org shorthand. Compact names
        // and absolute terms from local vocabularies retain their namespace.
        if (!term.includes(":") && !term.includes("/") && !term.includes("#")) return `https://schema.org/${term}`;
        return term;
      };
      const sameType = (node, types = []) => types.some((type) => canonicalType(node?.term) === canonicalType(type));
      const semanticPaths = new Map();
      const semanticNodes = new Map();
      const recordPaths = (node, markupPath, jsonldPath = null, compactPath = null) => {
        semanticNodes.set(node.id, node);
        semanticPaths.set(node.id, {
          markup: [markupPath],
          jsonld: jsonldPath ? [jsonldPath] : [],
          compact: compactPath ? [compactPath] : []
        });
        (node.children || []).forEach((child, index) => {
          const childMarkup = `${markupPath}/children/${index}`;
          if (child.kind === "value") {
            const property = pointer(leaf(child.term));
            semanticPaths.set(child.id, {
              markup: [childMarkup],
              jsonld: jsonldPath ? [`${jsonldPath}/${property}`] : [],
              compact: compactPath ? [`${compactPath}/${property}`] : []
            });
          } else if (child.kind === "entity") {
            const property = pointer(leaf(child.assignment?.relationship || "item"));
            recordPaths(child, childMarkup, jsonldPath ? `${jsonldPath}/${property}` : null, compactPath ? `${compactPath}/${property}` : null);
          } else recordPaths(child, childMarkup);
        });
      };
      (effective.tree.root.children || []).forEach((entity, index) => recordPaths(entity, `/root/children/${index}`, `/@graph/${index}`, `/entities/${index}`));

      const focusModel = args?.focusModel || {};
      const graphNodes = focusModel.nodes || {};
      const graphEdges = Array.isArray(focusModel.edges) ? focusModel.edges : [];
      const rootAlias = focusModel.root;
      const topEntities = (effective.tree.root.children || []).filter((node) => node.kind === "entity" && (!graphNodes[rootAlias] || sameType(node, graphNodes[rootAlias].types)));
      const pathsToAlias = new Map(rootAlias ? [[rootAlias, [[]]]] : []);
      const queue = rootAlias ? [{ alias: rootAlias, route: [], visited: new Set([rootAlias]) }] : [];
      while (queue.length) {
        const current = queue.shift();
        for (const edge of graphEdges.filter((candidate) => candidate.from === current.alias)) {
          if (current.visited.has(edge.to)) continue;
          const route = [...current.route, edge];
          const routes = pathsToAlias.get(edge.to) || [];
          routes.push(route);
          pathsToAlias.set(edge.to, routes);
          queue.push({ alias: edge.to, route, visited: new Set([...current.visited, edge.to]) });
        }
      }
      const traverseRoute = (route, initial = topEntities) => {
        let nodes = [...initial];
        for (const edge of route) {
          const target = graphNodes[edge.to] || {};
          nodes = nodes.flatMap((node) => (node.children || []).filter((child) => child.kind === "entity"
            && leaf(child.assignment?.relationship) === leaf(edge.property)
            && sameType(child, target.types || [])));
        }
        return nodes;
      };
      const resolveAlias = (alias) => {
        const routes = pathsToAlias.get(alias);
        if (!routes) return [];
        return [...new Map(routes.flatMap((route) => traverseRoute(route)).map((node) => [node.id, node])).values()];
      };
      const makeEntry = (id, kind, nodes, metadata = {}) => {
        const nodeIds = [...new Set(nodes.map((node) => node.id))];
        const formats = { markup: [], compact: [], jsonld: [] };
        for (const nodeId of nodeIds) for (const format of Object.keys(formats)) formats[format].push(...(semanticPaths.get(nodeId)?.[format] || []));
        for (const format of Object.keys(formats)) formats[format] = [...new Set(formats[format])];
        return { id, kind, nodeIds, formats, ...metadata };
      };
      const aliases = Object.fromEntries(Object.keys(graphNodes).map((alias) => [alias, makeEntry(alias, "node", resolveAlias(alias), { alias })]));
      const edges = Object.fromEntries(graphEdges.map((edge, index) => {
        const id = `${edge.from}\u001f${edge.property}\u001f${edge.to}`;
        const sourceNodes = resolveAlias(edge.from);
        return [id, makeEntry(id, "edge", traverseRoute([edge], sourceNodes), { edgeIndex: index, from: edge.from, property: edge.property, to: edge.to })];
      }));
      const focusIndex = { root: rootAlias || null, aliases, edges };
      const emptyFormats = () => ({ markup: [], compact: [], jsonld: [] });
      const reviewIndex = {
        entities: effective.reports.map((report) => ({
          entityId: report.entityId,
          status: report.accepted ? "accepted" : "unresolved",
          accepted: Boolean(report.accepted),
          selected: report.selected,
          margin: report.margin,
          tied: Boolean(report.tied),
          candidates: (report.ranked || []).map((candidate) => ({
            term: candidate.term,
            score: candidate.score,
            unsupported: Boolean(candidate.unsupported)
          })),
          formats: semanticPaths.get(report.entityId) || emptyFormats()
        })),
        fields: effective.findings.map((finding) => ({
          nodeId: finding.nodeId,
          role: finding.role || semanticNodes.get(finding.nodeId)?.role || "value",
          value: semanticNodes.get(finding.nodeId)?.value,
          status: finding.status === "assigned" ? "assigned" : "unresolved",
          term: finding.term || null,
          confidence: finding.confidence,
          candidates: (finding.candidates || []).map((candidate) => ({
            term: candidate.term,
            score: candidate.score,
            compatible: candidate.compatible !== false,
            source: candidate.source || null
          })),
          formats: semanticPaths.get(finding.nodeId) || emptyFormats()
        }))
      };
      globalThis.Site2JsonV2PreviewState = {
        previewId,
        tree: effective.tree,
        sourceRefs: result.observed?.sourceRefs || new Map(),
        focusIndex,
        reviewIndex
      };
      return {
        ok: true,
        previewId,
        pageUrl: location.href,
        durationMs: Math.round((finished - started) * 10) / 10,
        profileDigest: args?.profile?.digest || null,
        evidence: {
          tree: evidence.tree,
          findings: evidence.findings,
          reports: evidence.reports,
          output: evidence.output,
          validation: evidence.validation
        },
        output: effective.output?.data || null,
        formats: {
          markup: effective.tree,
          compact: effective.output?.compact || null,
          jsonld: effective.output?.data || null
        },
        focusIndex,
        reviewIndex,
        summary: {
          entityCount: graph.length,
          assignedFieldCount: effective.findings.filter((finding) => finding.status === "assigned").length,
          unresolvedFieldCount: effective.findings.filter((finding) => finding.status !== "assigned").length,
          acceptedTypeCount: effective.reports.filter((report) => report.accepted).length,
          unresolvedTypeCount: effective.reports.filter((report) => !report.accepted).length,
          grouping: {
            id: result.grouping.winner.id,
            kind: result.grouping.winner.kind,
            score: result.grouping.winner.score,
            hardValid: result.grouping.winner.hardValid,
            entityCount: result.grouping.winner.sources.length,
            axes: result.grouping.winner.axes,
            evidence: result.grouping.winner.evidence
          }
        },
        findings: effective.findings,
        reports: effective.reports,
        validation: effective.validation,
        effective
      };
    } catch (error) {
      return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) };
    }
  }

  function bridgeDetectSemanticDomV2(args) {
    "use strict";
    try {
      if (!globalThis.Site2JsonIrPipeline?.detectPage) throw new Error("The V2 page detector is unavailable on this page.");
      if (!globalThis.Site2JsonIrV2ReviewSurface?.derive || !globalThis.Site2JsonIrV2ReviewSurface?.buildEvidence) {
        throw new Error("The V2 review surface runtime is unavailable on this page.");
      }
      const started = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      const result = globalThis.Site2JsonIrPipeline.detectPage(document, args?.plan || {}, {
        profile: args?.profile || null,
        variants: args?.variants || {},
        detection: args?.detection || {}
      });
      const finished = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      const overlay = args?.overlay || {};
      const effectiveById = new Map();
      const effectiveFor = (detection) => {
        const cached = effectiveById.get(detection.id);
        if (cached) return cached;
        const evidence = globalThis.Site2JsonIrV2ReviewSurface.buildEvidence({
          tree: detection.tree,
          findings: detection.semantics?.findings || [],
          reports: detection.semantics?.reports || [],
          grouping: grouping(detection),
          output: detection.output || null,
          validation: detection.validation || null
        });
        const effective = globalThis.Site2JsonIrV2ReviewSurface.derive(evidence, overlay[detection.id] || {});
        const value = { evidence, effective };
        effectiveById.set(detection.id, value);
        return value;
      };
      const grouping = (detection) => ({
        id: detection.candidate.id,
        kind: detection.candidate.kind,
        score: detection.candidate.score,
        axes: detection.candidate.axes,
        hardValid: detection.candidate.hardValid,
        evidence: detection.candidate.evidence,
        entityCount: detection.candidate.sources.length
      });
      const selected = result.selected.map((detection) => {
        const { effective, evidence } = effectiveFor(detection);
        return {
          id: detection.id,
          status: detection.status,
          reasons: [...detection.reasons],
          ...(detection.parentDetectionId ? { parentDetectionId: detection.parentDetectionId } : {}),
          typeSignature: [...detection.typeSignature],
          metrics: { ...detection.metrics },
          grouping: grouping(detection),
          output: effective.output.data,
          compact: effective.output.compact,
          findings: effective.findings,
          reports: effective.reports,
          validation: effective.validation,
          evidence,
          effective
        };
      });
      const candidates = result.candidates.map((detection) => ({
        id: detection.id,
        status: detection.status,
        reasons: [...detection.reasons],
        ...(detection.alternativeTo ? { alternativeTo: detection.alternativeTo } : {}),
        ...(detection.parentDetectionId ? { parentDetectionId: detection.parentDetectionId } : {}),
        typeSignature: [...(detection.typeSignature || [])],
        metrics: detection.metrics ? { ...detection.metrics } : null,
        grouping: grouping(detection),
        ...(detection.error ? { error: detection.error } : {})
      }));
      globalThis.Site2JsonV2DetectionState = {
        selected: new Map(result.selected.map((detection) => {
          const { effective } = effectiveFor(detection);
          return [detection.id, {
          tree: effective.tree,
          sourceRefs: detection.observed?.sourceRefs,
          findings: effective.findings,
          output: {
            data: detection.output?.data,
            compact: detection.output?.compact
          }
        }];
        }))
      };
      return {
        ok: true,
        pageUrl: location.href,
        durationMs: Math.round((finished - started) * 10) / 10,
        profileDigest: args?.profile?.digest || null,
        summary: result.summary,
        selected,
        candidates
      };
    } catch (error) {
      return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) };
    }
  }

  function bridgeSurveySemanticDomV2(args) {
    "use strict";
    try {
      if (!globalThis.Site2JsonIrPageDetection?.survey) throw new Error("The V2 page survey is unavailable on this page.");
      const started = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      const survey = globalThis.Site2JsonIrPageDetection.survey(document, args?.plan || {}, { detection: args?.detection || {} });
      const observationIndex = new Map();
      const collect = (candidate, signature) => {
        const key = JSON.stringify(signature);
        const current = observationIndex.get(key);
        if (!current) {
          const sample = candidate.evidence.text;
          candidate.sampleValues = sample ? [sample] : [];
          candidate.groupIds = [candidate.groupId];
          candidate.provenance.occurrences = 1;
          observationIndex.set(key, candidate);
          return;
        }
        current.provenance.occurrences += 1;
        if (!current.groupIds.includes(candidate.groupId)) current.groupIds.push(candidate.groupId);
        if (candidate.evidence.text && !current.sampleValues.includes(candidate.evidence.text) && current.sampleValues.length < 3) {
          current.sampleValues.push(candidate.evidence.text);
        }
      };
      for (const group of survey.candidates) {
        for (const entity of group.observed.tree.root.children || []) {
          const entitySource = group.observed.sourceRefs.get(entity.id);
          const root = Array.isArray(entitySource) ? entitySource[0] : entitySource;
          if (root?.nodeType === 1) {
            const marker = {
              selector: group.id,
              suggestedName: "type",
              kind: "text",
              evidence: {
                tag: root.tagName?.toLowerCase() || "",
                id: root.getAttribute?.("id") || "",
                classes: String(root.getAttribute?.("class") || "").split(/\s+/).filter(Boolean).slice(0, 12),
                context: [root.getAttribute?.("itemtype"), root.getAttribute?.("data-type"), root.getAttribute?.("role")].filter(Boolean).join(" "),
                text: ""
              },
              groupId: group.id,
              provenance: { decision: "observed", source: "page-group-root" }
            };
            collect(marker, [marker.suggestedName, marker.evidence.tag, marker.evidence.id, marker.evidence.classes, marker.evidence.context]);
          }
          for (const field of entity.children || []) {
            const sources = group.observed.sourceRefs.get(field.id);
            const node = Array.isArray(sources) ? sources[0] : sources;
            const rendered = Array.isArray(field.value) ? field.value.find(Boolean) : field.value;
            const candidate = {
              selector: field.source || field.id,
              suggestedName: field.role,
              kind: field.role === "url" || field.role === "image" ? "url" : "text",
              evidence: {
                tag: node?.tagName?.toLowerCase?.() || "",
                id: node?.getAttribute?.("id") || "",
                classes: String(node?.getAttribute?.("class") || "").split(/\s+/).filter(Boolean).slice(0, 12),
                context: [node?.getAttribute?.("itemprop"), node?.getAttribute?.("aria-label")].filter(Boolean).join(" "),
                text: String(rendered || "").replace(/\s+/g, " ").trim().slice(0, 100)
              },
              groupId: group.id,
              provenance: { decision: "observed", source: field.source, confidence: field.confidence }
            };
            collect(candidate, [candidate.suggestedName, candidate.kind, candidate.selector, candidate.evidence.tag, candidate.evidence.id, candidate.evidence.classes, candidate.evidence.context]);
          }
        }
      }
      const finished = typeof performance === "object" && performance.now ? performance.now() : Date.now();
      const observations = [...observationIndex.values()];
      return {
        ok: true,
        pageUrl: location.href,
        durationMs: Math.round((finished - started) * 10) / 10,
        summary: { candidateCount: survey.candidateCount, surveyedCount: survey.candidates.length, observationCount: observations.length },
        observations
      };
    } catch (error) {
      return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) };
    }
  }

  function bridgeFocusSemanticDomV2(args) {
    "use strict";
    try {
      const highlighter = globalThis.Site2JsonPageHighlighter;
      const state = globalThis.Site2JsonV2PreviewState;
      const groupId = "site2json-v2-semantic-focus";
      if (!args?.previewId || state?.previewId !== args.previewId) {
        highlighter?.clearGroup?.(groupId);
        return { ok: false, reason: "stale-preview", nodeIds: [], sourceCount: 0 };
      }
      const reviewEntry = args.kind === "review"
        ? (args.reviewKind === "entity"
          ? state.reviewIndex?.entities?.find((candidate) => candidate.entityId === args.reviewId)
          : args.reviewKind === "field"
            ? state.reviewIndex?.fields?.find((candidate) => candidate.nodeId === args.reviewId)
            : null)
        : null;
      const entry = args.kind === "review"
        ? reviewEntry && { ...reviewEntry, nodeIds: [args.reviewId] }
        : args.kind === "edge"
          ? state.focusIndex?.edges?.[args.focusId]
          : state.focusIndex?.aliases?.[args.alias];
      if (!entry) {
        highlighter?.clearGroup?.(groupId);
        return { ok: true, nodeIds: [], sourceCount: 0 };
      }
      const matched = [];
      const sources = [];
      const sourceSet = new Set();
      const collectSources = (node) => {
        const referenced = state.sourceRefs.get(node.id);
        let directCount = 0;
        for (const source of Array.isArray(referenced) ? referenced : referenced ? [referenced] : []) {
          const element = source?.nodeType === Node.ELEMENT_NODE ? source : source?.parentElement;
          if (element) {
            directCount += 1;
            if (!sourceSet.has(element)) { sourceSet.add(element); sources.push(element); }
          }
        }
        // Prefer the semantic entity's own page boundary. Descendant values
        // are a fallback for synthesized nodes that have no direct source.
        if (!directCount) for (const child of node.children || []) collectSources(child);
      };
      const wantedIds = new Set(entry.nodeIds || []);
      const visit = (node) => {
        if (wantedIds.has(node.id)) {
          matched.push(node.id);
          collectSources(node);
        }
        for (const child of node.children || []) visit(child);
      };
      visit(state.tree.root);
      const result = highlighter?.setElementGroup?.({
        id: groupId,
        color: "purple",
        label: args.alias || (args.kind === "review" ? "Review decision" : entry.property) || "Semantic",
        numbered: false,
        limit: 200
      }, sources) || { matchCount: sources.length, shown: 0 };
      if (args.reveal !== false && sources[0]) sources[0].scrollIntoView({ block: "center", behavior: "smooth" });
      return { ok: true, nodeIds: matched, sourceCount: sources.length, shown: result.shown || 0 };
    } catch (error) {
      return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error), nodeIds: [], sourceCount: 0 };
    }
  }

  function bridgeFocusPageDetectionV2(args) {
    "use strict";
    try {
      const highlighter = globalThis.Site2JsonPageHighlighter;
      const groupId = "site2json-v2-detection-focus";
      const detection = globalThis.Site2JsonV2DetectionState?.selected?.get?.(args?.detectionId);
      if (!detection) {
        highlighter?.clearGroup?.(groupId);
        return { ok: true, sourceCount: 0, shown: 0 };
      }
      const entities = detection.tree?.root?.children || [];
      const selected = Number.isInteger(args?.entityIndex) ? [entities[args.entityIndex]].filter(Boolean) : entities;
      const sources = [];
      const seen = new Set();
      const resolveFieldChildren = (entity, role, detectionRecord) => {
        const termAliases = Object.freeze({
          name: Object.freeze(["title", "heading"]),
          headline: Object.freeze(["title", "heading"]),
          datePublished: Object.freeze(["date", "datePosted"]),
          dateCreated: Object.freeze(["date", "datePosted"]),
          dateModified: Object.freeze(["date", "datePosted"]),
          date: Object.freeze(["date", "datePosted"]),
          rating: Object.freeze(["rating"])
        });
        const children = entity.children || [];
        if (!children.length) return [];
        const targetProperty = String(role || "").trim();
        if (!targetProperty) return [];
        const aliases = termAliases[targetProperty]
          || termAliases[targetProperty.split(/[\/#:]/).filter(Boolean).at(-1)]
          || [];
        const roleMatches = children.filter((child) => child.role === targetProperty || aliases.includes(child.role));
        if (roleMatches.length) return roleMatches;
        const localTerm = String(targetProperty).split(/[\/#:]/).filter(Boolean).at(-1);
        const findingNodeIds = (detectionRecord?.findings || [])
          .filter((finding) => typeof finding?.nodeId === "string" && finding.status === "assigned" && String(finding?.term || "").trim() && finding.nodeId.startsWith(`${entity.id}:`))
          .filter((finding) => {
            const term = String(finding.term).trim().split(/[\/#:]/).filter(Boolean).at(-1);
            return term === localTerm;
          })
          .map((finding) => finding.nodeId);
        if (findingNodeIds.length) {
          const byFinding = children.filter((child) => findingNodeIds.includes(child.id));
          if (byFinding.length) return byFinding;
        }
        return [];
      };
      const collect = (node) => {
        if (!node) return;
        const references = detection.sourceRefs.get(node.id);
        for (const source of Array.isArray(references) ? references : references ? [references] : []) {
          const element = source?.nodeType === Node.ELEMENT_NODE ? source : source?.parentElement;
          if (element && !seen.has(element)) { seen.add(element); sources.push(element); }
        }
      };
      for (const entity of selected) {
        if (args?.role) {
          const values = resolveFieldChildren(entity, args.role, detection);
          if (values.length) for (const value of values) collect(value);
          else collect(entity);
        } else collect(entity);
      }
      const result = highlighter?.setElementGroup?.({
        id: groupId,
        color: "green",
        label: args?.role || "Detected",
        numbered: sources.length > 1,
        limit: 200
      }, sources) || { shown: sources.length };
      if (args?.reveal && sources[0]) sources[0].scrollIntoView({ block: "center", behavior: "smooth" });
      return { ok: true, sourceCount: sources.length, shown: result.shown || 0 };
    } catch (error) {
      return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error), sourceCount: 0, shown: 0 };
    }
  }

  function bridgeCaptureStructuralBaseline(args) {
    "use strict";
    try {
      const url = new URL(location.href);
      const baselines = Site2JsonDsl.captureStructuralBaselines(args.definition, document, url);
      return { ok: true, baselines };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  function bridgeCaptureFixture(args) {
    "use strict";
    try {
      const url = new URL(location.href);
      const definition = Site2JsonDsl.validateDefinition(args.definition);
      const page = Site2JsonDsl.matchingPage(definition, url, document);
      if (!page) return { ok: false, reason: "no-match", message: "The adapter does not match the current rendered page." };
      return { ok: true, ...Site2JsonFixtureCapture.capture(document, definition, page), pageId: page.id };
    } catch (error) { return { ok: false, reason: "error", message: error instanceof Error ? error.message : String(error) }; }
  }

  const api = Object.freeze({ bridgeAcceptScope, bridgeAddFieldCandidate, bridgeBuildBlockTable, bridgeCaptureFixture, bridgeCaptureStructuralBaseline, bridgeCaptureVariantEvidence, bridgeClassifyVariantItems, bridgeClassifyNestedVariantSlots, bridgeClearHighlights, bridgeDetectSemanticDomV2, bridgeDiscoverFields, bridgeDiscoverVariantItems, bridgeFindEvidenceScopes, bridgeFocusPageDetectionV2, bridgeFocusSemanticDomV2, bridgeHighlightSelector, bridgeInferScope, bridgeLocateSelection, bridgePageAnalysisContext, bridgePreviewExtraction, bridgePreviewField, bridgePreviewSemanticDomV2, bridgeReadSelection, bridgeRevealTarget, bridgeSurveySemanticDomV2 });
  root.Site2JsonSidebarPageBridge = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
