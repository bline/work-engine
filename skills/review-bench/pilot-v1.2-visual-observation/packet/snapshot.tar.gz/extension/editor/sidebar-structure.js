"use strict";

(function exposeSidebarStructure(root) {
  function create({ document, onHighlight, onClearHighlight, onAccept, onStatus }) {
    const elements = {
      adjustments: document.querySelector("#scope-adjustments"),
      narrower: document.querySelector("#scope-narrower-button"),
      wider: document.querySelector("#scope-wider-button"),
      usePreview: document.querySelector("#scope-use-preview-button"),
      levels: document.querySelector("#scope-levels")
    };
    let proposals = [];
    let selectedIndex = -1;

    function preview(index, { focus = false } = {}) {
      if (!proposals.length) return;
      selectedIndex = Math.max(0, Math.min(index, proposals.length - 1));
      const level = proposals[selectedIndex];
      for (const [itemIndex, item] of Array.from(elements.levels.children).entries()) {
        const selected = itemIndex === selectedIndex;
        item.classList.toggle("selected", selected);
        item.setAttribute("aria-checked", String(selected));
      }
      elements.narrower.disabled = selectedIndex === 0;
      elements.wider.disabled = selectedIndex === proposals.length - 1;
      elements.usePreview.disabled = false;
      elements.usePreview.textContent = `Use recommended <${level.tag}> items`;
      onHighlight(level.best.selector);
      onStatus("info", `Previewing <${level.tag}> boundary: ${level.best.matchCount} matches. Move narrower or wider, then accept explicitly.`);
      if (focus) elements.levels.children[selectedIndex]?.scrollIntoView({ block: "nearest" });
    }

    function restorePreview() {
      const level = proposals[selectedIndex];
      if (level) onHighlight(level.best.selector);
      else onClearHighlight();
    }

    function render(levels, chosenSelector, { independent = false } = {}) {
      elements.levels.replaceChildren();
      const seen = new Set();
      const usable = levels.filter((level) => {
        if (!level.best || seen.has(level.best.selector)) return false;
        seen.add(level.best.selector);
        return true;
      });
      if (!usable.length) {
        proposals = [];
        selectedIndex = -1;
        elements.adjustments.hidden = true;
        elements.levels.hidden = true;
        return;
      }
      proposals = usable;
      selectedIndex = Math.max(0, usable.findIndex((level) => level.best.selector === chosenSelector));
      for (const [index, level] of usable.entries()) {
        const item = document.createElement("li");
        const recommended = level.best.selector === chosenSelector;
        item.className = `option-item${recommended ? " selected" : ""}`;
        item.tabIndex = 0;
        item.setAttribute("role", "radio");
        item.setAttribute("aria-checked", String(index === selectedIndex));
        const code = document.createElement("code");
        code.textContent = level.best.selector;
        const meta = document.createElement("span");
        meta.className = "option-meta";
        meta.textContent = `${level.best.matchCount} matches · <${level.tag}> boundary · ${level.best.kind}`;
        const findings = document.createElement("ul");
        findings.className = "option-findings";
        for (const finding of level.best.findings || []) {
          const row = document.createElement("li");
          row.className = `option-finding ${finding.kind}`;
          row.textContent = `${finding.kind === "good" ? "✓" : "⚠"} ${finding.message}`;
          findings.append(row);
        }
        const actions = document.createElement("div");
        actions.className = "option-actions";
        const recommendation = document.createElement("span");
        recommendation.className = "recommended";
        recommendation.textContent = recommended ? "Recommended" : "";
        actions.append(recommendation);
        if (independent) {
          const use = document.createElement("button");
          use.type = "button";
          use.className = "compact";
          use.textContent = recommended ? "Use recommended scope" : "Use this scope";
          use.addEventListener("click", (event) => {
            event.stopPropagation();
            onClearHighlight();
            onAccept(level.best.selector);
          });
          actions.append(use);
        }
        item.append(code, meta, findings, actions);
        item.addEventListener("click", () => preview(index));
        item.addEventListener("keydown", (event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            preview(index);
          }
        });
        item.addEventListener("mouseenter", () => onHighlight(level.best.selector));
        item.addEventListener("mouseleave", restorePreview);
        item.addEventListener("focusin", () => onHighlight(level.best.selector));
        item.addEventListener("focusout", restorePreview);
        elements.levels.append(item);
      }
      elements.adjustments.hidden = false;
      elements.levels.hidden = false;
      preview(selectedIndex);
    }

    elements.narrower.addEventListener("click", () => preview(selectedIndex - 1, { focus: true }));
    elements.wider.addEventListener("click", () => preview(selectedIndex + 1, { focus: true }));
    elements.usePreview.addEventListener("click", () => {
      const level = proposals[selectedIndex];
      if (level) { onClearHighlight(); onAccept(level.best.selector); }
    });

    return Object.freeze({
      preview,
      render,
      selected: () => proposals[selectedIndex] || null,
      snapshot: () => proposals.map((level, index) => ({
        index,
        tag: level.tag,
        selector: level.best.selector,
        kind: level.best.kind,
        matchCount: level.best.matchCount,
        findings: level.best.findings || [],
        recommendation: level.best.recommendation || null,
        selected: index === selectedIndex
      })),
      proposals: () => proposals.slice()
    });
  }

  const api = Object.freeze({ create });
  root.Site2JsonSidebarStructure = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
