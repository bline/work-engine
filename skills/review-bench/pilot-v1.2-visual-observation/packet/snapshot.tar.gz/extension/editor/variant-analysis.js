(function initializeVariantAnalysis(root, factory) {
  "use strict";
  const ranking = root.Site2JsonSemanticRanking || (typeof require === "function" ? require("./semantic-ranking") : null);
  const api = factory(ranking);
  root.Site2JsonVariantAnalysis = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function variantAnalysisFactory(defaultRanking) {
  "use strict";

  function entityName(type, used) {
    const base = `${String(type || "Thing").replace(/[^A-Za-z0-9_]/g, "") || "Thing"}Result`;
    let name = base;
    let suffix = 2;
    while (used.has(name)) name = `${base}${suffix++}`;
    used.add(name);
    return name;
  }

  function selectorSet(item) {
    return new Set((item.candidates || [])
      .filter((candidate) => candidate.selector && candidate.selectorKind !== "fallback")
      .map((candidate) => candidate.selector));
  }

  function discriminatingEvidence(type, rows) {
    const inside = rows.filter((row) => row.winner?.schemaType === type && !row.ambiguous);
    const outside = rows.filter((row) => row.winner?.schemaType !== type || row.ambiguous);
    const selectors = new Set(inside.flatMap((row) => [...row.selectors]));
    return [...selectors].map((selector) => {
      const support = inside.filter((row) => row.selectors.has(selector)).length;
      const conflicts = outside.filter((row) => row.selectors.has(selector)).length;
      return { selector, support, conflicts, coverage: inside.length ? support / inside.length : 0 };
    }).filter((item) => item.conflicts === 0 && item.coverage >= 0.5)
      .sort((left, right) => right.coverage - left.coverage || right.support - left.support || left.selector.length - right.selector.length)
      .slice(0, 3)
      .map((item) => ({ selector: item.selector, weight: 6 + Math.round(item.coverage * 4) }));
  }

  function analyze(items, { ranking = defaultRanking, typeLimit = 5, candidateTypes = null, fallbackType = null, minScore = 6, minMargin = 2 } = {}) {
    if (!ranking?.rank) throw new Error("Semantic ranking is unavailable.");
    const rows = (items || []).map((item, index) => {
      const result = ranking.rank(item.candidates || [], {
        typeLimit: Math.max(typeLimit, 2),
        ...(Array.isArray(candidateTypes) && candidateTypes.length ? { allowedTypes: candidateTypes } : {})
      });
      const choices = result.types || [];
      const first = choices[0] || null;
      const second = choices[1] || null;
      const margin = first ? first.score - (second?.score || 0) : 0;
      const ambiguous = !first || first.score < minScore || margin < minMargin;
      return {
        index: Number.isSafeInteger(item.index) ? item.index : index,
        selectors: selectorSet(item),
        winner: first ? { modelId: first.id, schemaType: first.schemaType || first.id.replace(/^schema:/, ""), label: first.label, score: first.score, margin } : null,
        alternatives: choices.slice(1, 4).map((choice) => ({ modelId: choice.id, schemaType: choice.schemaType || choice.id.replace(/^schema:/, ""), label: choice.label, score: choice.score })),
        ambiguous
      };
    });
    const groups = new Map();
    for (const row of rows) {
      if (row.ambiguous || !row.winner) continue;
      const current = groups.get(row.winner.schemaType) || { modelId: row.winner.modelId, schemaType: row.winner.schemaType, label: row.winner.label, count: 0, score: 0 };
      current.count += 1;
      current.score += row.winner.score;
      groups.set(row.winner.schemaType, current);
    }
    const usedNames = new Set();
    const rankedCandidates = [...groups.values()]
      .sort((left, right) => right.count - left.count || right.score - left.score || left.label.localeCompare(right.label))
      .slice(0, typeLimit)
      .map((candidate) => ({
        ...candidate,
        averageScore: Math.round((candidate.score / candidate.count) * 10) / 10,
        entityName: entityName(candidate.schemaType, usedNames),
        evidence: discriminatingEvidence(candidate.schemaType, rows)
      }));
    // This pass proposes the bounded set of types that may occur. Definitive
    // per-item classification happens after field discovery, when compiled
    // semantic shape signals and any explicit page evidence are both available.
    const candidates = rankedCandidates;
    const acceptedTypes = new Set(candidates.map((candidate) => candidate.schemaType));
    const acceptedRows = fallbackType ? rows.map((row) => {
      if (!row.winner || acceptedTypes.has(row.winner.schemaType) || row.ambiguous) return row;
      const fallback = [row.winner, ...(row.alternatives || [])].find((candidate) => candidate.schemaType === fallbackType);
      return {
        ...row,
        winner: fallback || { modelId: `schema:${fallbackType}`, schemaType: fallbackType, label: fallbackType, score: 0, margin: 0 },
        ambiguous: false,
        fallback: true
      };
    }) : rows;
    return {
      status: "ready",
      sampledItems: acceptedRows.length,
      mixed: candidates.length >= 2,
      candidates,
      ambiguousCount: acceptedRows.filter((row) => row.ambiguous).length,
      rows: acceptedRows.map(({ selectors: _selectors, ...row }) => row),
      thresholds: { minScore, minMargin }
    };
  }

  return Object.freeze({ analyze });
});
