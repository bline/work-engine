(function initializeTransformCatalog(root, factory) {
  "use strict";
  const transforms = root.Site2JsonTransforms || (typeof require === "function" ? require("../core/transforms") : null);
  const api = factory(transforms);
  root.Site2JsonTransformCatalog = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function transformCatalogFactory(transforms) {
  "use strict";

  const CATEGORY_ORDER = Object.freeze([
    "Text",
    "Numbers",
    "Dates and times",
    "Money and rates",
    "URLs",
    "URL queries",
    "URL paths",
    "Collections",
    "Guards",
    "Encoding",
    "Other"
  ]);

  function descriptor(detail) {
    const searchText = [detail.name, detail.label, detail.description, detail.category, ...(detail.keywords || [])]
      .join(" ").toLowerCase();
    return Object.freeze({ ...detail, searchText });
  }

  const catalog = Object.freeze((transforms?.capabilityDetails?.() || []).map(descriptor));
  const byName = new Map(catalog.map((item) => [item.name, item]));

  function details(name) {
    return byName.get(name) || null;
  }

  function search(query = "", { zeroArgumentOnly = false } = {}) {
    const terms = String(query).trim().toLowerCase().split(/\s+/).filter(Boolean);
    return catalog.filter((item) => (
      (!zeroArgumentOnly || (item.minimumArguments === 0 && item.maximumArguments === 0))
      && terms.every((term) => item.searchText.includes(term))
    ));
  }

  function grouped(query = "", { recommended = [], zeroArgumentOnly = false } = {}) {
    const matches = search(query, { zeroArgumentOnly });
    const names = new Set(recommended);
    const groups = new Map();
    for (const item of matches) {
      if (!groups.has(item.category)) groups.set(item.category, []);
      groups.get(item.category).push(item);
    }
    const result = [];
    const preferred = matches.filter((item) => names.has(item.name));
    if (preferred.length) result.push({ name: "Recommended", items: preferred });
    for (const category of CATEGORY_ORDER) {
      const items = groups.get(category);
      if (items?.length) result.push({ name: category, items: items.sort((left, right) => left.label.localeCompare(right.label)) });
    }
    return result;
  }

  function validateStep(step) {
    try {
      transforms.validatePipeline([step]);
      return { ok: true };
    } catch (error) {
      return { ok: false, message: error instanceof Error ? error.message : String(error) };
    }
  }

  return Object.freeze({ CATEGORY_ORDER, all: () => [...catalog], details, grouped, search, validateStep });
});
