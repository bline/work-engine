// Native ESM entry for the extension's sidebar runtime.
import * as correctionPromotionApi from "../authoring/correction-promotion.mjs";

const adapterRegistry = globalThis.Site2JsonAdapterRegistry || null;
const draftRegistry = globalThis.Site2JsonAdapterDraftRegistry || null;
const semanticCompositions = globalThis.Site2JsonSemanticCompositions || null;
const semanticRanking = globalThis.Site2JsonSemanticRanking || null;
const variantAnalysis = globalThis.Site2JsonVariantAnalysis || null;
const pageAnalysisApi = globalThis.Site2JsonPageAnalysis || null;
const automaticConversion = globalThis.Site2JsonAutomaticConversion || null;
const automaticSettingsApi = globalThis.Site2JsonAutomaticSettings || null;
const extractionModel = globalThis.Site2JsonModel || null;
const sidebarWorkflow = globalThis.Site2JsonSidebarWorkflow || null;
const sidebarSemantics = globalThis.Site2JsonSidebarSemantics || null;
const sidebarCompositionGraph = globalThis.Site2JsonSidebarCompositionGraph || null;
const sidebarSemanticGraph = globalThis.Site2JsonSidebarSemanticGraph || null;
const sidebarReview = globalThis.Site2JsonSidebarReview || null;
const sidebarStructure = globalThis.Site2JsonSidebarStructure || null;
const detectionFirstApi = globalThis.Site2JsonDetectionFirst || null;
const visualEvidenceApi = globalThis.Site2JsonVisualEvidence || null;
const sidebarWorkspace = globalThis.Site2JsonSidebarWorkspace || null;
const sidebarSemanticLibrary = globalThis.Site2JsonSidebarSemanticLibrary || null;
const semanticToolboxApi = globalThis.Site2JsonSemanticToolbox || null;
const semanticBundleApi = globalThis.Site2JsonSemanticBundle || null;
const semanticLibraryApi = globalThis.Site2JsonSemanticLibrary || null;
const semanticLibraryIndexedDbApi = globalThis.Site2JsonSemanticLibraryIndexedDb || null;
const semanticLibraryInferenceApi = globalThis.Site2JsonSemanticLibraryInference || null;
const typeExtractionProfileApi = globalThis.Site2JsonTypeExtractionProfile || null;
const fieldMappingCorroboratorApi = globalThis.Site2JsonFieldMappingCorroborator || null;
const semanticMappingArbitratorApi = globalThis.Site2JsonSemanticMappingArbitrator || null;
const semanticAssignmentProfileApi = globalThis.Site2JsonSemanticAssignmentProfile || null;
const pageSemanticProfileApi = globalThis.Site2JsonPageSemanticProfile || null;
const semanticLibraryService = globalThis.Site2JsonSemanticLibraryService || (semanticLibraryApi && semanticToolboxApi
  ? semanticLibraryApi.createIndexedDbToolboxService && semanticLibraryIndexedDbApi && globalThis.indexedDB
    ? semanticLibraryApi.createIndexedDbToolboxService({
      toolboxApi: semanticToolboxApi,
      bundleApi: semanticBundleApi,
      indexedDbApi: semanticLibraryIndexedDbApi,
      indexedDB: globalThis.indexedDB,
      legacyStorage: chrome.storage?.local
    })
    : semanticLibraryApi.createLegacyToolboxService?.({ toolboxApi: semanticToolboxApi, bundleApi: semanticBundleApi, storage: chrome.storage?.local })
  : null);
const semanticLibraryInference = semanticLibraryInferenceApi?.create && semanticLibraryService && semanticRanking
  ? semanticLibraryInferenceApi.create({ service: semanticLibraryService, ranking: semanticRanking, vocabulary: Site2JsonSchemaVocabulary })
  : null;
const EXPANDED_EDITOR_ENABLED = false;
const FAST_VARIANT_SCAN = Object.freeze({ itemLimit: 24, elementLimit: 160, fast: true });
const PRODUCTION_REQUEST_KEY = "site2jsonProductionRunRequest";
const PRODUCTION_RESULT_KEY = "site2jsonProductionRunResult";

const els = {
  appTitle: document.querySelector("#app-title"),
  editorSubtitle: document.querySelector("#editor-subtitle"),
  appNavigation: document.querySelector("#app-navigation"),
  libraryHome: document.querySelector("#library-home"),
  semanticLibraryHome: document.querySelector("#semantic-library-home"),
  editorWorkspace: document.querySelector("#editor-workspace"),
  newAdapter: document.querySelector("#new-adapter-button"),
  backToLibrary: document.querySelector("#back-to-library-button"),
  libraryCount: document.querySelector("#library-count"),
  libraryFile: document.querySelector("#library-file"),
  libraryStatus: document.querySelector("#library-status"),
  libraryImportPreview: document.querySelector("#library-import-preview"),
  libraryPreviewTitle: document.querySelector("#library-preview-title"),
  libraryPreviewDetails: document.querySelector("#library-preview-details"),
  libraryConfirmImport: document.querySelector("#library-confirm-import"),
  libraryCancelImport: document.querySelector("#library-cancel-import"),
  libraryList: document.querySelector("#library-list"),
  libraryEmpty: document.querySelector("#library-empty"),
  draftPicker: document.querySelector("#draft-picker"),
  draftStatus: document.querySelector("#draft-status"),
  saveDraft: document.querySelector("#save-draft-button"),
  exportDraft: document.querySelector("#export-draft-button"),
  publishDraft: document.querySelector("#publish-draft-button"),
  discardDraft: document.querySelector("#discard-draft-button"),
  stepPageDetection: document.querySelector("#step-page-detection"),
  stepVisualEvidence: document.querySelector("#step-visual-evidence"),
  showPageDetection: document.querySelector("#show-page-detection-button"),
  selectionStatus: document.querySelector("#selection-status"),
  selectionSummary: document.querySelector("#selection-summary"),
  selectionTag: document.querySelector("#selection-tag"),
  selectionId: document.querySelector("#selection-id"),
  selectionClasses: document.querySelector("#selection-classes"),
  selectionText: document.querySelector("#selection-text"),
  selectionHrefRow: document.querySelector("#selection-href-row"),
  selectionHref: document.querySelector("#selection-href"),
  structureGuidance: document.querySelector("#structure-guidance"),
  inferRemaining: document.querySelector("#infer-remaining-button"),
  inferRemainingStatus: document.querySelector("#infer-remaining-status"),
  inferenceShortcut: document.querySelector("#inference-shortcut"),
  pickScope: document.querySelector("#pick-scope-button"),
  visualSelect: document.querySelector("#visual-select-button"),
  singleItemScope: document.querySelector("#single-item-scope"),
  stepSelection: document.querySelector("#step-selection"),
  stepScope: document.querySelector("#step-scope"),
  scopeHeading: document.querySelector("#scope-heading"),
  scopeHint: document.querySelector("#scope-hint"),
  scopeStatus: document.querySelector("#scope-status"),
  scopeShowPageAnalysis: document.querySelector("#scope-show-page-analysis"),
  scopeAdjustments: document.querySelector("#scope-adjustments"),
  scopeNarrower: document.querySelector("#scope-narrower-button"),
  scopeWider: document.querySelector("#scope-wider-button"),
  scopeUsePreview: document.querySelector("#scope-use-preview-button"),
  scopeLevels: document.querySelector("#scope-levels"),
  blockSetup: document.querySelector("#block-setup"),
  blockName: document.querySelector("#block-name"),
  blockSchemaType: document.querySelector("#block-schema-type"),
  schemaTypeMenu: document.querySelector("#schema-type-menu"),
  createBlock: document.querySelector("#create-block-button"),
  cancelBlock: document.querySelector("#cancel-block-button"),
  scopeAccepted: document.querySelector("#scope-accepted"),
  structureComplete: document.querySelector("#structure-complete"),
  structureCompleteTitle: document.querySelector("#structure-complete-title"),
  structureCompleteSummary: document.querySelector("#structure-complete-summary"),
  continueSemantics: document.querySelector("#continue-semantics-button"),
  stepSemantics: document.querySelector("#step-semantics"),
  semanticsContext: document.querySelector("#semantics-context"),
  semanticModelInput: document.querySelector("#semantic-model-input"),
  analyzeSemantics: document.querySelector("#analyze-semantics-button"),
  confirmSemantics: document.querySelector("#confirm-semantics-button"),
  semanticModelStatus: document.querySelector("#semantic-model-status"),
  semanticModelSummary: document.querySelector("#semantic-model-summary"),
  semanticRankingSummary: document.querySelector("#semantic-ranking-summary"),
  stepBlocks: document.querySelector("#step-blocks"),
  blockPickerLabel: document.querySelector("#block-picker-label"),
  blockPicker: document.querySelector("#block-picker"),
  activeBlockTitle: document.querySelector("#active-block-title"),
  activeBlockMeta: document.querySelector("#active-block-meta"),
  openTablePanel: document.querySelector("#open-table-panel-button"),
  tablePanelStatus: document.querySelector("#table-panel-status"),
  clearPinnedHighlight: document.querySelector("#clear-pinned-highlight-button"),
  blockTableEmpty: document.querySelector("#block-table-empty"),
  blockTableWrap: document.querySelector("#block-table-wrap"),
  blockTableHead: document.querySelector("#block-table-head"),
  blockTableBody: document.querySelector("#block-table-body"),
  stepFields: document.querySelector("#step-fields"),
  discoverFields: document.querySelector("#discover-fields-button"),
  includeUnmappedFields: document.querySelector("#include-unmapped-fields"),
  undoDiscovery: document.querySelector("#undo-discovery-button"),
  discoveryReportDetails: document.querySelector("#discovery-report-details"),
  discoveryStatus: document.querySelector("#discovery-status"),
  discoveryComplete: document.querySelector("#discovery-complete"),
  discoveryCompleteTitle: document.querySelector("#discovery-complete-title"),
  discoveryCompleteSummary: document.querySelector("#discovery-complete-summary"),
  continueReview: document.querySelector("#continue-review-button"),
  discoveryVariantLabel: document.querySelector("#discovery-variant-label"),
  discoveryVariantPicker: document.querySelector("#discovery-variant-picker"),
  discoveryVariantSummary: document.querySelector("#discovery-variant-summary"),
  reviewVariantLabel: document.querySelector("#review-variant-label"),
  reviewVariantPicker: document.querySelector("#review-variant-picker"),
  inferenceReviewBanner: document.querySelector("#inference-review-banner"),
  inferenceReviewSummary: document.querySelector("#inference-review-summary"),
  reviewInferredSemantics: document.querySelector("#review-inferred-semantics"),
  reviewComplete: document.querySelector("#review-complete"),
  reviewCompleteLabel: document.querySelector("#review-complete-label"),
  reviewCompleteTitle: document.querySelector("#review-complete-title"),
  reviewCompleteSummary: document.querySelector("#review-complete-summary"),
  continueFinish: document.querySelector("#continue-finish-button"),
  stepFieldEditor: document.querySelector("#step-field-editor"),
  backFromField: document.querySelector("#back-from-field-button"),
  fieldEditorTitle: document.querySelector("#field-editor-title"),
  fieldEditorContext: document.querySelector("#field-editor-context"),
  fieldStatus: document.querySelector("#field-status"),
  selectFieldOnPage: document.querySelector("#select-field-on-page-button"),
  fieldForm: document.querySelector("#field-form"),
  fieldSelector: document.querySelector("#field-selector"),
  fieldSelectorSuggestions: document.querySelector("#field-selector-suggestions"),
  fieldSelectorEvidence: document.querySelector("#field-selector-evidence"),
  selectionProposal: document.querySelector("#selection-proposal"),
  selectionProposalSummary: document.querySelector("#selection-proposal-summary"),
  selectionProposalSelector: document.querySelector("#selection-proposal-selector"),
  selectionProposalCoverage: document.querySelector("#selection-proposal-coverage"),
  useSelection: document.querySelector("#use-selection-button"),
  fieldName: document.querySelector("#field-name"),
  fieldNameMenu: document.querySelector("#field-name-menu"),
  fieldSemanticStatus: document.querySelector("#field-semantic-status"),
  fieldKind: document.querySelector("#field-kind"),
  fieldTransform: document.querySelector("#field-transform"),
  transformSteps: document.querySelector("#transform-steps"),
  transformArgumentForm: document.querySelector("#transform-argument-form"),
  transformArgumentTitle: document.querySelector("#transform-argument-title"),
  transformArgumentDescription: document.querySelector("#transform-argument-description"),
  transformArgumentFields: document.querySelector("#transform-argument-fields"),
  transformArgumentStatus: document.querySelector("#transform-argument-status"),
  saveTransformArguments: document.querySelector("#save-transform-arguments"),
  cancelTransformArguments: document.querySelector("#cancel-transform-arguments"),
  transformMenu: document.querySelector("#transform-menu"),
  transformStatus: document.querySelector("#transform-status"),
  fieldAttributeLabel: document.querySelector("#field-attribute-label"),
  fieldAttribute: document.querySelector("#field-attribute"),
  fieldMultiple: document.querySelector("#field-multiple"),
  fieldIdentity: document.querySelector("#field-identity"),
  fieldRequired: document.querySelector("#field-required"),
  customTermForm: document.querySelector("#custom-term-form"),
  customTermDescription: document.querySelector("#custom-term-description"),
  customTermValueType: document.querySelector("#custom-term-value-type"),
  customTermExample: document.querySelector("#custom-term-example"),
  fieldPreview: document.querySelector("#field-preview"),
  addField: document.querySelector("#add-field-button"),
  cancelField: document.querySelector("#cancel-field-button"),
  deleteField: document.querySelector("#delete-field-button"),
  correctionPromotion: document.querySelector("#correction-promotion"),
  correctionPromotionSummary: document.querySelector("#correction-promotion-summary"),
  correctionPromotionChanges: document.querySelector("#correction-promotion-changes"),
  correctionPromotionWarning: document.querySelector("#correction-promotion-warning"),
  correctionPromotionStatus: document.querySelector("#correction-promotion-status"),
  saveCorrectionPromotion: document.querySelector("#save-correction-promotion"),
  dismissCorrectionPromotion: document.querySelector("#dismiss-correction-promotion"),
  stepBuild: document.querySelector("#step-build"),
  adapterId: document.querySelector("#adapter-id"),
  adapterNamespace: document.querySelector("#adapter-namespace"),
  pageId: document.querySelector("#page-id"),
  pageType: document.querySelector("#page-type"),
  build: document.querySelector("#build-button"),
  refreshBaseline: document.querySelector("#refresh-baseline-button"),
  captureFixture: document.querySelector("#capture-fixture-button"),
  previewExtraction: document.querySelector("#preview-extraction-button"),
  buildStatus: document.querySelector("#build-status"),
  buildOutput: document.querySelector("#build-output"),
  extractionOutput: document.querySelector("#extraction-output")
};
els.workflowSteps = document.querySelector("#workflow-steps");
els.expandedWorkspaceBridge = document.querySelector("#expanded-workspace-bridge");
els.resumeSidebar = document.querySelector("#resume-sidebar-button");

const state = {
  pageUrl: null,
  blocks: [],
  activeBlockId: null,
  activeVariantEntityName: null,
  pendingScope: null,
  pendingField: null,
  pendingTransform: null,
  tableRows: [],
  customTerms: {},
  pinnedTarget: null,
  lastValidDefinition: null,
  lastDiscoveryBatch: null,
  discoveryReport: null,
  currentDraft: null,
  baseDefinition: null,
  drafts: [],
  entries: [],
  pendingImport: null,
  selectionProposal: null,
  currentSelection: null,
  automaticAuthoring: null,
  inferenceRun: null,
  inferenceRunning: false,
  driftReview: { status: "idle", findings: [], message: "" },
  workspaceMode: "library",
  route: "structure",
  fixture: null,
  pendingCorrectionPromotion: null,
  structureStartMode: "detection",
  pageDetectionReview: null
};
let autosaveTimer = null;
let fieldNameMenuIndex = -1;
let schemaTypeMenuIndex = -1;
let transformMenuIndex = -1;
const tabIdParameter = new URLSearchParams(location.search).get("tabId");
let inspectedTabId = tabIdParameter === null ? Number.NaN : Number(tabIdParameter);
let tablePanelPort = null;
let tablePanelHeartbeat = null;
let editorLeaseOwner = "sidebar";
const editorClientSessionId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
let editorSourceRevision = 0;
let semanticView = null;
let pageAnalysisService = null;
let activePageAnalysis = null;
let pageAnalysisRequest = 0;
let scopeProposalRequest = 0;
let compositionGraphView = null;
let semanticGraphView = null;
const attention = globalThis.Site2JsonAttention?.create?.({ document }) || null;
let reviewView = null;
let structureView = null;
let detectionFirstView = null;
let visualEvidenceView = null;
let visualEvidenceCaller = null;
let visualEvidenceDecisions = {};
let pageDetectionReport = null;
let workspaceView = null;
let semanticLibraryView = null;
let visualSelectionIntent = null;
let selectionBeforeVisualPick = null;
const scopeProposalCache = { repeating: null, single: null };

function activeBlock() {
  const block = state.blocks.find((candidate) => candidate.id === state.activeBlockId) || null;
  if (block) ensureBlockComposition(block);
  return block;
}

function canCheckStructuralHealth() {
  if (!state.lastValidDefinition) return false;
  const pageId = els.pageId.value.trim() || "collection";
  const page = state.lastValidDefinition.pages?.find((candidate) => candidate.id === pageId);
  return Boolean(page?.blocks?.some((block) => block.structuralBaseline));
}

function variantTargets(block = activeBlock()) {
  if (!block) return [];
  return [block, ...(block.variants?.candidates || [])].map(ensureVariantTarget);
}

function ensureVariantTarget(target) {
  if (!target) return null;
  target.fields ||= [];
  target.requireFields ||= [];
  target.monitorFields ||= [];
  const descriptor = Object.getOwnPropertyDescriptor(target, "identity");
  const legacyIdentity = descriptor && !descriptor.get ? target.identity : null;
  if (descriptor && !descriptor.get) delete target.identity;
  if (legacyIdentity) {
    const name = legacyIdentity.name && legacyIdentity.name !== "canonicalUrl" ? legacyIdentity.name : "url";
    const field = { ...legacyIdentity, name, identity: true, unresolved: false, semanticSource: legacyIdentity.semanticSource || "schema" };
    const existing = target.fields.findIndex((candidate) => candidate.name === name);
    if (existing >= 0) target.fields[existing] = field;
    else target.fields.unshift(field);
    target.identityField = name;
  }
  if (!target.identityField) target.identityField = target.fields.find((field) => field.identity)?.name || null;
  for (const field of target.fields) field.identity = Boolean(target.identityField && field.name === target.identityField);
  if (!Object.getOwnPropertyDescriptor(target, "identity")?.get) {
    Object.defineProperty(target, "identity", {
      configurable: true,
      enumerable: false,
      get() {
        return this.fields?.find((field) => field.name === this.identityField) || null;
      },
      set(value) {
        if (!value) {
          this.identityField = null;
          for (const field of this.fields || []) field.identity = false;
          return;
        }
        const name = value.name && value.name !== "canonicalUrl" ? value.name : "url";
        const normalized = { ...value, name, identity: true, unresolved: false };
        const existing = (this.fields || []).findIndex((field) => field.name === name);
        if (existing >= 0) this.fields[existing] = normalized;
        else this.fields = [normalized, ...(this.fields || [])];
        this.identityField = name;
        for (const field of this.fields) field.identity = field.name === name;
      }
    });
  }
  return target;
}

function activeEntityTarget(block = activeBlock()) {
  if (!block) return null;
  const selected = variantTargets(block).find((target) => target.entityName === state.activeVariantEntityName);
  return ensureVariantTarget(selected || block);
}

function renderVariantContextControls() {
  const block = activeBlock();
  const targets = variantTargets(block);
  const show = targets.length > 1;
  const active = activeEntityTarget(block);
  for (const [label, picker] of [[els.discoveryVariantLabel, els.discoveryVariantPicker], [els.reviewVariantLabel, els.reviewVariantPicker]]) {
    if (!label || !picker) continue;
    label.hidden = !show;
    picker.replaceChildren();
    for (const [index, target] of targets.entries()) {
      const option = document.createElement("option");
      option.value = target.entityName;
      option.textContent = `${target.schemaType}${index === 0 ? " · fallback" : ""}`;
      option.selected = target.entityName === active?.entityName;
      picker.append(option);
    }
  }
  if (els.discoveryVariantSummary) els.discoveryVariantSummary.textContent = show && active
    ? `Only items classified as ${active.schemaType} are sampled. Its fields are stored separately from the other result types.`
    : "";
}

async function activateVariantEntity(entityName) {
  const block = activeBlock();
  if (!variantTargets(block).some((target) => target.entityName === entityName)) return;
  state.activeVariantEntityName = entityName;
  state.pendingField = null;
  state.pendingCorrectionPromotion = null;
  clearDiscoveryUndo();
  renderVariantContextControls();
  reviewView?.renderHeading(block, activeEntityTarget(block));
  await refreshBlockTable();
}

function ensureBlockComposition(block) {
  if (!block || !semanticCompositions) return { ok: true, errors: [], warnings: [] };
  const normalized = semanticCompositions.normalize(block);
  if (!block.composition) block.composition = normalized.composition;
  if (block.semanticsReviewed === undefined) block.semanticsReviewed = true;
  return semanticCompositions.validate(block.composition, state.customTerms);
}

function showFieldEditor(title) {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  els.fieldEditorTitle.textContent = title;
  els.fieldEditorContext.textContent = block && entity ? `${block.name} · ${entity.schemaType}` : "";
  els.stepFieldEditor.hidden = false;
  document.body.classList.add("field-editor-open");
}

function hideFieldEditor() {
  document.body.classList.remove("field-editor-open");
  els.stepFieldEditor.hidden = true;
}

function panelFieldSnapshot(block, field, identity = false) {
  identity = identity || field.name === block.identityField || Boolean(field.identity);
  return {
    key: Site2JsonFieldDiscovery.sourceKey(field),
    name: field.name,
    label: field.name,
    selector: field.selector,
    attribute: field.attribute || null,
    unresolved: Boolean(field.unresolved),
    required: identity || block.requireFields.includes(field.name),
    identity
  };
}

function fieldEditorSnapshot() {
  if (!state.pendingField || els.stepFieldEditor.hidden) return null;
  const customTerm = els.customTermForm.hidden ? null : {
    description: els.customTermDescription.value,
    valueType: els.customTermValueType.value,
    example: els.customTermExample.value
  };
  const proposal = state.selectionProposal ? {
    summary: els.selectionProposalSummary.textContent,
    selector: els.selectionProposalSelector.textContent,
    coverage: els.selectionProposalCoverage.textContent
  } : null;
  return {
    key: state.pendingField.editingIdentity ? "identity" : (state.pendingField.editingSourceKey || `new:${state.activeBlockId || "block"}`),
    title: els.fieldEditorTitle.textContent,
    context: els.fieldEditorContext.textContent,
    status: els.fieldStatus.textContent,
    statusKind: els.fieldStatus.className.replace("status", "").trim(),
    selector: state.pendingField.selector || "",
    selectorEvidence: els.fieldSelectorEvidence.textContent,
    selectorCandidates: (state.pendingField.candidates || []).map((candidate) => ({ selector: candidate.selector, kind: candidate.kind, matchCount: candidate.matchCount })),
    name: els.fieldName.value,
    nameCandidates: (state.pendingField.semanticCandidates || []).slice(0, 80).map((candidate) => ({
      name: candidate.name,
      source: candidate.source || "schema",
      valueType: candidate.valueType || candidate.ranges?.join(" | ") || "Text",
      description: candidate.description || ""
    })),
    kind: els.fieldKind.value,
    attribute: els.fieldAttribute.value,
    multiple: els.fieldMultiple.checked,
    identity: els.fieldIdentity.checked,
    required: els.fieldRequired.checked,
    pipeline: selectedPipeline(),
    recommendedTransforms: recommendedTransformNames(),
    semanticStatus: els.fieldSemanticStatus.textContent,
    semanticKind: els.fieldSemanticStatus.className.replace("semantic-status", "").trim(),
    customTerm,
    proposal,
    preview: els.fieldPreview.textContent,
    submitLabel: els.addField.textContent
  };
}

function tablePanelSnapshot({ stale = false, clear = false } = {}) {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  return {
    pageUrl: state.pageUrl,
    inferenceReviewReady: !clear && inferenceReviewReady(),
    stale,
    driftReview: clear ? { status: "idle", findings: [], message: "" } : JSON.parse(JSON.stringify(state.driftReview)),
    activeBlockId: block?.id || null,
    structure: clear ? null : {
      selection: state.currentSelection ? JSON.parse(JSON.stringify(state.currentSelection)) : null,
      status: els.scopeStatus.textContent,
      statusKind: els.scopeStatus.className.replace("status", "").trim(),
      proposals: structureView?.snapshot() || [],
      pendingScope: state.pendingScope ? JSON.parse(JSON.stringify(state.pendingScope)) : null,
      blockName: els.blockName.value,
      schemaType: els.blockSchemaType.value
    },
    blocks: clear ? [] : state.blocks.map((candidate) => {
      const validation = ensureBlockComposition(candidate);
      return {
        id: candidate.id,
        name: candidate.name,
        schemaType: candidate.schemaType,
        matchCount: candidate.matchCount,
        unresolvedCount: variantTargets(candidate).reduce((total, target) => total + (target.fields || []).filter((field) => field.unresolved).length, 0),
        compositionValid: validation.ok,
        semanticsReviewed: candidate.semanticsReviewed !== false,
        compositionLabel: candidate.composition?.label || candidate.schemaType
      };
    }),
    activeBlock: !clear && block ? {
      id: block.id,
      name: block.name,
      schemaType: block.schemaType,
      scope: block.scope,
      matchCount: block.matchCount,
      composition: JSON.parse(JSON.stringify(block.composition)),
      compositionValidation: ensureBlockComposition(block),
      semanticsReviewed: block.semanticsReviewed !== false,
      semanticRanking: block.semanticRanking ? JSON.parse(JSON.stringify(block.semanticRanking)) : null,
      variantAnalysis: block.variantAnalysis ? JSON.parse(JSON.stringify(block.variantAnalysis)) : null,
      variants: block.variants ? JSON.parse(JSON.stringify(block.variants)) : null,
      activeVariantEntityName: entity?.entityName || null,
      discovery: {
        includeUnmapped: els.includeUnmappedFields.checked,
        canUndo: state.lastDiscoveryBatch?.blockId === block.id && state.lastDiscoveryBatch?.entityName === entity?.entityName,
        report: state.discoveryReport?.blockId === block.id ? { ...state.discoveryReport } : null
      },
      fields: [
        ...(entity?.fields || []).map((field) => panelFieldSnapshot(entity, field))
      ]
    } : null,
    rows: clear ? [] : state.tableRows
  };
}

function workflowState(snapshot = tablePanelSnapshot()) {
  if (!globalThis.Site2JsonEditorController) return null;
  return globalThis.Site2JsonEditorController.deriveWorkflow({ ...snapshot, validDefinition: Boolean(state.lastValidDefinition) });
}

function renderDiscoveryCompletion() {
  if (!els.discoveryComplete) return;
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  const fields = entity?.fields || [];
  const ready = block?.semanticsReviewed !== false && fields.length > 0;
  els.discoveryComplete.hidden = !ready;
  if (!ready) return;
  const unresolved = fields.filter((field) => field.unresolved).length;
  const mapped = fields.length - unresolved;
  els.discoveryCompleteTitle.textContent = `${entity.schemaType}: ${fields.length} discovered field${fields.length === 1 ? "" : "s"} ready to review`;
  const identity = entity.identity ? `“${entity.identityField}” is the canonical identity.` : "A canonical identity still needs to be chosen.";
  const decisions = unresolved
    ? `${unresolved} field${unresolved === 1 ? " needs" : "s need"} a semantic mapping decision in Review.`
    : "Every discovered field has a semantic mapping.";
  els.discoveryCompleteSummary.textContent = `${mapped} mapped · ${unresolved} unresolved. ${identity} ${decisions}`;
  els.continueReview.disabled = false;
}

function renderInferenceReviewBanner() {
  if (!els.inferenceReviewBanner) return;
  const ready = inferenceReviewReady();
  els.inferenceReviewBanner.hidden = !ready;
  if (!ready) return;
  els.inferenceReviewSummary.textContent = state.inferenceRun.summary
    || "Structure, semantic types, variants, and supported fields were inferred. Confirm the semantic model and inspect the field values before finishing.";
}

function reviewReadiness() {
  const targets = state.blocks.flatMap((block) => variantTargets(block).map((entity) => ({ block, entity })));
  const unreviewedBlocks = state.blocks.filter((block) => block.semanticsReviewed === false);
  const invalidBlocks = state.blocks.filter((block) => !ensureBlockComposition(block).ok);
  const unresolved = targets.flatMap(({ entity }) => entity.fields || []).filter((field) => field.unresolved);
  const missingFields = targets.filter(({ entity }) => !(entity.fields || []).length);
  const missingIdentity = targets.filter(({ entity }) => !entity.identity);
  return {
    ready: Boolean(targets.length) && !unreviewedBlocks.length && !invalidBlocks.length && !unresolved.length && !missingFields.length && !missingIdentity.length,
    targets,
    unreviewedBlocks,
    invalidBlocks,
    unresolved,
    missingFields,
    missingIdentity
  };
}

function renderReviewCompletion() {
  if (!els.reviewComplete) return;
  const review = reviewReadiness();
  els.reviewComplete.hidden = !review.targets.length;
  if (!review.targets.length) return;
  els.reviewComplete.classList.toggle("attention", !review.ready);
  els.continueFinish.disabled = !review.ready;
  if (review.ready) {
    const fieldCount = review.targets.reduce((total, { entity }) => total + entity.fields.length, 0);
    els.reviewCompleteLabel.textContent = "Review ready";
    els.reviewCompleteTitle.textContent = "Finish adapter details";
    els.reviewCompleteSummary.textContent = `${fieldCount} mapped field${fieldCount === 1 ? "" : "s"} across ${review.targets.length} result model${review.targets.length === 1 ? "" : "s"}. Semantic models, field mappings, and canonical identities are ready.`;
    return;
  }
  const blockers = [];
  if (review.unreviewedBlocks.length) blockers.push(`review Semantics for ${review.unreviewedBlocks.length} block${review.unreviewedBlocks.length === 1 ? "" : "s"}`);
  if (review.invalidBlocks.length) blockers.push(`repair ${review.invalidBlocks.length} invalid semantic model${review.invalidBlocks.length === 1 ? "" : "s"}`);
  if (review.unresolved.length) blockers.push(`map or delete ${review.unresolved.length} unresolved field${review.unresolved.length === 1 ? "" : "s"}`);
  if (review.missingFields.length) blockers.push(`discover fields for ${review.missingFields.length} result model${review.missingFields.length === 1 ? "" : "s"}`);
  if (review.missingIdentity.length) blockers.push(`choose an identity for ${review.missingIdentity.length} result model${review.missingIdentity.length === 1 ? "" : "s"}`);
  els.reviewCompleteLabel.textContent = "Review incomplete";
  els.reviewCompleteTitle.textContent = "Resolve the remaining decisions";
  els.reviewCompleteSummary.textContent = `Before continuing to Finish: ${blockers.join("; ")}.`;
}

function renderCorrectionPromotion() {
  if (!els.correctionPromotion) return;
  const proposal = state.pendingCorrectionPromotion;
  els.correctionPromotion.hidden = !proposal;
  if (!proposal) return;
  els.correctionPromotionSummary.textContent = proposal.fromProperty && proposal.fromProperty !== proposal.toProperty
    ? `You changed “${proposal.fromProperty}” to “${proposal.toProperty}”. Only reusable labels will be saved; selectors and rendered page content are excluded.`
    : `You mapped this value to “${proposal.toProperty}”. Only reusable labels will be saved; selectors and rendered page content are excluded.`;
  els.correctionPromotionChanges.replaceChildren(...proposal.changes.map((change) => {
    const item = document.createElement("li");
    item.textContent = change.operation === "add-alias"
      ? `Add “${change.value}” as an alias for ${change.termId}.`
      : `Mark “${change.value}” as an exclusion for ${change.termId}.`;
    return item;
  }));
  els.correctionPromotionWarning.hidden = !proposal.profileInfluenced;
  setStatus(els.correctionPromotionStatus, "", "Nothing changes until you confirm.");
}

function renderWizardProgressActions() {
  const route = state.route;
  const visibility = [
    [els.continueSemantics, route === "structure" && !els.structureComplete?.hidden],
    [els.confirmSemantics, route === "semantics"],
    [els.continueReview, route === "discover" && !els.discoveryComplete?.hidden],
    [els.continueFinish, route === "review" && !els.reviewComplete?.hidden]
  ];
  for (const [button, visible] of visibility) {
    if (button) button.hidden = !visible;
  }
  if (els.inferenceShortcut) els.inferenceShortcut.hidden = route === "finish";
}

function renderRoute() {
  if (!globalThis.document?.querySelectorAll) return;
  if (els.inferRemainingStatus && state.route === "finish") els.inferRemainingStatus.hidden = true;
  renderStructureCompletion();
  sidebarWorkflow?.render({ document, navigation: els.workflowSteps, route: state.route, workflow: workflowState() });
  semanticView?.render();
  compositionGraphView?.render();
  reviewView?.renderDrift(state.driftReview, canCheckStructuralHealth());
  semanticGraphView?.render();
  renderVariantContextControls();
  renderDiscoveryCompletion();
  renderInferenceReviewBanner();
  renderCorrectionPromotion();
  renderReviewCompletion();
  renderWizardProgressActions();
  renderStructureStartMode();
  if (state.blocks.length && !els.draftStatus.classList.contains("error") && !els.draftStatus.classList.contains("loading")) {
    setStatus(els.draftStatus, "", "Changes are autosaved in this working draft. Published extraction is unchanged.");
  }
  if (state.inferenceRun?.stage === "semantics" && state.inferenceRun.kind === "error" && !state.inferenceRun.stale) {
    semanticView?.setStatus("error", state.inferenceRun.message);
  }
}

function revealPanel(panel, focusTarget) {
  if (!panel) return;
  panel.hidden = false;
  if (focusTarget?.closest?.("#inference-shortcut")) focusTarget.hidden = false;
  panel.classList.add("attention-target");
  setTimeout(() => {
    panel.scrollIntoView?.({ block: "nearest" });
    focusTarget?.focus?.({ preventScroll: true });
  }, 0);
  setTimeout(() => panel.classList.remove("attention-target"), 1400);
}

function renderStructureCompletion() {
  if (!els.structureComplete) return;
  const block = activeBlock();
  const editingScope = Boolean(state.pendingScope) || !els.blockSetup.hidden;
  const shouldShow = Boolean(block) && !editingScope;
  els.structureComplete.hidden = !shouldShow;
  if (!shouldShow) return;
  els.stepScope.hidden = false;
  els.scopeHeading.textContent = "Extraction scope";
  els.scopeHint.textContent = "This scope is saved in your working draft.";
  els.scopeStatus.hidden = true;
  els.structureCompleteTitle.textContent = `“${block.name}” is ready for semantic review`;
  els.structureCompleteSummary.textContent = `${block.matchCount} matching item${block.matchCount === 1 ? "" : "s"} will be extracted as a collection of ${block.schemaType} items. Next, confirm what each item represents.`;
}

function updateStructureActionState() {
  if (!els.pickScope) return;
  const selection = state.currentSelection;
  const needsDraft = Boolean(draftRegistry) && !state.currentDraft;
  if (els.visualSelect) els.visualSelect.disabled = needsDraft;
  els.pickScope.disabled = needsDraft || !selection?.ok || Boolean(selection?.shadowBoundary);
  if (!els.structureGuidance) return;
  if (needsDraft) els.structureGuidance.textContent = "Choose or create a working draft above before defining page structure.";
  else if (!selection?.ok) els.structureGuidance.textContent = "Select one rendered item on the page to begin.";
  else if (!selection.shadowBoundary) els.structureGuidance.textContent = els.singleItemScope.checked
    ? "Single-item mode: select the detail item or its main content container."
    : "Selection ready. Find the repeated boundary surrounding this example item.";
  else els.structureGuidance.textContent = "";
}

function applyEditorLease(owner) {
  editorLeaseOwner = owner === "expanded" ? "expanded" : "sidebar";
  const expanded = editorLeaseOwner === "expanded";
  document.body.classList.toggle("workspace-expanded", expanded);
  if (els.expandedWorkspaceBridge) els.expandedWorkspaceBridge.hidden = !expanded;
  els.openTablePanel.textContent = expanded ? "Editor expanded" : "Expand editor";
  els.openTablePanel.disabled = expanded;
}

function requestEditorLease(owner) {
  postTablePanel({ type: "lease-command", owner });
}

function navigateWorkflow(step) {
  if (!sidebarWorkflow?.validRoute(step)) return;
  if (editorLeaseOwner === "expanded") requestEditorLease("sidebar");
  if (step === "finish") ensureSuggestedNamespace();
  state.route = step;
  renderRoute();
  if (step === "review" && state.lastValidDefinition && state.driftReview.status === "idle") {
    checkStructuralHealth().catch(() => {});
  }
  const target = document.querySelector(`[data-editor-route="${step}"]:not(.route-inactive)`);
  setTimeout(() => target?.scrollIntoView({ block: "start" }), 0);
}

function suggestedNamespace(adapterId = els.adapterId.value) {
  const normalized = String(adapterId || "").trim().toLowerCase();
  return /^[a-z][a-z0-9-]*$/.test(normalized) ? `https://site2json.dev/ns/${normalized}#` : "";
}

function ensureSuggestedNamespace() {
  const suggestion = suggestedNamespace();
  const canReplace = !els.adapterNamespace.value.trim() || els.adapterNamespace.dataset.suggested === "true";
  if (!suggestion || !canReplace) return false;
  els.adapterNamespace.value = suggestion;
  els.adapterNamespace.dataset.suggested = "true";
  return true;
}

function syncNamespaceSuggestionState() {
  els.adapterNamespace.dataset.suggested = els.adapterNamespace.value.trim() === suggestedNamespace() ? "true" : "false";
}

function ensureSuggestedAdapterMetadata(pageUrl = state.pageUrl) {
  if (!els.adapterId.value.trim() && pageUrl) {
    try {
      const hostname = new URL(pageUrl).hostname.replace(/^www\./, "");
      els.adapterId.value = hostname.split(".")[0].toLowerCase().replace(/[^a-z0-9-]/g, "");
    } catch { /* Metadata remains explicitly editable in Finish. */ }
  }
  ensureSuggestedNamespace();
}

function postTablePanel(message) {
  try { tablePanelPort?.postMessage(message); } catch { /* The panel can close between render and send. */ }
}

function publishTablePanel(options) {
  const snapshot = tablePanelSnapshot(options);
  postTablePanel({ type: "table-snapshot", snapshot, validDefinition: Boolean(state.lastValidDefinition) });
  postTablePanel({
    type: "editor-snapshot",
    sessionId: editorClientSessionId,
    revision: ++editorSourceRevision,
    editor: controllerEditorSnapshot()
  });
  renderRoute();
}

function controllerEditorSnapshot() {
  const draft = editorSnapshot();
  return {
    ...JSON.parse(JSON.stringify(draft)),
    activeBlockId: state.activeBlockId,
    currentDraftId: state.currentDraft?.id || null,
    currentAdapterId: state.currentDraft?.adapterId || null,
    hasValidDefinition: Boolean(state.lastValidDefinition),
    unresolvedFieldCount: state.blocks.reduce((total, block) => total + variantTargets(block).reduce((sum, entity) => sum + (entity.fields || []).filter((field) => field.unresolved).length, 0), 0),
    finish: {
      adapterId: els.adapterId.value,
      namespace: els.adapterNamespace.value,
      pageId: els.pageId.value,
      pageType: els.pageType.value,
      valid: Boolean(state.lastValidDefinition),
      canSave: Boolean(state.currentDraft),
      canExport: Boolean(state.currentDraft && state.lastValidDefinition),
      canPublish: Boolean(state.currentDraft && state.lastValidDefinition),
      canCaptureFixture: Boolean(state.lastValidDefinition),
      canCheckStructuralHealth: canCheckStructuralHealth(),
      canInferRemaining: Boolean(state.currentDraft && !state.inferenceRunning),
      buildStatus: els.buildStatus.textContent,
      buildStatusKind: els.buildStatus.className.replace("status", "").trim(),
      draftStatus: els.draftStatus.textContent,
      draftStatusKind: els.draftStatus.className.replace("status", "").trim(),
      preview: els.extractionOutput.textContent
    },
    route: state.pendingField && !els.stepFieldEditor.hidden ? "field" : "review",
    fieldEditor: fieldEditorSnapshot()
  };
}

function commandField(command) {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  if (!entity) return null;
  if (command.identity || command.fieldKey === "identity") return entity.identity ? { ...entity.identity, identity: true } : null;
  return entity.fields.find((field) => Site2JsonFieldDiscovery.sourceKey(field) === command.fieldKey) || null;
}

async function applySemanticModel(modelId) {
  await handleTablePanelCommand({ action: "set-semantic-model", modelId });
  publishTablePanel();
}

async function analyzeSemanticModel() {
  await handleTablePanelCommand({ action: "analyze-semantics" });
  semanticGraphView?.render();
  publishTablePanel();
}

async function analyzeBlockSemanticEvidence(block) {
  if (!block || !semanticRanking) throw new Error("Select a block before analyzing its semantic model.");
  block.semanticRanking = { status: "loading" };
  block.variantAnalysis = { status: "loading" };
  publishTablePanel();
  await ensureSemanticLibraryInference();
  const [result, itemResult] = await Promise.all([
    Site2JsonBridge.run(bridgeDiscoverFields, { scopeSelector: block.scope }),
    Site2JsonBridge.run(bridgeDiscoverVariantItems, { scopeSelector: block.scope, ...FAST_VARIANT_SCAN })
  ]);
  if (!result.ok) throw new Error(result.message || "Could not inspect the extraction scope.");
  const semantic = analyzeSemanticCandidates(result.candidates, {
    sampledScopes: result.sampledScopes,
    totalScopes: result.totalScopes,
    truncated: Boolean(result.truncated)
  });
  block.semanticRanking = semantic.ranking;
  block.semanticRecommendation = semantic.recommendation;
  // Per-item analysis only needs to distinguish plausible models from this
  // page. Re-ranking every card against the complete catalog made this action
  // grow with catalog size instead of page size.
  block.variantAnalysis = analyzeVariantItems(block, itemResult, block.semanticRanking, "refresh");
  if (block.variantAnalysis?.candidates?.length > 1) await refreshVariantClassification();
  invalidateBuiltDraft();
  return { recommendation: semantic.recommendation, observations: result.candidates, variantAnalysis: block.variantAnalysis };
}

function variantCandidateTypes(schemaType, ...rankings) {
  const types = [schemaType];
  for (const ranking of rankings) {
    for (const candidate of ranking?.types || []) types.push(candidate.schemaType || String(candidate.id || "").replace(/^schema:/, ""));
    for (const candidate of (ranking?.compositions || []).slice(0, 6)) {
      let composition = null;
      try { composition = semanticCompositions?.preset(candidate.id); } catch { composition = null; }
      const root = composition?.nodes?.[composition.root];
      types.push(candidate.schemaType, ...(root?.types || []));
    }
  }
  return [...new Set(types.filter((type) => type && (Site2JsonSchemaVocabulary.typeInfo(type) || semanticLibraryInference?.hasType(type))))].slice(0, 16);
}

function analyzeVariantItems(block, itemResult, ranking = block?.semanticRanking, source = "initial") {
  if (!itemResult?.ok || !variantAnalysis) {
    return { status: "error", message: itemResult?.message || "Could not analyze individual items.", source };
  }
  const started = typeof performance === "object" && performance.now ? performance.now() : Date.now();
  const pooled = new Map();
  for (const item of itemResult.items || []) {
    for (const candidate of item.candidates || []) {
      const key = [candidate.selector, candidate.attribute || "", candidate.kind || "text"].join("\u001f");
      if (!pooled.has(key)) pooled.set(key, candidate);
      if (pooled.size >= 160) break;
    }
    if (pooled.size >= 160) break;
  }
  // One catalog-wide pass over the de-duplicated page evidence can surface a
  // minority type that the first/aggregate item did not contain. Individual
  // items are then scored only against that small candidate set.
  const inferenceRanking = semanticLibraryInference || semanticRanking;
  const pooledRanking = inferenceRanking?.rank([...pooled.values()], { typeLimit: 12 }) || null;
  const analysis = variantAnalysis.analyze(itemResult.items || [], {
    ranking: inferenceRanking,
    candidateTypes: variantCandidateTypes(block.schemaType, pooledRanking, ranking),
    fallbackType: block.inferenceSchemaType || block.schemaType
  });
  if (block.semanticModelId && block.inferenceSchemaType && block.inferenceSchemaType !== block.schemaType) {
    for (const candidate of analysis.candidates || []) if (candidate.modelId === block.semanticModelId) candidate.schemaType = block.schemaType;
    for (const row of analysis.rows || []) {
      if (row.winner?.modelId === block.semanticModelId) row.winner.schemaType = block.schemaType;
      for (const alternate of row.alternatives || []) if (alternate.modelId === block.semanticModelId) alternate.schemaType = block.schemaType;
    }
  }
  const finished = typeof performance === "object" && performance.now ? performance.now() : Date.now();
  return {
    ...analysis,
    source,
    totalItems: itemResult.totalScopes,
    durationMs: Math.round(((Number(itemResult.durationMs) || 0) + finished - started) * 10) / 10
  };
}

function uniqueVariantEntityName(block, type, used) {
  const stem = `${String(type || "Thing").replace(/[^A-Za-z0-9_]/g, "") || "Thing"}Result`;
  let name = stem;
  let suffix = 2;
  while (used.has(name) || name === block.entityName) name = `${stem}${suffix++}`;
  used.add(name);
  return name;
}

async function applyVariantSuggestions() {
  const block = activeBlock();
  const analysis = block?.variantAnalysis;
  if (!block || !analysis?.mixed) throw new Error("Analyze a mixed result list before enabling variants.");
  const used = new Set(state.blocks.flatMap((candidate) => [
    candidate.entityName,
    ...(candidate.variants?.candidates || []).map((variant) => variant.entityName)
  ]));
  const proposed = analysis.candidates
    .filter((candidate) => candidate.schemaType !== block.schemaType)
    .slice(0, 5);
  const candidates = [];
  for (const candidate of proposed) {
    const localized = semanticLibraryInference?.materialize(candidate.modelId, {
      adapterPrefix: adapterPrefix(),
      existingTerms: state.customTerms
    }) || null;
    if (localized) state.customTerms = localized.customTerms;
    const schemaType = localized?.schemaType || candidate.schemaType;
    candidates.push({
      entityName: uniqueVariantEntityName(block, schemaType, used),
      schemaType,
      ...(localized ? { semanticModelId: candidate.modelId, inferenceSchemaType: localized.inferenceSchemaType } : {}),
      evidence: candidate.evidence.map((rule) => ({ ...rule })),
      identityField: block.identityField || null,
      fields: JSON.parse(JSON.stringify(block.fields || [])),
      requireFields: [...(block.requireFields || [])],
      monitorFields: [...(block.monitorFields || [])]
    });
  }
  if (!candidates.length) throw new Error("No alternate result type was detected in the current sample.");
  block.variants = {
    minScore: analysis.thresholds.minScore,
    minMargin: analysis.thresholds.minMargin,
    candidates
  };
  state.activeVariantEntityName = block.entityName;
  renderVariantContextControls();
  block.semanticsReviewed = false;
  invalidateBuiltDraft();
  semanticView?.render();
  await refreshBlockTable();
  await refreshVariantClassification();
  publishTablePanel();
}

async function clearVariantSuggestions() {
  const block = activeBlock();
  if (!block?.variants) return;
  delete block.variants;
  state.activeVariantEntityName = block.entityName;
  renderVariantContextControls();
  block.semanticsReviewed = false;
  invalidateBuiltDraft();
  semanticView?.render();
  await refreshBlockTable();
  block.variantClassification = null;
  publishTablePanel();
}

function variantClassificationDefinition(block) {
  const analyzed = block?.variantAnalysis?.candidates || [];
  const saved = block?.variants?.candidates || [];
  const candidates = analyzed
    .filter((candidate) => candidate.schemaType !== block.schemaType)
    .map((candidate) => saved.find((item) => item.schemaType === candidate.schemaType) || candidate);
  for (const candidate of saved) if (!candidates.some((item) => item.schemaType === candidate.schemaType)) candidates.push(candidate);
  const compiled = new Map((Site2JsonAdapterDefinition.compileVariantSignals?.(candidates) || []).map((item) => [item.entityName, item.signals]));
  return {
    minScore: block?.variants?.minScore ?? block?.variantAnalysis?.thresholds?.minScore ?? 6,
    minMargin: block?.variants?.minMargin ?? block?.variantAnalysis?.thresholds?.minMargin ?? 2,
    candidates: candidates.map((candidate) => ({ ...candidate, signals: compiled.get(candidate.entityName) || candidate.signals || [] }))
  };
}

async function refreshVariantClassification() {
  const block = activeBlock();
  const variants = block ? variantClassificationDefinition(block) : null;
  if (!block || !variants?.candidates?.length) return null;
  block.variantClassification = { status: "loading" };
  semanticGraphView?.render();
  const result = await Site2JsonBridge.run(bridgeClassifyVariantItems, {
    scopeSelector: block.scope,
    fallbackEntity: block.entityName,
    schemaType: block.schemaType,
    variants
  }).catch((error) => ({ ok: false, message: error.message }));
  block.variantClassification = result.ok ? { status: "ready", ...result } : { status: "error", message: result.message || "Could not classify rendered results." };
  const unresolvedRows = result.ok ? (result.rows || []).filter((row) => row.status !== "classified" && !variantFallbackAccepted(block, null, row.classification)) : [];
  attention?.sync?.(`root-variants:${block.id}`, unresolvedRows.length ? [{
    id: `root-variant:${block.id}`,
    severity: "error",
    message: `${unresolvedRows.length} sampled result${unresolvedRows.length === 1 ? " needs" : "s need"} distinguishing evidence or an accepted fallback.`,
    destination: {
      kind: "variant-evidence", screen: "semantics", blockId: block.id,
      candidateType: unresolvedRows[0]?.alternatives?.[0]?.schemaType || null,
      rootIndex: unresolvedRows[0]?.index ?? null, action: "resolve-evidence", section: "variant-types"
    }
  }] : []);
  semanticGraphView?.render();
  publishTablePanel();
  return block.variantClassification;
}

function nestedVariantSlotAlias(block, path) {
  return Object.keys(block?.composition?.nodes || {}).find((alias) => compositionNodePath(block.composition, alias) === path) || null;
}

function variantFallbackAccepted(block, slotPath, classification) {
  if (!classification?.classificationFingerprint || !classification?.configurationDigest) return false;
  return (block?.fallbackAcceptances || []).some((receipt) =>
    (receipt.slotPath || null) === (slotPath || null)
    && receipt.classificationFingerprint === classification.classificationFingerprint
    && receipt.configurationDigest === classification.configurationDigest
  );
}

function nestedVariantClassificationDefinitions(block) {
  const stored = new Map((block?.variantSlots || []).map((slot) => [slot.path, slot]));
  let slots = Object.values(block?.composition?.nodes || {}).some((node) => node.variants?.candidates?.length)
    ? nestedVariantSlots(block)
    : [...stored.values()];
  slots = slots.map((slot) => {
    const previous = stored.get(slot.path);
    if (!previous) return slot;
    return {
      ...slot,
      candidates: slot.candidates.map((candidate) => ({
        ...candidate,
        evidence: JSON.parse(JSON.stringify(previous.candidates.find((item) => item.schemaType === candidate.schemaType)?.evidence || candidate.evidence || []))
      }))
    };
  });
  block.variantSlots = JSON.parse(JSON.stringify(slots));
  return slots.map((slot) => ({
    path: slot.path,
    nodeAlias: nestedVariantSlotAlias(block, slot.path),
    runtime: Site2JsonAdapterDefinition.compileVariantSlotRuntime(slot)
  }));
}

async function refreshNestedVariantClassification(block = activeBlock(), slotPath = null) {
  if (!block) return null;
  const previousSlots = block.nestedVariantClassification?.status === "ready"
    ? block.nestedVariantClassification.slots || []
    : [];
  let slots;
  try {
    slots = nestedVariantClassificationDefinitions(block).filter((entry) => !slotPath || entry.path === slotPath);
  } catch (error) {
    block.nestedVariantClassification = { status: "pending", message: error.message, slots: [] };
    return block.nestedVariantClassification;
  }
  if (!slots.length) {
    block.nestedVariantClassification = null;
    attention?.sync?.(`nested-variants:${block.id}`, []);
    return null;
  }
  block.nestedVariantClassification = { status: "loading", slots: [] };
  const result = await Site2JsonBridge.run(bridgeClassifyNestedVariantSlots, { scopeSelector: block.scope, slots })
    .catch((error) => ({ ok: false, message: error.message }));
  const mergedSlots = result.ok && slotPath
    ? [...previousSlots.filter((slot) => slot.path !== slotPath), ...result.slots]
    : (result.slots || []);
  block.nestedVariantClassification = result.ok
    ? { status: "ready", ...result, slots: mergedSlots }
    : { status: "error", message: result.message || "Could not classify nested variant slots.", slots: [] };
  const issues = result.ok ? mergedSlots.flatMap((slot) => {
    const unresolvedRows = slot.rows.filter((row) => row.status !== "classified" && !variantFallbackAccepted(block, slot.path, row.classification));
    const unresolved = unresolvedRows.length;
    if (!unresolved) return [];
    const first = unresolvedRows[0];
    return [{
      id: `nested-variant:${block.id}:${slot.path}`,
      severity: "error",
      message: `${slot.path}: ${unresolved} of ${slot.sampled} sampled nested values need distinguishing evidence.`,
      destination: {
        kind: "variant-evidence", screen: "semantics", blockId: block.id,
        nodeAlias: slot.nodeAlias, slotPath: slot.path,
        candidateType: first?.alternatives?.[0]?.schemaType || null,
        rootIndex: first?.rootIndex ?? null, action: "resolve-evidence", section: "variant-types"
      }
    }];
  }) : [{
    id: `nested-variant:${block.id}:classification-error`, severity: "error",
    message: block.nestedVariantClassification.message,
    destination: { kind: "variant-evidence", screen: "semantics", blockId: block.id, action: "review-classification" }
  }];
  attention?.sync?.(`nested-variants:${block.id}`, issues);
  compositionGraphView?.render?.();
  publishTablePanel();
  return block.nestedVariantClassification;
}

async function addVariantEvidence(schemaType, rootIndex = null) {
  const block = activeBlock();
  if (block && schemaType === block.schemaType) throw new Error(`${block.schemaType} is the fallback. Add evidence only when assigning an alternate result type.`);
  let savedCandidate = block?.variants?.candidates?.find((candidate) => candidate.schemaType === schemaType);
  const analysisCandidate = block?.variantAnalysis?.candidates?.find((candidate) => candidate.schemaType === schemaType) || savedCandidate;
  if (!block || !analysisCandidate) throw new Error("Choose an alternate result type before adding evidence.");
  const result = await Site2JsonBridge.run(bridgeCaptureVariantEvidence, { scopeSelector: block.scope, ...(Number.isSafeInteger(rootIndex) ? { rootIndex } : {}) });
  if (!result.ok) throw new Error(result.message || "Could not turn the current selection into classification evidence.");
  const key = JSON.stringify(result.rule);
  if (!(analysisCandidate.evidence || []).some((rule) => JSON.stringify(rule) === key)) analysisCandidate.evidence = [...(analysisCandidate.evidence || []), result.rule];
  if (block.variants && !savedCandidate) {
    const used = new Set(variantTargets(block).map((candidate) => candidate.entityName));
    savedCandidate = {
      entityName: uniqueVariantEntityName(block, schemaType, used),
      schemaType,
      evidence: [],
      identityField: block.identityField || null,
      fields: JSON.parse(JSON.stringify(block.fields || [])),
      requireFields: [...(block.requireFields || [])],
      monitorFields: [...(block.monitorFields || [])]
    };
    block.variants.candidates.push(savedCandidate);
    renderVariantContextControls();
  }
  if (savedCandidate && !(savedCandidate.evidence || []).some((rule) => JSON.stringify(rule) === key)) savedCandidate.evidence.push({ ...result.rule });
  invalidateBuiltDraft();
  await refreshVariantClassification();
  semanticGraphView?.render();
  semanticGraphView?.elements && (semanticGraphView.elements.status.textContent = `Added evidence for ${schemaType}: ${result.label}. It will not be included in extracted JSON.`);
  publishTablePanel();
}

async function addNestedVariantEvidence({ slotPath, schemaType, rootIndex }) {
  const block = activeBlock();
  if (!block || !slotPath) throw new Error("The nested variant slot is no longer available.");
  nestedVariantClassificationDefinitions(block);
  const slot = block.variantSlots?.find((candidate) => candidate.path === slotPath);
  const candidate = slot?.candidates?.find((item) => item.schemaType === schemaType);
  if (!slot || !candidate) throw new Error(`Choose a candidate type configured for ${slotPath}.`);
  const result = await Site2JsonBridge.run(bridgeCaptureVariantEvidence, {
    scopeSelector: block.scope,
    ...(Number.isSafeInteger(rootIndex) ? { rootIndex } : {})
  });
  if (!result.ok) throw new Error(result.message || "Could not turn the current selection into nested classification evidence.");
  const key = JSON.stringify(result.rule);
  if (!(candidate.evidence || []).some((rule) => JSON.stringify(rule) === key)) candidate.evidence = [...(candidate.evidence || []), { ...result.rule }];
  const alias = nestedVariantSlotAlias(block, slotPath);
  const authoredCandidate = block.composition?.nodes?.[alias]?.variants?.candidates?.find((item) => item.type === schemaType);
  if (authoredCandidate && !(authoredCandidate.evidence || []).some((rule) => JSON.stringify(rule) === key)) {
    authoredCandidate.evidence = [...(authoredCandidate.evidence || []), { ...result.rule }];
  }
  invalidateBuiltDraft();
  await refreshNestedVariantClassification(block, slotPath);
  publishTablePanel();
  return result;
}

async function resolveVariantEvidence(context) {
  if (context?.slotPath) return addNestedVariantEvidence(context);
  return addVariantEvidence(context?.schemaType, context?.rootIndex);
}

async function acceptVariantFallback(context) {
  const block = activeBlock();
  const classification = context?.row?.classification;
  if (!block || !classification?.classificationFingerprint || !classification?.configurationDigest) {
    throw new Error("This result has no stable classification shape to accept. Refresh item types and try again.");
  }
  const slot = context.slotPath ? block.variantSlots?.find((item) => item.path === context.slotPath) : null;
  const receipt = {
    slotPath: context.slotPath || null,
    classificationFingerprint: classification.classificationFingerprint,
    configurationDigest: classification.configurationDigest,
    fallbackEntity: slot?.fallback?.entityName || slot?.fallback || block.entityName,
    acceptedAt: new Date().toISOString()
  };
  const receipts = (block.fallbackAcceptances || []).filter((item) => !(
    (item.slotPath || null) === receipt.slotPath
    && item.classificationFingerprint === receipt.classificationFingerprint
    && item.configurationDigest === receipt.configurationDigest
  ));
  block.fallbackAcceptances = [...receipts, receipt].slice(-128);
  invalidateBuiltDraft();
  if (context.slotPath) await refreshNestedVariantClassification(block, context.slotPath);
  else await refreshVariantClassification();
  publishTablePanel();
}

async function openVariantEvidenceDestination(destination) {
  if (destination?.blockId && activeBlock()?.id !== destination.blockId) await activateBlock(destination.blockId, { pin: false });
  const block = activeBlock();
  if (!block) return false;
  navigateWorkflow("semantics");
  document.querySelector("#close-semantic-graph")?.click?.();
  semanticGraphView?.render();
  if (destination.slotPath) {
    if (block.nestedVariantClassification?.status !== "ready") await refreshNestedVariantClassification(block, destination.slotPath);
    const slotReport = block.nestedVariantClassification?.slots?.find((slot) => slot.path === destination.slotPath);
    const row = slotReport?.rows?.find((candidate) => candidate.rootIndex === destination.rootIndex)
      || slotReport?.rows?.find((candidate) => candidate.status !== "classified");
    const slot = block.variantSlots?.find((candidate) => candidate.path === destination.slotPath);
    if (!row || !slot) return false;
    return semanticGraphView?.openResolver?.({
      kind: "nested", row, slotPath: destination.slotPath, nodeAlias: destination.nodeAlias,
      rootIndex: row.rootIndex, candidateType: destination.candidateType,
      candidates: slot.candidates.map((candidate) => ({ entityName: candidate.entityName, schemaType: candidate.schemaType }))
    }) || false;
  }
  const row = block.variantClassification?.rows?.find((candidate) => candidate.index === destination.rootIndex)
    || block.variantClassification?.rows?.find((candidate) => candidate.status !== "classified");
  if (!row) return false;
  return semanticGraphView?.openResolver?.({ kind: "root", row, rootIndex: row.index, candidateType: destination.candidateType }) || false;
}

async function confirmSemanticModel() {
  await handleTablePanelCommand({ action: "finish-semantics" });
  publishTablePanel();
  navigateWorkflow("discover");
}

function customRelationshipDefinition(command, sourceTypes, targetTypes) {
  if (!command.customTerm) return null;
  const name = String(command.property || "").trim();
  const prefix = adapterPrefix();
  if (!prefix) throw new Error("Set the adapter id before creating custom vocabulary.");
  if (!name.startsWith(`${prefix}:`) || !/^[a-z][a-z0-9-]*:[A-Za-z][A-Za-z0-9_-]*$/.test(name)) {
    throw new Error(`Custom relationships must use the adapter prefix, for example ${prefix}:editor.`);
  }
  const description = String(command.customTerm.description || "").trim();
  if (!description) throw new Error("Describe what the custom relationship means.");
  const evidenceAliases = String(command.customTerm.evidenceAliases || "").split(",").map((value) => value.trim()).filter(Boolean);
  const definition = {
    description,
    valueType: targetTypes[0],
    cardinality: "one",
    example: String(command.customTerm.example || evidenceAliases[0] || command.alias || command.to || targetTypes[0]),
    kind: "relationship",
    domainIncludes: [...new Set(sourceTypes)],
    rangeIncludes: [...new Set(targetTypes)],
    evidenceAliases: [...new Set([name.split(":").at(-1), ...evidenceAliases])]
  };
  const existing = state.customTerms[name];
  if (existing && (existing.kind !== "relationship" || JSON.stringify(existing.domainIncludes || []) !== JSON.stringify(definition.domainIncludes) || JSON.stringify(existing.rangeIncludes || []) !== JSON.stringify(definition.rangeIncludes))) {
    throw new Error(`${name} is already defined with a different meaning in this draft.`);
  }
  return {
    name,
    definition: existing || definition
  };
}

async function handleTablePanelCommand(command) {
  if (!command || typeof command.action !== "string") return;
  if (command.action === "activate-block") {
    await activateBlock(command.blockId, { pin: false });
  } else if (command.action === "highlight") {
    pinTarget(command.target);
    await revealTarget(command.target);
  } else if (command.action === "scroll-to-target") {
    pinTarget(command.target);
    await revealTarget({ ...command.target, scrollIntoView: true });
  } else if (command.action === "preview-highlight") {
    await highlightTarget(command.target, "transient");
  } else if (command.action === "clear-preview") {
    clearHighlight("transient");
  } else if (command.action === "clear-highlight") {
    clearPinnedHighlight();
  } else if (command.action === "check-structural-health") {
    await checkStructuralHealth();
  } else if (command.action === "open-structural-finding") {
    await openStructuralFinding(command.finding);
  } else if (command.action === "edit-field") {
    const field = commandField(command);
    if (field) await editField(field, { identity: Boolean(field.identity) });
  } else if (command.action === "remove-field") {
    const field = commandField(command);
    if (field) await removeField(field);
  } else if (command.action === "add-selected-field") {
    await pickField();
  } else if (command.action === "use-selection-proposal") {
    await useSelectionProposal();
  } else if (command.action === "preview-field-form") {
    if (state.pendingField) {
      applyExpandedFieldForm(command.form || {}, { chooseSemanticDefaults: Boolean(command.chooseSemanticDefaults) });
      await refreshFieldPreview();
    }
  } else if (command.action === "save-field-form") {
    applyExpandedFieldForm(command.form || {}, { chooseSemanticDefaults: Boolean(command.chooseSemanticDefaults) });
    await addField();
  } else if (command.action === "cancel-field") {
    cancelField();
  } else if (command.action === "set-semantic-model") {
    const block = activeBlock();
    if (block) {
      await ensureSemanticLibraryInference();
      const localized = semanticLibraryInference?.materialize(command.modelId, { adapterPrefix: adapterPrefix(), existingTerms: state.customTerms }) || null;
      const composition = localized?.composition || (String(command.modelId || "").startsWith("schema:")
        ? semanticCompositions.singleType(String(command.modelId).slice("schema:".length))
        : semanticCompositions.preset(command.modelId));
      const nextCustomTerms = localized?.customTerms || state.customTerms;
      const validation = semanticCompositions.validate(composition, nextCustomTerms);
      if (!validation.ok) throw new Error(validation.errors.join(" "));
      block.composition = composition;
      block.schemaType = composition.nodes[composition.root].types[0];
      if (localized) {
        state.customTerms = nextCustomTerms;
        block.semanticModelId = command.modelId;
        block.inferenceSchemaType = localized.inferenceSchemaType || block.schemaType;
      } else {
        delete block.semanticModelId;
        delete block.inferenceSchemaType;
      }
      delete block.semanticRecommendation;
      block.semanticsReviewed = false;
      invalidateBuiltDraft();
      renderBlockTabs();
    }
  } else if (command.action === "add-semantic-node") {
    const block = activeBlock();
    if (block) {
      if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(String(command.alias || ""))) throw new Error("Node aliases must start with a letter and contain only letters, numbers, _ or -.");
      const next = JSON.parse(JSON.stringify(block.composition));
      if (next.nodes[command.alias]) throw new Error(`Node alias ${command.alias} already exists.`);
      next.nodes[command.alias] = { types: [command.type], expectation: command.expectation || "optional" };
      next.edges.push({ from: command.from, property: command.property, to: command.alias, expectation: command.expectation || "optional" });
      const custom = customRelationshipDefinition(command, next.nodes[command.from]?.types || [], [command.type]);
      const previousCustom = custom ? state.customTerms[custom.name] : undefined;
      if (custom) state.customTerms[custom.name] = custom.definition;
      const validation = semanticCompositions.validate(next, state.customTerms);
      if (!validation.ok) {
        if (custom && previousCustom) state.customTerms[custom.name] = previousCustom;
        else if (custom) delete state.customTerms[custom.name];
        throw new Error(validation.errors.join(" "));
      }
      block.composition = next;
      block.semanticsReviewed = false;
      invalidateBuiltDraft();
    }
  } else if (command.action === "replace-semantic-composition") {
    const block = activeBlock();
    if (block) {
      const next = JSON.parse(JSON.stringify(command.composition));
      const nextCustomTerms = command.customTerms
        ? JSON.parse(JSON.stringify(command.customTerms))
        : state.customTerms;
      const validation = semanticCompositions.validate(next, nextCustomTerms);
      if (!validation.ok) throw new Error(validation.errors.join(" "));
      block.composition = next;
      state.customTerms = nextCustomTerms;
      block.schemaType = next.nodes[next.root].types[0];
      block.semanticsReviewed = false;
      invalidateBuiltDraft();
      renderBlockTabs();
    }
  } else if (command.action === "add-semantic-edge") {
    const block = activeBlock();
    if (block) {
      const next = JSON.parse(JSON.stringify(block.composition));
      if (!next.nodes[command.from] || !next.nodes[command.to]) throw new Error("Choose existing source and target nodes.");
      next.edges.push({ from: command.from, property: command.property, to: command.to, expectation: command.expectation || "optional" });
      const custom = customRelationshipDefinition(command, next.nodes[command.from].types, next.nodes[command.to].types);
      const previousCustom = custom ? state.customTerms[custom.name] : undefined;
      if (custom) state.customTerms[custom.name] = custom.definition;
      const validation = semanticCompositions.validate(next, state.customTerms);
      if (!validation.ok) {
        if (custom && previousCustom) state.customTerms[custom.name] = previousCustom;
        else if (custom) delete state.customTerms[custom.name];
        throw new Error(validation.errors.join(" "));
      }
      block.composition = next;
      block.semanticsReviewed = false;
      invalidateBuiltDraft();
    }
  } else if (command.action === "remove-semantic-edge") {
    const block = activeBlock();
    if (block) {
      block.composition = semanticCompositions.removeEdge(block.composition, Number(command.index));
      const validation = semanticCompositions.validate(block.composition, state.customTerms);
      if (!validation.ok) throw new Error(validation.errors.join(" "));
      block.semanticsReviewed = false;
      invalidateBuiltDraft();
    }
  } else if (command.action === "remove-semantic-node") {
    const block = activeBlock();
    if (block && command.alias !== block.composition.root) {
      block.composition = semanticCompositions.removeNode(block.composition, command.alias);
      block.semanticsReviewed = false;
      invalidateBuiltDraft();
    }
  } else if (command.action === "add-semantic-type") {
    const block = activeBlock();
    const node = block?.composition.nodes[command.alias];
    if (node && !node.types.includes(command.type)) {
      if (!semanticCompositions.singleType(command.type)) return;
      node.types.push(command.type);
      block.semanticsReviewed = false;
      invalidateBuiltDraft();
    }
  } else if (command.action === "remove-semantic-type") {
    const block = activeBlock();
    const node = block?.composition.nodes[command.alias];
    if (node && node.types.length > 1) {
      node.types = node.types.filter((type) => type !== command.type);
      if (command.alias === block.composition.root) block.schemaType = node.types[0];
      block.semanticsReviewed = false;
      invalidateBuiltDraft();
    }
  } else if (command.action === "finish-semantics") {
    const block = activeBlock();
    const validation = block ? semanticCompositions.validate(block.composition, state.customTerms) : { ok: false, errors: ["Select a block first."] };
    if (!validation.ok) throw new Error(validation.errors.join(" "));
    block.semanticsReviewed = true;
    invalidateBuiltDraft();
  } else if (command.action === "analyze-semantics") {
    const block = activeBlock();
    await analyzeBlockSemanticEvidence(block);
  } else if (command.action === "discover-fields") {
    els.includeUnmappedFields.checked = command.includeUnmapped !== false;
    await discoverFields({ includeUnmapped: els.includeUnmappedFields.checked });
  } else if (command.action === "undo-discovery") {
    await undoDiscovery();
  } else if (command.action === "infer-scope") {
    await pickScope({ allowSingle: command.allowSingle === true });
  } else if (command.action === "find-page-scopes") {
    await findPageScopes();
  } else if (command.action === "preview-scope") {
    structureView?.preview(Number(command.index));
  } else if (command.action === "accept-scope") {
    await acceptScope(command.selector);
  } else if (command.action === "create-block") {
    els.blockName.value = String(command.name || "");
    els.blockSchemaType.value = String(command.schemaType || "Thing");
    if (!await createBlock()) throw new Error(els.scopeStatus.textContent || "Could not create the block.");
  } else if (command.action === "cancel-scope") {
    cancelBlockSetup();
  } else if (command.action === "update-finish-metadata") {
    applyFinishMetadata(command.metadata);
    invalidateBuiltDraft();
  } else if (command.action === "build-draft") {
    if (command.metadata) applyFinishMetadata(command.metadata);
    await buildDraft();
  } else if (command.action === "refresh-structural-baseline") {
    if (command.metadata) applyFinishMetadata(command.metadata);
    await buildDraft({ refreshBaseline: true });
  } else if (command.action === "capture-fixture") {
    await captureFixture();
  } else if (command.action === "automatic-convert") {
    await automaticConvert();
  } else if (command.action === "infer-remaining") {
    await inferRemainingSteps();
  } else if (command.action === "preview-extraction") {
    await previewExtraction();
  } else if (command.action === "save-draft") {
    await saveCurrentDraft({ announce: true });
  } else if (command.action === "export-draft") {
    downloadDraftYaml();
  } else if (command.action === "publish-draft") {
    await publishCurrentDraft();
  } else if (command.action === "refresh") {
    await refreshBlockTable();
  } else if (command.action === "navigate-step") {
    navigateWorkflow(command.step);
  }
}

function applyFinishMetadata(metadata = {}) {
  els.adapterId.value = String(metadata.adapterId || "");
  els.adapterNamespace.value = String(metadata.namespace || "");
  syncNamespaceSuggestionState();
  els.pageId.value = String(metadata.pageId || "collection");
  els.pageType.value = String(metadata.pageType || "CollectionPage");
}

function connectTablePanel() {
  if (!Number.isInteger(inspectedTabId) || !chrome.runtime?.connect || tablePanelPort) return;
  tablePanelPort = chrome.runtime.connect({ name: `site2json-sidebar:${inspectedTabId}` });
  clearInterval(tablePanelHeartbeat);
  tablePanelHeartbeat = setInterval(() => {
    try { tablePanelPort?.postMessage({ type: "relay-heartbeat" }); } catch { /* Disconnect handling updates the UI. */ }
  }, 15_000);
  tablePanelPort.onMessage.addListener((message) => {
    if (message?.type === "panel-request-snapshot") {
      els.tablePanelStatus.textContent = "Expanded workspace connected to this inspected tab.";
      publishTablePanel();
    } else if (message?.type === "panel-command") {
      handleTablePanelCommand(message.command)
        .then(() => publishTablePanel())
        .catch((error) => setStatus(els.discoveryStatus, "error", error.message));
    } else if (message?.type === "execute-command") {
      (async () => {
        try {
          await handleTablePanelCommand(message.command);
          postTablePanel({ type: "command-result", commandId: message.commandId, ok: true });
          publishTablePanel();
        } catch (error) {
          postTablePanel({ type: "command-result", commandId: message.commandId, ok: false, error: error.message });
          setStatus(els.discoveryStatus, "error", error.message);
          publishTablePanel();
        }
      })();
    } else if (message?.type === "controller-state") {
      applyEditorLease(message.lease?.owner);
    }
  });
  tablePanelPort.onDisconnect.addListener(() => {
    tablePanelPort = null;
    clearInterval(tablePanelHeartbeat);
    tablePanelHeartbeat = null;
    applyEditorLease("sidebar");
    els.tablePanelStatus.textContent = "Expanded workspace disconnected. Reopen it to reconnect.";
  });
}

function disconnectTablePanel() {
  if (!tablePanelPort) return;
  publishTablePanel({ stale: true, clear: true });
  try { tablePanelPort.disconnect?.(); } catch { /* The relay may already be closing. */ }
  tablePanelPort = null;
  clearInterval(tablePanelHeartbeat);
  tablePanelHeartbeat = null;
}

function configureTablePanel() {
  // The sidebar is itself the tab's active side panel. Disabling the dormant
  // expanded workspace here disables (and immediately closes) this page too.
  // Only replace the tab-specific panel when that surface is actually enabled.
  if (!EXPANDED_EDITOR_ENABLED || !Number.isInteger(inspectedTabId) || !chrome.sidePanel?.setOptions) return;
  const path = `editor/table-panel.html?tabId=${inspectedTabId}`;
  chrome.sidePanel.setOptions({ tabId: inspectedTabId, path, enabled: true }).catch((error) => {
    els.tablePanelStatus.textContent = `Could not configure the table panel: ${error.message}`;
  });
}

async function openTablePanel() {
  if (!EXPANDED_EDITOR_ENABLED) {
    els.tablePanelStatus.textContent = "The expanded editor is temporarily disabled while the single sidebar workflow is stabilized.";
    return;
  }
  if (!Number.isInteger(inspectedTabId) || !chrome.sidePanel) {
    els.tablePanelStatus.textContent = "The browser side-panel API is unavailable here; continue in this pane.";
    return;
  }
  try {
    if (state.currentDraft) await saveCurrentDraft();
    await chrome.sidePanel.open({ tabId: inspectedTabId });
    els.tablePanelStatus.textContent = "Opening the expanded editor for this inspected tab…";
    connectTablePanel();
    requestEditorLease("expanded");
    publishTablePanel();
  } catch (error) {
    els.tablePanelStatus.textContent = `Could not open the table panel: ${error.message}`;
  }
}

function editorSnapshot() {
  const configured = state.blocks.length > 0 || Boolean(state.lastValidDefinition);
  const pageUrl = configured || !state.currentDraft?.editorState?.pageUrl
    ? state.pageUrl
    : state.currentDraft.editorState.pageUrl;
  return {
    pageUrl,
    adapterId: els.adapterId.value.trim(),
    namespace: els.adapterNamespace.value.trim(),
    pageId: els.pageId.value.trim(),
    pageType: els.pageType.value.trim(),
    fixture: state.fixture,
    version: state.baseDefinition?.version || 1,
    blocks: state.blocks,
    customTerms: state.customTerms,
    ...(state.pageDetectionReview ? { pageDetectionReview: state.pageDetectionReview } : {}),
    ...(state.inferenceRun ? { inference: state.inferenceRun } : {}),
    ...(state.automaticAuthoring ? { authoring: state.automaticAuthoring } : {})
  };
}

function inferenceReviewReady() {
  return Boolean(state.inferenceRun?.reviewReady && !state.inferenceRun?.stale);
}

function setDraftControls() {
  const hasDraft = Boolean(state.currentDraft);
  const hasDefinition = Boolean(state.lastValidDefinition);
  if (els.saveDraft) els.saveDraft.disabled = !hasDraft;
  if (els.exportDraft) els.exportDraft.disabled = !hasDraft || !hasDefinition;
  if (els.publishDraft) els.publishDraft.disabled = !hasDraft || !hasDefinition;
  if (els.exportDraft) els.exportDraft.title = hasDraft && !hasDefinition ? "Build and validate the adapter draft in Finish to enable export." : "";
  if (els.publishDraft) els.publishDraft.title = hasDraft && !hasDefinition ? "Build and validate the adapter draft in Finish to enable publishing." : "";
  if (els.captureFixture) els.captureFixture.disabled = !hasDefinition;
  if (els.discardDraft) els.discardDraft.disabled = !hasDraft;
  if (els.inferRemaining) els.inferRemaining.disabled = !hasDraft || state.inferenceRunning;
  updateStructureActionState();
}

function setLibraryStatus(message, kind = "") {
  if (!els.libraryStatus) return;
  els.libraryStatus.textContent = message;
  els.libraryStatus.className = `status ${kind}`.trim();
}

function downloadBytes(bytes, name, type = "application/yaml") {
  const url = URL.createObjectURL(new Blob([bytes], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

function refreshWorkspaceLists(selectedId = state.currentDraft?.id || "") {
  workspaceView?.renderPicker(state.entries, state.drafts, selectedId);
  workspaceView?.renderLibrary(state.entries, state.drafts, state.currentDraft?.id || null);
  setDraftControls();
}

function selectAppNavigation(view) {
  if (!els.appNavigation) return;
  for (const button of els.appNavigation.querySelectorAll("[data-app-view]")) {
    const selected = button.dataset.appView === view;
    button.classList.toggle("selected", selected);
    if (selected) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  }
}

function showEditorWorkspace() {
  state.workspaceMode = "editor";
  document.body.classList.remove("library-home-open");
  if (els.libraryHome) els.libraryHome.hidden = true;
  semanticLibraryView?.close();
  if (els.editorWorkspace) els.editorWorkspace.hidden = false;
  if (els.appNavigation) els.appNavigation.hidden = true;
  if (els.backToLibrary) els.backToLibrary.hidden = false;
  if (els.appTitle) els.appTitle.textContent = "Site2JSON adapter editor";
  if (els.editorSubtitle) els.editorSubtitle.textContent = "Select rendered evidence on the page; review its structured meaning here.";
}

function showLibraryHome() {
  state.workspaceMode = "library";
  discardHighlights();
  document.body.classList.remove("field-editor-open");
  document.body.classList.add("library-home-open");
  if (els.libraryHome) els.libraryHome.hidden = false;
  semanticLibraryView?.close();
  if (els.editorWorkspace) els.editorWorkspace.hidden = true;
  if (els.backToLibrary) els.backToLibrary.hidden = true;
  if (els.appNavigation) els.appNavigation.hidden = false;
  if (els.appTitle) els.appTitle.textContent = "Site2JSON";
  selectAppNavigation("adapters");
  if (els.editorSubtitle) els.editorSubtitle.textContent = "Manage published adapters and resume unfinished drafts.";
  refreshWorkspaceLists();
}

function showSemanticLibraryHome() {
  state.workspaceMode = "semantic-library";
  discardHighlights();
  document.body.classList.remove("field-editor-open");
  document.body.classList.add("library-home-open");
  if (els.libraryHome) els.libraryHome.hidden = true;
  if (els.editorWorkspace) els.editorWorkspace.hidden = true;
  if (els.backToLibrary) els.backToLibrary.hidden = true;
  if (els.appNavigation) els.appNavigation.hidden = false;
  if (els.appTitle) els.appTitle.textContent = "Site2JSON Semantic Library";
  selectAppNavigation("semantics");
  if (els.editorSubtitle) els.editorSubtitle.textContent = "Manage reusable semantic patterns, tags, and collections.";
  semanticLibraryView?.open();
}

async function returnToLibrary() {
  clearTimeout(autosaveTimer);
  autosaveTimer = null;
  if (state.currentDraft) await saveCurrentDraft();
  showLibraryHome();
}

function resetEditorForDraft() {
  discardHighlights();
  pageAnalysisRequest += 1;
  activePageAnalysis = null;
  state.blocks = [];
  state.activeBlockId = null;
  state.activeVariantEntityName = null;
  state.pendingScope = null;
  state.pendingField = null;
  state.pendingCorrectionPromotion = null;
  state.structureStartMode = "detection";
  state.pageDetectionReview = null;
  pageDetectionReport = null;
  detectionFirstView?.hide();
  state.pendingTransform = null;
  state.tableRows = [];
  state.customTerms = {};
  state.fixture = null;
  state.lastValidDefinition = null;
  state.lastDiscoveryBatch = null;
  state.automaticAuthoring = null;
  state.inferenceRun = null;
  state.inferenceRunning = false;
  state.driftReview = { status: "idle", findings: [], message: "" };
  state.route = "structure";
  scopeProposalCache.repeating = null;
  scopeProposalCache.single = null;
  els.singleItemScope.checked = false;
  els.pickScope.textContent = "Find repeating scope";
  els.blockPicker.replaceChildren();
  els.blockPickerLabel.hidden = true;
  els.stepBlocks.hidden = true;
  els.stepFields.hidden = true;
  els.stepBuild.hidden = true;
  els.stepScope.hidden = true;
  els.scopeHeading.textContent = "Scope proposal";
  els.scopeHint.textContent = "Candidates identify the repeated items, not their collection container. Hover one to see every match; nothing changes until you explicitly use it.";
  els.scopeStatus.hidden = false;
  els.scopeShowPageAnalysis.hidden = true;
  els.blockSetup.hidden = true;
  els.scopeAccepted.hidden = true;
  if (els.structureComplete) els.structureComplete.hidden = true;
  hideFieldEditor();
  els.buildOutput.textContent = "";
  els.extractionOutput.textContent = "";
  if (els.inferRemainingStatus) {
    setStatus(els.inferRemainingStatus, "", "");
    els.inferRemainingStatus.hidden = true;
  }
  els.previewExtraction.disabled = true;
  renderRoute();
}

async function openDraft(draft) {
  resetEditorForDraft();
  delete els.adapterNamespace.dataset.suggested;
  state.currentDraft = draft;
  const baseDefinition = draft.baseDefinition || draft.workingDefinition;
  state.baseDefinition = baseDefinition ? JSON.parse(JSON.stringify(baseDefinition)) : null;
  await draftRegistry.activate(draft.id);
  let editorState = draft.editorState;
  if ((!editorState?.blocks?.length || (state.pageUrl && editorState.pageUrl !== state.pageUrl)) && draft.workingDefinition && state.pageUrl) {
    editorState = Site2JsonAdapterDefinition.editorStateFromDefinition(draft.workingDefinition, state.pageUrl);
  }
  if (editorState) {
    state.pageUrl = state.pageUrl || editorState.pageUrl;
    state.blocks = JSON.parse(JSON.stringify(editorState.blocks || []));
    for (const block of state.blocks) {
      variantTargets(block);
      ensureBlockComposition(block);
    }
    state.customTerms = JSON.parse(JSON.stringify(editorState.customTerms || {}));
    state.fixture = editorState.fixture ? JSON.parse(JSON.stringify(editorState.fixture)) : null;
    state.automaticAuthoring = editorState.authoring ? JSON.parse(JSON.stringify(editorState.authoring)) : null;
    state.pageDetectionReview = editorState.pageDetectionReview ? JSON.parse(JSON.stringify(editorState.pageDetectionReview)) : null;
    state.inferenceRun = editorState.inference ? JSON.parse(JSON.stringify(editorState.inference)) : null;
    if (state.automaticAuthoring?.origin === "automatic" && state.automaticAuthoring.reviewStatus !== "reviewed") {
      for (const block of state.blocks) block.semanticsReviewed = false;
    }
    els.adapterId.value = editorState.adapterId || draft.adapterId || "";
    els.adapterNamespace.value = editorState.namespace || draft.workingDefinition?.namespace || "";
    els.pageId.value = editorState.pageId || "collection";
    els.pageType.value = editorState.pageType || "CollectionPage";
  } else {
    els.adapterId.value = draft.adapterId || "";
    els.adapterNamespace.value = draft.workingDefinition?.namespace || "";
    els.pageId.value = "collection";
    els.pageType.value = "CollectionPage";
  }
  syncNamespaceSuggestionState();
  state.lastValidDefinition = draft.workingDefinition || null;
  if (state.inferenceRun?.message && els.inferRemainingStatus) {
    els.inferRemainingStatus.hidden = false;
    setStatus(els.inferRemainingStatus, state.inferenceRun.kind || "ready", state.inferenceRun.message);
  }
  if (draft.workingDefinition) els.buildOutput.textContent = JSON.stringify(draft.workingDefinition, null, 2);
  if (state.blocks.length) {
    els.stepBlocks.hidden = false;
    els.stepFields.hidden = false;
    els.stepBuild.hidden = false;
    await activateBlock(state.blocks[0].id, { pin: false });
    state.route = workflowState()?.current || "semantics";
    if (state.route === "finish") ensureSuggestedAdapterMetadata();
    renderRoute();
    if (state.route === "review" && state.lastValidDefinition) checkStructuralHealth().catch(() => {});
  }
  refreshWorkspaceLists(draft.id);
  const message = state.blocks.length
    ? `Editing autosaved draft for ${draft.adapterId || "a new adapter"}. Published extraction is unchanged.`
    : draft.workingDefinition
      ? "This adapter has no page matching the inspected URL. Navigate to one of its supported pages to edit it visually."
      : "New draft created. Review what was detected on this page, or choose manual structure selection.";
  setStatus(els.draftStatus, state.blocks.length || !draft.workingDefinition ? "ready" : "error", message);
  showEditorWorkspace();
  if (!state.blocks.length && !draft.workingDefinition) {
    runDetectionFirst();
  }
}

async function beginEditingDraft(draft) {
  if (!draft) throw new Error("That adapter draft is no longer available.");
  if (state.currentDraft && state.currentDraft.id !== draft.id) await saveCurrentDraft();
  state.drafts = draftRegistry.upsert(state.drafts, draft);
  await draftRegistry.save(state.drafts);
  await openDraft(draft);
}

async function saveCurrentDraft({ announce = false } = {}) {
  if (!state.currentDraft || !draftRegistry) return;
  const next = draftRegistry.update(state.currentDraft, {
    workingDefinition: state.lastValidDefinition,
    editorState: editorSnapshot()
  });
  state.drafts = draftRegistry.upsert(state.drafts, next);
  state.currentDraft = next;
  await draftRegistry.save(state.drafts);
  refreshWorkspaceLists(next.id);
  if (announce) setStatus(els.draftStatus, "ready", "Draft saved locally. Published extraction is unchanged.");
}

async function discardCurrentDraft() {
  if (!state.currentDraft || !draftRegistry) return;
  const discarded = state.currentDraft;
  clearTimeout(autosaveTimer);
  autosaveTimer = null;
  if (els.discardDraft) els.discardDraft.disabled = true;
  setStatus(els.draftStatus, "loading", "Discarding this draft and preparing a fresh one…");
  try {
    const remaining = draftRegistry.remove(state.drafts, discarded.id);
    const fresh = draftRegistry.createNew({ pageUrl: state.pageUrl });
    const nextDrafts = draftRegistry.upsert(remaining, fresh);
    await draftRegistry.save(nextDrafts);
    state.drafts = nextDrafts;
    await openDraft(fresh);
    setStatus(els.draftStatus, "ready", "Draft discarded. A fresh draft is ready for this page; published adapters were not changed.");
  } catch (error) {
    setStatus(els.draftStatus, "error", `Could not discard the draft: ${error.message}`);
    refreshWorkspaceLists(state.currentDraft?.id);
  }
}

function scheduleDraftAutosave() {
  if (!state.currentDraft || !draftRegistry) return;
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => {
    saveCurrentDraft().catch((error) => setStatus(els.draftStatus, "error", error.message));
  }, 250);
}

function productionDocument(definition, observation, pageUrl = state.pageUrl) {
  if (!definition || !observation || !extractionModel || !globalThis.Site2JsonDsl) {
    throw new Error("The production extraction runtime is unavailable in this editor.");
  }
  const compiled = globalThis.Site2JsonDsl.compile(definition);
  const documentValue = extractionModel.assemble({ ...compiled, source: "local-file" }, observation, pageUrl);
  const entityCount = documentValue.blocks.reduce((total, block) => total + block.entities.length, 0);
  if (!entityCount) throw new Error("The inferred adapter matched, but it did not extract any entities.");
  return documentValue;
}

async function returnProductionResult(request, { definition, preview, published = false, automatic = true, decision = null } = {}) {
  if (!preview?.ok || !preview.observation) throw new Error(preview?.message || "The production interpreter did not return an extraction.");
  const documentValue = productionDocument(definition, preview.observation, state.pageUrl || request.pageUrl);
  await chrome.storage.session.set({
    [PRODUCTION_RESULT_KEY]: {
      version: 1,
      requestId: request.id,
      tabId: inspectedTabId,
      intent: request.intent === "session" ? "session" : "run",
      minimumConfidence: request.minimumConfidence,
      automatic,
      published,
      decision: decision?.outcome || null,
      completedAt: new Date().toISOString(),
      document: documentValue
    }
  });
  try {
    await chrome.action?.openPopup?.();
  } catch {
    const message = "Run complete. Reopen the Site2JSON popup to copy, download, or continue the session.";
    if (state.workspaceMode === "library") setLibraryStatus(message, "ready");
    else setAutomaticStatus("ready", message);
  }
  return documentValue;
}

async function consumeProductionRunRequest() {
  if (!chrome.storage?.session || !Number.isInteger(inspectedTabId)) return;
  const stored = await chrome.storage.session.get(PRODUCTION_REQUEST_KEY);
  const request = stored?.[PRODUCTION_REQUEST_KEY];
  if (!request || request.tabId !== inspectedTabId) return;
  await chrome.storage.session.remove(PRODUCTION_REQUEST_KEY);
  const requestedAt = Date.parse(request.requestedAt || "");
  if (!Number.isFinite(requestedAt) || Date.now() - requestedAt > 5 * 60_000) {
    setLibraryStatus("The automatic run request expired. Start Run again from the popup.", "error");
    return;
  }
  if (request.pageUrl && state.pageUrl && request.pageUrl !== state.pageUrl) {
    setLibraryStatus("The page changed while automatic Run was opening. Start Run again on the current page.", "error");
    return;
  }
  const settings = automaticSettingsApi?.normalize({ minimumConfidence: request.minimumConfidence }) || { minimumConfidence: "strong" };
  const existing = automaticConversion.resolveExisting({ entries: state.entries, drafts: state.drafts }, state.pageUrl || request.pageUrl);
  if (existing.outcome === automaticConversion.OUTCOMES.USE_EXISTING) {
    const preview = await Site2JsonBridge.run(bridgePreviewExtraction, { definition: existing.definition });
    await returnProductionResult(request, { definition: existing.definition, preview, published: true, automatic: false });
    return;
  }
  if (existing.outcome === automaticConversion.OUTCOMES.DISABLED_EXISTING) {
    setLibraryStatus(`“${existing.id}” supports this page but is disabled. Enable or review it before running extraction.`, "error");
    return;
  }
  if (existing.outcome === automaticConversion.OUTCOMES.PRESERVE_MANUAL_DRAFT || existing.outcome === automaticConversion.OUTCOMES.RESUME_AUTOMATIC_DRAFT) {
    await beginEditingDraft(existing.draft);
    setStatus(els.draftStatus, "error", `${automaticConflictMessage(existing)} Run stopped without replacing its decisions.`);
    return;
  }
  const blank = state.drafts.find((draft) => !automaticConversion.meaningfulDraft(draft) && draft.editorState?.pageUrl === state.pageUrl);
  await beginEditingDraft(blank || draftRegistry.createNew({ pageUrl: state.pageUrl || request.pageUrl }));
  const result = await automaticConvert({ minimumConfidence: settings.minimumConfidence });
  if (!result?.ok) return;
  await returnProductionResult(request, {
    definition: result.definition,
    preview: result.preview,
    published: result.published,
    automatic: true,
    decision: result.decision
  });
}

async function initializeDraftWorkspace() {
  if (!draftRegistry || !adapterRegistry || !chrome.storage?.local || !els.draftPicker) return;
  try {
    [state.entries, state.drafts] = await Promise.all([adapterRegistry.load(), draftRegistry.load()]);
    refreshWorkspaceLists();
    showLibraryHome();
    await consumeProductionRunRequest();
  } catch (error) {
    setStatus(els.draftStatus, "error", `Could not load editor drafts: ${error.message}`);
  }
}
const {
  bridgeAcceptScope,
  bridgeAddFieldCandidate,
  bridgeBuildBlockTable,
  bridgeCaptureFixture,
  bridgeCaptureStructuralBaseline,
  bridgeCaptureVariantEvidence,
  bridgeClassifyVariantItems,
  bridgeClassifyNestedVariantSlots,
  bridgeClearHighlights,
  bridgeDiscoverFields,
  bridgeDetectSemanticDomV2,
  bridgeDiscoverVariantItems,
  bridgeFindEvidenceScopes,
  bridgeFocusPageDetectionV2,
  bridgeFocusSemanticDomV2,
  bridgeHighlightSelector,
  bridgeInferScope,
  bridgeLocateSelection,
  bridgePageAnalysisContext,
  bridgePreviewExtraction,
  bridgePreviewField,
  bridgePreviewSemanticDomV2,
  bridgeReadSelection,
  bridgeRevealTarget,
  bridgeSurveySemanticDomV2
} = globalThis.Site2JsonSidebarPageBridge;

function semanticAssignmentRecords(customTerms = {}) {
  return Object.entries(customTerms).map(([id, definition]) => ({
    id,
    label: id,
    definition: { ...definition, canonicalUri: definition.canonicalUri || id }
  }));
}

function compositionCandidateTypes(composition) {
  const rootNode = composition?.nodes?.[composition.root];
  return [...new Set([
    ...(rootNode?.types || []),
    ...(rootNode?.variants?.candidates || []).map((candidate) => candidate.type || candidate.schemaType)
  ].filter(Boolean))];
}

async function previewSemanticDomV2(composition, customTerms, overlay = {}) {
  if (!semanticAssignmentProfileApi?.compile) throw new Error("The V2 semantic profile compiler is unavailable in this editor build.");
  const block = activeBlock();
  if (!block) throw new Error("Select an extraction block before previewing live data.");
  const records = semanticAssignmentRecords(customTerms);
  const profile = semanticAssignmentProfileApi.compile({
    candidateTypes: compositionCandidateTypes(composition),
    composition,
    libraryTypes: records.filter((record) => record.definition.kind === "type"),
    libraryProperties: records.filter((record) => record.definition.kind !== "type")
  });
  const result = await (Site2JsonBridge.runV2 || Site2JsonBridge.run)(bridgePreviewSemanticDomV2, {
    profile,
    focusModel: {
      root: composition.root,
      nodes: Object.fromEntries(Object.entries(composition.nodes || {}).map(([alias, node]) => [alias, { types: [...(node.types || [])] }])),
      edges: (composition.edges || []).map(({ from, property, to }) => ({ from, property, to }))
    },
    plan: { collection: { id: `preview:${block.id || block.entityName || "collection"}` } },
    overlay
  });
  if (!result?.ok) throw new Error(result?.message || "The V2 semantic-DOM preview could not parse this page.");
  return result;
}

async function detectPageSemanticDomV2(options = {}) {
  if (!pageSemanticProfileApi?.build) throw new Error("The V2 page semantic profiler is unavailable in this editor build.");
  await ensureSemanticLibraryInference();
  if (!semanticLibraryInference) throw new Error("The Semantic Library inference index is unavailable in this editor build.");
  const plan = options.plan || { collection: { id: "page-detection" } };
  const survey = await (Site2JsonBridge.runV2 || Site2JsonBridge.run)(bridgeSurveySemanticDomV2, {
    plan,
    detection: options.detection || {}
  });
  if (!survey?.ok) throw new Error(survey?.message || "The page could not be surveyed for semantic evidence.");
  const authoring = pageSemanticProfileApi.build(survey.observations, {
    inference: semanticLibraryInference,
    compiler: semanticAssignmentProfileApi,
    typeLimit: options.typeLimit,
    compositionLimit: options.compositionLimit
  });
  const detection = await (Site2JsonBridge.runV2 || Site2JsonBridge.run)(bridgeDetectSemanticDomV2, {
    plan,
    profile: authoring.profile,
    variants: options.variants || {},
    detection: options.detection || {}
  });
  if (!detection?.ok) throw new Error(detection?.message || "The page-wide semantic detector could not analyze this page.");
  return Object.freeze({ survey, authoring, detection });
}

function renderStructureStartMode() {
  if (state.blocks.length || state.route !== "structure") {
    detectionFirstView?.hide();
    if (els.showPageDetection) els.showPageDetection.hidden = true;
    return;
  }
  const detectionMode = state.structureStartMode !== "manual";
  if (els.stepSelection) els.stepSelection.hidden = detectionMode;
  if (els.stepScope && detectionMode) els.stepScope.hidden = true;
  if (els.showPageDetection) els.showPageDetection.hidden = detectionMode || !pageDetectionReport;
  if (detectionMode && pageDetectionReport) detectionFirstView?.render(pageDetectionReport, state.pageDetectionReview?.decisions || {});
  else if (!detectionMode) detectionFirstView?.hide();
}

async function focusPageDetection(focus = {}) {
  return (Site2JsonBridge.runV2 || Site2JsonBridge.run)(bridgeFocusPageDetectionV2, focus).catch(() => null);
}

async function runDetectionFirst({ force = false } = {}) {
  if (!state.currentDraft || state.blocks.length) return null;
  state.structureStartMode = "detection";
  renderStructureStartMode();
  detectionFirstView?.showLoading(force
    ? "Detecting the current page again…"
    : "Detecting rendered structures, fields, and likely Schema.org types…");
  try {
    const report = await detectPageSemanticDomV2();
    const profileDigest = report?.detection?.profileDigest || report?.authoring?.profile?.digest || null;
    const sameReview = state.pageDetectionReview?.pageUrl === report?.detection?.pageUrl
      && state.pageDetectionReview?.profileDigest === profileDigest;
    state.pageDetectionReview = {
      pageUrl: report?.detection?.pageUrl || state.pageUrl,
      profileDigest,
      decisions: sameReview ? { ...(state.pageDetectionReview.decisions || {}) } : {}
    };
    pageDetectionReport = report;
    detectionFirstView?.render(report, state.pageDetectionReview.decisions);
    scheduleDraftAutosave();
    return report;
  } catch (error) {
    pageDetectionReport = null;
    detectionFirstView?.showError(`Page detection could not finish: ${error.message}`);
    return null;
  }
}

function useManualStructure() {
  state.structureStartMode = "manual";
  detectionFirstView?.hide();
  els.stepSelection.hidden = false;
  if (els.showPageDetection) els.showPageDetection.hidden = !pageDetectionReport;
  runPageAnalysis().catch((error) => setStatus(els.scopeStatus, "error", `Page Analysis could not finish: ${error.message}`));
  revealPanel(els.stepSelection, els.visualSelect);
}

function restoreDetectionFirst() {
  state.structureStartMode = "detection";
  discardHighlights();
  renderStructureStartMode();
  if (pageDetectionReport) detectionFirstView?.render(pageDetectionReport, state.pageDetectionReview?.decisions || {});
  else runDetectionFirst();
  revealPanel(els.stepPageDetection, els.stepPageDetection?.querySelector(".detection-card"));
}

globalThis.Site2JsonV2PageDetection = Object.freeze({ run: detectPageSemanticDomV2 });

async function focusSemanticDomV2(focus) {
  return (Site2JsonBridge.runV2 || Site2JsonBridge.run)(bridgeFocusSemanticDomV2, focus);
}

function setStatus(el, kind, message) {
  el.textContent = message;
  el.className = `status ${kind}`;
}

function renderSelectionSummary(result) {
  state.currentSelection = result ? JSON.parse(JSON.stringify(result)) : null;
  if (!result || !result.ok) {
    els.selectionSummary.hidden = true;
    els.selectionStatus.hidden = false;
    els.selectionStatus.textContent = !result || result.reason === "no-selection"
      ? "No element selected."
      : (result.message || "Could not read the current selection.");
    updateStructureActionState();
    return;
  }
  els.selectionStatus.hidden = true;
  els.selectionSummary.hidden = false;
  els.selectionTag.textContent = result.summary.tag;
  els.selectionId.textContent = result.summary.id || "—";
  els.selectionClasses.textContent = result.summary.classes.length ? result.summary.classes.join(" ") : "—";
  els.selectionText.textContent = result.summary.text || "—";
  els.selectionHrefRow.hidden = !result.href;
  els.selectionHref.textContent = result.href || "";
  if (result.shadowBoundary) {
    els.selectionStatus.hidden = false;
    els.selectionStatus.className = "status error";
    els.selectionStatus.textContent = shadowBoundaryMessage(result.shadowBoundary);
  }
  updateStructureActionState();
}

function shadowBoundaryMessage(boundary) {
  const host = boundary?.host ? `<${boundary.host.tag}${boundary.host.id ? `#${boundary.host.id}` : ""}>` : "a custom-element host";
  return boundary?.mode === "closed"
    ? `Selected element is inside a closed Shadow DOM root hosted by ${host}. The extraction runtime cannot reproduce this selection.`
    : `Selected element is inside an open Shadow DOM root hosted by ${host}. Shadow-boundary selectors are not supported yet.`;
}

async function refreshSelection() {
  try {
    await Site2JsonBridge.syncSelectionFrame?.();
    const result = await Site2JsonBridge.run(bridgeReadSelection);
    if (result.pageUrl) state.pageUrl = result.pageUrl;
    renderSelectionSummary(result);
    await refreshSelectionAwareness(result);
    publishTablePanel();
  } catch (error) {
    renderSelectionSummary({ ok: false, message: error.message });
    postTablePanel({ type: "selection-focus", focus: null });
    publishTablePanel();
  }
}

async function startVisualSelection(intent = "scope") {
  if (!Site2JsonBridge.startSelection) return;
  visualSelectionIntent = intent;
  if (intent === "scope") {
    selectionBeforeVisualPick = state.currentSelection ? JSON.parse(JSON.stringify(state.currentSelection)) : null;
    els.visualSelect.disabled = true;
    renderSelectionSummary({ ok: false, message: "Move over the rendered page and click the item you want to extract. Press Escape to cancel." });
  } else if (intent !== "variant-evidence") {
    els.selectFieldOnPage.disabled = true;
    setStatus(els.fieldStatus, "loading", "Move over a field inside one highlighted item and click it. Press Escape to cancel.");
  }
  try {
    await Site2JsonBridge.startSelection(intent);
  } catch (error) {
    visualSelectionIntent = null;
    if (intent === "scope") {
      const previousSelection = selectionBeforeVisualPick;
      selectionBeforeVisualPick = null;
      renderSelectionSummary(previousSelection || { ok: false, reason: "no-selection" });
      restoreActivePageAnalysis();
      setStatus(els.selectionStatus, "error", error.message);
      updateStructureActionState();
    } else if (intent !== "variant-evidence") {
      els.selectFieldOnPage.disabled = false;
      setStatus(els.fieldStatus, "error", error.message);
    } else if (semanticGraphView?.elements) {
      semanticGraphView.elements.resolutionStatus.className = "status error";
      semanticGraphView.elements.resolutionStatus.textContent = error.message;
    }
  }
}

async function receiveVisualSelection(message, sender) {
  if (message?.type !== "site2json-picker:selection" || !message.selection) return;
  if (Number.isInteger(inspectedTabId) && sender?.tab?.id !== inspectedTabId) return;
  Site2JsonBridge.useSelectionFrame?.(sender.frameId);
  const intent = visualSelectionIntent || "scope";
  visualSelectionIntent = null;
  selectionBeforeVisualPick = null;
  await chrome.tabs.sendMessage(inspectedTabId, {
    type: "site2json-picker:freeze",
    keepInstanceId: message.selection.instanceId
  }).catch(() => {});
  const dismissPicker = () => chrome.tabs.sendMessage(inspectedTabId, {
    type: "site2json-picker:dismiss"
  }).catch(() => {});
  if (intent === "visual-evidence") {
    visualEvidenceView?.record(message.selection);
    await dismissPicker();
    return;
  }
  if (intent === "new-field") {
    els.selectFieldOnPage.disabled = false;
    await pickField({ selectedOnPage: true });
    await dismissPicker();
    return;
  }
  if (intent === "replace-field") {
    els.selectFieldOnPage.disabled = false;
    await refreshSelectionProposal();
    if (!state.selectionProposal) setStatus(els.fieldStatus, "error", "That element cannot be used as a field inside the active extraction scope.");
    await dismissPicker();
    return;
  }
  if (intent === "variant-evidence") {
    await refreshSelection();
    await dismissPicker();
    if (semanticGraphView?.elements) semanticGraphView.elements.resolutionStatus.textContent = "Evidence selected. Confirm the intended type, then save and reclassify the sample.";
    return;
  }
  await refreshSelection();
  await dismissPicker();
  els.visualSelect.textContent = "Select another item";
  restoreActivePageAnalysis();
  revealPanel(els.stepSelection, els.pickScope);
}

async function openVisualEvidence(invocation) {
  if (!visualEvidenceView) return;
  const caller = invocation?.caller === "graph" ? "graph" : "detection";
  let pageContext;
  try {
    pageContext = await pageAnalysisContext();
  } catch (error) {
    if (caller === "graph" && semanticGraphView?.elements?.resolutionStatus) {
      semanticGraphView.elements.resolutionStatus.className = "status error";
      semanticGraphView.elements.resolutionStatus.textContent = `Visual Evidence could not identify the current page revision: ${error.message}`;
    } else detectionFirstView?.showError?.(`Visual Evidence could not identify the current page revision: ${error.message}`);
    return;
  }
  visualEvidenceCaller = {
    caller,
    scrollY: document.scrollingElement?.scrollTop || 0,
    graphVisible: !document.querySelector("#semantic-composition-graph-view")?.hidden
  };
  for (const section of document.querySelectorAll(".step, #semantic-composition-graph-view")) section.hidden = true;
  visualEvidenceView.open({ ...invocation, context: { pageRevision: pageContext.key }, caller, callerLabel: caller === "graph" ? "Semantic graph" : "Detected on this page", decisions: visualEvidenceDecisions });
}

async function startVisualEvidencePick() {
  if (!Site2JsonBridge.startSelection) throw new Error("Rendered-page selection is unavailable.");
  visualSelectionIntent = "visual-evidence";
  await Site2JsonBridge.startSelection("visual-evidence");
}

function restoreVisualEvidenceCaller(result, apply = false) {
  if (apply && result?.decisions) visualEvidenceDecisions = { ...visualEvidenceDecisions, ...result.decisions };
  const caller = visualEvidenceCaller;
  visualEvidenceCaller = null;
  if (caller?.caller === "graph") document.querySelector("#semantic-composition-graph-view").hidden = false;
  else restoreDetectionFirst();
  if (apply) {
    if (caller?.caller === "graph") compositionGraphView?.refreshLivePreview?.();
    else runDetectionFirst({ force: true });
  }
  setTimeout(() => { if (document.scrollingElement) document.scrollingElement.scrollTop = caller?.scrollY || 0; }, 0);
}

let selectionAwarenessRequest = 0;

function selectionBlocks() {
  const active = activeBlock();
  return [...state.blocks]
    .sort((a, b) => Number(b.id === active?.id) - Number(a.id === active?.id))
    .map((block) => {
      const entity = block.id === active?.id ? activeEntityTarget(block) : block;
      return {
        id: block.id,
        scope: block.scope,
        fields: entity.fields.map((field) => ({ key: Site2JsonFieldDiscovery.sourceKey(field), selector: field.selector }))
      };
    });
}

function pinnedTargetMatchesSelection(target, located) {
  if (!target || !located?.ok) return false;
  const block = state.blocks.find((candidate) => candidate.id === located.blockId);
  if (!block) return false;
  if (target.withinSelector === block.scope) {
    if (Number.isSafeInteger(target.rootIndex) && target.rootIndex !== located.rootIndex) return false;
    const matchingKeys = new Set(located.fieldMatches?.map((match) => match.key) || []);
    const entity = activeEntityTarget(block);
    const matchingFields = entity.fields.map((field) => ({ key: Site2JsonFieldDiscovery.sourceKey(field), selector: field.selector }));
    return matchingFields.some((field) => field.selector === target.selector && matchingKeys.has(field.key));
  }
  if (target.selector !== block.scope || !located.isScopeRoot) return false;
  return !Number.isSafeInteger(target.matchIndex) || target.matchIndex === located.rootIndex;
}

async function refreshSelectionAwareness(selection) {
  const request = ++selectionAwarenessRequest;
  if (!selection?.ok || selection.shadowBoundary || state.blocks.length === 0) {
    postTablePanel({ type: "selection-focus", focus: null });
    hideSelectionProposal();
    return;
  }
  try {
    const located = await Site2JsonBridge.run(bridgeLocateSelection, { blocks: selectionBlocks() });
    if (request !== selectionAwarenessRequest) return;
    if (state.pinnedTarget && !pinnedTargetMatchesSelection(state.pinnedTarget, located)) clearPinnedHighlight();
    if (located.ok && located.blockId !== state.activeBlockId && !state.pendingField) {
      await activateBlock(located.blockId, { pin: false });
      if (request !== selectionAwarenessRequest) return;
    }
    postTablePanel({ type: "selection-focus", focus: located });
    if (state.pendingField) await refreshSelectionProposal();
    else hideSelectionProposal();
  } catch {
    if (request === selectionAwarenessRequest) postTablePanel({ type: "selection-focus", focus: null });
  }
}

const SCOPE_REASON_MESSAGES = {
  "no-selection": "Select a rendered item on the page first.",
  "no-match": "That selector no longer matches any element on the page."
};

const highlightRequests = { transient: 0, pinned: 0 };

async function highlightTarget(target, channel = "transient") {
  const request = ++highlightRequests[channel];
  try {
    await Site2JsonBridge.run(bridgeHighlightSelector, { ...target, channel, token: request });
  } catch {
    // Highlighting is supporting feedback; candidate review remains usable if a page rejects it.
  }
}

function highlightSelector(selector, withinSelector = null, channel = "transient") {
  return highlightTarget({ selector, withinSelector }, channel);
}

function clearHighlight(channel = "transient") {
  const token = ++highlightRequests[channel];
  Site2JsonBridge.run(bridgeClearHighlights, { channel, token }).catch(() => {});
}

function clearAllHighlights() {
  highlightRequests.transient += 1;
  highlightRequests.pinned += 1;
  Site2JsonBridge.run(bridgeClearHighlights, {}).catch(() => {});
}

function discardHighlights() {
  state.pinnedTarget = null;
  document.querySelectorAll(".pinned").forEach((element) => element.classList.remove("pinned"));
  els.clearPinnedHighlight.disabled = true;
  clearAllHighlights();
}

function pinTarget(target, uiElement = null) {
  document.querySelectorAll(".pinned").forEach((element) => element.classList.remove("pinned"));
  state.pinnedTarget = target;
  if (uiElement) uiElement.classList.add("pinned");
  els.clearPinnedHighlight.disabled = false;
  highlightTarget(target, "pinned");
}

async function revealTarget(target) {
  try {
    const result = await Site2JsonBridge.run(bridgeRevealTarget, target);
    if (!result.ok && result.reason !== "no-match") setStatus(document.body.classList.contains("field-editor-open") ? els.fieldStatus : els.discoveryStatus, "error", result.message || "Could not reveal that node in Elements.");
  } catch (error) {
    setStatus(document.body.classList.contains("field-editor-open") ? els.fieldStatus : els.discoveryStatus, "error", error.message);
  }
}

function clearPinnedHighlight() {
  state.pinnedTarget = null;
  document.querySelectorAll(".pinned").forEach((element) => element.classList.remove("pinned"));
  els.clearPinnedHighlight.disabled = true;
  clearHighlight("pinned");
  postTablePanel({ type: "clear-pinned-state" });
}

function renderScopeLevels(levels, chosenSelector, options) {
  structureView?.render(levels, chosenSelector, options);
}

function rememberScopeProposalView(mode, levels, chosenSelector, { independent = false } = {}) {
  scopeProposalCache[mode] = {
    levels,
    chosenSelector,
    heading: els.scopeHeading.textContent,
    hint: els.scopeHint.textContent,
    status: els.scopeStatus.textContent,
    statusKind: els.scopeStatus.className.replace("status", "").trim(),
    adjustmentsHidden: els.scopeAdjustments.hidden,
    independent
  };
}

function restoreScopeProposalView(view) {
  if (!view) return false;
  els.stepScope.hidden = false;
  els.scopeStatus.hidden = false;
  renderScopeLevels(view.levels, view.chosenSelector, { independent: view.independent });
  els.scopeHeading.textContent = view.heading;
  els.scopeHint.textContent = view.hint;
  els.scopeAdjustments.hidden = view.adjustmentsHidden;
  els.scopeShowPageAnalysis.hidden = !activePageAnalysis?.report;
  setStatus(els.scopeStatus, view.statusKind, view.status);
  return true;
}

async function pickScope({ allowSingle = els.singleItemScope.checked } = {}) {
  const request = ++scopeProposalRequest;
  const proposalMode = allowSingle ? "single" : "repeating";
  els.pickScope.disabled = true;
  els.stepScope.hidden = false;
  els.scopeHeading.textContent = "Scope proposal";
  els.scopeHint.textContent = "Hover a candidate to see every match on the page. Nothing changes until you explicitly use one.";
  els.scopeStatus.hidden = false;
  els.scopeShowPageAnalysis.hidden = !activePageAnalysis?.report;
  if (els.structureComplete) els.structureComplete.hidden = true;
  revealPanel(els.stepScope, null);
  setStatus(els.scopeStatus, "loading", "Reading the visual page selection…");
  try {
    const result = await Site2JsonBridge.run(bridgeInferScope, { allowSingle });
    if (request !== scopeProposalRequest) return;
    if (!result.ok) {
      setStatus(els.scopeStatus, "error", result.reason === "shadow-boundary" ? shadowBoundaryMessage(result.shadowBoundary) : (SCOPE_REASON_MESSAGES[result.reason] || result.message || "Could not infer an extraction scope."));
      return;
    }
    if (!result.chosen) {
      setStatus(els.scopeStatus, "error", allowSingle
        ? "No usable single-item boundary was found around the selected element. Select the detail item or its main content container and try again."
        : "No repeating boundary was found above the selected element. For a detail page, enable “Selected element is a single detail item” and try again.");
      renderScopeLevels(result.levels, null);
      rememberScopeProposalView(proposalMode, result.levels, null);
      return;
    }
    setStatus(els.scopeStatus, "ready", result.chosen.matchCount === 1
      ? "Recommended scope identifies one item. Review the proposal, then choose whether it is a detail item or a collection currently containing one result."
      : `Recommended scope matches ${result.chosen.matchCount} elements. Hover each proposal on the page, then choose one explicitly.`);
    renderScopeLevels(result.levels, result.chosen.selector);
    revealPanel(els.stepScope, els.scopeUsePreview);
    rememberScopeProposalView(proposalMode, result.levels, result.chosen.selector);
  } catch (error) {
    setStatus(els.scopeStatus, "error", error.message);
  } finally {
    updateStructureActionState();
  }
}

async function ensureSemanticLibraryInference({ force = false } = {}) {
  if (!semanticLibraryInference) return null;
  return semanticLibraryInference.load({ force });
}

function analyzeSemanticCandidates(candidates = [], details = {}) {
  if (!semanticRanking || !semanticCompositions) return { recommendation: null, ranking: null };
  const ranked = (semanticLibraryInference || semanticRanking).rank(candidates, { typeLimit: 12 });
  const choices = [...ranked.compositions, ...ranked.types]
    .filter((candidate) => candidate.score > 0)
    .sort((left, right) => right.score - left.score || right.explained - left.explained);
  const best = choices[0];
  const next = choices[1];
  const ranking = { status: "ready", ...details, ...ranked };
  if (!best) return { recommendation: null, ranking };
  const margin = best.score - (next?.score || 0);
  const confident = best.explained >= 3 && best.score >= 24 && margin >= Math.max(6, best.score * 0.12);
  let composition = null;
  try {
    composition = best.kind === "composition" ? semanticCompositions.preset(best.id) : semanticCompositions.singleType(best.id.replace(/^schema:/, ""));
  } catch { composition = null; }
  const schemaType = best.schemaType || composition?.nodes?.[composition.root]?.types?.[0] || "Thing";
  return { recommendation: {
    modelId: best.id, label: best.label, schemaType, score: best.score, explained: best.explained,
    total: best.total, margin: Math.round(margin * 10) / 10, confidence: confident ? "high" : "low"
  }, ranking };
}

function semanticRecommendation(candidates) {
  return analyzeSemanticCandidates(candidates).recommendation;
}

function singletonInferenceObservations(candidate) {
  const observations = (candidate.observations || []).map((observation) => JSON.parse(JSON.stringify(observation)));
  if (!candidate.singleton) return observations;
  observations.unshift({
    selector: candidate.selector,
    kind: "text",
    suggestedName: candidate.tag === "article" ? "Article" : "type",
    selectorKind: candidate.kind,
    evidence: { tag: candidate.tag, classes: [], text: "", value: "", context: "single detail root" }
  });
  if (candidate.tag !== "article") return observations;
  let articleBodyAssigned = false;
  for (const observation of observations.slice(1)) {
    const tag = observation.evidence?.tag || "";
    const generic = !observation.suggestedName || ["field", "text", "value"].includes(observation.suggestedName);
    if (/^h[1-3]$/.test(tag) && generic) observation.suggestedName = "headline";
    else if (tag === "time" && observation.evidence?.attribute === "datetime" && generic) observation.suggestedName = "datePublished";
    else if (tag === "p" && generic && !articleBodyAssigned) {
      observation.suggestedName = "articleBody";
      articleBodyAssigned = true;
    }
  }
  return observations;
}

async function analyzePageScopeCandidate(candidate) {
  await ensureSemanticLibraryInference();
  const started = typeof performance === "object" && performance.now ? performance.now() : Date.now();
  const semanticStarted = started;
  const semantic = analyzeSemanticCandidates(singletonInferenceObservations(candidate), {
    sampledScopes: candidate.sampledScopes || candidate.matchCount,
    totalScopes: candidate.matchCount,
    truncated: false
  });
  const semanticFinished = typeof performance === "object" && performance.now ? performance.now() : Date.now();
  const initialVariantItems = await Site2JsonBridge.run(bridgeDiscoverVariantItems, {
    scopeSelector: candidate.selector,
    ...FAST_VARIANT_SCAN
  }).catch((error) => ({ ok: false, message: error.message }));
  const schemaType = semantic.recommendation?.schemaType || "Thing";
  const variant = analyzeVariantItems({ schemaType, semanticRanking: semantic.ranking }, initialVariantItems, semantic.ranking, "page-analysis");
  const finished = typeof performance === "object" && performance.now ? performance.now() : Date.now();
  return {
    recommendation: semantic.recommendation,
    semanticRanking: semantic.ranking,
    initialVariantItems,
    variantAnalysis: variant,
    semanticDurationMs: Math.round((semanticFinished - semanticStarted) * 10) / 10,
    durationMs: Math.round((finished - started) * 10) / 10
  };
}

function ensurePageAnalysisService() {
  if (!pageAnalysisApi?.create) throw new Error("Page Analysis is not available in this editor build.");
  if (!pageAnalysisService) pageAnalysisService = pageAnalysisApi.create({
    findScopes: () => Site2JsonBridge.run(bridgeFindEvidenceScopes),
    analyzeScope: analyzePageScopeCandidate,
    now: () => typeof performance === "object" && performance.now ? performance.now() : Date.now(),
    candidateLimit: 3,
    minConfidence: "high",
    minMargin: 10
  });
  return pageAnalysisService;
}

async function pageAnalysisContext() {
  const result = bridgePageAnalysisContext
    ? await Site2JsonBridge.run(bridgePageAnalysisContext)
    : { ok: true, pageUrl: state.pageUrl, frameUrl: Site2JsonBridge.frameURL?.() || null, revision: 0 };
  if (!result?.ok) throw new Error(result?.message || "Could not identify the rendered page revision.");
  state.pageUrl = result.pageUrl || state.pageUrl;
  const selectedFrame = Site2JsonBridge.frameId?.() ?? Site2JsonBridge.frameURL?.() ?? "top";
  const frame = `${selectedFrame}|${result.frameUrl || state.pageUrl || "unknown"}`;
  const context = { pageUrl: state.pageUrl, frame, revision: Number(result.revision || 0) };
  return { ...context, key: [inspectedTabId, frame, context.pageUrl || "unknown", context.revision].join("|") };
}

function pageAnalysisVariantSummary(candidate) {
  const analysis = candidate?.analysis?.variantAnalysis;
  if (!analysis || analysis.status !== "ready") return "variant evidence unavailable";
  if (analysis.mixed) return `${analysis.candidates.length} distinguishable result types`;
  const primary = analysis.candidates?.[0]?.schemaType;
  return primary ? `one likely ${primary} result type` : "no distinguishable alternate result type";
}

function renderPageAnalysis(report) {
  if (!report || state.blocks.length || state.pendingScope || els.singleItemScope.checked) return;
  els.stepScope.hidden = false;
  els.scopeShowPageAnalysis.hidden = true;
  const singleton = report.scopeMode === "single";
  els.scopeHeading.textContent = singleton ? "Likely detail-page scope" : "Likely extraction scopes";
  els.scopeHint.textContent = singleton
    ? "Page Analysis identified a collection-of-one primary detail after comparing it with repeated content. Hover it to inspect the complete boundary; accepting it is still explicit."
    : "Page Analysis ranks repeated item boundaries, not their collection containers. Hover a boundary to inspect every match; accepting one is still explicit.";
  els.scopeStatus.hidden = false;
  els.scopeStatus.dataset.analysisDurationMs = String(Math.round(Number(report.durationMs || 0)));
  els.scopeStatus.dataset.structuralDurationMs = String(Math.round(Number(report.structuralDurationMs || 0)));
  if (report.status === "running") {
    setStatus(els.scopeStatus, "loading", "Analyzing structural evidence and likely result types…");
    return;
  }
  if (report.status === "error") {
    setStatus(els.scopeStatus, "error", report.error || "Page Analysis failed.");
    return;
  }
  const levels = report.candidates.map((candidate, index) => {
    const { observations: _observations, analysis, ...best } = candidate;
    return {
      depth: index,
      tag: candidate.tag,
      tagName: candidate.tag,
      best: {
        ...best,
        recommendation: analysis?.recommendation || null,
        semanticRanking: analysis?.semanticRanking || null,
        initialVariantItems: analysis?.initialVariantItems || null,
        variantAnalysis: analysis?.variantAnalysis || null
      }
    };
  });
  renderScopeLevels(levels, report.chosenSelector, { independent: true });
  // Page Analysis candidates are independently ranked boundaries, not the
  // narrower-to-wider ancestor chain produced from one manual selection.
  // Each card retains its own explicit accept action.
  els.scopeAdjustments.hidden = true;
  if (!report.chosenSelector) {
    setStatus(els.scopeStatus, "error", "Page Analysis did not find a convincing collection or detail-page boundary. Select one rendered item and infer its scope manually.");
    return;
  }
  const leading = report.candidates.find((candidate) => candidate.selector === report.chosenSelector) || report.candidates[0];
  els.scopeStatus.dataset.semanticDurationMs = String(Math.round(Number(leading?.analysis?.semanticDurationMs || 0)));
  els.scopeStatus.dataset.variantDurationMs = String(Math.round(Number(leading?.analysis?.variantAnalysis?.durationMs || 0)));
  const decision = report.decision?.status === "accepted"
    ? "It clears the automatic boundary threshold."
    : report.complete
      ? "It needs a manual boundary decision."
      : "Alternatives will finish during idle time; manual selection remains available now.";
  setStatus(els.scopeStatus, report.decision?.status === "accepted" ? "ready" : (report.complete ? "error" : "loading"),
    `${report.evidenceCount} evidence nodes produced ${report.candidates.length} candidate ${singleton ? "detail root" : "scope"}${report.candidates.length === 1 ? "" : "s"}. The leader has ${report.structuralConfidence} structural confidence, a ${report.structuralMargin.toFixed(1)}-point margin, and ${pageAnalysisVariantSummary(leading)}. ${decision}`);
  publishTablePanel();
}

function restoreActivePageAnalysis() {
  if (state.blocks.length || state.pendingScope || els.singleItemScope.checked || !activePageAnalysis?.report) return false;
  renderPageAnalysis(activePageAnalysis.report);
  const selector = activePageAnalysis.report.chosenSelector;
  if (selector) highlightSelector(selector).catch(() => {});
  return true;
}

async function runPageAnalysis({ force = false, complete = false, render = true } = {}) {
  if (render) {
    els.stepScope.hidden = false;
    els.scopeHeading.textContent = "Likely extraction scopes";
    els.scopeHint.textContent = "Page Analysis is checking repeated boundaries, semantics, and result variants without blocking Structure.";
    setStatus(els.scopeStatus, "loading", "Analyzing repeated evidence and likely result types…");
  }
  const context = await pageAnalysisContext();
  const request = ++pageAnalysisRequest;
  let session = null;
  session = ensurePageAnalysisService().start({
    key: context.key,
    context,
    force,
    onUpdate: (report) => {
      if (request !== pageAnalysisRequest) return;
      activePageAnalysis = { key: context.key, session, report };
      if (report.pageUrl) state.pageUrl = report.pageUrl;
      if (render) renderPageAnalysis(report);
    }
  });
  activePageAnalysis = { key: context.key, session, report: session.snapshot() };
  const report = await (complete ? session.complete() : session.leading());
  if (render && request === pageAnalysisRequest && report.chosenSelector && !state.pendingScope && !state.blocks.length) {
    await highlightSelector(report.chosenSelector);
  }
  if (!complete && !report.complete && typeof requestIdleCallback === "function") {
    requestIdleCallback(() => {
      if (request === pageAnalysisRequest) session.prefetch().catch(() => {});
    }, { timeout: 1500 });
  }
  return report;
}

async function findPageScopes() {
  els.stepScope.hidden = false;
  setStatus(els.scopeStatus, "loading", "Finding repeated evidence bundles across the page…");
  try {
    await runPageAnalysis({ force: true, complete: true });
  } catch (error) {
    setStatus(els.scopeStatus, "error", error.message);
  }
}

async function acceptScope(selector) {
  setStatus(els.scopeStatus, "loading", "Accepting scope…");
  try {
    const result = await Site2JsonBridge.run(bridgeAcceptScope, { selector });
    if (!result.ok) {
      setStatus(els.scopeStatus, "error", SCOPE_REASON_MESSAGES[result.reason] || result.message || "Could not accept this scope.");
      return;
    }
    els.scopeShowPageAnalysis.hidden = true;
    state.pageUrl = result.pageUrl;
    ensureSuggestedAdapterMetadata(result.pageUrl);
    const proposed = structureView?.proposals().find((level) => level.best?.selector === selector)?.best || null;
    let recommendation = proposed?.recommendation || null;
    let initialRanking = proposed?.semanticRanking || null;
    const needsSemanticScan = !recommendation || !initialRanking;
    if (needsSemanticScan) await ensureSemanticLibraryInference();
    const [observed, initialVariantItems] = await Promise.all([
      needsSemanticScan ? Site2JsonBridge.run(bridgeDiscoverFields, { scopeSelector: selector }) : Promise.resolve(null),
      proposed?.initialVariantItems
        ? Promise.resolve(proposed.initialVariantItems)
        : Site2JsonBridge.run(bridgeDiscoverVariantItems, { scopeSelector: selector, ...FAST_VARIANT_SCAN })
          .catch((error) => ({ ok: false, message: error.message }))
    ]);
    if (needsSemanticScan) {
      if (observed.ok) {
        const analysis = analyzeSemanticCandidates(observed.candidates, {
          sampledScopes: observed.sampledScopes,
          totalScopes: observed.totalScopes,
          truncated: Boolean(observed.truncated)
        });
        recommendation ||= analysis.recommendation;
        initialRanking ||= analysis.ranking;
      }
    }
    state.pendingScope = {
      selector, matchCount: result.matchCount, sample: result.sample, recommendation,
      semanticRanking: initialRanking,
      initialVariantItems,
      pageShape: proposed?.singleton || els.singleItemScope.checked ? "detail" : "collection"
    };
    els.scopeAccepted.hidden = false;
    els.scopeAccepted.textContent = `Selected: ${selector} (${result.matchCount} matches). Example item: <${result.sample.tag}>`;
    els.scopeLevels.hidden = true;
    els.scopeAdjustments.hidden = true;
    els.blockName.value = state.blocks.length ? `Results ${state.blocks.length + 1}` : "Results";
    els.blockSchemaType.value = recommendation?.confidence === "high" ? recommendation.schemaType : "Thing";
    els.blockSetup.hidden = false;
    setStatus(els.scopeStatus, "ready", recommendation?.confidence === "high"
      ? `Scope selected. Prefilled ${recommendation.label} from ${recommendation.explained}/${recommendation.total} explained observations; review or change it before creating the block.`
      : "Scope selected. Semantic evidence was not decisive, so the entity type remains Thing. Review or change it before creating the block.");
    pinTarget({ selector });
    revealPanel(els.blockSetup, els.blockName);
  } catch (error) {
    setStatus(els.scopeStatus, "error", error.message);
  }
}

function safeEntityName(schemaType, index) {
  const base = String(schemaType || "Thing").split(":").pop().replace(/[^A-Za-z0-9_]/g, "") || "Thing";
  const used = new Set(state.blocks.map((block) => block.entityName));
  if (!used.has(base)) return base;
  let suffix = index + 1;
  while (used.has(`${base}${suffix}`)) suffix += 1;
  return `${base}${suffix}`;
}

function normalizeSchemaType(typeValue) {
  return String(typeValue || "Thing").split(/[\/#:]/).filter(Boolean).pop() || "Thing";
}

function blocksFromAcceptedDetections(report, decisions = {}) {
  const selected = report?.detection?.selected || [];
  const profileDigest = report?.detection?.profileDigest || report?.authoring?.profile?.digest || null;
  const created = [];
  for (const detection of selected) {
    const decision = decisions[detection.id] || {};
    if (decision.state !== "accepted") continue;
    const schemaCandidates = Array.isArray(decision.detectedTypes) && decision.detectedTypes.length > 0
      ? decision.detectedTypes
      : detection.typeSignature;
    const schemaType = normalizeSchemaType(schemaCandidates?.[0] || "Thing");
    const matchCount = Number(detection?.grouping?.entityCount);
    const totalMatches = Number.isFinite(matchCount) && matchCount > 0 ? Math.trunc(matchCount) : 1;
    const index = state.blocks.length + created.length;
    const block = {
      id: `block-${index + 1}`,
      name: schemaType,
      entityName: safeEntityName(schemaType, index),
      schemaType,
      scope: null,
      matchCount: totalMatches,
      arity: totalMatches > 1 ? "many" : "one",
      role: "collection",
      fidelity: "summary",
      pageShape: totalMatches > 1 ? "collection" : "detail",
      identityField: null,
      fields: [],
      requireFields: [],
      monitorFields: [],
      detectionSeed: {
        kind: "page-detection",
        detectionId: detection.id,
        profileDigest,
        reviewedAt: decision.reviewedAt || new Date().toISOString(),
        detectedType: schemaType
      }
    };
    const composition = semanticCompositions?.singleType(schemaType) || null;
    if (composition) block.composition = JSON.parse(JSON.stringify(composition));
    block.semanticsReviewed = false;
    created.push(block);
  }
  return created;
}

function closeSchemaTypeMenu() {
  els.schemaTypeMenu.hidden = true;
  els.blockSchemaType.setAttribute("aria-expanded", "false");
  schemaTypeMenuIndex = -1;
}

function renderSchemaTypeMenu({ showAll = false } = {}) {
  const query = showAll ? "" : els.blockSchemaType.value.trim().toLowerCase();
  const preferred = ["JobPosting", "Product", "Offer", "Organization", "Person", "Event", "Article", "CreativeWork", "Thing"];
  const rank = new Map(preferred.map((name, index) => [name, index]));
  const matches = Site2JsonSchemaVocabulary.typeNames()
    .filter((name) => !query || name.toLowerCase().includes(query))
    .sort((left, right) => (rank.get(left) ?? 1000) - (rank.get(right) ?? 1000) || left.localeCompare(right))
    .slice(0, 30);
  els.schemaTypeMenu.replaceChildren();
  for (const type of matches) {
    const info = Site2JsonSchemaVocabulary.typeInfo(type);
    const option = document.createElement("button");
    option.type = "button";
    option.className = "combobox-option";
    option.setAttribute("role", "option");
    const name = document.createElement("strong");
    name.textContent = type;
    const detail = document.createElement("small");
    detail.textContent = `Schema.org ${info.status}${info.supers.length ? ` · subtype of ${info.supers.join(", ")}` : ""} — ${info.description}`;
    option.append(name, detail);
    option.addEventListener("mousedown", (event) => { event.preventDefault(); });
    option.addEventListener("click", () => { els.blockSchemaType.value = type; closeSchemaTypeMenu(); });
    els.schemaTypeMenu.append(option);
  }
  els.schemaTypeMenu.hidden = matches.length === 0;
  els.blockSchemaType.setAttribute("aria-expanded", matches.length ? "true" : "false");
  schemaTypeMenuIndex = -1;
}

function moveSchemaTypeMenu(delta) {
  const options = Array.from(els.schemaTypeMenu.querySelectorAll(".combobox-option"));
  if (!options.length) return;
  schemaTypeMenuIndex = (schemaTypeMenuIndex + delta + options.length) % options.length;
  options.forEach((option, index) => option.classList.toggle("active", index === schemaTypeMenuIndex));
  options[schemaTypeMenuIndex].scrollIntoView({ block: "nearest" });
}

async function createBlock() {
  if (!state.pendingScope) {
    setStatus(els.scopeStatus, "error", "Choose a scope before creating a block.");
    return false;
  }
  const name = els.blockName.value.trim();
  let schemaType = els.blockSchemaType.value.trim();
  if (!name || !schemaType) {
    setStatus(els.scopeStatus, "error", "Block name and entity type are required.");
    return false;
  }
  const recommended = state.pendingScope?.recommendation;
  let localizedRecommendation = null;
  if (recommended?.confidence === "high" && semanticLibraryInference) {
    localizedRecommendation = semanticLibraryInference.materialize(recommended.modelId, {
      adapterPrefix: adapterPrefix(),
      existingTerms: state.customTerms
    });
    if (localizedRecommendation) {
      state.customTerms = localizedRecommendation.customTerms;
      schemaType = localizedRecommendation.schemaType;
      els.blockSchemaType.value = schemaType;
    }
  }
  const index = state.blocks.length;
  const block = {
    id: `block-${index + 1}`,
    name,
    entityName: safeEntityName(schemaType, index),
    schemaType,
    scope: state.pendingScope.selector,
    matchCount: state.pendingScope.matchCount,
    arity: "many",
    role: "collection",
    fidelity: "summary",
    pageShape: state.pendingScope.pageShape || "collection",
    identityField: null,
    fields: [],
    requireFields: [],
    monitorFields: []
  };
  if (state.pendingScope.semanticRanking) block.semanticRanking = JSON.parse(JSON.stringify(state.pendingScope.semanticRanking));
  const normalized = localizedRecommendation ? null : semanticCompositions?.normalize(block);
  if (localizedRecommendation) {
    block.composition = localizedRecommendation.composition;
    block.semanticModelId = recommended.modelId;
    block.inferenceSchemaType = localizedRecommendation.inferenceSchemaType;
  } else if (normalized) block.composition = normalized.composition;
  if (recommended) block.semanticRecommendation = JSON.parse(JSON.stringify(recommended));
  if (!localizedRecommendation && recommended?.confidence === "high" && recommended.schemaType === schemaType && recommended.modelId?.startsWith("site2json:")) {
    block.composition = semanticCompositions.preset(recommended.modelId) || block.composition;
  }
  if (state.pendingScope.initialVariantItems) {
    block.variantAnalysis = analyzeVariantItems(block, state.pendingScope.initialVariantItems, block.semanticRanking, "initial");
  }
  block.semanticsReviewed = false;
  state.blocks.push(block);
  invalidateBuiltDraft();
  state.pendingScope = null;
  els.blockSetup.hidden = true;
  els.scopeAccepted.hidden = true;
  els.stepBlocks.hidden = false;
  els.stepFields.hidden = false;
  els.stepBuild.hidden = false;
  setStatus(els.scopeStatus, "", "");
  await activateBlock(block.id, { pin: true });
  renderRoute();
  revealPanel(els.structureComplete, els.continueSemantics);
  return true;
}

function cancelBlockSetup() {
  state.pendingScope = null;
  els.blockSetup.hidden = true;
  els.scopeAccepted.hidden = true;
  clearPinnedHighlight();
  setStatus(els.scopeStatus, "", "");
  const block = activeBlock();
  if (block) {
    Site2JsonBridge.run(bridgeAcceptScope, { selector: block.scope }).catch(() => {});
    renderRoute();
    revealPanel(els.structureComplete, els.continueSemantics);
  }
}

function renderBlockTabs() {
  reviewView?.renderPicker(state.blocks, state.activeBlockId);
}

async function activateBlock(blockId, { pin = false } = {}) {
  const block = state.blocks.find((candidate) => candidate.id === blockId);
  if (!block) return;
  state.activeBlockId = block.id;
  if (!variantTargets(block).some((target) => target.entityName === state.activeVariantEntityName)) state.activeVariantEntityName = block.entityName;
  state.pendingField = null;
  await ensureSemanticLibraryInference();
  hideSelectionProposal();
  closeTransformArguments();
  hideFieldEditor();
  const initialVariantScan = !block.variantAnalysis && variantAnalysis
    ? Site2JsonBridge.run(bridgeDiscoverVariantItems, { scopeSelector: block.scope, ...FAST_VARIANT_SCAN })
      .catch((error) => ({ ok: false, message: error.message }))
    : null;
  await Site2JsonBridge.run(bridgeAcceptScope, { selector: block.scope }).catch(() => {});
  renderBlockTabs();
  renderVariantContextControls();
  reviewView?.renderHeading(block, activeEntityTarget(block));
  els.undoDiscovery.disabled = state.lastDiscoveryBatch?.blockId !== block.id || state.lastDiscoveryBatch?.entityName !== activeEntityTarget(block)?.entityName;
  await refreshBlockTable();
  if (initialVariantScan) block.variantAnalysis = analyzeVariantItems(block, await initialVariantScan, block.semanticRanking, "initial");
  if (block.variants?.candidates?.length) await refreshVariantClassification();
  semanticView?.render();
  semanticGraphView?.render();
  if (pin) {
    pinTarget({ selector: block.scope });
    await revealTarget({ selector: block.scope });
  }
}

async function removeField(field) {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  if (!entity) return;
  clearPinnedHighlight();
  if (field.identity) {
    entity.fields = entity.fields.filter((candidate) => candidate.name !== entity.identityField);
    entity.identity = null;
    setStatus(els.discoveryStatus, "ready", `Removed identity field “${field.name}”. Choose or discover another identity before building.`);
  } else {
    const key = Site2JsonFieldDiscovery.sourceKey(field);
    entity.fields = entity.fields.filter((candidate) => Site2JsonFieldDiscovery.sourceKey(candidate) !== key);
    entity.requireFields = entity.requireFields.filter((name) => name !== field.name);
    setStatus(els.discoveryStatus, "ready", `Removed “${field.name}”.`);
  }
  clearDiscoveryUndo();
  invalidateBuiltDraft();
  await refreshBlockTable();
  await refreshNestedVariantClassification(block);
}

function renderBlockTable(block, rows) {
  reviewView?.renderTable(block, rows);
  publishTablePanel();
}
let blockTableRequest = 0;

async function refreshBlockTable() {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  if (!block || !entity) return { ok: false, reason: "no-entity", message: "Select a block and result type before discovering fields." };
  const request = ++blockTableRequest;
  els.blockTableEmpty.textContent = "Loading extracted values…";
  els.blockTableWrap.hidden = true;
  const result = await Site2JsonBridge.run(bridgeBuildBlockTable, {
    scopeSelector: block.scope,
    identityField: entity.identityField,
    fields: entity.fields,
    schemaType: block.schemaType,
    fallbackEntity: block.entityName,
    variants: block.variants || null,
    variantTarget: block.variants ? entity.entityName : null
  }).catch((error) => ({ ok: false, message: error.message }));
  if (request !== blockTableRequest || activeBlock()?.id !== block.id) return;
  if (!result.ok) {
    els.blockTableEmpty.textContent = result.message || "Could not build the extraction table.";
    state.tableRows = [];
    publishTablePanel();
    return;
  }
  entity.matchCount = result.total;
  block.matchCount = result.blockTotal ?? result.total;
  const analyzedRows = new Map((block.variantAnalysis?.mixed ? block.variantAnalysis.rows : []).map((row) => [row.index, row]));
  state.tableRows = result.rows.map((row) => ({ ...row, variant: row.variant || analyzedRows.get(row.index) || null }));
  renderBlockTabs();
  reviewView?.renderHeading(block, entity);
  renderBlockTable({ ...block, identityField: entity.identityField, fields: entity.fields }, state.tableRows);
}

function customRelationshipSuggestions(block, candidate) {
  const evidence = candidate?.evidence || candidate || {};
  const haystack = `${candidate?.suggestedName || ""} ${evidence.id || ""} ${(evidence.classes || []).join(" ")} ${evidence.context || ""} ${evidence.text || ""}`.toLowerCase();
  const normalizedSuggested = String(candidate?.suggestedName || "").replace(/[^a-z0-9]/gi, "").toLowerCase();
  const suggestions = [];
  for (const edge of block?.composition?.edges || []) {
    const term = state.customTerms[edge.property];
    if (term?.kind !== "relationship") continue;
    const aliases = [...new Set([edge.property.split(":").at(-1), ...(term.evidenceAliases || [])])].filter(Boolean);
    let relationshipScore = 0;
    for (const alias of aliases) {
      const lowered = alias.toLowerCase();
      if (haystack.includes(lowered)) relationshipScore = Math.max(relationshipScore, 18);
      if (normalizedSuggested && normalizedSuggested === lowered.replace(/[^a-z0-9]/g, "")) relationshipScore = Math.max(relationshipScore, 32);
    }
    if (relationshipScore < 18) continue;
    const target = block.composition.nodes[edge.to];
    for (const targetType of target?.types || term.rangeIncludes || []) {
      const schema = Site2JsonSchemaVocabulary.suggestions(targetType, evidence)
        .find((candidateTerm) => candidateTerm.source === "schema" && candidateTerm.score >= 6)
        || Site2JsonSchemaVocabulary.property(targetType, candidate.kind === "url" ? "url" : "name");
      if (!schema) continue;
      suggestions.push({
        ...schema,
        name: `${edge.property}.${schema.name}`,
        source: "extension",
        score: relationshipScore + Math.max(0, schema.score || 0),
        description: `${term.description} ${schema.description}`,
        vocabularyTerm: term,
        catalogValidity: {
          authority: "local-vocabulary",
          domain: { status: "valid", match: "direct", declared: [...(term.domainIncludes || [])] },
          range: { status: "declared", declared: [...(term.rangeIncludes || [])] },
          relationship: {
            property: edge.property,
            sourceTypes: [...(term.domainIncludes || [])],
            declaredTargetTypes: [...(term.rangeIncludes || [])],
            targetType
          }
        },
        semanticPrior: {
          salience: 40,
          cardinality: { value: schema.cardinality || "one", source: "site2json-authoring-default" }
        }
      });
    }
  }
  return suggestions.sort((left, right) => right.score - left.score);
}

function discoveredFieldSuggestions(block, entity, candidate, { allowInferredExtensions = true, profile = null } = {}) {
  const inferenceType = entity.inferenceSchemaType || entity.schemaType;
  const schemaInferenceType = semanticLibraryInference?.schemaFallback(inferenceType) || entity.schemaType;
  const candidateContext = `${candidate.selector || ""} ${candidate.suggestedName || ""} ${candidate.evidence?.context || ""}`.toLowerCase();
  const librarySuggestions = semanticLibraryInference?.propertySuggestions(inferenceType, candidate, {
    adapterPrefix: adapterPrefix(),
    existingTerms: state.customTerms
  }) || [];
  const profileSuggestions = profile && typeExtractionProfileApi
    ? typeExtractionProfileApi.suggestions(profile, candidate, {
      adapterPrefix: adapterPrefix(),
      allowInferredExtensions,
      librarySuggestions
    })
    : [
      ...librarySuggestions,
      ...Site2JsonSchemaVocabulary.suggestions(schemaInferenceType, candidate.evidence, { adapterPrefix: allowInferredExtensions ? adapterPrefix() : "" })
    ];
  return [
    ...(entity.entityName === block.entityName ? customRelationshipSuggestions(block, candidate) : []),
    ...profileSuggestions
  ];
}

function resolvedDiscoveredTerm(candidate, term) {
  if (!term) return null;
  return {
    ...term,
    transform: Site2JsonSchemaVocabulary.defaultPipeline(term, candidate.kind)
  };
}

function resolveDiscoveredField(block, entity, candidate, { allowInferredExtensions = true, profile = null } = {}) {
  const suggestions = discoveredFieldSuggestions(block, entity, candidate, { allowInferredExtensions, profile });
  const corroborated = fieldMappingCorroboratorApi?.corroborate(candidate, suggestions) || null;
  const term = corroborated ? corroborated.term : suggestions.find((suggestion) => {
    const leafName = suggestion.leafName || suggestion.name.split(".").at(-1);
    return ((suggestion.source === "extension" && suggestion.score >= 18) || (suggestion.source === "schema" && suggestion.score >= 6))
      && !(suggestion.source === "schema" && candidate.multiple && suggestion.cardinality !== "many")
      && !(suggestion.source === "schema" && candidate.kind === "url" && /\b(?:apply|avatar|category|skill|tag|navigation|menu)\b/.test(candidateContext))
      && !(suggestion.source === "schema" && leafName === "sameAs" && !/\b(?:sameas|social|profile)\b/.test(candidateContext))
      && !(leafName === "sameAs" && /\b(?:apply|category|skill|tag|navigation|menu)\b/.test(candidateContext))
      && !(suggestion.name === "url" && (candidate.multiple || candidate.kind !== "url" || candidate.attribute !== "href"))
      && !(leafName === "image" && (candidate.evidence?.tag !== "img" || candidate.attribute !== "src"));
  });
  return resolvedDiscoveredTerm(candidate, term);
}

let discoveryRequest = 0;

function setDiscoveryReport(kind, message) {
  state.discoveryReport = { blockId: state.activeBlockId, kind, message };
  setStatus(els.discoveryStatus, kind, message);
  if (els.discoveryReportDetails) {
    els.discoveryReportDetails.hidden = !message;
    els.discoveryReportDetails.open = kind === "loading" || kind === "error";
  }
  renderDiscoveryCompletion();
}

async function discoverFields({
  includeUnmapped = els.includeUnmappedFields.checked,
  allowInferredExtensions = includeUnmapped
} = {}) {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  if (!block || !entity) return;
  const request = ++discoveryRequest;
  els.discoverFields.disabled = true;
  setDiscoveryReport("loading", "Sampling rendered items and matching their recurring values…");
  publishTablePanel();
  try {
    await ensureSemanticLibraryInference();
    const inferenceType = entity.inferenceSchemaType || entity.schemaType;
    const schemaInferenceType = semanticLibraryInference?.schemaFallback(inferenceType) || entity.schemaType;
    const profile = typeExtractionProfileApi?.build(inferenceType, {
      schemaType: schemaInferenceType,
      libraryProperties: semanticLibraryInference?.propertiesForType(inferenceType, {
        adapterPrefix: adapterPrefix(),
        existingTerms: state.customTerms
      }) || [],
      customTerms: state.customTerms
    }) || null;
    const result = await Site2JsonBridge.run(bridgeDiscoverFields, {
      scopeSelector: block.scope,
      fallbackEntity: block.entityName,
      variantTarget: block.variants ? entity.entityName : null,
      variants: block.variants || null
    });
    if (request !== discoveryRequest || activeBlock()?.id !== block.id || activeEntityTarget()?.entityName !== entity.entityName) {
      return { ok: false, reason: "stale", message: "Field discovery was superseded by another editor action." };
    }
    if (!result.ok) {
      const messages = {
        "invalid-scope": "The block scope is not a valid CSS selector.",
        "no-scope": "The block scope no longer matches any rendered items.",
        "no-variant-scopes": `No rendered items currently classify as ${entity.schemaType}. Review its evidence in Semantics.`
      };
      setDiscoveryReport("error", messages[result.reason] || result.message || "Could not discover fields in this block.");
      return { ok: false, reason: result.reason || "discovery", message: messages[result.reason] || result.message || "Could not discover fields in this block." };
    }
    const previousFields = entity.fields.map((field) => ({ ...field, transform: [...(field.transform || [])] }));
    const previousIdentityField = entity.identityField || null;
    const previousRequireFields = [...entity.requireFields];
    const previousCustomTerms = JSON.parse(JSON.stringify(state.customTerms));
    const candidates = result.candidates;
    const arbitration = semanticMappingArbitratorApi?.arbitrate(
      candidates.map((candidate) => ({
        candidate,
        suggestions: discoveredFieldSuggestions(block, entity, candidate, { allowInferredExtensions, profile })
      })),
      {
        existingPropertyNames: entity.fields.filter((field) => !field.unresolved).map((field) => field.name),
        expectedProperties: [...new Set([entity.identityField, ...(entity.requireFields || [])].filter(Boolean))],
        relationshipExpectations: Object.fromEntries((block.composition?.edges || []).map((edge) => [edge.property, edge.expectation || "optional"]))
      }
    ) || null;
    for (const assignment of arbitration?.assignments || []) {
      if (assignment.report) assignment.candidate.corroboration = assignment.report;
    }
    const arbitratedTerms = arbitration
      ? new Map(arbitration.assignments.map((assignment) => [assignment.candidate, resolvedDiscoveredTerm(assignment.candidate, assignment.term)]))
      : null;
    const reconciled = Site2JsonFieldDiscovery.reconcile(
      entity.fields,
      candidates,
      (candidate) => arbitratedTerms
        ? arbitratedTerms.get(candidate) || null
        : resolveDiscoveredField(block, entity, candidate, { allowInferredExtensions, profile }),
      { includeUnmapped }
    );
    entity.fields = reconciled.fields;
    if (!entity.identity && block.pageShape === "detail" && result.totalScopes === 1 && !entity.fields.some((field) => field.name === "url")) {
      const pageUrlField = {
        name: "url",
        source: "pageUrl",
        selector: ":scope",
        attribute: null,
        kind: "url",
        multiple: false,
        transform: ["absoluteUrl", "stripQuery"],
        provenance: "discovery",
        locked: false,
        unresolved: false,
        semanticSource: "schema",
        sourceKey: ["pageUrl", "", "url"].join("\u001f"),
        evidence: { tag: "document", attribute: null, classes: [], text: state.pageUrl, value: state.pageUrl, context: "single detail page URL", multiple: false, matchCounts: [1] },
        coverage: { present: 1, sampled: 1 },
        sampleValues: [state.pageUrl],
        corroboration: {
          version: 1, status: "accepted", confidence: "strong", property: "url", source: "schema",
          score: 100, adjustedScore: 100, margin: 100, runnerUp: null,
          signals: [
            { kind: "value", strength: "strong", reason: "The rendered document URL is a valid URL value." },
            { kind: "structure", strength: "strong", reason: "A singleton detail page supplies its own canonical page URL." }
          ],
          reasons: []
        }
      };
      entity.fields.unshift(pageUrlField);
      reconciled.summary.added += 1;
    }
    let identityAdded = 0;
    if (!entity.identity) {
      const identity = Site2JsonFieldDiscovery.identityFieldCandidate(entity.fields);
      if (identity) {
        entity.identityField = identity.name;
        for (const field of entity.fields) field.identity = field.name === identity.name;
        identityAdded = 1;
      }
    }
    for (const field of entity.fields) {
      if (field.semanticSource !== "extension" || !field.vocabularyTerm) continue;
      const rootName = extensionRoot(field.name);
      if (!state.customTerms[rootName]) state.customTerms[rootName] = JSON.parse(JSON.stringify(field.vocabularyTerm));
    }
    invalidateBuiltDraft();
    state.lastDiscoveryBatch = { blockId: block.id, entityName: entity.entityName, previousFields, previousIdentityField, previousRequireFields, previousCustomTerms };
    els.undoDiscovery.disabled = false;
    await refreshBlockTable();
    await refreshNestedVariantClassification(block);
    const { added, upgraded, unchanged, skipped, unresolved, pruned } = reconciled.summary;
    const truncation = result.truncated ? " The first item exceeded the 400-element discovery limit." : "";
    const identityMessage = identityAdded ? ` Selected “${entity.identityField}” as the canonical identity.` : "";
    const prunedMessage = pruned ? ` Removed ${pruned} redundant unresolved presentation field${pruned === 1 ? "" : "s"}.` : "";
    setDiscoveryReport("ready", `${entity.schemaType}: scanned ${result.sampledScopes}/${result.totalScopes} classified items${result.blockTotalScopes ? ` from ${result.blockTotalScopes} block matches` : ""}.${identityMessage} Fields: added ${added}, upgraded ${upgraded}, kept ${unchanged}; excluded ${skipped} duplicate or unsupported candidate${skipped === 1 ? "" : "s"}.${prunedMessage} ${unresolved} newly added field${unresolved === 1 ? " is" : "s are"} unresolved.${truncation}`);
    if (entity.fields.length) revealPanel(els.discoveryComplete, els.continueReview);
    return { ok: true, result, reconciled, identityAdded, entityName: entity.entityName, profile: profile?.summary || null };
  } catch (error) {
    if (request === discoveryRequest) setDiscoveryReport("error", error.message);
    return { ok: false, reason: "error", message: error.message };
  } finally {
    if (request === discoveryRequest) els.discoverFields.disabled = false;
  }
}

function clearDiscoveryUndo() {
  state.lastDiscoveryBatch = null;
  els.undoDiscovery.disabled = true;
}

function invalidateBuiltDraft() {
  state.lastValidDefinition = null;
  if (!state.inferenceRunning && state.inferenceRun && !state.inferenceRun.stale) {
    state.inferenceRun = { ...state.inferenceRun, reviewReady: false, stale: true };
  }
  state.driftReview = { status: "idle", findings: [], message: "Validate the adapter before checking structural health." };
  els.previewExtraction.disabled = true;
  setDraftControls();
  scheduleDraftAutosave();
}

async function undoDiscovery() {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  const batch = state.lastDiscoveryBatch;
  if (!block || !entity || !batch || batch.blockId !== block.id || batch.entityName !== entity.entityName) return;
  entity.fields = batch.previousFields;
  entity.identityField = batch.previousIdentityField || null;
  for (const field of entity.fields) field.identity = field.name === entity.identityField;
  entity.requireFields = batch.previousRequireFields;
  state.customTerms = batch.previousCustomTerms;
  invalidateBuiltDraft();
  clearDiscoveryUndo();
  await refreshBlockTable();
  setDiscoveryReport("ready", "The most recent discovery batch was undone.");
  publishTablePanel();
}

function updateFieldKindVisibility() {
  els.fieldAttributeLabel.style.display = "";
  els.fieldAttribute.placeholder = els.fieldKind.value === "url" ? "href" : "optional, e.g. datetime or alt";
}

function selectedPipeline() {
  return Site2JsonTransformPicker.clonePipeline(state.pendingField?.pipeline || []);
}

function setPipeline(pipeline) {
  if (!state.pendingField) return;
  closeTransformArguments();
  state.pendingField.pipeline = Site2JsonTransformPicker.clonePipeline(pipeline);
  renderTransformSteps();
}

function recommendedTransformNames() {
  if (els.fieldIdentity.checked || els.fieldKind.value === "url") return ["absoluteUrl", "stripQuery"];
  const name = els.fieldName.value.trim();
  const candidate = state.pendingField?.semanticCandidates?.find((term) => term.name === name) || null;
  const term = candidate || Site2JsonSchemaVocabulary.property(activeBlock()?.schemaType, name);
  return Site2JsonSchemaVocabulary.defaultPipeline(term, els.fieldKind.value)
    .filter((step) => typeof step === "string");
}

function renderTransformSteps() {
  if (!els.transformSteps) return;
  const pipeline = selectedPipeline();
  els.transformSteps.replaceChildren();
  let locked = 0;
  if (!pipeline.length) {
    const empty = document.createElement("span");
    empty.className = "transform-empty";
    empty.textContent = "No transforms selected";
    els.transformSteps.append(empty);
  }
  pipeline.forEach((step, index) => {
    const isLocked = Site2JsonTransformPicker.isLocked(step);
    const detail = Site2JsonTransformCatalog.details(Site2JsonTransformPicker.stepName(step));
    const configurable = !isLocked && detail?.maximumArguments > 0;
    const token = document.createElement("span");
    token.className = `transform-step${isLocked ? " locked" : ""}${configurable ? " configured" : ""}`;
    token.dataset.index = String(index);
    token.dataset.name = Site2JsonTransformPicker.stepName(step);
    token.textContent = Site2JsonTransformPicker.formatStep(step);
    if (isLocked) {
      locked += 1;
      token.title = "This packaged transform does not expose compatible editor argument metadata, so it is preserved unchanged.";
    } else {
      if (configurable) {
        token.title = "Click to edit transform arguments.";
        token.addEventListener("click", () => { openTransformArguments(detail.name, index, step); });
      }
      const remove = document.createElement("button");
      remove.type = "button";
      remove.setAttribute("aria-label", `Remove ${Site2JsonTransformPicker.stepName(step)}`);
      remove.textContent = "×";
      remove.addEventListener("click", (event) => {
        event.stopPropagation();
        const result = Site2JsonTransformPicker.removeAt(selectedPipeline(), index);
        if (!result.removed) return;
        if (state.pendingTransform) closeTransformArguments();
        state.pendingField.pipeline = result.pipeline;
        renderTransformSteps();
        refreshFieldPreview();
      });
      token.append(remove);
    }
    els.transformSteps.append(token);
  });
  els.transformStatus.textContent = locked
    ? `${locked} transform${locked === 1 ? " is" : "s are"} preserved because compatible packaged argument metadata is unavailable.`
    : "Add packaged transforms in execution order. Click a configured token to edit its arguments.";
}

function closeTransformArguments() {
  state.pendingTransform = null;
  if (els.transformArgumentForm) els.transformArgumentForm.hidden = true;
  if (els.transformArgumentFields) els.transformArgumentFields.replaceChildren();
  if (els.transformArgumentStatus) setStatus(els.transformArgumentStatus, "", "");
}

function openTransformArguments(name, index, step = null) {
  const detail = Site2JsonTransformCatalog.details(name);
  if (!detail || !Site2JsonTransformPicker.editable(name) || detail.maximumArguments === 0) return;
  state.pendingTransform = { name, index };
  const values = Site2JsonTransformPicker.argumentValues(step || { name, args: [] });
  els.transformArgumentTitle.textContent = `${index < selectedPipeline().length ? "Edit" : "Add"} ${detail.label}`;
  els.transformArgumentDescription.textContent = `${detail.input} → ${detail.output}. ${detail.description}`;
  els.transformArgumentFields.replaceChildren();
  detail.argumentDefinitions.forEach((definition, argumentIndex) => {
    const required = argumentIndex < detail.minimumArguments && definition.required !== false;
    const label = document.createElement("label");
    label.textContent = `${definition.label}${required ? "" : " (optional)"}`;
    const input = definition.type === "string-list" || definition.type === "object"
      ? document.createElement("textarea")
      : document.createElement("input");
    input.dataset.argumentIndex = String(argumentIndex);
    input.value = values[argumentIndex] || "";
    if (definition.type === "integer") {
      input.type = "number";
      input.step = "1";
      if (definition.minimum !== undefined) input.min = String(definition.minimum);
      if (definition.maximum !== undefined) input.max = String(definition.maximum);
    } else if (input.tagName === "INPUT") {
      input.type = "text";
    }
    const help = document.createElement("small");
    help.textContent = definition.description;
    label.append(input, help);
    els.transformArgumentFields.append(label);
  });
  setStatus(els.transformArgumentStatus, "", "");
  els.transformArgumentForm.hidden = false;
  els.transformArgumentForm.scrollIntoView?.({ block: "nearest" });
  els.transformArgumentFields.querySelector("input, textarea")?.focus();
}

function saveTransformArguments() {
  if (!state.pendingField || !state.pendingTransform) return;
  const { name, index } = state.pendingTransform;
  const values = Array.from(els.transformArgumentFields.querySelectorAll("[data-argument-index]"), (input) => input.value);
  try {
    const step = Site2JsonTransformPicker.parseArguments(name, values);
    state.pendingField.pipeline = Site2JsonTransformPicker.setAt(selectedPipeline(), index, step);
    closeTransformArguments();
    renderTransformSteps();
    refreshFieldPreview();
  } catch (error) {
    setStatus(els.transformArgumentStatus, "error", error.message);
  }
}

function closeTransformMenu() {
  els.transformMenu.hidden = true;
  els.fieldTransform.setAttribute("aria-expanded", "false");
  transformMenuIndex = -1;
}

function selectTransformCandidate(name) {
  els.fieldTransform.value = "";
  closeTransformMenu();
  const detail = Site2JsonTransformCatalog.details(name);
  if (detail?.maximumArguments > 0) {
    openTransformArguments(name, selectedPipeline().length);
  } else {
    closeTransformArguments();
    state.pendingField.pipeline = Site2JsonTransformPicker.addZeroArgument(selectedPipeline(), name);
    renderTransformSteps();
    els.fieldTransform.focus();
    refreshFieldPreview();
  }
}

function renderTransformMenu({ showAll = false } = {}) {
  if (!state.pendingField) return closeTransformMenu();
  const query = showAll ? "" : els.fieldTransform.value;
  const groups = Site2JsonTransformCatalog.grouped(query, {
    recommended: recommendedTransformNames()
  });
  els.transformMenu.replaceChildren();
  for (const group of groups) {
    const section = document.createElement("section");
    section.className = "combobox-group";
    const heading = document.createElement("div");
    heading.className = "combobox-group-label";
    heading.textContent = group.name;
    section.append(heading);
    for (const candidate of group.items) {
      const option = document.createElement("button");
      option.type = "button";
      option.className = "combobox-option transform-option";
      option.setAttribute("role", "option");
      option.dataset.name = candidate.name;
      const name = document.createElement("strong");
      name.textContent = candidate.label;
      const detail = document.createElement("small");
      const argumentsLabel = candidate.maximumArguments ? ` · ${candidate.minimumArguments === candidate.maximumArguments ? candidate.minimumArguments : `${candidate.minimumArguments}–${candidate.maximumArguments}`} argument${candidate.maximumArguments === 1 ? "" : "s"}` : "";
      detail.textContent = `${candidate.name}${argumentsLabel} · ${candidate.input} → ${candidate.output} — ${candidate.description}`;
      option.append(name, detail);
      option.addEventListener("mousedown", (event) => { event.preventDefault(); });
      option.addEventListener("click", () => { selectTransformCandidate(candidate.name); });
      section.append(option);
    }
    els.transformMenu.append(section);
  }
  const options = els.transformMenu.querySelectorAll(".transform-option");
  els.transformMenu.hidden = options.length === 0;
  els.fieldTransform.setAttribute("aria-expanded", options.length ? "true" : "false");
  transformMenuIndex = -1;
}

function moveTransformMenu(delta) {
  const options = Array.from(els.transformMenu.querySelectorAll(".transform-option"));
  if (!options.length) return;
  transformMenuIndex = (transformMenuIndex + delta + options.length) % options.length;
  options.forEach((option, index) => option.classList.toggle("active", index === transformMenuIndex));
  options[transformMenuIndex].scrollIntoView({ block: "nearest" });
}

function adapterPrefix() {
  return els.adapterId.value.trim();
}

function extensionRoot(name) {
  return name.split(".")[0];
}

function renderFieldNameSuggestions(evidence) {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  if (!block || !entity) return [];
  const inferenceType = entity.inferenceSchemaType || entity.schemaType;
  const schemaInferenceType = semanticLibraryInference?.schemaFallback(inferenceType) || entity.schemaType;
  const suggestions = [
    ...(entity.entityName === block.entityName ? customRelationshipSuggestions(block, { evidence, suggestedName: evidence?.id || "", kind: evidence?.href ? "url" : "text" }) : []),
    ...(semanticLibraryInference?.propertySuggestions(inferenceType, {
      evidence,
      suggestedName: evidence?.id || "",
      kind: evidence?.href ? "url" : "text"
    }, { adapterPrefix: adapterPrefix(), existingTerms: state.customTerms }) || []),
    ...Site2JsonSchemaVocabulary.suggestions(schemaInferenceType, evidence, { adapterPrefix: adapterPrefix() })
  ];
  for (const [name, term] of Object.entries(state.customTerms)) {
    if (!suggestions.some((candidate) => candidate.name === name)) suggestions.push({ name, ...term, source: "extension", score: 0 });
  }
  state.pendingField.semanticCandidates = suggestions;
  return suggestions;
}

function closeFieldNameMenu() {
  els.fieldNameMenu.hidden = true;
  els.fieldName.setAttribute("aria-expanded", "false");
  fieldNameMenuIndex = -1;
}

function selectFieldNameCandidate(candidate) {
  if (!state.pendingField.semanticCandidates.some((current) => current.name === candidate.name)) state.pendingField.semanticCandidates.push(candidate);
  els.fieldName.value = candidate.name;
  if (candidate.valueType === "URL" && state.pendingField?.evidence?.href) {
    els.fieldKind.value = "url";
    els.fieldAttribute.value = "href";
  }
  updateFieldKindVisibility();
  updateFieldSemantics({ chooseDefaults: true });
  closeFieldNameMenu();
  refreshFieldPreview();
}

function renderFieldNameMenu({ showAll = false } = {}) {
  if (!state.pendingField || els.fieldIdentity.checked) return closeFieldNameMenu();
  const query = showAll ? "" : els.fieldName.value.trim().toLowerCase();
  let candidates = state.pendingField.semanticCandidates.filter((candidate) => !query || candidate.name.toLowerCase().includes(query));
  const prefix = adapterPrefix();
  if (query && !query.includes(":") && prefix && !Site2JsonSchemaVocabulary.property(activeEntityTarget()?.schemaType, query)) {
    const extensionName = `${prefix}:${els.fieldName.value.trim().replace(/[^A-Za-z0-9_-]/g, "")}`;
    candidates = [...candidates, {
      name: extensionName, source: "extension", valueType: "Text", cardinality: "one",
      description: "Create and document a new adapter extension term.", score: -1,
      example: state.pendingField.evidence?.text || ""
    }];
  }
  candidates = candidates.slice(0, 14);
  els.fieldNameMenu.replaceChildren();
  for (const candidate of candidates) {
    const option = document.createElement("button");
    option.type = "button";
    option.className = `combobox-option${candidate.source === "extension" ? " extension" : ""}`;
    option.setAttribute("role", "option");
    option.dataset.name = candidate.name;
    const name = document.createElement("strong");
    name.textContent = candidate.name;
    const detail = document.createElement("small");
    const valueTypes = candidate.ranges?.join(" | ") || candidate.valueType;
    const source = candidate.source === "extension" ? "Adapter extension" : `Schema.org ${candidate.status || "core"}`;
    detail.textContent = `${source} · ${valueTypes} · editor default: ${candidate.cardinality} — ${candidate.description}`;
    option.append(name, detail);
    option.addEventListener("mousedown", (event) => { event.preventDefault(); });
    option.addEventListener("click", () => { selectFieldNameCandidate(candidate); });
    els.fieldNameMenu.append(option);
  }
  els.fieldNameMenu.hidden = candidates.length === 0;
  els.fieldName.setAttribute("aria-expanded", candidates.length ? "true" : "false");
  fieldNameMenuIndex = -1;
}

function moveFieldNameMenu(delta) {
  const options = Array.from(els.fieldNameMenu.querySelectorAll(".combobox-option"));
  if (!options.length) return;
  fieldNameMenuIndex = (fieldNameMenuIndex + delta + options.length) % options.length;
  options.forEach((option, index) => option.classList.toggle("active", index === fieldNameMenuIndex));
  options[fieldNameMenuIndex].scrollIntoView({ block: "nearest" });
}

function updateFieldSemantics({ chooseDefaults = false, showErrors = true } = {}) {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  if (!block || !entity || !state.pendingField) return;
  if (els.fieldIdentity.checked) {
    els.customTermForm.hidden = true;
    els.fieldSemanticStatus.className = "semantic-status standard";
    els.fieldSemanticStatus.textContent = "Identity · emitted as @id/url, outside the ordinary field vocabulary.";
    setPipeline(["absoluteUrl", "stripQuery"]);
    return;
  }
  const name = els.fieldName.value.trim();
  const recommended = state.pendingField.semanticCandidates?.find((candidate) => candidate.name === name) || null;
  const term = Site2JsonSchemaVocabulary.property(entity.schemaType, name);
  if (term) {
    els.customTermForm.hidden = true;
    els.fieldSemanticStatus.className = "semantic-status standard";
    els.fieldSemanticStatus.textContent = `Schema.org ${term.status || "core"} ${entity.schemaType}.${term.name} · ${(term.ranges || [term.valueType]).join(" | ")} · editor default: ${term.cardinality}. ${term.description}`;
    if (chooseDefaults) {
      els.fieldMultiple.checked = term.cardinality === "many";
      setPipeline(Site2JsonSchemaVocabulary.defaultPipeline(recommended || term, els.fieldKind.value));
    }
    return;
  }
  if (!name) {
    els.customTermForm.hidden = true;
    els.fieldSemanticStatus.className = "semantic-status";
    els.fieldSemanticStatus.textContent = `Choose a known ${entity.schemaType} property, or enter an adapter extension term.`;
    return;
  }
  const prefix = adapterPrefix();
  if (!name.includes(":")) {
    els.customTermForm.hidden = true;
    els.fieldSemanticStatus.className = `semantic-status${showErrors ? " error" : ""}`;
    els.fieldSemanticStatus.textContent = showErrors
      ? `“${name}” is not in the packaged ${entity.schemaType} vocabulary. Use ${prefix || "adapter"}:${name} to define an extension term.`
      : `Choose a ${entity.schemaType} property from the suggestions, or use ${prefix || "adapter"}:${name} to create a documented extension term.`;
    return;
  }
  const rootName = extensionRoot(name);
  if (!prefix || !rootName.startsWith(`${prefix}:`)) {
    els.customTermForm.hidden = true;
    els.fieldSemanticStatus.className = `semantic-status${showErrors ? " error" : ""}`;
    els.fieldSemanticStatus.textContent = `Extension terms must use this adapter's ${prefix || "configured"}: prefix. Nested paths can be added after the registered root term later.`;
    return;
  }
  const existing = state.customTerms[rootName];
  els.customTermForm.hidden = false;
  els.fieldSemanticStatus.className = "semantic-status extension";
  els.fieldSemanticStatus.textContent = existing ? `Adapter extension ${rootName} · already documented in this draft${name === rootName ? "." : `; ${name} is a nested value.`}` : `New adapter extension ${rootName} · document it below before adding the field.`;
  if (existing) {
    els.customTermDescription.value = existing.description;
    els.customTermValueType.value = existing.valueType;
    els.customTermExample.value = typeof existing.example === "string" ? existing.example : JSON.stringify(existing.example);
  } else if (chooseDefaults) {
    els.customTermDescription.value = recommended?.description || "";
    els.customTermValueType.value = recommended?.valueType || "Text";
    els.customTermExample.value = recommended?.example || state.pendingField.evidence?.text || "";
    els.fieldMultiple.checked = recommended?.cardinality === "many";
    setPipeline(Site2JsonSchemaVocabulary.defaultPipeline(recommended, els.fieldKind.value));
  }
}

function renderFieldSelectorSuggestions(candidates) {
  els.fieldSelectorSuggestions.replaceChildren();
  for (const candidate of candidates) {
    const option = document.createElement("option");
    option.value = candidate.selector;
    const kind = candidate.kind === "derived" ? "generated-class prefix · fragile" : candidate.kind;
    option.label = `${candidate.matchCount} match${candidate.matchCount === 1 ? "" : "es"} in example · ${kind}`;
    els.fieldSelectorSuggestions.append(option);
  }
  els.fieldSelector.value = state.pendingField?.selector || "";
}

function hideSelectionProposal() {
  state.selectionProposal = null;
  els.selectionProposal.hidden = true;
}

let selectionProposalRequest = 0;

async function refreshSelectionProposal() {
  if (!state.pendingField || els.stepFieldEditor.hidden) {
    hideSelectionProposal();
    publishTablePanel();
    return;
  }
  const request = ++selectionProposalRequest;
  try {
    const result = await Site2JsonBridge.run(bridgeAddFieldCandidate);
    if (request !== selectionProposalRequest || !state.pendingField) return;
    if (!result.ok || !result.candidates?.length) {
      hideSelectionProposal();
      publishTablePanel();
      return;
    }
    const candidate = result.candidates[0];
    const selectedAttribute = result.href ? "href" : result.src ? "src" : (els.fieldKind.value === "url" ? (els.fieldAttribute.value.trim() || "href") : null);
    const preview = await Site2JsonBridge.run(bridgePreviewField, {
      selector: candidate.selector,
      attribute: selectedAttribute,
      kind: selectedAttribute ? "url" : els.fieldKind.value,
      multiple: els.fieldMultiple.checked,
      transform: selectedPipeline()
    });
    if (request !== selectionProposalRequest || !state.pendingField || !preview.ok) return;
    state.selectionProposal = { result, candidate, attribute: selectedAttribute, preview };
    els.selectionProposalSummary.textContent = `Selected <${result.element.tag}>${result.element.text ? ` · ${result.element.text}` : ""}`;
    els.selectionProposalSelector.textContent = `${candidate.selector}${selectedAttribute ? `@${selectedAttribute}` : ""}`;
    const counts = [...new Set(preview.matchCounts || [])].join(", ") || "0";
    els.selectionProposalCoverage.textContent = `Coverage ${preview.coverage.present}/${preview.coverage.sampled} · matches per item: ${counts}`;
    els.selectionProposal.hidden = false;
    publishTablePanel();
  } catch {
    if (request === selectionProposalRequest) {
      hideSelectionProposal();
      publishTablePanel();
    }
  }
}

async function useSelectionProposal() {
  const proposal = state.selectionProposal;
  if (!proposal || !state.pendingField) return;
  state.pendingField.selector = proposal.candidate.selector;
  state.pendingField.source = null;
  state.pendingField.defaultSelector = proposal.candidate.selector;
  state.pendingField.selectorManuallyChosen = true;
  state.pendingField.candidates = proposal.result.candidates;
  state.pendingField.evidence = { ...proposal.result.element, href: proposal.result.href, src: proposal.result.src };
  if (proposal.attribute) {
    els.fieldKind.value = "url";
    els.fieldAttribute.value = proposal.attribute;
    updateFieldKindVisibility();
  }
  renderFieldSelectorSuggestions(state.pendingField.candidates);
  setStatus(els.fieldStatus, "ready", "The selected element's selector is in the form. Review its preview, then save explicitly.");
  await refreshFieldPreview();
}

async function pickField({ selectedOnPage = false } = {}) {
  showFieldEditor("Add selected field");
  els.fieldForm.hidden = true;
  if (!selectedOnPage) {
    hideSelectionProposal();
    await startVisualSelection("new-field");
    return;
  }
  setStatus(els.fieldStatus, "loading", "Reading the selected page element…");
  try {
    const result = await Site2JsonBridge.run(bridgeAddFieldCandidate);
    if (!result.ok) {
      const messages = {
        "no-scope": "Accept a repeating scope first.",
        "no-selection": "Select an element inside a matched card first.",
        "shadow-boundary": shadowBoundaryMessage(result.shadowBoundary),
        "outside-scope": "The selected element isn't inside any card matching the accepted scope. Pick something inside a highlighted card.",
        "is-scope-root": "That's the whole item, not a field inside it. Select a child element such as the title or price and try again."
      };
      setStatus(els.fieldStatus, "error", messages[result.reason] || result.message || "Could not read the current selection.");
      return;
    }
    if (result.candidates.length === 0) {
      setStatus(els.fieldStatus, "error", "No usable selector could be generated for this element within the scope.");
      return;
    }
    const best = result.candidates[0];
    state.pendingField = {
      selector: best.selector,
      defaultSelector: best.selector,
      selectorManuallyChosen: false,
      candidates: result.candidates,
      name: "",
      multiple: false,
      evidence: { ...result.element, href: result.href, src: result.src }
    };
    const semanticSuggestions = renderFieldNameSuggestions(state.pendingField.evidence);
    const recommended = semanticSuggestions.find((term) => term.score > 0) || null;
    els.fieldName.value = recommended?.name || "";
    els.fieldKind.value = result.href || result.src ? "url" : "text";
    els.fieldAttribute.value = result.href ? "href" : result.src ? "src" : "";
    els.fieldMultiple.checked = false;
    els.fieldIdentity.checked = false;
    els.fieldRequired.checked = true;
    els.addField.textContent = "Add field";
    updateFieldKindVisibility();
    updateFieldSemantics({ chooseDefaults: true });
    renderFieldSelectorSuggestions(result.candidates);
    els.fieldForm.hidden = false;
    setStatus(els.fieldStatus, "ready", `Selected <${result.element.tag}>${result.element.text ? `: "${result.element.text}"` : ""}.`);
    hideSelectionProposal();
    await refreshFieldPreview();
  } catch (error) {
    setStatus(els.fieldStatus, "error", error.message);
  }
}

function updateMultipleFieldSelection() {
  if (!state.pendingField || state.pendingField.selectorManuallyChosen) {
    refreshFieldPreview();
    return;
  }
  if (!els.fieldMultiple.checked) {
    state.pendingField.selector = state.pendingField.defaultSelector;
  } else {
    const broader = state.pendingField.candidates
      .filter((candidate) => candidate.kind !== "fallback" && candidate.matchCount > 1)
      .sort((a, b) => b.matchCount - a.matchCount)[0];
    if (broader) state.pendingField.selector = broader.selector;
  }
  renderFieldSelectorSuggestions(state.pendingField.candidates);
  refreshFieldPreview();
}

let fieldSelectorInputTimer = null;

function fieldSelectorChanged() {
  if (!state.pendingField) return;
  state.pendingField.selector = els.fieldSelector.value;
  state.pendingField.source = null;
  state.pendingField.selectorManuallyChosen = true;
  clearTimeout(fieldSelectorInputTimer);
  fieldSelectorInputTimer = setTimeout(refreshFieldPreview, 180);
}

let fieldPreviewRequest = 0;

async function refreshFieldPreview() {
  if (!state.pendingField) return;
  const request = ++fieldPreviewRequest;
  const selector = state.pendingField.selector.trim();
  if (!selector) {
    els.fieldSelector.classList.add("invalid");
    els.fieldSelectorEvidence.className = "selector-evidence error";
    els.fieldSelectorEvidence.textContent = "Enter a CSS selector.";
    els.fieldPreview.textContent = "";
    clearHighlight("transient");
    publishTablePanel();
    return;
  }
  const args = {
    selector,
    source: state.pendingField.source || null,
    attribute: els.fieldKind.value === "url" ? (els.fieldAttribute.value.trim() || "href") : null,
    kind: els.fieldKind.value,
    multiple: els.fieldMultiple.checked,
    transform: selectedPipeline(),
    rootIndexes: activeBlock()?.variants ? state.tableRows.map((row) => row.index) : null
  };
  els.fieldPreview.textContent = "Loading preview…";
  els.fieldSelectorEvidence.className = "selector-evidence";
  els.fieldSelectorEvidence.textContent = "Checking selector…";
  try {
    const result = await Site2JsonBridge.run(bridgePreviewField, args);
    if (request !== fieldPreviewRequest) return;
    if (!result.ok) {
      els.fieldSelector.classList.add("invalid");
      els.fieldSelectorEvidence.className = "selector-evidence error";
      els.fieldSelectorEvidence.textContent = result.message || "Invalid CSS selector.";
      els.fieldPreview.textContent = result.message || "Could not preview this field.";
      clearHighlight("transient");
      publishTablePanel();
      return;
    }
    els.fieldSelector.classList.remove("invalid");
    const exactCandidate = state.pendingField.candidates.find((candidate) => candidate.selector === selector);
    const distinctCounts = [...new Set(result.matchCounts)].join(", ");
    const multipleWarning = !args.multiple && result.matchCounts.some((count) => count > 1)
      ? " · multiple nodes match; only the first will be used"
      : "";
    els.fieldSelectorEvidence.className = "selector-evidence";
    const selectorKind = exactCandidate?.kind === "derived" ? "Generated-class prefix · fragile" : (exactCandidate?.kind || "Custom CSS");
    els.fieldSelectorEvidence.textContent = `${selectorKind} · matches per sampled item: ${distinctCounts || 0} · coverage ${result.coverage.present}/${result.coverage.sampled}${multipleWarning}`;
    els.fieldPreview.textContent = `Coverage: ${result.coverage.present}/${result.coverage.sampled} sampled (of ${result.coverage.total} items)\n${JSON.stringify(result.values, null, 2)}`;
    highlightSelector(selector, activeBlock()?.scope || null);
    publishTablePanel();
  } catch (error) {
    if (request !== fieldPreviewRequest) return;
    els.fieldSelector.classList.add("invalid");
    els.fieldSelectorEvidence.className = "selector-evidence error";
    els.fieldSelectorEvidence.textContent = error.message;
    els.fieldPreview.textContent = error.message;
    clearHighlight("transient");
    publishTablePanel();
  }
}

async function editField(field, { identity = false } = {}) {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  if (!block || !entity) return;
  const evidence = field.evidence || {
    tag: "", id: null, classes: [], text: state.tableRows.find((row) => row.values[field.name] !== null)?.values[field.name] || "", context: "",
    href: field.kind === "url", multiple: field.multiple
  };
  state.pendingField = {
    selector: field.selector,
    source: field.source || null,
    defaultSelector: field.selector,
    selectorManuallyChosen: true,
    candidates: [{ selector: field.selector, kind: "current", matchCount: field.multiple ? 2 : 1, unique: !field.multiple, note: "Current field selector." }],
    evidence,
    editingSourceKey: Site2JsonFieldDiscovery.sourceKey(field),
    editingName: field.name,
    editingIdentity: identity,
    corroboration: field.corroboration ? JSON.parse(JSON.stringify(field.corroboration)) : null,
    originalField: JSON.parse(JSON.stringify(field))
  };
  renderFieldNameSuggestions(evidence);
  els.fieldName.value = field.unresolved ? "" : field.name;
  els.fieldKind.value = field.kind || "text";
  els.fieldAttribute.value = field.attribute || "";
  els.fieldMultiple.checked = Boolean(field.multiple);
  els.fieldIdentity.checked = identity;
  els.fieldRequired.checked = identity || entity.requireFields.includes(field.name);
  els.addField.textContent = identity ? "Save identity field" : "Save field";
  els.deleteField.hidden = false;
  els.deleteField.textContent = identity ? "Delete identity field" : "Delete field";
  updateFieldKindVisibility();
  updateFieldSemantics({ chooseDefaults: false, showErrors: !field.unresolved });
  setPipeline(field.transform || (field.kind === "url" ? ["absoluteUrl", "stripQuery"] : ["text", "trim"]));
  renderFieldSelectorSuggestions(state.pendingField.candidates);
  els.fieldForm.hidden = false;
  showFieldEditor(identity ? `Edit identity field · ${field.name}` : field.unresolved ? "Map discovered field" : `Edit ${field.name}`);
  if (field.unresolved) els.fieldEditorContext.textContent = `${block.name} · ${field.selector}`;
  const localKnowledge = field.corroboration?.localKnowledge;
  const localKnowledgeMessage = localKnowledge?.material
    ? `A local reusable profile changed this automatic decision from ${localKnowledge.withoutProfile?.property || "unresolved"} to ${field.corroboration?.property || "this mapping"}. Review the evidence and save to pin that exact profile snapshot in the adapter.`
    : null;
  setStatus(els.fieldStatus, field.unresolved ? (localKnowledgeMessage ? "warning" : "") : "ready", field.unresolved
    ? (localKnowledgeMessage || "Choose what this discovered value means. Its selector and extracted examples are ready for review.")
    : identity ? `“${field.name}” supplies the entity identity and remains an ordinary semantic field in extracted data.` : `Editing “${field.name}”. Saving marks this field as an explicit author decision.`);
  await Promise.all([refreshFieldPreview(), refreshSelectionProposal()]);
  if (field.unresolved) {
    els.fieldName.value = "";
    updateFieldSemantics({ chooseDefaults: false, showErrors: false });
  }
}

function applyExpandedFieldForm(form, { chooseSemanticDefaults = false } = {}) {
  if (!state.pendingField) return;
  state.pendingField.selector = String(form.selector ?? state.pendingField.selector).trim();
  if (form.selector !== undefined && state.pendingField.source && state.pendingField.selector !== ":scope") state.pendingField.source = null;
  state.pendingField.selectorManuallyChosen = true;
  els.fieldSelector.value = state.pendingField.selector;
  els.fieldName.value = String(form.name ?? els.fieldName.value);
  if (["text", "url"].includes(form.kind)) els.fieldKind.value = form.kind;
  els.fieldAttribute.value = String(form.attribute ?? els.fieldAttribute.value);
  els.fieldMultiple.checked = Boolean(form.multiple);
  els.fieldIdentity.checked = Boolean(form.identity);
  els.fieldRequired.checked = Boolean(form.required);
  updateFieldKindVisibility();
  updateFieldSemantics({ chooseDefaults: chooseSemanticDefaults });
  if (!chooseSemanticDefaults && Array.isArray(form.pipeline)) setPipeline(form.pipeline);
  if (!els.customTermForm.hidden && form.customTerm) {
    els.customTermDescription.value = String(form.customTerm.description || "");
    els.customTermValueType.value = String(form.customTerm.valueType || "Text");
    els.customTermExample.value = String(form.customTerm.example || "");
  }
}

async function addField() {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  if (!block || !entity) {
    setStatus(els.fieldStatus, "error", "Create or select a block first.");
    return;
  }
  const isIdentity = els.fieldIdentity.checked;
  const wasEditing = Boolean(state.pendingField?.editingSourceKey);
  const editingIdentity = Boolean(state.pendingField?.editingIdentity);
  const name = els.fieldName.value.trim();
  if (!name) {
    updateFieldSemantics({ showErrors: true });
    setStatus(els.fieldStatus, "error", "Give this field a name first.");
    return;
  }
  const kind = els.fieldKind.value;
  const attribute = state.pendingField.source ? null : (els.fieldAttribute.value.trim() || (kind === "url" ? "href" : null));
  const pick = {
    name, selector: state.pendingField.selector, attribute, kind,
    ...(state.pendingField.source ? { source: state.pendingField.source } : {}),
    multiple: els.fieldMultiple.checked, transform: selectedPipeline()
  };
  if (isIdentity && pick.multiple) {
    setStatus(els.fieldStatus, "error", "An identity field must produce exactly one value per item.");
    return;
  }
  const editingSourceKey = state.pendingField.editingSourceKey || null;
  const nameConflict = entity.fields.find((candidate) => candidate.name === name && Site2JsonFieldDiscovery.sourceKey(candidate) !== editingSourceKey);
  if (nameConflict) {
    setStatus(els.fieldStatus, "error", `Another field already uses “${name}”. Choose a different mapping or remove the existing field first.`);
    return;
  }
  const schemaTerm = Site2JsonSchemaVocabulary.property(entity.schemaType, name);
  // Identity is emitted as @id/url metadata rather than as an ordinary semantic
  // property. A dotted identity can therefore describe a nested entity path
  // without inventing and documenting an adapter-extension vocabulary term.
  if (!schemaTerm && !isIdentity) {
    if (els.customTermForm.hidden || !els.customTermDescription.value.trim() || !els.customTermExample.value.trim()) {
      updateFieldSemantics({ showErrors: true });
      setStatus(els.fieldStatus, "error", "Document the extension term's meaning and example before adding it.");
      return;
    }
    state.customTerms[extensionRoot(name)] = {
      description: els.customTermDescription.value.trim(),
      valueType: els.customTermValueType.value,
      cardinality: els.fieldMultiple.checked ? "many" : "one",
      example: els.customTermExample.value.trim()
    };
  }
  const previousName = state.pendingField.editingName || name;
  const selectedSemanticTerm = state.pendingField.semanticCandidates?.find((candidate) => candidate.name === name) || null;
  const semanticCorrected = Boolean(state.pendingField.originalField?.unresolved || state.pendingField.originalField?.name !== name);
  const correctionProposal = wasEditing && semanticCorrected && correctionPromotionApi?.proposal
    ? correctionPromotionApi.proposal({
        originalField: state.pendingField.originalField,
        selectedTerm: selectedSemanticTerm || { name },
        evidence: state.pendingField.evidence,
        adapterId: els.adapterId.value.trim() || state.currentDraft?.adapterId || "unsaved-adapter",
        decisionId: `${block.id || block.entityName}:${entity.entityName}:${name}`
      })
    : null;
  entity.fields = [
    ...entity.fields.filter((candidate) => editingSourceKey
      ? Site2JsonFieldDiscovery.sourceKey(candidate) !== editingSourceKey
      : candidate.name !== name),
    {
      ...pick, identity: isIdentity, provenance: "manual", locked: true, unresolved: false,
      semanticSource: schemaTerm ? "schema" : "extension", sourceKey: Site2JsonFieldDiscovery.sourceKey(pick),
      ...(state.pendingField.corroboration ? { corroboration: {
        ...JSON.parse(JSON.stringify(state.pendingField.corroboration)),
        property: name,
        status: "accepted",
        localKnowledge: state.pendingField.corroboration.localKnowledge
          ? { ...JSON.parse(JSON.stringify(state.pendingField.corroboration.localKnowledge)), acceptedByAuthor: true }
          : undefined
      } } : {})
    }
  ];
  entity.identityField = isIdentity ? name : (editingIdentity ? null : entity.identityField);
  for (const field of entity.fields) field.identity = field.name === entity.identityField;
  entity.requireFields = entity.requireFields.filter((candidate) => candidate !== previousName && candidate !== name);
  if (!isIdentity && els.fieldRequired.checked) entity.requireFields.push(name);
  clearDiscoveryUndo();
  invalidateBuiltDraft();
  fieldPreviewRequest += 1;
  state.pendingField = null;
  state.pendingCorrectionPromotion = correctionProposal;
  hideSelectionProposal();
  state.pendingTransform = null;
  closeTransformArguments();
  els.addField.textContent = "Add field";
  els.deleteField.hidden = true;
  closeTransformMenu();
  clearHighlight("transient");
  els.fieldForm.hidden = true;
  hideFieldEditor();
  await refreshBlockTable();
  await refreshNestedVariantClassification(block);
  renderCorrectionPromotion();
  setStatus(els.discoveryStatus, "ready", `${isIdentity ? "Identity" : "Field"} “${pick.name}” ${wasEditing ? "saved" : "added"}.`);
  publishTablePanel();
}

function cancelField() {
  if (visualSelectionIntent && visualSelectionIntent !== "scope") {
    Site2JsonBridge.cancelSelection?.();
    visualSelectionIntent = null;
    els.selectFieldOnPage.disabled = false;
  }
  fieldPreviewRequest += 1;
  state.pendingField = null;
  hideSelectionProposal();
  closeTransformArguments();
  els.addField.textContent = "Add field";
  els.deleteField.hidden = true;
  closeTransformMenu();
  clearHighlight("transient");
  els.fieldForm.hidden = true;
  hideFieldEditor();
  setStatus(els.fieldStatus, "", "");
  publishTablePanel();
}

async function deleteEditedField() {
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  const pending = state.pendingField;
  if (!block || !entity || !pending?.editingSourceKey) return;
  const field = pending.editingIdentity
    ? { ...entity.identity, identity: true }
    : entity.fields.find((candidate) => Site2JsonFieldDiscovery.sourceKey(candidate) === pending.editingSourceKey);
  if (!field) return;
  cancelField();
  await removeField(field);
}

async function saveCorrectionPromotion() {
  const proposal = state.pendingCorrectionPromotion;
  if (!proposal || !correctionPromotionApi?.apply || !semanticLibraryService) return;
  els.saveCorrectionPromotion.disabled = true;
  els.dismissCorrectionPromotion.disabled = true;
  setStatus(els.correctionPromotionStatus, "loading", "Saving a revision-checked profile update…");
  try {
    const saved = await correctionPromotionApi.apply(semanticLibraryService, proposal);
    semanticLibraryInference?.invalidate();
    pageAnalysisService?.invalidate();
    state.pendingCorrectionPromotion = null;
    renderCorrectionPromotion();
    setStatus(els.discoveryStatus, "ready", `Saved reusable guidance to ${saved.map((record) => record.label || record.termId || record.id).join(", ")}. Current adapter mappings were not changed.`);
  } catch (error) {
    setStatus(els.correctionPromotionStatus, "error", error.message);
  } finally {
    els.saveCorrectionPromotion.disabled = false;
    els.dismissCorrectionPromotion.disabled = false;
  }
}

function dismissCorrectionPromotion() {
  state.pendingCorrectionPromotion = null;
  renderCorrectionPromotion();
}

function automaticSignal(confidence) {
  if (confidence === "high") return "strong";
  if (confidence === "medium" || confidence === "moderate") return "moderate";
  return "weak";
}

function setAutomaticStatus(kind, message) {
  setStatus(els.buildStatus, kind, message);
}

function setInferenceStatus(kind, message) {
  if (!els.inferRemainingStatus) return;
  els.inferRemainingStatus.hidden = false;
  setStatus(els.inferRemainingStatus, kind, message);
}

async function recordInferenceResult({ stage, kind, message, summary = message, reviewReady = false, details = {} }) {
  state.inferenceRun = {
    version: 1,
    generatorVersion: "editor-infer-remaining-v1",
    completedAt: new Date().toISOString(),
    stage,
    kind,
    message,
    summary,
    reviewReady,
    stale: false,
    details: JSON.parse(JSON.stringify(details))
  };
  setInferenceStatus(kind, message);
  if (state.currentDraft && draftRegistry) await saveCurrentDraft();
  publishTablePanel();
}

async function recordAutomaticRunResult({ stage, kind, message, summary = message, reviewReady = false, details = {}, confidence = null }) {
  state.automaticAuthoring = automaticConversion.automaticMetadata({
    generatorVersion: "editor-automatic-v1",
    confidence: confidence || { decision: kind === "error" ? "stopped" : "review", stage, reasons: [message] }
  });
  state.inferenceRun = {
    version: 1,
    generatorVersion: "editor-automatic-v1",
    completedAt: new Date().toISOString(),
    stage,
    kind,
    message,
    summary,
    reviewReady,
    stale: false,
    details: JSON.parse(JSON.stringify(details))
  };
  setInferenceStatus(kind, message);
  if (state.currentDraft && draftRegistry) await saveCurrentDraft();
  publishTablePanel();
}

function showAutomaticRunStop(stage, message) {
  if (["structure", "semantics", "discover", "review", "finish"].includes(stage)) navigateWorkflow(stage);
  if (stage === "structure") setStatus(els.scopeStatus, "error", message);
  else if (stage === "semantics") semanticView?.setStatus("error", message);
  else if (stage === "discover") setStatus(els.discoveryStatus, "error", message);
  else if (stage === "library") setLibraryStatus(message, "error");
  else setAutomaticStatus("error", message);
}

function inferredFieldSummary(entity, discovery) {
  const observations = discovery?.result?.candidates || [];
  const mapped = (entity.fields || []).filter((field) => !field.unresolved);
  const ratio = observations.length ? mapped.length / observations.length : 0;
  const discovered = mapped.filter((field) => field.provenance === "discovery");
  const corroboration = {
    strong: discovered.filter((field) => field.corroboration?.confidence === "strong").length,
    moderate: discovered.filter((field) => field.corroboration?.confidence === "moderate").length,
    weak: discovered.filter((field) => field.corroboration?.confidence === "weak").length,
    unscored: discovered.filter((field) => !field.corroboration?.confidence).length
  };
  const coverageConfidence = entity.identity && mapped.length >= 2 && ratio >= 0.6
    ? "strong"
    : (entity.identity || mapped.length >= 1)
      ? "moderate"
      : "weak";
  const confidence = coverageConfidence === "weak" || corroboration.weak || corroboration.unscored
    ? "weak"
    : coverageConfidence === "moderate" || corroboration.moderate
      ? "moderate"
      : "strong";
  return {
    entityName: entity.entityName,
    schemaType: entity.schemaType,
    observed: observations.length,
    mapped: mapped.length,
    unresolved: (entity.fields || []).filter((field) => field.unresolved).length,
    identity: Boolean(entity.identity),
    ratio: Math.round(ratio * 100) / 100,
    corroboration,
    confidence
  };
}

function inferredVariantProblem(block) {
  const analysis = block.variantAnalysis;
  if (!analysis || analysis.status === "error") return analysis?.message || "Variant evidence could not be analyzed.";
  if (analysis.status !== "ready") return "Variant evidence has not finished analyzing.";
  return null;
}

async function inferRemainingSteps() {
  if (!state.currentDraft) throw new Error("Open or create a local adapter draft before inferring the remaining steps.");
  if (state.inferenceRunning) return;
  state.inferenceRunning = true;
  setDraftControls();
  setInferenceStatus("loading", "Inferring the remaining editor decisions from the current rendered page…");
  publishTablePanel();
  let stage = "structure";
  try {
    if (!state.blocks.length) {
      if (!state.pendingScope) {
        const report = await runPageAnalysis({ complete: true });
        if (report.decision?.status !== "accepted") {
          const message = `Stopped in Structure: ${report.decision?.reason || "no scope cleared the configured confidence threshold"}`;
          navigateWorkflow("structure");
          await recordInferenceResult({ stage: "structure", kind: "error", message, details: { decision: report.decision } });
          return;
        }
        const context = await pageAnalysisContext();
        if (context.key !== report.key) {
          ensurePageAnalysisService().invalidate(report.key);
          const message = "Stopped in Structure because the rendered document changed during analysis. Run inference again after the page settles.";
          navigateWorkflow("structure");
          await recordInferenceResult({ stage: "structure", kind: "error", message });
          return;
        }
        const candidate = report.candidates.find((item) => item.selector === report.chosenSelector) || report.candidates[0];
        if (!candidate) throw new Error("The accepted scope disappeared from Page Analysis.");
        const accepted = await Site2JsonBridge.run(bridgeAcceptScope, { selector: candidate.selector });
        if (!accepted.ok || accepted.matchCount !== candidate.matchCount) {
          ensurePageAnalysisService().invalidate(report.key);
          const message = "Stopped in Structure because the inferred boundary changed after analysis. Run inference again on the stable page.";
          navigateWorkflow("structure");
          await recordInferenceResult({ stage: "structure", kind: "error", message });
          return;
        }
        state.pageUrl = accepted.pageUrl || report.pageUrl || state.pageUrl;
        ensureSuggestedAdapterMetadata(state.pageUrl);
        const recommendation = candidate.analysis?.recommendation || semanticRecommendation(candidate.observations);
        state.pendingScope = {
          selector: candidate.selector,
          matchCount: candidate.matchCount,
          sample: accepted.sample || { tag: candidate.tag, text: "" },
          recommendation,
          semanticRanking: candidate.analysis?.semanticRanking || null,
          initialVariantItems: candidate.analysis?.initialVariantItems || null,
          pageShape: candidate.singleton ? "detail" : "collection",
          inferred: true
        };
        els.blockName.value = candidate.singleton ? "Detail" : "Results";
        els.blockSchemaType.value = recommendation?.confidence === "high" ? recommendation.schemaType : "Thing";
      }
      if (!await createBlock()) throw new Error(els.scopeStatus.textContent || "Could not create the inferred block.");
      const created = activeBlock();
      if (created) created.inference = { scope: "inferred", semantics: "pending", reviewed: false };
    }

    stage = "semantics";
    const fieldReports = [];
    const variantIssues = [];
    for (const block of state.blocks) {
      await activateBlock(block.id, { pin: false });
      let recommendation = block.semanticRecommendation || null;
      let observations = [];
      if (block.semanticsReviewed === false && recommendation?.confidence !== "high") {
        const analyzed = await analyzeBlockSemanticEvidence(block);
        recommendation = analyzed.recommendation;
        observations = analyzed.observations || [];
      }
      if (block.semanticsReviewed === false) {
        if (recommendation?.confidence !== "high") {
          const message = `Stopped in Semantics: ${block.name} does not have a semantic model above the automatic confidence threshold. Review the ranked suggestions.`;
          block.inference = { ...(block.inference || {}), semantics: "uncertain", reviewed: false };
          navigateWorkflow("semantics");
          semanticView?.setStatus("error", message);
          await recordInferenceResult({
            stage: "semantics", kind: "error", message,
            details: { blockId: block.id, recommendation, observed: observations.length }
          });
          return;
        }
        await handleTablePanelCommand({ action: "set-semantic-model", modelId: recommendation.modelId });
        block.semanticRecommendation = JSON.parse(JSON.stringify(recommendation));
        block.semanticsReviewed = false;
        block.inference = { ...(block.inference || {}), semantics: "inferred", semanticModelId: recommendation.modelId, reviewed: false };
      }

      if (!block.variantAnalysis || block.variantAnalysis.status !== "ready") await analyzeBlockSemanticEvidence(block);
      const variantProblem = inferredVariantProblem(block);
      if (variantProblem) {
        const message = `Stopped in Semantics: ${block.name} needs a result-type decision. ${variantProblem}`;
        block.inference = { ...(block.inference || {}), variants: "uncertain", reviewed: false };
        navigateWorkflow("semantics");
        semanticView?.setStatus("error", message);
        await recordInferenceResult({ stage: "semantics", kind: "error", message, details: { blockId: block.id, variantAnalysis: block.variantAnalysis } });
        return;
      }
      if (block.variantAnalysis.mixed && !block.variants?.candidates?.length) {
        await applyVariantSuggestions();
        block.inference = { ...(block.inference || {}), variants: "inferred", reviewed: false };
      }

      stage = "discover";
      for (const entity of variantTargets(block)) {
        state.activeVariantEntityName = entity.entityName;
        renderVariantContextControls();
        const discovery = await discoverFields({ includeUnmapped: false, allowInferredExtensions: false });
        if (!discovery?.ok) {
          const message = `Stopped in Discover: ${entity.schemaType} fields could not be inferred. ${discovery?.message || "Review this result type manually."}`;
          navigateWorkflow("discover");
          await recordInferenceResult({ stage: "discover", kind: "error", message, details: { blockId: block.id, entityName: entity.entityName, reason: discovery?.reason } });
          return;
        }
        for (const field of entity.fields || []) {
          if (field.provenance === "discovery") field.reviewed = false;
        }
        fieldReports.push(inferredFieldSummary(entity, discovery));
      }
      state.activeVariantEntityName = block.entityName;
      renderVariantContextControls();
      await refreshBlockTable();
      if (block.variants?.candidates?.length) {
        const classification = await refreshVariantClassification();
        if (classification?.status === "error" || Number(classification?.ambiguousCount || 0) > 0 || Number(classification?.unclassifiedCount || 0) > 0) {
          variantIssues.push(`${block.name} needs variant evidence for ${Number(classification?.ambiguousCount || 0)} ambiguous and ${Number(classification?.unclassifiedCount || 0)} fallback item(s)`);
          block.inference = { ...(block.inference || {}), variants: "uncertain", reviewed: false };
        }
      }
    }

    stage = "review";
    const weak = fieldReports.filter((report) => report.confidence === "weak");
    const missingIdentity = fieldReports.filter((report) => !report.identity);
    const mapped = fieldReports.reduce((total, report) => total + report.mapped, 0);
    const observed = fieldReports.reduce((total, report) => total + report.observed, 0);
    const issues = [
      ...(missingIdentity.length ? [`${missingIdentity.length} result type${missingIdentity.length === 1 ? " needs" : "s need"} a canonical identity`] : []),
      ...(weak.length ? [`${weak.length} result type${weak.length === 1 ? " has" : "s have"} weak field coverage`] : []),
      ...variantIssues
    ];
    const summary = `Inferred ${state.blocks.length} block${state.blocks.length === 1 ? "" : "s"} and mapped ${mapped}/${observed} observed field candidates. ${issues.length ? `${issues.join("; ")}. ` : ""}Any inferred semantic models and all newly inferred fields remain unreviewed.`;
    await recordInferenceResult({
      stage: "review", kind: "ready",
      message: `Inference reached Review. ${summary} Nothing was published and extraction was not run.`,
      summary, reviewReady: true,
      details: { fields: fieldReports, issues }
    });
    navigateWorkflow("review");
  } catch (error) {
    const message = `Inference stopped in ${stage[0].toUpperCase()}${stage.slice(1)}: ${error.message}`;
    navigateWorkflow(stage);
    await recordInferenceResult({ stage, kind: "error", message });
  } finally {
    state.inferenceRunning = false;
    setDraftControls();
    publishTablePanel();
  }
}

function automaticConflictMessage(existing) {
  const label = existing.id || existing.draft?.id || "another local definition";
  if (existing.outcome === automaticConversion.OUTCOMES.USE_EXISTING) {
    return `This page is already supported by the published “${label}” adapter. Automatic import did not create or replace anything; open that adapter from the library to edit it.`;
  }
  if (existing.outcome === automaticConversion.OUTCOMES.DISABLED_EXISTING) {
    return `The disabled “${label}” adapter already supports this page. Automatic import preserved it instead of creating a competing definition.`;
  }
  if (existing.outcome === automaticConversion.OUTCOMES.PRESERVE_MANUAL_DRAFT) {
    return `The manual draft “${label}” already contains work for this page. Automatic import preserved it; open that draft from the library to continue.`;
  }
  if (existing.outcome === automaticConversion.OUTCOMES.RESUME_AUTOMATIC_DRAFT) {
    return `The automatic draft “${label}” already targets this page. Open that draft from the library to resume it.`;
  }
  return "Existing local work for this page was preserved.";
}

async function automaticConvert({ minimumConfidence = "moderate" } = {}) {
  if (!automaticConversion) throw new Error("Automatic conversion is not available in this editor build.");
  if (!state.currentDraft) throw new Error("Open or create a local adapter draft before attempting automatic import.");
  if (state.blocks.length) throw new Error("This draft already has authored blocks. Automatic import will not overwrite them.");
  setAutomaticStatus("loading", "Running automatic conversion: locating evidence, inferring semantics, mapping fields, and testing extraction…");
  publishTablePanel();
  let stage = "structure";
  try {
    const analysisReport = await runPageAnalysis({ complete: true });
    if (analysisReport.decision?.status !== "accepted") {
      throw new Error(`Automatic conversion stopped in Structure: ${analysisReport.decision?.reason || "no scope cleared the configured confidence threshold"} Review the ranked page scopes manually.`);
    }
    const currentAnalysisContext = await pageAnalysisContext();
    if (currentAnalysisContext.key !== analysisReport.key) {
      ensurePageAnalysisService().invalidate(analysisReport.key);
      throw new Error("Automatic conversion stopped in Structure because the rendered document changed while it was being analyzed. Run it again after the page settles.");
    }
    state.pageUrl = analysisReport.pageUrl || state.pageUrl;
    stage = "library";
    const existing = automaticConversion.resolveExisting({
      entries: state.entries,
      drafts: state.drafts.filter((draft) => draft.id !== state.currentDraft.id)
    }, state.pageUrl);
    if (existing.outcome !== automaticConversion.OUTCOMES.AUTHOR) {
      throw new Error(automaticConflictMessage(existing));
    }
    stage = "structure";
    const candidate = analysisReport.candidates.find((item) => item.selector === analysisReport.chosenSelector) || analysisReport.candidates[0];
    if (!candidate) throw new Error("Automatic conversion stopped in Structure because the accepted scope no longer exists.");
    setAutomaticStatus("loading", "Automatic conversion: validating the inferred scope against the current page revision…");
    const acceptedScope = await Site2JsonBridge.run(bridgeAcceptScope, { selector: candidate.selector });
    if (!acceptedScope.ok || acceptedScope.matchCount !== candidate.matchCount) {
      ensurePageAnalysisService().invalidate(analysisReport.key);
      throw new Error("Automatic conversion stopped in Structure because the page changed after analysis. Run it again on the stable page.");
    }
    const recommendation = candidate.analysis?.recommendation || semanticRecommendation(candidate.observations);
    setAutomaticStatus("loading", "Automatic conversion: creating the inferred block…");
    const hostname = new URL(state.pageUrl).hostname.replace(/^www\./, "");
    const adapterId = hostname.split(".")[0].toLowerCase().replace(/[^a-z0-9-]/g, "") || "page";
    if (!els.adapterId.value) els.adapterId.value = adapterId;
    ensureSuggestedNamespace();
    state.pendingScope = {
      selector: candidate.selector,
      matchCount: candidate.matchCount,
      sample: { tag: candidate.tag, text: "" },
      recommendation,
      semanticRanking: candidate.analysis?.semanticRanking || null,
      initialVariantItems: candidate.analysis?.initialVariantItems || null,
      pageShape: candidate.singleton ? "detail" : "collection",
      automatic: true
    };
    els.blockName.value = candidate.singleton ? "Detail" : "Results";
    els.blockSchemaType.value = recommendation?.confidence === "high" ? recommendation.schemaType : "Thing";
    if (!await createBlock()) throw new Error(els.scopeStatus.textContent || "Automatic block creation failed.");
    const block = activeBlock();
    stage = "semantics";
    if (recommendation?.confidence !== "high") {
      throw new Error(`Automatic conversion stopped in Semantics: ${block.name} does not have a semantic model above the automatic confidence threshold. Review the ranked suggestions.`);
    }
    if (!block.variantAnalysis || block.variantAnalysis.status !== "ready") await analyzeBlockSemanticEvidence(block);
    const variantProblem = inferredVariantProblem(block);
    if (variantProblem) throw new Error(`Automatic conversion stopped in Semantics: ${variantProblem}`);
    if (block.variantAnalysis.mixed && !block.variants?.candidates?.length) {
      await applyVariantSuggestions();
    }
    const fieldReports = [];
    stage = "discover";
    for (const entity of variantTargets(block)) {
      state.activeVariantEntityName = entity.entityName;
      renderVariantContextControls();
      const discovery = await discoverFields({ includeUnmapped: false, allowInferredExtensions: false });
      if (!discovery?.ok) throw new Error(`Automatic conversion stopped in Discover: ${entity.schemaType} fields could not be inferred.`);
      fieldReports.push(inferredFieldSummary(entity, discovery));
    }
    state.activeVariantEntityName = block.entityName;
    renderVariantContextControls();
    const variantClassification = block.variants?.candidates?.length ? await refreshVariantClassification() : null;
    const variantConfidence = !variantClassification
      ? "strong"
      : variantClassification.status === "ready" && !variantClassification.ambiguousCount && !variantClassification.unclassifiedCount
        ? "strong"
        : "weak";
    const mappedCount = fieldReports.reduce((total, report) => total + report.mapped, 0);
    const observedCount = fieldReports.reduce((total, report) => total + report.observed, 0);
    const hasEveryIdentity = fieldReports.every((report) => report.identity);
    const fieldConfidence = fieldReports.some((report) => report.confidence === "weak")
      ? "weak"
      : fieldReports.some((report) => report.confidence === "moderate")
        ? "moderate"
        : "strong";
    stage = "finish";
    await buildDraft();
    const validation = {
      ok: Boolean(state.lastValidDefinition),
      message: state.lastValidDefinition ? "Adapter draft is valid." : (els.buildStatus.textContent || "Adapter validation failed.")
    };
    let extractionConfidence = "weak";
    let preview = null;
    let extractedCount = 0;
    if (state.lastValidDefinition) {
      preview = await Site2JsonBridge.run(bridgePreviewExtraction, { definition: state.lastValidDefinition });
      extractedCount = preview?.ok ? (preview.observation?.blocks || []).reduce((total, item) => total + (item.entities?.length || 0), 0) : 0;
      extractionConfidence = preview?.ok && extractedCount > 0 ? "strong" : "weak";
    }
    const signals = {
      scope: automaticSignal(analysisReport.structuralConfidence),
      scopeMargin: analysisReport.structuralMargin >= 10 ? "strong" : analysisReport.structuralMargin >= 5 ? "moderate" : "weak",
      semantics: automaticSignal(recommendation?.confidence),
      variants: variantConfidence,
      fields: fieldConfidence,
      extraction: extractionConfidence
    };
    const decision = automaticConversion.decideOutcome(signals, { minimumConfidence });
    const metadata = automaticConversion.automaticMetadata({
      generatorVersion: "editor-automatic-v1",
      confidence: {
        signals,
        decision: decision.outcome,
        reasons: decision.reasons,
        scope: candidate.selector,
        model: recommendation?.modelId || null,
        fields: { mapped: mappedCount, observed: observedCount, identity: hasEveryIdentity, resultTypes: fieldReports },
        variants: variantClassification,
        validation
      }
    });
    state.automaticAuthoring = metadata;
    await saveCurrentDraft();
    const definition = state.lastValidDefinition;
    let published = false;
    if (decision.publish && definition) {
      const publishedEntry = await publishCurrentDraft();
      if (!publishedEntry) throw new Error("The inferred adapter validated but could not be published locally.");
      published = true;
      setLibraryStatus(`Automatic run published ${publishedEntry.id} locally after every confidence check passed.`, "ready");
    } else {
      const details = [
        ...decision.reasons,
        `mapped ${mappedCount}/${observedCount} observed fields`,
        hasEveryIdentity ? "canonical identity found for every result type" : "canonical identity missing for at least one result type",
        ...(!validation.ok ? [`validation: ${validation.message}`] : [])
      ];
      const nextStep = signals.semantics === "weak"
        ? "Review the semantic model first."
        : signals.fields === "weak"
          ? "Review field mappings and canonical identity next."
          : "Review the extraction warnings next.";
      setAutomaticStatus("ready", `Automatic import saved as an unreviewed draft (${decision.outcome}). ${details.join("; ")}. ${nextStep}`);
      await recordAutomaticRunResult({
        stage: "review",
        kind: "ready",
        message: `Automatic Run reached Review. ${details.join("; ")}. ${nextStep}`,
        summary: `Automatic Run mapped ${mappedCount}/${observedCount} observed fields. ${decision.reasons.join("; ") || "Review all inferred decisions before publishing."}`,
        reviewReady: true,
        details: { decision, signals, fields: fieldReports, validation },
        confidence: metadata.confidence
      });
      navigateWorkflow(signals.semantics === "weak" ? "semantics" : "review");
    }
    els.buildOutput.textContent = JSON.stringify({
      decision, signals, scope: candidate.selector, model: recommendation,
      fields: { mapped: mappedCount, observed: observedCount, identity: hasEveryIdentity, resultTypes: fieldReports },
      validation, extraction: { ok: preview?.ok ?? false, entities: extractedCount }
    }, null, 2);
    publishTablePanel();
    return { ok: decision.download && Boolean(definition) && Boolean(preview?.ok) && extractedCount > 0, decision, signals, preview, definition, metadata, published };
  } catch (error) {
    const message = error.message || String(error);
    await recordAutomaticRunResult({ stage, kind: "error", message, details: { stage } });
    showAutomaticRunStop(stage, message);
    return { ok: false, stage, error: message };
  }
}

function compositionNodePath(composition, alias) {
  if (!composition || alias === composition.root) return "";
  const parent = new Map((composition.edges || []).map((edge) => [edge.to, edge]));
  const parts = [];
  const seen = new Set();
  let current = alias;
  while (current !== composition.root) {
    if (seen.has(current) || !parent.has(current)) return "";
    seen.add(current);
    const edge = parent.get(current);
    parts.unshift(edge.property);
    current = edge.from;
  }
  return parts.join(".");
}

function nestedVariantEntity(block, path, type, suffix) {
  const prefix = `${path}.`;
  const fields = (block.fields || []).filter((field) => field.name.startsWith(prefix)).map((field) => ({
    ...JSON.parse(JSON.stringify(field)),
    name: field.name.slice(prefix.length),
    identity: Boolean(field.identity || field.name === `${path}.url`)
  }));
  let identityField = fields.find((field) => field.identity)?.name || (fields.some((field) => field.name === "url") ? "url" : null);
  if (!identityField && block.identityField?.startsWith(prefix)) identityField = block.identityField.slice(prefix.length);
  if (!identityField) throw new Error(`Nested variant slot “${path}” needs a URL or identifier field below that relationship before the adapter can be built.`);
  const stem = `${block.entityName}_${path.replace(/[^A-Za-z0-9_]/g, "_")}_${String(type).replace(/[^A-Za-z0-9_]/g, "_")}`;
  return { entityName: `${stem}${suffix || ""}`, schemaType: type, identityField, fields };
}

function nestedVariantSlots(block) {
  const slots = [];
  for (const [alias, node] of Object.entries(block.composition?.nodes || {})) {
    if (!node.variants?.candidates?.length) continue;
    const path = compositionNodePath(block.composition, alias);
    if (!path) throw new Error(`Nested variant node “${alias}” must have one unambiguous path from the composition root.`);
    slots.push({
      path,
      fallback: nestedVariantEntity(block, path, node.variants.fallback || node.types[0], "Fallback"),
      candidates: node.variants.candidates.map((candidate, index) => ({
        ...nestedVariantEntity(block, path, candidate.type, `Variant${index + 1}`),
        evidence: JSON.parse(JSON.stringify(candidate.evidence || []))
      })),
      minScore: node.variants.minScore,
      minMargin: node.variants.minMargin
    });
  }
  return slots;
}

async function buildDraft({ refreshBaseline = false } = {}) {
  if (!state.blocks.length || !state.pageUrl) {
    setStatus(els.buildStatus, "error", "Create at least one repeating block first.");
    return;
  }
  const unresolved = state.blocks.flatMap((block) => variantTargets(block).map((entity) => ({ block, entity }))).find(({ entity }) => entity.fields.some((field) => field.unresolved));
  if (unresolved) {
    const count = unresolved.entity.fields.filter((field) => field.unresolved).length;
    setStatus(els.buildStatus, "error", `Review ${count} unmapped discovered field${count === 1 ? "" : "s"} in “${unresolved.block.name} · ${unresolved.entity.schemaType}” before building the adapter.`);
    return;
  }
  const missingIdentity = state.blocks.flatMap((block) => variantTargets(block).map((entity) => ({ block, entity }))).find(({ entity }) => !entity.identity);
  if (missingIdentity) {
    setStatus(els.buildStatus, "error", `Choose a scalar URL or identifier field as the canonical identity for “${missingIdentity.block.name} · ${missingIdentity.entity.schemaType}” first.`);
    return;
  }
  const adapterId = els.adapterId.value.trim();
  if (adapterId && !els.adapterNamespace.value.trim()) ensureSuggestedNamespace();
  const namespace = els.adapterNamespace.value.trim();
  if (!adapterId || !namespace) {
    const missing = !adapterId ? "Adapter id" : "Namespace";
    setStatus(els.buildStatus, "error", `${missing} is required before the adapter can be built.`);
    (!adapterId ? els.adapterId : els.adapterNamespace).focus();
    return;
  }
  const definition = Site2JsonAdapterDefinition.buildDraftDefinition({
    adapterId,
    namespace,
    pageUrl: state.pageUrl,
    pageId: els.pageId.value.trim() || "collection",
    pageType: els.pageType.value.trim() || "CollectionPage",
    fixture: state.fixture || null,
    blocks: state.blocks.map((block) => ({
      entityName: block.entityName,
      schemaType: block.schemaType,
      scope: block.scope,
      arity: block.arity,
      role: block.role,
      fidelity: block.fidelity,
      identityField: block.identityField,
      fields: block.fields,
      requireFields: block.requireFields,
      monitorFields: block.monitorFields || [],
      structuralBaseline: block.structuralBaseline || null,
      variants: block.variants ? JSON.parse(JSON.stringify(block.variants)) : null,
      variantSlots: block.variantSlots?.length ? JSON.parse(JSON.stringify(block.variantSlots)) : nestedVariantSlots(block)
    })),
    customTerms: state.customTerms,
    version: state.baseDefinition?.version || 1
  });
  let completeDefinition;
  try {
    completeDefinition = Site2JsonAdapterDefinition.mergeWithBase(state.baseDefinition, definition, els.pageId.value.trim() || "collection");
  } catch (error) {
    setStatus(els.buildStatus, "error", error.message);
    return;
  }
  let result = Site2JsonAdapterDefinition.validateDraft(completeDefinition);
  if (!result.ok) {
    setStatus(els.buildStatus, "error", result.message);
    els.buildOutput.textContent = JSON.stringify(completeDefinition, null, 2);
    els.previewExtraction.disabled = true;
    state.lastValidDefinition = null;
    return;
  }
  const currentPageId = els.pageId.value.trim() || "collection";
  let currentPage = result.definition.pages?.find((page) => page.id === currentPageId);
  const needsBaseline = currentPage?.blocks.some((block) => !block.structuralBaseline);
  if (Array.isArray(result.definition.pages) && (refreshBaseline || needsBaseline)) {
    setStatus(els.buildStatus, "loading", "Capturing structural baselines from the rendered page…");
    const captured = await Site2JsonBridge.run(bridgeCaptureStructuralBaseline, { definition: result.definition });
    if (!captured.ok) {
      setStatus(els.buildStatus, "error", captured.message || "Could not capture a structural baseline from this page.");
      els.previewExtraction.disabled = true;
      state.lastValidDefinition = null;
      publishTablePanel();
      return;
    }
    currentPage = result.definition.pages.find((page) => page.id === currentPageId);
    if (!currentPage || captured.baselines.length !== currentPage.blocks.length) {
      setStatus(els.buildStatus, "error", "The structural baseline did not match the current page blocks.");
      els.previewExtraction.disabled = true;
      state.lastValidDefinition = null;
      publishTablePanel();
      return;
    }
    currentPage.blocks.forEach((block, index) => {
      if (refreshBaseline || !block.structuralBaseline) block.structuralBaseline = captured.baselines[index];
    });
    state.blocks.forEach((block, index) => {
      if (refreshBaseline || !block.structuralBaseline) block.structuralBaseline = JSON.parse(JSON.stringify(captured.baselines[index]));
    });
    result = Site2JsonAdapterDefinition.validateDraft(result.definition);
    if (!result.ok) {
      setStatus(els.buildStatus, "error", result.message);
      els.previewExtraction.disabled = true;
      state.lastValidDefinition = null;
      publishTablePanel();
      return;
    }
  }
  state.lastValidDefinition = result.definition;
  if (refreshBaseline || needsBaseline) {
    state.driftReview = { status: "idle", findings: [], message: "Structural baseline saved. Check the rendered page from Review when you want to compare it." };
  }
  const baselineCount = result.definition.pages?.find((page) => page.id === (els.pageId.value.trim() || "collection"))?.blocks.filter((block) => block.structuralBaseline).length || 0;
  setStatus(els.buildStatus, "ready", baselineCount
    ? `Adapter draft is valid. Captured structural baselines for ${baselineCount} block${baselineCount === 1 ? "" : "s"}.`
    : "Adapter draft is valid.");
  els.buildOutput.textContent = JSON.stringify(result.definition, null, 2);
  els.previewExtraction.disabled = false;
  setDraftControls();
  reviewView?.renderDrift(state.driftReview, canCheckStructuralHealth());
  scheduleDraftAutosave();
  publishTablePanel();
}

async function previewExtraction() {
  if (!state.lastValidDefinition) return;
  els.previewExtraction.disabled = true;
  els.extractionOutput.textContent = "Running the production interpreter against this page…";
  try {
    const result = await Site2JsonBridge.run(bridgePreviewExtraction, { definition: state.lastValidDefinition });
    if (!result.ok) {
      els.extractionOutput.textContent = result.reason === "no-match"
        ? "The built adapter does not match the current page's host/path."
        : (result.message || "Extraction failed.");
      return;
    }
    const drift = updateStructuralReview(result.observation.warnings || []);
    const summary = drift.length
      ? `Structural drift findings (${drift.length})\n${drift.map((warning) => {
        if (warning.code === "scope.noMatches") return `• Block ${warning.block}: the stored scope no longer matches.`;
        if (warning.code === "scope.countDrift") return `• Block ${warning.block}: scope count changed from about ${warning.baseline} to ${warning.current}.`;
        if (warning.code === "shape.unknown") return `• Block ${warning.block}${warning.variant ? ` · ${warning.variant}` : ""}: ${warning.count} item${warning.count === 1 ? " has" : "s have"} an unknown dependency shape.`;
        if (warning.code === "field.selectorMissing") return `• ${warning.field}: selector coverage fell from ${Math.round(warning.baseline * 100)}% to 0%.`;
        if (warning.code === "field.coverageDrift") return `• ${warning.field}: coverage changed from ${Math.round(warning.baseline * 100)}% to ${Math.round(warning.current * 100)}%.`;
        if (warning.code === "field.cardinalityDrift") return `• ${warning.field}: matches per item changed from ${warning.baseline.join("–")} to ${warning.current.join("–")}.`;
        if (warning.code === "variant.classificationDrift") return `• ${warning.variant}: previously classified items no longer clear the variant thresholds.`;
        return `• Variant evidence changed for ${warning.candidate}.`;
      }).join("\n")}\n\n`
      : "Structural baseline: no drift detected.\n\n";
    els.extractionOutput.textContent = `${summary}${JSON.stringify(result.observation, null, 2)}`;
  } catch (error) {
    els.extractionOutput.textContent = error.message;
  } finally {
    els.previewExtraction.disabled = false;
    publishTablePanel();
  }
}

function isStructuralWarning(warning) {
  return /^(?:scope|shape|field\.(?:selectorMissing|coverageDrift|cardinalityDrift)|variant\.(?:evidenceDrift|classificationDrift))/.test(warning?.code || "");
}

function findingMessage(warning) {
  if (warning.code === "scope.noMatches") return `The stored scope no longer matches; it previously found about ${warning.baseline} items.`;
  if (warning.code === "scope.countDrift") return `Scope count changed from about ${warning.baseline} to ${warning.current}.`;
  if (warning.code === "shape.unknown") return `${warning.count} rendered item${warning.count === 1 ? " has" : "s have"} an unknown dependency shape.`;
  if (warning.code === "field.selectorMissing") return `Selector coverage fell from ${Math.round(warning.baseline * 100)}% to 0%.`;
  if (warning.code === "field.coverageDrift") return `Coverage changed from ${Math.round(warning.baseline * 100)}% to ${Math.round(warning.current * 100)}%.`;
  if (warning.code === "field.cardinalityDrift") return `Matches per item changed from ${warning.baseline.join("–")} to ${warning.current.join("–")}.`;
  if (warning.code === "variant.classificationDrift") return `${warning.variant} items no longer clear the compiled variant score and margin.`;
  return `Variant evidence for ${warning.candidate} changed from ${Math.round(warning.baseline * 100)}% to ${Math.round(warning.current * 100)}% coverage.`;
}

function localizeStructuralFinding(warning) {
  const pageId = els.pageId.value.trim() || "collection";
  const prefix = `${pageId}:`;
  const blockIndex = warning.block === pageId ? 0 : warning.block?.startsWith(prefix) ? Number(warning.block.slice(prefix.length)) : -1;
  const block = state.blocks[blockIndex];
  if (!block) return null;
  const entity = variantTargets(block).find((candidate) => candidate.entityName === warning.variant) || block;
  const field = warning.field === "canonicalUrl" ? entity.identity : entity.fields.find((candidate) => candidate.name === warning.field);
  const titleParts = [block.name];
  if (warning.variant) titleParts.push(entity.schemaType);
  if (warning.field) titleParts.push(warning.field === "canonicalUrl" ? "canonical URL" : warning.field);
  return {
    ...JSON.parse(JSON.stringify(warning)),
    blockId: block.id,
    blockName: block.name,
    variantEntityName: entity.entityName,
    variantLabel: entity.schemaType,
    fieldKey: field ? (warning.field === "canonicalUrl" ? "identity" : Site2JsonFieldDiscovery.sourceKey(field)) : null,
    title: titleParts.join(" · "),
    message: findingMessage(warning),
    target: field?.selector ? { withinSelector: block.scope, selector: field.selector } : { selector: block.scope }
  };
}

function updateStructuralReview(warnings) {
  const findings = warnings.filter(isStructuralWarning).map(localizeStructuralFinding).filter(Boolean);
  const errors = findings.filter((finding) => finding.severity === "error").length;
  const strong = findings.filter((finding) => finding.severity === "strong-warning").length;
  state.driftReview = {
    status: "ready",
    findings,
    checkedAt: new Date().toISOString(),
    message: findings.length
      ? `${findings.length} structural finding${findings.length === 1 ? "" : "s"}${errors ? ` · ${errors} error${errors === 1 ? "" : "s"}` : ""}${strong ? ` · ${strong} strong warning${strong === 1 ? "" : "s"}` : ""}.`
      : "No structural drift detected on the rendered page."
  };
  reviewView?.renderDrift(state.driftReview, canCheckStructuralHealth());
  return findings;
}

async function checkStructuralHealth() {
  if (state.driftReview.status === "checking") return;
  if (!canCheckStructuralHealth()) {
    state.driftReview = { status: "unavailable", findings: [], message: "No structural baseline is saved for this page. Validate the adapter in Finish to capture one." };
    reviewView?.renderDrift(state.driftReview, false);
    publishTablePanel();
    return;
  }
  state.driftReview = { status: "checking", findings: [], message: "Checking the rendered page against the saved baseline…" };
  reviewView?.renderDrift(state.driftReview, true);
  publishTablePanel();
  try {
    const result = await Site2JsonBridge.run(bridgePreviewExtraction, { definition: state.lastValidDefinition });
    if (!result.ok) throw new Error(result.reason === "no-match" ? "The adapter does not match this rendered page." : (result.message || "Structural health check failed."));
    updateStructuralReview(result.observation.warnings || []);
  } catch (error) {
    state.driftReview = { status: "error", findings: [], message: error.message };
    reviewView?.renderDrift(state.driftReview, true);
  }
  publishTablePanel();
}

async function openStructuralFinding(finding) {
  if (!finding?.blockId) return;
  if (state.activeBlockId !== finding.blockId) await activateBlock(finding.blockId, { pin: false });
  if (finding.variantEntityName && state.activeVariantEntityName !== finding.variantEntityName) await activateVariantEntity(finding.variantEntityName);
  const block = activeBlock();
  const entity = activeEntityTarget(block);
  const field = finding.fieldKey === "identity"
    ? entity?.identity && { ...entity.identity, identity: true }
    : entity?.fields.find((candidate) => Site2JsonFieldDiscovery.sourceKey(candidate) === finding.fieldKey);
  if (field) await editField(field, { identity: Boolean(field.identity) });
  else {
    navigateWorkflow("review");
    pinTarget(finding.target);
    await revealTarget({ ...finding.target, scrollIntoView: true });
  }
}

async function sha256Text(value) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return `sha256:${Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}

async function captureFixture() {
  if (!state.lastValidDefinition) return;
  els.captureFixture.disabled = true;
  setStatus(els.buildStatus, "loading", "Capturing and scrubbing the rendered page…");
  publishTablePanel();
  try {
    const captured = await Site2JsonBridge.run(bridgeCaptureFixture, { definition: state.lastValidDefinition });
    if (!captured.ok) throw new Error(captured.message || "Could not capture a scrubbed fixture from this page.");
    const digest = await sha256Text(captured.html);
    const safeAdapter = state.lastValidDefinition.adapter.replace(/[^a-z0-9._-]+/gi, "-");
    const safePage = captured.pageId.replace(/[^a-z0-9._-]+/gi, "-");
    const source = `${safeAdapter}-${safePage}.fixture.html`;
    const previousDigest = state.fixture?.digest || null;
    const fixture = {
      format: captured.format,
      source,
      digest,
      bytes: captured.bytes,
      capturedAt: new Date().toISOString()
    };
    const definition = JSON.parse(JSON.stringify(state.lastValidDefinition));
    const page = definition.pages.find((candidate) => candidate.id === captured.pageId);
    if (!page) throw new Error("The captured fixture did not match a page in the adapter.");
    page.fixture = fixture;
    const validation = Site2JsonAdapterDefinition.validateDraft(definition);
    if (!validation.ok) throw new Error(validation.message);
    state.fixture = fixture;
    state.lastValidDefinition = validation.definition;
    els.buildOutput.textContent = JSON.stringify(validation.definition, null, 2);
    downloadBytes(captured.html, source, "text/html");
    const comparison = previousDigest
      ? (previousDigest === digest ? " It is unchanged from the previous fixture." : " Its structure changed from the previous fixture; provenance was updated.")
      : " This is the first fixture for this page.";
    setStatus(els.buildStatus, "ready", `Downloaded ${source} (${captured.bytes} scrubbed bytes).${comparison}`);
    setDraftControls();
    scheduleDraftAutosave();
  } catch (error) {
    setStatus(els.buildStatus, "error", error.message);
  } finally {
    setDraftControls();
    publishTablePanel();
  }
}

function downloadDraftYaml() {
  const definition = state.lastValidDefinition || state.currentDraft?.workingDefinition;
  if (!definition) return;
  try {
    const text = draftRegistry.serializeDefinition(definition);
    const url = URL.createObjectURL(new Blob([text], { type: "application/yaml" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = state.currentDraft?.sourceName || `${definition.adapter}.yaml`;
    link.click();
    URL.revokeObjectURL(url);
    setStatus(els.draftStatus, "ready", "Draft exported as inert YAML. You can publish this file through a future remote source.");
  } catch (error) {
    setStatus(els.draftStatus, "error", error.message);
  }
}

async function publishCurrentDraft() {
  if (!state.currentDraft) return;
  try {
    await saveCurrentDraft();
    const result = await draftRegistry.publish(state.currentDraft, state.entries, state.drafts);
    state.entries = result.entries;
    state.drafts = result.drafts;
    state.currentDraft = null;
    state.baseDefinition = result.entry.definition;
    state.lastValidDefinition = result.entry.definition;
    refreshWorkspaceLists();
    showLibraryHome();
    setLibraryStatus(`${result.entry.id} was published locally. Extraction now uses this validated definition.`, "ready");
    return result.entry;
  } catch (error) {
    setStatus(els.draftStatus, "error", error.message);
    return null;
  }
}

function clearLibraryImport() {
  state.pendingImport = null;
  if (els.libraryImportPreview) els.libraryImportPreview.hidden = true;
  if (els.libraryFile) els.libraryFile.value = "";
}

workspaceView = sidebarWorkspace?.create({
  document,
  summarizeEntry: (entry) => adapterRegistry.summarize(entry),
  draftForAdapter: (drafts, adapterId) => draftRegistry.forAdapter(drafts, adapterId)
}) || null;
semanticLibraryView = sidebarSemanticLibrary?.create({
  document,
  service: semanticLibraryService,
  bundleApi: semanticBundleApi,
  onLibraryChange: () => {
    semanticLibraryInference?.invalidate();
    pageAnalysisService?.invalidate();
  }
}) || null;
detectionFirstView = detectionFirstApi?.create({
  document,
  onDecision: (_detection, _decision, decisions) => {
    if (!state.pageDetectionReview) return;
    state.pageDetectionReview = { ...state.pageDetectionReview, decisions };
    scheduleDraftAutosave();
  },
  onContinue: ({ report, decisions }) => {
    const blocks = blocksFromAcceptedDetections(report, decisions);
    if (!blocks.length) throw new Error("Accept at least one detected group before continuing.");
    state.pageDetectionReview = {
      ...(state.pageDetectionReview || {}),
      decisions,
      acceptedDetections: blocks.map((block) => block.detectionSeed)
    };
    state.blocks = blocks;
    state.activeBlockId = blocks[0].id;
    state.activeVariantEntityName = null;
    state.inferenceRun = null;
    state.inferenceRunning = false;
    state.pendingScope = null;
    invalidateBuiltDraft();
    state.structureStartMode = "detection";
    renderStructureStartMode();
    navigateWorkflow("semantics");
  },
  onFocus: (focus) => focusPageDetection(focus),
  onClearFocus: () => focusPageDetection({}),
  onVisualEvidence: openVisualEvidence,
  onManual: useManualStructure,
  onRefresh: () => runDetectionFirst({ force: true })
}) || null;
visualEvidenceView = visualEvidenceApi?.create({
  document,
  onPick: startVisualEvidencePick,
  onCancel: (result) => restoreVisualEvidenceCaller(result, false),
  onBack: (result) => restoreVisualEvidenceCaller(result, false),
  onComplete: (result) => restoreVisualEvidenceCaller(result, true)
}) || null;
structureView = sidebarStructure?.create({
  document,
  onHighlight: (selector) => highlightSelector(selector),
  onClearHighlight: () => clearHighlight("transient"),
  onAccept: acceptScope,
  onStatus: (kind, message) => setStatus(els.scopeStatus, kind, message)
}) || null;
semanticView = sidebarSemantics?.create({
  document,
  compositions: semanticCompositions,
  getBlock: activeBlock,
  onApply: applySemanticModel,
  onAnalyze: analyzeSemanticModel,
  onConfirm: confirmSemanticModel,
  onAddNode: async (command) => {
    await handleTablePanelCommand({ action: "add-semantic-node", ...command });
    publishTablePanel();
  },
  onAddEdge: async (command) => {
    await handleTablePanelCommand({ action: "add-semantic-edge", ...command });
    publishTablePanel();
  },
  onRemoveEdge: async (index) => {
    await handleTablePanelCommand({ action: "remove-semantic-edge", index });
    publishTablePanel();
  },
  onRemoveNode: async (alias) => {
    await handleTablePanelCommand({ action: "remove-semantic-node", alias });
    publishTablePanel();
  },
  onAddType: async (alias, type) => {
    await handleTablePanelCommand({ action: "add-semantic-type", alias, type });
    publishTablePanel();
  },
  onRemoveType: async (alias, type) => {
    await handleTablePanelCommand({ action: "remove-semantic-type", alias, type });
    publishTablePanel();
  },
  getAdapterPrefix: adapterPrefix,
  getCustomTerms: () => state.customTerms
}) || null;
compositionGraphView = sidebarCompositionGraph?.create({
  document,
  compositions: semanticCompositions,
  toolboxApi: semanticToolboxApi,
  libraryService: semanticLibraryService,
  storage: chrome.storage?.local,
  getBlock: activeBlock,
  getCustomTerms: () => state.customTerms,
  getAdapterPrefix: adapterPrefix,
  onPreview: previewSemanticDomV2,
  onFocus: focusSemanticDomV2,
  onVisualEvidence: openVisualEvidence,
  onApply: async (composition, customTerms) => {
    await handleTablePanelCommand({ action: "replace-semantic-composition", composition, customTerms });
    semanticView?.render();
    publishTablePanel();
  }
}) || null;
semanticGraphView = sidebarSemanticGraph?.create({
  document,
  getBlock: activeBlock,
  onAnalyze: analyzeSemanticModel,
  onApply: applyVariantSuggestions,
  onClear: clearVariantSuggestions,
  onAddEvidence: addVariantEvidence,
  onRefreshClassification: refreshVariantClassification,
  onResolveEvidence: resolveVariantEvidence,
  onAcceptFallback: acceptVariantFallback,
  onPickEvidence: () => startVisualSelection("variant-evidence"),
  onPreviewItem: (index) => {
    const block = activeBlock();
    if (block) highlightTarget({ selector: block.scope, matchIndex: index }, "transient");
  },
  onClearPreview: () => clearHighlight("transient"),
  onRevealItem: (index) => {
    const block = activeBlock();
    if (block) {
      pinTarget({ selector: block.scope, matchIndex: index });
      revealTarget({ selector: block.scope, matchIndex: index, scrollIntoView: true });
    }
  },
  onSelect: (schemaType) => {
    const block = activeBlock();
    const target = variantTargets(block).find((candidate) => candidate.schemaType === schemaType);
    if (target) activateVariantEntity(target.entityName).catch((error) => setStatus(els.discoveryStatus, "error", error.message));
  }
}) || null;
attention?.registerNavigator?.("variant-evidence", (destination) => {
  openVariantEvidenceDestination(destination).catch((error) => {
    attention?.sync?.("variant-evidence-navigation", [{
      id: `variant-evidence-navigation:${error.message}`, severity: "error", message: error.message,
      destination
    }]);
  });
});
reviewView = sidebarReview?.create({
  document,
  onActivate: (blockId) => activateBlock(blockId, { pin: true }),
  onPreview: (target) => highlightTarget(target, "transient"),
  onClearPreview: () => clearHighlight("transient"),
  onPin: pinTarget,
  onReveal: revealTarget,
  onEdit: (field) => editField(field, { identity: Boolean(field.identity) }),
  onRemove: removeField,
  onAdd: pickField,
  onCheckDrift: () => checkStructuralHealth(),
  onOpenFinding: (finding) => openStructuralFinding(finding)
}) || null;
reviewView?.renderDrift(state.driftReview, canCheckStructuralHealth());
sidebarWorkflow?.bind(els.workflowSteps, navigateWorkflow);
renderRoute();

els.libraryFile?.addEventListener("change", async () => {
  const file = els.libraryFile.files?.[0];
  clearLibraryImport();
  if (!file) return;
  setLibraryStatus("Validating locally…", "loading");
  try {
    const result = await adapterRegistry.createEntry(await file.arrayBuffer(), file.name);
    const existing = state.entries.find((entry) => entry.id === result.entry.id);
    if (existing) result.entry.enabled = existing.enabled;
    state.pendingImport = result.entry;
    els.libraryPreviewTitle.textContent = `${result.summary.id} v${result.summary.version}${existing ? " · replaces published copy" : ""}`;
    const transforms = result.summary.transforms.length ? result.summary.transforms.join(", ") : "none";
    const draftWarning = existing && draftRegistry.forAdapter(state.drafts, result.entry.id) ? " · warning: the existing draft cannot publish over this replacement" : "";
    els.libraryPreviewDetails.textContent = `${result.summary.hosts.join(", ")} · ${result.summary.pageTypes.join(", ")} · transforms: ${transforms} · ${result.summary.sourceDigest}${draftWarning}`;
    els.libraryConfirmImport.textContent = existing ? "Replace adapter" : "Store adapter";
    els.libraryImportPreview.hidden = false;
    setLibraryStatus("Review this inert adapter before storing it.");
  } catch (error) {
    setLibraryStatus(error.message, "error");
  }
});

els.libraryConfirmImport?.addEventListener("click", async () => {
  if (!state.pendingImport) return;
  try {
    const id = state.pendingImport.id;
    const replaced = state.entries.some((entry) => entry.id === id);
    state.entries = adapterRegistry.upsert(state.entries, state.pendingImport);
    await adapterRegistry.save(state.entries);
    clearLibraryImport();
    refreshWorkspaceLists();
    setLibraryStatus(`${id} was ${replaced ? "replaced" : "stored"} locally.`, "ready");
  } catch (error) {
    setLibraryStatus(error.message, "error");
  }
});

els.libraryCancelImport?.addEventListener("click", () => {
  clearLibraryImport();
  setLibraryStatus("Import cancelled.");
});

els.libraryList?.addEventListener("change", async (event) => {
  const input = event.target;
  if (input.dataset.action !== "toggle-adapter") return;
  const id = input.closest("[data-adapter-id]").dataset.adapterId;
  try {
    state.entries = adapterRegistry.setEnabled(state.entries, id, input.checked);
    await adapterRegistry.save(state.entries);
    refreshWorkspaceLists();
    setLibraryStatus(`${id} is now ${input.checked ? "enabled" : "disabled"}.`, "ready");
  } catch (error) {
    setLibraryStatus(error.message, "error");
  }
});

els.libraryList?.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const adapterItem = button.closest("[data-adapter-id]");
  const draftItem = button.closest("[data-draft-id]");
  try {
    if (adapterItem) {
      const entry = state.entries.find((candidate) => candidate.id === adapterItem.dataset.adapterId);
      if (button.dataset.action === "edit-adapter") {
        const existing = draftRegistry.forAdapter(state.drafts, entry.id);
        await beginEditingDraft(existing || draftRegistry.createFromPublished(entry));
      } else if (button.dataset.action === "export-adapter") {
        downloadBytes(adapterRegistry.sourceBytes(entry), entry.sourceName || `${entry.id}.yaml`);
        setLibraryStatus(`Exported the original ${entry.id} file.`, "ready");
      } else if (button.dataset.action === "delete-adapter" && confirm(`Delete the published ${entry.id} adapter?`)) {
        state.entries = adapterRegistry.remove(state.entries, entry.id);
        await adapterRegistry.save(state.entries);
        refreshWorkspaceLists();
        setLibraryStatus(`${entry.id} was deleted.`, "ready");
      }
      return;
    }
    const draft = state.drafts.find((candidate) => candidate.id === draftItem?.dataset.draftId);
    if (!draft) return;
    if (button.dataset.action === "open-draft") {
      await beginEditingDraft(draft);
    } else if (button.dataset.action === "export-library-draft") {
      const text = draftRegistry.serializeDefinition(draft.workingDefinition);
      downloadBytes(new TextEncoder().encode(text), draft.sourceName || `${draft.adapterId}.yaml`);
      setLibraryStatus(`Exported the ${draft.adapterId} draft as YAML.`, "ready");
    } else if (button.dataset.action === "publish-library-draft") {
      if (draft.id === state.currentDraft?.id) {
        await publishCurrentDraft();
      } else {
        const result = await draftRegistry.publish(draft, state.entries, state.drafts);
        state.entries = result.entries;
        state.drafts = result.drafts;
        refreshWorkspaceLists();
        setLibraryStatus(`${result.entry.id} was published locally.`, "ready");
      }
    } else if (button.dataset.action === "discard-library-draft") {
      state.drafts = draftRegistry.remove(state.drafts, draft.id);
      await draftRegistry.save(state.drafts);
      if (draft.id === state.currentDraft?.id) {
        state.currentDraft = null;
        state.baseDefinition = null;
        await draftRegistry.activate(null);
        resetEditorForDraft();
        setStatus(els.draftStatus, "", "Choose a draft. Published adapters are unchanged.");
      }
      refreshWorkspaceLists();
      setLibraryStatus("Draft discarded. Its published adapter was not changed.", "ready");
    }
  } catch (error) {
    setLibraryStatus(error.message, "error");
  }
});

if (els.draftPicker) els.draftPicker.addEventListener("change", async () => {
  const value = els.draftPicker.value;
  if (!value) return;
  try {
    if (state.currentDraft) await saveCurrentDraft();
    let draft;
    if (value === "new") {
      draft = draftRegistry.createNew({ pageUrl: state.pageUrl });
    } else if (value.startsWith("draft:")) {
      draft = state.drafts.find((candidate) => candidate.id === value.slice("draft:".length));
    } else if (value.startsWith("published:")) {
      const entry = state.entries.find((candidate) => candidate.id === value.slice("published:".length));
      draft = draftRegistry.createFromPublished(entry);
    }
    if (!draft) throw new Error("That adapter draft is no longer available.");
    await beginEditingDraft(draft);
  } catch (error) {
    setStatus(els.draftStatus, "error", error.message);
    refreshWorkspaceLists(state.currentDraft?.id);
  }
});
els.newAdapter?.addEventListener("click", () => {
  beginEditingDraft(draftRegistry.createNew({ pageUrl: state.pageUrl }))
    .catch((error) => setLibraryStatus(error.message, "error"));
});
els.appNavigation?.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-app-view]");
  if (!button) return;
  if (button.dataset.appView === "semantics") showSemanticLibraryHome();
  else showLibraryHome();
});
els.backToLibrary?.addEventListener("click", () => {
  returnToLibrary().catch((error) => setStatus(els.draftStatus, "error", error.message));
});
els.saveDraft?.addEventListener("click", () => { saveCurrentDraft({ announce: true }).catch((error) => setStatus(els.draftStatus, "error", error.message)); });
els.exportDraft?.addEventListener("click", downloadDraftYaml);
els.publishDraft?.addEventListener("click", publishCurrentDraft);
els.discardDraft?.addEventListener("click", () => { discardCurrentDraft(); });
for (const input of [els.adapterId, els.adapterNamespace, els.pageId, els.pageType]) {
  input.addEventListener("input", () => {
    invalidateBuiltDraft();
    publishTablePanel();
  });
}
els.adapterId.addEventListener("input", () => {
  if (ensureSuggestedNamespace()) scheduleDraftAutosave();
});
els.adapterNamespace.addEventListener("input", () => {
  els.adapterNamespace.dataset.suggested = "false";
});

els.pickScope.addEventListener("click", () => { pickScope(); });
els.visualSelect?.addEventListener("click", () => { startVisualSelection(); });
els.showPageDetection?.addEventListener("click", restoreDetectionFirst);
els.scopeShowPageAnalysis?.addEventListener("click", () => {
  scopeProposalRequest += 1;
  if (restoreActivePageAnalysis()) revealPanel(els.stepScope, els.scopeLevels.querySelector(".option-item.selected"));
});
els.singleItemScope.addEventListener("change", () => {
  els.pickScope.textContent = els.singleItemScope.checked ? "Create single-item scope" : "Find repeating scope";
  updateStructureActionState();
  if (state.pendingScope) return;
  const mode = els.singleItemScope.checked ? "single" : "repeating";
  if (restoreScopeProposalView(scopeProposalCache[mode])) return;
  if (mode === "repeating" && activePageAnalysis?.report) {
    renderPageAnalysis(activePageAnalysis.report);
    const selector = activePageAnalysis.report.chosenSelector;
    if (selector) highlightSelector(selector).catch(() => {});
    return;
  }
  renderScopeLevels([], null);
  els.scopeStatus.hidden = false;
  setStatus(els.scopeStatus, "", mode === "single"
    ? "Single-item mode enabled. Create the scope again to inspect this page as one item."
    : "Repeating mode enabled. Select one example item and find its surrounding collection.");
});
els.continueSemantics?.addEventListener("click", () => { navigateWorkflow("semantics"); });
els.inferRemaining?.addEventListener("click", () => {
  inferRemainingSteps().catch((error) => setInferenceStatus("error", error.message));
});
els.reviewInferredSemantics?.addEventListener("click", () => navigateWorkflow("semantics"));
els.blockSchemaType.addEventListener("focus", () => { renderSchemaTypeMenu({ showAll: true }); });
els.blockSchemaType.addEventListener("input", () => { renderSchemaTypeMenu(); });
els.blockSchemaType.addEventListener("blur", () => { setTimeout(closeSchemaTypeMenu, 100); });
els.blockSchemaType.addEventListener("keydown", (event) => {
  if (event.key === "ArrowDown" || event.key === "ArrowUp") {
    event.preventDefault();
    if (els.schemaTypeMenu.hidden) renderSchemaTypeMenu();
    moveSchemaTypeMenu(event.key === "ArrowDown" ? 1 : -1);
  } else if (event.key === "Enter" && schemaTypeMenuIndex >= 0) {
    event.preventDefault();
    els.schemaTypeMenu.querySelectorAll(".combobox-option")[schemaTypeMenuIndex]?.click();
  } else if (event.key === "Escape") {
    event.stopPropagation();
    closeSchemaTypeMenu();
  }
});
els.createBlock.addEventListener("click", () => { createBlock().catch((error) => setStatus(els.scopeStatus, "error", error.message)); });
els.cancelBlock.addEventListener("click", cancelBlockSetup);
els.clearPinnedHighlight.addEventListener("click", clearPinnedHighlight);
els.openTablePanel.addEventListener("click", openTablePanel);
els.resumeSidebar?.addEventListener("click", () => requestEditorLease("sidebar"));
els.discoverFields.addEventListener("click", () => { discoverFields(); });
els.discoveryVariantPicker?.addEventListener("change", () => { activateVariantEntity(els.discoveryVariantPicker.value); });
els.reviewVariantPicker?.addEventListener("change", () => { activateVariantEntity(els.reviewVariantPicker.value); });
els.continueReview?.addEventListener("click", () => navigateWorkflow("review"));
els.continueFinish?.addEventListener("click", () => navigateWorkflow("finish"));
els.undoDiscovery.addEventListener("click", undoDiscovery);
els.fieldSelector.addEventListener("input", fieldSelectorChanged);
els.fieldSelector.addEventListener("change", () => {
  clearTimeout(fieldSelectorInputTimer);
  fieldSelectorChanged();
});
els.useSelection.addEventListener("click", useSelectionProposal);
els.selectFieldOnPage?.addEventListener("click", () => {
  startVisualSelection(state.pendingField ? "replace-field" : "new-field");
});
els.fieldKind.addEventListener("change", () => { updateFieldKindVisibility(); refreshFieldPreview(); });
els.fieldTransform.addEventListener("focus", () => { renderTransformMenu({ showAll: true }); });
els.fieldTransform.addEventListener("input", () => { renderTransformMenu(); });
els.fieldTransform.addEventListener("blur", () => { setTimeout(closeTransformMenu, 100); });
els.fieldTransform.addEventListener("keydown", (event) => {
  if (event.key === "ArrowDown" || event.key === "ArrowUp") {
    event.preventDefault();
    if (els.transformMenu.hidden) renderTransformMenu();
    moveTransformMenu(event.key === "ArrowDown" ? 1 : -1);
  } else if (event.key === "Enter" && transformMenuIndex >= 0) {
    event.preventDefault();
    els.transformMenu.querySelectorAll(".transform-option")[transformMenuIndex]?.click();
  } else if (event.key === "Escape") {
    event.stopPropagation();
    closeTransformMenu();
  }
});
els.saveTransformArguments.addEventListener("click", saveTransformArguments);
els.cancelTransformArguments.addEventListener("click", closeTransformArguments);
els.fieldName.addEventListener("focus", () => { renderFieldNameMenu({ showAll: true }); });
els.fieldName.addEventListener("input", () => { updateFieldSemantics({ chooseDefaults: true, showErrors: false }); renderFieldNameMenu(); });
els.fieldName.addEventListener("blur", () => { setTimeout(closeFieldNameMenu, 100); });
els.fieldName.addEventListener("keydown", (event) => {
  if (event.key === "ArrowDown" || event.key === "ArrowUp") {
    event.preventDefault();
    if (els.fieldNameMenu.hidden) renderFieldNameMenu();
    moveFieldNameMenu(event.key === "ArrowDown" ? 1 : -1);
  } else if (event.key === "Enter" && fieldNameMenuIndex >= 0) {
    event.preventDefault();
    els.fieldNameMenu.querySelectorAll(".combobox-option")[fieldNameMenuIndex]?.click();
  } else if (event.key === "Escape") {
    event.stopPropagation();
    closeFieldNameMenu();
  }
});
els.fieldIdentity.addEventListener("change", () => { updateFieldSemantics({ chooseDefaults: true }); closeFieldNameMenu(); });
els.fieldAttribute.addEventListener("change", () => { refreshFieldPreview(); });
els.fieldMultiple.addEventListener("change", () => { updateMultipleFieldSelection(); });
els.addField.addEventListener("click", () => { addField(); });
els.cancelField.addEventListener("click", () => { cancelField(); });
els.deleteField.addEventListener("click", () => { deleteEditedField(); });
els.backFromField.addEventListener("click", () => { cancelField(); });
els.saveCorrectionPromotion?.addEventListener("click", () => { saveCorrectionPromotion(); });
els.dismissCorrectionPromotion?.addEventListener("click", dismissCorrectionPromotion);
els.build.addEventListener("click", () => { buildDraft(); });
els.refreshBaseline.addEventListener("click", () => { buildDraft({ refreshBaseline: true }); });
els.captureFixture.addEventListener("click", () => { captureFixture(); });
els.previewExtraction.addEventListener("click", () => { previewExtraction(); });
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    clearHighlight("transient");
    clearPinnedHighlight();
  }
});

document.addEventListener("visibilitychange", () => {
  if (document.hidden) discardHighlights();
});
window.addEventListener("pagehide", () => { clearTimeout(autosaveTimer); discardHighlights(); disconnectTablePanel(); });
window.addEventListener("beforeunload", () => { clearTimeout(autosaveTimer); discardHighlights(); disconnectTablePanel(); });
function handlePageNavigated() {
  Site2JsonBridge.resetFrame?.();
  pageAnalysisRequest += 1;
  activePageAnalysis = null;
  pageDetectionReport = null;
  state.pageDetectionReview = null;
  state.structureStartMode = "detection";
  pageAnalysisService?.invalidate();
  scopeProposalCache.repeating = null;
  scopeProposalCache.single = null;
  discardHighlights();
  state.pageUrl = null;
  state.pendingScope = null;
  state.pendingField = null;
  hideSelectionProposal();
  closeTransformArguments();
  state.tableRows = [];
  state.lastValidDefinition = null;
  state.driftReview = { status: "idle", findings: [], message: "" };
  state.lastDiscoveryBatch = null;
  publishTablePanel({ stale: true, clear: true });
  postTablePanel({ type: "selection-focus", focus: null });
  hideFieldEditor();
  els.undoDiscovery.disabled = true;
  els.previewExtraction.disabled = true;
  setStatus(els.selectionStatus, "loading", "Page navigated. Select an item in the new document.");
  renderSelectionSummary({ ok: false, reason: "no-selection" });
  els.visualSelect.textContent = "Select item on page";
}

async function restorePageAuthoringHighlight() {
  if (state.workspaceMode !== "editor" || !state.currentDraft) return;
  if (!state.blocks.length) {
    await runDetectionFirst();
    return;
  }
  const block = activeBlock() || state.blocks[0];
  if (!block?.scope) return;
  await Site2JsonBridge.run(bridgeAcceptScope, { selector: block.scope }).catch(() => null);
  await highlightSelector(block.scope);
}

document.body.classList.add("sidepanel-host");
els.visualSelect.hidden = false;
els.selectFieldOnPage.hidden = false;
els.openTablePanel.hidden = true;
els.tablePanelStatus.hidden = true;
chrome.runtime.onMessage.addListener((message, sender) => {
    receiveVisualSelection(message, sender).catch((error) => renderSelectionSummary({ ok: false, message: error.message }));
    if (message?.type === "site2json-picker:cancelled" && sender?.tab?.id === inspectedTabId) {
      const cancelledIntent = visualSelectionIntent;
      visualSelectionIntent = null;
      if (cancelledIntent === "visual-evidence") {
        visualEvidenceView?.pickerCancelled();
        return false;
      }
      if (cancelledIntent === "scope") {
        const previousSelection = selectionBeforeVisualPick;
        selectionBeforeVisualPick = null;
        renderSelectionSummary(previousSelection || { ok: false, reason: "no-selection" });
        restoreActivePageAnalysis();
        if (!previousSelection?.ok) setStatus(els.selectionStatus, "", "Selection cancelled. Choose a recommended scope or select an item manually.");
      } else if (cancelledIntent === "variant-evidence") {
        if (semanticGraphView?.elements) semanticGraphView.elements.resolutionStatus.textContent = "Evidence selection cancelled. Choose an element or close the resolver.";
      } else if (cancelledIntent) {
        els.selectFieldOnPage.disabled = false;
        setStatus(els.fieldStatus, "", "Selection cancelled. The field has not changed.");
      }
    }
    return false;
});
chrome.tabs?.onUpdated?.addListener((changedTabId, changeInfo, tab) => {
    if (changedTabId !== inspectedTabId) return;
    if (changeInfo.status === "loading") handlePageNavigated();
    if (changeInfo.status === "complete" && state.workspaceMode === "editor" && state.currentDraft) {
      state.pageUrl = tab?.url || state.pageUrl;
      restorePageAuthoringHighlight().catch((error) => setStatus(els.scopeStatus, "error", `Page Analysis could not finish: ${error.message}`));
    }
});
(async () => {
    if (!Number.isInteger(inspectedTabId)) {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      inspectedTabId = activeTab?.id;
      state.pageUrl = activeTab?.url || null;
    } else {
      const tab = await chrome.tabs.get(inspectedTabId);
      state.pageUrl = tab?.url || null;
    }
    Site2JsonBridge.useTab?.(inspectedTabId);
})().catch(() => {}).finally(() => {
  renderSelectionSummary({ ok: false, reason: "no-selection" });
  configureTablePanel();
  connectTablePanel();
  initializeDraftWorkspace();
});
