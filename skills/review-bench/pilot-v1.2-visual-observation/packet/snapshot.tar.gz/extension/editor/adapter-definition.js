(function initializeAdapterDefinition(root, factory) {
  "use strict";
  const dsl = root.Site2JsonDsl || (typeof require === "function" ? require("../core/dsl") : null);
  const api = factory(dsl);
  root.Site2JsonAdapterDefinition = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function adapterDefinitionFactory(dsl) {
  "use strict";

  const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));

  function derivePathRule(pathname) {
    const normalized = pathname.length > 1 ? pathname.replace(/\/$/, "") : pathname;
    return { mode: "exact", value: normalized || "/" };
  }

  function declaredSelector(selector, attribute) {
    return attribute ? `${selector}@${attribute}` : selector;
  }

  function fieldBinding(pick) {
    const transform = pick.transform || (pick.kind === "url" ? ["absoluteUrl", "stripQuery"] : ["text", "trim"]);
    if (pick.source) return { source: pick.source, transform, ...(pick.multiple ? { multiple: true } : {}) };
    const selectors = pick.selectors?.length ? [...pick.selectors] : [declaredSelector(pick.selector, pick.attribute)];
    return { selectors, transform, ...(pick.multiple ? { multiple: true } : {}) };
  }

  function compiledVariantSignals(candidate, peers) {
    if (Array.isArray(candidate.signals)) return clone(candidate.signals);
    const peerFields = (peers || []).map((peer) => new Map((peer.fields || []).map((field) => [field.name, field])));
    return (candidate.fields || []).slice(0, 64).map((field) => {
      const occurrences = peerFields.filter((fields) => fields.has(field.name)).length;
      const binding = JSON.stringify(fieldBinding(field));
      const equivalent = peerFields.filter((fields) => fields.has(field.name) && JSON.stringify(fieldBinding(fields.get(field.name))) === binding).length;
      const kind = field.identity ? "identity" : field.name.includes(".") ? "relationship" : "field";
      const weight = occurrences === 1 ? (kind === "relationship" ? 12 : 10) : equivalent < peerFields.length ? 6 : kind === "identity" ? 1 : 2;
      return { field: field.name, kind, weight };
    });
  }

  function definitionBlock(block) {
    const rootCandidates = block.variants?.candidates || [];
    return {
      entity: block.entityName,
      scope: block.scope,
      arity: block.arity || "many",
      role: block.role || "collection",
      fidelity: block.fidelity || "summary",
      ...(block.structuralBaseline ? { structuralBaseline: JSON.parse(JSON.stringify(block.structuralBaseline)) } : {}),
      ...(block.variants?.candidates?.length ? { variants: {
        fallback: block.entityName,
        candidates: block.variants.candidates.map((candidate) => ({
          entity: candidate.entityName,
          signals: compiledVariantSignals(candidate, rootCandidates),
          evidence: candidate.evidence.map((rule) => ({ ...rule }))
        })),
        minScore: block.variants.minScore,
        minMargin: block.variants.minMargin
      } } : {}),
      ...(block.variantSlots?.length ? { variantSlots: block.variantSlots.map((slot) => ({
        path: slot.path,
        fallback: slot.fallback.entityName,
        candidates: slot.candidates.map((candidate) => ({
          entity: candidate.entityName,
          signals: compiledVariantSignals(candidate, slot.candidates),
          evidence: clone(candidate.evidence || [])
        })),
        minScore: slot.minScore,
        minMargin: slot.minMargin
      })) } : {}),
      ...(block.requireFields?.length ? { require: block.requireFields } : {}),
      ...(block.monitorFields?.length ? { monitor: block.monitorFields } : {})
    };
  }

  function definitionEntity(block) {
    const fields = (block.fields || []).map((field) => ({ ...field }));
    let identityField = block.identityField || fields.find((field) => field.identity)?.name || null;
    // Older editor states stored canonical identity as a separate selector.
    // Normalize those states while building so existing drafts remain valid,
    // but emit one semantic field as the source of truth going forward.
    if (!identityField && block.identity) {
      identityField = block.identity.name && block.identity.name !== "canonicalUrl" ? block.identity.name : "url";
      const normalized = { ...block.identity, name: identityField, identity: true };
      const existing = fields.findIndex((field) => field.name === identityField);
      if (existing >= 0) fields[existing] = normalized;
      else fields.unshift(normalized);
    }
    if (!identityField) throw new Error(`${block.entityName || block.schemaType || "Entity"} requires an identity field.`);
    return {
      schemaType: block.schemaType,
      identity: { field: identityField },
      fields: Object.fromEntries(fields.map((field) => [field.name, fieldBinding(field)]))
    };
  }

  function authoringEnvelope(blocks, pageId) {
    const knowledge = new Map();
    const decisions = [];
    for (const block of blocks) for (const entity of [block, ...(block.variants?.candidates || [])]) {
      for (const field of entity.fields || []) {
        const report = field.corroboration;
        if (!report?.property) continue;
        const refs = [];
        for (const source of report.localKnowledge?.sources || []) {
          if (!source.profile || !source.profileDigest) continue;
          const id = `${source.id || source.termId || report.property}@${source.profileDigest}`;
          refs.push(id);
          if (!knowledge.has(id)) knowledge.set(id, {
            id,
            kind: "property-profile",
            term: source.termId || report.property,
            revision: source.revision ?? null,
            digest: source.profileDigest,
            provenance: {
              source: clone(source.source || null),
              bundle: clone(source.bundle || null),
              importId: source.importId || null,
              canonicalUri: source.canonicalUri || null,
              libraryRecordId: source.id || null
            },
            profile: clone(source.profile)
          });
        }
        decisions.push({
          id: `${pageId}:${block.entityName}:${entity.entityName}:${field.name}`,
          page: pageId,
          block: block.entityName,
          entity: entity.entityName,
          field: field.name,
          property: report.property,
          status: report.status || "accepted",
          confidence: report.confidence || "unknown",
          acceptedByAuthor: Boolean(report.localKnowledge?.acceptedByAuthor || field.provenance === "manual"),
          knowledgeRefs: refs,
          report: clone(report)
        });
      }
    }
    for (const block of blocks) for (const receipt of (block.fallbackAcceptances || []).slice(-128)) {
      decisions.push({
        id: `${pageId}:${block.entityName}:variant-fallback:${receipt.slotPath || "root"}:${receipt.classificationFingerprint}:${receipt.configurationDigest}`,
        page: pageId,
        block: block.entityName,
        entity: receipt.fallbackEntity || block.entityName,
        field: receipt.slotPath || "$variant",
        property: receipt.fallbackEntity || block.schemaType,
        status: "fallback-accepted",
        confidence: "author-reviewed",
        acceptedByAuthor: true,
        knowledgeRefs: [],
        report: { version: 1, kind: "variant-fallback", ...clone(receipt) }
      });
    }
    return decisions.length ? { version: 1, knowledge: [...knowledge.values()], decisions } : null;
  }

  function buildDraftDefinition({
    adapterId,
    namespace,
    pageUrl,
    pageId,
    pageType,
    fixture = null,
    entityName,
    schemaType,
    scope,
    arity = "many",
    role = "collection",
    fidelity = "summary",
    identity,
    identityField,
    fields = [],
    requireFields = [],
    blocks = null,
    customTerms = {},
    version = 1
  }) {
    const url = new URL(pageUrl);
    const draftBlocks = blocks || [{
      entityName, schemaType, scope, arity, role, fidelity, identity, identityField, fields, requireFields
    }];
    const authoring = authoringEnvelope(draftBlocks, pageId);
    return {
      adapter: adapterId,
      version,
      dslVersion: 1,
      namespace,
      ...(Object.keys(customTerms).length ? { vocabulary: { terms: customTerms } } : {}),
      ...(authoring ? { authoring } : {}),
      hosts: [url.hostname],
      entities: Object.fromEntries(draftBlocks.flatMap((block) => [
        [block.entityName, definitionEntity(block)],
        ...(block.variants?.candidates || []).map((candidate) => [candidate.entityName, definitionEntity({
          ...block,
          entityName: candidate.entityName,
          schemaType: candidate.schemaType,
          fields: candidate.fields || block.fields,
          identityField: candidate.identityField || block.identityField,
          identity: candidate.identity || block.identity
        })]),
        ...(block.variantSlots || []).flatMap((slot) => [slot.fallback, ...slot.candidates].map((candidate) => [candidate.entityName, definitionEntity(candidate)]))
      ])),
      pages: [
        {
          id: pageId,
          match: { host: [url.hostname], path: [derivePathRule(url.pathname)] },
          pageType,
          ...(fixture ? { fixture: JSON.parse(JSON.stringify(fixture)) } : {}),
          blocks: draftBlocks.map(definitionBlock)
        }
      ]
    };
  }

  function validateDraft(definition) {
    try {
      return { ok: true, definition: dsl.validateDefinition(definition) };
    } catch (error) {
      return { ok: false, message: error instanceof Error ? error.message : String(error) };
    }
  }

  function selectorPick(name, binding) {
    const declared = binding.selectors?.[0] || ":scope";
    const match = declared.startsWith("xpath:") ? null : declared.match(/^(.*)@([A-Za-z_][\w:.-]*)$/);
    const attribute = match ? match[2] : null;
    return {
      name,
      ...(binding.source ? { source: binding.source } : {}),
      selector: match ? match[1] : declared,
      selectors: [...binding.selectors],
      attribute,
      kind: attribute === "href" || attribute === "src" ? "url" : "text",
      multiple: Boolean(binding.multiple),
      transform: [...binding.transform],
      provenance: "imported",
      locked: true,
      unresolved: false
    };
  }

  function editorEntity(entity) {
    const fields = Object.entries(entity.fields).map(([name, binding]) => selectorPick(name, binding));
    let identityField = entity.identity?.field || null;
    if (!identityField && entity.identity?.canonicalUrl) {
      identityField = "url";
      const legacy = { ...selectorPick(identityField, entity.identity.canonicalUrl), identity: true };
      const existing = fields.findIndex((field) => field.name === identityField);
      if (existing >= 0) fields[existing] = legacy;
      else fields.unshift(legacy);
    }
    for (const field of fields) field.identity = field.name === identityField;
    return { identityField, fields };
  }

  function pathMatches(page, url) {
    return page.match.host.includes(url.hostname) && page.match.path.some((rule) => (
      rule.mode === "exact" ? url.pathname === rule.value || url.pathname === `${rule.value}/` : url.pathname.startsWith(rule.value)
    ));
  }

  function editorStateFromDefinition(definition, pageUrl) {
    const url = new URL(pageUrl);
    const page = definition.pages.find((candidate) => pathMatches(candidate, url));
    if (!page) return null;
    const blocks = page.blocks.map((block, index) => {
      const entity = definition.entities[block.entity];
      const editor = editorEntity(entity);
      const decisionFor = (entityName, field) => definition.authoring?.decisions?.find((decision) => decision.page === page.id && decision.entity === entityName && decision.field === field.name);
      for (const field of editor.fields) {
        const decision = decisionFor(block.entity, field);
        if (decision?.report) field.corroboration = clone(decision.report);
      }
      return {
        id: `imported-${index}-${block.entity}`,
        name: block.entity,
        entityName: block.entity,
        schemaType: entity.schemaType,
        scope: block.scope,
        arity: block.arity,
        role: block.role,
        fidelity: block.fidelity,
        identityField: editor.identityField,
        fields: editor.fields,
        requireFields: [...(block.require || [])],
        monitorFields: [...(block.monitor || [])],
        fallbackAcceptances: (definition.authoring?.decisions || [])
          .filter((decision) => decision.page === page.id && decision.block === block.entity && decision.report?.kind === "variant-fallback")
          .map((decision) => {
            const receipt = clone(decision.report);
            delete receipt.kind;
            delete receipt.version;
            return receipt;
          }).slice(-128),
        ...(block.structuralBaseline ? { structuralBaseline: JSON.parse(JSON.stringify(block.structuralBaseline)) } : {}),
        ...(block.variants ? { variants: {
          minScore: block.variants.minScore,
          minMargin: block.variants.minMargin,
          candidates: block.variants.candidates.map((candidate) => {
            const variant = definition.entities[candidate.entity];
            const variantEditor = editorEntity(variant);
            for (const field of variantEditor.fields) {
              const decision = decisionFor(candidate.entity, field);
              if (decision?.report) field.corroboration = clone(decision.report);
            }
            return {
              entityName: candidate.entity,
              schemaType: variant.schemaType,
              signals: clone(candidate.signals),
              evidence: candidate.evidence.map((rule) => ({ ...rule })),
              identityField: variantEditor.identityField,
              fields: variantEditor.fields,
              requireFields: [...(block.require || [])],
              monitorFields: [...(block.monitor || [])]
            };
          })
        } } : {}),
        ...(block.variantSlots ? { variantSlots: block.variantSlots.map((slot) => ({
          path: slot.path,
          minScore: slot.minScore,
          minMargin: slot.minMargin,
          fallback: {
            entityName: slot.fallback,
            schemaType: definition.entities[slot.fallback].schemaType,
            ...editorEntity(definition.entities[slot.fallback])
          },
          candidates: slot.candidates.map((candidate) => ({
            entityName: candidate.entity,
            schemaType: definition.entities[candidate.entity].schemaType,
            signals: clone(candidate.signals),
            evidence: clone(candidate.evidence),
            ...editorEntity(definition.entities[candidate.entity])
          }))
        })) } : {}),
        matchCount: 0
      };
    });
    return {
      pageUrl,
      pageId: page.id,
      pageType: page.pageType,
      ...(page.fixture ? { fixture: JSON.parse(JSON.stringify(page.fixture)) } : {}),
      adapterId: definition.adapter,
      namespace: definition.namespace,
      version: definition.version,
      blocks,
      customTerms: JSON.parse(JSON.stringify(definition.vocabulary?.terms || {}))
    };
  }

  function mergeWithBase(baseDefinition, generatedDefinition, editedPageId) {
    if (!baseDefinition) return generatedDefinition;
    if (baseDefinition.adapter !== generatedDefinition.adapter) throw new Error("An existing adapter's id cannot be changed inside its draft.");
    const merged = JSON.parse(JSON.stringify(baseDefinition));
    merged.namespace = generatedDefinition.namespace;
    merged.vocabulary = generatedDefinition.vocabulary;
    if (!merged.vocabulary) delete merged.vocabulary;
    const retainedDecisions = (merged.authoring?.decisions || []).filter((decision) => decision.page !== editedPageId);
    const nextDecisions = [...retainedDecisions, ...(generatedDefinition.authoring?.decisions || [])];
    const referencedKnowledge = new Set(nextDecisions.flatMap((decision) => decision.knowledgeRefs || []));
    const allKnowledge = [...(merged.authoring?.knowledge || []), ...(generatedDefinition.authoring?.knowledge || [])];
    const knowledge = [...new Map(allKnowledge.filter((item) => referencedKnowledge.has(item.id)).map((item) => [item.id, item])).values()];
    if (nextDecisions.length) merged.authoring = { version: 1, knowledge, decisions: nextDecisions };
    else delete merged.authoring;
    merged.hosts = [...new Set([...merged.hosts, ...generatedDefinition.hosts])];
    for (const [name, entity] of Object.entries(generatedDefinition.entities)) merged.entities[name] = entity;
    const generatedPage = generatedDefinition.pages[0];
    const index = merged.pages.findIndex((page) => page.id === editedPageId);
    if (index < 0) merged.pages.push(generatedPage);
    else merged.pages[index] = { ...merged.pages[index], pageType: generatedPage.pageType, blocks: generatedPage.blocks };
    return merged;
  }

  function compileVariantSignals(candidates) {
    return (candidates || []).map((candidate) => ({
      entityName: candidate.entityName,
      signals: compiledVariantSignals(candidate, candidates)
    }));
  }

  function compileVariantSlotRuntime(slot) {
    if (!slot?.path || !slot?.fallback || !slot?.candidates?.length) throw new Error("A nested variant slot requires a path, fallback, and candidates.");
    const members = [slot.fallback, ...slot.candidates];
    const entities = Object.fromEntries(members.map((member) => [member.entityName, definitionEntity(member)]));
    return {
      definition: { entities },
      slot: {
        path: slot.path,
        fallback: slot.fallback.entityName,
        candidates: slot.candidates.map((candidate) => ({
          entity: candidate.entityName,
          signals: compiledVariantSignals(candidate, slot.candidates),
          evidence: clone(candidate.evidence || [])
        })),
        minScore: slot.minScore,
        minMargin: slot.minMargin
      }
    };
  }

  return { buildDraftDefinition, compileVariantSignals, compileVariantSlotRuntime, editorStateFromDefinition, mergeWithBase, validateDraft };
});
