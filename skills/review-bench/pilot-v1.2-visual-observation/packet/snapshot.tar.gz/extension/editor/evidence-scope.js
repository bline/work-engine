(function initializeEvidenceScope(root, factory) {
  "use strict";
  const selectors = root.Site2JsonSelectorCandidates || (typeof require === "function" ? require("./selector-candidates") : null);
  const discovery = root.Site2JsonFieldDiscovery || (typeof require === "function" ? require("./field-discovery") : null);
  const api = factory(selectors, discovery);
  root.Site2JsonEvidenceScope = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function evidenceScopeFactory(selectors, discovery) {
  "use strict";

  const DATE = /\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:\s*,)?\s+\d{4}\b/i;
  const MONEY = /(?:[$€£]|\b(?:usd|eur|gbp|cad|aud)\b)\s*\d|\d\s*(?:[$€£]|\b(?:usd|eur|gbp|cad|aud)\b)/i;
  const PERCENT = /\d+(?:\.\d+)?\s*%/;
  const SKIP = new Set(["button", "form", "html", "input", "nav", "noscript", "option", "path", "script", "select", "style", "svg", "template", "textarea", "use"]);
  const SINGLETON_SKIP = new Set(["aside", "footer", "form", "header", "nav"]);
  const DETAIL_HOOK = /(?:^|[-_])(?:article|content|detail|entry|item|job|main|page|post|product|profile|record|story)(?:$|[-_])/i;
  const SECONDARY_HOOK = /(?:^|[-_])(?:author|authors|contributor|contributors|recommended|recommendations|related|sidebar|similar|suggested)(?:$|[-_])/i;
  const WEIGHT = Object.freeze({ url: 5, heading: 4, date: 4, money: 4, image: 2, percentage: 2, text: 1 });
  const KIND_RANK = Object.freeze({ data: 0, aria: 1, class: 2, structure: 3, derived: 4, fallback: 5 });
  const SINGLETON_KIND_WEIGHT = Object.freeze({ id: 18, data: 18, aria: 15, class: 12, structure: 10, derived: 2, fallback: -8 });

  function cleanText(node) {
    return String(node?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function eligible(node) {
    if (!node?.tagName) return false;
    const tag = node.tagName.toLowerCase();
    return !SKIP.has(tag) && !node.hidden && node.getAttribute("aria-hidden") !== "true";
  }

  function semanticHook(node) {
    return [selectors.stableId(node), ...selectors.stableClassNames(node), node.getAttribute?.("data-test"), node.getAttribute?.("data-testid"), node.getAttribute?.("itemprop"), node.getAttribute?.("aria-label")]
      .filter(Boolean).join(" ");
  }

  function evidenceKinds(node) {
    const tag = node.tagName.toLowerCase();
    const text = cleanText(node);
    const kinds = [];
    if (tag === "a" && node.hasAttribute("href") && !/^(?:#|javascript:)/i.test(node.getAttribute("href"))) kinds.push("url");
    if (/^h[1-6]$/.test(tag)) kinds.push("heading");
    if (tag === "img" && node.hasAttribute("src") && !/^data:/i.test(node.getAttribute("src"))) kinds.push("image");
    if (tag === "time" || node.hasAttribute("datetime") || DATE.test(text)) kinds.push("date");
    if (MONEY.test(text)) kinds.push("money");
    if (PERCENT.test(text)) kinds.push("percentage");
    const childCount = node.children?.length || 0;
    if (text.length >= 3 && text.length <= 500 && (childCount === 0 || semanticHook(node))) kinds.push("text");
    return [...new Set(kinds)];
  }

  function evidenceNodes(document, { elementLimit = 6000, evidenceLimit = 600 } = {}) {
    const found = [];
    for (const node of Array.from(document.querySelectorAll("*")).slice(0, elementLimit)) {
      if (!eligible(node)) continue;
      const kinds = evidenceKinds(node);
      if (!kinds.length || (kinds.length === 1 && kinds[0] === "text" && !semanticHook(node))) continue;
      found.push({ node, kinds });
      if (found.length >= evidenceLimit) break;
    }
    return found;
  }

  function parentCount(nodes) {
    return new Set(nodes.map((node) => node.parentElement).filter(Boolean)).size;
  }

  function parentAnchoredSelectors(node, document) {
    const parent = node.parentElement;
    if (!parent) return [];
    const tag = node.tagName.toLowerCase();
    const results = [];
    for (const candidate of selectors.generateCandidates(parent, document)) {
      if (["id", "derived", "fallback"].includes(candidate.kind)) continue;
      const selector = `${candidate.selector} > ${tag}`;
      let roots;
      try { roots = Array.from(document.querySelectorAll(selector)); } catch { continue; }
      if (roots.length > 1 && roots.includes(node)) results.push({ selector, kind: "structure", matchCount: roots.length });
    }
    return results;
  }

  function rootEvidence(root, evidence) {
    const contained = evidence.filter((item) => root === item.node || root.contains(item.node));
    const kinds = new Set(contained.flatMap((item) => item.kinds));
    const urls = contained.filter((item) => item.kinds.includes("url")).map((item) => item.node.getAttribute("href")).filter(Boolean);
    const headingLink = root.matches?.("h1 a[href], h2 a[href], h3 a[href]")
      ? root
      : root.querySelector?.("h1 a[href], h2 a[href], h3 a[href]");
    const primaryUrl = headingLink?.getAttribute("href") || urls[0] || "";
    return {
      kinds, urls, primaryUrl, textLength: cleanText(root).length,
      count: contained.length, descendantCount: contained.filter((item) => item.node !== root).length
    };
  }

  function normalizedIdentity(value, document) {
    if (!value || /^(?:#|javascript:)/i.test(value)) return "";
    try {
      const url = new URL(value, document.location?.href || "https://site2json.invalid/");
      url.hash = "";
      for (const key of [...url.searchParams.keys()]) {
        if (/^(?:utm_.+|fbclid|gclid)$/i.test(key)) url.searchParams.delete(key);
      }
      return url.href;
    } catch {
      return String(value).trim();
    }
  }

  function entityIndependence(document, roots, perRoot, consistentKinds) {
    const nested = roots.map((root, index) => roots.some((other, otherIndex) => index !== otherIndex && (root.contains(other) || other.contains(root))));
    const topologyRatio = nested.filter((value) => !value).length / roots.length;
    const requiredKinds = Math.max(2, Math.ceil(consistentKinds.length * 0.6));
    const complete = perRoot.map((item) => {
      const repeatedKinds = consistentKinds.filter((kind) => item.kinds.has(kind)).length;
      return repeatedKinds >= requiredKinds && (item.kinds.has("url") || item.kinds.has("heading"));
    });
    const completenessRatio = complete.filter(Boolean).length / roots.length;
    const identities = perRoot.map((item) => normalizedIdentity(item.primaryUrl, document)).filter(Boolean);
    const identityDistinctness = identities.length
      ? new Set(identities).size / roots.length
      : 0.5;
    const lengths = perRoot.map((item) => item.textLength).filter((length) => length > 0).sort((a, b) => a - b);
    const sizeBalance = lengths.length > 1 ? lengths[0] / Math.max(1, lengths[lengths.length - 1]) : 1;
    const score = topologyRatio * 0.35 + completenessRatio * 0.3 + identityDistinctness * 0.25 + sizeBalance * 0.1;
    return {
      score: Math.round(score * 100) / 100,
      topologyRatio: Math.round(topologyRatio * 100) / 100,
      completenessRatio: Math.round(completenessRatio * 100) / 100,
      identityDistinctness: Math.round(identityDistinctness * 100) / 100,
      sizeBalance: Math.round(sizeBalance * 100) / 100,
      nestedMatchCount: nested.filter(Boolean).length
    };
  }

  function secondaryContext(node) {
    for (let current = node; current?.tagName && current.tagName !== "BODY"; current = current.parentElement) {
      const tag = current.tagName.toLowerCase();
      if (["aside", "footer", "nav"].includes(tag) || current.getAttribute?.("role") === "complementary") return true;
      if (SECONDARY_HOOK.test(semanticHook(current))) return true;
    }
    return false;
  }

  function evaluate(document, selector, selectorKind, evidence, nodeIds) {
    let roots;
    try { roots = Array.from(document.querySelectorAll(selector)); } catch { return null; }
    if (roots.length < 2 || roots.length > 250) return null;
    // A class selector generated from an eligible descendant can also match a
    // page-level BODY/FORM wrapper. Treat the selector as a whole: one
    // ineligible root makes it unsafe as an entity collection boundary.
    if (roots.some((root) => !eligible(root))) return null;
    const perRoot = roots.map((root) => rootEvidence(root, evidence));
    const useful = perRoot.filter((item) => item.kinds.size >= 2);
    if (useful.length < Math.min(2, roots.length)) return null;
    const kinds = [...new Set(perRoot.flatMap((item) => [...item.kinds]))];
    const coverage = Object.fromEntries(kinds.map((kind) => [kind, perRoot.filter((item) => item.kinds.has(kind)).length / roots.length]));
    const consistentKinds = kinds.filter((kind) => coverage[kind] >= 0.6 && kind !== "text");
    if (consistentKinds.length < 2) return null;
    const parents = parentCount(roots);
    const distinctUrls = new Set(perRoot.flatMap((item) => item.urls)).size;
    const urlCoverage = perRoot.filter((item) => item.urls.length).length / roots.length;
    const identityRatio = urlCoverage && distinctUrls ? Math.min(urlCoverage, distinctUrls / roots.length) : 0;
    const consistency = consistentKinds.reduce((sum, kind) => sum + coverage[kind] * (WEIGHT[kind] || 1), 0);
    const descendantRatio = perRoot.reduce((sum, item) => sum + (item.count ? item.descendantCount / item.count : 0), 0) / roots.length;
    const commonParentScore = parents === 1 ? 18 : Math.max(-30, 8 - parents * 4);
    const fragilityPenalty = selectorKind === "fallback" ? 20 : selectorKind === "derived" ? 10 : 0;
    const secondaryRatio = roots.filter(secondaryContext).length / roots.length;
    const secondaryPenalty = secondaryRatio * 45;
    const independence = entityIndependence(document, roots, perRoot, consistentKinds);
    const independenceAdjustment = independence.score * 30 - (1 - independence.score) * 45;
    const score = Math.round((consistency * 10 + identityRatio * 35 + Math.min(roots.length, 20) + commonParentScore + descendantRatio * 12 + independenceAdjustment - fragilityPenalty - secondaryPenalty) * 10) / 10;
    const findings = [
      { kind: parents === 1 ? "good" : "warning", message: parents === 1 ? "All candidate items share one collection parent." : `Candidate items are spread across ${parents} parents.` },
      { kind: "good", message: `${consistentKinds.join(", ")} evidence repeats across most items.` }
    ];
    if (identityRatio >= 0.6) findings.push({ kind: "good", message: "Most items contain a distinct URL identity candidate." });
    else findings.push({ kind: "warning", message: "Distinct item identity is weak or missing." });
    if (independence.nestedMatchCount) findings.push({ kind: "warning", message: `${independence.nestedMatchCount} matches contain or are contained by another match; they are not independent collection items.` });
    if (independence.completenessRatio < 0.8) findings.push({ kind: "warning", message: "Some matches look like fragments rather than complete entity observations." });
    if (independence.identityDistinctness < 0.8) findings.push({ kind: "warning", message: "Candidate identity repeats across matches." });
    if (independence.sizeBalance < 0.3) findings.push({ kind: "warning", message: "Match sizes are severely imbalanced, which suggests one entity may have been split into fragments." });
    findings.push({
      kind: independence.score >= 0.75 && independence.topologyRatio === 1 ? "good" : "warning",
      message: `Entity independence ${Math.round(independence.score * 100)}%: topology ${Math.round(independence.topologyRatio * 100)}%, completeness ${Math.round(independence.completenessRatio * 100)}%, identity ${Math.round(independence.identityDistinctness * 100)}%, balance ${Math.round(independence.sizeBalance * 100)}%.`
    });
    if (secondaryRatio >= 0.5) findings.push({ kind: "warning", message: "Most matches occur in related, recommended, or complementary page content." });
    return {
      selector, kind: selectorKind, tag: roots[0].tagName.toLowerCase(), matchCount: roots.length,
      rootSignature: roots.map((root) => {
        if (!nodeIds.has(root)) nodeIds.set(root, nodeIds.size + 1);
        return nodeIds.get(root);
      }).join(","),
      parentCount: parents, evidenceKinds: kinds, consistentKinds, evidenceCoverage: coverage,
      identityRatio: Math.round(identityRatio * 100) / 100,
      entityIndependence: independence,
      secondaryContextRatio: Math.round(secondaryRatio * 100) / 100,
      score, findings
    };
  }

  function findRepeating(document, options = {}, providedEvidence = null) {
    const evidence = providedEvidence || evidenceNodes(document, options);
    const ancestors = [];
    const seenNodes = new Set();
    const maxDepth = options.maxDepth ?? 7;
    for (const item of evidence) {
      let node = item.node;
      for (let depth = 0; node && node.tagName && depth <= maxDepth && node.tagName !== "BODY"; depth += 1, node = node.parentElement) {
        if (!seenNodes.has(node)) { seenNodes.add(node); ancestors.push(node); }
      }
    }
    const bySelector = new Map();
    for (const node of ancestors.slice(0, options.ancestorLimit ?? 1200)) {
      const candidates = [...selectors.generateCandidates(node, document), ...parentAnchoredSelectors(node, document)];
      for (const candidate of candidates) {
        if (candidate.kind === "id" || candidate.matchCount < 2 || candidate.matchCount > 250) continue;
        const current = bySelector.get(candidate.selector);
        if (!current || (KIND_RANK[candidate.kind] ?? 9) < (KIND_RANK[current.kind] ?? 9)) bySelector.set(candidate.selector, candidate);
      }
    }
    const nodeIds = new Map();
    const seenRootSets = new Set();
    const ranked = Array.from(bySelector.values(), (candidate) => evaluate(document, candidate.selector, candidate.kind, evidence, nodeIds))
      .filter(Boolean)
      .sort((left, right) => right.score - left.score || right.consistentKinds.length - left.consistentKinds.length || left.parentCount - right.parentCount)
      .filter((candidate) => {
        if (seenRootSets.has(candidate.rootSignature)) return false;
        seenRootSets.add(candidate.rootSignature);
        return true;
      })
      .slice(0, options.candidateLimit ?? 8);
    const winner = ranked[0] || null;
    const runnerUp = ranked[1] || null;
    const margin = winner ? winner.score - (runnerUp?.score || 0) : 0;
    const independentCollection = winner?.entityIndependence?.score >= 0.75
      && winner.entityIndependence.topologyRatio === 1
      && winner.entityIndependence.completenessRatio >= 0.8
      && winner.entityIndependence.identityDistinctness >= 0.8
      && winner.entityIndependence.sizeBalance >= 0.3;
    const confidence = !winner ? "none" : winner.score >= 120 && margin >= 10 && winner.identityRatio >= 0.6 && independentCollection ? "high" : winner.score >= 85 ? "medium" : "low";
    const candidates = ranked.map((candidate) => {
      const observed = discovery.discover(document, candidate.selector, { sampleLimit: 40, elementLimit: 400 });
      const { rootSignature: _rootSignature, ...plain } = candidate;
      return { ...plain, observations: observed.ok ? observed.candidates : [], sampledScopes: observed.ok ? observed.sampledScopes : 0 };
    });
    return { ok: true, mode: "collection", evidenceCount: evidence.length, confidence, margin: Math.round(margin * 10) / 10, candidates, chosen: candidates[0] || null };
  }

  function elementDepth(node) {
    let depth = 0;
    for (let current = node; current?.parentElement; current = current.parentElement) depth += 1;
    return depth;
  }

  function descendantElementCount(root) {
    return root.querySelectorAll?.("*").length || 0;
  }

  function selectorForSingleton(node, document) {
    if (node === document.body) return { selector: "body", kind: "structure", matchCount: 1 };
    const tag = node.tagName.toLowerCase();
    if (["article", "main"].includes(tag) && document.querySelectorAll(tag).length === 1) {
      return { selector: tag, kind: "structure", matchCount: 1 };
    }
    return selectors.generateCandidates(node, document).find((candidate) => candidate.matchCount === 1) || null;
  }

  function singletonRoots(document, evidence, { selectedElement = null, maxDepth = 10, singletonRootLimit = 120 } = {}) {
    const roots = [];
    const byNode = new Map();
    const reasonRank = { selected: 0, "selected-ancestor": 0, landmark: 1, "semantic-hook": 2, "split-layout": 3, "header-content-siblings": 4 };
    function add(node, reason, depth = elementDepth(node)) {
      if (!node?.tagName || node.tagName === "HTML") return;
      const tag = node.tagName.toLowerCase();
      if (SINGLETON_SKIP.has(tag) || node.hidden || node.getAttribute("aria-hidden") === "true") return;
      const current = byNode.get(node);
      if (current) {
        if ((reasonRank[reason] ?? 0) > (reasonRank[current.reason] ?? 0)) current.reason = reason;
        return;
      }
      const entry = { node, reason, depth };
      byNode.set(node, entry);
      roots.push(entry);
    }

    function addHeaderContentRoots(containing = null) {
      for (const header of document.querySelectorAll("header")) {
        const entityHeading = header.querySelector("h1");
        const parent = header.parentElement;
        if (!entityHeading || !parent || header.querySelector("nav") || header.closest("nav, aside, footer")) continue;
        if (containing && parent !== containing && !parent.contains(containing)) continue;
        const controls = header.querySelectorAll("button, input, select, textarea").length;
        const siblingContent = Array.from(parent.children).filter((node) => node !== header && !["NAV", "ASIDE", "FOOTER"].includes(node.tagName))
          .some((node) => cleanText(node).length >= 120 && (node.querySelector("p, article, main, section") || cleanText(node).split(/\s+/).length >= 45));
        if (controls <= 2 && siblingContent) add(parent, "header-content-siblings");
      }
    }

    if (selectedElement) {
      for (let node = selectedElement, depth = 0; node?.tagName && depth <= maxDepth; node = node.parentElement, depth += 1) {
        add(node, node === selectedElement ? "selected" : "selected-ancestor", depth);
        if (node === document.body) break;
      }
      if (selectedElement === document.body) {
        for (const node of document.querySelectorAll("article, main, [role='main']")) add(node, "landmark");
      }
      addHeaderContentRoots(selectedElement);
      return roots.slice(0, singletonRootLimit);
    }

    for (const node of document.querySelectorAll("main, [role='main']")) add(node, "landmark");
    const articles = Array.from(document.querySelectorAll("article"));
    for (const node of articles) {
      const stableUnique = selectors.generateCandidates(node, document).some((candidate) => candidate.matchCount === 1 && !["derived", "fallback"].includes(candidate.kind));
      if (articles.length === 1 || (node.querySelector("h1") && stableUnique)) add(node, "landmark");
    }
    for (const item of evidence) {
      for (let node = item.node, depth = 0; node?.tagName && node !== document.body && depth <= maxDepth; node = node.parentElement, depth += 1) {
        const hook = `${selectors.stableId(node)} ${selectors.stableClassNames(node).join(" ")} ${node.getAttribute?.("data-test") || ""} ${node.getAttribute?.("data-testid") || ""}`;
        if (DETAIL_HOOK.test(hook)) add(node, "semantic-hook");
      }
    }

    // Some detail pages split the title and body into sibling containers. In
    // that case their nearest shared root is a legitimate collection of one.
    const heading = document.querySelector("h1");
    const main = document.querySelector("main, [role='main']");
    if (heading && main && !main.contains(heading) && cleanText(main).length >= 120) {
      let shared = heading;
      while (shared && shared !== document.body && !shared.contains(main)) shared = shared.parentElement;
      add(shared || document.body, "split-layout");
    }
    addHeaderContentRoots();
    return roots.slice(0, singletonRootLimit);
  }

  function evaluateSingleton(document, rootInfo, evidence) {
    const root = rootInfo.node;
    const selectorCandidate = selectorForSingleton(root, document);
    if (!selectorCandidate) return null;
    const tag = root.tagName.toLowerCase();
    const text = cleanText(root);
    const words = text ? text.split(/\s+/).length : 0;
    const elements = descendantElementCount(root);
    const rootData = rootEvidence(root, evidence);
    const kinds = [...rootData.kinds];
    if (words >= 45 && !kinds.includes("text")) kinds.push("text");
    const headings = root.querySelectorAll("h1, h2, h3").length + (/^h[1-3]$/.test(tag) ? 1 : 0);
    const paragraphs = root.querySelectorAll("p").length;
    const images = root.querySelectorAll("img[src]").length;
    const links = root.querySelectorAll("a[href]").length;
    const controls = root.querySelectorAll("button, input, select, textarea").length;
    const boilerplateRoots = root.querySelectorAll("nav, footer, aside, form").length;
    const landmarkWeight = tag === "article" ? 30 : tag === "main" || root.getAttribute("role") === "main" ? 22 : tag === "section" ? 8 : tag === "body" ? -16 : 0;
    const stableHook = semanticHook(root);
    const hookWeight = DETAIL_HOOK.test(stableHook) ? 16 : 0;
    const kindWeight = kinds.reduce((sum, kind) => sum + (WEIGHT[kind] || 1) * 2, 0);
    const readableContent = Math.min(28, words / 8) + Math.min(12, paragraphs * 3) + Math.min(6, images * 2);
    const headingWeight = headings ? 18 + Math.min(8, headings * 2) : -18;
    const density = elements ? words / elements : words;
    const densityWeight = Math.min(12, density * 2);
    const selectorWeight = SINGLETON_KIND_WEIGHT[selectorCandidate.kind] ?? 0;
    const depthWeight = Math.min(14, Math.max(0, elementDepth(root) - 1) * 2);
    const splitWeight = ["split-layout", "header-content-siblings"].includes(rootInfo.reason) ? 50 : 0;
    const linkPenalty = words ? Math.max(0, links / Math.max(words, 1) - 0.15) * 80 : links * 4;
    const boilerplatePenalty = boilerplateRoots * 7 + controls * 1.5 + linkPenalty;
    const tinyPenalty = words < 20 ? 30 : words < 45 ? 12 : 0;
    const score = Math.round((landmarkWeight + hookWeight + kindWeight + readableContent + headingWeight + densityWeight + selectorWeight + depthWeight + splitWeight - boilerplatePenalty - tinyPenalty) * 10) / 10;
    const findings = [
      { kind: headings ? "good" : "warning", message: headings ? `${headings} content heading${headings === 1 ? "" : "s"} occur inside this detail root.` : "This root has no content heading." },
      { kind: words >= 45 ? "good" : "warning", message: `${words} readable words occur inside this candidate.` },
      { kind: boilerplatePenalty < 15 ? "good" : "warning", message: boilerplatePenalty < 15 ? "Little navigation or form boilerplate occurs inside this root." : "Navigation, controls, or link density weaken this detail boundary." }
    ];
    if (["split-layout", "header-content-siblings"].includes(rootInfo.reason)) findings.push({ kind: "good", message: "This root keeps an entity header and substantial sibling content together." });
    return {
      selector: selectorCandidate.selector,
      kind: selectorCandidate.kind,
      tag,
      matchCount: 1,
      parentCount: 1,
      singleton: true,
      reason: rootInfo.reason,
      depth: rootInfo.depth,
      score,
      wordCount: words,
      headingCount: headings,
      evidenceKinds: kinds,
      evidenceCount: rootData.count,
      boilerplatePenalty: Math.round(boilerplatePenalty * 10) / 10,
      findings
    };
  }

  function findSingleton(document, options = {}, providedEvidence = null) {
    const evidence = providedEvidence || evidenceNodes(document, options);
    const roots = singletonRoots(document, evidence, options);
    const evaluated = roots.map((root) => ({ root, candidate: evaluateSingleton(document, root, evidence) })).filter((item) => item.candidate);
    const bySelector = new Map();
    for (const item of evaluated) {
      const current = bySelector.get(item.candidate.selector);
      if (!current || item.candidate.score > current.candidate.score) bySelector.set(item.candidate.selector, item);
    }
    const rankedEntries = Array.from(bySelector.values()).sort((left, right) => right.candidate.score - left.candidate.score || right.candidate.depth - left.candidate.depth);
    let winnerEntry = rankedEntries[0] || null;
    if (options.selectedElement === document.body) winnerEntry = rankedEntries.find((item) => item.root.node === document.body) || winnerEntry;
    const limit = options.candidateLimit ?? 8;
    const ranked = rankedEntries.map((item) => item.candidate).slice(0, limit);
    const winner = winnerEntry?.candidate || null;
    if (winner && !ranked.some((candidate) => candidate.selector === winner.selector)) {
      if (ranked.length >= limit) ranked[ranked.length - 1] = winner;
      else ranked.push(winner);
    }
    const runnerUp = ranked.find((candidate) => candidate.selector !== winner?.selector) || null;
    const margin = winner ? winner.score - (runnerUp?.score || 0) : 0;
    const semanticShape = Boolean(winner && winner.headingCount >= 1 && winner.wordCount >= 45 && winner.evidenceKinds.length >= 2);
    const confidence = !winner ? "none" : winner.score >= 100 && margin >= 12 && semanticShape ? "high" : winner.score >= 75 && semanticShape ? "medium" : "low";
    const candidates = ranked.map((candidate) => {
      if (options.includeObservations === false) return candidate;
      const observed = discovery.discover(document, candidate.selector, { sampleLimit: 1, elementLimit: 500 });
      return { ...candidate, observations: observed.ok ? observed.candidates : [], sampledScopes: observed.ok ? observed.sampledScopes : 0 };
    });
    const chosen = candidates.find((candidate) => candidate.selector === winner?.selector) || null;
    const levels = roots.map((root) => {
      const candidate = evaluated.find((item) => item.root === root)?.candidate || null;
      return { depth: root.depth, tagName: root.node.tagName.toLowerCase(), element: root.node, best: candidate };
    });
    return { ok: true, mode: "single", evidenceCount: evidence.length, confidence, margin: Math.round(margin * 10) / 10, candidates, chosen, levels };
  }

  function readableWordsOutside(root, excludedRoots = []) {
    const document = root?.ownerDocument;
    if (!document?.createTreeWalker) return 0;
    const showText = document.defaultView?.NodeFilter?.SHOW_TEXT || 4;
    const walker = document.createTreeWalker(root, showText);
    let words = 0;
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const parent = node.parentElement;
      if (!parent || excludedRoots.some((excluded) => excluded === parent || excluded.contains(parent))) continue;
      const chrome = parent.closest?.("nav, aside, footer, form, script, style");
      if (chrome && root.contains(chrome)) continue;
      const text = String(node.nodeValue || "").replace(/\s+/g, " ").trim();
      if (text) words += text.split(/\s+/).length;
    }
    return words;
  }

  function find(document, options = {}) {
    const evidence = evidenceNodes(document, options);
    const repeated = findRepeating(document, options, evidence);
    const singleton = findSingleton(document, options, evidence);
    if (repeated.confidence === "high") {
      let repeatedRoots = [];
      try {
        repeatedRoots = repeated.chosen ? Array.from(document.querySelectorAll(repeated.chosen.selector)) : [];
      } catch { /* Invalid selectors have already been excluded by evaluation. */ }
      const secondaryCollection = Number(repeated.chosen?.secondaryContextRatio || 0) >= 0.5;
      const repeatedWords = repeatedRoots.reduce((total, root) => total + readableWordsOutside(root), 0);
      const detailChoices = singleton.candidates.map((candidate) => {
        const explicit = candidate.tag === "article" || ["semantic-hook", "split-layout", "header-content-siblings"].includes(candidate.reason);
        let root = null;
        try { root = document.querySelector(candidate.selector); } catch { /* Already validated. */ }
        const heading = root?.querySelector("h1") || null;
        const headingOutside = Boolean(heading && !repeatedRoots.some((repeatedRoot) => repeatedRoot.contains(heading)));
        const outsideWords = root ? readableWordsOutside(root, repeatedRoots) : 0;
        const primaryShare = outsideWords / Math.max(1, outsideWords + repeatedWords);
        const structurallyPlausible = candidate.score >= 100 && candidate.headingCount >= 1 && candidate.evidenceKinds.length >= 2;
        const dominates = explicit && structurallyPlausible && headingOutside
          && ((secondaryCollection && outsideWords >= 20 && candidate.evidenceKinds.length >= 3)
            || (!secondaryCollection && outsideWords >= 45 && primaryShare >= 0.35));
        return { candidate, outsideWords, primaryShare, dominates };
      }).filter((choice) => choice.dominates)
        .sort((left, right) => right.outsideWords - left.outsideWords || right.candidate.score - left.candidate.score);
      const primary = detailChoices[0] || null;
      if (primary) {
        primary.candidate.findings.push({ kind: "good", message: `${primary.outsideWords} readable words remain in the primary detail after excluding the repeated candidate.` });
        const candidates = [primary.candidate, ...singleton.candidates.filter((candidate) => candidate.selector !== primary.candidate.selector)];
        const margin = Math.max(12, Number(singleton.margin || 0), primary.outsideWords - 30);
        return {
          ...singleton,
          confidence: "high",
          margin: Math.round(margin * 10) / 10,
          candidates,
          chosen: primary.candidate,
          arbitration: { winner: "single", reason: "primary-detail", outsideWords: primary.outsideWords, repeatedWords, primaryShare: Math.round(primary.primaryShare * 100) / 100, secondaryCollection },
          secondaryScopes: repeated.candidates
        };
      }
      return { ...repeated, arbitration: { winner: "collection", reason: "dominant-repeated-content", repeatedWords, secondaryCollection }, detailScopes: singleton.candidates };
    }
    if (singleton.confidence === "high") return singleton;
    if (repeated.chosen) return repeated;
    return { ...singleton, chosen: null };
  }

  return Object.freeze({ evidenceKinds, find, findRepeating, findSingleton });
});
