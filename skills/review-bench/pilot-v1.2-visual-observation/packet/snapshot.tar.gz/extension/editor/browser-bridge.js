"use strict";

// The browser side-panel editor uses this scripting-backed transport to run
// shared extraction operations in the page and frame selected by the picker.
(function initializeBrowserBridge(root) {

  const tabIdParameter = new URLSearchParams(location.search).get("tabId");
  let tabId = tabIdParameter === null ? Number.NaN : Number(tabIdParameter);
  const CORE_FILES = [
    "core/utils.js",
    "core/transforms.js",
    "core/variant-classifier.js",
    "core/dsl.js",
    "editor/selector-candidates.js",
    "editor/fixture-capture.js",
    "editor/scope-inference.js",
    "editor/field-discovery.js",
    "editor/evidence-scope.js",
    "content/page-highlighter.js",
    "content/page-picker.js"
  ];
  const V2_FILES = [
    "content/page-highlighter.js",
    "ir/semantic-dom.js",
    "ir/source-bindings.js",
    "ir/field-observation.js",
    "ir/v2-review-surface.js",
    "ir/normalization.js",
    "ir/type-assignment.js",
    "ir/semantic-assignment.js",
    "ir/validation.js",
    "ir/serialization.js",
    "ir/grouping-inference.js",
    "ir/page-detection.js",
    "ir/pipeline.js"
  ];
  let selectedFrameId = 0;
  let injection = null;
  let v2Injection = null;

  function requireTab() {
    if (!Number.isInteger(tabId) || tabId < 0) throw new Error("This editor was not opened for a browser tab.");
    return tabId;
  }

  async function ensureInjected({ refresh = false } = {}) {
    requireTab();
    if (refresh || !injection) {
      injection = chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: CORE_FILES
      }).catch((error) => {
        injection = null;
        throw error;
      });
    }
    return injection;
  }

  async function run(fn, args, options = {}) {
    await ensureInjected();
    const frameId = Number.isInteger(options.frameId) ? options.frameId : selectedFrameId;
    const results = await chrome.scripting.executeScript({
      target: { tabId: requireTab(), frameIds: [frameId] },
      func: fn,
      args: [args ?? null]
    });
    if (!results?.length) throw new Error("The selected page frame is no longer available.");
    return results[0].result;
  }

  async function ensureV2Injected() {
    requireTab();
    if (!v2Injection) {
      v2Injection = chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: V2_FILES
      }).catch((error) => {
        v2Injection = null;
        throw error;
      });
    }
    return v2Injection;
  }

  async function runV2(fn, args, options = {}) {
    await ensureV2Injected();
    const frameId = Number.isInteger(options.frameId) ? options.frameId : selectedFrameId;
    const results = await chrome.scripting.executeScript({
      target: { tabId: requireTab(), frameIds: [frameId] },
      func: fn,
      args: [args ?? null]
    });
    if (!results?.length) throw new Error("The selected page frame is no longer available.");
    return results[0].result;
  }

  async function startSelection(mode = "scope") {
    await ensureInjected({ refresh: true });
    await chrome.tabs.sendMessage(requireTab(), { type: "site2json-picker:start", mode });
  }

  async function cancelSelection() {
    await chrome.tabs.sendMessage(requireTab(), { type: "site2json-picker:cancel" }).catch(() => {});
  }

  function useSelectionFrame(frameId) {
    selectedFrameId = Number.isInteger(frameId) ? frameId : 0;
  }

  function useTab(nextTabId) {
    const normalized = Number(nextTabId);
    if (!Number.isInteger(normalized) || normalized < 0) return false;
    if (normalized !== tabId) {
      tabId = normalized;
      selectedFrameId = 0;
      injection = null;
      v2Injection = null;
    }
    return true;
  }

  function resetFrame() {
    selectedFrameId = 0;
    injection = null;
    v2Injection = null;
  }

  const bridge = {
    host: "sidepanel",
    run,
    runV2,
    startSelection,
    cancelSelection,
    useTab,
    useSelectionFrame,
    syncSelectionFrame: async () => selectedFrameId,
    resetFrame,
    frameId: () => selectedFrameId
  };
  Object.defineProperty(bridge, "tabId", { enumerable: true, get: () => tabId });
  root.Site2JsonBridge = bridge;
})(globalThis);
