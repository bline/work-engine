"use strict";

(function exposeSidebarWorkflow(root) {
  const ROUTES = Object.freeze(["structure", "semantics", "discover", "review", "finish"]);
  const routeSet = new Set(ROUTES);

  function validRoute(route) {
    return routeSet.has(route);
  }

  function render({ document, navigation, route, workflow }) {
    if (!document?.querySelectorAll) return;
    for (const section of document.querySelectorAll("[data-editor-route]")) {
      section.classList.toggle("route-inactive", section.dataset.editorRoute !== route);
    }
    if (!navigation || !workflow) return;
    for (const button of navigation.querySelectorAll("[data-workflow-step]")) {
      const step = workflow.steps.find((candidate) => candidate.id === button.dataset.workflowStep);
      const selected = button.dataset.workflowStep === route;
      button.className = `${step?.status || "pending"}${selected ? " selected" : ""}`;
      button.disabled = step?.status === "pending";
      button.setAttribute("aria-current", selected ? "step" : "false");
    }
  }

  function bind(navigation, navigate) {
    if (!navigation) return () => {};
    const listener = (event) => {
      const button = event.target.closest("[data-workflow-step]");
      if (button && validRoute(button.dataset.workflowStep)) navigate(button.dataset.workflowStep);
    };
    navigation.addEventListener("click", listener);
    return () => navigation.removeEventListener("click", listener);
  }

  const api = Object.freeze({ ROUTES, bind, render, validRoute });
  root.Site2JsonSidebarWorkflow = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
