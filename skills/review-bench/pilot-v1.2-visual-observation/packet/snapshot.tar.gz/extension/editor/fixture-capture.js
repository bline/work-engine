(function initializeFixtureCapture(root, factory) {
  "use strict";
  const selectors = root.Site2JsonSelectorCandidates || (typeof require === "function" ? require("./selector-candidates") : null);
  const api = factory(selectors);
  root.Site2JsonFixtureCapture = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function fixtureCaptureFactory(selectors) {
  "use strict";

  const FORMAT = "site2json-scrubbed-html-v1";
  const MAX_BYTES = 500_000;
  const MAX_ELEMENTS = 12_000;
  const DROP_TAGS = new Set(["script", "style", "noscript", "template", "iframe", "frame", "object", "embed", "canvas", "svg", "link"]);
  const URL_ATTRIBUTES = new Set(["action", "cite", "data", "formaction", "href", "ping", "poster", "src", "srcset"]);
  const SAFE_VALUE_ATTRIBUTES = new Set(["data-test", "data-testid", "data-test-id", "data-qa", "data-cy", "data-automation-id", "role", "itemprop", "type"]);

  function selectorContract(definition, page) {
    const classes = new Set();
    const attributes = new Set();
    const values = new Map();
    const sources = [];
    for (const block of page.blocks) {
      sources.push(block.scope);
      const entityNames = [block.entity, ...(block.variants?.candidates || []).map((candidate) => candidate.entity)];
      for (const entityName of entityNames) {
        const entity = definition.entities[entityName];
        if (!entity) continue;
        const bindings = entity.identity?.field
          ? Object.values(entity.fields)
          : [entity.identity?.canonicalUrl, ...Object.values(entity.fields)].filter(Boolean);
        for (const binding of bindings) sources.push(...(binding.selectors || []));
      }
      for (const candidate of block.variants?.candidates || []) {
        for (const rule of candidate.evidence) {
          if (rule.selector) sources.push(rule.selector);
          if (rule.attribute && typeof rule.equals === "string") {
            const name = rule.attribute.toLowerCase();
            attributes.add(name);
            if (!values.has(name)) values.set(name, new Set());
            values.get(name).add(rule.equals);
          }
        }
      }
    }
    for (const source of sources) {
      if (typeof source !== "string" || source.startsWith("xpath:")) continue;
      const declaredAttribute = source.match(/@([A-Za-z_][\w:.-]*)$/)?.[1];
      if (declaredAttribute) attributes.add(declaredAttribute.toLowerCase());
      const selector = source.replace(/@[A-Za-z_][\w:.-]*$/, "");
      for (const match of selector.matchAll(/\.(-?(?:\\.|[\w-])+)/g)) classes.add(match[1].replace(/\\(.)/g, "$1"));
      for (const match of selector.matchAll(/\[\s*([A-Za-z_][\w:.-]*)/g)) attributes.add(match[1].toLowerCase());
      for (const match of selector.matchAll(/\[\s*([A-Za-z_][\w:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\]\s]+))\s*\]/g)) {
        const name = match[1].toLowerCase();
        if (!values.has(name)) values.set(name, new Set());
        values.get(name).add(match[2] ?? match[3] ?? match[4]);
      }
      if (/#/.test(selector)) attributes.add("id");
    }
    return { classes, attributes, values };
  }

  function scrubbedClassValue(element, contract) {
    return selectors.stableClassNames(element).filter((name) => contract.classes.has(name)).join(" ");
  }

  function sanitizeAttribute(sourceElement, cloneElement, attribute, contract, indexes) {
    const name = attribute.name.toLowerCase();
    if (name === "class") {
      const value = scrubbedClassValue(sourceElement, contract);
      if (value) cloneElement.setAttribute("class", value);
      else cloneElement.removeAttribute("class");
      return;
    }
    if (name === "id") {
      if (contract.attributes.has("id") && !selectors.looksGenerated(attribute.value)) cloneElement.setAttribute("id", `fixture-id-${++indexes.id}`);
      else cloneElement.removeAttribute(attribute.name);
      return;
    }
    if (name === "style" || name.startsWith("on") || name === "nonce" || name === "integrity" || name === "crossorigin") {
      cloneElement.removeAttribute(attribute.name);
      return;
    }
    if (URL_ATTRIBUTES.has(name)) {
      if (contract.attributes.has(name)) cloneElement.setAttribute(name, "#");
      else cloneElement.removeAttribute(attribute.name);
      return;
    }
    if (contract.values.get(name)?.has(attribute.value)) {
      cloneElement.setAttribute(name, attribute.value);
      return;
    }
    if (!contract.attributes.has(name) && !SAFE_VALUE_ATTRIBUTES.has(name) && !["alt", "aria-hidden", "hidden", "lang", "title"].includes(name)) {
      cloneElement.removeAttribute(attribute.name);
      return;
    }
    if (SAFE_VALUE_ATTRIBUTES.has(name) && attribute.value.length <= 80 && !/[\s@/]/.test(attribute.value)) {
      cloneElement.setAttribute(name, attribute.value);
      return;
    }
    cloneElement.setAttribute(name, attribute.value === "" ? "" : "fixture");
  }

  function capture(document, definition, page) {
    if (!document?.documentElement || !definition || !page) throw new Error("A rendered document and matching adapter page are required.");
    const elementCount = document.querySelectorAll("*").length;
    if (elementCount > MAX_ELEMENTS) throw new Error(`Rendered page has ${elementCount} elements; fixture capture is limited to ${MAX_ELEMENTS}.`);
    const contract = selectorContract(definition, page);
    const clone = document.documentElement.cloneNode(true);
    const sourceElements = [document.documentElement, ...document.documentElement.querySelectorAll("*")];
    const cloneElements = [clone, ...clone.querySelectorAll("*")];
    const indexes = { id: 0 };
    for (let index = cloneElements.length - 1; index >= 0; index -= 1) {
      const sourceElement = sourceElements[index];
      const cloneElement = cloneElements[index];
      if (DROP_TAGS.has(cloneElement.tagName.toLowerCase())) {
        cloneElement.remove();
        continue;
      }
      for (const attribute of [...cloneElement.attributes]) sanitizeAttribute(sourceElement, cloneElement, attribute, contract, indexes);
      if (["input", "option", "textarea"].includes(cloneElement.tagName.toLowerCase())) {
        cloneElement.removeAttribute("checked");
        cloneElement.removeAttribute("selected");
        cloneElement.removeAttribute("value");
      }
    }
    const walker = clone.ownerDocument.createTreeWalker(clone, 128 | 4);
    const removable = [];
    while (walker.nextNode()) removable.push(walker.currentNode);
    for (const node of removable) {
      if (node.nodeType === 8) node.remove();
      else node.textContent = node.parentElement?.tagName.toLowerCase() === "title" ? "Site2JSON scrubbed fixture" : "";
    }
    const html = `<!doctype html>\n${clone.outerHTML.replace(/>\s+</g, "><")}\n`;
    const bytes = new TextEncoder().encode(html).byteLength;
    if (bytes > MAX_BYTES) throw new Error(`Scrubbed fixture is ${bytes} bytes; maximum is ${MAX_BYTES}.`);
    if (/<(?:script|style|iframe|object|embed|svg)\b|\son[a-z]+=|(?:https?:|data:|blob:|javascript:)/i.test(html)) throw new Error("Scrubbed fixture retained forbidden executable or remote content.");
    return { format: FORMAT, html, bytes, elements: elementCount };
  }

  return Object.freeze({ FORMAT, MAX_BYTES, MAX_ELEMENTS, capture, selectorContract });
});
