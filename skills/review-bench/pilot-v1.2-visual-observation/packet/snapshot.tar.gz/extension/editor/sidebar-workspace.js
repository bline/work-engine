"use strict";

(function exposeSidebarWorkspace(root) {
  function create({ document, summarizeEntry, draftForAdapter }) {
    const elements = {
      count: document.querySelector("#library-count"),
      list: document.querySelector("#library-list"),
      empty: document.querySelector("#library-empty"),
      picker: document.querySelector("#draft-picker")
    };

    function button(action, label, className = "secondary", disabled = false) {
      const element = document.createElement("button");
      element.type = "button";
      element.dataset.action = action;
      element.className = className;
      element.textContent = label;
      element.disabled = disabled;
      return element;
    }

    function authoringBadge(editorState) {
      const authoring = editorState?.authoring;
      if (authoring?.origin !== "automatic") return null;
      return `auto · ${authoring.reviewStatus || "unreviewed"}`;
    }

    function renderLibrary(entries, drafts, currentDraftId = null) {
      elements.list.replaceChildren();
      elements.count.textContent = String(entries.length + drafts.length);
      elements.empty.hidden = entries.length + drafts.length > 0;
      for (const entry of entries) {
        const summary = summarizeEntry(entry);
        const draft = draftForAdapter(drafts, entry.id);
        const item = document.createElement("article");
        item.className = "library-item";
        item.dataset.adapterId = entry.id;
        const heading = document.createElement("div");
        heading.className = "library-item-heading";
        const title = document.createElement("strong");
        title.textContent = `${entry.id} v${summary.version}`;
        const badge = document.createElement("small");
        badge.textContent = [draft ? "published · draft available" : "published", authoringBadge(entry.editorState)].filter(Boolean).join(" · ");
        heading.append(title, badge);
        const meta = document.createElement("div");
        meta.className = "library-item-meta";
        meta.textContent = `${summary.hosts.join(", ")} · ${summary.pageTypes.join(", ")}`;
        const actions = document.createElement("div");
        actions.className = "actions";
        const enable = document.createElement("label");
        enable.className = "library-enable";
        const toggle = document.createElement("input");
        toggle.type = "checkbox";
        toggle.checked = entry.enabled;
        toggle.dataset.action = "toggle-adapter";
        enable.append(toggle, document.createTextNode("Enabled"));
        actions.append(enable, button("edit-adapter", draft ? "Resume draft" : "Edit", ""), button("export-adapter", "Export"), button("delete-adapter", "Delete", "secondary", Boolean(draft)));
        item.append(heading, meta, actions);
        elements.list.append(item);
      }
      for (const draft of drafts) {
        const item = document.createElement("article");
        item.className = "library-item";
        item.dataset.draftId = draft.id;
        const heading = document.createElement("div");
        heading.className = "library-item-heading";
        const title = document.createElement("strong");
        title.textContent = draft.adapterId || "New adapter";
        const badge = document.createElement("small");
        badge.textContent = [draft.id === currentDraftId ? "draft · open" : "draft", authoringBadge(draft.editorState)].filter(Boolean).join(" · ");
        heading.append(title, badge);
        const meta = document.createElement("div");
        meta.className = "library-item-meta";
        meta.textContent = `Autosaved ${new Date(draft.updatedAt).toLocaleString()}`;
        const actions = document.createElement("div");
        actions.className = "actions";
        actions.append(button("open-draft", "Resume", ""), button("export-library-draft", "Export YAML", "secondary", !draft.workingDefinition), button("publish-library-draft", "Publish", "secondary", !draft.workingDefinition), button("discard-library-draft", "Discard", "secondary"));
        item.append(heading, meta, actions);
        elements.list.append(item);
      }
    }

    function renderPicker(entries, drafts, selectedId = "") {
      elements.picker.replaceChildren();
      const prompt = document.createElement("option");
      prompt.value = "";
      prompt.textContent = "Choose a stored adapter or draft…";
      elements.picker.append(prompt);
      const createDraft = document.createElement("option");
      createDraft.value = "new";
      createDraft.textContent = "+ New adapter draft";
      elements.picker.append(createDraft);
      if (drafts.length) {
        const group = document.createElement("optgroup");
        group.label = "Autosaved drafts";
        for (const draft of drafts) {
          const option = document.createElement("option");
          option.value = `draft:${draft.id}`;
          option.textContent = `${draft.adapterId || "New adapter"} — ${new Date(draft.updatedAt).toLocaleString()}`;
          group.append(option);
        }
        elements.picker.append(group);
      }
      const editable = entries.filter((entry) => !draftForAdapter(drafts, entry.id));
      if (editable.length) {
        const group = document.createElement("optgroup");
        group.label = "Published adapters (creates a draft copy)";
        for (const entry of editable) {
          const option = document.createElement("option");
          option.value = `published:${entry.id}`;
          option.textContent = `${entry.id} v${entry.definition.version}`;
          group.append(option);
        }
        elements.picker.append(group);
      }
      elements.picker.value = selectedId ? `draft:${selectedId}` : "";
    }

    return Object.freeze({ elements, renderLibrary, renderPicker });
  }

  const api = Object.freeze({ create });
  root.Site2JsonSidebarWorkspace = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
