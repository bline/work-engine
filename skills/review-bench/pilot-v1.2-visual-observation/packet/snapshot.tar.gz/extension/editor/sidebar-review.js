"use strict";

(function exposeSidebarReview(root) {
  function create({ document, onActivate, onPreview, onClearPreview, onPin, onReveal, onEdit, onRemove, onAdd, onCheckDrift, onOpenFinding }) {
    const elements = {
      pickerLabel: document.querySelector("#block-picker-label"),
      picker: document.querySelector("#block-picker"),
      title: document.querySelector("#active-block-title"),
      meta: document.querySelector("#active-block-meta"),
      unresolvedSection: document.querySelector("#unresolved-fields-section"),
      unresolvedSummary: document.querySelector("#unresolved-fields-summary"),
      unresolvedBody: document.querySelector("#unresolved-fields-body"),
      empty: document.querySelector("#block-table-empty"),
      wrap: document.querySelector("#block-table-wrap"),
      head: document.querySelector("#block-table-head"),
      body: document.querySelector("#block-table-body"),
      structuralSection: document.querySelector("#structural-findings-section"),
      structuralSummary: document.querySelector("#structural-findings-summary"),
      structuralList: document.querySelector("#structural-findings-list"),
      structuralCheck: document.querySelector("#check-structural-health-button")
    };

    function wireHighlight(element, target) {
      element.addEventListener("mouseenter", () => onPreview(target));
      element.addEventListener("mouseleave", onClearPreview);
      element.addEventListener("click", (event) => {
        event.stopPropagation();
        onPin(target, element);
        onReveal(target);
      });
    }

    function renderPicker(blocks, activeBlockId) {
      elements.picker.replaceChildren();
      for (const block of blocks) {
        const option = document.createElement("option");
        option.value = block.id;
        const targets = [block, ...(block.variants?.candidates || [])];
        const unresolved = targets.reduce((total, target) => total + (target.fields || []).filter((field) => field.unresolved).length, 0);
        option.textContent = `${block.name} — ${block.schemaType} · ${block.matchCount} matches${unresolved ? ` · ${unresolved} issue${unresolved === 1 ? "" : "s"}` : ""}`;
        option.selected = block.id === activeBlockId;
        elements.picker.append(option);
      }
      elements.pickerLabel.hidden = blocks.length === 0;
    }

    function renderHeading(block, entity = block) {
      elements.title.textContent = block?.name || "";
      const variantCount = block?.variants?.candidates?.length || 0;
      elements.meta.textContent = block ? `${entity.schemaType}${variantCount ? ` · ${entity.entityName === block.entityName ? "fallback" : "variant"}` : ""} · ${entity.matchCount ?? block.matchCount} matches` : "";
    }

    function renderDrift(review, canCheck) {
      if (!elements.structuralSection) return;
      elements.structuralSection.hidden = !canCheck && review?.status === "idle";
      elements.structuralCheck.disabled = !canCheck || review?.status === "checking";
      elements.structuralCheck.textContent = review?.status === "checking" ? "Checking…" : "Check page";
      elements.structuralList.replaceChildren();
      elements.structuralSummary.textContent = review?.message || (canCheck
        ? "Check the rendered page against its saved baseline."
        : "Validate the adapter in Finish to capture a baseline first.");
      for (const finding of review?.findings || []) {
        const row = document.createElement("button");
        row.type = "button";
        row.className = `structural-finding ${finding.severity || "warning"}`;
        const badge = document.createElement("span");
        badge.className = "structural-finding-badge";
        badge.textContent = finding.severity === "error" ? "Error" : finding.severity === "strong-warning" ? "Strong warning" : "Warning";
        const content = document.createElement("span");
        const title = document.createElement("strong");
        title.textContent = finding.title;
        const detail = document.createElement("small");
        detail.textContent = finding.message;
        content.append(title, detail);
        row.append(badge, content);
        row.addEventListener("mouseenter", () => finding.target && onPreview(finding.target));
        row.addEventListener("mouseleave", onClearPreview);
        row.addEventListener("click", () => onOpenFinding(finding));
        elements.structuralList.append(row);
      }
    }

    function tableValue(value) {
      if (value === null || value === undefined || (Array.isArray(value) && value.length === 0)) return { text: "missing", missing: true };
      if (Array.isArray(value)) return { text: value.join(" · "), missing: false };
      if (typeof value === "object") return { text: JSON.stringify(value), missing: false };
      return { text: String(value), missing: false };
    }

    function humanizeToken(value) {
      return String(value || "")
        .split(/__|--/).at(-1)
        .replace(/[_-]+/g, " ")
        .replace(/([a-z])([A-Z])/g, "$1 $2")
        .trim();
    }

    function selectorLabel(selector) {
      const source = String(selector || "");
      const classes = [...source.matchAll(/\.([a-zA-Z_][\w-]*)/g)];
      const classLabel = humanizeToken(classes.at(-1)?.[1]);
      const terminal = source.split(/\s*>\s*|\s+/).filter(Boolean).at(-1) || "";
      const tag = terminal.match(/^([a-zA-Z][\w-]*)/)?.[1] || "";
      const position = terminal.match(/:nth-of-type\((\d+)\)/)?.[1];
      const role = terminal.match(/\[role=["']?([^\]"']+)/)?.[1];
      if (classLabel && position) return `${classLabel} · ${tag} ${position}`;
      if (classLabel) return classLabel;
      if (role) return `${humanizeToken(tag)} · ${humanizeToken(role)}`;
      return humanizeToken(tag) || "Discovered value";
    }

    function unresolvedLabel(field) {
      const suggested = field.evidence?.suggestedName || field.suggestedName;
      if (suggested) return suggested;
      const stored = String(field.name || "")
        .replace(/^_unmapped_/, "")
        .replace(/_\d+$/, "")
        .replace(/([a-z])([A-Z])/g, "$1 $2");
      return /^(field|value|text)$/i.test(stored) ? selectorLabel(field.selector) : stored || selectorLabel(field.selector);
    }

    function unresolvedExample(field, rows) {
      const value = rows.find((row) => row.values[field.name] !== null && row.values[field.name] !== undefined)?.values[field.name]
        ?? field.evidence?.text;
      return tableValue(value).text;
    }

    function localKnowledgeBadge(field) {
      const knowledge = field.corroboration?.localKnowledge;
      if (!knowledge?.sources?.length) return null;
      const badge = document.createElement("small");
      badge.className = `local-knowledge-badge${knowledge.material ? " material" : ""}`;
      badge.textContent = knowledge.acceptedByAuthor ? "local knowledge · reviewed" : "local knowledge influenced";
      const source = knowledge.sources[0];
      const baseline = knowledge.withoutProfile;
      badge.title = [
        `Reusable profile: ${source.termId || source.id || "local property"}${source.revision !== null && source.revision !== undefined ? ` revision ${source.revision}` : ""}`,
        source.profileDigest ? `Snapshot: ${source.profileDigest}` : "",
        baseline ? `Without it: ${baseline.accepted ? baseline.property : "unresolved"}` : "",
        knowledge.material ? "This profile changed the automatic decision and requires author review." : "The same decision was supported without this profile."
      ].filter(Boolean).join("\n");
      return badge;
    }

    function renderUnresolved(block, rows) {
      const fields = block.fields.filter((field) => field.unresolved);
      elements.unresolvedBody.replaceChildren();
      elements.unresolvedSection.hidden = fields.length === 0;
      if (!fields.length) return;
      elements.unresolvedSummary.textContent = `${fields.length} discovered field${fields.length === 1 ? " needs" : "s need"} a semantic decision`;
      for (const field of fields) {
        const tr = document.createElement("tr");
        const name = document.createElement("td");
        const label = document.createElement("strong");
        label.textContent = unresolvedLabel(field);
        const knowledgeBadge = localKnowledgeBadge(field);
        const selector = document.createElement("code");
        selector.textContent = field.selector;
        name.append(label, ...(knowledgeBadge ? [knowledgeBadge] : []), selector);
        const example = document.createElement("td");
        example.textContent = unresolvedExample(field, rows);
        example.title = example.textContent;
        const actions = document.createElement("td");
        actions.className = "unresolved-field-actions";
        const map = document.createElement("button");
        map.type = "button";
        map.className = "compact";
        map.textContent = "Map";
        map.addEventListener("click", () => onEdit(field));
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "secondary compact danger";
        remove.textContent = "Delete";
        remove.addEventListener("click", () => onRemove(field));
        actions.append(map, remove);
        tr.append(name, example, actions);
        wireHighlight(name, { withinSelector: block.scope, selector: field.selector });
        wireHighlight(example, { withinSelector: block.scope, selector: field.selector });
        elements.unresolvedBody.append(tr);
      }
    }

    function fieldRowHeader(block, field) {
      const th = document.createElement("th");
      th.scope = "row";
      th.classList.add("field-row-header");
      th.classList.toggle("unresolved-column", Boolean(field.unresolved));
      th.classList.toggle("identity-column", Boolean(field.identity));
      th.title = `${field.selector}${field.unresolved ? " — Unmapped: review before publishing" : ""}`;
      const content = document.createElement("span");
      content.className = "field-column-header";
      const label = document.createElement("span");
      label.className = "field-column-label";
      label.textContent = field.name;
      if (field.identity) {
        label.title = "Canonical identity field";
        label.setAttribute("aria-label", `${field.name}, canonical identity field`);
        const badge = document.createElement("small");
        badge.className = "identity-field-badge";
        badge.textContent = "identity";
        label.append(" ", badge);
      }
      const knowledgeBadge = localKnowledgeBadge(field);
      if (knowledgeBadge) label.append(" ", knowledgeBadge);
      const actions = document.createElement("span");
      actions.className = "field-column-actions";
      const edit = document.createElement("button");
      edit.type = "button";
      edit.className = "field-column-action edit";
      edit.textContent = "✎";
      edit.title = `Edit ${field.name}${field.identity ? " identity field" : ""}`;
      edit.setAttribute("aria-label", edit.title);
      edit.addEventListener("click", (event) => { event.stopPropagation(); onEdit(field); });
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "field-column-action remove";
      remove.textContent = "🗑";
      remove.title = `Remove ${field.name}${field.identity ? " identity field" : ""}`;
      remove.setAttribute("aria-label", remove.title);
      remove.addEventListener("click", (event) => { event.stopPropagation(); onRemove(field); });
      actions.append(edit, remove);
      content.append(label, actions);
      th.append(content);
      wireHighlight(th, { withinSelector: block.scope, selector: field.selector });
      return th;
    }

    function renderTable(block, rows) {
      elements.head.replaceChildren();
      elements.body.replaceChildren();
      renderUnresolved(block, rows);
      if (!rows.length) {
        elements.wrap.hidden = true;
        elements.empty.textContent = "This scope currently matches no rendered items.";
        return;
      }
      elements.empty.textContent = "";
      elements.wrap.hidden = false;
      const fields = block.fields.filter((field) => !field.unresolved).map((field) => ({
        ...field,
        identity: Boolean(field.identity || (block.identityField && field.name === block.identityField))
      }));
      if (block.identity && !fields.some((field) => field.name === (block.identity.name === "canonicalUrl" ? "url" : block.identity.name))) {
        fields.unshift({ ...block.identity, name: "url", identity: true });
      }
      const headRow = document.createElement("tr");
      const fieldHead = document.createElement("th");
      fieldHead.className = "field-axis-header";
      fieldHead.scope = "col";
      const fieldHeadContent = document.createElement("span");
      fieldHeadContent.className = "field-axis-header-content";
      const fieldLabel = document.createElement("span");
      fieldLabel.textContent = "Field";
      const add = document.createElement("button");
      add.type = "button";
      add.className = "add-field-column-button";
      add.textContent = "+";
      add.title = "Add the selected element as a field";
      add.setAttribute("aria-label", add.title);
      add.addEventListener("click", (event) => { event.stopPropagation(); onAdd(); });
      fieldHeadContent.append(fieldLabel, add);
      fieldHead.append(fieldHeadContent);
      headRow.append(fieldHead);
      for (const row of rows) {
        const itemHead = document.createElement("th");
        itemHead.scope = "col";
        itemHead.className = "item-column-header";
        const number = document.createElement("span");
        number.textContent = String(row.index + 1);
        itemHead.append(number);
        if (row.variant?.winner) {
          const type = document.createElement("small");
          type.textContent = row.variant.ambiguous ? "Ambiguous" : row.variant.winner.schemaType;
          itemHead.classList.toggle("variant-ambiguous", Boolean(row.variant.ambiguous));
          itemHead.append(type);
        }
        itemHead.title = row.variant?.winner
          ? `Matched item ${row.index + 1} · ${row.variant.winner.schemaType}${row.variant.ambiguous ? " (classification is ambiguous)" : ""}`
          : `Matched item ${row.index + 1}`;
        wireHighlight(itemHead, { selector: block.scope, matchIndex: row.index });
        headRow.append(itemHead);
      }
      elements.head.append(headRow);
      for (const field of fields) {
        const tr = document.createElement("tr");
        tr.append(fieldRowHeader(block, field));
        for (const row of rows) {
          const cell = document.createElement("td");
          const rendered = tableValue(row.values[field.name]);
          cell.textContent = rendered.text;
          cell.title = rendered.text;
          if (rendered.missing) cell.classList.add("missing");
          if (field.unresolved) cell.classList.add("unresolved-column");
          wireHighlight(cell, { withinSelector: block.scope, rootIndex: row.index, selector: field.selector });
          tr.append(cell);
        }
        elements.body.append(tr);
      }
    }

    elements.picker.addEventListener("change", () => onActivate(elements.picker.value));
    elements.structuralCheck?.addEventListener("click", onCheckDrift);
    return Object.freeze({ elements, renderDrift, renderHeading, renderPicker, renderTable });
  }

  const api = Object.freeze({ create });
  root.Site2JsonSidebarReview = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
