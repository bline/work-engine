(function initializeTransformPicker(root, factory) {
  "use strict";
  const catalog = root.Site2JsonTransformCatalog || (typeof require === "function" ? require("./transform-catalog") : null);
  const api = factory(catalog);
  root.Site2JsonTransformPicker = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function transformPickerFactory(catalog) {
  "use strict";

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function pipeline(value) {
    return Array.isArray(value) ? clone(value) : [];
  }

  function stepName(step) {
    return typeof step === "string" ? step : step?.name || "invalid transform";
  }

  function isLocked(step) {
    const detail = catalog.details(stepName(step));
    return Boolean(!detail || detail.argumentDefinitions?.length !== detail.maximumArguments);
  }

  function formatStep(step) {
    const name = stepName(step);
    if (!step || typeof step !== "object" || !Array.isArray(step.args) || !step.args.length) return name;
    return `${name}(${step.args.map((argument) => JSON.stringify(argument)).join(", ")})`;
  }

  function addZeroArgument(value, name) {
    const detail = catalog.details(name);
    if (!detail || detail.minimumArguments !== 0 || detail.maximumArguments !== 0) {
      throw new Error(`${name} is not an available zero-argument transform.`);
    }
    return [...pipeline(value), name];
  }

  function editable(name) {
    const detail = catalog.details(name);
    return Boolean(detail && detail.argumentDefinitions?.length === detail.maximumArguments);
  }

  function parseArgument(raw, definition, required) {
    const blank = raw === undefined || raw === null || String(raw).trim() === "";
    if (blank && !required) return { omitted: true };
    if (definition.type === "string") {
      const value = String(raw ?? "");
      if (definition.allowEmpty === false && !value.length) throw new Error(`${definition.label} cannot be empty.`);
      if (definition.maximumLength !== undefined && value.length > definition.maximumLength) throw new Error(`${definition.label} must be at most ${definition.maximumLength} characters.`);
      return { value };
    }
    if (definition.type === "integer") {
      if (!/^-?\d+$/.test(String(raw ?? "").trim())) throw new Error(`${definition.label} must be a whole number.`);
      const value = Number(raw);
      if (!Number.isSafeInteger(value)) throw new Error(`${definition.label} must be a safe integer.`);
      if (definition.minimum !== undefined && value < definition.minimum) throw new Error(`${definition.label} must be at least ${definition.minimum}.`);
      if (definition.maximum !== undefined && value > definition.maximum) throw new Error(`${definition.label} must be at most ${definition.maximum}.`);
      return { value };
    }
    if (definition.type === "string-list") {
      const value = String(raw ?? "").split(/\r?\n/).map((item) => item.trim()).filter(Boolean);
      if (value.length < (definition.minimumItems || 0)) throw new Error(`${definition.label} requires at least ${definition.minimumItems} value${definition.minimumItems === 1 ? "" : "s"}.`);
      return { value };
    }
    if (definition.type === "object") {
      let value;
      try { value = JSON.parse(String(raw ?? "")); } catch { throw new Error(`${definition.label} must be a valid JSON object.`); }
      if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`${definition.label} must be a JSON object.`);
      return { value };
    }
    throw new Error(`${definition.label} has an unsupported editor type.`);
  }

  function parseArguments(name, rawValues) {
    const detail = catalog.details(name);
    if (!editable(name)) throw new Error(`${name} does not have editable packaged arguments.`);
    const args = [];
    for (let index = 0; index < detail.argumentDefinitions.length; index += 1) {
      const definition = detail.argumentDefinitions[index];
      const required = index < detail.minimumArguments && definition.required !== false;
      const parsed = parseArgument(rawValues[index], definition, required);
      if (parsed.omitted) break;
      args.push(parsed.value);
    }
    const step = args.length ? { name, args } : name;
    const validation = catalog.validateStep(step);
    if (!validation.ok) throw new Error(validation.message);
    return step;
  }

  function setAt(value, index, step) {
    const next = pipeline(value);
    if (!Number.isSafeInteger(index) || index < 0 || index > next.length) throw new Error("Transform position is invalid.");
    if (index === next.length) next.push(clone(step));
    else next[index] = clone(step);
    return next;
  }

  function argumentValues(step) {
    const detail = catalog.details(stepName(step));
    const args = step && typeof step === "object" && Array.isArray(step.args) ? step.args : [];
    return (detail?.argumentDefinitions || []).map((definition, index) => {
      const value = args[index];
      if (value === undefined) return "";
      if (definition.type === "string-list") return value.join("\n");
      if (definition.type === "object") return JSON.stringify(value, null, 2);
      return String(value);
    });
  }

  function removeAt(value, index) {
    const next = pipeline(value);
    if (!Number.isSafeInteger(index) || index < 0 || index >= next.length || isLocked(next[index])) return { pipeline: next, removed: false };
    next.splice(index, 1);
    return { pipeline: next, removed: true };
  }

  return Object.freeze({ addZeroArgument, argumentValues, clonePipeline: pipeline, editable, formatStep, isLocked, parseArguments, removeAt, setAt, stepName });
});
