(function initializeSemanticRanking(root, factory) {
  "use strict";
  const vocabulary = root.Site2JsonSchemaVocabulary || (typeof require === "function" ? require("./schema-vocabulary") : null);
  const compositions = root.Site2JsonSemanticCompositions || (typeof require === "function" ? require("./semantic-compositions") : null);
  const api = factory(vocabulary, compositions);
  root.Site2JsonSemanticRanking = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticRankingFactory(vocabulary, compositions) {
  "use strict";

  const DATE = /\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:\s*,)?\s+\d{4}\b/i;
  const MONEY = /(?:[$€£]|\b(?:usd|eur|gbp|cad|aud)\b)\s*\d|\d\s*(?:[$€£]|\b(?:usd|eur|gbp|cad|aud)\b)/i;
  const PERCENT = /\d+(?:\.\d+)?\s*%/;
  const STOP = new Set([
    "about", "action", "actions", "all", "and", "any", "are", "body", "box", "but", "can", "card", "content", "data", "detail", "details", "each", "field", "for", "from", "had", "has", "have", "header", "identity", "info", "into", "item", "its", "job", "label", "may", "meta", "module", "not", "one", "our", "record", "result", "row", "that", "the", "their", "this", "text", "through", "value", "view", "was", "were", "with", "your",
    // Selector grammar and ordinary element names are structural syntax, not
    // vocabulary evidence. In particular, `nth-of-type` must not become
    // evidence for Schema.org's inherited `additionalType` property.
    "after", "before", "child", "class", "first", "last", "not", "nth", "type",
    "anchor", "button", "div", "heading", "image", "link", "list", "span", "strong", "sub"
  ]);
  const EXPECTATION_WEIGHT = Object.freeze({ core: 1, common: 0.92, optional: 0.78 });
  const termCache = new Map();
  const typeDepthCache = new Map();

  function words(value) {
    return String(value || "").replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase()
      .split(/[^a-z0-9]+/).filter((word) => word.length > 2 && !STOP.has(word) && !/^\d+$/.test(word));
  }

  function observation(candidate, index) {
    const evidence = candidate?.evidence || {};
    const text = String(evidence.text || evidence.value || candidate?.sampleValues?.find(Boolean) || "");
    const directTokens = [...new Set([
      ...words(candidate?.suggestedName), ...words(candidate?.selector), ...words(evidence.id),
      ...words((evidence.classes || []).join(" "))
    ])];
    const contextTokens = [...new Set(words(evidence.context).filter((token) => !directTokens.includes(token)))];
    const labelTokens = text.length <= 100 && words(text).length <= 12 ? [...new Set(words(text))] : [];
    const shapes = [];
    if (candidate?.kind === "url" || evidence.href || evidence.src) shapes.push("URL");
    if (DATE.test(text) || evidence.attribute === "datetime") shapes.push("date");
    if (MONEY.test(text)) shapes.push("money");
    if (PERCENT.test(text)) shapes.push("percentage");
    if (/^h[1-6]$/.test(evidence.tag || "")) shapes.push("heading");
    if (evidence.tag === "img") shapes.push("image");
    if (candidate?.multiple) shapes.push("repeated");
    return {
      id: index,
      selector: candidate?.selector || "",
      directTokens,
      contextTokens,
      labelTokens,
      shapes,
      multiple: Boolean(candidate?.multiple),
      coverage: candidate?.coverage || null
    };
  }

  function propertyMatch(term, observed) {
    let compiled = termCache.get(term.name);
    if (!compiled) {
      compiled = { propertyWords: new Set(words(term.name)), ranges: new Set(term.ranges || []) };
      termCache.set(term.name, compiled);
    }
    const { propertyWords, ranges } = compiled;
    const directOverlaps = observed.directTokens.filter((token) => propertyWords.has(token));
    const contextOverlaps = observed.contextTokens.filter((token) => propertyWords.has(token));
    let score = Math.min(12, directOverlaps.length * 6) + Math.min(3, contextOverlaps.length * 1.5);
    const reasons = [
      ...directOverlaps.map((token) => `direct DOM token “${token}” matches ${term.name}`),
      ...contextOverlaps.map((token) => `ancestor token “${token}” weakly supports ${term.name}`)
    ];
    // Shapes constrain a meaning; they do not establish it. A date-shaped
    // value is compatible with hundreds of date properties, and money is
    // compatible with many numeric properties. Keep those contributions below
    // the explanation threshold unless semantic DOM evidence also agrees.
    if (observed.shapes.includes("URL") && ranges.has("URL")) { score += 2; reasons.push("URL value shape is compatible"); }
    if (observed.shapes.includes("URL") && term.name === "url" && !observed.multiple) { score += 6; reasons.push("single link attribute fits url"); }
    if (observed.shapes.includes("date") && (ranges.has("Date") || ranges.has("DateTime"))) { score += 2; reasons.push("date value shape is compatible"); }
    if (observed.shapes.includes("money") && ["MonetaryAmount", "PriceSpecification", "Number"].some((range) => ranges.has(range))) { score += 2; reasons.push("money value shape is compatible"); }
    if (observed.shapes.includes("percentage") && (ranges.has("Number") || ranges.has("Float"))) { score += 2; reasons.push("percentage can map to a numeric property"); }
    if (observed.shapes.includes("heading") && ["title", "headline", "name"].includes(term.name)) { score += 4; reasons.push("heading structure fits a title or name"); }
    if (observed.shapes.includes("image") && term.name === "image") { score += 6; reasons.push("image source fits image"); }
    if (observed.multiple && term.cardinality === "many") { score += 2; reasons.push("repeated values fit a collection property"); }
    if (observed.multiple && term.cardinality !== "many") { score -= 4; reasons.push("repeated values conflict with a scalar-looking property"); }
    return { score, reasons };
  }

  function scoreNode(alias, node, observed, priorityNames = []) {
    let best = null;
    for (const type of node.inferenceTypes || node.types || []) {
      for (const term of vocabulary.propertiesFor(type)) {
        const match = propertyMatch(term, observed);
        const priority = priorityNames.includes(term.name) ? 1.5 : 0;
        const rankedScore = match.score + priority;
        if (!best || rankedScore > best.score) best = { ...match, score: rankedScore, alias, type, property: term.name };
      }
    }
    for (const term of node.inferenceProperties || []) {
      const match = propertyMatch(term, observed);
      const priority = priorityNames.includes(term.name) ? 1.5 : 0;
      const rankedScore = match.score + priority;
      if (!best || rankedScore > best.score) best = {
        ...match,
        score: rankedScore,
        alias,
        type: node.types?.[0],
        property: term.name
      };
    }
    return best || { score: 0, reasons: [], alias, type: node.types?.[0], property: null };
  }

  function tokenMatches(left, right) {
    return left === right || (left.length > 3 && `${left}s` === right) || (right.length > 3 && `${right}s` === left);
  }

  function nodeAffinity(alias, node, observed, priorityNames = []) {
    const hints = [...new Set(words([alias, ...(node.types || []), node.description || "", ...(node.evidenceKeywords || []), ...priorityNames].join(" ")))];
    const matches = (tokens) => tokens.filter((token) => hints.some((hint) => tokenMatches(token, hint)));
    const direct = matches(observed.directTokens);
    const labels = matches(observed.labelTokens);
    const context = matches(observed.contextTokens);
    const score = Math.min(6, direct.length * 3) + Math.min(6, labels.length * 3) + Math.min(1.5, context.length * 0.5);
    return {
      score,
      reasons: [
        ...direct.slice(0, 2).map((token) => `direct token “${token}” supports ${alias}`),
        ...labels.slice(0, 2).map((token) => `rendered label “${token}” supports ${alias}`),
        ...context.slice(0, 1).map((token) => `ancestor context “${token}” weakly supports ${alias}`)
      ]
    };
  }

  function rootTypeAffinity(composition, observations) {
    const root = composition.nodes?.[composition.root];
    const typeTokens = new Set([
      ...(root?.types || []),
      ...(root?.inferenceTypeNames || []),
      ...(root?.evidenceKeywords || [])
    ].flatMap(words));
    if (!typeTokens.size) return { score: 0, evidence: null };
    let best = null;
    for (const observed of observations) {
      const matches = observed.directTokens.filter((token) => typeTokens.has(token));
      if (!matches.length) continue;
      const candidate = {
        score: Math.min(12, matches.length * 10),
        evidence: {
          observation: observed.selector || `observation ${observed.id + 1}`,
          path: composition.root,
          reasons: matches.slice(0, 2).map((token) => `direct DOM token “${token}” names the item type`)
        }
      };
      if (!best || candidate.score > best.score) best = candidate;
    }
    return best || { score: 0, evidence: null };
  }

  function scoreComposition(composition, observations, { details = false } = {}) {
    const mappings = observations.map((observed) => {
      let best = null;
      for (const [alias, node] of Object.entries(composition.nodes || {})) {
        const candidate = scoreNode(alias, node, observed, composition.priorities?.[alias] || []);
        candidate.weightedScore = candidate.score * (EXPECTATION_WEIGHT[node.expectation] || 0.7);
        if (!best || candidate.weightedScore > best.weightedScore) best = candidate;
      }
      return { observation: observed, ...(best || { score: 0, weightedScore: 0, reasons: [] }) };
    });
    const explained = mappings.filter((mapping) => mapping.weightedScore >= 6);
    const rawScore = explained.reduce((sum, mapping) => sum + Math.min(20, mapping.weightedScore), 0);
    const relatedNodeEvidence = Object.entries(composition.nodes || {}).filter(([alias]) => alias !== composition.root).map(([alias, node]) => {
      let best = { score: 0, reasons: [], observation: null };
      for (const observed of observations) {
        const affinity = nodeAffinity(alias, node, observed, composition.priorities?.[alias] || []);
        if (affinity.score > best.score) best = { ...affinity, observation: observed };
      }
      return { alias, types: [...(node.types || [])], ...best };
    });
    const supportedNodes = relatedNodeEvidence.filter((item) => item.score >= 3);
    const relationshipEvidence = supportedNodes.reduce((sum, item) => sum + Math.min(8, item.score), 0);
    // Explicit page hooks such as data-type="Person", itemtype, or a stable
    // `.person-card` class are type evidence rather than extracted fields.
    // Scoring the root token lets mixed-result detection use those invisible
    // markers without requiring the marker to become output data.
    const rootTypeEvidence = rootTypeAffinity(composition, observations);
    const score = Math.max(0, rawScore + relationshipEvidence + rootTypeEvidence.score);
    const strongest = [...explained].sort((left, right) => right.weightedScore - left.weightedScore).slice(0, 4).map((mapping) => ({
      observation: mapping.observation.selector || `observation ${mapping.observation.id + 1}`,
      path: `${mapping.alias}.${mapping.property}`,
      reasons: mapping.reasons.slice(0, 2)
    }));
    const conceptEvidence = supportedNodes.slice(0, 3).map((item) => ({
      observation: item.observation?.selector || item.alias,
      path: item.alias,
      reasons: item.reasons.slice(0, 2)
    }));
    return {
      id: composition.id,
      label: composition.label,
      kind: composition.kind,
      schemaType: composition.schemaType || composition.nodes?.[composition.root]?.types?.[0] || "Thing",
      ...(composition.librarySourceCount ? { librarySourceCount: composition.librarySourceCount } : {}),
      score: Math.round(score * 10) / 10,
      explained: explained.length,
      total: observations.length,
      unexplained: observations.length - explained.length,
      supportedNodes: supportedNodes.map((item) => ({ alias: item.alias, types: item.types, score: item.score })),
      evidence: [
        ...(rootTypeEvidence.evidence ? [rootTypeEvidence.evidence] : []),
        ...strongest.slice(0, Math.max(1, 4 - conceptEvidence.length - (rootTypeEvidence.evidence ? 1 : 0))),
        ...conceptEvidence
      ],
      ...(details ? { mappings: mappings.map((mapping) => ({ selector: mapping.observation.selector, path: mapping.property ? `${mapping.alias}.${mapping.property}` : null, score: mapping.weightedScore, reasons: mapping.reasons })) } : {})
    };
  }

  function rank(candidates, { typeLimit = 12, allowedTypes = null, additionalCompositions = [] } = {}) {
    const observations = (candidates || []).map(observation);
    const additionalResults = (additionalCompositions || []).map((composition) => scoreComposition(composition, observations));
    const compositionResults = [
      ...compositions.packaged().map((composition) => scoreComposition(composition, observations)),
      ...additionalResults.filter((result) => result.kind !== "library-type")
    ]
      .sort((left, right) => right.score - left.score || right.explained - left.explained || left.label.localeCompare(right.label));
    function typeDepth(type, seen = new Set()) {
      if (seen.size === 0 && typeDepthCache.has(type)) return typeDepthCache.get(type);
      if (!type || seen.has(type)) return 0;
      seen.add(type);
      const parents = vocabulary.typeInfo(type)?.supers || [];
      const depth = parents.length ? 1 + Math.max(...parents.map((parent) => typeDepth(parent, new Set(seen)))) : 0;
      if (seen.size === 1) typeDepthCache.set(type, depth);
      return depth;
    }
    const seenEvidence = new Set();
    const typeNames = Array.isArray(allowedTypes) && allowedTypes.length
      ? [...new Set(allowedTypes)].filter((type) => vocabulary.typeInfo(type))
      : vocabulary.typeNames();
    const schemaTypeResults = typeNames.map((type) => ({ ...scoreComposition(compositions.singleType(type), observations), typeDepth: typeDepth(type) }))
      .filter((result) => result.score > 0)
      .sort((left, right) => right.score - left.score || right.explained - left.explained || left.typeDepth - right.typeDepth || left.label.localeCompare(right.label))
      .filter((result) => {
        const signature = `${result.score}\u001f${result.explained}\u001f${result.evidence.map((item) => `${item.observation}:${item.path}`).join("|")}`;
        if (seenEvidence.has(signature)) return false;
        seenEvidence.add(signature);
        return true;
      })
      .slice(0, typeLimit)
      .map(({ typeDepth: _typeDepth, ...result }) => result);
    const typeResults = [...schemaTypeResults, ...additionalResults.filter((result) => result.kind === "library-type" && result.score > 0)]
      .sort((left, right) => right.score - left.score || right.explained - left.explained || left.label.localeCompare(right.label))
      .slice(0, typeLimit);
    return {
      observationCount: observations.length,
      shapeSummary: Object.fromEntries([...new Set(observations.flatMap((item) => item.shapes))].sort().map((shape) => [shape, observations.filter((item) => item.shapes.includes(shape)).length])),
      compositions: compositionResults,
      types: typeResults
    };
  }

  function explain(candidates, composition) {
    return scoreComposition(composition, (candidates || []).map(observation), { details: true });
  }

  return Object.freeze({ explain, rank, scoreComposition });
});
