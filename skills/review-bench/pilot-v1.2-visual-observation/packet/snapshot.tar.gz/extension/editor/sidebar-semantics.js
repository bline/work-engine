"use strict";

(function exposeSidebarSemantics(root) {
  function create({
    document, compositions, getBlock, onApply, onAnalyze, onConfirm,
    onAddNode, onAddEdge, onRemoveEdge, onRemoveNode, onAddType, onRemoveType,
    getAdapterPrefix = () => "", getCustomTerms = () => ({})
  }) {
    const elements = {
      context: document.querySelector("#semantics-context"),
      input: document.querySelector("#semantic-model-input"),
      analyze: document.querySelector("#analyze-semantics-button"),
      confirm: document.querySelector("#confirm-semantics-button"),
      status: document.querySelector("#semantic-model-status"),
      selectionView: document.querySelector("#semantic-selection-view"),
      overview: document.querySelector("#semantic-overview"),
      overviewTitle: document.querySelector("#semantic-overview-title"),
      overviewCounts: document.querySelector("#semantic-overview-counts"),
      overviewPreview: document.querySelector("#semantic-overview-preview"),
      openAdvanced: document.querySelector("#open-semantic-advanced"),
      closeAdvanced: document.querySelector("#close-semantic-advanced"),
      advancedView: document.querySelector("#semantic-advanced-view"),
      structureHeading: document.querySelector("#semantic-structure-heading"),
      summary: document.querySelector("#semantic-model-summary"),
      menu: document.querySelector("#semantic-ranking-summary"),
      allTypes: document.querySelector("#semantic-all-types"),
      nodeCount: document.querySelector("#semantic-node-count"),
      nodeList: document.querySelector("#semantic-node-list"),
      edgeCount: document.querySelector("#semantic-edge-count"),
      edgeList: document.querySelector("#semantic-edge-list"),
      addRelationship: document.querySelector("#semantic-add-relationship"),
      relationFrom: document.querySelector("#semantic-relation-from"),
      relationProperty: document.querySelector("#semantic-relation-property"),
      relationTarget: document.querySelector("#semantic-relation-target"),
      relationType: document.querySelector("#semantic-relation-type"),
      relationTypes: document.querySelector("#semantic-relation-types"),
      relationAlias: document.querySelector("#semantic-relation-alias"),
      relationExpectation: document.querySelector("#semantic-relation-expectation"),
      customRelationship: document.querySelector("#semantic-custom-relationship"),
      customPrefix: document.querySelector("#semantic-custom-prefix"),
      customTerm: document.querySelector("#semantic-custom-term"),
      customDescription: document.querySelector("#semantic-custom-description"),
      customAliases: document.querySelector("#semantic-custom-aliases"),
      relationAdd: document.querySelector("#semantic-add-relationship-button"),
      relationStatus: document.querySelector("#semantic-relationship-status")
    };
    let cachedChoices = null;
    let menuIndex = -1;
    let advancedOpen = false;

    function setStatus(kind, message) {
      elements.status.textContent = message;
      elements.status.className = `status ${kind || ""}`.trim();
    }

    function allChoices() {
      if (!compositions) return [];
      if (cachedChoices) return cachedChoices;
      const packaged = compositions.packaged().map((item) => ({
        id: item.id, label: item.label, kind: "Composition", description: item.description
      }));
      const types = compositions.typeNames().map((type) => {
        const model = compositions.singleType(type);
        return { id: model.id, label: model.label, kind: "Schema.org type", description: model.description };
      });
      cachedChoices = [...packaged, ...types];
      return cachedChoices;
    }

    function populateAllTypes() {
      if (elements.allTypes.childElementCount || !compositions) return;
      const fragment = document.createDocumentFragment();
      for (const type of compositions.typeNames()) {
        const option = document.createElement("option");
        option.value = type;
        fragment.append(option);
      }
      elements.allTypes.append(fragment);
    }

    function choice(value) {
      const query = String(value || "").trim().toLowerCase();
      if (!query) return null;
      return allChoices().find((candidate) => candidate.id.toLowerCase() === query || candidate.label.toLowerCase() === query) || null;
    }

    function choiceById(id) {
      return allChoices().find((candidate) => candidate.id === id) || null;
    }

    function rankedChoices(block) {
      const ranking = block?.semanticRanking;
      if (!ranking || ranking.status === "loading") return [];
      return [...(ranking.compositions || []), ...(ranking.types || [])]
        .filter((candidate) => candidate.score > 0)
        .sort((left, right) => right.score - left.score || right.explained - left.explained)
        .slice(0, 6)
        .map((candidate) => ({
          ...(choiceById(candidate.id) || {
            id: candidate.id,
            label: candidate.label,
            kind: candidate.kind === "library-pattern" ? "Semantic Library graph"
              : candidate.kind === "library-type" ? "Semantic Library type"
                : candidate.kind === "composition" ? "Composition" : "Schema.org type",
            description: ""
          }),
          ranking: candidate
        }));
    }

    function filteredChoices(query) {
      const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
      return allChoices()
        .filter((candidate) => {
          const haystack = `${candidate.label} ${candidate.id} ${candidate.kind} ${candidate.description}`.toLowerCase();
          return terms.every((term) => haystack.includes(term));
        })
        .sort((left, right) => {
          const leftStarts = left.label.toLowerCase().startsWith(query.toLowerCase()) ? 0 : 1;
          const rightStarts = right.label.toLowerCase().startsWith(query.toLowerCase()) ? 0 : 1;
          return leftStarts - rightStarts || left.label.localeCompare(right.label);
        })
        .slice(0, 30)
        .map((candidate) => ({ ...candidate, ranking: null }));
    }

    function menuChoices(block) {
      const query = elements.input.value.trim();
      if (query) return { label: "Matching models", rows: filteredChoices(query) };
      const rows = rankedChoices(block);
      const currentId = block?.composition?.id;
      if (currentId && !rows.some((row) => row.id === currentId)) {
        const current = choiceById(currentId);
        if (current) rows.unshift({ ...current, ranking: null });
      }
      return { label: rows.some((row) => row.ranking) ? "Suggested for this page" : "Current model · type to search all models", rows };
    }

    function renderMenu(block) {
      elements.menu.replaceChildren();
      menuIndex = -1;
      const choices = menuChoices(block);
      const context = document.createElement("div");
      context.className = "semantic-model-menu-context";
      context.textContent = choices.label;
      context.setAttribute("role", "presentation");
      elements.menu.append(context);
      if (!choices.rows.length) {
        const empty = document.createElement("div");
        empty.className = "semantic-model-empty";
        empty.textContent = elements.input.value.trim() ? "No models match this search." : "No supported suggestions were found. Type to search all models.";
        elements.menu.append(empty);
        return;
      }
      for (const [index, candidate] of choices.rows.entries()) {
        const selected = candidate.id === block?.composition?.id;
        const button = document.createElement("button");
        button.type = "button";
        button.id = `semantic-model-option-${index}`;
        button.className = `semantic-model-option${selected ? " selected" : ""}`;
        button.dataset.modelId = candidate.id;
        button.setAttribute("role", "option");
        button.setAttribute("aria-selected", String(selected));
        const check = document.createElement("span");
        check.className = "semantic-model-check";
        check.textContent = selected ? "✓" : "";
        const name = document.createElement("strong");
        name.textContent = candidate.label;
        const detail = document.createElement("small");
        detail.textContent = candidate.ranking
          ? `${selected ? "Selected · " : "Suggested · "}${candidate.kind} · explains ${candidate.ranking.explained}/${candidate.ranking.total}`
          : `${selected ? "Selected · " : ""}${candidate.kind} · ${candidate.description}`;
        button.append(check, name, detail);
        button.addEventListener("click", () => selectModel(candidate));
        elements.menu.append(button);
      }
    }

    function suggestedAlias(type, nodes) {
      const base = String(type || "node").replace(/^[^A-Za-z]+/, "");
      const initial = base ? base[0].toLowerCase() + base.slice(1) : "node";
      if (!nodes[initial]) return initial;
      let suffix = 2;
      while (nodes[`${initial}${suffix}`]) suffix += 1;
      return `${initial}${suffix}`;
    }

    function nodeEntries(composition) {
      return Object.entries(composition?.nodes || {}).sort(([left], [right]) => (
        (left === composition.root ? -1 : 0) - (right === composition.root ? -1 : 0)
        || left.localeCompare(right)
      ));
    }

    function relationOptions(block) {
      const source = block?.composition?.nodes?.[elements.relationFrom.value];
      return source ? compositions.relationshipOptions(source.types) : [];
    }

    function updateRelationTargets(block) {
      const composition = block?.composition;
      const source = composition?.nodes?.[elements.relationFrom.value];
      const property = elements.relationProperty.value;
      const custom = property === "__custom__";
      const previousTarget = elements.relationTarget.value;
      const previousType = elements.relationType.value.trim();
      const targetTypes = custom ? compositions.typeNames() : (source && property ? compositions.relationshipTargetTypes(source.types, property) : []);
      const targetSet = new Set(targetTypes);
      elements.relationTypes.replaceChildren();
      for (const type of targetTypes) {
        const option = document.createElement("option");
        option.value = type;
        elements.relationTypes.append(option);
      }
      elements.relationTarget.replaceChildren();
      const create = document.createElement("option");
      create.value = "";
      create.textContent = "Create a new node…";
      elements.relationTarget.append(create);
      for (const [alias, node] of nodeEntries(composition)) {
        if (!node.types.some((type) => targetSet.has(type))) continue;
        const option = document.createElement("option");
        option.value = alias;
        option.textContent = `${alias} · ${node.types.join(" + ")}`;
        elements.relationTarget.append(option);
      }
      if ([...elements.relationTarget.options].some((option) => option.value === previousTarget)) elements.relationTarget.value = previousTarget;
      if (targetSet.has(previousType)) elements.relationType.value = previousType;
      else if (!elements.relationTarget.value) elements.relationType.value = custom ? "" : (targetTypes[0] || "");
      const existing = Boolean(elements.relationTarget.value);
      elements.relationType.disabled = existing || !property;
      elements.relationAlias.disabled = existing || !property;
      if (!existing && elements.relationType.value && !elements.relationAlias.value) {
        elements.relationAlias.value = suggestedAlias(elements.relationType.value, composition?.nodes || {});
      }
      elements.relationAdd.disabled = !source || !property || (!existing && (!elements.relationType.value || !elements.relationAlias.value));
      elements.customRelationship.hidden = !custom;
      const prefix = getAdapterPrefix();
      elements.customPrefix.textContent = prefix
        ? `This relationship will be registered in the ${prefix}: adapter vocabulary and made available to Discovery.`
        : "Set the adapter id before saving a custom relationship.";
      if (custom && prefix && !elements.customTerm.value) elements.customTerm.value = `${prefix}:`;
    }

    function updateRelationProperties(block) {
      const previous = elements.relationProperty.value;
      const options = relationOptions(block);
      elements.relationProperty.replaceChildren();
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = options.length ? "Choose a Schema.org relationship…" : "No entity relationships available";
      elements.relationProperty.append(placeholder);
      for (const option of options) {
        const element = document.createElement("option");
        element.value = option.property;
        element.textContent = `${option.property} → ${(option.entityRanges || option.ranges).join(" | ")}`;
        element.title = option.description;
        elements.relationProperty.append(element);
      }
      const custom = document.createElement("option");
      custom.value = "__custom__";
      custom.textContent = "Create a custom relationship…";
      elements.relationProperty.append(custom);
      if (options.some((option) => option.property === previous)) elements.relationProperty.value = previous;
      updateRelationTargets(block);
    }

    function renderRelationForm(block) {
      const composition = block?.composition;
      const previous = elements.relationFrom.value;
      elements.relationFrom.replaceChildren();
      for (const [alias, node] of nodeEntries(composition)) {
        const option = document.createElement("option");
        option.value = alias;
        option.textContent = `${alias} · ${node.types.join(" + ")}`;
        elements.relationFrom.append(option);
      }
      if (composition?.nodes?.[previous]) elements.relationFrom.value = previous;
      elements.addRelationship.hidden = !composition;
      updateRelationProperties(block);
    }

    function typePill(alias, type, removable) {
      const pill = document.createElement("span");
      pill.className = "semantic-type-pill";
      pill.append(document.createTextNode(type));
      if (removable) {
        const remove = document.createElement("button");
        remove.type = "button";
        remove.textContent = "×";
        remove.title = `Remove ${type} from ${alias}`;
        remove.addEventListener("click", () => run(() => onRemoveType(alias, type), { successMessage: `Removed ${type} from ${alias}.` }));
        pill.append(remove);
      }
      return pill;
    }

    function renderOutline(composition) {
      elements.structureHeading.hidden = !composition;
      elements.summary.hidden = !composition;
      elements.nodeList.replaceChildren();
      elements.edgeList.replaceChildren();
      if (!composition) return;
      elements.nodeCount.textContent = `${Object.keys(composition.nodes).length}`;
      elements.edgeCount.textContent = `${composition.edges.length}`;
      for (const [alias, node] of nodeEntries(composition)) {
        const card = document.createElement("article");
        card.className = `semantic-node${alias === composition.root ? " root" : ""}`;
        const label = document.createElement("strong");
        label.className = "semantic-node-alias";
        label.textContent = alias;
        const meta = document.createElement("span");
        meta.className = "semantic-node-meta";
        meta.textContent = `${alias === composition.root ? "Root · " : ""}${node.expectation}`;
        card.append(label, meta);
        if (alias !== composition.root) {
          const remove = document.createElement("button");
          remove.type = "button";
          remove.className = "semantic-remove";
          remove.textContent = "Remove";
          remove.title = `Remove ${alias} and relationships that depend on it`;
          remove.addEventListener("click", () => run(() => onRemoveNode(alias), { successMessage: `Removed ${alias} from the composition.` }));
          card.append(remove);
        }
        const types = document.createElement("div");
        types.className = "semantic-node-types";
        for (const type of node.types) types.append(typePill(alias, type, node.types.length > 1));
        const addType = document.createElement("div");
        addType.className = "semantic-node-add-type";
        const input = document.createElement("input");
        input.setAttribute("list", "semantic-all-types");
        input.placeholder = "Add another compatible @type…";
        const button = document.createElement("button");
        button.type = "button";
        button.className = "secondary";
        button.textContent = "+ Type";
        button.addEventListener("click", () => {
          const type = input.value.trim();
          if (type) run(() => onAddType(alias, type), { successMessage: `Added ${type} to ${alias}.` });
        });
        addType.append(input, button);
        card.append(types, addType);
        elements.nodeList.append(card);
      }
      if (!composition.edges.length) {
        const empty = document.createElement("div");
        empty.className = "semantic-edge-empty";
        empty.textContent = "This is a one-node model. Add a relationship when the page represents a related entity.";
        elements.edgeList.append(empty);
      }
      for (const [index, edge] of composition.edges.entries()) {
        const row = document.createElement("article");
        row.className = "semantic-edge";
        const main = document.createElement("div");
        main.className = "semantic-edge-main";
        const property = document.createElement("code");
        property.textContent = edge.property;
        main.append(document.createTextNode(`${edge.from} — `), property, document.createTextNode(` → ${edge.to}`));
        const expectation = document.createElement("small");
        expectation.textContent = edge.expectation;
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "semantic-remove";
        remove.textContent = "Remove";
        remove.title = "Remove this relationship and any nodes no longer reachable from the root";
        remove.addEventListener("click", () => run(() => onRemoveEdge(index), { successMessage: `Removed ${edge.property}.` }));
        row.append(main, remove, expectation);
        elements.edgeList.append(row);
      }
      renderRelationForm(getBlock());
    }

    function renderOverview(block) {
      const composition = block?.composition || null;
      elements.overview.hidden = !composition;
      elements.openAdvanced.disabled = !composition;
      if (!composition) {
        elements.overviewTitle.textContent = "";
        elements.overviewCounts.textContent = "";
        elements.overviewPreview.textContent = "";
        return;
      }
      const nodeCount = Object.keys(composition.nodes || {}).length;
      const edgeCount = (composition.edges || []).length;
      elements.overviewTitle.textContent = composition.label;
      elements.overviewCounts.textContent = `${nodeCount} node${nodeCount === 1 ? "" : "s"} · ${edgeCount} relationship${edgeCount === 1 ? "" : "s"}${block.semanticsReviewed ? " · reviewed" : ""}`;
      const preview = (composition.edges || []).slice(0, 3).map((edge) => `${edge.from} — ${edge.property} → ${edge.to}`);
      const remaining = edgeCount - preview.length;
      elements.overviewPreview.textContent = preview.length
        ? `${preview.join(" · ")}${remaining > 0 ? ` · +${remaining} more` : ""}`
        : "One-node model. Open the graph or form editor if this page represents related entities.";
    }

    function renderViewMode(block) {
      if (!block) advancedOpen = false;
      elements.selectionView.hidden = advancedOpen;
      elements.advancedView.hidden = !advancedOpen || !block;
      renderOverview(block);
    }

    function render() {
      const block = getBlock();
      const composition = block?.composition || null;
      elements.context.textContent = block ? `${block.name} · ${block.matchCount} matches` : "Create a repeating block first.";
      elements.input.disabled = !block;
      elements.analyze.disabled = !block || block.semanticRanking?.status === "loading";
      const validation = composition && compositions ? compositions.validate(composition, getCustomTerms()) : { ok: false, errors: [] };
      elements.confirm.disabled = !block || !validation.ok;
      if (!block) setStatus("", "Create or select a block to choose its semantic model.");
      else if (!validation.ok) setStatus("error", validation.errors.join(" "));
      else if (block.semanticsReviewed) setStatus("ready", "This semantic model has been reviewed.");
      else setStatus("loading", "Choose the highlighted model or select another, then continue when the structure looks right.");
      renderMenu(block);
      renderOutline(composition);
      renderViewMode(block);
    }

    async function run(operation, { successMessage = "", reveal = null, focusSelected = false } = {}) {
      try {
        await operation();
        render();
        if (successMessage) setStatus("ready", successMessage);
        setTimeout(() => {
          reveal?.scrollIntoView?.({ block: "nearest" });
          if (focusSelected) elements.menu.querySelector(".semantic-model-option.selected, .semantic-model-option")?.focus({ preventScroll: true });
        }, 0);
        return true;
      } catch (error) {
        setStatus("error", error instanceof Error ? error.message : String(error));
        return false;
      }
    }

    function selectModel(candidate) {
      const current = getBlock()?.composition?.id;
      elements.input.value = "";
      if (candidate.id === current) {
        renderMenu(getBlock());
        setStatus("ready", `${candidate.label} is the selected model.`);
        return;
      }
      run(() => onApply(candidate.id), {
        successMessage: `Selected ${candidate.label}. Review the model structure, then continue when it looks right.`,
        reveal: elements.summary,
        focusSelected: true
      });
    }

    function moveMenu(delta) {
      const options = Array.from(elements.menu.querySelectorAll(".semantic-model-option"));
      if (!options.length) return;
      menuIndex = (menuIndex + delta + options.length) % options.length;
      options.forEach((option, index) => option.classList.toggle("active", index === menuIndex));
      elements.input.setAttribute("aria-activedescendant", options[menuIndex].id);
      options[menuIndex].scrollIntoView({ block: "nearest" });
    }

    function bind() {
      populateAllTypes();
      elements.input.addEventListener("input", () => renderMenu(getBlock()));
      elements.input.addEventListener("keydown", (event) => {
        if (event.key === "ArrowDown" || event.key === "ArrowUp") {
          event.preventDefault();
          moveMenu(event.key === "ArrowDown" ? 1 : -1);
        } else if (event.key === "Enter" && menuIndex >= 0) {
          event.preventDefault();
          elements.menu.querySelectorAll(".semantic-model-option")[menuIndex]?.click();
        } else if (event.key === "Escape" && elements.input.value) {
          event.preventDefault();
          elements.input.value = "";
          renderMenu(getBlock());
        }
      });
      elements.analyze.addEventListener("click", () => run(onAnalyze, { reveal: elements.menu, focusSelected: true }));
      elements.confirm.addEventListener("click", () => run(onConfirm));
      elements.openAdvanced.addEventListener("click", () => {
        if (!getBlock()?.composition) return;
        advancedOpen = true;
        render();
        setTimeout(() => {
          elements.advancedView.scrollIntoView({ block: "start" });
          elements.closeAdvanced.focus({ preventScroll: true });
        }, 0);
      });
      elements.closeAdvanced.addEventListener("click", () => {
        advancedOpen = false;
        render();
        setTimeout(() => {
          elements.selectionView.scrollIntoView({ block: "start" });
          elements.openAdvanced.focus({ preventScroll: true });
        }, 0);
      });
      elements.relationFrom.addEventListener("change", () => updateRelationProperties(getBlock()));
      elements.relationProperty.addEventListener("change", () => {
        if (elements.relationProperty.value === "__custom__") {
          elements.relationType.value = "";
          elements.relationAlias.value = "";
        }
        updateRelationTargets(getBlock());
      });
      elements.relationTarget.addEventListener("change", () => updateRelationTargets(getBlock()));
      elements.relationType.addEventListener("input", () => {
        const block = getBlock();
        elements.relationAlias.value = suggestedAlias(elements.relationType.value.trim(), block?.composition?.nodes || {});
        elements.relationAdd.disabled = !elements.relationProperty.value || !elements.relationType.value.trim() || !elements.relationAlias.value.trim();
      });
      elements.relationAlias.addEventListener("input", () => {
        elements.relationAdd.disabled = !elements.relationProperty.value || !elements.relationType.value.trim() || !elements.relationAlias.value.trim();
      });
      elements.relationAdd.addEventListener("click", () => {
        const target = elements.relationTarget.value;
        const command = {
          from: elements.relationFrom.value,
          property: elements.relationProperty.value === "__custom__" ? elements.customTerm.value.trim() : elements.relationProperty.value,
          expectation: elements.relationExpectation.value
        };
        if (elements.relationProperty.value === "__custom__") {
          command.customTerm = {
            description: elements.customDescription.value.trim(),
            evidenceAliases: elements.customAliases.value.trim()
          };
        }
        const operation = target
          ? () => onAddEdge({ ...command, to: target })
          : () => onAddNode({ ...command, alias: elements.relationAlias.value.trim(), type: elements.relationType.value.trim() });
        run(operation, {
          successMessage: `Added ${command.property} relationship.`,
          reveal: elements.edgeList
        }).then((ok) => {
          if (ok) {
            elements.relationAlias.value = "";
            elements.relationType.value = "";
            elements.customDescription.value = "";
            elements.customAliases.value = "";
          }
        });
      });
    }

    bind();
    return Object.freeze({ choice, elements, render, setStatus });
  }

  const api = Object.freeze({ create });
  root.Site2JsonSidebarSemantics = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this);
