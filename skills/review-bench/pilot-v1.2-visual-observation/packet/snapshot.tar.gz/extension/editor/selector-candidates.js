(function initializeSelectorCandidates(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonSelectorCandidates = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function selectorCandidatesFactory() {
  "use strict";

  const PRIORITY_DATA_ATTRIBUTES = ["data-test", "data-testid", "data-test-id", "data-qa", "data-cy", "data-automation-id"];
  const KIND_RANK = { id: 1, data: 2, aria: 3, class: 4, structure: 5, derived: 6, fallback: 7 };

  function hashLike(value) {
    return value.length >= 5
      && /[a-z]/i.test(value)
      && /\d/.test(value)
      && /^[a-z0-9]+$/i.test(value);
  }

  // This is deliberately shared by every wizard authoring path. Scope,
  // field, discovery, and variant-evidence selectors must not make separate
  // guesses about whether a framework token is safe to persist in the DSL.
  function looksGenerated(token) {
    const value = String(token || "").trim();
    if (!value) return true;
    if (value.length > 64) return true;
    if (/^[a-f0-9]{6,}$/i.test(value)) return true;
    if (/\d{4,}/.test(value)) return true;
    if (/^(?:ember|jss)\d+$/i.test(value)) return true;
    if (/^(?:css|emotion|jsx|svelte)-[a-z0-9_-]{4,}$/i.test(value)) return true;
    if (/^sc-[a-z0-9_-]{5,}$/i.test(value)) return true;
    if (/^(?:makeStyles|withStyles|useStyles)-.+-\d+$/i.test(value)) return true;
    if (/^_?ng(?:content|host)-/i.test(value) || /^ng-tns-/i.test(value)) return true;
    const doubleUnderscoreSuffix = value.match(/^(.*__)([a-z0-9]+)$/i);
    if (doubleUnderscoreSuffix && hashLike(doubleUnderscoreSuffix[2])) return true;
    const cssModule = value.match(/(?:^|_)([a-z0-9]{5,})(?:_\d+)?$/i);
    if (cssModule && hashLike(cssModule[1])) return true;
    if (/^[a-z]+[-_][a-f0-9]{4,}$/i.test(value)) return true;
    return false;
  }

  function stableClassNames(element) {
    const classes = Array.from(element?.classList || []);
    const styledComponents = classes.some((value) => /^sc-[a-z0-9_-]{5,}$/i.test(value));
    return classes.filter((value) => {
      if (looksGenerated(value)) return false;
      // styled-components emits a stable-looking mixed-case companion hash
      // beside its sc-* marker (for example "sc-aXZVg jZdJPA"). Without the
      // marker, rejecting all camelCase words would discard valid BEM/UI hooks.
      if (styledComponents && /^(?=.*[a-z])(?=.*[A-Z])[A-Za-z]{5,14}$/.test(value)) return false;
      return true;
    });
  }

  function stableId(element) {
    return element?.id && !looksGenerated(element.id) ? element.id : "";
  }

  function generatedClassPrefix(value) {
    const token = String(value || "");
    const doubleUnderscore = token.match(/^(.*__)([a-z0-9]+)$/i);
    if (doubleUnderscore && hashLike(doubleUnderscore[2])) return doubleUnderscore[1];
    const cssModule = token.match(/^(.*_)([a-z0-9]{5,})_\d+$/i);
    if (cssModule && hashLike(cssModule[2])) return cssModule[1];
    const numbered = token.match(/^((?:makeStyles|withStyles|useStyles)-.+-)(\d+)$/i);
    if (numbered) return numbered[1];
    return "";
  }

  function cssEscapeToken(value, document) {
    const view = document?.defaultView || (typeof globalThis === "object" ? globalThis : undefined);
    if (view?.CSS && typeof view.CSS.escape === "function") return view.CSS.escape(value);
    return String(value).replace(/([^a-zA-Z0-9_-])/g, "\\$1").replace(/^(\d)/, "\\3$1 ");
  }

  function cssEscapeAttributeValue(value) {
    return String(value).replace(/\\/g, "\\\\").replace(/"/g, "\\\"");
  }

  function positionalSelector(element, document, boundary) {
    const segments = [];
    let node = element;
    let depth = 0;
    while (node && node.nodeType === 1 && node !== boundary && depth < 4) {
      const parent = node.parentElement;
      const nodeId = stableId(node);
      if (nodeId) {
        segments.unshift(`#${cssEscapeToken(nodeId, document)}`);
        break;
      }
      let segment = node.tagName.toLowerCase();
      if (parent) {
        const siblings = Array.from(parent.children).filter((child) => child.tagName === node.tagName);
        if (siblings.length > 1) segment += `:nth-of-type(${siblings.indexOf(node) + 1})`;
      }
      segments.unshift(segment);
      node = parent;
      depth += 1;
    }
    return segments.join(" > ");
  }

  function noteFor(kind, matchCount, unique) {
    if (kind === "derived") {
      return unique
        ? "Fragile: matches the readable prefix of a generated class; currently unique."
        : `Fragile: matches the readable prefix of a generated class. Matches ${matchCount} elements.`;
    }
    if (kind === "fallback") {
      return unique
        ? "Fragile: relies on positional (:nth-of-type) matching, but currently unique."
        : `Fragile: relies on positional (:nth-of-type) matching. Matches ${matchCount} elements.`;
    }
    return unique ? "Unique match." : `Matches ${matchCount} elements including this one; add more context to disambiguate.`;
  }

  function collectCandidates(element, queryRoot, escapeDocument, boundary) {
    if (!element || typeof element.querySelectorAll !== "function") return [];
    if (!queryRoot || typeof queryRoot.querySelectorAll !== "function") return [];
    const found = [];

    function addCandidate(selector, kind) {
      if (!selector) return;
      let nodes;
      try {
        nodes = Array.from(queryRoot.querySelectorAll(selector));
      } catch {
        return;
      }
      if (!nodes.includes(element)) return;
      const matchCount = nodes.length;
      const unique = matchCount === 1;
      found.push({ selector, kind, rank: KIND_RANK[kind], matchCount, unique, note: noteFor(kind, matchCount, unique) });
    }

    const elementId = stableId(element);
    if (elementId) {
      addCandidate(`#${cssEscapeToken(elementId, escapeDocument)}`, "id");
    }

    const dataAttributes = Array.from(element.attributes || []).filter((attr) => (
      attr.name.startsWith("data-") && attr.value && !looksGenerated(attr.value) && !attr.name.startsWith("data-v-") && !attr.name.startsWith("data-react")
    ));
    const prioritized = dataAttributes.filter((attr) => PRIORITY_DATA_ATTRIBUTES.includes(attr.name));
    const other = dataAttributes.filter((attr) => !PRIORITY_DATA_ATTRIBUTES.includes(attr.name));
    for (const attr of [...prioritized, ...other]) {
      addCandidate(`[${attr.name}="${cssEscapeAttributeValue(attr.value)}"]`, "data");
    }

    const role = element.getAttribute?.("role");
    if (role) addCandidate(`${element.tagName.toLowerCase()}[role="${cssEscapeAttributeValue(role)}"]`, "aria");
    const ariaLabel = element.getAttribute?.("aria-label");
    if (ariaLabel) addCandidate(`[aria-label="${cssEscapeAttributeValue(ariaLabel)}"]`, "aria");

    const stableClasses = stableClassNames(element);
    if (stableClasses.length > 0) {
      addCandidate(stableClasses.slice(0, 2).map((cls) => `.${cssEscapeToken(cls, escapeDocument)}`).join(""), "class");
      for (const cls of stableClasses.slice(0, 4)) {
        addCandidate(`.${cssEscapeToken(cls, escapeDocument)}`, "class");
      }
    }

    for (const cls of Array.from(element.classList || []).slice(0, 6)) {
      const prefix = generatedClassPrefix(cls);
      if (!prefix) continue;
      addCandidate(`${element.tagName.toLowerCase()}[class*="${cssEscapeAttributeValue(prefix)}"]`, "derived");
    }

    addCandidate(positionalSelector(element, escapeDocument, boundary), "fallback");

    const bySelector = new Map();
    for (const candidate of found) {
      if (!bySelector.has(candidate.selector)) bySelector.set(candidate.selector, candidate);
    }
    const uniqueCandidates = Array.from(bySelector.values());
    return uniqueCandidates
      .sort((a, b) => (a.rank - b.rank) || (Number(b.unique) - Number(a.unique)) || (a.matchCount - b.matchCount))
      .map(({ rank, ...candidate }) => candidate);
  }

  function generateCandidates(element, doc) {
    const document = doc || element?.ownerDocument;
    return collectCandidates(element, document, document, null);
  }

  function generateScopedCandidates(element, scopeRoot, doc) {
    const document = doc || element?.ownerDocument;
    const direct = collectCandidates(element, scopeRoot, document, scopeRoot);
    const parent = element?.parentElement;
    if (!parent || parent === scopeRoot) return direct;
    const parentCandidates = collectCandidates(parent, scopeRoot, document, scopeRoot)
      .filter((candidate) => !["derived", "fallback"].includes(candidate.kind))
      .slice(0, 3);
    const childCandidates = direct
      .filter((candidate) => !["derived", "fallback", "id"].includes(candidate.kind))
      .slice(0, 4);
    const structural = [];
    for (const parentCandidate of parentCandidates) {
      for (const childCandidate of childCandidates) {
        const selector = `${parentCandidate.selector} > ${childCandidate.selector}`;
        let nodes;
        try {
          nodes = Array.from(scopeRoot.querySelectorAll(selector));
        } catch {
          continue;
        }
        if (!nodes.includes(element)) continue;
        structural.push({
          selector,
          kind: "structure",
          matchCount: nodes.length,
          unique: nodes.length === 1,
          note: `Anchored to the selected element's stable parent within the scope.`
        });
      }
    }
    // A field often has no hook of its own while a nearby BEM-style ancestor
    // does. Anchor the precise relative path to stable ancestors instead of
    // falling back to an unanchored chain from the card root.
    for (let ancestor = element?.parentElement, depth = 0; ancestor && ancestor !== scopeRoot && depth < 4; ancestor = ancestor.parentElement, depth += 1) {
      const anchors = collectCandidates(ancestor, scopeRoot, document, scopeRoot)
        .filter((candidate) => !["derived", "fallback"].includes(candidate.kind))
        .slice(0, 3);
      if (!anchors.length) continue;
      const segments = [];
      for (let node = element; node && node !== ancestor; node = node.parentElement) {
        const parentNode = node.parentElement;
        let segment = node.tagName.toLowerCase();
        if (parentNode) {
          const siblings = Array.from(parentNode.children).filter((sibling) => sibling.tagName === node.tagName);
          if (siblings.length > 1) segment += `:nth-of-type(${siblings.indexOf(node) + 1})`;
        }
        segments.unshift(segment);
      }
      const relative = segments.join(" > ");
      for (const anchor of anchors) {
        const selector = `${anchor.selector} > ${relative}`;
        let nodes;
        try { nodes = Array.from(scopeRoot.querySelectorAll(selector)); } catch { continue; }
        if (!nodes.includes(element)) continue;
        structural.push({
          selector,
          kind: "structure",
          matchCount: nodes.length,
          unique: nodes.length === 1,
          note: "Anchored to a stable ancestor within the scope."
        });
      }
    }
    const bySelector = new Map();
    for (const candidate of [...direct, ...structural]) {
      if (!bySelector.has(candidate.selector)) bySelector.set(candidate.selector, candidate);
    }
    return Array.from(bySelector.values()).sort((left, right) => (
      (KIND_RANK[left.kind] ?? 9) - (KIND_RANK[right.kind] ?? 9)
      || Number(right.unique) - Number(left.unique)
      || left.matchCount - right.matchCount
    ));
  }

  function pickBest(candidates) {
    return Array.isArray(candidates) && candidates.length > 0 ? candidates[0] : null;
  }

  function summarizeElement(element) {
    if (!element || element.nodeType !== 1) return null;
    return {
      tag: element.tagName.toLowerCase(),
      id: element.id || null,
      classes: Array.from(element.classList || []),
      text: (element.textContent || "").replace(/\s+/g, " ").trim().slice(0, 120)
    };
  }

  function shadowBoundary(element) {
    const root = element?.getRootNode?.();
    if (!root || root.nodeType === 9 || !root.host) return null;
    return {
      mode: root.mode === "closed" ? "closed" : "open",
      host: summarizeElement(root.host)
    };
  }

  return { generateCandidates, generateScopedCandidates, pickBest, looksGenerated, stableClassNames, stableId, generatedClassPrefix, shadowBoundary, summarizeElement };
});
