(function initializeScopeInference(root, factory) {
  "use strict";
  const selectorCandidates = root.Site2JsonSelectorCandidates || (typeof require === "function" ? require("./selector-candidates") : null);
  const api = factory(selectorCandidates);
  root.Site2JsonScopeInference = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function scopeInferenceFactory(selectorCandidates) {
  "use strict";

  const MAX_DEPTH = 8;
  const KIND_WEIGHT = { id: 6, data: 5, structure: 4, aria: 3, class: 2, derived: 1, fallback: 0 };
  const ENTITY_ROOT_WEIGHT = { article: 700, main: 600, section: 500, aside: 250, div: 100, body: 25 };

  function ancestorChain(element, maxDepth) {
    const chain = [];
    let node = element;
    let depth = 0;
    while (node && node.nodeType === 1 && node.tagName !== "BODY" && depth <= maxDepth) {
      chain.push(node);
      node = node.parentElement;
      depth += 1;
    }
    return chain;
  }

  function siblingMatchCount(element, selector) {
    const parent = element.parentElement;
    if (!parent) return 0;
    return Array.from(parent.children).filter((child) => {
      try {
        return child.matches(selector);
      } catch {
        return false;
      }
    }).length;
  }

  function parentCount(document, selector) {
    try {
      return new Set(Array.from(document.querySelectorAll(selector), (node) => node.parentElement).filter(Boolean)).size;
    } catch {
      return 0;
    }
  }

  function structuralFindings(candidate) {
    const findings = [];
    if (candidate.parentCount === 1) findings.push({ kind: "good", message: "All matches share one parent." });
    else if (candidate.parentCount > 1) findings.push({ kind: "warning", message: `Matches are scattered across ${candidate.parentCount} parents.` });
    if (candidate.siblingMatchCount > 1) findings.push({ kind: "good", message: `${candidate.siblingMatchCount} matching sibling items surround the selection.` });
    else findings.push({ kind: "warning", message: "Only one matching item appears under the selected element's parent." });
    if (candidate.kind === "derived") findings.push({ kind: "warning", message: "Selector uses the readable prefix of a generated class and may change after a rebuild." });
    if (candidate.kind === "fallback") findings.push({ kind: "warning", message: "Selector depends on document position." });
    return findings;
  }

  function singularFindings(candidate) {
    const findings = [{ kind: "good", message: "Selector identifies one rendered item." }];
    if (candidate.kind === "derived") findings.push({ kind: "warning", message: "Selector uses the readable prefix of a generated class and may change after a rebuild." });
    if (candidate.kind === "fallback") findings.push({ kind: "warning", message: "Selector depends on document position; prefer a stable ID, class, or data attribute when available." });
    return findings;
  }

  function parentAnchoredCandidates(element, document) {
    const parent = element.parentElement;
    if (!parent) return [];
    const tag = element.tagName.toLowerCase();
    const found = [];
    for (const parentCandidate of selectorCandidates.generateCandidates(parent, document)) {
      if (["derived", "fallback"].includes(parentCandidate.kind)) continue;
      const selector = `${parentCandidate.selector} > ${tag}`;
      let matches;
      try {
        matches = Array.from(document.querySelectorAll(selector));
      } catch {
        continue;
      }
      if (matches.length <= 1 || !matches.includes(element)) continue;
      found.push({
        selector,
        kind: "structure",
        matchCount: matches.length,
        unique: false,
        note: `Repeated <${tag}> children beneath a stable parent selector.`
      });
    }
    return found;
  }

  function scopeScore(candidate, depth) {
    if (!candidate || candidate.matchCount <= 1) return -Infinity;
    const kindWeight = KIND_WEIGHT[candidate.kind] ?? 1;
    const scatteredPenalty = Math.max(0, candidate.parentCount - 1) * 25;
    return kindWeight * 1000 + Math.min(candidate.siblingMatchCount, 50) * 10 - scatteredPenalty - depth;
  }

  function singularScopeScore(candidate, depth, tagName) {
    if (!candidate || candidate.matchCount !== 1) return -Infinity;
    const rootWeight = ENTITY_ROOT_WEIGHT[tagName] || 0;
    const kindWeight = KIND_WEIGHT[candidate.kind] ?? 1;
    return rootWeight + kindWeight * 100 + depth;
  }

  function candidatesByDepth(pickedElement, document, { maxDepth = MAX_DEPTH } = {}) {
    const chain = ancestorChain(pickedElement, maxDepth);
    return chain.map((element, depth) => {
      const scored = [...selectorCandidates.generateCandidates(element, document), ...parentAnchoredCandidates(element, document)]
        .filter((candidate) => candidate.kind !== "id" && candidate.matchCount > 1)
        .map((candidate) => {
          const enriched = {
            ...candidate,
            siblingMatchCount: siblingMatchCount(element, candidate.selector),
            parentCount: parentCount(document, candidate.selector)
          };
          return { ...enriched, findings: structuralFindings(enriched) };
        })
        .sort((a, b) => scopeScore(b, depth) - scopeScore(a, depth));
      return { depth, element, tagName: element.tagName.toLowerCase(), best: scored[0] || null, candidates: scored };
    });
  }

  function repeatedDirectChildLevel(container, document) {
    const groups = new Map();
    for (const child of Array.from(container?.children || [])) {
      const tagName = child.tagName.toLowerCase();
      if (!groups.has(tagName)) groups.set(tagName, []);
      groups.get(tagName).push(child);
    }
    const levels = [];
    for (const [tagName, children] of groups) {
      if (children.length <= 1) continue;
      const bySelector = new Map();
      for (const element of children) {
        for (const candidate of [...selectorCandidates.generateCandidates(element, document), ...parentAnchoredCandidates(element, document)]) {
          if (candidate.kind === "id" || candidate.matchCount <= 1 || bySelector.has(candidate.selector)) continue;
          bySelector.set(candidate.selector, { element, candidate });
        }
      }
      const scored = Array.from(bySelector.values())
        .map(({ element, candidate }) => {
          const enriched = {
            ...candidate,
            siblingMatchCount: siblingMatchCount(element, candidate.selector),
            parentCount: parentCount(document, candidate.selector)
          };
          return { element, candidate: { ...enriched, findings: structuralFindings(enriched) } };
        })
        .filter(({ candidate }) => candidate.siblingMatchCount > 1)
        .sort((a, b) => scopeScore(b.candidate, -1) - scopeScore(a.candidate, -1));
      if (scored.length) levels.push({
        depth: -1,
        element: scored[0].element,
        tagName,
        best: scored[0].candidate,
        candidates: scored.map((entry) => entry.candidate)
      });
    }
    levels.sort((a, b) => scopeScore(b.best, -1) - scopeScore(a.best, -1));
    return levels[0] || null;
  }

  function singularCandidatesByDepth(pickedElement, document, { maxDepth = MAX_DEPTH } = {}) {
    let chain = ancestorChain(pickedElement, maxDepth);
    const body = document.body;
    if (pickedElement === body) {
      const roots = [
        ...(document.querySelectorAll("article").length === 1 ? [document.querySelector("article")] : []),
        ...(document.querySelectorAll("main").length === 1 ? [document.querySelector("main")] : []),
        ...(document.querySelectorAll('[role="main"]').length === 1 ? [document.querySelector('[role="main"]')] : [])
      ].filter((element, index, all) => element && all.indexOf(element) === index && body.contains(element));
      roots.sort((left, right) => left.contains(right) ? 1 : right.contains(left) ? -1 : 0);
      chain = [...roots, body];
    } else if (body && !chain.includes(body) && chain.length <= maxDepth) {
      chain.push(body);
    }
    return chain.map((element, depth) => {
      const tagName = element.tagName.toLowerCase();
      const tagCandidate = ENTITY_ROOT_WEIGHT[tagName] && document.querySelectorAll(tagName).length === 1
        ? [{ selector: tagName, kind: "structure", matchCount: 1, unique: true, note: `Unique <${tagName}> item root.` }]
        : [];
      const bySelector = new Map([...tagCandidate, ...selectorCandidates.generateCandidates(element, document)].map((candidate) => [candidate.selector, candidate]));
      const scored = Array.from(bySelector.values())
        .filter((candidate) => candidate.matchCount === 1)
        .map((candidate) => ({
          ...candidate,
          siblingMatchCount: 1,
          parentCount: 1,
          findings: singularFindings(candidate)
        }))
        .sort((a, b) => singularScopeScore(b, depth, tagName) - singularScopeScore(a, depth, tagName));
      return { depth, element, tagName, best: scored[0] || null, candidates: scored };
    });
  }

  function inferRepeatingScope(pickedElement, document, options = {}) {
    if (options.allowSingle) {
      const singularLevels = singularCandidatesByDepth(pickedElement, document, options);
      const singularRanked = singularLevels
        .filter((level) => level.best)
        .sort((a, b) => singularScopeScore(b.best, b.depth, b.tagName) - singularScopeScore(a.best, a.depth, a.tagName));
      // In single-item mode the author may intentionally select <body> when
      // an entity is split across sibling header and main containers. Keep
      // narrower semantic roots available as alternatives, but do not choose
      // one automatically and discard evidence outside it.
      const singularWinner = pickedElement === document.body
        ? singularLevels.find((level) => level.element === document.body && level.best) || null
        : singularRanked[0] || null;
      return {
        mode: "single",
        levels: singularLevels,
        chosen: singularWinner ? {
          selector: singularWinner.best.selector,
          kind: singularWinner.best.kind,
          matchCount: 1,
          siblingMatchCount: 1,
          parentCount: 1,
          findings: singularWinner.best.findings,
          depth: singularWinner.depth
        } : null
      };
    }
    const descendant = repeatedDirectChildLevel(pickedElement, document);
    const levels = [descendant, ...candidatesByDepth(pickedElement, document, options)].filter(Boolean);
    const ranked = levels
      .filter((level) => level.best)
      .sort((a, b) => scopeScore(b.best, b.depth) - scopeScore(a.best, a.depth));
    const winner = ranked[0] || null;
    return {
      mode: winner ? "collection" : null,
      levels,
      chosen: winner ? {
        selector: winner.best.selector,
        kind: winner.best.kind,
        matchCount: winner.best.matchCount,
        siblingMatchCount: winner.best.siblingMatchCount,
        parentCount: winner.best.parentCount,
        findings: winner.best.findings,
        depth: winner.depth
      } : null
    };
  }

  function inferRepeatingScopeFromExamples(elementA, elementB, document, options = {}) {
    const levelsA = candidatesByDepth(elementA, document, options);
    const chainB = ancestorChain(elementB, options.maxDepth ?? MAX_DEPTH);
    const shared = [];
    for (const level of levelsA) {
      for (const candidate of level.candidates) {
        let matches;
        try {
          matches = Array.from(document.querySelectorAll(candidate.selector));
        } catch {
          continue;
        }
        if (!matches.includes(level.element)) continue;
        const matchedB = chainB.find((node) => matches.includes(node));
        if (!matchedB) continue;
        if (matchedB.tagName !== level.element.tagName) continue;
        shared.push({
          selector: candidate.selector,
          kind: candidate.kind,
          matchCount: candidate.matchCount,
          siblingMatchCount: candidate.siblingMatchCount,
          parentCount: candidate.parentCount,
          findings: candidate.findings,
          depthA: level.depth,
          depthB: chainB.indexOf(matchedB)
        });
      }
    }
    shared.sort((a, b) => scopeScore(b, b.depthA) - scopeScore(a, a.depthA));
    return { candidates: shared, chosen: shared[0] || null };
  }

  return { candidatesByDepth, inferRepeatingScope, inferRepeatingScopeFromExamples };
});
