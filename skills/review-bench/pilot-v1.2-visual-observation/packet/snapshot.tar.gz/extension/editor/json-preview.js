"use strict";

(function initializeJsonPreview(root, factory) {
  const api = factory();
  root.Site2JsonJsonPreview = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function jsonPreviewFactory() {
  "use strict";

  function serialize(value) {
    return JSON.stringify(value ?? null, null, 2);
  }

  function pointerSegment(value) {
    return String(value).replace(/~/g, "~0").replace(/\//g, "~1");
  }

  function serializedLines(value) {
    const lines = [];
    function append(current, path, depth, prefix = "") {
      const indent = "  ".repeat(depth);
      if (!current || typeof current !== "object") {
        lines.push({ text: `${indent}${prefix}${JSON.stringify(current)}`, path });
        return;
      }
      const array = Array.isArray(current);
      const entries = array ? current.map((item, index) => [String(index), item]) : Object.entries(current);
      if (!entries.length) {
        lines.push({ text: `${indent}${prefix}${array ? "[]" : "{}"}`, path });
        return;
      }
      lines.push({ text: `${indent}${prefix}${array ? "[" : "{"}`, path });
      entries.forEach(([key, item], index) => {
        const childPath = `${path}/${pointerSegment(key)}`;
        const childPrefix = array ? "" : `${JSON.stringify(key)}: `;
        const before = lines.length;
        append(item, childPath, depth + 1, childPrefix);
        if (index < entries.length - 1) lines[lines.length - 1].text += ",";
        // The opening line is the addressable row for a nested value, while
        // its descendants keep their own precise paths.
        if (lines.length > before) lines[before].path = childPath;
      });
      lines.push({ text: `${indent}${array ? "]" : "}"}`, path });
    }
    append(value ?? null, "", 0);
    return lines;
  }

  function pathContains(container, candidate) {
    return candidate === container || (container && candidate.startsWith(`${container}/`));
  }

  function render(element, value, prism = globalThis.Site2JsonPrism, options = {}) {
    const records = serializedLines(value);
    const source = records.map((record) => record.text).join("\n");
    const grammar = prism?.languages?.json;
    element.classList.add("language-json");
    const highlights = [...new Set((options.highlightStrings || []).map(String).filter(Boolean))];
    const focusPaths = [...new Set((options.highlightPaths || []).map(String).filter(Boolean))];
    const pathAliases = options.pathAliases || {};
    const rendered = records.flatMap((record, index) => {
      const line = record.text;
      const row = element.ownerDocument.createElement("span");
      row.className = "s2j-code-line";
      row.dataset.line = String(index + 1);
      row.dataset.path = record.path;
      const aliases = [...new Set(Object.entries(pathAliases)
        .filter(([path]) => pathContains(path, record.path))
        .sort(([left], [right]) => right.length - left.length)
        .flatMap(([, values]) => values || []))];
      if (aliases.length) row.dataset.focusAliases = aliases.join("\u001f");
      if (focusPaths.some((path) => pathContains(path, record.path)) || highlights.some((item) => line.includes(item))) row.classList.add("selected");
      if (aliases.length && typeof options.onFocus === "function") {
        row.classList.add("focusable");
        row.tabIndex = 0;
        row.setAttribute("role", "button");
        row.title = `Focus ${aliases.join(", ")} in the semantic graph`;
        const activate = () => options.onFocus(aliases, record.path);
        row.addEventListener("click", activate);
        row.addEventListener("keydown", (event) => {
          if (event.key !== "Enter" && event.key !== " ") return;
          event.preventDefault();
          activate();
        });
      }
      if (grammar && typeof prism.highlight === "function") row.innerHTML = prism.highlight(line || " ", grammar, "json");
      else row.textContent = line || " ";
      return index < records.length - 1
        ? [row, element.ownerDocument.createTextNode("\n")]
        : [row];
    });
    element.replaceChildren(...rendered);
    if (options.reveal !== false) element.querySelector(".s2j-code-line.selected")?.scrollIntoView?.({ block: "center" });
    return source;
  }

  return Object.freeze({ render, serialize, serializedLines });
});
