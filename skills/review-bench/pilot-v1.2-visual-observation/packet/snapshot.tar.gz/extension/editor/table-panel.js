"use strict";

const els = {
  pageLabel: document.querySelector("#page-label"),
  refresh: document.querySelector("#refresh-button"),
  clearHighlight: document.querySelector("#clear-highlight-button"),
  blockPickerLabel: document.querySelector("#block-picker-label"),
  blockPicker: document.querySelector("#block-picker"),
  blockHeading: document.querySelector("#block-heading"),
  issueSummary: document.querySelector("#issue-summary"),
  structureRoute: document.querySelector("#structure-route"),
  structureAutomatic: document.querySelector("#structure-automatic"),
  structureInfer: document.querySelector("#structure-infer"),
  structureSingleItem: document.querySelector("#structure-single-item"),
  structureScanPage: document.querySelector("#structure-scan-page"),
  structureSelection: document.querySelector("#structure-selection"),
  structureStatus: document.querySelector("#structure-status"),
  scopeProposalsCard: document.querySelector("#scope-proposals-card"),
  scopeProposals: document.querySelector("#scope-proposals"),
  structureBlockForm: document.querySelector("#structure-block-form"),
  structureAcceptedScope: document.querySelector("#structure-accepted-scope"),
  structureBlockName: document.querySelector("#structure-block-name"),
  structureSchemaType: document.querySelector("#structure-schema-type"),
  structureSchemaTypes: document.querySelector("#structure-schema-types"),
  structureCancel: document.querySelector("#structure-cancel"),
  structureCreate: document.querySelector("#structure-create"),
  reviewRoute: document.querySelector("#review-route"),
  reviewWorkspace: document.querySelector("#review-workspace"),
  driftReview: document.querySelector("#drift-review"),
  driftReviewSummary: document.querySelector("#drift-review-summary"),
  driftReviewList: document.querySelector("#drift-review-list"),
  driftReviewCheck: document.querySelector("#drift-review-check"),
  semanticsRoute: document.querySelector("#semantics-route"),
  discoverRoute: document.querySelector("#discover-route"),
  discoverContext: document.querySelector("#discover-context"),
  discoverRun: document.querySelector("#discover-run"),
  discoverIncludeUnmapped: document.querySelector("#discover-include-unmapped"),
  discoverUndo: document.querySelector("#discover-undo"),
  discoverReview: document.querySelector("#discover-review"),
  discoverReport: document.querySelector("#discover-report"),
  discoverCounts: document.querySelector("#discover-counts"),
  finishRoute: document.querySelector("#finish-route"),
  finishBuild: document.querySelector("#finish-build"),
  finishRefreshBaseline: document.querySelector("#finish-refresh-baseline"),
  finishCaptureFixture: document.querySelector("#finish-capture-fixture"),
  finishMetadata: document.querySelector("#finish-metadata"),
  finishAdapterId: document.querySelector("#finish-adapter-id"),
  finishNamespace: document.querySelector("#finish-namespace"),
  finishPageId: document.querySelector("#finish-page-id"),
  finishPageType: document.querySelector("#finish-page-type"),
  finishBuildStatus: document.querySelector("#finish-build-status"),
  finishPreview: document.querySelector("#finish-preview"),
  finishSave: document.querySelector("#finish-save"),
  finishExport: document.querySelector("#finish-export"),
  finishPublish: document.querySelector("#finish-publish"),
  finishDraftStatus: document.querySelector("#finish-draft-status"),
  finishPreviewWrap: document.querySelector("#finish-preview-wrap"),
  finishPreviewOutput: document.querySelector("#finish-preview-output"),
  semanticsContext: document.querySelector("#semantics-context"),
  semanticsDone: document.querySelector("#semantics-done"),
  modelSearch: document.querySelector("#model-search"),
  modelOptions: document.querySelector("#model-options"),
  modelCurrent: document.querySelector("#model-current"),
  analyzeSemantics: document.querySelector("#analyze-semantics"),
  modelRankingStatus: document.querySelector("#model-ranking-status"),
  modelRankings: document.querySelector("#model-rankings"),
  compositionStatus: document.querySelector("#composition-status"),
  compositionOutline: document.querySelector("#composition-outline"),
  relatedFrom: document.querySelector("#related-from"),
  relatedType: document.querySelector("#related-type"),
  relatedTypeOptions: document.querySelector("#related-type-options"),
  relatedProperty: document.querySelector("#related-property"),
  relatedAlias: document.querySelector("#related-alias"),
  relatedExpectation: document.querySelector("#related-expectation"),
  addRelatedNode: document.querySelector("#add-related-node"),
  relatedNodeStatus: document.querySelector("#related-node-status"),
  fieldEditorRoute: document.querySelector("#field-editor-route"),
  fieldEditorTitle: document.querySelector("#field-editor-title"),
  fieldEditorContext: document.querySelector("#field-editor-context"),
  fieldEditorBack: document.querySelector("#field-editor-back"),
  fieldEditorStatus: document.querySelector("#field-editor-status"),
  fieldEditorForm: document.querySelector("#field-editor-form"),
  fieldSelector: document.querySelector("#field-selector"),
  fieldSelectorOptions: document.querySelector("#field-selector-options"),
  fieldSelectorEvidence: document.querySelector("#field-selector-evidence"),
  fieldName: document.querySelector("#field-name"),
  fieldNameOptions: document.querySelector("#field-name-options"),
  fieldKind: document.querySelector("#field-kind"),
  fieldAttribute: document.querySelector("#field-attribute"),
  fieldMultiple: document.querySelector("#field-multiple"),
  fieldIdentity: document.querySelector("#field-identity"),
  fieldRequired: document.querySelector("#field-required"),
  fieldSemanticStatus: document.querySelector("#field-semantic-status"),
  customTermFields: document.querySelector("#custom-term-fields"),
  customTermDescription: document.querySelector("#custom-term-description"),
  customTermValueType: document.querySelector("#custom-term-value-type"),
  customTermExample: document.querySelector("#custom-term-example"),
  fieldPipeline: document.querySelector("#field-pipeline"),
  transformSearch: document.querySelector("#transform-search"),
  transformOptions: document.querySelector("#transform-options"),
  transformArguments: document.querySelector("#transform-arguments"),
  transformArgumentsTitle: document.querySelector("#transform-arguments-title"),
  transformArgumentsDescription: document.querySelector("#transform-arguments-description"),
  transformArgumentFields: document.querySelector("#transform-argument-fields"),
  transformArgumentStatus: document.querySelector("#transform-argument-status"),
  transformArgumentsCancel: document.querySelector("#transform-arguments-cancel"),
  transformArgumentsSave: document.querySelector("#transform-arguments-save"),
  transformHelp: document.querySelector("#transform-help"),
  selectionProposal: document.querySelector("#selection-proposal"),
  selectionProposalSummary: document.querySelector("#selection-proposal-summary"),
  selectionProposalSelector: document.querySelector("#selection-proposal-selector"),
  selectionProposalCoverage: document.querySelector("#selection-proposal-coverage"),
  useSelectionProposal: document.querySelector("#use-selection-proposal"),
  fieldPreview: document.querySelector("#field-preview"),
  fieldCancel: document.querySelector("#field-cancel"),
  fieldSave: document.querySelector("#field-save"),
  empty: document.querySelector("#empty-state"),
  tableWrap: document.querySelector("#table-wrap"),
  tableHead: document.querySelector("#table-head"),
  tableBody: document.querySelector("#table-body"),
  connectionStatus: document.querySelector("#connection-status"),
  workflowSteps: document.querySelector("#workflow-steps"),
  leasePaused: document.querySelector("#lease-paused"),
  resumeExpanded: document.querySelector("#resume-expanded-button")
};

const tabIdParameter = new URLSearchParams(location.search).get("tabId");
let tabId = tabIdParameter === null ? Number.NaN : Number(tabIdParameter);
let port = null;
let connected = false;
let snapshot = null;
let editor = null;
let selectionFocus = null;
let workflow = null;
let leaseOwner = "sidebar";
let heartbeat = null;
let fieldEditorKey = null;
let fieldDraftDirty = false;
let returnFocus = null;
let workspaceRoute = "review";
let advanceAfterStructureCreate = false;
let localPipeline = [];
let pendingTransform = null;
let livePreviewTimer = null;
const transformCatalog = globalThis.Site2JsonTransformCatalog;
const transformPicker = globalThis.Site2JsonTransformPicker;
const semanticCompositions = globalThis.Site2JsonSemanticCompositions;

function setConnection(message, kind = "") {
  els.connectionStatus.textContent = message;
  els.connectionStatus.className = `connection-status ${kind}`.trim();
}

function send(command) {
  if (!port || !connected) {
    setConnection("The Site2JSON editor is not connected for this tab.", "error");
    return;
  }
  port.postMessage({ type: "editor-command", command });
}

function sendProtocol(message) {
  if (!port || !connected) return;
  port.postMessage(message);
}

function renderWorkflow() {
  els.workflowSteps.replaceChildren();
  for (const step of workflow?.steps || []) {
    const routes = ["structure", "review", "semantics", "discover", "finish"];
    const routeActive = routes.includes(step.id) && step.id === workspaceRoute;
    const button = document.createElement("button");
    button.type = "button";
    button.className = `workflow-step ${step.status}${routeActive ? " active" : ""}`;
    button.textContent = step.id[0].toUpperCase() + step.id.slice(1);
    button.setAttribute("aria-current", routeActive || ((!routes.includes(workspaceRoute)) && step.id === workflow.current) ? "step" : "false");
    button.title = step.id === "review" ? "Review extracted values here" : `Open ${step.id} in this workspace`;
    button.addEventListener("click", () => {
      if (routes.includes(step.id)) {
        workspaceRoute = step.id;
        renderTable();
        return;
      }
      send({ action: "navigate-step", step: step.id });
      setConnection(`Continuing to ${step.id} in the Site2JSON editor.`, "connected");
    });
    els.workflowSteps.append(button);
  }
}

function applyLease(owner) {
  leaseOwner = owner === "sidebar" ? "sidebar" : "expanded";
  const paused = leaseOwner !== "expanded";
  els.leasePaused.hidden = !paused;
  const editingField = Boolean(editor?.fieldEditor);
  const route = editingField ? "field" : workspaceRoute;
  els.empty.hidden = paused || editingField || Boolean(snapshot?.activeBlock);
  els.tableWrap.hidden = paused || route !== "review" || !snapshot?.activeBlock;
  els.reviewWorkspace.hidden = paused || route !== "review" || !snapshot?.activeBlock;
  els.structureRoute.hidden = paused || route !== "structure";
  els.reviewRoute.hidden = paused || route !== "review";
  els.semanticsRoute.hidden = paused || route !== "semantics";
  els.discoverRoute.hidden = paused || route !== "discover";
  els.finishRoute.hidden = paused || route !== "finish";
  els.fieldEditorRoute.hidden = paused || route !== "field";
}

function targetEvents(element, target) {
  element.addEventListener("mouseenter", () => send({ action: "preview-highlight", target }));
  element.addEventListener("mouseleave", () => send({ action: "clear-preview" }));
  element.addEventListener("click", (event) => {
    event.stopPropagation();
    document.querySelectorAll(".pinned").forEach((candidate) => candidate.classList.remove("pinned"));
    element.classList.add("pinned");
    send({ action: "highlight", target });
  });
  element.addEventListener("dblclick", (event) => {
    event.preventDefault();
    event.stopPropagation();
    send({ action: "scroll-to-target", target });
  });
}

function displayed(value) {
  if (value === null || value === undefined || (Array.isArray(value) && value.length === 0)) return { text: "missing", missing: true };
  if (Array.isArray(value)) return { text: value.join(" · "), missing: false };
  if (typeof value === "object") return { text: JSON.stringify(value), missing: false };
  return { text: String(value), missing: false };
}

function valuePresent(value) {
  return value !== null && value !== undefined && value !== "" && (!Array.isArray(value) || value.length > 0);
}

function commandButton(label, title, className, command) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = className;
  button.textContent = label;
  button.title = title;
  button.setAttribute("aria-label", title);
  button.addEventListener("click", (event) => {
    event.stopPropagation();
    if (command.action === "edit-field") {
      returnFocus = { fieldKey: command.fieldKey, scrollTop: els.tableWrap.scrollTop, scrollLeft: els.tableWrap.scrollLeft };
      fieldDraftDirty = false;
    } else if (command.action === "add-selected-field") {
      returnFocus = { fieldKey: null, scrollTop: els.tableWrap.scrollTop, scrollLeft: els.tableWrap.scrollLeft };
      fieldDraftDirty = false;
    }
    send(command);
    if (command.action === "edit-field" || command.action === "add-selected-field") {
      setConnection("Opening the field editor…", "connected");
    }
  });
  return button;
}

function renderTabs() {
  els.blockPicker.replaceChildren();
  for (const block of snapshot?.blocks || []) {
    const option = document.createElement("option");
    option.value = block.id;
    option.textContent = `${block.name} — ${block.schemaType} · ${block.matchCount} matches${block.unresolvedCount ? ` · ${block.unresolvedCount} issues` : ""}`;
    option.selected = block.id === snapshot.activeBlockId;
    els.blockPicker.append(option);
  }
  els.blockPickerLabel.hidden = !(snapshot?.blocks || []).length;
}

function renderIssues() {
  const block = snapshot?.activeBlock;
  if (!block) {
    els.issueSummary.hidden = true;
    return;
  }
  const unresolved = block.fields.filter((field) => field.unresolved).length;
  const incomplete = block.fields.filter((field) => field.required && (snapshot.rows || []).some((row) => !valuePresent(row.values?.[field.name]))).length;
  const missingIdentity = block.fields.some((field) => field.identity) ? 0 : 1;
  const parts = [];
  if (unresolved) parts.push(`${unresolved} unmapped`);
  if (incomplete) parts.push(`${incomplete} required field${incomplete === 1 ? "" : "s"} incomplete`);
  if (missingIdentity) parts.push("canonical identity missing");
  if (snapshot.driftReview?.findings?.length) parts.push(`${snapshot.driftReview.findings.length} structural finding${snapshot.driftReview.findings.length === 1 ? "" : "s"}`);
  els.issueSummary.textContent = parts.length ? `Review: ${parts.join(" · ")}` : "";
  els.issueSummary.hidden = parts.length === 0;
}

function renderDriftReview() {
  const review = snapshot?.driftReview || { status: "idle", findings: [], message: "" };
  const canCheck = Boolean(editor?.finish?.canCheckStructuralHealth);
  els.driftReview.hidden = !canCheck && review.status === "idle";
  els.driftReviewCheck.disabled = !canCheck || review.status === "checking";
  els.driftReviewCheck.textContent = review.status === "checking" ? "Checking…" : "Check page";
  els.driftReviewSummary.textContent = review.message || (canCheck
    ? "Check the rendered page against its saved baseline."
    : "Validate the adapter in Finish to capture a baseline first.");
  els.driftReviewList.replaceChildren();
  for (const finding of review.findings || []) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = `drift-finding ${finding.severity || "warning"}`;
    const severity = document.createElement("span");
    severity.className = "drift-severity";
    severity.textContent = finding.severity === "error" ? "Error" : finding.severity === "strong-warning" ? "Strong warning" : "Warning";
    const content = document.createElement("span");
    const title = document.createElement("strong");
    title.textContent = finding.title;
    const detail = document.createElement("small");
    detail.textContent = finding.message;
    content.append(title, detail);
    const action = document.createElement("span");
    action.className = "drift-finding-action";
    action.textContent = finding.fieldKey ? "Review field →" : "Show block →";
    row.append(severity, content, action);
    row.addEventListener("mouseenter", () => finding.target && send({ action: "preview-highlight", target: finding.target }));
    row.addEventListener("mouseleave", () => send({ action: "clear-preview" }));
    row.addEventListener("click", (event) => {
      event.stopPropagation();
      send({ action: "open-structural-finding", finding });
    });
    els.driftReviewList.append(row);
  }
}

function populateOptions(list, values, valueKey, label) {
  list.replaceChildren();
  for (const candidate of values || []) {
    const option = document.createElement("option");
    option.value = candidate[valueKey];
    option.label = label(candidate);
    list.append(option);
  }
}

function expandedFieldForm() {
  const field = editor?.fieldEditor;
  return {
    selector: els.fieldSelector.value,
    name: els.fieldName.value,
    kind: els.fieldKind.value,
    attribute: els.fieldAttribute.value,
    multiple: els.fieldMultiple.checked,
    identity: els.fieldIdentity.checked,
    required: els.fieldRequired.checked,
    pipeline: transformPicker.clonePipeline(localPipeline),
    customTerm: field?.customTerm || !els.customTermFields.hidden ? {
      description: els.customTermDescription.value,
      valueType: els.customTermValueType.value,
      example: els.customTermExample.value
    } : null
  };
}

let pendingSemanticDefaults = false;

function markFieldDirty() {
  fieldDraftDirty = true;
  els.fieldEditorStatus.textContent = "Unsaved changes in this expanded editor.";
  els.fieldEditorStatus.className = "editor-status";
}

function scheduleLivePreview({ semanticDefaults = false, pipelineEdited = false } = {}) {
  if (!editor?.fieldEditor) return;
  markFieldDirty();
  pendingSemanticDefaults = pipelineEdited ? false : (pendingSemanticDefaults || semanticDefaults);
  clearTimeout(livePreviewTimer);
  livePreviewTimer = setTimeout(() => {
    const chooseSemanticDefaults = pendingSemanticDefaults;
    pendingSemanticDefaults = false;
    send({ action: "preview-field-form", form: expandedFieldForm(), chooseSemanticDefaults });
  }, 160);
}

function closeSuggestionMenu(menu, input) {
  menu.hidden = true;
  input.setAttribute("aria-expanded", "false");
}

function renderFieldNameOptions({ showAll = false } = {}) {
  const field = editor?.fieldEditor;
  if (!field || els.fieldIdentity.checked) return closeSuggestionMenu(els.fieldNameOptions, els.fieldName);
  const query = showAll ? "" : els.fieldName.value.trim().toLowerCase();
  let candidates = (field.nameCandidates || []).filter((candidate) => !query || candidate.name.toLowerCase().includes(query));
  const prefix = editor?.currentAdapterId || "";
  if (query && !query.includes(":") && prefix && !candidates.some((candidate) => candidate.name.toLowerCase() === query)) {
    const local = els.fieldName.value.trim().replace(/[^A-Za-z0-9_-]/g, "");
    if (local) candidates = [...candidates, { name: `${prefix}:${local}`, source: "extension", valueType: "Text", description: "Create and document an adapter extension term." }];
  }
  els.fieldNameOptions.replaceChildren();
  for (const candidate of candidates.slice(0, 18)) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "suggestion-option";
    button.setAttribute("role", "option");
    const name = document.createElement("strong");
    name.textContent = candidate.name;
    const detail = document.createElement("small");
    detail.textContent = `${candidate.source === "extension" ? "Adapter extension" : "Schema.org"} · ${candidate.valueType} — ${candidate.description}`;
    button.append(name, detail);
    button.addEventListener("mousedown", (event) => event.preventDefault());
    button.addEventListener("click", () => {
      els.fieldName.value = candidate.name;
      closeSuggestionMenu(els.fieldNameOptions, els.fieldName);
      scheduleLivePreview({ semanticDefaults: true });
    });
    els.fieldNameOptions.append(button);
  }
  els.fieldNameOptions.hidden = candidates.length === 0;
  els.fieldName.setAttribute("aria-expanded", candidates.length ? "true" : "false");
}

function closeTransformOptions() {
  closeSuggestionMenu(els.transformOptions, els.transformSearch);
}

function openTransformArguments(name, index, step = null) {
  const detail = transformCatalog.details(name);
  if (!detail || !transformPicker.editable(name) || detail.maximumArguments === 0) return;
  pendingTransform = { name, index };
  const values = transformPicker.argumentValues(step || { name, args: [] });
  els.transformArgumentsTitle.textContent = `${index < localPipeline.length ? "Edit" : "Add"} ${detail.label}`;
  els.transformArgumentsDescription.textContent = `${detail.input} → ${detail.output}. ${detail.description}`;
  els.transformArgumentFields.replaceChildren();
  detail.argumentDefinitions.forEach((definition, argumentIndex) => {
    const required = argumentIndex < detail.minimumArguments && definition.required !== false;
    const label = document.createElement("label");
    label.textContent = `${definition.label}${required ? "" : " (optional)"}`;
    const input = definition.type === "string-list" || definition.type === "object" ? document.createElement("textarea") : document.createElement("input");
    input.dataset.argumentIndex = String(argumentIndex);
    input.value = values[argumentIndex] || "";
    if (definition.type === "integer") {
      input.type = "number";
      input.step = "1";
      if (definition.minimum !== undefined) input.min = String(definition.minimum);
      if (definition.maximum !== undefined) input.max = String(definition.maximum);
    } else if (input.tagName === "INPUT") input.type = "text";
    const help = document.createElement("small");
    help.textContent = definition.description;
    label.append(input, help);
    els.transformArgumentFields.append(label);
  });
  els.transformArgumentStatus.textContent = "";
  els.transformArguments.hidden = false;
  els.transformArgumentFields.querySelector("input, textarea")?.focus();
}

function closeTransformArguments() {
  pendingTransform = null;
  els.transformArguments.hidden = true;
  els.transformArgumentFields.replaceChildren();
  els.transformArgumentStatus.textContent = "";
}

function renderPipeline() {
  els.fieldPipeline.replaceChildren();
  let locked = 0;
  if (!localPipeline.length) {
    const empty = document.createElement("small");
    empty.textContent = "No transforms selected";
    els.fieldPipeline.append(empty);
  }
  localPipeline.forEach((step, index) => {
    const name = transformPicker.stepName(step);
    const detail = transformCatalog.details(name);
    const isLocked = transformPicker.isLocked(step);
    const configurable = !isLocked && detail?.maximumArguments > 0;
    const token = document.createElement("span");
    token.className = `pipeline-step${isLocked ? " locked" : ""}${configurable ? " configurable" : ""}`;
    token.textContent = transformPicker.formatStep(step);
    if (configurable) {
      token.title = "Click to edit transform arguments.";
      token.addEventListener("click", () => openTransformArguments(name, index, step));
    }
    if (isLocked) {
      locked += 1;
      token.title = "Preserved unchanged because compatible packaged argument metadata is unavailable.";
    } else {
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "×";
      remove.setAttribute("aria-label", `Remove ${name}`);
      remove.addEventListener("click", (event) => {
        event.stopPropagation();
        const result = transformPicker.removeAt(localPipeline, index);
        if (!result.removed) return;
        localPipeline = result.pipeline;
        closeTransformArguments();
        renderPipeline();
        scheduleLivePreview({ pipelineEdited: true });
      });
      token.append(remove);
    }
    els.fieldPipeline.append(token);
  });
  els.transformHelp.textContent = locked
    ? `${locked} transform${locked === 1 ? " is" : "s are"} preserved because compatible packaged argument metadata is unavailable.`
    : "Add packaged transforms in execution order. Click a configured step to edit its arguments.";
}

function renderTransformOptions({ showAll = false } = {}) {
  const query = showAll ? "" : els.transformSearch.value;
  const groups = transformCatalog.grouped(query, { recommended: editor?.fieldEditor?.recommendedTransforms || [] });
  els.transformOptions.replaceChildren();
  for (const group of groups) {
    const heading = document.createElement("div");
    heading.className = "suggestion-group";
    heading.textContent = group.name;
    els.transformOptions.append(heading);
    for (const detail of group.items) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "suggestion-option";
      const label = document.createElement("strong");
      label.textContent = detail.label;
      const description = document.createElement("small");
      description.textContent = `${detail.input} → ${detail.output} · ${detail.description}`;
      button.append(label, description);
      button.addEventListener("mousedown", (event) => event.preventDefault());
      button.addEventListener("click", () => {
        els.transformSearch.value = "";
        closeTransformOptions();
        if (detail.maximumArguments > 0) openTransformArguments(detail.name, localPipeline.length);
        else {
          localPipeline = transformPicker.addZeroArgument(localPipeline, detail.name);
          renderPipeline();
          scheduleLivePreview({ pipelineEdited: true });
        }
      });
      els.transformOptions.append(button);
    }
  }
  els.transformOptions.hidden = groups.length === 0;
  els.transformSearch.setAttribute("aria-expanded", groups.length ? "true" : "false");
}

function renderModelOptions({ showAll = false } = {}) {
  const query = showAll ? "" : els.modelSearch.value;
  const groups = semanticCompositions.choices(query);
  els.modelOptions.replaceChildren();
  for (const [label, choices] of [["Compositions", groups.compositions], ["Schema.org types", groups.types]]) {
    if (!choices.length) continue;
    const heading = document.createElement("div");
    heading.className = "suggestion-group";
    heading.textContent = label;
    els.modelOptions.append(heading);
    for (const choice of choices) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "suggestion-option";
      const title = document.createElement("strong");
      title.textContent = choice.label;
      const detail = document.createElement("small");
      detail.textContent = `${choice.kind === "composition" ? `Composition · ${choice.nodeCount} nodes` : "Schema.org type"} — ${choice.description}`;
      button.append(title, detail);
      button.addEventListener("mousedown", (event) => event.preventDefault());
      button.addEventListener("click", () => {
        els.modelSearch.value = "";
        closeSuggestionMenu(els.modelOptions, els.modelSearch);
        send({ action: "set-semantic-model", modelId: choice.id });
      });
      els.modelOptions.append(button);
    }
  }
  const hasOptions = els.modelOptions.childElementCount > 0;
  els.modelOptions.hidden = !hasOptions;
  els.modelSearch.setAttribute("aria-expanded", hasOptions ? "true" : "false");
}

function renderModelRankings(block) {
  const ranking = block?.semanticRanking;
  els.modelRankings.replaceChildren();
  els.analyzeSemantics.disabled = ranking?.status === "loading";
  if (!ranking || ranking.status !== "ready") {
    els.modelRankingStatus.textContent = ranking?.status === "loading"
      ? "Inspecting recurring values and comparing compatible Schema.org properties…"
      : "Analyze the current repeating scope to rank plausible starting models. Nothing is selected automatically.";
    return;
  }
  const shapes = Object.entries(ranking.shapeSummary || {}).map(([shape, count]) => `${count} ${shape}`).join(" · ");
  els.modelRankingStatus.textContent = `Observed ${ranking.observationCount} recurring value${ranking.observationCount === 1 ? "" : "s"} across ${ranking.sampledScopes}/${ranking.totalScopes} items${shapes ? ` · ${shapes}` : ""}. Scores are relative evidence, not confidence.`;
  const candidates = [...(ranking.compositions || []), ...(ranking.types || [])]
    .sort((left, right) => right.score - left.score || right.explained - left.explained)
    .slice(0, 8);
  for (const candidate of candidates) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "model-ranking";
    const heading = document.createElement("span");
    const name = document.createElement("strong");
    name.textContent = candidate.label;
    const fit = document.createElement("small");
    const related = candidate.supportedNodes?.length ? ` · supports ${candidate.supportedNodes.length} related concept${candidate.supportedNodes.length === 1 ? "" : "s"}` : "";
    fit.textContent = `${candidate.kind === "composition" ? "Composition" : "Schema.org type"} · explains ${candidate.explained}/${candidate.total}${related}`;
    heading.append(name, fit);
    const meter = document.createElement("span");
    meter.className = "ranking-meter";
    const fill = document.createElement("i");
    const maximum = candidates[0]?.score || 1;
    fill.style.width = `${Math.max(4, Math.round((candidate.score / maximum) * 100))}%`;
    meter.append(fill);
    const why = document.createElement("small");
    const evidence = candidate.evidence?.slice(0, 2).map((item) => `${item.observation} → ${item.path}`).join("; ");
    why.textContent = evidence || "Only weak generic compatibility was found.";
    row.append(heading, meter, why);
    row.title = "Use this as the starting semantic model";
    row.addEventListener("click", () => send({ action: "set-semantic-model", modelId: candidate.id }));
    els.modelRankings.append(row);
  }
}

function populateTypeOptions() {
  if (els.relatedTypeOptions.childElementCount) return;
  const fragment = document.createDocumentFragment();
  for (const type of semanticCompositions.typeNames()) {
    const option = document.createElement("option");
    option.value = type;
    fragment.append(option);
  }
  els.relatedTypeOptions.append(fragment);
}

function updateRelationshipOptions() {
  const composition = snapshot?.activeBlock?.composition;
  const source = composition?.nodes?.[els.relatedFrom.value];
  const type = els.relatedType.value.trim();
  const previous = els.relatedProperty.value;
  els.relatedProperty.replaceChildren();
  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = type ? "Choose a compatible relationship…" : "Choose a type first…";
  els.relatedProperty.append(placeholder);
  if (!source || !type) return;
  let options = [];
  try { options = semanticCompositions.relationshipOptions(source.types, type); } catch { /* Invalid types remain visible for correction. */ }
  for (const option of options) {
    const element = document.createElement("option");
    element.value = option.property;
    element.textContent = `${option.property} — ${option.description}`;
    els.relatedProperty.append(element);
  }
  if (options.some((option) => option.property === previous)) els.relatedProperty.value = previous;
  els.relatedNodeStatus.textContent = options.length ? "" : `No range-compatible Schema.org relationship from ${els.relatedFrom.value || "this node"} to ${type}.`;
}

function suggestedAlias(type, nodes) {
  const base = String(type || "node").replace(/^[^A-Za-z]+/, "");
  const initial = base ? base[0].toLowerCase() + base.slice(1) : "node";
  if (!nodes[initial]) return initial;
  let suffix = 2;
  while (nodes[`${initial}${suffix}`]) suffix += 1;
  return `${initial}${suffix}`;
}

function renderCompositionOutline(composition) {
  els.compositionOutline.replaceChildren();
  for (const [alias, node] of Object.entries(composition.nodes || {})) {
    const card = document.createElement("article");
    card.className = `composition-node${alias === composition.root ? " root" : ""}`;
    const heading = document.createElement("div");
    heading.className = "node-heading";
    const title = document.createElement("div");
    const strong = document.createElement("strong");
    strong.textContent = alias;
    const meta = document.createElement("small");
    meta.textContent = `${alias === composition.root ? "root · " : ""}${node.expectation}`;
    title.append(strong, meta);
    heading.append(title);
    if (alias !== composition.root) {
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "node-remove";
      remove.textContent = "×";
      remove.title = `Remove ${alias} and any now-unreachable descendants`;
      remove.addEventListener("click", () => send({ action: "remove-semantic-node", alias }));
      heading.append(remove);
    }
    const pills = document.createElement("div");
    pills.className = "type-pills";
    for (const type of node.types) {
      const pill = document.createElement("span");
      pill.className = "type-pill";
      pill.append(document.createTextNode(type));
      if (node.types.length > 1) {
        const remove = document.createElement("button");
        remove.type = "button";
        remove.textContent = "×";
        remove.title = `Remove ${type} from ${alias}`;
        remove.addEventListener("click", () => send({ action: "remove-semantic-type", alias, type }));
        pill.append(remove);
      }
      pills.append(pill);
    }
    const addType = document.createElement("div");
    addType.className = "node-add-type";
    const input = document.createElement("input");
    input.className = "node-type-input";
    input.setAttribute("list", "related-type-options");
    input.placeholder = "Add another @type…";
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "+ Type";
    button.addEventListener("click", () => {
      const type = input.value.trim();
      if (type) send({ action: "add-semantic-type", alias, type });
    });
    addType.append(input, button);
    const outgoing = (composition.edges || []).filter((edge) => edge.from === alias);
    const edges = document.createElement("div");
    edges.className = "node-edges";
    for (const edge of outgoing) {
      const row = document.createElement("div");
      row.className = "composition-edge";
      const line = document.createElement("span");
      line.className = "edge-line";
      const text = document.createElement("span");
      const property = document.createElement("code");
      property.textContent = edge.property;
      text.append(property, document.createTextNode(` → ${edge.to} · ${edge.expectation}`));
      row.append(line, text);
      edges.append(row);
    }
    card.append(heading, pills, addType, edges);
    els.compositionOutline.append(card);
  }
}

function renderSemantics() {
  if (workspaceRoute !== "semantics") return;
  const block = snapshot?.activeBlock;
  const composition = block?.composition;
  populateTypeOptions();
  if (!block || !composition) {
    els.semanticsContext.textContent = "Create or select a repeating block first.";
    els.compositionOutline.replaceChildren();
    els.semanticsDone.disabled = true;
    return;
  }
  els.semanticsContext.textContent = `${block.name} · ${block.matchCount} matches`;
  els.modelCurrent.textContent = `${composition.label} · ${Object.keys(composition.nodes).length} node${Object.keys(composition.nodes).length === 1 ? "" : "s"}${block.semanticsReviewed ? " · reviewed" : " · modified"}`;
  const validation = block.compositionValidation || semanticCompositions.validate(composition);
  const messages = [...(validation.errors || []), ...(validation.warnings || [])];
  els.compositionStatus.textContent = messages.length ? messages.join(" ") : "Valid connected semantic graph. Composition data is authoring-only until compiled into explicit adapter mappings.";
  els.compositionStatus.className = `composition-status ${validation.ok ? (validation.warnings?.length ? "warning" : "") : "error"}`.trim();
  els.semanticsDone.disabled = !validation.ok;
  renderModelRankings(block);
  renderCompositionOutline(composition);
  const previousSource = els.relatedFrom.value;
  els.relatedFrom.replaceChildren();
  for (const alias of Object.keys(composition.nodes)) {
    const option = document.createElement("option");
    option.value = alias;
    option.textContent = `${alias} · ${composition.nodes[alias].types.join(" + ")}`;
    els.relatedFrom.append(option);
  }
  if (composition.nodes[previousSource]) els.relatedFrom.value = previousSource;
  updateRelationshipOptions();
}

function renderDiscover() {
  if (workspaceRoute !== "discover") return;
  const block = snapshot?.activeBlock;
  if (!block) {
    els.discoverContext.textContent = "Create or select a repeating block first.";
    els.discoverRun.disabled = true;
    els.discoverUndo.disabled = true;
    els.discoverCounts.replaceChildren();
    return;
  }
  const discovery = block.discovery || {};
  const loading = discovery.report?.kind === "loading";
  els.discoverContext.textContent = `${block.name} · ${block.matchCount} rendered items`;
  els.discoverIncludeUnmapped.checked = discovery.includeUnmapped !== false;
  els.discoverRun.disabled = loading;
  els.discoverRun.textContent = loading ? "Discovering…" : "Discover fields";
  els.discoverUndo.disabled = loading || !discovery.canUndo;
  els.discoverReport.textContent = discovery.report?.message || "No discovery run has been recorded for this block.";
  els.discoverReport.className = `discover-report ${discovery.report?.kind || ""}`.trim();
  const fields = block.fields || [];
  const metrics = [
    ["Fields", fields.length],
    ["Mapped", fields.filter((field) => !field.unresolved).length],
    ["Unmapped", fields.filter((field) => field.unresolved).length],
    ["Identity", fields.some((field) => field.identity) ? "present" : "missing"]
  ];
  els.discoverCounts.replaceChildren();
  for (const [label, value] of metrics) {
    const item = document.createElement("div");
    const strong = document.createElement("strong");
    strong.textContent = String(value);
    const small = document.createElement("small");
    small.textContent = label;
    item.append(strong, small);
    els.discoverCounts.append(item);
  }
}

function renderStructure() {
  if (workspaceRoute !== "structure") return;
  const structure = snapshot?.structure || {};
  const selection = structure.selection;
  if (selection?.ok) {
    const summary = selection.summary || {};
    const details = [
      `<${summary.tag || "element"}>`,
      summary.id ? `#${summary.id}` : "",
      ...(summary.classes || []).slice(0, 4).map((name) => `.${name}`)
    ].filter(Boolean).join(" ");
    els.structureSelection.textContent = `${details}${summary.text ? ` — ${summary.text}` : ""}`;
  } else {
    els.structureSelection.textContent = selection?.message || "No element selected. Choose one rendered result in Elements.";
  }
  els.structureInfer.disabled = !selection?.ok || Boolean(selection?.shadowBoundary);
  els.structureAutomatic.disabled = !editor?.finish?.canInferRemaining;
  els.structureInfer.textContent = els.structureSingleItem.checked
    ? "Infer single item"
    : (snapshot?.blocks || []).length ? "Infer another repeating scope" : "Infer repeating scope";
  const automaticStatus = "";
  els.structureStatus.textContent = automaticStatus || structure.status || "";
  els.structureStatus.className = `structure-status ${automaticStatus ? (editor.finish.buildStatusKind || "") : (structure.statusKind || "")}`.trim();
  els.scopeProposals.replaceChildren();
  for (const proposal of structure.proposals || []) {
    const item = document.createElement("article");
    item.className = `scope-proposal${proposal.selected ? " selected" : ""}`;
    const heading = document.createElement("div");
    const selector = document.createElement("code");
    selector.textContent = proposal.selector;
    const meta = document.createElement("small");
    meta.textContent = `${proposal.matchCount} matches · <${proposal.tag}> · ${proposal.kind}`;
    heading.append(selector, meta);
    const findings = document.createElement("ul");
    for (const finding of proposal.findings || []) {
      const row = document.createElement("li");
      row.textContent = `${finding.kind === "good" ? "✓" : "⚠"} ${finding.message}`;
      findings.append(row);
    }
    if (proposal.recommendation?.confidence === "high") {
      const row = document.createElement("li");
      row.textContent = `✓ Semantic suggestion: ${proposal.recommendation.label} (${proposal.recommendation.explained}/${proposal.recommendation.total} observations explained).`;
      findings.append(row);
    }
    const use = document.createElement("button");
    use.type = "button";
    use.textContent = "Use this scope";
    use.addEventListener("click", () => send({ action: "accept-scope", selector: proposal.selector }));
    item.append(heading, findings, use);
    item.addEventListener("mouseenter", () => send({ action: "preview-highlight", target: { selector: proposal.selector } }));
    item.addEventListener("mouseleave", () => send({ action: "clear-preview" }));
    item.addEventListener("click", (event) => {
      if (!event.target.closest("button")) send({ action: "preview-scope", index: proposal.index });
    });
    els.scopeProposals.append(item);
  }
  els.scopeProposalsCard.hidden = !(structure.proposals || []).length || Boolean(structure.pendingScope);
  const pending = structure.pendingScope;
  els.structureBlockForm.hidden = !pending;
  if (pending) {
    els.structureAcceptedScope.textContent = `${pending.selector} · ${pending.matchCount} matches`;
    if (!els.structureBlockForm.contains(document.activeElement)) {
      els.structureBlockName.value = structure.blockName || "Results";
      els.structureSchemaType.value = structure.schemaType || "Thing";
    }
  }
  if (!els.structureSchemaTypes.children.length) {
    for (const type of globalThis.Site2JsonSchemaVocabulary.typeNames()) {
      const option = document.createElement("option");
      option.value = type;
      els.structureSchemaTypes.append(option);
    }
  }
}

function advanceFromCompletedStructureCreate() {
  if (!advanceAfterStructureCreate || !snapshot?.activeBlock) return;
  advanceAfterStructureCreate = false;
  workspaceRoute = "semantics";
}

function finishMetadata() {
  return {
    adapterId: els.finishAdapterId.value.trim(),
    namespace: els.finishNamespace.value.trim(),
    pageId: els.finishPageId.value.trim() || "collection",
    pageType: els.finishPageType.value.trim() || "CollectionPage"
  };
}

function renderFinish() {
  if (workspaceRoute !== "finish") return;
  const finish = editor?.finish || {};
  if (!els.finishMetadata.contains(document.activeElement)) {
    els.finishAdapterId.value = finish.adapterId || "";
    els.finishNamespace.value = finish.namespace || "";
    els.finishPageId.value = finish.pageId || "collection";
    els.finishPageType.value = finish.pageType || "CollectionPage";
  }
  els.finishBuild.disabled = !snapshot?.activeBlock;
  els.finishRefreshBaseline.disabled = !snapshot?.activeBlock;
  els.finishCaptureFixture.disabled = !finish.canCaptureFixture;
  els.finishPreview.disabled = !finish.valid;
  els.finishSave.disabled = !finish.canSave;
  els.finishExport.disabled = !finish.canExport;
  els.finishPublish.disabled = !finish.canPublish;
  els.finishBuildStatus.textContent = finish.buildStatus || "Validate the current draft before previewing or publishing it.";
  els.finishBuildStatus.className = `finish-status ${finish.buildStatusKind || ""}`.trim();
  els.finishDraftStatus.textContent = finish.draftStatus || "";
  els.finishDraftStatus.className = `finish-status ${finish.draftStatusKind || ""}`.trim();
  els.finishPreviewOutput.textContent = finish.preview || "";
  els.finishPreviewWrap.hidden = !finish.preview;
}

function renderFieldEditor() {
  const field = editor?.fieldEditor || null;
  if (!field) {
    if (fieldEditorKey !== null && returnFocus) {
      els.tableWrap.scrollTop = returnFocus.scrollTop;
      els.tableWrap.scrollLeft = returnFocus.scrollLeft;
      const row = returnFocus.fieldKey
        ? Array.from(els.tableBody.querySelectorAll("tr[data-field-key]")).find((candidate) => candidate.dataset.fieldKey === returnFocus.fieldKey)
        : els.tableBody.querySelector(".add-field-row");
      row?.classList.add("return-focus");
      row?.scrollIntoView({ block: "nearest" });
      setTimeout(() => row?.classList.remove("return-focus"), 1400);
    }
    fieldEditorKey = null;
    fieldDraftDirty = false;
    localPipeline = [];
    clearTimeout(livePreviewTimer);
    closeTransformOptions();
    closeTransformArguments();
    applyLease(leaseOwner);
    return;
  }
  const changedField = fieldEditorKey !== field.key;
  const customWasHidden = els.customTermFields.hidden;
  if (changedField || !fieldDraftDirty) {
    fieldEditorKey = field.key;
    els.fieldSelector.value = field.selector || "";
    els.fieldName.value = field.name || "";
    els.fieldKind.value = field.kind || "text";
    els.fieldAttribute.value = field.attribute || "";
    els.fieldMultiple.checked = Boolean(field.multiple);
    els.fieldIdentity.checked = Boolean(field.identity);
    els.fieldRequired.checked = Boolean(field.required);
    if (field.customTerm) {
      els.customTermDescription.value = field.customTerm.description || "";
      els.customTermValueType.value = field.customTerm.valueType || "Text";
      els.customTermExample.value = field.customTerm.example || "";
    }
  }
  els.fieldEditorTitle.textContent = field.title || "Edit field";
  els.fieldEditorContext.textContent = field.context || "";
  els.fieldEditorStatus.textContent = fieldDraftDirty ? "Unsaved changes in this expanded editor." : (field.status || "");
  els.fieldEditorStatus.className = `editor-status ${fieldDraftDirty ? "" : (field.statusKind || "")}`.trim();
  els.fieldSelectorEvidence.textContent = field.selectorEvidence || "";
  populateOptions(els.fieldSelectorOptions, field.selectorCandidates, "selector", (candidate) => `${candidate.kind} · ${candidate.matchCount} matches`);
  els.fieldSemanticStatus.textContent = field.semanticStatus || "";
  els.fieldSemanticStatus.parentElement.classList.toggle("error", field.semanticKind === "error");
  els.customTermFields.hidden = !field.customTerm;
  if (field.customTerm && customWasHidden) {
    els.customTermDescription.value = field.customTerm.description || "";
    els.customTermValueType.value = field.customTerm.valueType || "Text";
    els.customTermExample.value = field.customTerm.example || "";
  }
  localPipeline = transformPicker.clonePipeline(field.pipeline || []);
  renderPipeline();
  els.selectionProposal.hidden = !field.proposal;
  if (field.proposal) {
    els.selectionProposalSummary.textContent = field.proposal.summary || "";
    els.selectionProposalSelector.textContent = field.proposal.selector || "";
    els.selectionProposalCoverage.textContent = field.proposal.coverage || "";
  }
  els.fieldPreview.textContent = field.preview || "";
  els.fieldSave.textContent = field.submitLabel || "Save field";
  applyLease(leaseOwner);
}

function scrollTableTargetIntoView(target) {
  if (!target) return;
  const wrap = els.tableWrap;
  const sticky = els.tableHead.querySelector("th:first-child");
  const stickyWidth = sticky?.offsetWidth || 0;
  const headerHeight = els.tableHead.offsetHeight || 0;
  const top = target.offsetTop;
  const bottom = top + target.offsetHeight;
  if (top < wrap.scrollTop + headerHeight) wrap.scrollTop = Math.max(0, top - headerHeight);
  else if (bottom > wrap.scrollTop + wrap.clientHeight) wrap.scrollTop = Math.max(0, bottom - wrap.clientHeight);

  if (target.dataset.rootIndex === undefined) return;
  const left = target.offsetLeft;
  const right = left + target.offsetWidth;
  const visibleLeft = wrap.scrollLeft + stickyWidth;
  const visibleRight = wrap.scrollLeft + wrap.clientWidth;
  if (left < visibleLeft) wrap.scrollLeft = Math.max(0, left - stickyWidth);
  else if (right > visibleRight) wrap.scrollLeft = Math.max(0, right - wrap.clientWidth);
}

function applySelectionFocus() {
  document.querySelectorAll(".elements-selection").forEach((element) => element.classList.remove("elements-selection"));
  const focus = selectionFocus;
  if (!focus || !focus.ok || focus.blockId !== snapshot?.activeBlockId) {
    if (focus?.reason === "outside-scope") setConnection(`Selected <${focus.selected?.tag || "element"}> is outside the known repeating scopes.`, "stale");
    return;
  }
  const matches = focus.fieldMatches || [];
  const strongestMode = matches[0]?.mode || null;
  const strongestMatches = matches.filter((match) => match.mode === strongestMode);
  const unambiguousField = !focus.isScopeRoot && strongestMatches.length === 1 ? strongestMatches[0] : null;
  const fieldKey = unambiguousField?.key || null;
  const fieldRow = fieldKey
    ? Array.from(els.tableBody.querySelectorAll("tr[data-field-key]")).find((row) => row.dataset.fieldKey === fieldKey)
    : null;
  const targets = [];
  if (fieldRow) {
    targets.push(fieldRow.querySelector(`[data-root-index="${focus.rootIndex}"]`) || fieldRow.querySelector("td"));
  } else if (focus.isScopeRoot) {
    targets.push(els.tableHead.querySelector(`[data-root-index="${focus.rootIndex}"]`));
  } else if (strongestMatches.length > 1) {
    for (const match of strongestMatches) {
      const row = Array.from(els.tableBody.querySelectorAll("tr[data-field-key]")).find((candidate) => candidate.dataset.fieldKey === match.key);
      const cell = row?.querySelector(`[data-root-index="${focus.rootIndex}"]`);
      if (cell) targets.push(cell);
    }
  }
  for (const target of targets) target?.classList.add("elements-selection");
  scrollTableTargetIntoView(targets[0]);
  const field = snapshot.activeBlock.fields.find((candidate) => candidate.key === fieldKey);
  setConnection(field
    ? `Elements selection · ${field.label} · item ${focus.rootIndex + 1}`
    : strongestMatches.length > 1
      ? `Selected <${focus.selected?.tag || "element"}> in item ${focus.rootIndex + 1} · contains ${strongestMatches.length} mapped fields`
      : `Selected <${focus.selected?.tag || "element"}> in item ${focus.rootIndex + 1} · not mapped`, field ? "connected" : "stale");
}

function renderTable() {
  els.tableHead.replaceChildren();
  els.tableBody.replaceChildren();
  const block = snapshot?.activeBlock;
  const rows = snapshot?.rows || [];
  renderTabs();
  renderIssues();
  renderDriftReview();
  renderWorkflow();
  renderStructure();
  renderSemantics();
  renderDiscover();
  renderFinish();
  els.pageLabel.textContent = snapshot?.pageUrl || "Extraction table";
  els.blockHeading.textContent = block ? `${block.schemaType} · ${block.matchCount} matches` : "";
  if (!block) {
    els.tableWrap.hidden = true;
    els.empty.hidden = leaseOwner !== "expanded";
    els.empty.textContent = connected ? "Create or open an extraction block in the Site2JSON editor." : "Open the Site2JSON editor to connect this workspace.";
    renderFieldEditor();
    return;
  }

  els.empty.hidden = true;
  els.tableWrap.hidden = leaseOwner !== "expanded";
  const examples = rows;
  const headRow = document.createElement("tr");
  const fieldHead = document.createElement("th");
  fieldHead.textContent = `Field · ${block.fields.length}`;
  targetEvents(fieldHead, { selector: block.scope });
  headRow.append(fieldHead);
  for (const example of examples) {
    const th = document.createElement("th");
    th.dataset.rootIndex = String(example.index);
    th.textContent = String(example.index + 1);
    th.title = `Rendered item ${example.index + 1}`;
    targetEvents(th, { selector: block.scope, matchIndex: example.index });
    headRow.append(th);
  }
  els.tableHead.append(headRow);

  for (const field of block.fields) {
    const tr = document.createElement("tr");
    tr.dataset.fieldKey = field.key;
    const fieldCell = document.createElement("td");
    if (field.unresolved) fieldCell.classList.add("unresolved");
    if (field.identity) fieldCell.classList.add("identity");
    fieldCell.title = `${field.selector}${field.attribute ? `@${field.attribute}` : ""}${field.unresolved ? " — Unmapped" : ""}`;
    const header = document.createElement("div");
    header.className = "field-header";
    const fieldInfo = document.createElement("span");
    fieldInfo.className = "field-label";
    const label = document.createElement("span");
    label.textContent = field.label;
    if (field.identity) {
      const badge = document.createElement("small");
      badge.className = "identity-field-badge";
      badge.textContent = "identity";
      label.append(" ", badge);
    }
    const coverage = document.createElement("small");
    coverage.className = "field-coverage";
    const present = rows.filter((row) => valuePresent(row.values?.[field.name])).length;
    coverage.textContent = `${present}/${rows.length} present${field.unresolved ? " · unmapped" : ""}`;
    fieldInfo.append(label, coverage);
    const actions = document.createElement("span");
    actions.className = "field-actions";
    actions.append(
      commandButton("✎", `Edit ${field.label}`, "field-action edit", { action: "edit-field", fieldKey: field.key, identity: field.identity }),
      commandButton("🗑", `Remove ${field.label}`, "field-action remove", { action: "remove-field", fieldKey: field.key, identity: field.identity })
    );
    header.append(fieldInfo, actions);
    fieldCell.append(header);
    targetEvents(fieldCell, { withinSelector: block.scope, selector: field.selector });
    tr.append(fieldCell);
    for (const row of examples) {
      const cell = document.createElement("td");
      cell.dataset.rootIndex = String(row.index);
      const value = displayed(row.values?.[field.name]);
      cell.textContent = value.text;
      cell.title = value.text;
      if (value.missing) cell.classList.add("missing");
      if (field.unresolved) cell.classList.add("unresolved");
      targetEvents(cell, { withinSelector: block.scope, rootIndex: row.index, selector: field.selector });
      tr.append(cell);
    }
    els.tableBody.append(tr);
  }
  const addRow = document.createElement("tr");
  addRow.className = "add-field-row";
  const addCell = document.createElement("td");
  addCell.colSpan = examples.length + 1;
  addCell.append(commandButton("+ Add selected field", "Add the selected element as a field", "add-button", { action: "add-selected-field" }));
  addRow.append(addCell);
  els.tableBody.append(addRow);
  applySelectionFocus();
  renderFieldEditor();
  applyLease(leaseOwner);
}

async function connect() {
  if ((!Number.isInteger(tabId) || tabId < 0) && chrome.tabs?.query) {
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = active?.id;
  }
  if (!Number.isInteger(tabId) || tabId < 0) {
    setConnection("This panel was not opened for an inspected tab.", "error");
    return;
  }
  port = chrome.runtime.connect({ name: `site2json-table:${tabId}` });
  port.onMessage.addListener((message) => {
    if (message?.type === "relay-status") {
      connected = Boolean(message.sidebarConnected && message.controllerConnected !== false);
      if (!connected) snapshot = null;
      setConnection(connected ? "Connected to the Site2JSON editor." : "Open the Site2JSON editor to connect.", connected ? "connected" : "error");
      renderTable();
    } else if (message?.type === "table-snapshot") {
      snapshot = message.snapshot;
      advanceFromCompletedStructureCreate();
      if (snapshot?.stale) setConnection("The inspected page navigated. Waiting for a fresh table.", "stale");
      else if (connected) setConnection(`Connected · ${snapshot?.rows?.length || 0} rendered rows`, "connected");
      renderTable();
    } else if (message?.type === "selection-focus") {
      selectionFocus = message.focus || null;
      applySelectionFocus();
    } else if (message?.type === "controller-state") {
      if (Object.prototype.hasOwnProperty.call(message, "snapshot")) snapshot = message.snapshot;
      if (Object.prototype.hasOwnProperty.call(message, "editor")) editor = message.editor;
      if (Object.prototype.hasOwnProperty.call(message, "selectionFocus")) selectionFocus = message.selectionFocus;
      workflow = message.workflow || workflow;
      if (message.lastCommandResult?.ok === false) advanceAfterStructureCreate = false;
      advanceFromCompletedStructureCreate();
      applyLease(message.lease?.owner);
      if (message.lastCommandResult?.ok === false) setConnection(message.lastCommandResult.error || "The editor command failed.", "error");
      renderTable();
    } else if (message?.type === "command-rejected") {
      advanceAfterStructureCreate = false;
      const reasons = {
        "inactive-surface": "This workspace is not the active editor. Resume it before making changes.",
        "command-pending": "The previous editor action is still running.",
        "invalid-command": "That editor action was not recognized."
      };
      setConnection(reasons[message.reason] || "The editor action was rejected.", "error");
    } else if (message?.type === "clear-pinned-state") {
      document.querySelectorAll(".pinned").forEach((candidate) => candidate.classList.remove("pinned"));
    }
  });
  port.onDisconnect.addListener(() => {
    port = null;
    connected = false;
    snapshot = null;
    editor = null;
    selectionFocus = null;
    setConnection("The editor relay disconnected. Close and reopen this panel.", "error");
    renderTable();
  });
  sendProtocol({ type: "controller-request-state" });
  clearInterval(heartbeat);
  heartbeat = setInterval(() => sendProtocol({ type: "workspace-heartbeat" }), 15_000);
}

els.refresh.addEventListener("click", () => send({ action: "refresh" }));
els.driftReviewCheck.addEventListener("click", () => send({ action: "check-structural-health" }));
els.blockPicker.addEventListener("change", () => send({ action: "activate-block", blockId: els.blockPicker.value }));
els.clearHighlight.addEventListener("click", () => {
  document.querySelectorAll(".pinned").forEach((candidate) => candidate.classList.remove("pinned"));
  send({ action: "clear-highlight" });
});
els.resumeExpanded.addEventListener("click", () => sendProtocol({ type: "lease-command", owner: "expanded" }));
els.structureAutomatic.addEventListener("click", () => send({ action: "infer-remaining" }));
els.structureInfer.addEventListener("click", () => send({ action: "infer-scope", allowSingle: els.structureSingleItem.checked }));
els.structureSingleItem.addEventListener("change", renderStructure);
els.structureScanPage.addEventListener("click", () => send({ action: "find-page-scopes" }));
els.structureCancel.addEventListener("click", () => send({ action: "cancel-scope" }));
els.structureBlockForm.addEventListener("submit", (event) => {
  event.preventDefault();
  advanceAfterStructureCreate = true;
  send({
    action: "create-block",
    name: els.structureBlockName.value.trim(),
    schemaType: els.structureSchemaType.value.trim()
  });
});
els.modelSearch.addEventListener("focus", () => renderModelOptions({ showAll: true }));
els.modelSearch.addEventListener("input", () => renderModelOptions());
els.modelSearch.addEventListener("blur", () => setTimeout(() => closeSuggestionMenu(els.modelOptions, els.modelSearch), 100));
els.analyzeSemantics.addEventListener("click", () => send({ action: "analyze-semantics" }));
els.discoverRun.addEventListener("click", () => send({ action: "discover-fields", includeUnmapped: els.discoverIncludeUnmapped.checked }));
els.discoverUndo.addEventListener("click", () => send({ action: "undo-discovery" }));
els.discoverReview.addEventListener("click", () => {
  workspaceRoute = "review";
  renderTable();
});
for (const input of els.finishMetadata.querySelectorAll("input")) {
  input.addEventListener("change", () => send({ action: "update-finish-metadata", metadata: finishMetadata() }));
}
els.finishBuild.addEventListener("click", () => send({ action: "build-draft", metadata: finishMetadata() }));
els.finishRefreshBaseline.addEventListener("click", () => send({ action: "refresh-structural-baseline", metadata: finishMetadata() }));
els.finishCaptureFixture.addEventListener("click", () => send({ action: "capture-fixture" }));
els.finishPreview.addEventListener("click", () => send({ action: "preview-extraction" }));
els.finishSave.addEventListener("click", () => send({ action: "save-draft" }));
els.finishExport.addEventListener("click", () => send({ action: "export-draft" }));
els.finishPublish.addEventListener("click", () => send({ action: "publish-draft" }));
els.relatedFrom.addEventListener("change", updateRelationshipOptions);
els.relatedType.addEventListener("input", () => {
  const composition = snapshot?.activeBlock?.composition;
  if (composition && !els.relatedAlias.value) els.relatedAlias.value = suggestedAlias(els.relatedType.value.trim(), composition.nodes);
  updateRelationshipOptions();
});
els.addRelatedNode.addEventListener("click", () => {
  const command = {
    action: "add-semantic-node",
    from: els.relatedFrom.value,
    type: els.relatedType.value.trim(),
    property: els.relatedProperty.value,
    alias: els.relatedAlias.value.trim(),
    expectation: els.relatedExpectation.value
  };
  if (!command.type || !command.property || !command.alias) {
    els.relatedNodeStatus.textContent = "Choose a destination type, relationship, and node alias.";
    return;
  }
  els.relatedNodeStatus.textContent = "";
  send(command);
  els.relatedType.value = "";
  els.relatedAlias.value = "";
});
els.semanticsDone.addEventListener("click", () => send({ action: "finish-semantics" }));
function cancelExpandedField() {
  clearTimeout(livePreviewTimer);
  pendingSemanticDefaults = false;
  fieldDraftDirty = false;
  send({ action: "cancel-field" });
}
els.fieldEditorBack.addEventListener("click", cancelExpandedField);
els.fieldCancel.addEventListener("click", cancelExpandedField);
els.useSelectionProposal.addEventListener("click", () => {
  clearTimeout(livePreviewTimer);
  pendingSemanticDefaults = false;
  fieldDraftDirty = false;
  send({ action: "use-selection-proposal" });
});
els.fieldSelector.addEventListener("input", () => scheduleLivePreview());
els.fieldName.addEventListener("focus", () => renderFieldNameOptions({ showAll: true }));
els.fieldName.addEventListener("input", () => {
  renderFieldNameOptions();
  scheduleLivePreview({ semanticDefaults: true });
});
els.fieldName.addEventListener("blur", () => setTimeout(() => closeSuggestionMenu(els.fieldNameOptions, els.fieldName), 100));
els.fieldKind.addEventListener("change", () => scheduleLivePreview({ semanticDefaults: true }));
els.fieldAttribute.addEventListener("input", () => scheduleLivePreview());
els.fieldMultiple.addEventListener("change", () => scheduleLivePreview());
els.fieldIdentity.addEventListener("change", () => scheduleLivePreview({ semanticDefaults: true }));
els.fieldRequired.addEventListener("change", () => scheduleLivePreview());
for (const input of [els.customTermDescription, els.customTermValueType, els.customTermExample]) {
  input.addEventListener("input", () => scheduleLivePreview());
  input.addEventListener("change", () => scheduleLivePreview());
}
els.transformSearch.addEventListener("focus", () => renderTransformOptions({ showAll: true }));
els.transformSearch.addEventListener("input", () => renderTransformOptions());
els.transformSearch.addEventListener("blur", () => setTimeout(closeTransformOptions, 100));
els.transformArgumentsCancel.addEventListener("click", closeTransformArguments);
els.transformArgumentsSave.addEventListener("click", () => {
  if (!pendingTransform) return;
  const values = Array.from(els.transformArgumentFields.querySelectorAll("[data-argument-index]"), (input) => input.value);
  try {
    const step = transformPicker.parseArguments(pendingTransform.name, values);
    localPipeline = transformPicker.setAt(localPipeline, pendingTransform.index, step);
    closeTransformArguments();
    renderPipeline();
    scheduleLivePreview({ pipelineEdited: true });
  } catch (error) {
    els.transformArgumentStatus.textContent = error.message;
  }
});
els.fieldEditorForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const field = editor?.fieldEditor;
  if (!field) return;
  clearTimeout(livePreviewTimer);
  const chooseSemanticDefaults = pendingSemanticDefaults;
  pendingSemanticDefaults = false;
  fieldDraftDirty = false;
  send({ action: "save-field-form", form: expandedFieldForm(), chooseSemanticDefaults });
});
window.addEventListener("pagehide", () => clearInterval(heartbeat));
connect();
