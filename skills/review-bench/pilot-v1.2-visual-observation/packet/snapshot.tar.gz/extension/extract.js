(function initializeRuntime(root, factory) {
  "use strict";
  const model = root.Site2JsonModel || (typeof require === "function" ? require("./core/model") : null);
  const dsl = root.Site2JsonDsl || (typeof require === "function" ? require("./core/dsl") : null);
  const api = factory(model, dsl);
  root.Site2JsonRuntime = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function runtimeFactory(model, dsl) {
  "use strict";

  function extract(definitions, document, location) {
    try {
      if (!Array.isArray(definitions) || definitions.length === 0) return { ok: false, reason: "no-adapters" };
      const adapters = definitions.map((definition) => ({ ...dsl.compile(definition), source: "local-file" }));
      return model.extract(adapters, document, location);
    } catch (error) {
      return {
        ok: false,
        reason: "extraction-error",
        message: error instanceof Error ? error.message : "Unknown extraction error"
      };
    }
  }

  return { extract };
});
