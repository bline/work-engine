"use strict";

const params = new URLSearchParams(location.search);
let tabId = Number(params.get("tabId"));
let selectedFrameId = 0;
let selection = null;

const els = {
  statusDot: document.querySelector("#status-dot"),
  statusTitle: document.querySelector("#status-title"),
  statusDetail: document.querySelector("#status-detail"),
  start: document.querySelector("#start-picker"),
  cancel: document.querySelector("#cancel-picker"),
  card: document.querySelector("#selection-card"),
  elementName: document.querySelector("#element-name"),
  frameLabel: document.querySelector("#frame-label"),
  openingTag: document.querySelector("#opening-tag"),
  text: document.querySelector("#element-text"),
  scopeSelectorRow: document.querySelector("#scope-selector-row"),
  scopeMatchRow: document.querySelector("#scope-match-row"),
  scopeSelector: document.querySelector("#scope-selector"),
  scopeMatchCount: document.querySelector("#scope-match-count"),
  selector: document.querySelector("#selector"),
  matchCount: document.querySelector("#match-count"),
  reselect: document.querySelector("#reselect")
};

function setStatus(kind, title, detail) {
  els.statusDot.className = `status-dot ${kind || ""}`;
  els.statusTitle.textContent = title;
  els.statusDetail.textContent = detail;
}

async function resolveTab() {
  if (Number.isInteger(tabId) && tabId >= 0) return tabId;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id;
  if (!Number.isInteger(tabId)) throw new Error("No active browser tab is available.");
  return tabId;
}

async function installPicker() {
  const id = await resolveTab();
  const existing = await chrome.scripting.executeScript({
    target: { tabId: id, allFrames: true },
    func: () => ({
      present: Boolean(globalThis.Site2JsonPagePicker),
      version: globalThis.Site2JsonPagePicker?.version || 0
    })
  });
  if (existing.some((result) => result.result?.present && result.result.version === 0)) {
    throw new Error("An older picker is still running in this page. Reload the page once, then start selecting again.");
  }
  const results = await chrome.scripting.executeScript({
    target: { tabId: id, allFrames: true },
    files: ["editor/selector-candidates.js", "editor/scope-inference.js", "content/page-highlighter.js", "content/page-picker.js"]
  });
  const versions = await chrome.scripting.executeScript({
    target: { tabId: id, allFrames: true },
    func: () => ({
      picker: globalThis.Site2JsonPagePicker?.version || 0,
      highlighter: globalThis.Site2JsonPageHighlighter?.version || 0
    })
  });
  const stale = versions.find((result) => result.result?.picker !== 3 || result.result?.highlighter !== 1);
  if (stale) throw new Error("An older picker is still running in this page. Reload the page once, then start selecting again.");
  return new Set((results || []).map((result) => result.frameId)).size;
}

async function sendToFrames(message, frameId = null) {
  const id = await resolveTab();
  const options = Number.isInteger(frameId) ? { frameId } : undefined;
  return chrome.tabs.sendMessage(id, message, options);
}

async function startPicker() {
  try {
    const frameCount = await installPicker();
    selection = null;
    els.card.hidden = true;
    await sendToFrames({ type: "site2json-picker:start" });
    els.start.textContent = "Restart selecting";
    els.cancel.disabled = false;
    setStatus("active", "Selecting on the page", `${frameCount || 1} accessible ${frameCount === 1 ? "frame is" : "frames are"} listening. Click an element or press Escape to cancel.`);
  } catch (error) {
    const permissionFailure = /Cannot access contents|permission to access|Cannot access a chrome/i.test(error.message);
    setStatus("error", "Picker could not start", permissionFailure
      ? "Site2JSON does not currently have temporary access to this page. Close this panel, click the Site2JSON toolbar icon on the page, and open the visual picker again."
      : error.message);
  }
}

async function cancelPicker() {
  try { await sendToFrames({ type: "site2json-picker:cancel" }); } catch { /* A navigation may remove the receiver. */ }
  els.cancel.disabled = true;
  setStatus("", "Picker stopped", "Start it again whenever you are ready.");
}

function renderSelection(next, sender) {
  selection = next;
  selectedFrameId = Number.isInteger(sender?.frameId) ? sender.frameId : 0;
  els.elementName.textContent = `<${next.element.tag}>`;
  els.frameLabel.textContent = selectedFrameId === 0 ? "Top page" : `Frame ${selectedFrameId}`;
  els.openingTag.textContent = next.element.openingTag;
  els.text.textContent = next.element.text || "This element has no rendered text.";
  const scope = next.scopeProposal || null;
  els.scopeSelectorRow.hidden = !scope;
  els.scopeMatchRow.hidden = !scope;
  els.scopeSelector.textContent = scope?.selector || "";
  els.scopeMatchCount.textContent = scope ? String(scope.matchCount) : "";
  els.selector.textContent = next.exactSelector || next.selector;
  els.matchCount.textContent = next.exactMatchCount ?? next.matchCount ?? "Unknown";
  els.card.hidden = false;
  els.cancel.disabled = false;
  setStatus("selected", "Element selected", "The page highlight is locked. Navigate nearby elements or choose another one.");
  sendToFrames({ type: "site2json-picker:freeze", keepInstanceId: next.instanceId }).catch(() => {});
}

chrome.runtime.onMessage.addListener((message, sender) => {
  if (sender?.tab?.id !== tabId) return false;
  if (message?.type === "site2json-picker:selection" && message.selection) renderSelection(message.selection, sender);
  if (message?.type === "site2json-picker:cancelled") {
    els.cancel.disabled = true;
    setStatus("", "Selection cancelled", "Start the picker to try again.");
  }
  return false;
});

els.start.addEventListener("click", startPicker);
els.reselect.addEventListener("click", startPicker);
els.cancel.addEventListener("click", cancelPicker);
for (const button of document.querySelectorAll("[data-navigate]")) {
  button.addEventListener("click", async () => {
    try {
      await sendToFrames({ type: "site2json-picker:navigate", direction: button.dataset.navigate }, selectedFrameId);
    } catch (error) {
      setStatus("error", "Could not navigate", error.message);
    }
  });
}

window.addEventListener("pagehide", () => {
  if (Number.isInteger(tabId)) chrome.tabs.sendMessage(tabId, { type: "site2json-picker:cancel" }).catch(() => {});
});
