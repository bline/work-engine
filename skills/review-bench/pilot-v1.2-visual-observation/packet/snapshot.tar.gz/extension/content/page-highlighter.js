// Page-side multi-group highlighter. This merges OpenPicker's MIT-licensed
// plain-DOM selector highlighter with Site2JSON's existing numbered,
// scoped, transient/pinned highlight behavior. See vendor/OPENPICKER-LICENSE.txt.
(function initializeSite2JsonPageHighlighter(root) {
  "use strict";

  const VERSION = 3;
  if (root.Site2JsonPageHighlighter?.version === VERSION) return;
  root.Site2JsonPageHighlighter?.destroy?.();

  const HOST_ID = "__site2json-page-highlights";
  const MAX_BOXES = 200;
  const PALETTE = {
    green: { border: "#18a558", fill: "rgba(24,165,88,.12)" },
    blue: { border: "#2463a7", fill: "rgba(36,99,167,.12)" },
    purple: { border: "#8b5cf6", fill: "rgba(139,92,246,.12)" },
    amber: { border: "#c77700", fill: "rgba(199,119,0,.12)" },
    red: { border: "#c2413b", fill: "rgba(194,65,59,.12)" }
  };
  const groups = new Map();
  let host = null;
  let shadow = null;
  let frameRequest = 0;

  function ensureHost() {
    if (host?.isConnected) return;
    host = document.createElement("div");
    host.id = HOST_ID;
    Object.assign(host.style, { position: "fixed", inset: "0", pointerEvents: "none", zIndex: "2147483645" });
    shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
      .box { position: fixed; box-sizing: border-box; border: 2px solid; border-radius: 3px; box-shadow: 0 0 0 1px rgba(255,255,255,.82) inset; pointer-events: none; }
      .badge { position: absolute; left: -2px; top: -18px; min-width: 18px; height: 18px; padding: 0 4px; border-radius: 3px 3px 0 0; color: #fff; font: 700 10px/18px system-ui,sans-serif; text-align: center; }
    `;
    shadow.append(style);
    document.documentElement.append(host);
    window.addEventListener("scroll", schedule, true);
    window.addEventListener("resize", schedule, true);
  }

  function removeHostIfEmpty() {
    if (groups.size) return;
    window.removeEventListener("scroll", schedule, true);
    window.removeEventListener("resize", schedule, true);
    if (frameRequest) cancelAnimationFrame(frameRequest);
    frameRequest = 0;
    host?.remove();
    host = null;
    shadow = null;
  }

  function matchesFor(config) {
    try {
      let roots = config.withinSelector ? Array.from(document.querySelectorAll(config.withinSelector)) : [document];
      if (Number.isSafeInteger(config.rootIndex)) roots = roots[config.rootIndex] ? [roots[config.rootIndex]] : [];
      let matches = config.withinSelector
        ? roots.flatMap((scope) => config.selector ? Array.from(scope.querySelectorAll(config.selector)) : [scope])
        : Array.from(document.querySelectorAll(config.selector));
      matches = Array.from(new Set(matches));
      if (Number.isSafeInteger(config.matchIndex)) matches = matches[config.matchIndex] ? [matches[config.matchIndex]] : [];
      return matches;
    } catch {
      return [];
    }
  }

  function colors(config) {
    const base = PALETTE[config.color] || PALETTE.blue;
    return { border: config.border || base.border, fill: config.fill || base.fill };
  }

  function draw() {
    frameRequest = 0;
    for (const group of groups.values()) {
      for (let index = 0; index < group.boxes.length; index += 1) {
        const node = group.matches[index];
        const box = group.boxes[index];
        if (!node?.isConnected) {
          box.style.display = "none";
          continue;
        }
        const rect = node.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0 || rect.bottom < 0 || rect.top > window.innerHeight || rect.right < 0 || rect.left > window.innerWidth) {
          box.style.display = "none";
          continue;
        }
        box.style.display = "block";
        box.style.transform = `translate3d(${Math.round(rect.left)}px, ${Math.round(rect.top)}px, 0)`;
        box.style.width = `${Math.round(rect.width)}px`;
        box.style.height = `${Math.round(rect.height)}px`;
      }
    }
  }

  function schedule() {
    if (!frameRequest) frameRequest = requestAnimationFrame(draw);
  }

  function clearGroup(groupId) {
    const group = groups.get(groupId);
    if (!group) return false;
    for (const box of group.boxes) box.remove();
    groups.delete(groupId);
    removeHostIfEmpty();
    return true;
  }

  function setGroup(config) {
    const groupId = String(config?.id || "default");
    clearGroup(groupId);
    if (!config?.selector) return { ok: false, groupId, matchCount: 0, shown: 0 };
    const matches = matchesFor(config);
    if (!matches.length) return { ok: true, groupId, matchCount: 0, shown: 0 };
    ensureHost();
    const theme = colors(config);
    const shownMatches = matches.slice(0, Math.min(Number(config.limit) || MAX_BOXES, MAX_BOXES));
    const boxes = shownMatches.map((_node, index) => {
      const box = document.createElement("div");
      box.className = "box";
      box.dataset.group = groupId;
      box.style.borderColor = theme.border;
      box.style.background = theme.fill;
      if (config.numbered !== false) {
        const badge = document.createElement("span");
        badge.className = "badge";
        badge.style.background = theme.border;
        badge.textContent = config.label ? `${config.label} ${index + 1}` : String(index + 1);
        box.append(badge);
      }
      shadow.append(box);
      return box;
    });
    groups.set(groupId, { config: { ...config, id: groupId }, matches: shownMatches, boxes });
    draw();
    return { ok: true, groupId, matchCount: matches.length, shown: shownMatches.length };
  }

  function setElementGroup(config, elements) {
    const groupId = String(config?.id || "default");
    clearGroup(groupId);
    const matches = Array.from(new Set(Array.from(elements || []).filter((node) => node?.nodeType === Node.ELEMENT_NODE)));
    if (!matches.length) return { ok: true, groupId, matchCount: 0, shown: 0 };
    ensureHost();
    const theme = colors(config || {});
    const shownMatches = matches.slice(0, Math.min(Number(config?.limit) || MAX_BOXES, MAX_BOXES));
    const boxes = shownMatches.map((_node, index) => {
      const box = document.createElement("div");
      box.className = "box";
      box.dataset.group = groupId;
      box.style.borderColor = theme.border;
      box.style.background = theme.fill;
      if (config?.numbered !== false) {
        const badge = document.createElement("span");
        badge.className = "badge";
        badge.style.background = theme.border;
        badge.textContent = config?.label ? `${config.label} ${index + 1}` : String(index + 1);
        box.append(badge);
      }
      shadow.append(box);
      return box;
    });
    groups.set(groupId, { config: { ...(config || {}), id: groupId }, matches: shownMatches, boxes });
    draw();
    return { ok: true, groupId, matchCount: matches.length, shown: shownMatches.length };
  }

  function setGroups(configs) {
    return (Array.isArray(configs) ? configs : []).map(setGroup);
  }

  function clearAll() {
    for (const groupId of Array.from(groups.keys())) clearGroup(groupId);
    return { ok: true };
  }

  function snapshot() {
    return Array.from(groups, ([id, group]) => ({ id, selector: group.config.selector, shown: group.boxes.length }));
  }

  function destroy() {
    clearAll();
    window.removeEventListener("scroll", schedule, true);
    window.removeEventListener("resize", schedule, true);
  }

  root.Site2JsonPageHighlighter = { version: VERSION, setGroup, setElementGroup, setGroups, clearGroup, clearAll, snapshot, destroy };
})(globalThis);
