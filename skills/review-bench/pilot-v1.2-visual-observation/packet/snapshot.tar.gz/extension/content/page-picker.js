(function initializeSite2JsonPagePicker(root) {
  "use strict";

  const VERSION = 6;
  if (root.Site2JsonPagePicker?.version === VERSION) return;
  // Newer builds can remove their listeners before replacement. Pickers from
  // before this lifecycle contract require one page reload; the panel detects
  // that version mismatch instead of silently using stale selection behavior.
  root.Site2JsonPagePicker?.destroy?.();

  const MESSAGE = {
    START: "site2json-picker:start",
    CANCEL: "site2json-picker:cancel",
    FREEZE: "site2json-picker:freeze",
    DISMISS: "site2json-picker:dismiss",
    NAVIGATE: "site2json-picker:navigate",
    SELECTION: "site2json-picker:selection",
    CANCELLED: "site2json-picker:cancelled"
  };
  const instanceId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  const state = {
    active: false,
    locked: false,
    mode: "scope",
    target: null,
    pendingTarget: null,
    frameRequest: 0,
    host: null,
    highlight: null,
    tooltip: null,
    tag: null,
    text: null
    ,menu: null
  };

  function insidePicker(target) {
    return target instanceof Node && Boolean(state.host && (target === state.host || state.host.contains(target)));
  }

  function targetFromEvent(event) {
    const candidate = event.composedPath?.()[0] || event.target;
    if (!(candidate instanceof Element) || insidePicker(candidate)) return null;
    return candidate;
  }

  function compact(value, maximum) {
    const normalized = String(value || "").replace(/\s+/g, " ").trim();
    return normalized.length > maximum ? `${normalized.slice(0, maximum - 1)}…` : normalized;
  }

  function openingTag(element, maximumAttributes = 8) {
    const attributes = Array.from(element.attributes || []).slice(0, maximumAttributes).map((attribute) => (
      `${attribute.name}="${compact(attribute.value, 80).replace(/"/g, "&quot;")}"`
    ));
    const omitted = Math.max(0, element.attributes.length - attributes.length);
    return `<${element.tagName.toLowerCase()}${attributes.length ? ` ${attributes.join(" ")}` : ""}${omitted ? ` … +${omitted}` : ""}>`;
  }

  function escapeCssToken(value) {
    if (root.CSS?.escape) return root.CSS.escape(value);
    return String(value).replace(/([^a-zA-Z0-9_-])/g, "\\$1").replace(/^(\d)/, "\\3$1 ");
  }

  function stableSelectorSegment(element) {
    const selectors = root.Site2JsonSelectorCandidates;
    const id = selectors?.stableId?.(element);
    if (id) return `#${escapeCssToken(id)}`;

    const tag = element.tagName.toLowerCase();
    const priorityAttributes = ["data-testid", "data-test", "data-test-id", "data-qa", "data-cy"];
    for (const name of priorityAttributes) {
      const value = element.getAttribute?.(name);
      if (value && !selectors?.looksGenerated?.(value)) {
        return `${tag}[${name}="${String(value).replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}"]`;
      }
    }

    const classes = selectors?.stableClassNames?.(element) || [];
    return `${tag}${classes.slice(0, 2).map((value) => `.${escapeCssToken(value)}`).join("")}`;
  }

  // This is orientation copy, not the selector persisted in an adapter. Keep
  // it cheap enough for pointer movement: walk a few ancestors, but never run
  // querySelectorAll or selector scoring until the user clicks.
  function hoverSelector(element) {
    const segments = [];
    let node = element;
    for (let depth = 0; node?.nodeType === 1 && depth < 4; depth += 1, node = node.parentElement) {
      const segment = stableSelectorSegment(node);
      segments.unshift(segment);
      if (segment.startsWith("#") || segment.includes("[data-")) break;
      if (node === document.body) break;
    }
    if (segments.length <= 3) return segments.join(" > ");
    return `${segments[0]} > … > ${segments.slice(-2).join(" > ")}`;
  }

  function mount() {
    if (state.host?.isConnected) return;
    const host = document.createElement("site2json-picker-ui");
    host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
      :host { all: initial; }
      .highlight { position: fixed; display: none; z-index: 2147483646; border: 2px solid #2f6fa4; border-radius: 4px; background: rgb(47 111 164 / 12%); box-shadow: 0 0 0 1px rgb(255 255 255 / 85%), 0 7px 24px rgb(22 63 108 / 20%); pointer-events: none; transition: none; }
      .highlight.locked { border-color: #1d5f96; background: rgb(47 111 164 / 19%); box-shadow: 0 0 0 2px #fff, 0 8px 28px rgb(22 63 108 / 25%); }
      .tooltip { position: fixed; display: none; z-index: 2147483647; max-width: min(440px, calc(100vw - 20px)); padding: 8px 10px; border: 1px solid #3f5f79; border-radius: 7px; color: #e5f1fc; background: #142532; box-shadow: 0 8px 28px rgb(0 0 0 / 28%); font: 11px/1.4 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; pointer-events: none; }
      .tag { display: block; overflow: hidden; color: #8fc6f0; text-overflow: ellipsis; white-space: nowrap; }
      .text { display: block; margin-top: 3px; overflow: hidden; color: #d5ddd7; text-overflow: ellipsis; white-space: nowrap; }
      .hint { color: #9ebacf; }
      .menu { position: fixed; display: none; z-index: 2147483647; min-width: 150px; padding: 4px; border: 1px solid #60788c; border-radius: 8px; background: #142532; box-shadow: 0 10px 30px rgb(0 0 0 / 32%); pointer-events: auto; }
      .menu button { all: initial; display: block; box-sizing: border-box; width: 100%; padding: 7px 9px; border-radius: 5px; color: #e5f1fc; font: 12px/1.25 system-ui,sans-serif; cursor: pointer; }
      .menu button:hover,.menu button:focus { background: #28465d; outline: none; }
    `;
    const highlight = document.createElement("div");
    highlight.className = "highlight";
    const tooltip = document.createElement("div");
    tooltip.className = "tooltip";
    const tag = document.createElement("span");
    tag.className = "tag";
    const text = document.createElement("span");
    text.className = "text";
    tooltip.append(tag, text);
    const menu = document.createElement("div"); menu.className = "menu"; menu.setAttribute("role", "menu"); menu.addEventListener("keydown", onMenuKeyDown);
    shadow.append(style, highlight, tooltip, menu);
    document.documentElement.appendChild(host);
    Object.assign(state, { host, highlight, tooltip, tag, text, menu });
  }

  function placeOverlay(element) {
    if (!element?.isConnected || !state.highlight || !state.tooltip) return;
    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 && rect.height <= 0) return;
    const highlightStyle = state.highlight.style;
    highlightStyle.display = "block";
    highlightStyle.transform = `translate3d(${Math.round(rect.left)}px, ${Math.round(rect.top)}px, 0)`;
    highlightStyle.width = `${Math.max(0, Math.round(rect.width))}px`;
    highlightStyle.height = `${Math.max(0, Math.round(rect.height))}px`;

    state.tag.textContent = hoverSelector(element);
    const summary = compact(element.textContent, 150);
    state.text.textContent = state.locked ? `${summary || "No rendered text"} · selected` : (summary || "Click to select");
    const tooltipStyle = state.tooltip.style;
    tooltipStyle.display = "block";
    tooltipStyle.left = `${Math.max(8, Math.min(rect.left, window.innerWidth - 450))}px`;
    const estimatedHeight = summary ? 58 : 38;
    const below = rect.bottom + 8;
    tooltipStyle.top = `${below + estimatedHeight <= window.innerHeight ? below : Math.max(8, rect.top - estimatedHeight - 8)}px`;
  }

  function renderPendingTarget() {
    state.frameRequest = 0;
    if (!state.active || state.locked) return;
    const target = state.pendingTarget;
    if (!target || target === state.target) return;
    state.target = target;
    placeOverlay(target);
  }

  function onPointerMove(event) {
    const target = targetFromEvent(event);
    if (!target || target === state.target || target === state.pendingTarget) return;
    state.pendingTarget = target;
    if (!state.frameRequest) state.frameRequest = requestAnimationFrame(renderPendingTarget);
  }

  function selectionPayload(element) {
    const candidates = root.Site2JsonSelectorCandidates?.generateCandidates(element, document) || [];
    const best = root.Site2JsonSelectorCandidates?.pickBest(candidates) || candidates[0] || null;
    const inferred = state.mode === "scope" ? root.Site2JsonScopeInference?.inferRepeatingScope(element, document) : null;
    const scopeProposal = inferred?.chosen ? {
      selector: inferred.chosen.selector,
      matchCount: inferred.chosen.matchCount,
      siblingMatchCount: inferred.chosen.siblingMatchCount,
      parentCount: inferred.chosen.parentCount,
      depth: inferred.chosen.depth,
      findings: inferred.chosen.findings
    } : null;
    const interpretations = [];
    const visibleText = compact(element.textContent, 500);
    if (visibleText) interpretations.push({ kind: "text", label: "Visible text", value: visibleText });
    if (element.getAttribute?.("href")) interpretations.push({ kind: "url", label: "Link URL", value: element.href || element.getAttribute("href") });
    if (element.getAttribute?.("src")) interpretations.push({ kind: "image", label: "Image source", value: element.src || element.getAttribute("src") });
    if (element.getAttribute?.("alt")) interpretations.push({ kind: "attribute", attribute: "alt", label: "Alternative text", value: element.getAttribute("alt") });
    return {
      pickerVersion: VERSION,
      instanceId,
      frameUrl: location.href,
      element: {
        tag: element.tagName.toLowerCase(),
        id: element.id || null,
        classes: Array.from(element.classList || []),
        openingTag: openingTag(element, 30),
        text: compact(element.textContent, 500)
      },
      // `selector` remains the recommended selector for early consumers. A
      // repeating boundary is preferable during Structure; `exactSelector`
      // only relocates the individual node that was clicked.
      selector: scopeProposal?.selector || best?.selector || element.tagName.toLowerCase(),
      matchCount: scopeProposal?.matchCount ?? best?.matchCount ?? null,
      scopeProposal,
      exactSelector: best?.selector || element.tagName.toLowerCase(),
      exactMatchCount: best?.matchCount ?? null,
      candidates: candidates.slice(0, 8), interpretations
    };
  }

  function publishSelection(element, interpretation = null) {
    root.__site2jsonSelectedElement = element;
    state.target = element;
    state.pendingTarget = null;
    state.locked = true;
    state.active = false;
    removeInteractionListeners();
    state.highlight?.classList.add("locked");
    placeOverlay(element);
    const selection = selectionPayload(element);
    selection.interpretation = interpretation || selection.interpretations[0] || null;
    if (selection.scopeProposal) root.Site2JsonPageHighlighter?.setGroup({
      id: "picker-scope",
      selector: selection.scopeProposal.selector,
      color: "blue",
      numbered: true
    });
    chrome.runtime.sendMessage({ type: MESSAGE.SELECTION, selection }).catch(() => {});
  }

  function onClick(event) {
    const target = targetFromEvent(event);
    if (!target) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const selection = selectionPayload(target);
    if (state.mode === "visual-evidence" && selection.interpretations.length > 1) {
      state.locked = true; removeInteractionListeners(); state.menu.replaceChildren();
      for (const interpretation of selection.interpretations) { const button=document.createElement("button"); button.type="button"; button.setAttribute("role","menuitem"); button.textContent=interpretation.label; button.addEventListener("click",()=>publishSelection(target,interpretation)); state.menu.append(button); }
      state.menu.style.display="block"; state.menu.style.left=`${Math.max(8,Math.min(event.clientX,innerWidth-180))}px`; state.menu.style.top=`${Math.max(8,Math.min(event.clientY,innerHeight-(selection.interpretations.length*36+12)))}px`; state.menu.querySelector("button")?.focus();
    } else publishSelection(target, selection.interpretations[0] || null);
  }

  function onKeyDown(event) {
    event.preventDefault();
    event.stopImmediatePropagation();
    if (event.key === "Escape") cancel(true);
  }

  function onMenuKeyDown(event) {
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopImmediatePropagation();
      cancel(true);
      return;
    }
    if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const choices = Array.from(state.menu?.querySelectorAll("button") || []);
    if (!choices.length) return;
    const activeElement = state.menu.getRootNode().activeElement;
    const current = Math.max(0, choices.indexOf(activeElement));
    const next = event.key === "Home" ? 0
      : event.key === "End" ? choices.length - 1
        : (current + (event.key === "ArrowDown" ? 1 : -1) + choices.length) % choices.length;
    choices[next].focus();
  }

  function onContextMenu(event) {
    if (insidePicker(event.target)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    cancel(true);
  }

  function onViewportChange() {
    if (!state.target || state.frameRequest) return;
    state.pendingTarget = state.target;
    state.frameRequest = requestAnimationFrame(() => {
      state.frameRequest = 0;
      if (state.target) placeOverlay(state.target);
    });
  }

  function addInteractionListeners() {
    window.addEventListener("pointermove", onPointerMove, true);
    window.addEventListener("click", onClick, true);
    window.addEventListener("contextmenu", onContextMenu, true);
    window.addEventListener("keydown", onKeyDown, true);
  }

  function removeInteractionListeners() {
    window.removeEventListener("pointermove", onPointerMove, true);
    window.removeEventListener("click", onClick, true);
    window.removeEventListener("contextmenu", onContextMenu, true);
    window.removeEventListener("keydown", onKeyDown, true);
  }

  function start(mode = "scope") {
    mount();
    delete root.__site2jsonSelectedElement;
    root.Site2JsonPageHighlighter?.clearGroup("picker-scope");
    removeInteractionListeners();
    state.active = true;
    state.locked = false;
    state.mode = mode === "scope" ? "scope" : mode === "visual-evidence" ? "visual-evidence" : "field";
    state.target = null;
    state.pendingTarget = null;
    state.highlight.classList.remove("locked");
    state.highlight.style.display = "none";
    state.tooltip.style.display = "none";
    addInteractionListeners();
  }

  function cancel(notify = false) {
    state.active = false;
    state.locked = false;
    state.target = null;
    delete root.__site2jsonSelectedElement;
    state.pendingTarget = null;
    if (state.frameRequest) cancelAnimationFrame(state.frameRequest);
    state.frameRequest = 0;
    removeInteractionListeners();
    root.Site2JsonPageHighlighter?.clearGroup("picker-scope");
    state.host?.remove();
    Object.assign(state, { host: null, highlight: null, tooltip: null, tag: null, text: null, menu: null });
    if (notify) chrome.runtime.sendMessage({ type: MESSAGE.CANCELLED, instanceId }).catch(() => {});
  }

  function dismiss() {
    state.active = false;
    state.locked = false;
    state.target = null;
    state.pendingTarget = null;
    if (state.frameRequest) cancelAnimationFrame(state.frameRequest);
    state.frameRequest = 0;
    removeInteractionListeners();
    root.Site2JsonPageHighlighter?.clearGroup("picker-scope");
    state.host?.remove();
    Object.assign(state, { host: null, highlight: null, tooltip: null, tag: null, text: null, menu: null });
  }

  function navigate(direction) {
    if (!state.target) return;
    const choices = {
      parent: state.target.parentElement,
      previous: state.target.previousElementSibling,
      next: state.target.nextElementSibling,
      child: state.target.firstElementChild
    };
    const target = choices[direction];
    if (target && target !== state.host) publishSelection(target);
  }

  // Deterministic extension-owned automation hook. This remains inside the
  // isolated content-script world; page scripts cannot invoke it.
  function select(selector) {
    if (!state.active || typeof selector !== "string") return false;
    let target;
    try { target = document.querySelector(selector); } catch { return false; }
    if (!(target instanceof Element) || insidePicker(target)) return false;
    target.scrollIntoView({ block: "center", inline: "center" });
    publishSelection(target);
    return true;
  }

  window.addEventListener("scroll", onViewportChange, true);
  window.addEventListener("resize", onViewportChange, true);
  function onRuntimeMessage(message) {
    if (message?.type === MESSAGE.START) start(message.mode);
    else if (message?.type === MESSAGE.CANCEL) cancel(false);
    else if (message?.type === MESSAGE.FREEZE && message.keepInstanceId !== instanceId) cancel(false);
    else if (message?.type === MESSAGE.DISMISS) dismiss();
    else if (message?.type === MESSAGE.NAVIGATE) navigate(message.direction);
    else if (message?.type === "site2json-highlight:set") root.Site2JsonPageHighlighter?.setGroup(message.group);
    else if (message?.type === "site2json-highlight:set-many") root.Site2JsonPageHighlighter?.setGroups(message.groups);
    else if (message?.type === "site2json-highlight:clear") root.Site2JsonPageHighlighter?.clearGroup(message.groupId);
    else if (message?.type === "site2json-highlight:clear-all") root.Site2JsonPageHighlighter?.clearAll();
    return false;
  }
  chrome.runtime.onMessage.addListener(onRuntimeMessage);

  function destroy() {
    cancel(false);
    delete root.__site2jsonSelectedElement;
    window.removeEventListener("scroll", onViewportChange, true);
    window.removeEventListener("resize", onViewportChange, true);
    chrome.runtime.onMessage.removeListener?.(onRuntimeMessage);
  }

  root.Site2JsonPagePicker = { version: VERSION, start, cancel, navigate, select, destroy, instanceId };
})(globalThis);
