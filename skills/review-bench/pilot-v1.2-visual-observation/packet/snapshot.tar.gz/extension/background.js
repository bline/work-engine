"use strict";

const PENDING_COMMAND_KEY = "pendingShortcutCommand";
const supportedCommands = new Set(["start-session", "add-page", "copy-session", "download-session"]);

const sidebarPorts = new Map();
const tablePorts = new Map();
const controllerPorts = new Map();

function sidePanelPath(tabId) {
  return `editor/sidebar.html?tabId=${tabId}`;
}

async function configureSidePanelForTab(tabId) {
  if (!Number.isInteger(tabId) || !chrome.sidePanel?.setOptions) return;
  try {
    await chrome.sidePanel.setOptions({ tabId, path: sidePanelPath(tabId), enabled: true });
  } catch (error) {
    // Tabs can disappear while the service worker is configuring existing windows.
    console.warn("Could not configure the site2json side panel for tab", tabId, error);
  }
}

// A manifest default side panel has no reliable way to discover which tab owns it:
// extension pages can report another window as "current". Give every browser tab a
// tab-specific URL up front so the editor always receives its authoritative tab id.
if (chrome.sidePanel?.setOptions && chrome.tabs) {
  chrome.tabs.query({}).then((tabs) => Promise.all(tabs.map((tab) => configureSidePanelForTab(tab.id))));
  chrome.tabs.onCreated?.addListener((tab) => configureSidePanelForTab(tab.id));
  chrome.tabs.onActivated?.addListener(({ tabId }) => configureSidePanelForTab(tabId));
  chrome.tabs.onUpdated?.addListener((tabId) => configureSidePanelForTab(tabId));
}

function relayDescriptor(name) {
  const match = /^(site2json-sidebar|site2json-table|site2json-controller):(\d+)$/.exec(name || "");
  if (!match) return null;
  const roles = { "site2json-sidebar": "sidebar", "site2json-table": "table", "site2json-controller": "controller" };
  return { role: roles[match[1]], tabId: Number(match[2]) };
}

function portSet(registry, tabId) {
  if (!registry.has(tabId)) registry.set(tabId, new Set());
  return registry.get(tabId);
}

function postAll(ports, message) {
  for (const port of ports || []) {
    try { port.postMessage(message); } catch { /* A disconnect may race this broadcast. */ }
  }
}

if (chrome.runtime?.onConnect) chrome.runtime.onConnect.addListener((port) => {
  const descriptor = relayDescriptor(port.name);
  if (!descriptor) return;
  const registries = { sidebar: sidebarPorts, table: tablePorts, controller: controllerPorts };
  const ownRegistry = registries[descriptor.role];
  const own = portSet(ownRegistry, descriptor.tabId);
  own.add(port);
  port.postMessage({
    type: "relay-status",
    sidebarConnected: Boolean(sidebarPorts.get(descriptor.tabId)?.size),
    controllerConnected: Boolean(controllerPorts.get(descriptor.tabId)?.size)
  });
  if (descriptor.role === "table") postAll(sidebarPorts.get(descriptor.tabId), { type: "panel-request-snapshot" });
  if (descriptor.role === "sidebar") postAll(tablePorts.get(descriptor.tabId), {
    type: "relay-status", sidebarConnected: true, controllerConnected: Boolean(controllerPorts.get(descriptor.tabId)?.size)
  });
  if (descriptor.role === "controller") postAll(tablePorts.get(descriptor.tabId), {
    type: "relay-status", sidebarConnected: Boolean(sidebarPorts.get(descriptor.tabId)?.size), controllerConnected: true
  });
  if (descriptor.role === "table") postAll(controllerPorts.get(descriptor.tabId), { type: "surface-connected", surface: "expanded" });
  if (descriptor.role === "sidebar") postAll(controllerPorts.get(descriptor.tabId), { type: "surface-connected", surface: "sidebar" });
  if (descriptor.role === "controller" && tablePorts.get(descriptor.tabId)?.size) {
    port.postMessage({ type: "surface-connected", surface: "expanded" });
  }
  if (descriptor.role === "controller") {
    postAll(sidebarPorts.get(descriptor.tabId), { type: "panel-request-snapshot" });
  }
  if (descriptor.role !== "controller") postAll(controllerPorts.get(descriptor.tabId), { type: "controller-request-state" });

  port.onMessage.addListener((message) => {
    if (message?.type === "relay-heartbeat") return;
    const relayed = message?.type === "editor-command"
      ? { ...message, sourceSurface: descriptor.role === "table" ? "expanded" : "sidebar" }
      : message;
    for (const [role, registry] of Object.entries(registries)) {
      if (role !== descriptor.role) postAll(registry.get(descriptor.tabId), relayed);
    }
  });
  port.onDisconnect.addListener(() => {
    own.delete(port);
    if (!own.size) ownRegistry.delete(descriptor.tabId);
    if (descriptor.role === "sidebar") postAll(tablePorts.get(descriptor.tabId), {
      type: "relay-status", sidebarConnected: Boolean(sidebarPorts.get(descriptor.tabId)?.size), controllerConnected: Boolean(controllerPorts.get(descriptor.tabId)?.size)
    });
    if (descriptor.role === "sidebar" && !sidebarPorts.get(descriptor.tabId)?.size) {
      postAll(controllerPorts.get(descriptor.tabId), { type: "surface-disconnected", surface: "sidebar" });
    }
    if (descriptor.role === "controller") postAll(tablePorts.get(descriptor.tabId), {
      type: "relay-status", sidebarConnected: Boolean(sidebarPorts.get(descriptor.tabId)?.size), controllerConnected: false
    });
    if (descriptor.role === "table" && !tablePorts.get(descriptor.tabId)?.size) {
      postAll(controllerPorts.get(descriptor.tabId), { type: "surface-disconnected", surface: "expanded" });
    }
  });
});

chrome.commands.onCommand.addListener(async (command) => {
  if (!supportedCommands.has(command)) return;
  await chrome.storage.session.set({
    [PENDING_COMMAND_KEY]: { command, requestedAt: new Date().toISOString() }
  });
  try {
    await chrome.action.openPopup();
  } catch (error) {
    await chrome.storage.session.remove(PENDING_COMMAND_KEY);
    console.error("Could not open the site2json popup for shortcut", error);
  }
});
