(function initializeIrPageDetection(root, factory) {
  "use strict";
  const normalization = root.Site2JsonNormalization || (typeof require === "function" ? require("./normalization") : null);
  const semanticAssignment = root.Site2JsonIrSemanticAssignment || (typeof require === "function" ? require("./semantic-assignment") : null);
  const validation = root.Site2JsonIrValidation || (typeof require === "function" ? require("./validation") : null);
  const serialization = root.Site2JsonIrSerialization || (typeof require === "function" ? require("./serialization") : null);
  const groupingInference = root.Site2JsonIrGroupingInference || (typeof require === "function" ? require("./grouping-inference") : null);
  const api = factory(normalization, semanticAssignment, validation, serialization, groupingInference);
  root.Site2JsonIrPageDetection = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irPageDetectionFactory(normalization, semanticAssignment, validation, serialization, groupingInference) {
  "use strict";

  const DEFAULTS = Object.freeze({
    maxCandidates: 48,
    maxDetections: 16,
    maxSurveyCandidates: 12,
    minGroupingScore: 20,
    minObservedRoles: 2,
    minAcceptedRatio: 0.5
  });

  function survey(document, plan = {}, options = {}) {
    const settings = { ...DEFAULTS, ...(options.detection || {}) };
    const grouping = groupingInference.infer(document, plan);
    const candidates = [];
    for (const candidate of grouping.candidates) {
      if (candidates.length >= settings.maxSurveyCandidates) break;
      if (!candidate.hardValid || candidate.score < settings.minGroupingScore) continue;
      try {
        candidates.push(Object.freeze({
          id: candidate.id,
          candidate,
          observed: normalization.observeDetectedSources(document, plan, candidate.sources, {
            id: candidate.id,
            kind: candidate.kind,
            score: candidate.score,
            axes: candidate.axes,
            evidence: candidate.evidence
          })
        }));
      } catch {
        // detect() owns actionable candidate failures. A survey only gathers
        // bounded authoring evidence, so one malformed candidate must not
        // erase observations from every other credible grouping.
      }
    }
    return Object.freeze({
      version: 1,
      settings: Object.freeze({ ...settings }),
      candidateCount: grouping.candidates.length,
      candidates: Object.freeze(candidates)
    });
  }

  function roots(source) {
    return Array.isArray(source) ? source : [source];
  }

  function overlaps(left, right) {
    return roots(left).some((a) => roots(right).some((b) => a === b || a?.contains?.(b) || b?.contains?.(a)));
  }

  function coverage(left, right) {
    if (!left.length) return 0;
    return left.filter((source) => right.some((candidate) => overlaps(source, candidate))).length / left.length;
  }

  function overlapKind(left, right) {
    const leftCoverage = coverage(left.sources, right.sources);
    const rightCoverage = coverage(right.sources, left.sources);
    if (leftCoverage < 0.8 || rightCoverage < 0.8) return null;
    const leftContains = left.sources.some((source) => right.sources.some((candidate) => roots(source).some((a) => roots(candidate).some((b) => a !== b && a?.contains?.(b)))));
    const rightContains = right.sources.some((source) => left.sources.some((candidate) => roots(source).some((a) => roots(candidate).some((b) => a !== b && a?.contains?.(b)))));
    if (leftContains === rightContains) return "equivalent";
    return leftContains ? "left-contains-right" : "right-contains-left";
  }

  function typeSignature(reports) {
    return [...new Set((reports || []).filter((report) => report.accepted).map((report) => report.selected).filter(Boolean))].sort();
  }

  function sameTypeFamily(left, right) {
    if (!left.typeSignature.length || !right.typeSignature.length) return true;
    return left.typeSignature.length === right.typeSignature.length
      && left.typeSignature.every((type, index) => type === right.typeSignature[index]);
  }

  function duplicates(left, right) {
    const relationship = overlapKind(left, right);
    if (!relationship) return false;
    // Singleton landmarks are page/detail-root fallbacks. When one envelopes a
    // credible repeated or sequence grouping, retaining both would present the
    // same rendered evidence as two independent detections. Preserve the
    // singleton in the candidate ledger, but let the more specific grouping
    // own the selected result.
    if (left.candidate?.kind === "singleton" || right.candidate?.kind === "singleton") return true;
    return sameTypeFamily(left, right);
  }

  function analyze(document, plan, candidate, options) {
    const observed = normalization.observeDetectedSources(document, plan, candidate.sources, {
      id: candidate.id,
      kind: candidate.kind,
      score: candidate.score,
      axes: candidate.axes,
      evidence: candidate.evidence
    });
    const observationValidation = validation.validate(observed.tree, { stage: "observed" });
    if (!observationValidation.ok) throw new Error(observationValidation.errors.join(" "));
    const semantics = semanticAssignment.assign(observed.tree, options);
    const assignedValidation = validation.validate(semantics.tree, { stage: "assigned", allowUnresolved: true });
    if (!assignedValidation.ok) throw new Error(assignedValidation.errors.join(" "));
    const grouping = {
      id: candidate.id,
      kind: candidate.kind,
      score: candidate.score,
      axes: candidate.axes,
      hardValid: candidate.hardValid,
      evidence: candidate.evidence,
      entityCount: candidate.sources.length
    };
    const output = serialization.serialize(semantics.tree, {
      propertyAssignments: semantics.findings,
      typeAssignments: semantics.reports,
      grouping
    });
    const roleCounts = (observed.tree.root.children || []).map((entity) => (entity.children || []).filter((child) => child.kind === "value").length);
    const acceptedCount = semantics.reports.filter((report) => report.accepted).length;
    const acceptedRatio = semantics.reports.length ? acceptedCount / semantics.reports.length : 0;
    return {
      id: candidate.id,
      candidate,
      sources: candidate.sources,
      observed,
      semantics,
      tree: semantics.tree,
      output,
      validation: assignedValidation,
      typeSignature: typeSignature(semantics.reports),
      metrics: {
        entityCount: candidate.sources.length,
        observedRoleCount: roleCounts.reduce((sum, count) => sum + count, 0),
        meanObservedRoles: roleCounts.length ? roleCounts.reduce((sum, count) => sum + count, 0) / roleCounts.length : 0,
        acceptedCount,
        acceptedRatio,
        unresolvedCount: semantics.findings.filter((finding) => finding.status === "unresolved").length
      }
    };
  }

  function detect(document, plan = {}, options = {}) {
    const settings = { ...DEFAULTS, ...(options.detection || {}) };
    const grouping = groupingInference.infer(document, plan);
    const analyzed = [];
    const boundedCandidates = grouping.candidates.slice(0, settings.maxCandidates);
    for (const candidate of boundedCandidates) {
      const reasons = [];
      if (!candidate.hardValid) reasons.push("entity-independence");
      if (candidate.score < settings.minGroupingScore) reasons.push("grouping-score");
      if (reasons.length) {
        analyzed.push({ id: candidate.id, candidate, sources: candidate.sources, status: "rejected", reasons });
        continue;
      }
      try {
        const detection = analyze(document, plan, candidate, options);
        if (detection.metrics.meanObservedRoles < settings.minObservedRoles) reasons.push("insufficient-observations");
        if (detection.metrics.acceptedRatio < settings.minAcceptedRatio) reasons.push("semantic-confidence");
        analyzed.push({ ...detection, status: reasons.length ? "review" : "credible", reasons });
      } catch (error) {
        analyzed.push({
          id: candidate.id,
          candidate,
          sources: candidate.sources,
          status: "rejected",
          reasons: ["analysis-error"],
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
    for (const candidate of grouping.candidates.slice(boundedCandidates.length)) {
      analyzed.push({ id: candidate.id, candidate, sources: candidate.sources, status: "deferred", reasons: ["analysis-limit"] });
    }

    const selected = [];
    for (const detection of analyzed.filter((item) => item.status === "credible" || item.status === "review")) {
      if (selected.length >= settings.maxDetections) {
        detection.status = "deferred";
        detection.reasons.push("detection-limit");
        continue;
      }
      const duplicate = selected.find((other) => duplicates(detection, other));
      if (duplicate) {
        detection.status = "alternative";
        detection.reasons.push("overlapping-alternative");
        detection.alternativeTo = duplicate.id;
        continue;
      }
      for (const other of selected) {
        if (sameTypeFamily(detection, other)) continue;
        const relationship = overlapKind(detection, other);
        if (relationship === "right-contains-left" && !detection.parentDetectionId) detection.parentDetectionId = other.id;
        else if (relationship === "left-contains-right" && !other.parentDetectionId) other.parentDetectionId = detection.id;
      }
      detection.status = detection.status === "credible" ? "selected" : "review";
      selected.push(detection);
    }

    return Object.freeze({
      version: 1,
      settings: Object.freeze({ ...settings }),
      selected: Object.freeze(selected),
      candidates: Object.freeze(analyzed),
      summary: Object.freeze({
        candidateCount: grouping.candidates.length,
        analyzedCount: analyzed.filter((item) => item.semantics).length,
        selectedCount: selected.length,
        reviewCount: selected.filter((item) => item.status === "review").length,
        entityCount: selected.reduce((sum, item) => sum + Number(item.metrics?.entityCount || 0), 0),
        acceptedEntityCount: selected.reduce((sum, item) => sum + Number(item.metrics?.acceptedCount || 0), 0)
      })
    });
  }

  return Object.freeze({ DEFAULTS, survey, detect, analyze, overlapKind });
});
