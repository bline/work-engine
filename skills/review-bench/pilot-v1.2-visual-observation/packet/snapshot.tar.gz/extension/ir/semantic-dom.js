(function initializeSemanticDom(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonSemanticDom = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function semanticDomFactory() {
  "use strict";

  const KINDS = new Set(["collection", "entity", "value"]);

  function text(value, label) {
    const result = String(value || "").trim();
    if (!result) throw new Error(`${label} is required.`);
    return result;
  }

  function node(definition = {}) {
    const kind = text(definition.kind, "S2J Markup node kind");
    if (!KINDS.has(kind)) throw new Error(`Unsupported S2J Markup node kind: ${kind}.`);
    const result = {
      id: text(definition.id, "S2J Markup node id"),
      kind,
      children: (definition.children || []).map(node)
    };
    if (definition.term) result.term = text(definition.term, "Semantic term");
    if (definition.role) result.role = text(definition.role, "Observation role");
    if (definition.source) result.source = text(definition.source, "Source binding");
    if (Object.prototype.hasOwnProperty.call(definition, "value")) result.value = definition.value;
    if (definition.confidence !== undefined) result.confidence = Math.max(0, Math.min(1, Number(definition.confidence) || 0));
    if (definition.assignment) result.assignment = { ...definition.assignment };
    if (definition.typeCandidates?.length) result.typeCandidates = definition.typeCandidates.map((candidate) => ({ ...candidate }));
    if (definition.provenance?.length) result.provenance = definition.provenance.map((item) => ({ ...item }));
    return result;
  }

  function document(definition = {}) {
    return Object.freeze({
      format: "site2json-s2j-markup",
      version: 1,
      root: node(definition.root || definition)
    });
  }

  function walk(value, visit) {
    const rootNode = value?.root || value;
    (function descend(current, parent = null) {
      visit(current, parent);
      for (const child of current.children || []) descend(child, current);
    })(rootNode);
  }

  function find(value, id) {
    let match = null;
    walk(value, (current) => { if (current.id === id) match = current; });
    return match;
  }

  return Object.freeze({ KINDS: Object.freeze([...KINDS]), document, node, walk, find });
});
