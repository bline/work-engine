(function initializeIrSemanticAssignment(root, factory) {
  "use strict";
  const semanticDom = root.Site2JsonSemanticDom || (typeof require === "function" ? require("./semantic-dom") : null);
  const typeAssignment = root.Site2JsonIrTypeAssignment || (typeof require === "function" ? require("./type-assignment") : null);
  const api = factory(semanticDom, typeAssignment);
  root.Site2JsonIrSemanticAssignment = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irSemanticAssignmentFactory(semanticDom, typeAssignment) {
  "use strict";

  const SCHEMA = "https://schema.org/";
  const GENERIC_TERMS = new Set([`${SCHEMA}name`, `${SCHEMA}url`, `${SCHEMA}description`]);
  const DEFAULT_ROLE_CANDIDATES = Object.freeze({
    title: Object.freeze([{ term: `${SCHEMA}name`, score: 4, ranges: ["Text"] }]),
    heading: Object.freeze([{ term: `${SCHEMA}name`, score: 3, ranges: ["Text"] }]),
    url: Object.freeze([{ term: `${SCHEMA}url`, score: 5, ranges: ["URL"] }]),
    description: Object.freeze([{ term: `${SCHEMA}description`, score: 4, ranges: ["Text"] }]),
    date: Object.freeze([
      { term: `${SCHEMA}datePosted`, score: 2, ranges: ["Date", "DateTime"] },
      { term: `${SCHEMA}datePublished`, score: 2, ranges: ["Date", "DateTime"] }
    ]),
    datePosted: Object.freeze([{ term: `${SCHEMA}datePosted`, score: 5, ranges: ["Date", "DateTime"] }]),
    datePublished: Object.freeze([{ term: `${SCHEMA}datePublished`, score: 5, ranges: ["Date", "DateTime"] }]),
    employmentType: Object.freeze([{ term: `${SCHEMA}employmentType`, score: 5, ranges: ["Text"] }]),
    salary: Object.freeze([{ term: `${SCHEMA}baseSalary`, score: 5, ranges: ["MonetaryAmount", "Number", "PriceSpecification"] }]),
    author: Object.freeze([{ term: `${SCHEMA}author`, score: 5, ranges: ["Organization", "Person"] }]),
    price: Object.freeze([{ term: `${SCHEMA}price`, score: 5, ranges: ["Number", "Text"] }])
  });

  function clamp(value) {
    return Math.max(0, Math.min(1, Number(value) || 0));
  }

  function normalizeRoleCandidates(options = {}, profile = null) {
    const result = {};
    for (const [role, candidates] of Object.entries(DEFAULT_ROLE_CANDIDATES)) {
      result[role] = candidates.map((candidate) => ({ ...candidate }));
    }
    for (const [role, decision] of Object.entries(options.properties || {})) {
      const supplied = Array.isArray(decision) ? decision : [decision];
      result[role] = supplied.filter((candidate) => candidate?.term).map((candidate) => ({
        term: candidate.term,
        score: Number(candidate.score ?? candidate.weight ?? 4),
        confidence: candidate.confidence,
        ranges: [...(candidate.ranges || [])],
        source: candidate.source
      }));
    }
    for (const [role, candidates] of Object.entries(profile?.roleCandidates || {})) {
      const byTerm = new Map((result[role] || []).map((candidate) => [candidate.term, candidate]));
      for (const candidate of candidates || []) if (candidate?.term) byTerm.set(candidate.term, { ...candidate, ranges: [...(candidate.ranges || [])] });
      result[role] = [...byTerm.values()];
    }
    return result;
  }

  function candidateTypes(options = {}, profile = null) {
    return (options.types || profile?.types || typeAssignment.DEFAULT_TYPES).map((type) => ({
      term: type.term,
      signals: { ...(type.signals || {}) },
      source: type.source || "built-in",
      relationships: (type.relationships || []).map((relationship) => ({
        ...relationship,
        materializationWeight: Number(relationship.materializationWeight || 0),
        materializations: (relationship.materializations || []).map((materialization) => ({ ...materialization }))
      }))
    }));
  }

  function rangeLeaf(value) {
    return String(value || "").split(/[\/#:]/).filter(Boolean).at(-1) || "";
  }

  function observedShape(value) {
    const sample = Array.isArray(value) ? value.find((item) => item !== null && item !== undefined) : value;
    if (typeof sample === "boolean") return "Boolean";
    if (typeof sample === "number") return Number.isInteger(sample) ? "Integer" : "Number";
    const text = String(sample ?? "").trim();
    if (/^(?:https?:|mailto:|tel:|\/)/i.test(text)) return "URL";
    if (/^\d{4}-\d{2}-\d{2}(?:[T ]|$)/.test(text)) return text.includes("T") ? "DateTime" : "Date";
    if (/^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(text.replace(/,/g, ""))) return "Number";
    return "Text";
  }

  function rangeEvidence(node, ranges = []) {
    const declared = ranges.map(rangeLeaf).filter(Boolean);
    const observed = observedShape(node.value);
    if (!declared.length) return { compatible: true, score: 0, observed, declared };
    const scalar = new Set(["Boolean", "Date", "DateTime", "Integer", "Number", "Text", "Time", "URL"]);
    const exact = declared.includes(observed);
    const compatible = exact
      || (observed === "Integer" && declared.includes("Number"))
      || (observed === "Date" && declared.includes("DateTime"))
      || declared.includes("Text")
      || (observed === "Number" && declared.some((value) => ["MonetaryAmount", "PriceSpecification", "QuantitativeValue"].includes(value)));
    const entityOnly = declared.every((value) => !scalar.has(value));
    const entityLabel = observed === "Text" && entityOnly;
    const structuredText = observed === "Text" && declared.some((value) => ["MonetaryAmount", "PriceSpecification", "QuantitativeValue"].includes(value));
    return {
      compatible: compatible || entityLabel || structuredText,
      score: exact ? 2 : compatible ? 1 : entityLabel || structuredText ? 0 : -3,
      observed,
      declared,
      materialization: entityLabel ? "entity-label" : structuredText ? "structured-text" : exact ? "exact" : compatible ? "coercible" : "incompatible"
    };
  }

  function propertyOptions(node, roleCandidates, type) {
    return (roleCandidates[node.role] || []).map((candidate) => {
      const signalWeight = Number(type.signals[candidate.term] || 0);
      const generic = GENERIC_TERMS.has(candidate.term);
      const range = rangeEvidence(node, candidate.ranges || []);
      const domainCompatible = generic || signalWeight > 0 || type.term === `${SCHEMA}Thing`;
      const compatible = domainCompatible && range.compatible;
      const domainScore = signalWeight > 0 ? 2 : generic ? 0 : -3;
      return {
        term: candidate.term,
        localScore: Number(candidate.score || 0),
        domainScore,
        rangeScore: range.score,
        observedShape: range.observed,
        ranges: range.declared,
        materialization: range.materialization,
        signalWeight,
        semanticWeight: candidate.source === "schema" && ["title", "heading", "url", "description"].includes(node.role)
          ? Math.min(1, signalWeight)
          : signalWeight,
        compatible,
        score: Number(candidate.score || 0) + domainScore + range.score,
        confidence: candidate.confidence,
        source: candidate.source || "built-in"
      };
    }).sort((left, right) => right.score - left.score || left.term.localeCompare(right.term));
  }

  function relationshipOptions(node, type) {
    const alternatives = [];
    for (const relationship of type.relationships || []) {
      const signalWeight = Number(type.signals[relationship.term] || 0);
      if (!signalWeight) continue;
      for (const materialization of relationship.materializations || []) {
        if (materialization.role !== node.role) continue;
        const range = rangeEvidence(node, materialization.ranges || []);
        const relationshipPath = (materialization.path?.length ? materialization.path : [{ relationship: relationship.term, targetType: materialization.targetType }])
          .map((step) => ({ relationship: step.relationship, targetType: step.targetType }));
        alternatives.push({
          term: materialization.property,
          relationship: relationshipPath[0].relationship,
          targetType: relationshipPath.at(-1).targetType,
          relationshipPath,
          supportTerm: relationship.term,
          localScore: Number(materialization.score || 0),
          domainScore: 2,
          rangeScore: range.score,
          observedShape: range.observed,
          ranges: range.declared,
          materialization: range.materialization,
          signalWeight,
          semanticWeight: Number(relationship.materializationWeight || signalWeight),
          compatible: range.compatible,
          score: Number(materialization.score || 0) + 2 + range.score,
          source: materialization.source || relationship.source || "compiled-profile"
        });
      }
    }
    return alternatives;
  }

  function hypothesis(entity, type, roleCandidates) {
    const assignments = [];
    const matched = new Map();
    let unsupported = 0;
    for (const child of entity.children || []) {
      if (child.kind !== "value") continue;
      const alternatives = [...propertyOptions(child, roleCandidates, type), ...relationshipOptions(child, type)]
        .sort((left, right) => right.score - left.score || left.term.localeCompare(right.term));
      const selected = alternatives.find((candidate) => candidate.compatible) || null;
      if (!selected) unsupported += 1;
      if (selected?.signalWeight > 0) {
        const term = selected.supportTerm || selected.term;
        matched.set(term, Math.max(Number(matched.get(term) || 0), Number(selected.semanticWeight ?? selected.signalWeight)));
      }
      assignments.push({ nodeId: child.id, role: child.role, selected, alternatives });
    }
    const semanticScore = [...matched.values()].reduce((sum, weight) => sum + weight, 0);
    return {
      term: type.term,
      score: semanticScore - unsupported,
      semanticScore,
      unsupported,
      matched: [...matched.keys()],
      assignments
    };
  }

  function classifyEntity(entity, types, roleCandidates, options = {}) {
    const ranked = types.map((type) => hypothesis(entity, type, roleCandidates))
      .sort((left, right) => right.score - left.score || left.term.localeCompare(right.term));
    const leading = ranked[0] || hypothesis(entity, { term: `${SCHEMA}Thing`, signals: {} }, roleCandidates);
    const runnerUp = ranked[1] || { term: null, score: 0, matched: [], assignments: [] };
    const margin = leading.score - runnerUp.score;
    const tied = Boolean(runnerUp.term && leading.score === runnerUp.score);
    const accepted = !tied && leading.score >= (options.minScore ?? 3) && margin >= (options.minMargin ?? 2);
    const fallback = options.fallback || `${SCHEMA}Thing`;
    return {
      winner: tied ? null : leading,
      leading,
      runnerUp,
      margin,
      tied,
      accepted,
      selected: accepted ? leading.term : fallback,
      ranked
    };
  }

  function neutralFallbackAssignments(entity, roleCandidates) {
    return (entity.children || []).filter((child) => child.kind === "value").map((child) => {
      const alternatives = (roleCandidates[child.role] || []).map((candidate) => {
        const range = rangeEvidence(child, candidate.ranges || []);
        return {
          term: candidate.term,
          localScore: Number(candidate.score || 0),
          domainScore: 0,
          rangeScore: range.score,
          observedShape: range.observed,
          ranges: range.declared,
          materialization: range.materialization,
          signalWeight: 0,
          compatible: range.compatible,
          score: Number(candidate.score || 0) + range.score,
          confidence: candidate.confidence,
          source: candidate.source || "built-in"
        };
      }).sort((left, right) => right.score - left.score || left.term.localeCompare(right.term));
      return {
        nodeId: child.id,
        role: child.role,
        selected: alternatives.length === 1 && GENERIC_TERMS.has(alternatives[0].term) ? alternatives[0] : null,
        alternatives
      };
    });
  }

  function assign(tree, options = {}) {
    const profile = options.profile || null;
    const roleCandidates = normalizeRoleCandidates(options.schema || {}, profile);
    const types = candidateTypes(options.variants || {}, profile);
    const findings = [];
    const reports = [];

    function visit(node) {
      if (node.kind !== "entity") return { ...node, children: (node.children || []).map(visit) };
      const originalChildren = (node.children || []).map(visit);
      const report = classifyEntity({ ...node, children: originalChildren }, types, roleCandidates, options.variants || {});
      const chosenAssignments = report.accepted
        ? report.leading.assignments
        : neutralFallbackAssignments({ ...node, children: originalChildren }, roleCandidates);
      const byNode = new Map(chosenAssignments.map((assignment) => [assignment.nodeId, assignment]));
      const assignedChildren = originalChildren.map((child) => {
        if (child.kind !== "value") return child;
        const decision = byNode.get(child.id);
        const selected = decision?.selected || null;
        const candidates = (decision?.alternatives || []).map((candidate) => ({
          term: candidate.term,
          score: candidate.score,
          localScore: candidate.localScore,
          domainScore: candidate.domainScore,
          rangeScore: candidate.rangeScore,
          observedShape: candidate.observedShape,
          ranges: candidate.ranges,
          materialization: candidate.materialization,
          relationship: candidate.relationship,
          targetType: candidate.targetType,
          relationshipPath: candidate.relationshipPath,
          signalWeight: candidate.signalWeight,
          compatible: candidate.compatible,
          source: candidate.source
        }));
        if (!selected) {
          findings.push({ nodeId: child.id, role: child.role, status: "unresolved", candidates });
          return child;
        }
        const confidence = clamp(Number(child.confidence ?? 1) * Number(selected.confidence ?? 1));
        findings.push({
          nodeId: child.id,
          role: child.role,
          status: "assigned",
          term: selected.term,
          confidence,
          selectedType: report.selected,
          candidates
        });
        const assignedValue = {
          ...child,
          term: selected.term,
          confidence,
          assignment: { stage: "joint-semantic-assignment", role: child.role, entityType: report.selected, confidence },
          provenance: [...(child.provenance || []), {
            source: "joint-semantic-assignment",
            family: "role-and-type-coherence",
            decision: selected.term,
            entityType: report.selected,
            confidence
          }]
        };
        if (!selected.relationship || !selected.targetType) return assignedValue;
        const path = selected.relationshipPath?.length
          ? selected.relationshipPath
          : [{ relationship: selected.relationship, targetType: selected.targetType }];
        return path.reduceRight((nested, step, index) => ({
          id: `${child.id}--${path.slice(0, index + 1).map((item) => item.relationship.split(/[\/#:]/).filter(Boolean).at(-1) || "relationship").join("--")}`,
          kind: "entity",
          term: step.targetType,
          confidence,
          assignment: {
            stage: "joint-semantic-assignment",
            relationship: step.relationship,
            entityType: step.targetType,
            accepted: true,
            confidence
          },
          provenance: [{
            source: "joint-semantic-assignment",
            family: "relationship-materialization",
            decision: step.relationship,
            targetType: step.targetType,
            confidence
          }],
          children: [nested]
        }), assignedValue);
      });
      const coalesceRelationships = (items) => {
        const children = [];
        const relationshipGroups = new Map();
        for (const item of items) {
          const child = item.kind === "entity" ? { ...item, children: coalesceRelationships(item.children || []) } : item;
          const relationship = child.kind === "entity" ? child.assignment?.relationship : null;
          if (!relationship) {
            children.push(child);
            continue;
          }
          const key = `${relationship}\u001f${child.term}`;
          const existing = relationshipGroups.get(key);
          if (existing) existing.children = coalesceRelationships([...existing.children, ...child.children]);
          else {
            const group = { ...child, children: [...child.children] };
            relationshipGroups.set(key, group);
            children.push(group);
          }
        }
        return children;
      };
      const children = coalesceRelationships(assignedChildren);

      const typeConfidence = report.leading.score > 0 ? clamp(report.margin / report.leading.score) : 0;
      const publicRanked = report.ranked.map((candidate) => ({
        term: candidate.term,
        score: candidate.score,
        matched: candidate.matched,
        semanticScore: candidate.semanticScore,
        unsupported: candidate.unsupported
      }));
      const publicLeading = { ...publicRanked[0] };
      const publicRunnerUp = publicRanked[1] || { term: null, score: 0, matched: [] };
      const publicReport = {
        entityId: node.id,
        winner: report.tied ? null : publicLeading,
        leading: publicLeading,
        runnerUp: publicRunnerUp,
        margin: report.margin,
        tied: report.tied,
        accepted: report.accepted,
        selected: report.selected,
        ranked: publicRanked
      };
      reports.push(publicReport);
      return {
        ...node,
        term: report.selected,
        confidence: typeConfidence,
        assignment: { stage: "joint-semantic-assignment", accepted: report.accepted, margin: report.margin, confidence: typeConfidence },
        typeCandidates: publicRanked,
        provenance: [...(node.provenance || []), {
          source: "joint-semantic-assignment",
          family: "property-and-type-coherence",
          decision: report.selected,
          confidence: typeConfidence,
          margin: report.margin
        }],
        children
      };
    }

    const assigned = semanticDom.document(visit(tree.root));
    return Object.freeze({ tree: assigned, findings: Object.freeze(findings), reports: Object.freeze(reports) });
  }

  return Object.freeze({ SCHEMA, DEFAULT_ROLE_CANDIDATES, assign, classifyEntity, normalizeRoleCandidates, observedShape, rangeEvidence });
});
