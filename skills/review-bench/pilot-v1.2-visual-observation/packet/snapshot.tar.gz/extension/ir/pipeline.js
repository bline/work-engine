(function initializeIrPipeline(root, factory) {
  "use strict";
  const normalization = root.Site2JsonNormalization || (typeof require === "function" ? require("./normalization") : null);
  const semanticAssignment = root.Site2JsonIrSemanticAssignment || (typeof require === "function" ? require("./semantic-assignment") : null);
  const validation = root.Site2JsonIrValidation || (typeof require === "function" ? require("./validation") : null);
  const serialization = root.Site2JsonIrSerialization || (typeof require === "function" ? require("./serialization") : null);
  const groupingInference = root.Site2JsonIrGroupingInference || (typeof require === "function" ? require("./grouping-inference") : null);
  const pageDetection = root.Site2JsonIrPageDetection || (typeof require === "function" ? require("./page-detection") : null);
  const api = factory(normalization, semanticAssignment, validation, serialization, groupingInference, pageDetection);
  root.Site2JsonIrPipeline = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irPipelineFactory(normalization, semanticAssignment, validation, serialization, groupingInference, pageDetection) {
  "use strict";

  function run(document, plan, options = {}) {
    const observed = normalization.observe(document, plan);
    const observationValidation = validation.validate(observed.tree, { stage: "observed" });
    if (!observationValidation.ok) throw new Error(observationValidation.errors.join(" "));
    const semantics = semanticAssignment.assign(observed.tree, options);
    const properties = Object.freeze({ tree: semantics.tree, findings: semantics.findings });
    const types = Object.freeze({ tree: semantics.tree, reports: semantics.reports });
    const assignedValidation = validation.validate(semantics.tree, { stage: "assigned", allowUnresolved: true });
    if (!assignedValidation.ok) throw new Error(assignedValidation.errors.join(" "));
    const output = serialization.serialize(semantics.tree, { propertyAssignments: properties.findings, typeAssignments: types.reports });
    return Object.freeze({ observed, semantics, properties, types, tree: semantics.tree, output, validation: assignedValidation });
  }

  function infer(document, plan, options = {}) {
    const grouping = groupingInference.infer(document, plan);
    if (!grouping.winner) throw new Error("No credible semantic grouping was found.");
    const observed = normalization.observeDetectedSources(document, plan, grouping.winner.sources, {
      id: grouping.winner.id,
      kind: grouping.winner.kind,
      score: grouping.winner.score,
      axes: grouping.winner.axes,
      evidence: grouping.winner.evidence
    });
    const observationValidation = validation.validate(observed.tree, { stage: "observed" });
    if (!observationValidation.ok) throw new Error(observationValidation.errors.join(" "));
    const semantics = semanticAssignment.assign(observed.tree, options);
    const properties = Object.freeze({ tree: semantics.tree, findings: semantics.findings });
    const types = Object.freeze({ tree: semantics.tree, reports: semantics.reports });
    const assignedValidation = validation.validate(semantics.tree, { stage: "assigned", allowUnresolved: true });
    if (!assignedValidation.ok) throw new Error(assignedValidation.errors.join(" "));
    const output = serialization.serialize(semantics.tree, {
      propertyAssignments: properties.findings,
      typeAssignments: types.reports,
      grouping: {
        id: grouping.winner.id,
        kind: grouping.winner.kind,
        score: grouping.winner.score,
        axes: grouping.winner.axes,
        hardValid: grouping.winner.hardValid,
        evidence: grouping.winner.evidence,
        entityCount: grouping.winner.sources.length
      }
    });
    return Object.freeze({ observed, semantics, properties, types, tree: semantics.tree, output, grouping, validation: assignedValidation });
  }

  function detectPage(document, plan = {}, options = {}) {
    return pageDetection.detect(document, plan, options);
  }

  return Object.freeze({ run, infer, detectPage });
});
