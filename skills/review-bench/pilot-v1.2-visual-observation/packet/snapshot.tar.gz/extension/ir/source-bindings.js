(function initializeSourceBindings(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonSourceBindings = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function sourceBindingsFactory() {
  "use strict";

  const KINDS = new Set(["selector", "sequence", "literal", "visual"]);

  function normalize(definitions = {}) {
    const result = {};
    for (const [id, input] of Object.entries(definitions)) {
      const kind = String(input?.kind || "").trim();
      if (!KINDS.has(kind)) throw new Error(`Binding ${id} has unsupported kind ${kind || "(empty)"}.`);
      const binding = { ...input, id, kind };
      if (kind === "selector" && !String(binding.selector || "").trim()) throw new Error(`Selector binding ${id} requires a selector.`);
      if (kind === "sequence" && !String(binding.startsWith || "").trim()) throw new Error(`Sequence binding ${id} requires startsWith.`);
      if (kind === "visual" && !String(binding.profile || "").trim()) throw new Error(`Visual binding ${id} requires a profile.`);
      result[id] = Object.freeze(binding);
    }
    return Object.freeze(result);
  }

  function matches(node, selector) {
    try { return Boolean(node?.matches?.(selector)); } catch { return false; }
  }

  function queryContext(context, selector, all = false) {
    const roots = Array.isArray(context) ? context : [context];
    const found = [];
    for (const root of roots) {
      if (matches(root, selector)) found.push(root);
      if (root?.querySelectorAll) found.push(...root.querySelectorAll(selector));
      if (!all && found.length) break;
    }
    return all ? [...new Set(found)] : found.slice(0, 1);
  }

  function sequenceGroups(container, binding) {
    const direct = binding.directChildren !== false;
    const ordered = direct ? Array.from(container?.children || []) : Array.from(container?.querySelectorAll?.("*") || []);
    const starts = ordered.map((node, index) => matches(node, binding.startsWith) ? index : -1).filter((index) => index >= 0);
    return starts.map((start, index) => ordered.slice(start, starts[index + 1] ?? ordered.length));
  }

  function resolve(binding, context) {
    if (!binding) return [];
    if (binding.kind === "literal") return [binding.value];
    if (binding.kind === "visual") return Object.prototype.hasOwnProperty.call(binding, "value") ? [binding.value] : [];
    if (binding.kind === "selector") return queryContext(context, binding.selector, binding.all !== false);
    if (binding.kind === "sequence") {
      const containers = binding.within ? queryContext(context, binding.within, true) : (Array.isArray(context) ? context : [context]);
      return containers.flatMap((container) => sequenceGroups(container, binding));
    }
    return [];
  }

  function read(binding, source) {
    if (!binding) return null;
    if (binding.kind === "literal" || binding.kind === "visual") return binding.value ?? null;
    const node = Array.isArray(source) ? source[0] : source;
    if (!node) return null;
    if (binding.read === "attribute") return node.getAttribute?.(binding.attribute) ?? null;
    return String(node.textContent || "").replace(/\s+/g, " ").trim() || null;
  }

  return Object.freeze({ KINDS: Object.freeze([...KINDS]), normalize, resolve, read, queryContext });
});
