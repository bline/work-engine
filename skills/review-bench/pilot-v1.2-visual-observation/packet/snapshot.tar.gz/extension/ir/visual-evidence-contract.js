(function initializeVisualEvidenceContract(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonVisualEvidenceContract = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function visualEvidenceContractFactory() {
  "use strict";

  const MAX_TEXT = 2048;
  const MAX_CANDIDATES = 16;
  const READERS = new Set(["text", "url", "image-src", "attribute"]);
  const has = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
  const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  const plain = (value) => object(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);

  function issue(errors, path, message) { errors.push(`${path} ${message}`); }
  function shape(value, allowed, required, path, errors) {
    if (!plain(value)) { issue(errors, path, "must be a plain object."); return false; }
    for (const key of Object.keys(value)) if (!allowed.includes(key)) issue(errors, `${path}.${key}`, "is not allowed.");
    for (const key of required) if (!has(value, key)) issue(errors, `${path}.${key}`, "is required.");
    return true;
  }
  function text(value, path, errors, { required = true, max = MAX_TEXT } = {}) {
    if (value == null && !required) return;
    if (typeof value !== "string" || !value.trim()) issue(errors, path, "must be a non-empty string.");
    else if (value.length > max) issue(errors, path, `must be at most ${max} characters.`);
  }
  function integer(value, path, errors, minimum = 0, maximum = 10000) {
    if (!Number.isInteger(value) || value < minimum || value > maximum) issue(errors, path, `must be an integer from ${minimum} to ${maximum}.`);
  }
  function finite(value, path, errors, minimum = 0, maximum = 1) {
    if (!Number.isFinite(value) || value < minimum || value > maximum) issue(errors, path, `must be a finite number from ${minimum} to ${maximum}.`);
  }
  function list(value, path, errors, maximum = MAX_CANDIDATES) {
    if (!Array.isArray(value)) { issue(errors, path, "must be an array."); return false; }
    if (value.length > maximum) issue(errors, path, `must contain at most ${maximum} entries.`);
    return true;
  }
  function inert(value, path, errors, seen = new Set()) {
    if (typeof value === "function" || typeof value === "symbol" || typeof value === "bigint") { issue(errors, path, "must contain inert data only."); return; }
    if (!object(value)) return;
    if (!plain(value) && !Array.isArray(value)) { issue(errors, path, "must not contain live or class-backed objects."); return; }
    if (seen.has(value)) { issue(errors, path, "must not contain circular references."); return; }
    seen.add(value);
    for (const [key, item] of Object.entries(value)) {
      if (["ownerDocument", "nodeType", "window", "document"].includes(key)) issue(errors, `${path}.${key}`, "must not contain a live page reference.");
      inert(item, `${path}.${key}`, errors, seen);
    }
    seen.delete(value);
  }
  function freeze(value) {
    if (!object(value) && !Array.isArray(value)) return value;
    for (const item of Object.values(value)) freeze(item);
    return Object.freeze(value);
  }
  function accepted(input, errors) {
    if (errors.length) return Object.freeze({ ok: false, errors: Object.freeze(errors), value: null });
    return Object.freeze({ ok: true, errors: Object.freeze([]), value: freeze(JSON.parse(JSON.stringify(input))) });
  }

  function validateObservation(input) {
    const errors = [];
    inert(input, "observation", errors);
    if (!shape(input, ["version", "observationId", "status", "target", "action", "repeatedGroup", "provenance"], ["version", "observationId", "status", "target", "provenance"], "observation", errors)) return accepted(input, errors);
    if (input.version !== 1) issue(errors, "observation.version", "must equal 1.");
    text(input.observationId, "observation.observationId", errors, { max: 160 });
    if (!["authored", "unresolved", "cancelled"].includes(input.status)) issue(errors, "observation.status", "must be authored, unresolved, or cancelled.");
    if (shape(input.target, ["typeTerm", "propertyTerm", "path", "variantKey"], ["propertyTerm", "path"], "observation.target", errors)) {
      for (const key of ["typeTerm", "propertyTerm", "path", "variantKey"]) if (has(input.target, key)) text(input.target[key], `observation.target.${key}`, errors, { max: 512 });
    }
    if (input.status === "authored" && !has(input, "action")) issue(errors, "observation.action", "is required for authored observations.");
    if (has(input, "action") && shape(input.action, ["kind", "frameUrl", "element", "interpretation"], ["kind", "element", "interpretation"], "observation.action", errors)) {
      if (input.action.kind !== "rendered-page-click") issue(errors, "observation.action.kind", "must be rendered-page-click.");
      if (has(input.action, "frameUrl")) text(input.action.frameUrl, "observation.action.frameUrl", errors, { max: 2048 });
      if (shape(input.action.element, ["tag", "role", "candidateFingerprints"], ["tag", "candidateFingerprints"], "observation.action.element", errors)) {
        text(input.action.element.tag, "observation.action.element.tag", errors, { max: 64 });
        if (has(input.action.element, "role")) text(input.action.element.role, "observation.action.element.role", errors, { max: 128 });
        if (list(input.action.element.candidateFingerprints, "observation.action.element.candidateFingerprints", errors)) input.action.element.candidateFingerprints.forEach((item, index) => text(item, `observation.action.element.candidateFingerprints.${index}`, errors, { max: 512 }));
      }
      if (shape(input.action.interpretation, ["kind", "reader", "attribute"], ["kind", "reader"], "observation.action.interpretation", errors)) {
        if (!["text", "url", "image", "attribute"].includes(input.action.interpretation.kind)) issue(errors, "observation.action.interpretation.kind", "is unsupported.");
        if (!READERS.has(input.action.interpretation.reader)) issue(errors, "observation.action.interpretation.reader", "must name a packaged reader.");
        if (input.action.interpretation.reader === "attribute") text(input.action.interpretation.attribute, "observation.action.interpretation.attribute", errors, { max: 128 });
      }
    }
    if (has(input, "repeatedGroup") && shape(input.repeatedGroup, ["mode", "groupObservationId", "selectedItemOrdinal", "itemCountAtAuthoring", "scopeFingerprint"], ["mode"], "observation.repeatedGroup", errors)) {
      if (!["one", "many"].includes(input.repeatedGroup.mode)) issue(errors, "observation.repeatedGroup.mode", "must be one or many.");
      if (input.repeatedGroup.mode === "many") {
        for (const key of ["groupObservationId", "selectedItemOrdinal", "itemCountAtAuthoring", "scopeFingerprint"]) if (!has(input.repeatedGroup, key)) issue(errors, `observation.repeatedGroup.${key}`, "is required for many mode.");
        text(input.repeatedGroup.groupObservationId, "observation.repeatedGroup.groupObservationId", errors, { max: 160 });
        integer(input.repeatedGroup.selectedItemOrdinal, "observation.repeatedGroup.selectedItemOrdinal", errors);
        integer(input.repeatedGroup.itemCountAtAuthoring, "observation.repeatedGroup.itemCountAtAuthoring", errors, 1);
        if (Number.isInteger(input.repeatedGroup.selectedItemOrdinal) && Number.isInteger(input.repeatedGroup.itemCountAtAuthoring) && input.repeatedGroup.selectedItemOrdinal >= input.repeatedGroup.itemCountAtAuthoring) issue(errors, "observation.repeatedGroup.selectedItemOrdinal", "must identify an item in the authored population.");
        text(input.repeatedGroup.scopeFingerprint, "observation.repeatedGroup.scopeFingerprint", errors, { max: 512 });
      }
    }
    if (shape(input.provenance, ["source", "authoredAt", "pickerVersion", "pageRevision", "detectionRunId"], ["source", "authoredAt", "pageRevision"], "observation.provenance", errors)) {
      const allowedSources = input.status === "authored"
        ? ["human-rendered-page-click"]
        : ["human-rendered-page-click", "human-left-unresolved"];
      if (!allowedSources.includes(input.provenance.source)) issue(errors, "observation.provenance.source", `must preserve ${allowedSources.join(" or ")} provenance.`);
      text(input.provenance.authoredAt, "observation.provenance.authoredAt", errors, { max: 64 });
      if (input.provenance.source === "human-rendered-page-click" && !has(input.provenance, "pickerVersion")) issue(errors, "observation.provenance.pickerVersion", "is required for rendered-page clicks.");
      if (has(input.provenance, "pickerVersion")) integer(input.provenance.pickerVersion, "observation.provenance.pickerVersion", errors, 1, 1000);
      text(input.provenance.pageRevision, "observation.provenance.pageRevision", errors, { max: 512 });
      if (has(input.provenance, "detectionRunId")) text(input.provenance.detectionRunId, "observation.provenance.detectionRunId", errors, { max: 160 });
    }
    return accepted(input, errors);
  }

  function validateCandidate(candidate, path, errors, kinds) {
    if (!plain(candidate)) { issue(errors, path, "must be a plain object."); return; }
    if (!kinds.includes(candidate.kind)) { issue(errors, `${path}.kind`, "is unsupported."); return; }
    const selectorKind = candidate.kind === "stable-selector" || candidate.kind === "stable-relative-selector";
    const allowed = selectorKind ? ["kind", "selector"] : ["kind", "tags", "childIndexes"];
    const required = selectorKind ? ["kind", "selector"] : ["kind", "tags"];
    shape(candidate, allowed, required, path, errors);
    if (selectorKind) text(candidate.selector, `${path}.selector`, errors, { max: 1024 });
    else {
      if (list(candidate.tags, `${path}.tags`, errors, 32)) candidate.tags.forEach((item, index) => text(item, `${path}.tags.${index}`, errors, { max: 64 }));
    }
    if (has(candidate, "childIndexes") && list(candidate.childIndexes, `${path}.childIndexes`, errors, 32)) candidate.childIndexes.forEach((item, index) => integer(item, `${path}.childIndexes.${index}`, errors, 0, 10000));
  }

  function validatePortableBinding(input) {
    const errors = [];
    inert(input, "binding", errors);
    if (!shape(input, ["kind", "version", "scope", "target", "layout", "validation", "baseline", "provenance"], ["kind", "version", "scope", "target", "validation", "baseline", "provenance"], "binding", errors)) return accepted(input, errors);
    if (input.kind !== "visual") issue(errors, "binding.kind", "must be visual.");
    if (input.version !== 1) issue(errors, "binding.version", "must equal 1.");
    if (shape(input.scope, ["mode", "rootCandidates", "itemRelation"], ["mode", "rootCandidates", "itemRelation"], "binding.scope", errors)) {
      if (!["one", "many"].includes(input.scope.mode)) issue(errors, "binding.scope.mode", "must be one or many.");
      if (list(input.scope.rootCandidates, "binding.scope.rootCandidates", errors) && !input.scope.rootCandidates.length) issue(errors, "binding.scope.rootCandidates", "must contain a non-coordinate locator.");
      else input.scope.rootCandidates?.forEach((item, index) => validateCandidate(item, `binding.scope.rootCandidates.${index}`, errors, ["stable-selector", "relative-structure"]));
      if (!["self", "descendant"].includes(input.scope.itemRelation)) issue(errors, "binding.scope.itemRelation", "is unsupported.");
    }
    if (shape(input.target, ["relation", "locatorCandidates", "renderedRole", "tag", "reader", "attribute"], ["relation", "locatorCandidates", "tag", "reader"], "binding.target", errors)) {
      if (!["self", "descendant"].includes(input.target.relation)) issue(errors, "binding.target.relation", "is unsupported.");
      if (list(input.target.locatorCandidates, "binding.target.locatorCandidates", errors) && !input.target.locatorCandidates.length) issue(errors, "binding.target.locatorCandidates", "must contain a non-coordinate locator.");
      else input.target.locatorCandidates?.forEach((item, index) => validateCandidate(item, `binding.target.locatorCandidates.${index}`, errors, ["stable-relative-selector", "relative-path"]));
      text(input.target.tag, "binding.target.tag", errors, { max: 64 });
      if (has(input.target, "renderedRole")) text(input.target.renderedRole, "binding.target.renderedRole", errors, { max: 128 });
      if (!READERS.has(input.target.reader)) issue(errors, "binding.target.reader", "must name a packaged reader.");
      if (input.target.reader === "attribute") text(input.target.attribute, "binding.target.attribute", errors, { max: 128 });
    }
    if (has(input, "layout") && shape(input.layout, ["normalizedRect", "order"], [], "binding.layout", errors)) {
      if (has(input.layout, "normalizedRect") && shape(input.layout.normalizedRect, ["x", "y", "width", "height"], ["x", "y", "width", "height"], "binding.layout.normalizedRect", errors)) for (const key of ["x", "y", "width", "height"]) finite(input.layout.normalizedRect[key], `binding.layout.normalizedRect.${key}`, errors);
      if (has(input.layout, "order") && shape(input.layout.order, ["axis", "rank"], ["axis", "rank"], "binding.layout.order", errors)) { if (!["block", "inline"].includes(input.layout.order.axis)) issue(errors, "binding.layout.order.axis", "is unsupported."); integer(input.layout.order.rank, "binding.layout.order.rank", errors); }
    }
    if (shape(input.validation, ["uniqueness", "minimumCoverage", "maximumMultiplicity", "shape", "allowedRoleDrift"], ["uniqueness", "minimumCoverage", "maximumMultiplicity", "shape", "allowedRoleDrift"], "binding.validation", errors)) {
      if (!["exactly-one-per-item", "at-most-one-per-item"].includes(input.validation.uniqueness)) issue(errors, "binding.validation.uniqueness", "is unsupported.");
      finite(input.validation.minimumCoverage, "binding.validation.minimumCoverage", errors);
      integer(input.validation.maximumMultiplicity, "binding.validation.maximumMultiplicity", errors, 1, 64);
      text(input.validation.shape, "binding.validation.shape", errors, { max: 64 });
      if (list(input.validation.allowedRoleDrift, "binding.validation.allowedRoleDrift", errors, 16)) input.validation.allowedRoleDrift.forEach((item, index) => text(item, `binding.validation.allowedRoleDrift.${index}`, errors, { max: 128 }));
    }
    if (shape(input.baseline, ["scope", "coverage", "matchesPerItem", "shapeFingerprint"], ["scope", "coverage", "matchesPerItem", "shapeFingerprint"], "binding.baseline", errors)) {
      if (shape(input.baseline.scope, ["typical", "minimum"], ["typical", "minimum"], "binding.baseline.scope", errors)) { integer(input.baseline.scope.typical, "binding.baseline.scope.typical", errors, 1); integer(input.baseline.scope.minimum, "binding.baseline.scope.minimum", errors, 1); }
      finite(input.baseline.coverage, "binding.baseline.coverage", errors);
      if (list(input.baseline.matchesPerItem, "binding.baseline.matchesPerItem", errors, 64)) input.baseline.matchesPerItem.forEach((item, index) => integer(item, `binding.baseline.matchesPerItem.${index}`, errors, 0, 64));
      text(input.baseline.shapeFingerprint, "binding.baseline.shapeFingerprint", errors, { max: 512 });
    }
    if (shape(input.provenance, ["observationIds", "compiler"], ["observationIds", "compiler"], "binding.provenance", errors)) {
      if (list(input.provenance.observationIds, "binding.provenance.observationIds", errors, 32) && !input.provenance.observationIds.length) issue(errors, "binding.provenance.observationIds", "must preserve at least one authored observation reference.");
      else input.provenance.observationIds?.forEach((item, index) => text(item, `binding.provenance.observationIds.${index}`, errors, { max: 160 }));
      text(input.provenance.compiler, "binding.provenance.compiler", errors, { max: 160 });
    }
    return accepted(input, errors);
  }

  return Object.freeze({ validateObservation, validatePortableBinding });
});
