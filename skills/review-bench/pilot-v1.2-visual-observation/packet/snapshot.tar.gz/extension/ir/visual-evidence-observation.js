(function initializeVisualEvidenceObservation(root, factory) {
  "use strict";
  const contract = root.Site2JsonVisualEvidenceContract
    || (typeof require === "function" ? require("./visual-evidence-contract") : null);
  const api = factory(contract);
  root.Site2JsonVisualEvidenceObservation = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function visualEvidenceObservationFactory(contract) {
  "use strict";

  const localName = (term) => String(term || "").split(/[\/#:]/).filter(Boolean).at(-1) || String(term || "");
  const stable = (value) => {
    if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
    if (value && typeof value === "object") return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stable(value[key])}`).join(",")}}`;
    return JSON.stringify(value);
  };
  function fingerprint(value) {
    let left = 2166136261;
    let right = 3339675911;
    for (const character of stable(value)) {
      left ^= character.charCodeAt(0); left = Math.imul(left, 16777619);
      right ^= character.charCodeAt(0); right = Math.imul(right, 2246822519);
    }
    return `s2j1:${(left >>> 0).toString(16).padStart(8, "0")}${(right >>> 0).toString(16).padStart(8, "0")}`;
  }
  function interpretation(value = {}) {
    value = value || {};
    const kind = ["text", "url", "image", "attribute"].includes(value.kind) ? value.kind : null;
    if (!kind) return null;
    const result = { kind, reader: kind === "image" ? "image-src" : kind };
    if (kind === "attribute" && value.attribute) result.attribute = String(value.attribute);
    return result;
  }
  function repeatedGroup(target) {
    const group = target?.repeatedGroup;
    if (!group || group.mode !== "many") return group?.mode === "one" ? { mode: "one" } : undefined;
    return {
      mode: "many",
      groupObservationId: String(group.groupObservationId),
      selectedItemOrdinal: Number(group.selectedItemOrdinal),
      itemCountAtAuthoring: Number(group.itemCountAtAuthoring),
      scopeFingerprint: String(group.scopeFingerprint)
    };
  }
  function observation({ status, target, selection, context, observationId, authoredAt }) {
    const semantic = target?.semantic || {};
    const selectedInterpretation = interpretation(selection?.interpretation);
    const clickRecorded = Boolean(selection);
    const result = {
      version: 1,
      observationId: String(observationId),
      status,
      target: {
        ...(semantic.typeTerm ? { typeTerm: String(semantic.typeTerm) } : {}),
        propertyTerm: String(semantic.propertyTerm),
        path: String(semantic.path),
        ...(semantic.variantKey ? { variantKey: String(semantic.variantKey) } : {})
      },
      ...(repeatedGroup(target) ? { repeatedGroup: repeatedGroup(target) } : {}),
      provenance: {
        source: clickRecorded ? "human-rendered-page-click" : "human-left-unresolved",
        authoredAt: String(authoredAt),
        pageRevision: String(context?.pageRevision),
        ...(clickRecorded ? { pickerVersion: Number(selection?.pickerVersion) } : {}),
        ...(target?.detectionRunId ? { detectionRunId: String(target.detectionRunId) } : {})
      }
    };
    if (status === "authored" && clickRecorded) {
      result.action = {
        kind: "rendered-page-click",
        ...(selection?.frameUrl ? { frameUrl: String(selection.frameUrl) } : {}),
        element: {
          tag: String(selection?.element?.tag || "unknown"),
          ...(selection?.element?.role ? { role: String(selection.element.role) } : {}),
          candidateFingerprints: (selection?.candidates || []).slice(0, 16).map((candidate) => fingerprint(candidate))
        },
        interpretation: selectedInterpretation
      };
    }
    const validated = contract?.validateObservation?.(result);
    if (!validated?.ok) throw new Error(`Visual Evidence observation is invalid: ${(validated?.errors || ["validator unavailable"]).join(" ")}`);
    return validated.value;
  }

  function detectionTargets(detection) {
    const tree = detection?.effective?.tree;
    const findingByNode = new Map((detection?.effective?.findings || []).map((finding) => [finding.nodeId, finding]));
    if (!tree?.root) return [];
    const topEntities = (tree.root.children || []).filter((node) => node.kind === "entity");
    const count = Math.max(Number(detection?.grouping?.entityCount || topEntities.length), 1);
    const scopeFingerprint = fingerprint({
      kind: detection?.grouping?.kind || "unknown",
      axes: detection?.grouping?.axes || {},
      entityCount: count
    });
    const targets = [];
    const visit = (node, entity, entityIndex, terms) => {
      const nextTerms = node.kind === "entity"
        ? [...terms, ...(node.assignment?.relationship ? [node.assignment.relationship] : []), node.term].filter(Boolean)
        : terms;
      if (node.kind === "value") {
        const finding = findingByNode.get(node.id);
        const propertyTerm = finding?.term || node.term;
        if (!propertyTerm) return;
        const semanticTerms = [...terms, propertyTerm];
        targets.push({
          id: `${detection.id}:${node.id}`,
          entityIndex,
          kind: "field",
          label: semanticTerms.map(localName).join("."),
          semantic: { typeTerm: entity.term, propertyTerm, path: semanticTerms.join(" > "), variantKey: localName(entity.term) },
          currentEvidence: { inferred: true, value: node.value },
          detectionRunId: detection.id,
          repeatedGroup: count > 1 ? { mode: "many", groupObservationId: `group-${fingerprint({ detection: detection.id, count })}`, selectedItemOrdinal: entityIndex, itemCountAtAuthoring: count, scopeFingerprint } : { mode: "one" }
        });
        return;
      }
      for (const child of node.children || []) visit(child, entity, entityIndex, nextTerms);
    };
    topEntities.forEach((entity, index) => visit(entity, entity, index, []));
    return targets;
  }

  function graphTarget(graph, selectedAlias, reference) {
    const routes = [];
    const queue = [{ alias: graph?.root, terms: [...(graph?.nodes?.[graph?.root]?.types || [])], visited: new Set([graph?.root]) }];
    while (queue.length) {
      const current = queue.shift();
      if (current.alias === selectedAlias) routes.push(current.terms);
      for (const edge of (graph?.edges || []).filter((candidate) => candidate.from === current.alias)) {
        if (current.visited.has(edge.to)) continue;
        queue.push({ alias: edge.to, terms: [...current.terms, edge.property, ...(graph?.nodes?.[edge.to]?.types || [])].filter(Boolean), visited: new Set([...current.visited, edge.to]) });
      }
    }
    const uniqueRoutes = [...new Map(routes.map((route) => [stable(route), route])).values()];
    const propertyTerm = reference?.property;
    const nodeTypes = [...new Set(graph?.nodes?.[selectedAlias]?.types || [])];
    const resolved = uniqueRoutes.length === 1 && propertyTerm;
    const terms = resolved ? [...uniqueRoutes[0], propertyTerm] : [propertyTerm].filter(Boolean);
    return {
      id: `graph:${fingerprint({ routes: uniqueRoutes, propertyTerm })}`,
      kind: "field",
      label: [...nodeTypes.map(localName), localName(propertyTerm)].filter(Boolean).join("."),
      semantic: {
        ...(nodeTypes.length === 1 ? { typeTerm: nodeTypes[0] } : {}),
        propertyTerm: String(propertyTerm || "unresolved-property"),
        path: resolved ? terms.join(" > ") : String(propertyTerm || "unresolved-property")
      },
      resolution: resolved ? "resolved" : "unresolved",
      alternatives: uniqueRoutes.map((route) => [...route, propertyTerm].filter(Boolean).join(" > ")),
      currentEvidence: null,
      repeatedGroup: { mode: "one" }
    };
  }

  return Object.freeze({ detectionTargets, fingerprint, graphTarget, observation });
});
