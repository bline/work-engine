(function initializeDurableBindingReconstruction(root, factory) {
  "use strict";
  const sourceBindings = root.Site2JsonSourceBindings || (typeof require === "function" ? require("./source-bindings") : null);
  const selectorCandidates = root.Site2JsonSelectorCandidates || (typeof require === "function" ? require("../editor/selector-candidates") : null);
  const api = factory(sourceBindings, selectorCandidates);
  root.Site2JsonDurableBindingReconstruction = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function durableBindingReconstructionFactory(sourceBindings, selectorCandidates) {
  "use strict";

  function freezeDeep(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    for (const child of Object.values(value)) freezeDeep(child);
    return Object.freeze(value);
  }

  function text(value) {
    return String(value ?? "").replace(/\s+/g, " ").trim();
  }

  function sameNodes(actual, intended) {
    return actual.length === intended.length && actual.every((node, index) => node === intended[index]);
  }

  function provenance(node, sourceCount, method = null) {
    return {
      decision: method ? "reconstructed" : "cannot-reconstruct",
      semanticNodeId: typeof node?.id === "string" ? node.id : null,
      identityScope: "detection-run",
      sourceCount,
      ...(method ? { method } : {})
    };
  }

  function failure(node, reason, sourceCount = 0, detail = null) {
    return freezeDeep({ ok: false, status: "cannot-reconstruct", reason, ...(detail ? { detail } : {}), provenance: provenance(node, sourceCount) });
  }

  function readOptions(node, element) {
    if (!Object.prototype.hasOwnProperty.call(node || {}, "value")) return [{}];
    const expected = text(node.value);
    const options = [];
    if (text(element.textContent) === expected) options.push({ read: "text" });
    for (const attribute of element.getAttributeNames?.() || []) {
      if (text(element.getAttribute(attribute)) === expected) options.push({ read: "attribute", attribute });
    }
    return options;
  }

  function verifyRead(binding, resolved, node) {
    if (!Object.prototype.hasOwnProperty.call(node || {}, "value")) return true;
    return text(sourceBindings.read(binding, resolved)) === text(node.value);
  }

  function durableCandidates(element, scope, document) {
    return selectorCandidates.generateScopedCandidates(element, scope, document).filter((candidate) => candidate.kind !== "fallback");
  }

  function success(node, binding, resolved, method) {
    const normalized = sourceBindings.normalize({ reconstructed: binding }).reconstructed;
    return freezeDeep({
      ok: true,
      status: "reconstructed",
      binding: normalized,
      verification: {
        roundTripped: true,
        sourceCount: Array.isArray(resolved) ? resolved.length : 1,
        valueRead: Object.prototype.hasOwnProperty.call(node || {}, "value") ? sourceBindings.read(normalized, resolved) : null
      },
      provenance: provenance(node, Array.isArray(resolved) ? resolved.length : 1, method)
    });
  }

  function selectorBinding(node, sources, document, scope) {
    for (const candidate of durableCandidates(sources[0], scope, document)) {
      const base = { kind: "selector", selector: candidate.selector, all: true };
      const resolved = sourceBindings.resolve(base, scope);
      if (!sameNodes(resolved, sources)) continue;
      for (const reading of readOptions(node, sources[0])) {
        const binding = { ...base, ...reading };
        if (verifyRead(binding, resolved, node)) return success(node, binding, resolved, "selector");
      }
    }
    return null;
  }

  function sequenceBinding(node, sources, document, scope) {
    const container = sources[0]?.parentElement;
    if (!container || sources.some((source) => source.parentElement !== container)) return null;
    const children = Array.from(container.children || []);
    const start = children.indexOf(sources[0]);
    if (start < 0 || !sameNodes(children.slice(start, start + sources.length), sources)) return null;

    const withinCandidates = container === document.documentElement
      ? [{ selector: ":root", kind: "structure" }]
      : durableCandidates(container, scope, document);
    const startCandidates = durableCandidates(sources[0], container, document);
    for (const within of withinCandidates) {
      for (const startsWith of startCandidates) {
        const base = { kind: "sequence", within: within.selector, startsWith: startsWith.selector, directChildren: true };
        const groups = sourceBindings.resolve(base, scope);
        if (groups.length !== 1 || !Array.isArray(groups[0]) || !sameNodes(groups[0], sources)) continue;
        for (const reading of readOptions(node, sources[0])) {
          const binding = { ...base, ...reading };
          if (verifyRead(binding, groups[0], node)) return success(node, binding, groups[0], "sequence");
        }
      }
    }
    return null;
  }

  function reconstruct(input = {}) {
    const node = input.node || null;
    const document = input.document || null;
    const referenced = input.sources ?? input.sourceRefs?.get?.(node?.id);
    const sources = Array.isArray(referenced) ? [...referenced] : referenced ? [referenced] : [];
    if (!document?.querySelectorAll) return failure(node, "missing-document", sources.length);
    if (!sources.length) return failure(node, "missing-source", 0);
    if (sources.some((source) => source?.nodeType !== 1 || source.ownerDocument !== document)) {
      return failure(node, "non-element-source", sources.length, "Every source must be a live element in the supplied document.");
    }
    if (new Set(sources).size !== sources.length) return failure(node, "ambiguous-source", sources.length, "Source contributions must be distinct and ordered.");

    const scope = input.scope || document;
    if (scope !== document && (scope?.nodeType !== 1 || scope.ownerDocument !== document)) return failure(node, "invalid-scope", sources.length);
    const selector = selectorBinding(node, sources, document, scope);
    if (selector) return selector;
    const sequence = sources.length > 1 ? sequenceBinding(node, sources, document, scope) : null;
    if (sequence) return sequence;
    return failure(node, "no-durable-round-trip", sources.length, "Only fragile or inexact selector/sequence candidates were available.");
  }

  return Object.freeze({ reconstruct });
});
