(function initializeNormalization(root, factory) {
  "use strict";
  const semanticDom = root.Site2JsonSemanticDom || (typeof require === "function" ? require("./semantic-dom") : null);
  const sourceBindings = root.Site2JsonSourceBindings || (typeof require === "function" ? require("./source-bindings") : null);
  const fieldObservation = root.Site2JsonIrFieldObservation || (typeof require === "function" ? require("./field-observation") : null);
  const api = factory(semanticDom, sourceBindings, fieldObservation);
  root.Site2JsonNormalization = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function normalizationFactory(semanticDom, sourceBindings, fieldObservation) {
  "use strict";

  function normalize(document, plan = {}) {
    const bindings = sourceBindings.normalize(plan.bindings || {});
    const collection = plan.collection || {};
    const itemBinding = bindings[collection.items];
    if (!itemBinding) throw new Error(`Collection item binding ${collection.items || "(empty)"} was not found.`);
    const itemSources = sourceBindings.resolve(itemBinding, document);
    const sourceRefs = new Map();
    const entities = itemSources.map((itemSource, index) => {
      const entityId = `${collection.id || "collection"}:item:${index + 1}`;
      sourceRefs.set(entityId, itemSource);
      const children = (collection.values || []).map((field) => {
        const binding = bindings[field.source];
        if (!binding) throw new Error(`Value binding ${field.source || "(empty)"} was not found.`);
        const valueId = `${entityId}:value:${field.id}`;
        const resolved = sourceBindings.resolve(binding, itemSource);
        sourceRefs.set(valueId, resolved);
        return { id: valueId, kind: "value", term: field.term, source: field.source, children: [] };
      });
      return { id: entityId, kind: "entity", term: collection.type, source: collection.items, children };
    });
    const tree = semanticDom.document({
      id: collection.id || "collection",
      kind: "collection",
      term: collection.type,
      source: collection.source || collection.items,
      children: entities
    });
    return Object.freeze({ tree, bindings, sourceRefs });
  }

  function observe(document, plan = {}) {
    const bindings = sourceBindings.normalize(plan.bindings || {});
    const collection = plan.collection || {};
    const itemBinding = bindings[collection.items];
    if (!itemBinding) throw new Error(`Collection item binding ${collection.items || "(empty)"} was not found.`);
    const itemSources = sourceBindings.resolve(itemBinding, document);
    return observeSources(document, plan, itemSources, { kind: itemBinding.kind, binding: collection.items }, bindings);
  }

  function observeSources(document, plan = {}, itemSources = [], grouping = {}, suppliedBindings = null) {
    const bindings = suppliedBindings || sourceBindings.normalize(plan.bindings || {});
    const collection = plan.collection || {};
    const sourceRefs = new Map();
    const entities = itemSources.map((itemSource, index) => {
      const entityId = `${collection.id || "collection"}:item:${index + 1}`;
      sourceRefs.set(entityId, itemSource);
      const children = [];
      for (const field of collection.observations || []) {
        const binding = bindings[field.source];
        if (!binding) throw new Error(`Observation binding ${field.source || "(empty)"} was not found.`);
        const resolved = sourceBindings.resolve(binding, itemSource);
        const values = resolved.map((source) => sourceBindings.read(binding, source)).filter((value) => value !== null && value !== "");
        if (!values.length && field.optional !== false) continue;
        const value = binding.multiple ? values : values[0];
        if (value === undefined) continue;
        const valueId = `${entityId}:observation:${field.id}`;
        sourceRefs.set(valueId, resolved);
        children.push({
          id: valueId,
          kind: "value",
          role: field.role || field.id,
          source: field.source,
          value,
          confidence: field.confidence ?? 1,
          provenance: [{ source: field.source, family: field.family || "dom", decision: "observed", confidence: field.confidence ?? 1 }],
          children: []
        });
      }
      return { id: entityId, kind: "entity", source: collection.items || grouping.id || "inferred-group", children };
    });
    const tree = semanticDom.document({
      id: collection.id || "collection",
      kind: "collection",
      source: collection.source || collection.items || grouping.id || "inferred-group",
      children: entities
    });
    return Object.freeze({ tree, bindings, sourceRefs, grouping: { ...grouping } });
  }

  function observeDetectedSources(document, plan = {}, itemSources = [], grouping = {}) {
    const collection = plan.collection || {};
    const sourceRefs = new Map();
    const entities = itemSources.map((itemSource, index) => {
      const entityId = `${collection.id || "collection"}:item:${index + 1}`;
      sourceRefs.set(entityId, itemSource);
      const detected = fieldObservation.observe(itemSource, { singleton: itemSources.length === 1 });
      const children = detected.map((observation, observationIndex) => {
        const valueId = `${entityId}:observation:${observation.role}:${observationIndex + 1}`;
        if (observation.sourceNode) sourceRefs.set(valueId, [observation.sourceNode]);
        return {
          id: valueId,
          kind: "value",
          role: observation.role,
          source: observation.source,
          value: observation.value,
          confidence: observation.confidence,
          provenance: [{
            source: observation.source,
            family: observation.family,
            decision: "observed",
            confidence: observation.confidence
          }],
          children: []
        };
      });
      return { id: entityId, kind: "entity", source: grouping.id || "inferred-group", children };
    });
    const tree = semanticDom.document({
      id: collection.id || "collection",
      kind: "collection",
      source: grouping.id || "inferred-group",
      children: entities
    });
    return Object.freeze({ tree, bindings: Object.freeze({}), sourceRefs, grouping: { ...grouping } });
  }

  return Object.freeze({ normalize, observe, observeSources, observeDetectedSources });
});
