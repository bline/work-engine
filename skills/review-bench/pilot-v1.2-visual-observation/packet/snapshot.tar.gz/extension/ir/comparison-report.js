(function initializeIrComparisonReport(root, factory) {
  "use strict";
  const dsl = root.Site2JsonDsl || (typeof require === "function" ? require("../core/dsl") : null);
  const pipeline = root.Site2JsonIrPipeline || (typeof require === "function" ? require("./pipeline") : null);
  const api = factory(dsl, pipeline);
  root.Site2JsonIrComparisonReport = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irComparisonReportFactory(dsl, pipeline) {
  "use strict";

  function build(result, label = "V2 semantic-DOM run") {
    const observedEntities = result.observed.tree.root.children.filter((node) => node.kind === "entity");
    return Object.freeze({
      label,
      grouping: {
        collectionId: result.observed.tree.root.id,
        strategy: result.observed.grouping || null,
        alternatives: (result.grouping?.candidates || []).map((candidate) => ({
          id: candidate.id,
          kind: candidate.kind,
          score: candidate.score,
          axes: candidate.axes,
          hardValid: candidate.hardValid,
          evidence: candidate.evidence,
          entityCount: candidate.sources.length
        })),
        entityCount: observedEntities.length,
        entities: observedEntities.map((entity) => ({
          id: entity.id,
          observations: entity.children.map((value) => ({ role: value.role, value: value.value, source: value.source }))
        }))
      },
      mappings: result.properties.findings.map((finding) => ({ ...finding })),
      variants: result.types.reports.map((report) => ({
        entityId: report.entityId,
        selected: report.selected,
        accepted: report.accepted,
        winner: report.winner,
        leading: report.leading,
        runnerUp: report.runnerUp,
        margin: report.margin,
        alternatives: report.ranked
      })),
      validation: {
        observed: true,
        assigned: result.validation?.ok !== false,
        reviewRequired: result.properties.findings.some((finding) => finding.status !== "assigned")
          || result.types.reports.some((report) => !report.accepted)
      },
      output: result.output
    });
  }

  function comparableEntity(entity) {
    return Object.fromEntries(Object.entries(entity || {})
      .filter(([key]) => key !== "@id")
      .sort(([left], [right]) => left.localeCompare(right)));
  }

  function comparableGraph(graph) {
    return (graph || []).map(comparableEntity);
  }

  function failure(error) {
    return error ? { failed: true, name: error.name || "Error", message: String(error.message || error) } : { failed: false, name: null, message: null };
  }

  function executeV1(document, config) {
    try {
      const pageUrl = new URL(config.url || document.URL || "https://example.invalid/");
      const observation = dsl.compile(config.definition).extract(document, pageUrl);
      const graph = observation.blocks.flatMap((block) => block.entities || []);
      const warnings = observation.warnings || [];
      return {
        engine: "v1-dsl",
        output: { "@graph": graph },
        comparableOutput: comparableGraph(graph),
        explanations: { pageType: observation.pageType, blocks: observation.blocks, warnings },
        confidence: {
          exposed: true,
          stopped: false,
          unresolved: warnings.filter((item) => item.code === "variant.ambiguous").reduce((sum, item) => sum + Number(item.count || 0), 0),
          decisions: warnings.filter((item) => /ambiguous|confidence/i.test(String(item.code || "")))
        },
        failure: failure(null)
      };
    } catch (error) {
      return { engine: "v1-dsl", output: null, comparableOutput: null, explanations: null, confidence: { exposed: false, stopped: true, unresolved: null, decisions: [] }, failure: failure(error) };
    }
  }

  function executeV2(document, config) {
    try {
      const result = pipeline.infer(document, config.plan || {}, config.options || {});
      const report = build(result, config.label || "V2 semantic-DOM run");
      const unresolved = report.variants.filter((item) => !item.accepted).length + report.mappings.filter((item) => item.status !== "assigned").length;
      return {
        engine: "v2-semantic-dom",
        output: result.output.data,
        comparableOutput: comparableGraph(result.output.data["@graph"]),
        explanations: report,
        confidence: {
          exposed: true,
          stopped: false,
          unresolved,
          decisions: {
            grouping: report.grouping.strategy,
            mappings: report.mappings,
            variants: report.variants
          }
        },
        failure: failure(null)
      };
    } catch (error) {
      return { engine: "v2-semantic-dom", output: null, comparableOutput: null, explanations: null, confidence: { exposed: false, stopped: true, unresolved: null, decisions: [] }, failure: failure(error) };
    }
  }

  function compare(document, { label = "V1 / V2 comparison", v1, v2 } = {}) {
    if (!v1?.definition) throw new Error("A V1 DSL definition is required for comparison.");
    if (!v2?.plan) throw new Error("A V2 inference plan is required for comparison.");
    const legacy = executeV1(document, v1);
    const semanticDom = executeV2(document, { ...v2, label });
    const bothSucceeded = !legacy.failure.failed && !semanticDom.failure.failed;
    return Object.freeze({
      label,
      v1: legacy,
      v2: semanticDom,
      deltas: {
        bothSucceeded,
        outputEqual: bothSucceeded && JSON.stringify(legacy.comparableOutput) === JSON.stringify(semanticDom.comparableOutput),
        unresolved: bothSucceeded ? semanticDom.confidence.unresolved - legacy.confidence.unresolved : null,
        failureChanged: legacy.failure.failed !== semanticDom.failure.failed
      }
    });
  }

  return Object.freeze({ build, compare });
});
