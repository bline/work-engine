(function initializeIrProvenance(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonIrProvenance = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irProvenanceFactory() {
  "use strict";

  function finding(input = {}) {
    return Object.freeze({
      source: String(input.source || "unknown"),
      family: String(input.family || "unknown"),
      decision: String(input.decision || "proposal"),
      confidence: Math.max(0, Math.min(1, Number(input.confidence || 0))),
      message: String(input.message || "")
    });
  }

  return Object.freeze({ finding });
});
