# Site2JSON S2J Markup and Semantic DOM

This directory is the isolated pre-release v2 implementation described in [`docs/artificial-semantic-dom.md`](../../docs/artificial-semantic-dom.md).

The first slice intentionally has no dependency on the existing DSL. It proves that ordinary wrapped cards and flat sibling sequences can produce the same portable collection/entity/value tree and resolve through the same extraction code.

**S2J Markup** is the portable collection/entity/value intermediate format. The **Semantic DOM** is the live object model used by the runtime and editor. Live page DOM nodes remain in an ephemeral source-reference map returned by normalization; they are never serialized into S2J Markup.

The second slice adds a complete, self-contained path:

- `semantic-assignment.js` jointly maps neutral observation roles to vocabulary properties and classifies entity types with ranked alternatives and margins;
- `../authoring/semantic-assignment-profile.js` compiles Schema.org domain/range relationships, reviewed nested-materialization rules, and installed local-vocabulary terms into a bounded profile; runtime assignment consumes that profile without loading the catalog or local storage;
- `../authoring/page-semantic-profile.js` converts the typeless page survey into a bounded, provenance-bearing type shortlist through the existing Semantic Library inference index. Repeated cards contribute occurrence counts and samples without pretending each repetition is independent semantic evidence. Weaker duplicate interpretations must stay inside the score band, while candidates explaining distinct observations remain eligible for heterogeneous pages;
- `schema-assignment.js` and `type-assignment.js` remain comparison primitives, but the V2 pipeline no longer makes those decisions sequentially;
- `serialization.js` emits JSON-LD data plus assignment provenance;
- `pipeline.js` runs neutral observation through validated output;
- `comparison-report.js` exposes grouping, mappings, variants, and output for fixture comparison.
- `grouping-inference.js` proposes sibling collections, flat heading-led sequences, and singleton detail regions, then ranks them on usefulness, repetition consistency, and entity independence.
- `field-observation.js` materializes bounded neutral heading, canonical identity, descriptive text, date, employment, author, price, and salary observations without fixture-supplied field selectors.
- `page-detection.js` evaluates many bounded grouping candidates through those same observation and semantic-assignment primitives. It preserves rejected and overlapping alternatives with reasons while selecting multiple credible, non-duplicative groups across the current page. The detector accepts a compiled profile but has no graph-editor or icon dependency.

`pipeline.infer()` remains the single-leading-group primitive used by the current live preview. `page-detection.survey()` is the typeless authoring preflight; `pipeline.detectPage()` is the detection-first runtime primitive. The editor runs survey → shared Schema/Semantic Library ranking → bounded profile compilation → page detection, while only the compact profile crosses back into the page. Detection returns every selected page group plus the candidate ledger that explains what was rejected, deferred, or retained for review. A selected group is not presented as proof that the page is fully understood; unresolved semantic assignments remain explicit review state.

Relationship materialization is explicit rather than inferred from arbitrary ontology reachability. The compiler converts the selected semantic composition's typed edges and per-node priority fields into bounded relationship paths. Multiple observations coalesce into one related entity, custom-vocabulary terms retain provenance, and deep paths serialize recursively. The packaged `Product.offers -> Offer.price` rule remains the safe default when no authored graph supplies it. Valid but unreviewed graph paths remain authoring possibilities; they do not invent runtime entities.

## Browser preview

The semantic graph editor can compile its unsaved working graph and run this pipeline against the current rendered page with **Preview live data**. The preview is ephemeral: it neither applies the graph nor changes the adapter. Only the compact compiled profile and a minimal runtime plan cross into the page; the generated catalog and semantic-library storage remain in the editor. The result crossing back is JSON-safe output, counts, timing, grouping evidence, and assignment reports—never live DOM nodes.

This is the first browser-facing V2 action and the foundation for the planned split graph/live-data authoring surface. V2 injection is lazy and separate from the existing selector bridge, so ordinary highlighting and V1 authoring actions do not load the V2 runtime.

## Selection and introspection

The graph, rendered page, S2J Markup, and output projections are different views of one extraction decision. Each live preview now builds an ephemeral focus index from the assigned Semantic DOM: graph aliases and relationships point to stable semantic node IDs, those IDs point to precise JSON Pointer-style paths in S2J Markup, Compact JSON, and JSON-LD, and the page-local source-reference map points to the rendered evidence. No DOM node crosses the extension bridge.

Selecting a graph node or relationship therefore highlights its actual output subtree and its actual rendered source elements rather than searching for matching type-name text. Conversely, a preview row with recorded provenance is keyboard- and pointer-focusable and selects the most specific graph node that owns it. Page overlays intentionally remain non-interactive so they do not intercept the inspected site's controls; page-to-graph focus is not claimed by this slice.

This synchronized-selection contract precedes richer execution animation. It supports immediate authoring tasks—selecting a semantic node, scrolling the page to the observations assigned to it, and emphasizing the corresponding preview rows—and later supports a flow view in which observed results visibly travel through classification decisions into semantic buckets. That visualization must remain an explanation of the same recorded provenance and scoring events, not a separate extraction pipeline.
