(function initializeIrTypeAssignment(root, factory) {
  "use strict";
  const semanticDom = root.Site2JsonSemanticDom || (typeof require === "function" ? require("./semantic-dom") : null);
  const api = factory(semanticDom);
  root.Site2JsonIrTypeAssignment = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irTypeAssignmentFactory(semanticDom) {
  "use strict";

  const SCHEMA = "https://schema.org/";
  const DEFAULT_TYPES = Object.freeze([
    { term: `${SCHEMA}JobPosting`, signals: { [`${SCHEMA}datePosted`]: 4, [`${SCHEMA}employmentType`]: 4, [`${SCHEMA}baseSalary`]: 3, [`${SCHEMA}name`]: 1 } },
    { term: `${SCHEMA}Article`, signals: { [`${SCHEMA}datePublished`]: 4, [`${SCHEMA}author`]: 3, [`${SCHEMA}name`]: 1 } },
    // Product price is expressed through Product.offers -> Offer.price. Until
    // relationship materialization supplies that shape, a direct price value
    // must not manufacture Product support in the conservative fallback.
    { term: `${SCHEMA}Product`, signals: { [`${SCHEMA}name`]: 1 } },
    { term: `${SCHEMA}Thing`, signals: { [`${SCHEMA}name`]: 1 } }
  ]);

  function classify(entity, types, options) {
    const present = new Set(entity.children.filter((child) => child.kind === "value" && child.term).map((child) => child.term));
    const ranked = types.map((type) => {
      const matched = Object.entries(type.signals || {}).filter(([term]) => present.has(term));
      const score = matched.reduce((sum, [, weight]) => sum + Number(weight || 0), 0);
      return { term: type.term, score, matched: matched.map(([term]) => term) };
    }).sort((left, right) => right.score - left.score || left.term.localeCompare(right.term));
    const leading = ranked[0] || { term: `${SCHEMA}Thing`, score: 0, matched: [] };
    const runnerUp = ranked[1] || { term: null, score: 0, matched: [] };
    const margin = leading.score - runnerUp.score;
    const tied = Boolean(runnerUp.term && leading.score === runnerUp.score);
    const accepted = !tied && leading.score >= (options.minScore ?? 3) && margin >= (options.minMargin ?? 2);
    const fallback = options.fallback || `${SCHEMA}Thing`;
    return {
      winner: tied ? null : leading,
      leading,
      runnerUp,
      margin,
      tied,
      accepted,
      selected: accepted ? leading.term : fallback,
      ranked
    };
  }

  function assign(tree, options = {}) {
    const types = options.types || DEFAULT_TYPES;
    const reports = [];
    function visit(node) {
      const children = (node.children || []).map(visit);
      if (node.kind !== "entity") return { ...node, children };
      const report = classify({ ...node, children }, types, options);
      reports.push({ entityId: node.id, ...report });
      const confidence = report.leading.score ? report.margin / report.leading.score : 0;
      return {
        ...node,
        term: report.selected,
        confidence,
        assignment: { stage: "schema-type", accepted: report.accepted, margin: report.margin, confidence },
        typeCandidates: report.ranked,
        provenance: [...(node.provenance || []), {
          source: "type-assignment",
          family: "semantic-shape",
          decision: report.selected,
          confidence,
          margin: report.margin
        }],
        children
      };
    }
    const assigned = semanticDom.document(visit(tree.root));
    return Object.freeze({ tree: assigned, reports: Object.freeze(reports) });
  }

  return Object.freeze({ DEFAULT_TYPES, classify, assign });
});
