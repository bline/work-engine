(function initializeIrFieldObservation(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonIrFieldObservation = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irFieldObservationFactory() {
  "use strict";

  const MAX_NODES = 240;

  function roots(source) {
    return (Array.isArray(source) ? source : [source]).filter(Boolean);
  }

  function text(node) {
    return String(node?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function nodes(source) {
    const result = [];
    for (const root of roots(source)) {
      if (root?.nodeType === 1) result.push(root);
      if (root?.querySelectorAll) result.push(...root.querySelectorAll("*"));
      if (result.length >= MAX_NODES) break;
    }
    return [...new Set(result)].slice(0, MAX_NODES);
  }

  function classText(node) {
    return String(node?.getAttribute?.("class") || "").toLowerCase();
  }

  function depth(node) {
    let result = 0;
    for (let current = node; current?.parentElement; current = current.parentElement) result += 1;
    return result;
  }

  function add(best, input) {
    if (input.value === null || input.value === undefined || input.value === "") return;
    const current = best.get(input.role);
    if (!current || input.confidence > current.confidence) best.set(input.role, Object.freeze(input));
  }

  function canonicalUrl(document) {
    return document?.querySelector?.('link[rel="canonical"]')?.getAttribute?.("href")
      || document?.baseURI
      || "";
  }

  function relativePostedDate(value, now = Date.now()) {
    const rendered = String(value || "").replace(/\s+/g, " ").trim();
    if (!/\bposted\b/i.test(rendered)) return null;
    const instant = new Date(now);
    if (!Number.isFinite(instant.getTime())) return null;
    if (/\bposted\s+(?:just\s+now|today)\b/i.test(rendered)) return instant.toISOString();
    if (/\bposted\s+yesterday\b/i.test(rendered)) {
      instant.setUTCDate(instant.getUTCDate() - 1);
      return instant.toISOString();
    }
    const match = rendered.match(/\bposted\s+(?:about\s+)?(\d+)\s*(mins?|minutes?|hrs?|hours?|days?|weeks?)\s+ago\b/i);
    if (!match) return null;
    const amount = Number(match[1]);
    const unit = match[2].toLowerCase();
    const milliseconds = /^(?:min|minute)/.test(unit) ? 60_000
      : /^(?:hr|hour)/.test(unit) ? 3_600_000
        : /^day/.test(unit) ? 86_400_000
          : 604_800_000;
    instant.setTime(instant.getTime() - amount * milliseconds);
    return instant.toISOString();
  }

  function absolutePostedDate(value) {
    const rendered = String(value || "").replace(/\s+/g, " ").trim();
    const match = rendered.match(/\bposted\s+(?:on\s+)?(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+(\d{1,2}),\s*(\d{4})\b/i);
    if (!match) return null;
    const months = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
    const month = months[match[1].slice(0, 3).toLowerCase()];
    const day = Number(match[2]);
    const year = Number(match[3]);
    const instant = new Date(Date.UTC(year, month - 1, day));
    if (instant.getUTCFullYear() !== year || instant.getUTCMonth() !== month - 1 || instant.getUTCDate() !== day) return null;
    return `${year.toString().padStart(4, "0")}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`;
  }

  function renderedPostedDate(value, now) {
    return relativePostedDate(value, now) || absolutePostedDate(value);
  }

  function observe(source, options = {}) {
    const all = nodes(source);
    const best = new Map();
    const document = all[0]?.ownerDocument;
    const heading = all.find((node) => node.matches?.("h1"))
      || all.find((node) => node.matches?.("h2, h3") && node.querySelector?.("a[href]"))
      || all.find((node) => node.matches?.("h2, h3"));
    if (heading) add(best, { role: "title", value: text(heading), confidence: heading.matches("h1") ? 0.98 : 0.93, family: "semantic-html", sourceNode: heading, source: "dom:heading-text" });

    const headingLink = heading?.querySelector?.("a[href]") || (heading?.matches?.("a[href]") ? heading : null);
    if (headingLink) add(best, { role: "url", value: headingLink.getAttribute("href"), confidence: 0.98, family: "attribute", sourceNode: headingLink, source: "dom:heading-link-href" });
    if (!headingLink && options.singleton !== false) {
      const url = canonicalUrl(document);
      if (url && !/^about:blank/.test(url)) add(best, { role: "url", value: url, confidence: 0.96, family: "document", sourceNode: null, source: "document:canonical-url" });
    }

    const proseArticle = all.find((node) => node.matches?.("article") && text(node).length >= 80);
    const described = all.find((node) => /(^|[^a-z])(desc(?:ription)?|summary|snippet)([^a-z]|$)/.test(classText(node)) && text(node).length >= 20);
    const paragraph = all.find((node) => node.matches?.("p") && text(node).length >= 20);
    const description = described || proseArticle || paragraph;
    if (description) add(best, { role: "description", value: text(description), confidence: described ? 0.95 : proseArticle ? 0.9 : 0.72, family: "rendered-text", sourceNode: description, source: "dom:descriptive-text" });

    const renderedPosted = all.map((node) => ({ node, rendered: text(node) }))
      .map((candidate) => ({ ...candidate, value: renderedPostedDate(candidate.rendered, options.now) }))
      .filter(({ value }) => value)
      .sort((left, right) => left.rendered.length - right.rendered.length || depth(right.node) - depth(left.node))[0];
    if (renderedPosted) {
      add(best, {
        role: "datePosted",
        value: renderedPosted.value,
        confidence: 0.94,
        family: "rendered-text",
        sourceNode: renderedPosted.node,
        source: relativePostedDate(renderedPosted.rendered, options.now) ? "dom:relative-posted-text" : "dom:absolute-posted-text"
      });
    }

    for (const node of all) {
      if (node.matches?.("time")) {
        const value = node.getAttribute("datetime") || text(node);
        const vocabulary = `${classText(node)} ${node.getAttribute("itemprop") || ""}`.toLowerCase();
        const role = /posted/.test(vocabulary) ? "datePosted" : /published/.test(vocabulary) ? "datePublished" : "date";
        add(best, { role, value, confidence: role === "date" ? 0.72 : 0.97, family: "semantic-html", sourceNode: node, source: "dom:time" });
      }
      const vocabulary = `${classText(node)} ${node.getAttribute?.("itemprop") || ""}`.toLowerCase();
      if (/employment/.test(vocabulary) && text(node)) add(best, { role: "employmentType", value: text(node), confidence: 0.94, family: "dom-vocabulary", sourceNode: node, source: "dom:employment-label" });
      if (/author/.test(vocabulary) && text(node)) add(best, { role: "author", value: text(node), confidence: 0.92, family: "dom-vocabulary", sourceNode: node, source: "dom:author-label" });
      if (/(^|\s)price(\s|$)/.test(vocabulary) && text(node)) add(best, { role: "price", value: text(node), confidence: 0.9, family: "dom-vocabulary", sourceNode: node, source: "dom:price-label" });
      if (node.matches?.("dt") && /base\s+salary|salary\s+range|salary/i.test(text(node))) {
        const valueNode = node.parentElement?.querySelector?.("dd") || node.nextElementSibling;
        if (text(valueNode)) add(best, { role: "salary", value: text(valueNode), confidence: 0.96, family: "label-value", sourceNode: valueNode, source: "dom:salary-definition" });
      }
    }

    return Object.freeze([...best.values()]);
  }

  return Object.freeze({ MAX_NODES, observe, relativePostedDate, absolutePostedDate, renderedPostedDate });
});
