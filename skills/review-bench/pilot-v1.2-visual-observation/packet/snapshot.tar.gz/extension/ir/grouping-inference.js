(function initializeIrGroupingInference(root, factory) {
  "use strict";
  const sourceBindings = root.Site2JsonSourceBindings || (typeof require === "function" ? require("./source-bindings") : null);
  const fieldObservation = root.Site2JsonIrFieldObservation || (typeof require === "function" ? require("./field-observation") : null);
  const api = factory(sourceBindings, fieldObservation);
  root.Site2JsonIrGroupingInference = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irGroupingInferenceFactory(sourceBindings, fieldObservation) {
  "use strict";

  const MAX_ELEMENTS = 500;
  const MAX_CANDIDATES = 120;
  const HASH_SEED = 0x811c9dc5;
  const HASH_PRIME = 0x01000193;

  function roots(source) {
    return Array.isArray(source) ? source : [source];
  }

  function observationShape(source, observations, bindings, options = {}) {
    if (!observations.length) {
      const detected = fieldObservation.observe(source, options);
      return {
        roles: detected.map((item) => item.role).sort(),
        values: Object.fromEntries(detected.map((item) => [item.role, item.value])),
        observations: detected
      };
    }
    const roles = [];
    const values = {};
    for (const observation of observations) {
      const binding = bindings[observation.source];
      if (!binding) continue;
      const resolved = sourceBindings.resolve(binding, source);
      const read = resolved.map((item) => sourceBindings.read(binding, item)).filter((value) => value !== null && value !== "");
      if (!read.length) continue;
      const role = observation.role || observation.id;
      roles.push(role);
      values[role] = binding.multiple ? read : read[0];
    }
    return { roles: [...new Set(roles)].sort(), values };
  }

  function jaccard(left, right) {
    const a = new Set(left);
    const b = new Set(right);
    const union = new Set([...a, ...b]);
    if (!union.size) return 0;
    let intersection = 0;
    for (const value of a) if (b.has(value)) intersection += 1;
    return intersection / union.size;
  }

  function meanPairConsistency(shapes) {
    if (shapes.length < 2) return 1;
    let total = 0;
    let count = 0;
    for (let left = 0; left < shapes.length; left += 1) {
      for (let right = left + 1; right < shapes.length; right += 1) {
        total += jaccard(shapes[left].roles, shapes[right].roles);
        count += 1;
      }
    }
    return count ? total / count : 0;
  }

  function independentSources(sources, shapes) {
    if (sources.length < 2) return 1;
    let contained = 0;
    for (let left = 0; left < sources.length; left += 1) {
      for (let right = 0; right < sources.length; right += 1) {
        if (left === right) continue;
        const leftRoots = roots(sources[left]);
        const rightRoots = roots(sources[right]);
        if (leftRoots.some((a) => rightRoots.some((b) => a !== b && a?.contains?.(b)))) contained += 1;
      }
    }
    const identities = shapes.map((shape) => String(shape.values.url || "").trim()).filter(Boolean);
    const identityScore = identities.length === sources.length ? new Set(identities).size / identities.length : 0.5;
    const containmentScore = contained ? 0 : 1;
    return Math.min(identityScore, containmentScore);
  }

  function evaluate(candidate, observations, bindings) {
    const shapes = candidate.sources.map((source) => observationShape(source, observations, bindings, { singleton: candidate.sources.length === 1 }));
    const fieldCount = Math.max(4, observations.length, ...shapes.map((shape) => shape.roles.length));
    const usefulness = shapes.reduce((sum, shape) => sum + shape.roles.length / fieldCount, 0) / Math.max(1, shapes.length);
    const consistency = meanPairConsistency(shapes);
    const independence = independentSources(candidate.sources, shapes);
    const coreRoles = new Set(["title", "heading", "url", "description"]);
    const distinguishingRoles = new Set(["datePosted", "datePublished", "employmentType", "salary", "author", "price"]);
    const semanticCoherence = shapes.reduce((sum, shape) => {
      const core = shape.roles.filter((role) => coreRoles.has(role)).length;
      const distinguishing = shape.roles.some((role) => distinguishingRoles.has(role));
      return sum + Math.min(1, core / 2 * 0.6 + (distinguishing ? 0.4 : 0));
    }, 0) / Math.max(1, shapes.length);
    const repeated = candidate.sources.length > 1;
    const hardValid = !repeated || independence >= 0.75;
    const score = usefulness * 40
      + (repeated ? 20 : 0)
      + consistency * (repeated ? 15 : 5)
      + independence * (repeated ? 20 : 0)
      + semanticCoherence * 10
      + (candidate.kind === "sequence" ? 4 : 0)
      - (hardValid ? 0 : 35);
    return {
      ...candidate,
      score,
      axes: { usefulness, repetitionConsistency: consistency, entityIndependence: independence, semanticCoherence },
      hardValid,
      shapes
    };
  }

  function nodeToken(node) {
    const tag = node?.tagName?.toLowerCase?.() || "node";
    const testId = node?.getAttribute?.("data-testid");
    const role = node?.getAttribute?.("role");
    return [tag, testId && `testid:${testId}`, role && `role:${role}`].filter(Boolean).join("|");
  }

  function normalizeClassName(name) {
    return String(name || "").trim().toLowerCase();
  }

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLowerCase().slice(0, 96);
  }

  function sourceLeafSignature(node) {
    const directHref = node?.getAttribute?.("href");
    const heading = Array.from(node?.children || []).find((child) => /^H[1-6]$/i.test(child.tagName || ""));
    const anchor = heading?.querySelector?.("a[href]");
    const href = anchor?.getAttribute?.("href") || directHref || "";
    const text = normalizeText(heading?.textContent || "");
    return [href ? `href:${href}` : "", text ? `text:${text}` : ""].filter(Boolean).join("|");
  }

  function stableClassSignature(node) {
    const classes = Array.from(node?.classList || [])
      .map(normalizeClassName)
      .filter(Boolean)
      .filter((name) => !/^css-|^js-|^_/.test(name))
      .sort();
    return classes.slice(0, 4).join(".");
  }

  function nodePath(node, limit = 8) {
    const parts = [];
    let current = node;
    let depth = 0;
    while (current && current.nodeType === 1 && current.tagName && depth < limit) {
      const tag = current.tagName.toLowerCase();
      const id = current.getAttribute?.("id");
      const role = current.getAttribute?.("role");
      const testId = current.getAttribute?.("data-testid");
      const classes = stableClassSignature(current);
      const fragment = [tag, id && `#${id}`, role && `role:${role}`, testId && `testid:${testId}`, classes && `class:${classes}`]
        .filter(Boolean)
        .join("|");
      parts.unshift(fragment);
      current = current.parentElement;
      depth += 1;
    }
    return parts.join(" > ");
  }

  function sourceSignature(source) {
    const nodeSignature = `${source.tagName?.toLowerCase?.() || "node"}|${nodeToken(source)}|${nodePath(source)}|${sourceLeafSignature(source)}`;
    return `s:${nodeSignature}`;
  }

  function evidenceSignature(kind, evidence) {
    if (kind === "siblings") {
      return `siblings|${evidence?.parentTag || ""}|${evidence?.repeatedToken || ""}`;
    }
    if (kind === "sequence") {
      return `sequence|${evidence?.parentTag || ""}|${evidence?.startsWith || ""}`;
    }
    return `singleton|${evidence?.landmark || ""}`;
  }

  function candidateSignature(candidate) {
    const flattened = candidate.sources.flatMap(roots).map(sourceSignature).sort();
    return `${candidate.kind}|${flattened.length}|${evidenceSignature(candidate.kind, candidate.evidence)}|${flattened.join("|")}`;
  }

  function hash32(input) {
    let hash = HASH_SEED >>> 0;
    for (let index = 0; index < input.length; index += 1) {
      hash ^= input.charCodeAt(index);
      hash = Math.imul(hash, HASH_PRIME) >>> 0;
    }
    return `00000000${hash.toString(16)}`.slice(-8);
  }

  function candidates(document) {
    const result = [];
    const seen = new Set();
    let nextOrder = 0;
    function add(kind, sources, evidence) {
      if (!sources.length || result.length >= MAX_CANDIDATES) return;
      const rootNodes = sources.flatMap(roots);
      const key = `${candidateSignature({ kind, sources: rootNodes, evidence })}`;
      const id = `group:${hash32(key)}`;
      if (seen.has(id)) return;
      seen.add(id);
      result.push({ id, kind, sources, evidence, order: nextOrder++ });
    }

    const elements = Array.from(document.querySelectorAll("*")).slice(0, MAX_ELEMENTS);
    for (const parent of elements) {
      const children = Array.from(parent.children || []);
      if (children.length < 2 || children.length > 80) continue;
      const byToken = new Map();
      for (const child of children) {
        const token = nodeToken(child);
        if (!byToken.has(token)) byToken.set(token, []);
        byToken.get(token).push(child);
      }
      for (const [token, matches] of byToken) {
        if (matches.length >= 2) add("siblings", matches, { parentTag: parent.tagName.toLowerCase(), repeatedToken: token });
      }

      const headingIndexes = children.map((child, index) => /^H[1-3]$/.test(child.tagName) && child.querySelector("a[href]") ? index : -1)
        .filter((index) => index >= 0);
      if (headingIndexes.length >= 2) {
        const groups = headingIndexes.map((start, index) => children.slice(start, headingIndexes[index + 1] ?? children.length));
        add("sequence", groups, { parentTag: parent.tagName.toLowerCase(), startsWith: "linked-heading" });
      }
    }

    for (const main of Array.from(document.querySelectorAll("main")).slice(0, 8)) add("singleton", [main], { landmark: "main" });
    for (const article of Array.from(document.querySelectorAll("article")).filter((node) => node.querySelector("h1")).slice(0, 8)) {
      add("singleton", [article], { landmark: "article-with-h1" });
    }
    if (!result.length && document.body) add("singleton", [document.body], { landmark: "body-fallback" });
    return result;
  }

  function infer(document, plan = {}) {
    const bindings = sourceBindings.normalize(plan.bindings || {});
    const observations = plan.collection?.observations || [];
    const ranked = candidates(document).map((candidate) => evaluate(candidate, observations, bindings))
      .sort((left, right) => Number(right.hardValid) - Number(left.hardValid) || right.score - left.score || left.order - right.order || left.id.localeCompare(right.id));
    return Object.freeze({ winner: ranked[0] || null, candidates: Object.freeze(ranked) });
  }

  return Object.freeze({ infer, evaluate, candidates });
});
