(function initializeIrSchemaAssignment(root, factory) {
  "use strict";
  const semanticDom = root.Site2JsonSemanticDom || (typeof require === "function" ? require("./semantic-dom") : null);
  const api = factory(semanticDom);
  root.Site2JsonIrSchemaAssignment = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irSchemaAssignmentFactory(semanticDom) {
  "use strict";

  const SCHEMA = "https://schema.org/";
  const DEFAULT_PROPERTIES = Object.freeze({
    title: { term: `${SCHEMA}name`, confidence: 0.96 },
    heading: { term: `${SCHEMA}name`, confidence: 0.9 },
    url: { term: `${SCHEMA}url`, confidence: 0.99 },
    description: { term: `${SCHEMA}description`, confidence: 0.96 },
    datePosted: { term: `${SCHEMA}datePosted`, confidence: 0.98 },
    datePublished: { term: `${SCHEMA}datePublished`, confidence: 0.98 },
    employmentType: { term: `${SCHEMA}employmentType`, confidence: 0.98 },
    salary: { term: `${SCHEMA}baseSalary`, confidence: 0.92 },
    author: { term: `${SCHEMA}author`, confidence: 0.9 },
    price: { term: `${SCHEMA}price`, confidence: 0.92 }
  });

  function assign(tree, options = {}) {
    const properties = { ...DEFAULT_PROPERTIES, ...(options.properties || {}) };
    const findings = [];
    function visit(node) {
      const children = (node.children || []).map(visit);
      if (node.kind !== "value") return { ...node, children };
      const decision = properties[node.role];
      if (!decision?.term) {
        findings.push({ nodeId: node.id, role: node.role, status: "unresolved", candidates: [] });
        return { ...node, children };
      }
      const confidence = Math.max(0, Math.min(1, Number(decision.confidence ?? 1) * Number(node.confidence ?? 1)));
      findings.push({ nodeId: node.id, role: node.role, status: "assigned", term: decision.term, confidence });
      return {
        ...node,
        term: decision.term,
        confidence,
        assignment: { stage: "schema-property", role: node.role, confidence },
        provenance: [...(node.provenance || []), { source: "schema-assignment", family: "semantic", decision: decision.term, confidence }],
        children
      };
    }
    const assigned = semanticDom.document(visit(tree.root));
    return Object.freeze({ tree: assigned, findings: Object.freeze(findings) });
  }

  return Object.freeze({ SCHEMA, DEFAULT_PROPERTIES, assign });
});
