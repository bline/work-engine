"use strict";

(function initializeIrV2ReviewSurface(root, factory) {
  const validation = root.Site2JsonIrValidation || (typeof require === "function" ? require("./validation") : null);
  const serialization = root.Site2JsonIrSerialization || (typeof require === "function" ? require("./serialization") : null);
  const api = factory(validation, serialization);
  root.Site2JsonIrV2ReviewSurface = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irV2ReviewSurfaceFactory(validation, serialization) {
  "use strict";

  const SCHEMA_THING = "https://schema.org/Thing";
  const SURFACE_KIND = "v2-review-surface-evidence";

  function isObject(value) {
    return typeof value === "object" && value !== null;
  }

  function isRecord(value) {
    return isObject(value) && Object.getPrototypeOf(value) === Object.prototype;
  }

  function trimString(value) {
    return typeof value === "string" ? value.trim() : "";
  }

  function clone(value, seen = new WeakMap()) {
    if (!isObject(value)) return value;
    if (seen.has(value)) return seen.get(value);

    if (value instanceof Map || value instanceof Set) {
      const next = value instanceof Map ? new Map() : new Set();
      seen.set(value, next);
      if (value instanceof Map) {
        for (const [key, item] of value.entries()) next.set(clone(key, seen), clone(item, seen));
      } else {
        for (const item of value.values()) next.add(clone(item, seen));
      }
      return next;
    }

    if (Array.isArray(value)) {
      const next = new Array(value.length);
      seen.set(value, next);
      for (let index = 0; index < value.length; index += 1) next[index] = clone(value[index], seen);
      return next;
    }

    const output = {};
    seen.set(value, output);
    for (const key of Object.keys(value)) output[key] = clone(value[key], seen);
    return output;
  }

  function freezeDeep(value, seen = new WeakSet()) {
    if (!isObject(value) || seen.has(value)) return value;
    seen.add(value);

    if (value instanceof Map) {
      for (const [key, item] of value.entries()) {
        freezeDeep(key, seen);
        freezeDeep(item, seen);
      }
      return Object.freeze(value);
    }

    if (value instanceof Set) {
      for (const item of value.values()) freezeDeep(item, seen);
      return Object.freeze(value);
    }

    if (Array.isArray(value)) {
      for (const item of value) freezeDeep(item, seen);
      return Object.freeze(value);
    }

    for (const key of Object.keys(value)) freezeDeep(value[key], seen);
    return Object.freeze(value);
  }

  function normalizeOutput(raw) {
    if (!isRecord(raw)) return null;
    if (raw.data || raw.compact) {
      return {
        data: isObject(raw.data) ? clone(raw.data) : null,
        compact: isObject(raw.compact) ? clone(raw.compact) : null
      };
    }
    if (raw["@context"] || raw["@graph"]) {
      return { data: clone(raw), compact: null };
    }
    return clone(raw);
  }

  function toEntries(value) {
    return Array.isArray(value) ? value : [];
  }

  function normalizeFindingDecision(value) {
    const nodeId = trimString(value?.nodeId || value?.id);
    if (!nodeId) return null;
    const status = trimString(value.status || value.state).toLowerCase();
    if (status === "unresolved" || status === "rejected") return { nodeId, status: "unresolved" };
    const term = trimString(value.term || value.selectedTerm);
    if (!term) return null;
    return { nodeId, status: "assigned", term };
  }

  function normalizeReportDecision(value) {
    const entityId = trimString(value?.entityId || value?.id);
    if (!entityId) return null;
    const status = trimString(value.status || value.state).toLowerCase();
    const selected = trimString(value.selected || value.selectedType);
    const explicitAccepted = typeof value.accepted === "boolean" ? !!value.accepted : null;
    const rejected = status === "unresolved" || status === "rejected" || explicitAccepted === false;
    if (!rejected && selected && selected !== SCHEMA_THING) {
      const accepted = status === "accepted" ? true : explicitAccepted !== null ? explicitAccepted : true;
      return { entityId, status: "accepted", accepted, selected };
    }
    return { entityId, status: "unresolved", accepted: false, selected: SCHEMA_THING };
  }

  function normalizeEvidenceInput(input = {}) {
    const evidenceTree = input.tree || input.semantics?.tree;
    if (!evidenceTree || !evidenceTree.root) throw new Error("V2 report payload is missing a semantic-DOM tree.");
    return {
      kind: SURFACE_KIND,
      tree: clone(evidenceTree),
      findings: toEntries(input.findings || input.semantics?.findings).map((finding) => clone(finding)),
      reports: toEntries(input.reports || input.semantics?.reports).map((report) => clone(report)),
      output: normalizeOutput(input.output || input.result || {}),
      validation: isRecord(input.validation) ? clone(input.validation) : null,
      grouping: isRecord(input.grouping) ? clone(input.grouping) : null,
      source: isRecord(input.source) ? clone(input.source) : isObject(input.sourceRefs) ? clone(input.sourceRefs) : null
    };
  }

  function normalizeOverlay(raw = {}) {
    const findings = {};
    const reports = {};

    const addFinding = (decision) => {
      const normalized = normalizeFindingDecision(decision);
      if (normalized) findings[normalized.nodeId] = normalized;
    };

    const addReport = (decision) => {
      const normalized = normalizeReportDecision(decision);
      if (normalized) reports[normalized.entityId] = normalized;
    };

    for (const decision of toEntries(raw.findings)) addFinding(decision);
    for (const decision of toEntries(raw.fieldDecisions)) addFinding(decision);
    for (const decision of toEntries(raw.findingDecisions)) addFinding(decision);
    for (const [nodeId, decision] of Object.entries(isRecord(raw.findingDecisions) ? raw.findingDecisions : {})) addFinding({ nodeId, ...decision });
    for (const [nodeId, decision] of Object.entries(isRecord(raw.fieldDecisions) ? raw.fieldDecisions : {})) addFinding({ nodeId, ...decision });
    for (const [nodeId, decision] of Object.entries(isRecord(raw.findings) && !Array.isArray(raw.findings) ? raw.findings : {})) addFinding({ nodeId, ...decision });

    for (const decision of toEntries(raw.reports)) addReport(decision);
    for (const decision of toEntries(raw.typeDecisions)) addReport(decision);
    for (const [entityId, decision] of Object.entries(isRecord(raw.typeDecisions) ? raw.typeDecisions : {})) addReport({ entityId, ...decision });
    for (const [entityId, decision] of Object.entries(isRecord(raw.reports) && !Array.isArray(raw.reports) ? raw.reports : {})) addReport({ entityId, ...decision });

    return freezeDeep({ findings, reports });
  }

  function effectiveFinding(finding, decision = null) {
    if (!decision) return finding;
    if (decision.status === "unresolved") {
      const result = clone(finding);
      result.status = "unresolved";
      delete result.term;
      return result;
    }
    if (!trimString(decision.term)) return finding;
    return { ...finding, status: "assigned", term: trimString(decision.term) };
  }

  function applyReportOverride(report, decision = null) {
    if (!decision) return report;
    const accepted = decision.status === "accepted" && Boolean(decision.accepted);
    const selected = accepted ? (trimString(decision.selected) || SCHEMA_THING) : SCHEMA_THING;
    return { ...clone(report), selected, accepted, status: accepted ? "accepted" : "unresolved" };
  }

  function treeWithDecisions(tree, findingDecisions, reportDecisions) {
    function apply(node) {
      const children = toEntries(node.children).map(apply);
      const assignment = node.kind === "value"
        ? findingDecisions[node.id]
        : node.kind === "entity"
          ? reportDecisions[node.id]
          : null;
      const next = { ...node, children };

      if (node.kind === "value" && assignment) {
        if (assignment.status === "unresolved") {
          const unresolved = { ...next, assignment: { ...(next.assignment || {}), stage: "review-overlay", decision: "unresolved" } };
          delete unresolved.term;
          return unresolved;
        }
        if (trimString(assignment.term)) {
          return {
            ...next,
            term: trimString(assignment.term),
            assignment: { ...(next.assignment || {}), stage: "review-overlay", decision: "assigned", selectedTerm: trimString(assignment.term) }
          };
        }
      }

      if (node.kind === "entity" && assignment) {
        const entityType = assignment.accepted ? (trimString(assignment.selected) || SCHEMA_THING) : SCHEMA_THING;
        return {
          ...next,
          term: entityType,
          assignment: { ...(next.assignment || {}), stage: "review-overlay", decision: assignment.accepted ? "type" : "unresolved", entityType }
        };
      }

      return next;
    }

    return { ...tree, root: apply(tree.root) };
  }

  function buildEvidence(input) {
    return freezeDeep(normalizeEvidenceInput(input));
  }

  function derive(evidenceInput, overlay = {}) {
    const evidence = evidenceInput?.kind === SURFACE_KIND ? evidenceInput : buildEvidence(evidenceInput);
    if (!evidence?.tree || !evidence.tree.root) throw new Error("A V2 review surface requires a semantic-DOM tree and findings.");

    const normalizedOverlay = normalizeOverlay(overlay);
    const findingDecisions = {};
    const reportDecisions = {};

    for (const [nodeId, decision] of Object.entries(normalizedOverlay.findings)) {
      const target = evidence.findings.find((finding) => finding.nodeId === nodeId);
      if (target) findingDecisions[nodeId] = decision;
    }

    for (const [entityId, decision] of Object.entries(normalizedOverlay.reports)) {
      const target = evidence.reports.find((report) => report.entityId === entityId);
      if (target) reportDecisions[entityId] = applyReportOverride(target, decision);
    }

    const effectiveFindings = evidence.findings.map((finding) => effectiveFinding(finding, findingDecisions[finding.nodeId] || null));
    const effectiveReports = evidence.reports.map((report) => reportDecisions[report.entityId] || clone(report));
    const effectiveTree = treeWithDecisions(evidence.tree, findingDecisions, reportDecisions);
    const serializationInput = { propertyAssignments: effectiveFindings, typeAssignments: effectiveReports };
    const effectiveOutput = serialization.serialize(effectiveTree, evidence.grouping ? { ...serializationInput, grouping: evidence.grouping } : serializationInput);
    const effectiveValidation = validation.validate(effectiveTree, { stage: "assigned", allowUnresolved: true });

    return freezeDeep({
      tree: effectiveTree,
      findings: effectiveFindings,
      reports: effectiveReports,
      output: {
        data: clone(effectiveOutput.data),
        compact: clone(effectiveOutput.compact)
      },
      validation: clone(effectiveValidation),
      grouping: evidence.grouping ? clone(evidence.grouping) : null
    });
  }

  return Object.freeze({
    SCHEMA_THING,
    SURFACE_KIND,
    buildEvidence,
    normalizeOverlay,
    derive,
    normalizeFindingDecision,
    normalizeReportDecision,
    treeWithDecisions
  });
});
