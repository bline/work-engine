(function initializeIrValidation(root, factory) {
  "use strict";
  const semanticDom = root.Site2JsonSemanticDom || (typeof require === "function" ? require("./semantic-dom") : null);
  const api = factory(semanticDom);
  root.Site2JsonIrValidation = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irValidationFactory(semanticDom) {
  "use strict";

  function validate(tree, options = {}) {
    const stage = options.stage || "assigned";
    const allowUnresolved = options.allowUnresolved === true;
    const errors = [];
    const ids = new Set();
    try {
      semanticDom.walk(tree, (node, parent) => {
        if (ids.has(node.id)) errors.push(`Duplicate artificial node id: ${node.id}.`);
        ids.add(node.id);
        if (node.kind === "collection" && parent) errors.push(`Collection ${node.id} must be the root node.`);
        if (stage === "assigned" && !allowUnresolved && node.kind === "entity" && !node.term) errors.push(`Entity ${node.id} requires a semantic type.`);
        if (stage === "assigned" && !allowUnresolved && node.kind === "value" && !node.term) errors.push(`Value ${node.id} requires a semantic property.`);
        if (stage === "observed" && node.kind === "value" && !node.role) errors.push(`Observed value ${node.id} requires a neutral role.`);
        if (node.kind === "value" && !node.source && !Object.prototype.hasOwnProperty.call(node, "value")) errors.push(`Value ${node.id} requires a source or materialized value.`);
      });
    } catch (error) {
      errors.push(error.message);
    }
    return Object.freeze({ ok: errors.length === 0, errors });
  }

  return Object.freeze({ validate });
});
