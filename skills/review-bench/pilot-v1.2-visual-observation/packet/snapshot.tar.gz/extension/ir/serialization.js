(function initializeIrSerialization(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonIrSerialization = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irSerializationFactory() {
  "use strict";

  function localName(term) {
    const value = String(term || "");
    return value.split(/[\/#:]/).filter(Boolean).pop() || value;
  }

  function entityValue(entity) {
    const result = { "@type": localName(entity.term) };
    for (const child of entity.children || []) {
      if (child.kind === "value" && child.term && Object.prototype.hasOwnProperty.call(child, "value")) result[localName(child.term)] = child.value;
      if (child.kind === "entity") result[localName(child.assignment?.relationship || "item")] = entityValue(child);
    }
    return result;
  }

  function compactEntity(entity) {
    const result = { type: localName(entity.term) };
    for (const child of entity.children || []) {
      if (child.kind === "value" && child.term && Object.prototype.hasOwnProperty.call(child, "value")) result[localName(child.term)] = child.value;
      if (child.kind === "entity") result[localName(child.assignment?.relationship || "item")] = compactEntity(child);
    }
    return result;
  }

  function serialize(tree, reports = {}) {
    return Object.freeze({
      format: "site2json-semantic-extraction",
      version: 1,
      data: { "@context": "https://schema.org", "@graph": tree.root.children.filter((node) => node.kind === "entity").map(entityValue) },
      compact: { entities: tree.root.children.filter((node) => node.kind === "entity").map(compactEntity) },
      provenance: {
        rootId: tree.root.id,
        entities: tree.root.children.filter((node) => node.kind === "entity").map((entity) => ({
          id: entity.id,
          type: entity.term,
          confidence: entity.confidence ?? 0,
          assignment: entity.assignment || null,
          candidates: entity.typeCandidates || []
        })),
        propertyAssignments: reports.propertyAssignments || [],
        typeAssignments: reports.typeAssignments || [],
        grouping: reports.grouping || null
      }
    });
  }

  return Object.freeze({ compactEntity, localName, serialize });
});
