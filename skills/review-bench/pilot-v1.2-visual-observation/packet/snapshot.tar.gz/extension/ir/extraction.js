(function initializeIrExtraction(root, factory) {
  "use strict";
  const sourceBindings = root.Site2JsonSourceBindings || (typeof require === "function" ? require("./source-bindings") : null);
  const api = factory(sourceBindings);
  root.Site2JsonIrExtraction = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irExtractionFactory(sourceBindings) {
  "use strict";

  function localName(term) {
    const value = String(term || "");
    return value.split(/[\/#:]/).filter(Boolean).pop() || value;
  }

  function extract(normalized) {
    const collection = normalized.tree.root;
    return collection.children.map((entity) => {
      const result = { "@type": localName(entity.term) };
      for (const valueNode of entity.children.filter((child) => child.kind === "value")) {
        const binding = normalized.bindings[valueNode.source];
        const sources = normalized.sourceRefs.get(valueNode.id) || [];
        const values = sources.map((source) => sourceBindings.read(binding, source)).filter((value) => value !== null && value !== "");
        const value = binding?.multiple ? values : values[0];
        if (value !== undefined && (!Array.isArray(value) || value.length)) result[localName(valueNode.term)] = value;
      }
      return result;
    });
  }

  return Object.freeze({ extract });
});
