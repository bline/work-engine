(function initializeIrObservation(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonIrObservation = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irObservationFactory() {
  "use strict";

  const STYLE_PROPERTIES = Object.freeze(["display", "position", "backgroundColor", "borderColor", "borderRadius", "boxShadow", "fontSize", "fontWeight", "lineHeight", "textAlign"]);

  function observe(node) {
    const rect = node?.getBoundingClientRect?.() || { x: 0, y: 0, width: 0, height: 0 };
    const computed = node?.ownerDocument?.defaultView?.getComputedStyle?.(node) || {};
    return Object.freeze({
      tag: node?.tagName?.toLowerCase?.() || "",
      rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
      style: Object.fromEntries(STYLE_PROPERTIES.map((property) => [property, computed[property] || ""])),
      visible: !node?.hidden && node?.getAttribute?.("aria-hidden") !== "true" && rect.width >= 0 && rect.height >= 0
    });
  }

  return Object.freeze({ STYLE_PROPERTIES, observe });
});
