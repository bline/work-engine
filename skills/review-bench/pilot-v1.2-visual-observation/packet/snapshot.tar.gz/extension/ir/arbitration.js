(function initializeIrArbitration(root, factory) {
  "use strict";
  const api = factory();
  root.Site2JsonIrArbitration = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function irArbitrationFactory() {
  "use strict";

  function rank(candidates = []) {
    return candidates.map((candidate) => ({ ...candidate, score: Number(candidate.score || 0) }))
      .sort((left, right) => right.score - left.score || String(left.id).localeCompare(String(right.id)));
  }

  return Object.freeze({ rank });
});
