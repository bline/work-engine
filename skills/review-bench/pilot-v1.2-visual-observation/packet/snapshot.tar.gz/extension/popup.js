"use strict";

const SESSION_STORAGE_KEY = "site2jsonSession";
const EXPORT_FORMAT_STORAGE_KEY = "site2jsonExportFormat";
const COMPACT_RAW_TEXT_STORAGE_KEY = "site2jsonCompactIncludeRawText";
const PENDING_COMMAND_KEY = "pendingShortcutCommand";
const PRODUCTION_REQUEST_KEY = "site2jsonProductionRunRequest";
const PRODUCTION_RESULT_KEY = "site2jsonProductionRunResult";
const MAX_SESSION_BYTES = 4_500_000;
const EXPORT_FORMATS = new Set(["compact", "jsonld"]);
const automaticConversion = globalThis.Site2JsonAutomaticConversion;
const automaticSettingsApi = globalThis.Site2JsonAutomaticSettings;
const statusCard = document.querySelector("#status-card");
const statusIndicator = document.querySelector("#status-indicator");
const statusTitle = document.querySelector("#status-title");
const statusDetail = document.querySelector("#status-detail");
const thresholdDetail = document.querySelector("#automatic-threshold");
const runButton = document.querySelector("#run-button");
const resultActions = document.querySelector("#result-actions");
const copyButton = document.querySelector("#copy-button");
const downloadButton = document.querySelector("#download-button");
const sessionButton = document.querySelector("#session-button");
const discardButton = document.querySelector("#discard-button");
const sessionCount = document.querySelector("#session-count");
const sessionDetail = document.querySelector("#session-detail");
const manageAdaptersButton = document.querySelector("#manage-adapters-button");
const openPickerButton = document.querySelector("#open-picker-button");
const formatInputs = [...document.querySelectorAll('input[name="export-format"]')];
const includeRawTextInput = document.querySelector("#include-raw-text");

let currentDocument = null;
let activeSession = null;
let activeTab = null;
let entries = [];
let drafts = [];
let runResolution = null;
let automaticSettings = automaticSettingsApi.normalize();
let exportFormat = "compact";
let includeRawText = false;
let running = false;

function setStatus(kind, title, detail) {
  statusCard.className = `status-card ${kind}`;
  statusIndicator.className = `status-indicator ${kind}`;
  statusTitle.textContent = title;
  statusDetail.textContent = detail;
}

function displayedExport() {
  if (activeSession) {
    return exportFormat === "jsonld"
      ? Site2JsonExporters.jsonLdSession(activeSession, Site2JsonSession)
      : Site2JsonExporters.compactSession(activeSession, Site2JsonSession, { includeRawText });
  }
  if (!currentDocument) return null;
  return exportFormat === "jsonld" ? Site2JsonExporters.jsonLd(currentDocument) : Site2JsonExporters.compact(currentDocument, { includeRawText });
}

function renderPreflight() {
  thresholdDetail.textContent = `Automatic confidence threshold: ${automaticSettingsApi.label(automaticSettings.minimumConfidence)}`;
  const outcomes = automaticConversion.OUTCOMES;
  if (runResolution?.outcome === outcomes.USE_EXISTING) {
    setStatus("ready", "Adapter ready", `${runResolution.id} is enabled for this page. Run will use it without inference.`);
  } else if (runResolution?.outcome === outcomes.AUTHOR) {
    setStatus("partial", "No adapter for this page", `Run will infer the structure, semantics, and fields automatically. It stops in the editor rather than guessing below ${automaticSettingsApi.label(automaticSettings.minimumConfidence).toLowerCase()} confidence.`);
  } else if (runResolution?.outcome === outcomes.DISABLED_EXISTING) {
    setStatus("partial", "Matching adapter is disabled", `Run will open ${runResolution.id} in the editor so you can review or enable it; no competing adapter will be created.`);
  } else if (runResolution?.outcome === outcomes.PRESERVE_MANUAL_DRAFT || runResolution?.outcome === outcomes.RESUME_AUTOMATIC_DRAFT) {
    setStatus("partial", "Adapter draft needs attention", "Run will open the existing work in the editor and preserve its decisions.");
  } else {
    setStatus("error", "This page is unavailable", "Site2JSON could not inspect the active browser tab.");
  }
}

function renderControls() {
  const exportData = displayedExport();
  resultActions.hidden = !exportData;
  copyButton.disabled = !exportData || running;
  downloadButton.disabled = !exportData || running;
  copyButton.textContent = activeSession ? "Copy session" : "Copy results";
  downloadButton.textContent = exportFormat === "jsonld" ? "Download JSON-LD" : "Download JSON";
  includeRawTextInput.disabled = exportFormat !== "compact";
  runButton.textContent = currentDocument ? "Run again" : "Run";
  runButton.disabled = running || !activeTab?.id || !runResolution;
  openPickerButton.disabled = running || !activeTab?.id;
  if (!activeSession) {
    sessionCount.textContent = "Inactive";
    sessionDetail.textContent = "Run each page through the same adapter-or-infer workflow, then export one deduplicated collection.";
    sessionButton.textContent = "Start session";
    sessionButton.disabled = running || !activeTab?.id || !runResolution;
    discardButton.disabled = true;
    return;
  }
  const summary = Site2JsonSession.summarize(activeSession);
  sessionCount.textContent = `${summary.uniqueEntities} entities`;
  const gaps = summary.missingPositions.length ? `; missing ${summary.missingPositions.join(", ")}` : "";
  const stale = Site2JsonSession.isStale(activeSession) ? "; over 4 hours old" : "";
  sessionDetail.textContent = `${summary.snapshots} page snapshots; positions ${summary.positions.join(", ") || "unknown"}${gaps}${stale}.`;
  sessionButton.textContent = currentDocument && activeSession.snapshots[currentDocument.extraction.snapshotKey] ? "Replace this page" : "Add this page";
  const incompatible = currentDocument && !Site2JsonSession.sameCollection(activeSession, currentDocument);
  sessionButton.disabled = running || !activeTab?.id || !runResolution || incompatible || Site2JsonSession.isFinished(activeSession);
  discardButton.disabled = running;
}

async function storeSession(session) {
  const bytes = new TextEncoder().encode(JSON.stringify(session)).length;
  if (bytes > MAX_SESSION_BYTES) throw new Error("This session is too large for local extension storage. Export it before adding pages.");
  await chrome.storage.local.set({ [SESSION_STORAGE_KEY]: session });
  activeSession = session;
  renderControls();
}

async function clearSession() {
  await chrome.storage.local.remove(SESSION_STORAGE_KEY);
  activeSession = null;
  await chrome.action.setBadgeText({ text: "" });
  renderControls();
}

async function updateBadge() {
  const count = activeSession ? Site2JsonSession.summarize(activeSession).uniqueEntities : 0;
  await chrome.action.setBadgeBackgroundColor({ color: "#176b38" });
  await chrome.action.setBadgeText({ text: count ? String(count) : "" });
}

function renderExtraction(documentValue, { automatic = false, published = false } = {}) {
  currentDocument = documentValue;
  const count = currentDocument.extraction.blocks.reduce((total, block) => total + block.count, 0);
  const quality = currentDocument.extraction.quality;
  const warningCount = currentDocument.extraction.warnings.length;
  const monitored = Math.round((quality.monitoredFieldCoverage ?? 1) * 100);
  const origin = automatic ? `Automatically inferred${published ? " and published" : " from an unreviewed draft"}` : `${currentDocument.extraction.adapter} adapter`;
  const detail = `${origin}; ${Math.round(quality.requiredFieldCoverage * 100)}% required fields, ${monitored}% monitored fields${warningCount ? `; ${warningCount} warnings` : ""}.`;
  setStatus(quality.complete && warningCount === 0 ? "ready" : "partial", `${count} ${count === 1 ? "entity" : "entities"} extracted`, detail);
}

async function extractExisting() {
  const definition = runResolution?.definition;
  if (!definition) throw new Error("The matching adapter is no longer available.");
  await chrome.scripting.executeScript({
    target: { tabId: activeTab.id },
    files: ["core/utils.js", "core/transforms.js", "core/variant-classifier.js", "core/dsl.js", "core/model.js", "extract.js"]
  });
  const results = await chrome.scripting.executeScript({
    target: { tabId: activeTab.id },
    func: (adapterDefinitions) => globalThis.Site2JsonRuntime.extract(adapterDefinitions, document, location),
    args: [[definition]]
  });
  const result = results?.[0]?.result;
  if (!result || result.ok !== true) {
    const scopeDrift = result?.warnings?.find((warning) => warning.code === "scope.noMatches");
    if (scopeDrift) throw new Error(`The stored scope for block ${scopeDrift.block} no longer matches. Open the adapter editor to repair it.`);
    const messages = { unsupported: "The adapter no longer matches this rendered page.", empty: "The adapter matched, but no entities were found." };
    throw new Error(messages[result?.reason] || result?.message || "This page could not be extracted.");
  }
  renderExtraction(result.document);
  return result.document;
}

async function openPickerPanel() {
  if (!activeTab?.id) throw new Error("No active browser tab is available.");
  if (!chrome.sidePanel?.setOptions || !chrome.sidePanel?.open) throw new Error("This browser does not provide the extension side-panel API.");
  await chrome.sidePanel.setOptions({ tabId: activeTab.id, path: `editor/sidebar.html?tabId=${activeTab.id}`, enabled: true });
  await chrome.sidePanel.open({ tabId: activeTab.id });
  window.close();
}

async function queueAutomaticRun(intent) {
  const request = {
    version: 1,
    id: crypto.randomUUID(),
    tabId: activeTab.id,
    pageUrl: activeTab.url,
    intent,
    minimumConfidence: automaticSettings.minimumConfidence,
    requestedAt: new Date().toISOString()
  };
  await chrome.storage.session.set({ [PRODUCTION_REQUEST_KEY]: request });
  setStatus("loading", "Opening automatic inference", "The editor will stay on the exact decision if the configured confidence threshold is not met.");
  await openPickerPanel();
}

async function updateSession() {
  if (!currentDocument) return;
  const replacing = Boolean(activeSession?.snapshots[currentDocument.extraction.snapshotKey]);
  const next = activeSession ? Site2JsonSession.addDocument(activeSession, currentDocument) : Site2JsonSession.create(currentDocument);
  await storeSession(next);
  await updateBadge();
  setStatus("ready", replacing ? "Page replaced" : "Page added", `${Site2JsonSession.summarize(next).uniqueEntities} unique entities are in the session.`);
}

async function runCurrentPage({ intent = "run" } = {}) {
  if (running) return;
  running = true;
  renderControls();
  setStatus("loading", intent === "session" ? "Preparing page for session" : "Running extraction", "Using an enabled adapter when available; otherwise automatic inference will open beside the page.");
  try {
    if (runResolution?.outcome === automaticConversion.OUTCOMES.USE_EXISTING) {
      await extractExisting();
      if (intent === "session") await updateSession();
    } else {
      await queueAutomaticRun(intent);
    }
  } catch (error) {
    setStatus("error", "Run stopped", error.message);
  } finally {
    running = false;
    renderControls();
  }
}

function filename() {
  const documents = activeSession ? Site2JsonSession.documents(activeSession) : [];
  const extraction = activeSession ? documents[0]?.extraction : currentDocument?.extraction;
  const extractedAt = activeSession?.finishedAt || activeSession?.lastExtractionAt || extraction?.extractedAt || new Date().toISOString();
  const timestamp = extractedAt.replace(/[:.]/g, "-");
  const format = exportFormat === "jsonld" ? "-jsonld" : "";
  return `site2json-${extraction?.adapter || "page"}${format}-${timestamp}.json`;
}

async function copyExport() {
  const data = displayedExport();
  if (!data) return;
  const copiedSession = Boolean(activeSession);
  await navigator.clipboard.writeText(JSON.stringify(data, null, 2));
  if (activeSession) await clearSession();
  await chrome.action.setBadgeText({ text: "✓" });
  setStatus("ready", "Copied structured data", copiedSession ? "The session was copied and cleared." : "The current extraction is on your clipboard.");
}

async function downloadExport() {
  const data = displayedExport();
  if (!data) return;
  const mimeType = exportFormat === "jsonld" ? "application/ld+json" : "application/json";
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: mimeType }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename();
  link.click();
  URL.revokeObjectURL(url);
  if (activeSession) await clearSession();
  setStatus("ready", "Download started", "The structured JSON file is ready.");
}

async function consumeProductionResult() {
  const stored = await chrome.storage.session.get(PRODUCTION_RESULT_KEY);
  const result = stored?.[PRODUCTION_RESULT_KEY];
  if (!result || result.tabId !== activeTab?.id) return false;
  await chrome.storage.session.remove(PRODUCTION_RESULT_KEY);
  if (!result.document) return false;
  renderExtraction(result.document, { automatic: result.automatic === true, published: result.published === true });
  if (result.intent === "session") {
    await updateSession();
    if (result.automatic === true) {
      const summary = Site2JsonSession.summarize(activeSession);
      const provenance = result.published === true ? "The inferred adapter was published locally." : "The inferred adapter remains an unreviewed draft.";
      setStatus("ready", "Page added", `${summary.uniqueEntities} unique ${summary.uniqueEntities === 1 ? "entity is" : "entities are"} in the session. ${provenance}`);
    }
  }
  return true;
}

async function runPendingShortcut() {
  const stored = await chrome.storage.session.get(PENDING_COMMAND_KEY);
  const command = stored[PENDING_COMMAND_KEY]?.command;
  if (!command) return;
  await chrome.storage.session.remove(PENDING_COMMAND_KEY);
  const actions = {
    "start-session": () => runCurrentPage({ intent: "session" }),
    "add-page": () => runCurrentPage({ intent: "session" }),
    "copy-session": copyExport,
    "download-session": downloadExport
  };
  await actions[command]?.();
  setTimeout(() => window.close(), 250);
}

async function initialize() {
  try {
    const [stored, settings, tabs, storedEntries, storedDrafts] = await Promise.all([
      chrome.storage.local.get([SESSION_STORAGE_KEY, EXPORT_FORMAT_STORAGE_KEY, COMPACT_RAW_TEXT_STORAGE_KEY]),
      automaticSettingsApi.load(),
      chrome.tabs.query({ active: true, currentWindow: true }),
      Site2JsonAdapterRegistry.load(),
      Site2JsonAdapterDraftRegistry.load()
    ]);
    activeSession = stored[SESSION_STORAGE_KEY] || null;
    exportFormat = EXPORT_FORMATS.has(stored[EXPORT_FORMAT_STORAGE_KEY]) ? stored[EXPORT_FORMAT_STORAGE_KEY] : "compact";
    includeRawText = stored[COMPACT_RAW_TEXT_STORAGE_KEY] === true;
    automaticSettings = settings;
    activeTab = tabs[0] || null;
    entries = storedEntries;
    drafts = storedDrafts;
    runResolution = activeTab?.url ? automaticConversion.resolveExisting({ entries, drafts }, activeTab.url) : null;
    for (const input of formatInputs) input.checked = input.value === exportFormat;
    includeRawTextInput.checked = includeRawText;
    renderPreflight();
    renderControls();
    await updateBadge();
    await consumeProductionResult();
    renderControls();
    await runPendingShortcut();
  } catch (error) {
    setStatus("error", "Site2JSON could not start", error.message);
    renderControls();
  }
}

runButton.addEventListener("click", () => runCurrentPage().catch((error) => setStatus("error", "Run stopped", error.message)));
copyButton.addEventListener("click", () => copyExport().catch((error) => setStatus("error", "Copy failed", error.message)));
downloadButton.addEventListener("click", () => downloadExport().catch((error) => setStatus("error", "Download failed", error.message)));
sessionButton.addEventListener("click", () => runCurrentPage({ intent: "session" }).catch((error) => setStatus("error", "Session update failed", error.message)));
discardButton.addEventListener("click", () => clearSession().then(() => {
  if (currentDocument) setStatus("ready", "Session discarded", "The current extraction is still available.");
  else renderPreflight();
}).catch((error) => setStatus("error", "Could not discard session", error.message)));
manageAdaptersButton.addEventListener("click", () => chrome.runtime.openOptionsPage());
openPickerButton.addEventListener("click", () => openPickerPanel().catch((error) => setStatus("error", "Could not open editor", error.message)));
for (const input of formatInputs) {
  input.addEventListener("change", async () => {
    if (!input.checked || !EXPORT_FORMATS.has(input.value)) return;
    try {
      await chrome.storage.local.set({ [EXPORT_FORMAT_STORAGE_KEY]: input.value });
      exportFormat = input.value;
      renderControls();
    } catch (error) {
      for (const candidate of formatInputs) candidate.checked = candidate.value === exportFormat;
      setStatus("error", "Could not save export format", error.message);
    }
  });
}
includeRawTextInput.addEventListener("change", async () => {
  const next = includeRawTextInput.checked;
  try {
    await chrome.storage.local.set({ [COMPACT_RAW_TEXT_STORAGE_KEY]: next });
    includeRawText = next;
  } catch (error) {
    includeRawTextInput.checked = includeRawText;
    setStatus("error", "Could not save Compact JSON setting", error.message);
  }
});

globalThis.Site2JsonPopupReady = initialize();
