"use strict";

const automaticSettings = globalThis.Site2JsonAutomaticSettings;
const confidence = document.querySelector("#automatic-confidence");
const status = document.querySelector("#settings-status");
const appearance = document.querySelector("#appearance-theme");
const appearanceStatus = document.querySelector("#appearance-status");

function setStatus(kind, message) {
  status.className = `status ${kind}`;
  status.textContent = message;
}

async function initialize() {
  try {
    const settings = await automaticSettings.load();
    confidence.value = settings.minimumConfidence;
    appearance.value = await globalThis.Site2JsonTheme.load();
  } catch (error) {
    confidence.disabled = true;
    setStatus("error", error.message);
  }
}

appearance.addEventListener("change", async () => {
  appearance.disabled = true;
  try {
    const preference = await globalThis.Site2JsonTheme.save(appearance.value);
    appearance.value = preference;
    appearanceStatus.className = "status success";
    appearanceStatus.textContent = preference === "system" ? "Site2JSON now follows your system theme." : `${preference[0].toUpperCase()}${preference.slice(1)} theme selected.`;
  } catch (error) {
    appearanceStatus.className = "status error";
    appearanceStatus.textContent = error.message;
  } finally {
    appearance.disabled = false;
  }
});

confidence.addEventListener("change", async () => {
  confidence.disabled = true;
  try {
    const settings = await automaticSettings.save({ minimumConfidence: confidence.value });
    confidence.value = settings.minimumConfidence;
    setStatus("success", `Automatic runs now require ${automaticSettings.label(settings.minimumConfidence).toLowerCase()} confidence.`);
  } catch (error) {
    setStatus("error", error.message);
  } finally {
    confidence.disabled = false;
  }
});

initialize();
