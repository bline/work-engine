# Semantic Compositions and Hint Maps

> Authoring model for schema-aware field discovery in the Site2JSON browser-side-panel editor.

**Status:** review draft. This document defines the intended model and UX, not the current runtime contract. Open decisions are collected near the end rather than hidden in examples.

**Implemented authoring slice:** the browser-side-panel editor stores a validated composition snapshot per block, supports one-type and composed models, and provides both a graph canvas and accessible ordinary controls for range-compatible edits. The pinned Schema.org catalog supplies inheritance-aware relationship and target-type choices. Authors may also declare adapter-prefixed relationships with explicit domains, ranges, descriptions, and evidence aliases; those declarations join the draft vocabulary and can guide field discovery. Composition topology remains editor state, while custom vocabulary declarations are exported with the adapter.

## 1. Purpose

The editor can reliably discover that a repeating card contains links, dates, money, names, labels, and lists. It cannot infer their semantic meaning from value shape alone.

A freelance-marketplace result demonstrates the problem. One card may contain:

- the date the opportunity was posted;
- the deadline for submitting a quote;
- the buyer's historical spend;
- the proposed project budget;
- the number of quotes already received;
- an action for submitting another quote.

Those values do not fit cleanly into one flat `JobPosting` record. Several are better described through related Schema.org concepts such as `Demand`, `Service`, `AggregateOffer`, `PriceSpecification`, and `QuoteAction`. Others may remain genuine site-specific extensions.

The current single-type picker gives the recommender too little context. It can see that a value is a date and overconfidently call it `datePosted`, even when the value means “quotes accepted until.” Adding site-specific phrase rules would repair one page while making the system less generic.

This proposal introduces a **semantic composition**: an authoring-time graph of relevant types, properties, and relationships. It constrains and explains mapping recommendations while leaving the final decision with the author.

## 2. Goals

The system should:

1. separate structural DOM discovery from semantic interpretation;
2. let an author begin with either one Schema.org type or a reusable composition;
3. model relationships between concepts, not merely collect type names;
4. rank plausible field mappings using vocabulary, structure, and observed values;
5. make ambiguity and uncertainty visible;
6. allow adapter-local vocabulary extensions without teaching core about individual sites;
7. compile reviewed choices into an explicit, deterministic adapter;
8. keep runtime extraction independent of authoring heuristics; and
9. remain useful when its recommendations are wrong.

It should not attempt to prove what a page means. The author remains the source of truth.

## 3. Terms

**Observation**  
A semantic-neutral record of something found in the DOM: its selector candidates, value kind, samples, coverage, multiplicity, and structural context.

**Semantic type**  
A vocabulary class such as `JobPosting`, `Demand`, or `Organization`.

**Semantic composition**  
A reusable authoring profile containing named nodes, their allowed types, and explicit relationships between those nodes. A composition may also provide discovery priorities and explanations, but never executable extraction logic.

**Node alias**  
A stable, human-readable identifier within a composition, such as `listing`, `service`, `quotes`, or `quoteAction`. It is not an emitted vocabulary term.

**Property path**  
A mapping target through the composition graph, such as `listing.datePosted`, `listing.itemOffered.name`, or `listing.potentialAction.target`.

**Mapping proposal**  
A ranked, explained suggestion connecting one observation to one property path and transform pipeline.

**Reviewed mapping**  
An author-confirmed mapping. Reviewed mappings are locked against automatic replacement.

**Extension term**  
An adapter-prefixed property declared in the adapter's inline vocabulary registry when no standard property expresses the intended meaning accurately.

## 4. Core Invariants

### 4.1 Observation precedes interpretation

DOM discovery first records what is present. It does not need a selected schema to retain a candidate value. Selecting or changing a semantic composition reinterprets the same observations without rescanning the page.

### 4.2 Value shape is evidence, not meaning

A date-shaped string supports date-compatible properties. It does not distinguish `datePosted`, `validThrough`, `startDate`, or an adapter-specific deadline. A currency range supports money-related structures but does not establish whether it is salary, project budget, employer spend, or an offer.

### 4.3 A composition is a graph

The relationship between `Demand`, `Service`, and `AggregateOffer` matters. A bag of selected types would allow nonsensical paths and would not explain where a discovered property belongs.

### 4.4 Profiles constrain; they do not prove

A selected composition narrows the search space and supplies useful prior expectations. It cannot convert weak evidence into semantic certainty.

### 4.5 Authoring intelligence never becomes runtime logic

The published adapter contains explicit selectors, transforms, entity types, property paths, and vocabulary declarations. The extraction runtime does not run the hint map, guess meanings, or depend on the profile remaining installed.

### 4.6 User decisions are durable

Manual edits and confirmations are locked. Rediscovery may report new suggestions, but it cannot silently overwrite a reviewed selector, property, type, transform, or cardinality.

### 4.7 Uncertainty fails visibly

Unresolved observations remain numbered `_unmapped_field_N` entries. Ambiguous proposals display alternatives and reasons. Publication is blocked until each unresolved field is mapped, documented as an extension, or removed.

### 4.8 No site-specific phrase rules in core

Core may use vocabulary labels, comments, aliases generated from the pinned schema, HTML semantics, value shapes, and generic structural evidence. It does not contain rules such as “text beginning with Send before means X” or selectors tied to Guru, Upwork, or another site.

## 5. Authoring Pipeline

```text
rendered DOM
    |
    v
structural observations
selectors, values, coverage, multiplicity, context
    |
    +--------------------------+
    | selected composition     |
    | nodes, types, relations  |
    +--------------------------+
    |
    v
ranked mapping proposals
property path + transform + explanation + confidence
    |
    v
author review and correction
    |
    v
explicit extraction graph
    |
    +--> declarative adapter DSL
    +--> live extraction preview
    +--> canonical JSON-LD
```

Structural discovery and semantic mapping are separate stages of one workflow. **Discover fields** may run before or after composition selection. Choosing a composition later upgrades unresolved automatic suggestions in place.

## 6. Structural Observation Model

An observation should preserve enough information to compare selectors and reconsider semantics without rediscovering the DOM.

```json
{
  "id": "observation-12",
  "blockId": "search-results",
  "source": {
    "kind": "text",
    "selectorCandidates": [
      {
        "selector": ".jobRecord__meta",
        "coverage": 1,
        "valuesPerScope": { "minimum": 1, "maximum": 1 },
        "quality": ["semantic-class", "short", "scope-relative"]
      },
      {
        "selector": ".copy.small",
        "coverage": 1,
        "valuesPerScope": { "minimum": 2, "maximum": 3 },
        "quality": ["short", "ambiguous-within-scope"]
      }
    ],
    "selectedAttribute": null,
    "html": {
      "tag": "div",
      "role": null,
      "tokens": ["job", "record", "meta"]
    },
    "structuralContext": {
      "ancestorTokens": ["header", "identity"],
      "nearHeading": true,
      "labelTextSamples": []
    }
  },
  "values": {
    "samples": ["Posted on Dec 30, 2025", "Posted on Dec 09, 2025"],
    "inferredShapes": ["text", "absolute-date-containing-text"],
    "coverage": 1,
    "observedCardinality": "one"
  },
  "state": "unresolved"
}
```

The exact serialized shape may change, but the model must retain these facts:

- more than one selector candidate;
- selector quality findings rather than only a numeric score;
- values from every scope when the block has at most 100 matches;
- observed per-scope cardinality;
- source kind and selected attribute;
- stable DOM tokens and generic structural context;
- compatible value shapes and packaged transform candidates;
- whether a person has reviewed the observation.

Raw page text is sensitive and may be large. Observation samples are bounded, draft-local, and covered by the same local-storage and export rules as the rest of the editor draft.

## 7. Semantic Composition Model

### 7.1 Single types are valid compositions

Selecting `Article`, `Product`, or `JobPosting` creates a composition with one root node. The familiar simple case remains simple.

```yaml
id: schema:JobPosting
label: JobPosting
kind: schema-type
root: listing
nodes:
  listing:
    types: [JobPosting]
    expectation: core
edges: []
```

### 7.2 Reusable compositions

A packaged composition describes a common semantic pattern. It is an authoring convenience, not a new emitted class.

The following is deliberately a modeling hypothesis for review, not a frozen representation of every freelance marketplace:

```yaml
id: site2json:freelance-opportunity
label: Freelance marketplace opportunity
kind: composition
description: A request for freelance services that may collect quotes or proposals.
keywords: [freelance, project, contract, bid, quote, proposal, marketplace]
root: listing
nodes:
  listing:
    types: [JobPosting, Demand]
    description: The buyer's request for work.
    expectation: core
  service:
    types: [Service]
    description: The work or capability being requested.
    expectation: common
    evidenceKeywords: [service, skill, category, capability]
  buyer:
    types: [Organization]
    description: The organization offering the opportunity in this example profile.
    expectation: common
    evidenceKeywords: [buyer, employer, client, company, organization, profile]
  buyerRating:
    types: [AggregateRating]
    description: Aggregate feedback about the buyer when the marketplace exposes it.
    expectation: optional
  quotes:
    types: [AggregateOffer]
    description: Aggregate facts about responses when individual offers are unavailable.
    expectation: optional
  quoteAction:
    types: [QuoteAction]
    description: The action through which a response can be submitted.
    expectation: optional
edges:
  - from: listing
    property: itemOffered
    to: service
    expectation: common
  - from: listing
    property: hiringOrganization
    to: buyer
    expectation: common
  - from: buyer
    property: aggregateRating
    to: buyerRating
    expectation: optional
  - from: service
    property: offers
    to: quotes
    expectation: optional
  - from: listing
    property: potentialAction
    to: quoteAction
    expectation: optional
priorities:
  listing: [title, description, datePosted, validThrough, skills, priceSpecification]
  service: [name, description, category, areaServed]
  buyer: [name, address, location]
  buyerRating: [ratingValue, bestRating, worstRating, ratingCount]
  quotes: [offerCount, lowPrice, highPrice, priceCurrency]
  quoteAction: [target]
```

Every edge must be checked against the pinned Schema.org catalog and shown honestly when it is only a site2json modeling convention. Schema.org domain and range declarations guide authoring; they are not treated as closed-world validation rules. In this example, the multi-typed root and the interpretation of response summaries remain experimental even though the individual vocabulary relationships are range-compatible.

### 7.3 Composition graph versus realized graph

A composition describes concepts that may be relevant; it is not a claim that every node appears in every card. Nodes and edges carry an authoring prior:

- **core** — defines the subject of the composition;
- **common** — expected often enough to rank prominently when evidence exists; or
- **optional** — part of the useful search space, but never presumed present.

These are profile-level expectations, not field confidence. A `common` node with no supporting observation emits nothing. An `optional` node with strong machine-readable evidence can yield a strong mapping proposal. Except for the root entity represented by the accepted scope, nodes materialize in the compiled graph only when one or more reviewed fields or identities target them.

This distinction lets `AggregateOffer` and `QuoteAction` remain useful possibilities without asserting that every marketplace exposes an offer aggregate or that every apply button is semantically a quote action.

### 7.4 Multi-typing

JSON-LD permits a node to have more than one `@type`. A composition may therefore allow:

```yaml
nodes:
  listing:
    types: [JobPosting, Demand]
```

Multi-typing must be intentional and visible. It must not be used merely to unlock every property from several catalogs. Whether a freelance listing should be a multi-typed node or two related nodes is an open modeling decision described in §19.

### 7.5 Composition data is inert

A composition may contain:

- identifiers, labels, descriptions, and search keywords;
- Schema.org node types;
- explicit property edges;
- ranked or grouped property priorities;
- generic authoring explanations; and
- optional compatibility metadata derived from the pinned vocabulary.

It may not contain:

- JavaScript or expressions;
- arbitrary regular expressions;
- CSS or XPath selectors;
- site hostnames or site-specific phrases;
- transform implementations; or
- remote executable behavior.

This keeps profiles on the configuration side of Chrome Web Store policy and ensures they cannot disguise logic as remotely supplied data.

### 7.6 Independent reuse

Semantic compositions and site adapters form two independent reusable layers:

```text
semantic composition                  site adapter
what concepts may exist here          how this DOM exposes them
            \                         /
             +---- explicit mapping -+
```

One freelance-opportunity composition can guide unrelated Upwork, Guru, Freelancer, or PeoplePerHour adapters without containing any of their selectors. Conversely, one site adapter may define several reusable entity models—for opportunities, organizations, and unrelated content—and bind them from different search, detail, primary, or related blocks. Schema.org property paths are the bridge; the compiled adapter is the durable result.

## 8. Composition Selection UX

Composition selection happens after a repeating scope is accepted and before semantic recommendations are treated as strong. Discovery can still inventory fields first.

### 8.1 Responsive workspace architecture

Site2JSON is one responsive editor application hosted in Chrome's browser side panel. The editor owns its draft, workflow, autosave, semantic graph, tables, and live preview. A small browser bridge executes tab-scoped operations such as selection, inspection, highlighting, and page analysis in the rendered page.

```text
                         browser side panel
                  draft · workflow · graph · preview
                                  |
                          tab/frame browser bridge
                                  |
                           rendered page DOM
                    select · inspect · highlight · extract
```

The editor is opened from the extension popup or an automatic run that needs review. Its visual picker overlays the rendered page, so authoring does not depend on DevTools or Chrome's Elements tree. The editor remains usable when DevTools is closed and can expand to the full available side-panel width.

The editor shell renders the entire workflow, not a table-specific application:

```text
+--------------------------------------------------------------------------+
| Site2JSON | Scope: Results v | 1 Structure  2 Semantics  3 Discover ... |
+--------------------------------------------------------------------------+
|                                                                          |
|                     active workspace interface                           |
|            scope inventory · graph · table · field editor                |
|                                                                          |
+--------------------------------------------------------------------------+
| Connected to rendered page · 18 matches                                  |
+--------------------------------------------------------------------------+
```

The same future component—fixture comparison, source editor, validation report, or vocabulary inspector—automatically receives a responsive home. Dense interfaces use local scrolling and alternate layouts rather than a second editor host.

### 8.2 Guided authoring workflow

The editor presents a shared, clickable workflow rather than a rigid modal wizard:

```text
1 Structure -> 2 Semantics -> 3 Discover -> 4 Review -> 5 Finish
```

Progress is derived from the adapter draft, not stored as separate wizard state:

- **Structure** is complete when the current page's entity-producing blocks have accepted scopes and valid binding metadata.
- **Semantics** is complete when every referenced entity definition has a valid semantic graph.
- **Discover** is complete when each block has a structural observation inventory reconciled against its entity graph.
- **Review** is complete when unresolved mappings and blocking selector or coverage findings are addressed.
- **Finish** becomes available when the complete adapter validates.

Every step remains clickable. Creation naturally moves left to right; repairing an imported adapter may begin directly at Review. Returning to Structure or Semantics invalidates only the derived statuses affected by that edit.

Surface use by step:

| Step | Compact Elements role | Expanded workspace |
| --- | --- | --- |
| Structure | Select DOM nodes and accept scope proposals | Inventory all blocks, roles, arity, fidelity, and entity bindings |
| Semantics | Show entity summary and selected DOM context | Compose node/type/relationship graph |
| Discover | Start or monitor discovery | Show per-block progress and resulting columns |
| Review | Repair selectors and mappings against Elements | Extraction table, issues, field editor, and graph links |
| Finish | Save/publish/export controls | Full validation report and artifact summary |

The stepper, active block, active entity, selected field, and unresolved counts remain synchronized between hosts. Expanding or resuming never changes workflow position.

### 8.3 Starting a model

The first control asks one question:

```text
What does one matched result represent?
[ Search compositions and Schema.org types...                 ]

Compositions
  Freelance marketplace opportunity
  Product offer listing
  Event schedule

Schema.org types
  JobPosting
  Demand
  Service
```

Each result states whether it is a **Composition** or **Schema.org type**, gives a one-line definition, and previews its node count or immediate type hierarchy. Search matches labels, descriptions, aliases, and keywords.

Choosing one Schema.org type creates a one-node composition. Choosing a packaged composition loads its reviewed nodes, relationships, expectations, and property priorities. The selection itself is sufficient confirmation because the entire editor is a reversible draft.

There is no arbitrary default semantic model. The editor may rank likely starting choices from generic page evidence, but it must not silently choose the meaning of a block.

The first implemented ranking slice is intentionally conservative. **Analyze items** reuses structural discovery, compares observations with packaged composition nodes and Schema.org property ranges, and displays relative evidence rather than a probability. Additional nodes add value only when observations support them; unsupported optional nodes are neutral rather than incurring an artificial graph-size penalty. It stores only selector/path explanations and aggregate shape counts—not sampled page text. The weights are isolated in the authoring-only semantic-ranking module so they can be tuned against diverse sites without changing the DSL interpreter or published adapters.

### 8.4 Graph workspace

The Semantics step is graph-oriented in the expanded workspace, with an outline available as a synchronized exact representation:

```text
+--------------------------------------------------------------------------+
| Block: Results  | Freelance marketplace opportunity | Undo Redo | Done   |
+-----------------+------------------------------------------+-------------+
| ADD             | GRAPH                                    | INSPECTOR   |
| Search types... |                                          | listing     |
|                 |  [JobPosting + Demand]                    | ROOT · CORE |
| Compositions    |       | itemOffered                       |             |
| Schema types    |       v                                   | Types       |
| Recent          |    [Service] ---- offers ---> [Aggregate] | [JobPosting]|
|                 |       |                                   | [Demand]    |
|                 |       + hiringOrganization --> [Buyer]    |             |
|                 |                                          | Properties  |
+-----------------+------------------------------------------+-------------+
| 6 nodes · 5 edges · 4 reviewed · 3 unresolved                           |
+--------------------------------------------------------------------------+
```

- **Add palette** searches compositions, Schema.org types, and recently used concepts.
- **Graph** provides the spatial overview and direct relationship editing.
- **Inspector** edits the selected node or edge without modal dialogs.
- **Outline** provides a keyboard-accessible tree and exact property-path review.

An initial implementation may ship the relationship outline before interactive canvas editing, but it lives in the expanded workspace and uses the same normalized graph model.

The outline looks like:

```text
MODEL  Freelance marketplace opportunity        Modified

listing                                      ROOT · CORE
[JobPosting x] [Demand x]                    6 mapped fields
│
├─ itemOffered                               COMMON       edit
│  service
│  [Service x]                               2 mapped fields
│  └─ offers                                 OPTIONAL     edit
│     quotes
│     [AggregateOffer x]                     1 mapped field
│
├─ hiringOrganization                        COMMON       edit
│  buyer
│  [Organization x]                          3 mapped fields
│  └─ aggregateRating                        OPTIONAL     edit
│     buyerRating
│     [AggregateRating x]                    1 mapped field
│
└─ potentialAction                           OPTIONAL     edit
   quoteAction
   [QuoteAction x]                           1 mapped field

[+ Add related node]  [+ Add type to a node]
```

The graph and outline are semantic projections, not representations of DOM nesting. Shared nodes may appear as references in more than one outline branch.

#### Graph interaction

The graph canvas supports progressively richer direct manipulation:

- search or drag a Schema.org type from a palette to create a node;
- drag from a node's relationship port to another node;
- autocomplete range-compatible properties while an edge is being drawn;
- highlight compatible destinations and explain rejected connections;
- add or remove type pills directly on a node;
- show mapped-field counts, warnings, and `core`/`common`/`optional` state on the graph;
- click a node or mapped property to synchronize the extraction table, Elements selection, and rendered-page highlight; and
- apply automatic layout after graph edits while still permitting temporary manual positioning.

The normalized composition graph remains the source of truth. The outline and canvas are synchronized projections of it, so adopting or replacing a graph library cannot change adapter semantics. Node coordinates, collapsed state, zoom, and layout direction are optional editor metadata and never enter the runtime adapter.

The outline remains available alongside the canvas. It is the keyboard-accessible representation, the compact fallback, and the clearest way to review exact property paths. A graph-rendering library should therefore be selected for interaction and layout quality rather than treated as the data model itself.

Node interaction:

- clicking a node filters or focuses fields mapped to that node;
- hovering highlights all DOM observations contributing values to that node;
- a node shows its alias, type pills, expectation, and mapped-field counts;
- expanding a node shows prioritized properties and currently mapped fields;
- clicking a type pill opens its Schema.org definition and permits removal; and
- the root node cannot be deleted without replacing the model.

Edge interaction:

- clicking an edge opens its source node, property, destination node, and expectation;
- hovering an edge highlights fields contributing to its destination subtree, because the semantic edge itself may have no literal DOM node;
- range or domain warnings appear on the edge, not buried in a field; and
- removing an edge that disconnects its destination leaves that node as **Needs relationship** until reattached or removed.

Disconnected nodes are valid temporary draft state but block publication.

### 8.5 Adding a related type

The author can start from a node's **+ Related node** action or the global **+ Add related node** action. Starting from a node fixes the source and usually produces better suggestions.

Autocomplete results are complete relationship proposals, not bare type names:

```text
Add from: listing · JobPosting + Demand
Search: Organization

Recommended
  hiringOrganization -> Organization
  Organization offering the job position. Range also permits Person.

Other compatible relationships
  seller -> Organization
  itemOffered.provider -> Organization

Other actions
  Add Organization as another type on listing
  Create an adapter extension relationship...
```

Selecting a proposal creates the node and edge in one undoable operation. Because the menu shows the entire path, the relationship is explicit even when the author accepts the recommended default.

Adding another `@type` to an existing node is always a separately labeled action. The editor does not infer multi-typing merely because two types have overlapping properties.

If the author begins with the global action, each result includes its complete origin and path:

```text
listing.hiringOrganization -> Organization
service.provider -> Organization
quoteAction.agent -> Person
```

This avoids adding a type pill whose relationship is only explained afterward.

### 8.6 Relationship defaults

There are three sources of reasonable defaults, in order:

1. **Packaged composition.** Selecting a reviewed composition loads its declared edges directly.
2. **Current graph plus Schema.org.** Adding a type enumerates properties whose domain accepts the source type and whose range accepts the destination type. Reverse-direction properties are considered and labeled separately.
3. **Adapter extension.** When no standard relationship is accurate, the author can declare a documented adapter-prefixed relationship with value type and cardinality.

Compatible standard relationships are ranked using:

- the node from which the author invoked the action;
- direct domain/range compatibility before inherited or broadly applicable relationships;
- composition edge and property priorities;
- core vocabulary before pending or superseded terms;
- consistency with existing reviewed mappings; and
- whether the proposal preserves a connected graph.

Direct relationships from the node where the action began rank first. Compatible paths from other existing graph nodes may appear afterward with their complete origin, so an author can deliberately attach a new concept elsewhere without losing context.

A default is shown as **Recommended** only when one candidate clearly leads. The editor still displays the full relationship that will be created. If several candidates remain credible, they are shown as alternatives without pretense that the first is semantically correct.

Neither DOM text nor datatype alone chooses a relationship. A card containing a person's name does not establish whether that person is the employer, author, seller, provider, or action agent.

### 8.7 Editing and removing graph parts

Every graph change is immediate, undoable draft state:

- changing an edge re-evaluates only untouched mappings beneath it;
- removing a node preserves its fields as unresolved observations;
- removing one type from a multi-typed node identifies mappings that depended on that type;
- changing the root composition reconciles observations by source identity;
- reviewed mappings that no longer fit receive a conflict instead of being rewritten; and
- an **Undo** banner summarizes the effect, such as “5 mappings preserved, 2 became unresolved.”

The editor does not use confirmation dialogs for ordinary graph edits. It reserves confirmation for destructive actions that cannot be recovered from draft history.

### 8.8 Relationship to fields and the table

The extraction table, Elements bridge, and graph workspace are synchronized projections of the same draft:

- a table field row displays a compact semantic path such as `buyer › aggregateRating › ratingValue`;
- choosing **Edit in graph** switches the expanded workspace to Semantics and focuses the corresponding node and edge chain;
- selecting a node in the graph workspace filters the extraction table to its mapped fields without removing other data;
- editing a field groups property autocomplete by compatible graph node;
- an unresolved field can be assigned by choosing a property on an existing node; and
- a property whose target node is absent offers **Add node and map** as one action.

For example, mapping a feedback percentage to `AggregateRating.ratingValue` can offer:

```text
Add buyer.aggregateRating -> AggregateRating
and map this field to ratingValue
```

That operation adds the optional node and edge, maps the field, refreshes the table, and remains one undoable transaction.

### 8.9 Packaged and custom compositions

Editing a packaged composition creates an entity-draft-local resolved copy and marks it **Modified**; it never mutates the packaged definition. The toolbar offers:

```text
[Reset to packaged] [Save as reusable composition...] [Export composition...]
```

Saving as reusable asks for a label, description, and search keywords. Custom compositions live in local authoring storage and may later use the same source and digest machinery as adapters. The entity draft retains a resolved snapshot so an update to a packaged or custom composition cannot silently change an adapter draft.

### 8.10 Responsive mode and accessibility

The side panel renders the complete responsive application at every supported width. Dense components may use linear summaries, drawers, local scrolling, or alternate layouts, but draft inspection, recovery, validation, and navigation remain available in the same editor.

The editor must support:

- keyboard navigation through nodes, edges, and autocomplete results;
- visible focus independent of page-highlight color;
- text labels for `core`, `common`, `optional`, warnings, and mapping state;
- no meaning conveyed by connector shape or color alone; and
- predictable focus restoration when returning from a field editor.

### 8.11 Block context and entity ownership

DOM observations belong to a block because its repeating scope defines where each item begins and ends. The semantic composition belongs to the reusable entity definition referenced by that block, matching `DESIGN.md`'s entity/binding separation:

```text
Entity: Opportunity
└── semantic composition graph
    ├── bound by Search results block   <- active scope evidence
    ├── bound by Related results block  <- different scope evidence
    └── bound by Detail page block      <- higher-fidelity evidence
```

The active block is therefore an **evidence lens** over an entity model:

- switching between blocks bound to the same entity preserves the graph and changes selector samples, coverage, fidelity, and highlighting;
- switching to a block bound to another entity loads that entity's graph;
- graph edits affect every block binding that references the entity and show an “Used by N blocks” indicator;
- only evidence from the active scope drives live recommendations unless stored fixtures for another binding are explicitly loaded; and
- warnings distinguish “invalid for this entity model” from “not observed in this block.”

The model toolbar uses a compact switcher rather than duplicating the full Elements tab strip:

```text
Scope: [Results · 18 matches v]   Entity: Opportunity · used by 3 blocks
```

The author can copy an existing entity model into a new entity definition, save an entity's model as a reusable composition, or replace one entity's model without changing unrelated entities. Creating that copy is explicit; merely switching blocks never forks the composition.

## 9. Property-Path Catalog

The editor expands the selected composition into a finite catalog of mapping targets.

For each node it includes:

- properties applicable to any of the node's types, including inherited domains;
- each property's declared ranges and vocabulary status;
- property paths created by explicit composition edges;
- editor cardinality defaults, clearly identified as site2json defaults; and
- adapter-local extension terms already declared for that block or adapter.

Paths are displayed with both a concise label and their graph location:

```text
datePosted                    listing.datePosted
validThrough                  listing.validThrough
offerCount                    listing.itemOffered.offers.offerCount
target                        listing.potentialAction.target
buyer name                    listing.hiringOrganization.name
buyer feedback                listing.hiringOrganization.aggregateRating.ratingValue
guru:employerSpend            listing.hiringOrganization.guru:employerSpend
```

The node alias is an editor concept. The emitted JSON-LD uses vocabulary properties and nested objects, not aliases such as `listing` or `quotes`.

## 10. Recommendation Model

### 10.1 Compatibility gates

Before ranking, the recommender removes structurally impossible candidates where it can do so safely. These are hard filters:

- a URL attribute is incompatible with a date-only property;
- a dotted path cannot descend through a property whose range is only a literal type;
- a node property must belong to a type represented at that node or be an explicitly declared extension;
- nested mappings must follow an edge present in the composition graph; and
- a transform's output shape must be compatible with the property's expected value shape.

Schema.org permits flexible RDF graphs, so domain and range mismatches should normally produce an error in the editor's proposed model, not a claim that arbitrary external JSON-LD is globally invalid.

Observed cardinality is not a hard filter. Schema.org does not declare ordinary property cardinality, pages sometimes repeat scalar-looking labels, and a selector may simply be too broad. Cardinality mismatches therefore remain ranking evidence and visible warnings, applied once in §10.2.

### 10.2 Evidence

Remaining candidates are ranked using generic evidence:

1. machine-readable page metadata associated with the same rendered entity;
2. explicit HTML semantics, attributes, ARIA labels, headings, and label/value relationships;
3. stable tokens from IDs, classes, and nearby structure;
4. normalized vocabulary property names, descriptions, and aliases;
5. the selected composition's node expectations and per-node property priorities, used only as weak priors;
6. value-shape and transform compatibility;
7. observed cardinality and coverage across peer scopes;
8. consistency with already reviewed mappings in the same block; and
9. selector quality and specificity within the scope.

Composition `keywords` help authors find the right composition in the picker; they do not map page fields. A node's bounded `evidenceKeywords` are generic semantic aliases used only to decide whether observations support that node (for example, `employer` as evidence for a buyer `Organization`). They never contain site selectors or site-specific phrases. Per-node `priorities` are the composition input used for property ranking. None can override incompatible types or stronger contradictory DOM evidence.

Schema.org type ranking is incremental across the class hierarchy. Inherited properties establish the parent fit; a subtype ranks above its parent only when observations support properties or type evidence added by that subtype. Equal-fit descendants collapse behind the more general representative rather than filling the shortlist with arbitrary specializations.

The recommender must compare the complete set of observations within a card. Two date observations compete for two date-compatible properties; they are not mapped independently as though each were the only date present.

### 10.3 Confidence states

The UI uses explainable states instead of an unexplained decimal score:

- **Reviewed** — confirmed or explicitly edited by the author.
- **Strong suggestion** — multiple independent signals agree and no close alternative remains.
- **Plausible** — compatible and useful, but another meaning remains credible.
- **Unresolved** — insufficient evidence or conflicting alternatives.

Every non-reviewed proposal can answer “Why?” with positive and negative evidence. For example:

> Plausible `validThrough`: the value contains an absolute date and appears near an action. `datePosted` is also compatible; no explicit machine-readable property or stable semantic label distinguishes them.

This is preferable to a confident but brittle phrase match.

### 10.4 Acceptance of error

The recommender will sometimes be wrong. The design optimizes for cheap correction:

- discovered values are added immediately when requested;
- guessed mappings are visually distinct from reviewed mappings;
- alternatives are one interaction away;
- editing a mapping locks it;
- composition changes can revise untouched guesses; and
- incorrect fields are easy to delete.

## 11. Selector Choice Follows Semantic Choice

An observation may have several valid selectors. The selector that is best for one meaning may be wrong for another.

For example, a broad class may collect every small label in a card, while a narrower structurally anchored selector isolates the posted date. The editor should not discard the narrow candidate merely because the broad class has high card coverage.

Once a semantic target and cardinality are proposed, selector ranking favors:

- one correct value per scope for scalar fields;
- the complete recurring collection for many-valued fields;
- selectors whose samples remain shape-compatible;
- stable semantic hooks over positional paths; and
- selectors that do not overlap another field unexpectedly.

Selector and semantic confidence are reported separately. A field can have a strong meaning with a fragile selector, or a stable selector with unresolved meaning.

## 12. Editor Reconciliation Rules

Discovery and composition changes operate on source identity: block, relative selector, selected attribute, and value kind.

1. Rediscovery reuses the same observation instead of creating a duplicate field.
2. An untouched suggestion may receive a better property path, transform, or selector.
3. A reviewed mapping is never changed automatically.
4. Removing a composition node marks affected suggestions unresolved; it does not delete reviewed fields.
5. Adding a composition node re-evaluates unresolved and untouched suggestions.
6. If two observations converge on one scalar property, the conflict is shown rather than silently replacing either field.
7. If a property path changes because an edge changes, reviewed mappings become explicit migration decisions.
8. Each discovery or composition edit is one undoable transaction.

## 13. Field Editor UX

The dedicated field editor should show:

- the current source and all selector alternatives;
- example values and coverage;
- selected semantic path and owning node;
- compatible property alternatives grouped by node;
- declared ranges, description, status, and editor cardinality;
- transform pipeline and output preview;
- confidence state and explanation;
- extension-term creation when no standard property fits; and
- a **Reviewed** control that locks the mapping.

The extraction table remains the main review surface. Its sticky field row should add compact indicators for:

- semantic path;
- value shape;
- selector health;
- mapping state; and
- missing coverage.

Clicking an unresolved or plausible row opens the field editor with alternatives already filtered by the selected composition.

## 14. Adapter-Local Extensions

The selected composition does not eliminate custom vocabulary. It makes the decision to use it more informed.

The editor offers an extension when:

1. the observation is useful and recurring;
2. no standard property path accurately expresses its meaning;
3. the author supplies or confirms a description;
4. its value type and cardinality are explicit; and
5. the adapter namespace is available.

The resulting declaration remains inline in the one-file adapter:

```yaml
vocabulary:
  prefix: guru
  namespace: https://site2json.dev/ns/guru#
  terms:
    guru:employerSpend:
      description: Total historical marketplace spend reported for the buyer.
      valueType: MonetaryAmount
      cardinality: one
      example:
        currency: USD
        value: 3501
```

Composition files do not define site namespaces or site-specific terms. A custom local composition may reference an extension already declared by the current adapter, but it cannot make that term globally standard.

Repeated cross-site concepts may later justify a shared site2json marketplace vocabulary. Promotion requires reviewed examples from multiple adapters and is not automatic.

## 15. Runtime and DSL Boundary

The semantic composition belongs to the authoring layer. The runtime needs only the compiled result.

The current DSL primarily models one `schemaType` plus nested records. Supporting composition-derived graphs may require a normalized intermediate representation with:

- one or more typed nodes;
- stable editor node aliases;
- explicit property edges;
- field mappings targeted to a node and property;
- nested-node cardinality;
- optional node identifiers; and
- one or more `@type` values per emitted node.

The exact YAML syntax should not be frozen by this document. First define and validate the normalized graph model; then choose a readable serialization that preserves existing simple adapters.

A one-node adapter should continue to look approximately as simple as it does today. Complex graph syntax should be paid only by complex pages.

Composition nodes also introduce an ownership question that the current DSL does not answer. A node alias identifies a position in the authoring graph; it does not by itself say whether the compiled node becomes a reusable top-level `entities:` definition or an anonymous nested structure private to one parent entity. Stage E must define that boundary explicitly. A likely rule is to reuse a named entity definition when a node has independent identity or is bound from multiple pages or blocks, while keeping identity-less structured values inline. That rule remains a proposal because deduplication, fidelity upgrades, and cross-block reuse all depend on getting it right.

Compilation must produce deterministic JSON-LD. It must not invent entities that the page does not expose. If a card reports only “90 quotes received,” the output may contain an `AggregateOffer` with `offerCount`; it must not fabricate 90 individual `Offer` nodes.

## 16. Worked Marketplace Example

Consider a Guru-like card containing:

- title and canonical link;
- “Posted on Dec 30, 2025”;
- “90 Quotes Received”;
- “Fixed Price | $10k-$25k”;
- a description and skills;
- buyer name, location, historical spend, and feedback rate;
- “Send before Aug 20, 2026”; and
- a **Send a Quote** action.

With a freelance-opportunity composition, the editor can make better, still reviewable proposals:

| Observation | Candidate mapping | Confidence notes |
| --- | --- | --- |
| heading link | `listing.title` plus identity URL | Strong: heading, link, one per card |
| posted label/date | `listing.datePosted` | Strong only with distinguishing structural or metadata evidence |
| response count | `listing.itemOffered.offers.offerCount` | Plausible: integer and aggregate-response context |
| project budget | `listing.priceSpecification` or a service-related price path | Plausible; exact graph placement is a modeling decision |
| skills | `listing.skills` | Strong when repeated labels form a complete collection |
| quote deadline | `listing.validThrough` or `guru:quoteDeadline` | Ambiguous unless the surrounding semantics distinguish listing validity from quote acceptance |
| quote button URL | `listing.potentialAction.target` | Strong when action/link evidence agrees |
| buyer name | `listing.hiringOrganization.name` | Strong when the buyer identity is structurally grouped |
| buyer location | `listing.hiringOrganization.address` | Plausible; a marketplace label may be less precise than a postal address |
| buyer feedback rate | `listing.hiringOrganization.aggregateRating.ratingValue` | Plausible only if the displayed percentage is genuinely an aggregate rating |
| buyer historical spend | `listing.hiringOrganization.guru:employerSpend` | Extension on the buyer node: not the listing's budget or current offer price |

This example demonstrates three boundaries:

- the profile narrows the candidates without pretending certainty;
- the standard graph is preferred when it fits; and
- adapter-specific marketplace facts remain extensions.

The same composition may help with Upwork, but it does not force identical fields. Upwork connects cost, client history, proposal tiers, and Guru quote mechanics can remain distinct extension terms while sharing standard nodes for the opportunity, requested service, aggregate responses, and actions.

## 17. Validation and Tests

### 17.1 Composition validation

A composition validator checks:

- unique node aliases;
- an existing root node;
- known Schema.org types and properties;
- edges whose endpoints exist;
- range compatibility between an edge property and destination type;
- valid `core`, `common`, or `optional` expectations and exactly one core root;
- absence of selectors, expressions, regexes, and executable fields;
- bounded labels, descriptions, keywords, and priority lists; and
- stable identifiers and version metadata for packaged profiles.

### 17.2 Recommendation tests

The suite should include:

- one-type compositions as a backward-compatible baseline;
- ambiguous cards with two or more dates;
- money values with different meanings in the same card;
- scalar-versus-many selector competition;
- literal-range properties that reject impossible dotted paths;
- changing compositions while preserving reviewed fields;
- idempotent rediscovery;
- extension fallback without site-specific core rules; and
- explanations that name the evidence and competing alternatives.

Golden tests should separate structural expected observations from semantic expected mappings. Generating both from the same heuristic would repeat the circular-ground-truth problem described in `DESIGN.md` §22.1.

### 17.3 Output tests

Compiled adapters require fixtures that verify:

- JSON-LD graph shape;
- type and property placement;
- no fabricated nodes;
- compact projection stability;
- missing-value behavior;
- identity and session merging; and
- parity between editor preview and production interpreter.

## 18. Implementation Sequence

The next editor work should proceed in narrow, reviewable stages.

### Stage 0 — Responsive editor shell

Implementation status: complete. The editor is a single browser-side-panel application. It owns draft state, workflow, autosave, semantic graph, Review tables, and live preview. Its tab-scoped browser bridge provides rendered-page selection, highlighting, analysis, and extraction without a DevTools host. The obsolete DevTools page, inspected-window transport, dual-host lease, and Elements-sidebar workflow have been removed.

- Keep tab/frame routing explicit in every page operation.
- Keep dense interfaces responsive through local scrolling and alternate layouts.
- Autosave before navigation or destructive transitions.
- Test side-panel reconnects, tab navigation, stale messages, iframe routing, and unsupported page access.

### Stage A — Formalize the normalized model

- Define JSON Schemas for observations and semantic compositions.
- Treat the current entity definition's `schemaType` as a one-node composition.
- Generate property-path catalogs from the pinned Schema.org data.
- Validate compositions without changing runtime output.

### Stage B — Preserve evidence

- Retain alternative selectors and their per-scope cardinality.
- Separate value-shape inference from semantic naming.
- Expose selector confidence independently from mapping confidence.

### Stage C — Composition picker

- Add the searchable token interface.
- Ship the single-type path and one experimental freelance composition.
- Display the graph and permit removing or adding related nodes.
- Re-evaluate only untouched suggestions when the composition changes.

Implemented first slice: single-type and freelance-composition selection, relationship outline editing, validation, and explicit evidence-based starting-model ranking. Automatic field remapping after a composition change remains Stage D work.

### Stage D — Mapping proposals

- Expand paths from the graph.
- Add compatibility gates and explainable confidence states.
- Compare observations jointly within a card.
- Keep unresolved values in the extraction table.

### Stage E — Graph compilation

- Define the minimal DSL additions needed for typed related nodes.
- Decide when a composition node references a reusable `entities:` definition and when it compiles as an inline anonymous structure.
- Compile the editor graph into explicit adapter data.
- Verify JSON-LD and compact output with Guru and Upwork fixtures.

### Stage F — Custom compositions

- Allow local composition creation and reuse.
- Export authoring profiles separately from runtime adapters when useful.
- Apply the same digest, draft, and future source rules as other local authoring data.

The current recommender should not accumulate more isolated property heuristics before Stages A and B establish these boundaries.

## 19. Open Decisions for Review

1. **Freelance root model.** Should the opportunity be one node typed as both `JobPosting` and `Demand`, a `Demand` linked to a `Service`, or a site-dependent choice exposed by the composition?
2. **Response modeling.** Is `Service.offers -> AggregateOffer` the clearest standard representation for bid/quote summaries, or should the response aggregate attach elsewhere?
3. **Budget placement.** Should a requested project budget use `Demand.priceSpecification`, an `Offer`/`PriceSpecification` structure, or an extension when no actual offer exists?
4. **Deadlines.** When is a quote deadline accurately `validThrough`, and when does its narrower meaning justify an extension?
5. **Domain/range enforcement.** Which incompatibilities block a proposal, and which should merely warn given Schema.org's open-world conventions?
6. **Multi-typing.** Should packaged profiles use multiple types on one node or prefer explicit related nodes?
7. **Node ownership and reuse.** When does a typed composition node become a reusable adapter `entities:` definition with its own identity, bindings, deduplication, and fidelity upgrades, rather than an anonymous nested value private to its parent?
8. **Profile persistence.** Does a draft store only the selected profile ID plus edits, or a fully resolved composition snapshot to prevent future catalog drift?
9. **Adapter export.** Should exported adapters retain optional authoring metadata describing the source composition, or only the compiled graph?
10. **Custom composition sharing.** Should locally created profiles be separately exportable before remote sources exist?
11. **Confidence presentation.** Are four named states sufficient, or should the UI also expose an advanced numeric/debug score?
12. **Localization.** How should generic vocabulary token matching work for non-English page labels without introducing a large phrase-rule system?
13. **Shared extensions.** What evidence threshold promotes a repeated marketplace concept from adapter-local terms into a shared site2json namespace?
14. **Alternative node types.** Should a reusable role such as buyer declare an `Organization`-or-`Person` choice distinct from intentional multi-typing, or should packaged compositions use one default type and let authors replace it?

None of these decisions changes the foundational separation: observe first, compose a semantic graph, propose transparently, let the author decide, and compile the result into explicit inert DSL.

## 20. Acceptance Criteria

This design is ready to implement when reviewers agree that:

- a single Schema.org type remains an easy entry point;
- a composition has explicit nodes and relationships;
- DOM observation is reusable across composition changes;
- the recommender cannot rely on site-specific phrases or selectors;
- suggested property paths are constrained by the selected graph;
- selector and semantic confidence remain separate;
- reviewed mappings survive discovery and composition changes;
- extension terms stay adapter-local and documented;
- compiled node ownership and reuse are explicit rather than inferred from nesting;
- runtime extraction requires no authoring profile or heuristic engine; and
- the open marketplace-modeling questions have either decisions or deliberately scoped experiments.
