# Structural Fingerprints and Fixture Drift

Status: dependency fingerprints, runtime drift findings, scrubbed fixture capture, and fixture provenance are implemented.

## Implemented Vertical Slice

The current implementation captures a bounded baseline when a newly authored block is validated in Finish. Existing baselines are preserved during ordinary validation and change only through the explicit **Refresh structural baseline** action.

The embedded baseline currently records:

- typical and minimum block-scope counts;
- profiles grouped by selected result variant;
- known dependency shapes using deterministic `s2j1` fingerprints;
- field coverage and minimum/maximum matches per item;
- selector-fallback choice as part of each shape;
- variant-evidence coverage.

Runtime extraction reports `scope.noMatches`, `scope.countDrift`, `shape.unknown`, `field.selectorMissing`, `field.coverageDrift`, `field.cardinalityDrift`, and `variant.evidenceDrift` findings through the existing extraction warning channel. Finish previews summarize those findings before showing the raw observation.

Review exposes the same findings in a dedicated **Structural health** section on both editor surfaces. Checking the page reruns the production interpreter against the rendered DOM. Each result is localized to its authored block, result variant, and field: hovering previews the dependency on the page, field findings open the matching field editor, and scope or shape findings reveal their block. An adapter without an embedded baseline is reported as unavailable rather than healthy.

Finish also provides an explicit **Capture scrubbed fixture** action. It creates a deterministic, text-free HTML artifact, downloads it locally, computes a SHA-256 digest, and records bounded provenance metadata on the matching DSL page. A repeated capture reports whether the digest is unchanged or changed before updating the explicit capture metadata. The `s2j1` shape digest remains the runtime change detector; the cryptographic fixture checksum identifies the separate review artifact.

## Purpose

An adapter can continue producing apparently valid output after a website redesign while optional selectors silently stop matching. Required and monitored fields catch some missing values when extraction runs, but they do not explain whether the page structure changed or distinguish a normal sparse result from selector drift.

Structural fingerprints give each authored block a compact baseline describing the rendered DOM that the adapter actually depends on. A later extraction can compare the live dependency surface with that baseline and report targeted drift without treating unrelated page changes as adapter failures.

## Artifact Model

The system should keep two related artifacts with different jobs:

1. **Scrubbed page fixture** — a separate captured HTML file representing one rendered page state. Its checksum identifies and protects that exact fixture.
2. **Structural baseline** — compact, bounded data embedded in the adapter DSL. It records the expected shapes, selector cardinality, and field coverage for each block and result variant.

The checksum of the complete fixture is not the redesign detector. Dynamic content, ordering, advertisements, or an unrelated footer could change that checksum. Redesign detection compares normalized block and field fingerprints derived only from adapter-relevant structure.

A fixture belongs to a rendered page state rather than to an individual selector or block. Multiple blocks can share one page fixture while retaining independent structural baselines in the DSL.

Examples of separate page states include:

- logged in and logged out;
- desktop and mobile layouts;
- populated and empty results;
- locale-specific layouts;
- feature-flagged or A/B-tested layouts.

## Fingerprint Ownership

Every page block owns a baseline for its scope. When a block supports result variants, each result type owns its own set of item shapes and field statistics.

```text
Page fixture
├── Jobs block
│   ├── JobPosting fallback shapes
│   ├── PersonResult shapes
│   └── OrganizationResult shapes
└── Navigation block
    └── SiteNavigationElement shapes
```

This prevents legitimate structural differences between result types from appearing as redesign drift.

## Normalized Structural Projection

Each matched scope item is reduced to the smallest structural projection needed by the adapter. The projection may include:

- the block scope and its match count;
- elements reached by identity and field selectors;
- elements reached by variant-evidence selectors;
- tag names;
- class names and attributes actually used by those selectors;
- limited ancestor and sibling relationships needed to preserve selector meaning;
- matches per item;
- whether a selected value is text, an attribute, or a multiple-value collection.

The projection excludes:

- rendered text and extracted values;
- unrelated descendants and page regions;
- volatile framework attributes that the adapter does not use;
- event handlers and executable page content;
- arbitrary full-DOM serialization.

The normalized projection is serialized deterministically and hashed. Equivalent dependency structures should produce the same fingerprint even when names, dates, prices, ordering, or unrelated markup change.

### Selector stability comes first

A structural fingerprint only protects dependencies that the adapter records. It cannot make a selector durable if authoring chose a generated styling token in the first place. All automatic selector creation therefore uses one shared stability classifier before selectors enter the DSL:

- Structure scope proposals;
- automatic and manually initiated field discovery;
- selectors proposed for a selected field;
- variant-discriminator evidence;
- parent and ancestor anchors used by any of those paths.

The classifier excludes known volatile forms from CSS-in-JS and scoped-style systems, including Emotion/`css-*`, styled-components identifiers and companion hashes, JSS counters, CSS Module hash suffixes, Svelte scope classes, and Angular scope tokens. Stable semantic classes such as BEM hooks, explicit test attributes, roles, labels, and meaningful IDs remain eligible. A readable CSS Module prefix may be offered as a verified partial-token selector (for example `button[class*="Button__button__"]`), but it remains explicitly fragile and ranks below genuinely stable and structurally anchored selectors. When no usable prefix exists, authoring uses a structural/positional fallback and labels it as fragile rather than persisting a token that merely looks precise.

The projection may retain a class or attribute only after the selector authoring rules accepted it as a dependency. Imported or manually typed selectors are not silently rewritten; a later implementation should surface generated-token use as an explicit selector-fragility finding and offer a reviewed repair.

## Optional Elements and Shape Profiles

A recurring item type cannot be represented reliably by one structural checksum. Many sites omit the HTML element entirely when an optional value is absent. Conditional badges, actions, media, and promoted-result treatments can create additional legitimate shapes.

The baseline therefore stores a bounded set of observed shape profiles per result type:

```text
PersonResult
  Shape A: name + image + location       72%
  Shape B: name + location               21%
  Shape C: name only                      7%
```

It also records field-level behavior independently:

```text
name      coverage 100%   matches per item 1
image     coverage  72%   matches per item 0–1
location  coverage  93%   matches per item 0–1
```

Known shapes are not warnings merely because optional elements are absent. Drift is determined by new shapes, lost shapes, and meaningful changes in field coverage or selector cardinality.

The set must be bounded. Rare shapes beyond the stored limit can be summarized as an aggregate rather than allowing fixture data to grow without limit.

## Comparison and Findings

At extraction time, the live page produces the same normalized projection and statistics. The comparison should return structured findings rather than a single pass/fail bit.

Examples:

- `scope.noMatches` — a block scope that previously matched now matches nothing;
- `scope.countDrift` — a normally populated block has an unexpectedly small or large match count;
- `shape.unknown` — one or more items have a structural shape not present in the baseline;
- `shape.populationShift` — known shapes remain, but their distribution changes materially;
- `field.selectorMissing` — a selector has no matches in any item;
- `field.coverageDrift` — coverage changes materially from its baseline;
- `field.cardinalityDrift` — a selector that normally matched once now matches zero or many times;
- `variant.evidenceDrift` — a discriminator disappeared or began matching competing result types;

Fixture digest comparison currently happens only during explicit fixture recapture because the HTML artifact is deliberately not required at extraction time.

Suggested severity rules:

- **Error:** required identity or required field disappears, the block scope has no matches, or extraction becomes empty.
- **Strong warning:** a previously universal field approaches zero coverage, every item has a new shape, or variant evidence becomes ambiguous.
- **Warning:** an optional or monitored field changes materially, a new minority shape appears, or cardinality changes.
- **Informational:** a small population shift remains within configured tolerance.

Absolute thresholds alone are insufficient. A change from 100% to 90% can matter more than a change from 35% to 30%. Comparisons should consider the baseline, sample size, field policy, and configured tolerance.

## Current DSL Shape

The exact names remain open, but the structural baseline should live beside the block it monitors:

```yaml
pages:
  - id: directory
    fixture:
      format: site2json-scrubbed-html-v1
      capturedAt: "2026-08-11T20:00:00Z"
      digest: "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      source: "directory-logged-out.fixture.html"
      bytes: 42817
    blocks:
      - entity: DirectoryResult
        scope: ".result"
        structuralBaseline:
          scopeMatches:
            typical: 20
            minimum: 1
          variants:
            PersonResult:
              sampleSize: 20
              shapes:
                - fingerprint: "s2j1:0123456789abcdef"
                  frequency: 0.72
                - fingerprint: "s2j1:fedcba9876543210"
                  frequency: 0.28
              fields:
                name:
                  coverage: 1
                  matchesPerItem: [1, 1]
                image:
                  coverage: 0.72
                  matchesPerItem: [0, 1]
```

All values must remain inert, bounded, deterministic data accepted by the normal DSL validator. Fingerprints must not introduce executable matching logic or require the stored HTML fixture at extraction time.

## Authoring Lifecycle

The implemented authoring lifecycle separates the two explicit operations:

1. **Validate / Refresh structural baseline** runs the adapter, builds normalized projections for every block and result variant, and embeds bounded shape and coverage data in the DSL.
2. **Capture scrubbed fixture** removes text, comments, executable elements, remote URL values, form state, event handlers, and unused or generated selector hooks; serializes the remaining topology deterministically; computes its SHA-256 checksum; downloads the HTML; and records only its format, safe filename, digest, byte size, and capture time in the DSL.

A drift warning must not silently replace the baseline. Recapturing after a legitimate redesign is an explicit review operation so that a broken selector cannot teach the system that missing data is the new healthy state.

## Runtime and Editor Presentation

Extraction should continue returning data whenever the normal adapter contract permits it, while attaching structured drift findings to extraction warnings and quality metadata.

The editor translates those findings into actionable messages:

- “`title` coverage fell from 100% to 5%.”
- “`.result-card` previously matched about 20 items and now matches 2.”
- “All Person results now have an unknown shape.”
- “The `data-result-type` discriminator no longer exists.”
- “`skills` now matches three elements per item instead of one.”

Review links each finding to its block, result type, field, and live page highlight. A richer stored-baseline detail comparison remains future work.

## Privacy and Portability

The fixture scrubber and structural projector must minimize retained page data. A structural baseline should never contain sampled user text, credentials, raw personal data, or executable site code.

Fixtures remain optional development and review artifacts. The embedded structural baseline is sufficient for runtime drift checks, and the fixture digest provides provenance when the corresponding fixture is available.

## Open Decisions

- How many shape profiles are retained per result type.
- Default tolerances for coverage, cardinality, and count drift.
- Whether baselines are scoped by viewport, authentication state, locale, or an explicit named profile.
- How a block-wide `require`/`monitor` policy should evolve for variant-specific fields.
- Whether structurally equivalent selectors should share a fingerprint after selector repair.
- How fixture recapture is reviewed and versioned when a redesign is legitimate.
