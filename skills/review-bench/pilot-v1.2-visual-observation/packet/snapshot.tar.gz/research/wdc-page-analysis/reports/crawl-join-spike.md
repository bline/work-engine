# JobPosting crawl-join feasibility spike

Date: 2026-08-14

## Decision

The exact-crawl join is provisionally viable for a first JobPosting alignment experiment. A deterministic sample of 50 source pages from 50 distinct pay-level domains produced 49 unique matching HTML captures in `CC-MAIN-2024-42`, one page with two matching captures, no missing pages, and no final retrieval failures.

The ambiguous page should be rejected rather than resolved heuristically. That leaves 49 candidate pages for the next declaration/DOM-alignment slice.

This result is a go decision for a small alignment feasibility study, not evidence that recovery will generalize to other Schema.org classes or the full WDC corpus.

## Inputs

- WDC Schema.org 2024 JobPosting class-specific `part_13.gz`
- WDC JobPosting pay-level-domain-to-part lookup
- Common Crawl collection `CC-MAIN-2024-42`, the crawl named by the WDC release

The downloaded chunk is 66,795,054 compressed bytes, contains 2,401,028 N-Quads lines, and maps to 1,068 pay-level domains in the lookup. Checksums and source URLs are recorded in [`../manifests/sources.json`](../manifests/sources.json).

## Sampling

Counting unit: source page.

Domain weighting: at most one selected page per lookup-defined pay-level domain.

Selection rule: stream the compressed chunk in its published order and retain the first provenance URL encountered for each new pay-level domain until 50 domains have been selected. The sampler scanned 217,468 N-Quads lines. All 217,468 provenance URLs encountered during that scan matched a domain assigned to `part_13.gz` by the lookup.

This rule is deterministic but not random. It avoids domination by a few large hosts while retaining possible ordering and first-page bias.

## Results

| Outcome | Pages | Percent of selected pages |
| --- | ---: | ---: |
| Unique exact-crawl HTML capture | 49 | 98% |
| Multiple exact-crawl HTML captures | 1 | 2% |
| No matching capture | 0 | 0% |
| Final retrieval failure | 0 | 0% |

All 49 retrieved byte ranges passed gzip validation, decompressed to WARC response records, declared an HTTP `text/html` content type, and contained the text `JobPosting`. The last check is only a transport-level sanity check; it does not establish declaration quality, visible DOM alignment, or benchmark eligibility.

Transient Common Crawl index errors occurred during the run. The fetcher now retries bounded `429` and `5xx` responses and reuses completed records when resumed. The final counts above exclude recovered transport errors.

For comparison, the official 1,000-quad WDC sample contained 31 source URLs across only four hosts; all 31 had a unique source-crawl capture. The host-diverse result is the more useful feasibility signal.

## Interpretation

The main infrastructure risk in the proposal—recovering immutable source-crawl HTML from WDC provenance URLs—did not fail in this slice. A conservative policy can reject ambiguous matches and retain 98% of the selected pages.

The next slice should remain offline and small:

1. Extract the HTTP entity body and publisher declarations from the 49 recovered WARC responses.
2. Preserve declared values without semantic repair.
3. Run the existing Site2JSON candidate-scope generator against the recovered HTML under a clearly recorded static observation mode.
4. Manually inspect a small stratified subset to estimate declaration usability and declared-value-to-scope alignment precision.
5. Report declaration quality and alignment quality separately, with page, entity, and pay-level-domain denominators.

Do not expand to additional chunks or types until that alignment inspection establishes whether the recovered pages can produce trustworthy silver labels.

## Limitations

- One Schema.org type and one class chunk only.
- Fifty pages are enough for a feasibility gate, not a corpus-quality estimate.
- First-seen selection is deterministic rather than statistically representative.
- The experiment measures static archived HTML; it does not measure rendered-page availability or static/rendered drift.
- A string occurrence of `JobPosting` does not prove that the declaration is parseable or tied to visible page content.
- Results are page-weighted with one selected page per PLD. They must not be reported as entity-weighted or as representative of all WDC domains.
