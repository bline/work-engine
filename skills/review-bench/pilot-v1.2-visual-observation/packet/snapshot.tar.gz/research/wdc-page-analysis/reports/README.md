# Reports

Reviewed aggregate reports may be committed here when they name:

- the experiment manifest and source versions;
- the Site2JSON Git revision;
- all filters and rejection policies;
- entity, page, host, pay-level-domain, and applicable cluster denominators;
- train, validation, test, and temporal partition policy; and
- known selection and static-versus-rendered biases.

Work-in-progress generated reports belong under `reports/generated/`, which is ignored.

