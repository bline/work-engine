# JobPosting static declaration/alignment spike

Date: 2026-08-14

## Decision

Proceed with a broader alignment-validation slice, but do not scale collection or tune production heuristics yet.

The crawl join remains strong, and human adjudication confirmed six non-equivalent high-confidence ranking failures in a deliberately selected seven-page disagreement stratum. Entity-to-root assignment, population coherence, identity evidence, and an extraction-grounded boundary rule now exist for this pilot. The next slice must test and version that policy on a broader, freshly reviewed sample before the corpus can tune heuristics or train a model.

Site2JSON always produces and maintains a collection, including when the current page contributes one item. The existing `single` and `collection` inference modes are structural search paths, not alternative output models. A detail-page run may enrich an identified item already present in the session collection. This spike evaluates page-local boundaries only; it does not label session enrichment.

## Inputs and observation mode

- 49 uniquely recovered JobPosting source pages from 49 distinct pay-level domains
- Immutable `CC-MAIN-2024-42` WARC response bodies
- Static archived HTML parsed with `jsdom`; scripts were not executed and external resources were not loaded
- The repository's real [`evidence-scope.js`](../../../extension/editor/evidence-scope.js) candidate generator
- Strict JSON parsing with no semantic repair, plus conservative Microdata and RDFa discovery

The experiment manifest records source and implementation digests in [`../manifests/experiments/jobposting-static-alignment.json`](../manifests/experiments/jobposting-static-alignment.json).

## Declaration assessment

Counting unit: source page, with one sampled page per pay-level domain.

| Strict static declaration result | Pages | Percent |
| --- | ---: | ---: |
| At least one JobPosting entity found | 42 | 85.7% |
| No strictly parseable JobPosting entity | 7 | 14.3% |

All seven pages without an entity contained invalid JSON-LD. Six had an unescaped control character inside a string; one wrapped JSON in a CDATA-style comment. These are declaration parse failures, not proof that the visible page lacks a job. The raw WDC quads may still preserve useful declared values for them, but any normalization must remain explicit and separate from the publisher declaration.

The raw WDC comparison confirms that distinction. The selected 50-page sample contributes 3,516 quads and 69 WDC-extracted JobPosting entities. Restricting to the 49 pages with unique crawl captures gives 67 WDC entities versus 60 entities from strict HTML parsing:

- entity counts agree on all 42 strictly parseable pages;
- WDC has exactly one additional JobPosting on each of the seven strict parse-failure pages; and
- strict HTML parsing is never higher than the WDC count.

The WDC graph therefore preserves a separate `declared` representation for these seven pages without claiming that their embedded JSON-LD is syntactically usable. The selected graphs have now been reconstructed into research entities with raw RDF term metadata, full predicate IRIs, and a separate mechanical object projection. No semantic repair is applied.

The 42 parseable pages contained 60 JobPosting entities:

- 39 pages declared one entity;
- two pages declared three entities; and
- one page declared 15 entities.

By page, 41 used JSON-LD and one used Microdata. Entity-weighted rates would be materially distorted by the 15-entity page, so page, entity, and domain denominators must remain separate.

## Structural inference output

The current scope generator returned a chosen boundary on 44 of 49 pages and labeled 30 choices high-confidence. Those figures describe system behavior, not correctness.

The alignment probe compared non-URL declared scalar values with visible text and extractable attributes. It excludes scripts, styles, metadata, templates, hidden subtrees, and declaration text itself. For each declared entity, values must concentrate in one matched root; matches are not pooled across roots.

Among the 42 strictly parseable pages:

| Page-weighted proxy | Chosen boundary | Best generated boundary |
| --- | ---: | ---: |
| No declared-value match | 9 (21.4%) | 4 (9.5%) |
| At least 25% matched | 27 (64.3%) | 34 (81.0%) |
| At least 50% matched | 13 (31.0%) | 18 (42.9%) |
| At least 75% matched | 1 (2.4%) | 1 (2.4%) |
| Mean best-entity match ratio | 33.6% | 40.7% |

A generated alternative improved on the winner on 12 pages. Eight improved by at least ten percentage points, five improved by at least 25 points, and five crossed the 50% threshold only with an alternative. This indicates a real ranking opportunity, but it is not yet a ranking-error count because the proxy does not establish boundary correctness.

Using the WDC-declared layer extends the same proxy to all 49 uniquely recovered pages, including the seven strict parse failures:

| Page-weighted WDC proxy | Chosen boundary | Best generated boundary |
| --- | ---: | ---: |
| No declared-value match | 9 (18.4%) | 4 (8.2%) |
| At least 25% matched | 30 (61.2%) | 40 (81.6%) |
| At least 50% matched | 15 (30.6%) | 20 (40.8%) |
| At least 75% matched | 0 | 0 |
| Mean best-entity match ratio | 32.7% | 39.8% |

On this complete page denominator, an alternative improves on the winner on 14 pages; ten improve by at least ten percentage points, six by at least 25 points, and five cross the 50% threshold only with an alternative. The lower ratios relative to strict JSON reflect the full WDC property graph, not weaker recovery, and remain diagnostic rather than correctness labels.

## Structure-aware entity assignment

A second diagnostic policy now assigns each WDC-declared entity to one distinct candidate root. A candidate passes local checks only when:

- root count equals declared entity count;
- every entity is assigned to a different root;
- matched evidence includes at least two distinct values from at least two independent semantic families;
- every assignment has a title or identity anchor;
- candidate roots are not nested or overlapping;
- the selector does not resolve to `body`; and
- a near-whole-page root containing boilerplate landmarks is rejected.

This policy still produces review candidates, not silver labels:

| Structure-aware result | Pages | Percent of 49 pages |
| --- | ---: | ---: |
| Current chosen boundary passes local checks | 6 | 12.2% |
| At least one generated boundary passes | 22 | 44.9% |
| Exactly one generated boundary passes | 9 | 18.4% |
| Current winner is that unique boundary | 2 | 4.1% |
| Unique passing alternative exists instead | 7 | 14.3% |

All seven unique alternatives are `main` detail boundaries. In every case, the current winner came from the repeated-population path, was marked high confidence, and exceeded the configured margin of ten; observed margins range from 12.3 to 105.8. Their selected roots fragment the detail page into two or three repeated regions. Compact review found all seven `main` alternatives structurally plausible. These are priority adjudication cases because, if confirmed, they are dangerous structural false acceptances rather than ordinary abstentions.

Of the two pages where the current winner is the unique passing boundary, one is a plausible job-detail `main`. The other is a broad category page whose generic publisher-declared JobPosting appears questionable. This demonstrates why structure, declaration compatibility, and publisher/type correctness must remain separate gates.

Four additional chosen boundaries pass local checks but compete with nested alternatives representing similar content. They need boundary-equivalence or human adjudication rather than arbitrary exact-selector scoring.

## Human adjudication of the unique-candidate stratum

One project-owner reviewer examined all nine uniquely eligible cases in a blinded local viewer. The viewer rendered the recovered static HTML, labeled candidates A/B without loading the inference-role key, and removed publisher scripts. Questions were ordered adaptively: visible type and page role first, then population shape, then boundary preference and equivalence only for eligible pages.

The review also established an extraction-grounded boundary rule from the current DSL implementation:

- unmatched navigation or boilerplate inside one complete item root can be acceptable because downstream field mapping may ignore it; but
- multiple selector matches are extracted independently as collection items and are never merged into one item, so fragments that collectively contain one job are not an equivalent boundary.

Two of nine pages were excluded before boundary scoring. One was a suspected-spam/thin aggregator record without enough visible job evidence; the other was a category-navigation page rather than a visible `JobPosting`. These were the two cases where the current winner already equaled the unique structure-eligible selector. They remain useful declaration/type-mismatch examples, not scope-accuracy examples.

The other seven pages were exactly the high-confidence disagreement stratum identified above:

| Human-reviewed result | Pages | Percent of 7 scored pages |
| --- | ---: | ---: |
| Structure-eligible candidate is extraction-acceptable | 7 | 100% |
| Structure-eligible candidate is preferred | 6 | 85.7% |
| Current inference winner is extraction-acceptable | 1 | 14.3% |
| Current winner is preferred | 1 | 14.3% |
| Candidates contain equivalent content in this snapshot | 1 | 14.3% |

The one current-winner preference was a tighter wrapper around the same content as the broader `main`; both were extraction-compatible on the captured page. The other six current winners were genuine boundary failures under current product behavior: related-job contamination, incomplete job fragments, duplicated summaries, or two/three matched roots for one logical job. The structure-eligible `main` candidate was acceptable in all seven.

This is strong failure-mining evidence, not a general accuracy estimate. The stratum was deliberately selected because the conservative structure policy yielded exactly one candidate, it covers only `JobPosting`, it has one reviewer, and two reviewed pages appeared to reuse the same site template. It does show that all six non-equivalent disagreements were ranking failures rather than candidate-generation failures—and that the existing high-confidence/margin gate accepted every one of them.

## Qualitative review

A local ignored review artifact now contains 26 distinct pages selected across declaration, value-alignment, structure-assignment, and hash-baseline strata. This is a failure-discovery sample, not gold evaluation data.

The nine uniquely eligible structure cases are also packaged as a separate adjudication queue. It contains nine source pages from nine lookup-defined pay-level domains and nine declared entities. Candidate roles are deterministically swapped between A and B; a separate key preserves which candidate was the current winner. The blank decision record asks for page role, preferred or equivalent boundary, and declared-type compatibility independently.

The diagnostic cases exposed:

- cookie dialogs and navigation/footer populations selected instead of job content;
- a repeated selector covering only part of a 15-job declared population;
- a single broad `main` root containing three separately declared jobs;
- one entity split into several sibling roots that would become separate collection items;
- mixed candidates containing a primary job, a related job, and an email-alert box;
- visible detail pages for which candidate generation abstained; and
- static pages where the declared title or job body was absent from the useful DOM.

The hash-selected baseline contained one plausibly correct `article` boundary. The other four included an incorrect footer population, a broad page wrapper, an abstention whose only alternative was `body`, and a page whose publisher-declared JobPosting appeared inconsistent with the visible article. This tiny qualitative sample must not be reported as an accuracy estimate, but it confirms that the diagnostic failures are not confined to deliberately selected edge cases.

The review also caught and corrected an early research-harness bug: using raw `textContent` allowed JSON-LD script text to produce false perfect matches. A regression test now requires declaration scripts to remain invisible to alignment.

## Historical presentation recovery

The exact Common Crawl HTML join did not recover the pages' dependency graphs, so the initial human review was structural rather than a validation of historical visual grouping. The seven type-compatible reviewed pages referenced ten external stylesheets. A bounded Wayback probe queried each exact URL over a broad window, selected captures immediately before and after the Common Crawl HTML timestamp, fetched the raw archived payloads, and compared local SHA-256 digests:

| Stylesheet evidence | Resources | Percent of 10 resources |
| --- | ---: | ---: |
| Matching verified payloads before and after the page capture | 3 | 30% |
| Usable payload on only one side of the page capture | 4 | 40% |
| No usable exact-URL payload | 3 | 30% |

The three stable resources cover two of the seven pages: both external stylesheets for case 03 and the main fingerprinted stylesheet for case 08. Case 03 is the strongest result, bracketed from 0.6 days before to 11.3 days after the page capture with byte-identical fetched CSS. Case 08 is also stable but has a much wider bracket, from 48.7 days before to 79.2 days after. The one-sided observations range from 2.4 days before to 163.2 days after and must not be pooled with bracket-confirmed presentation evidence.

This technique therefore helps, but it does not make the sample render-complete. CDX digests, timestamp proximity, and fingerprinted filenames are useful metadata; the final stability witness is equality of the fetched raw payloads. Missing presentation evidence must remain unavailable rather than becoming a negative visual-coherence score.

## What this says about WDC ROI

WDC is already useful as a realistic failure-mining and regression source. It found behaviors that synthetic value distributions would not reveal: cookie overlays, related-content competition, fragmented detail layouts, partial listing selectors, publisher/type mismatch, and malformed declarations.

It is not yet a trustworthy automatic training-label source. Publisher declarations remain weak labels, and visible-value overlap alone cannot distinguish an entity root from a broad container, fragmented siblings, or a heterogeneous population.

## Next slice

Keep the same 49-page sample and avoid downloading more data. Add:

1. Expand human review beyond the uniquely eligible stratum, including ambiguous/nested candidates, multi-entity pages, parse failures, and hash-selected baselines.
2. Turn the extraction-grounded boundary and equivalence decisions into a versioned silver-label policy, then measure precision on a fresh sample.
3. Add at least one additional schema type and template clustering before treating domain counts as independent diversity.
4. Replace the diagnostic greedy entity assignment with a reviewed, versioned assignment policy if multi-entity pages enter the benchmark.
5. Create minimized synthetic regressions for the six confirmed high-confidence ranking failures before tuning production weights.
6. Add a future session-level extension for item identity and detail-page enrichment; WDC can suggest identity fields, while consented product telemetry is likely the better source of actual navigation/enrichment labels.

Only after that review should the project report candidate recall, winner accuracy, or semantic type accuracy. The semantic-ranking benchmark should also wait until the harness reproduces the production singleton-observation wrapper rather than calling only the lower-level ranker.

## Limitations

- One type, one WDC chunk, and 49 domains.
- Static archived HTML only; no rendered JavaScript state.
- Strict declaration parsing deliberately rejects repairable syntax.
- The alignment figures are diagnostic proxies, not labels.
- Structure-aware assignment is a conservative heuristic and currently uses deterministic greedy matching.
- Human adjudication rendered captured static HTML in a browser, but scripts remained disabled and external resource behavior was not treated as captured application state.
- Session navigation and enrichment behavior are outside this page-local sample.
