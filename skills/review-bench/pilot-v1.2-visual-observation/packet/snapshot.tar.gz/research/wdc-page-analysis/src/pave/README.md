# PAVE spike

Inspect PAVE JSONL fields, confirm `pid` title/description anchoring, and test whether offer identifiers permit selective linkage to source records. PAVE attributes are not DOM scopes or Schema.org property labels.

