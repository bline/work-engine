"use strict";

const { canonicalUrl, rootEvidence } = require("./dom-evidence");

const FAMILY_WEIGHT = Object.freeze({ identity: 6, title: 6, organization: 4, location: 3, date: 3, compensation: 3, employment: 2, other: 1 });
const STRONG_FAMILIES = new Set(["identity", "title", "organization", "location", "date", "compensation", "employment"]);

function family(path) {
  const value = String(path || "").toLowerCase();
  if (/(?:^|\.)(?:url|sameas|identifier)(?:\.|$)/.test(value)) return "identity";
  if (/(?:^|\.)(?:title|headline)(?:\.|$)/.test(value)) return "title";
  if (/(?:hiringorganization|employer|organization)/.test(value)) return "organization";
  if (/(?:joblocation|applicantlocation|address|country|locality|region)/.test(value)) return "location";
  if (/(?:dateposted|validthrough|date|time)/.test(value)) return "date";
  if (/(?:salary|currency|price|compensation|wage)/.test(value)) return "compensation";
  if (/(?:employmenttype|workhours|joblocationtype)/.test(value)) return "employment";
  return "other";
}

function eligibleValue(item) {
  const value = String(item?.value || "").replace(/\s+/g, " ").trim();
  return value.length >= 3 && value.length <= 500 && !/^_:[^\s]+$/.test(value) && !/^\S+@\S+$/.test(value);
}

function matches(item, evidence, baseUrl) {
  const value = String(item.value).replace(/\s+/g, " ").trim();
  if (/^https?:\/\//i.test(value)) {
    const url = canonicalUrl(value, baseUrl);
    return Boolean(url && evidence.urls.has(url));
  }
  return evidence.combined.includes(value.normalize("NFKC").toLowerCase());
}

function edge(entity, evidence, rootIndex, baseUrl) {
  const values = entity.values.filter(eligibleValue);
  const matched = values.filter((item) => matches(item, evidence, baseUrl));
  const families = [...new Set(matched.map((item) => family(item.path)))];
  const strongFamilies = families.filter((name) => STRONG_FAMILIES.has(name));
  const distinctMatchedValues = new Set(matched.map((item) => String(item.value).normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase())).size;
  const score = families.reduce((total, name) => total + FAMILY_WEIGHT[name], 0) + matched.length + (values.length ? matched.length / values.length : 0);
  return {
    rootIndex,
    score: Math.round(score * 1000) / 1000,
    eligibleValues: values.length,
    matchedValues: matched.length,
    distinctMatchedValues,
    matchRatio: values.length ? Math.round((matched.length / values.length) * 1000) / 1000 : 0,
    families,
    strongFamilies,
    matchedPaths: [...new Set(matched.map((item) => item.path))].sort()
  };
}

function greedyAssignment(matrix) {
  const choices = matrix.flatMap((edges, entityIndex) => edges.map((item) => ({ ...item, entityIndex })))
    .filter((item) => item.matchedValues > 0)
    .sort((left, right) => right.score - left.score || right.strongFamilies.length - left.strongFamilies.length || right.matchedValues - left.matchedValues || left.entityIndex - right.entityIndex || left.rootIndex - right.rootIndex);
  const entities = new Set();
  const roots = new Set();
  const assignments = [];
  for (const choice of choices) {
    if (entities.has(choice.entityIndex) || roots.has(choice.rootIndex)) continue;
    entities.add(choice.entityIndex);
    roots.add(choice.rootIndex);
    assignments.push(choice);
  }
  return assignments.sort((left, right) => left.entityIndex - right.entityIndex);
}

function hasNestedRoots(roots) {
  return roots.some((root, index) => roots.some((other, otherIndex) => index !== otherIndex && root.contains(other)));
}

function assessCandidate(document, candidate, entities) {
  let roots;
  try { roots = Array.from(document.querySelectorAll(candidate.selector)); } catch { roots = []; }
  const evidence = roots.map(rootEvidence);
  const matrix = entities.map((entity) => evidence.map((item, rootIndex) => edge(entity, item, rootIndex, document.baseURI)));
  const assignments = greedyAssignment(matrix);
  const documentWords = Math.max(1, rootEvidence(document.body).words);
  const rootDiagnostics = roots.map((root, index) => ({
    index,
    tag: root.tagName.toLowerCase(),
    words: evidence[index].words,
    documentTextShare: Math.round((evidence[index].words / documentWords) * 1000) / 1000,
    boilerplateDescendants: root.querySelectorAll("nav, footer, aside").length
  }));
  const findings = [];
  if (roots.length !== entities.length) findings.push({ code: "population-count-mismatch", roots: roots.length, entities: entities.length });
  if (hasNestedRoots(roots)) findings.push({ code: "nested-or-overlapping-roots" });
  if (roots.some((root) => root === document.body)) findings.push({ code: "body-root" });
  if (rootDiagnostics.some((root) => root.documentTextShare >= 0.9 && root.boilerplateDescendants > 0)) findings.push({ code: "boilerplate-dominated-root" });
  if (assignments.length !== entities.length) findings.push({ code: "incomplete-entity-assignment", assigned: assignments.length, entities: entities.length });
  const weak = assignments.filter((item) => item.strongFamilies.length < 2);
  if (weak.length) findings.push({ code: "insufficient-independent-families", assignments: weak.map((item) => item.entityIndex) });
  const duplicated = assignments.filter((item) => item.distinctMatchedValues < 2);
  if (duplicated.length) findings.push({ code: "insufficient-distinct-values", assignments: duplicated.map((item) => item.entityIndex) });
  const unanchored = assignments.filter((item) => !item.strongFamilies.some((name) => ["title", "identity"].includes(name)));
  if (unanchored.length) findings.push({ code: "missing-title-or-identity-anchor", assignments: unanchored.map((item) => item.entityIndex) });
  return {
    selector: candidate.selector,
    eligible: entities.length > 0 && findings.length === 0,
    rootCount: roots.length,
    entityCount: entities.length,
    assignedEntities: assignments.length,
    assignments,
    rootDiagnostics,
    findings,
    score: Math.round(assignments.reduce((total, item) => total + item.score, 0) * 1000) / 1000
  };
}

module.exports = { assessCandidate, edge, eligibleValue, family, greedyAssignment };
