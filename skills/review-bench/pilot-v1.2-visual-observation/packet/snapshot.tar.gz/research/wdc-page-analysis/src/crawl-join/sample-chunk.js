"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");
const zlib = require("node:zlib");
const { PATHS } = require("../scaffold");

const DEFAULT_PART = "part_13.gz";
const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 500;

function parseArgs(argv) {
  const values = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) throw new Error(`Unexpected argument: ${token}`);
    const name = token.slice(2);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for --${name}.`);
    values[name] = value;
    index += 1;
  }
  const part = values.part || DEFAULT_PART;
  const input = path.resolve(PATHS.researchRoot, values.input || `data/raw/wdc-schemaorg-2024/jobposting/${part}`);
  const lookup = path.resolve(PATHS.researchRoot, values.lookup || "data/raw/wdc-schemaorg-2024/jobposting/JobPosting_lookup.csv");
  const output = path.resolve(PATHS.researchRoot, values.output || `data/intermediate/jobposting/${part}-host-diverse.json`);
  const limit = Number(values.limit || DEFAULT_LIMIT);
  if (!/^part_\d+\.gz$/.test(part)) throw new Error("--part must look like part_13.gz.");
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > MAX_LIMIT) throw new Error(`--limit must be an integer from 1 to ${MAX_LIMIT}.`);
  return { input, lookup, output, part, limit };
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function sourceUrl(line) {
  return line.match(/ <(https?:\/\/[^>]+)>\s+\.\s*$/)?.[1] || null;
}

function domainsForPart(csv, part) {
  const domains = new Set();
  for (const line of csv.split(/\r?\n/).slice(1)) {
    if (!line) continue;
    const [pld, , fileLookup] = line.split(",");
    if (fileLookup === part && pld) domains.add(pld.toLowerCase());
  }
  return domains;
}

function payLevelDomain(source, allowedDomains) {
  let hostname;
  try {
    hostname = new URL(source).hostname.toLowerCase().replace(/\.$/, "");
  } catch {
    return null;
  }
  const labels = hostname.split(".");
  for (let index = 0; index < labels.length; index += 1) {
    const candidate = labels.slice(index).join(".");
    if (allowedDomains.has(candidate)) return candidate;
  }
  return null;
}

function fileSha256(filename) {
  return new Promise((resolve, reject) => {
    const digest = crypto.createHash("sha256");
    fs.createReadStream(filename).on("data", (chunk) => digest.update(chunk)).on("error", reject).on("end", () => resolve(digest.digest("hex")));
  });
}

async function sample(options) {
  const allowedDomains = domainsForPart(fs.readFileSync(options.lookup, "utf8"), options.part);
  if (!allowedDomains.size) throw new Error(`No domains in the lookup map to ${options.part}.`);

  const pages = [];
  const selectedDomains = new Set();
  let linesRead = 0;
  let provenanceUrlsRead = 0;
  let unmatchedUrls = 0;
  const lines = readline.createInterface({ input: fs.createReadStream(options.input).pipe(zlib.createGunzip()), crlfDelay: Infinity });
  for await (const line of lines) {
    linesRead += 1;
    const url = sourceUrl(line);
    if (!url) continue;
    provenanceUrlsRead += 1;
    const pld = payLevelDomain(url, allowedDomains);
    if (!pld) {
      unmatchedUrls += 1;
      continue;
    }
    if (selectedDomains.has(pld)) continue;
    selectedDomains.add(pld);
    pages.push({ sourceUrl: url, sourceUrlSha256: `sha256:${sha256(url)}`, payLevelDomain: pld });
    if (pages.length === options.limit) {
      lines.close();
      break;
    }
  }

  const result = {
    format: "site2json-wdc-host-diverse-page-sample",
    version: 1,
    generatedAt: new Date().toISOString(),
    input: path.relative(PATHS.researchRoot, options.input),
    inputSha256: `sha256:${await fileSha256(options.input)}`,
    lookup: path.relative(PATHS.researchRoot, options.lookup),
    part: options.part,
    availablePayLevelDomains: allowedDomains.size,
    selection: "first provenance URL encountered for each new lookup-defined pay-level domain",
    requested: options.limit,
    selected: pages.length,
    scan: { linesRead, provenanceUrlsRead, unmatchedUrls },
    pages
  };
  fs.mkdirSync(path.dirname(options.output), { recursive: true });
  fs.writeFileSync(options.output, `${JSON.stringify(result, null, 2)}\n`);
  return result;
}

async function main() {
  const result = await sample(parseArgs(process.argv.slice(2)));
  process.stdout.write(`${JSON.stringify({ ...result, pages: undefined }, null, 2)}\n`);
}

if (require.main === module) {
  main().catch((error) => {
    process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
    process.exitCode = 1;
  });
}

module.exports = { domainsForPart, payLevelDomain, sourceUrl };
