"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { JSDOM, VirtualConsole } = require("jsdom");
const { PATHS } = require("../scaffold");
const {
  captures,
  classifyBracket,
  fetchCapturePayload,
  nearestBracket,
  sha256
} = require("./probe-wayback-css");

const DEFAULT_INPUT = "data/derived/jobposting/validated-static-pages";
const DEFAULT_PROBE = "data/derived/jobposting/wayback-css-bracket-probe.json";
const DEFAULT_OUTPUT = "data/derived/jobposting/validated-visual-pages";
const ACCEPTED = new Set(["exact-capture", "stable-bracket"]);
const HTML_ASSETS = Object.freeze([
  ["img[src]", "src", "image"],
  ["source[src]", "src", "media"],
  ["video[poster]", "poster", "image"],
  ["input[type=image][src]", "src", "image"]
]);

function parseArgs(argv) {
  const options = { input: DEFAULT_INPUT, probe: DEFAULT_PROBE, output: DEFAULT_OUTPUT, maxAssets: 250 };
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    const value = argv[index + 1];
    if (!token.startsWith("--") || !value || value.startsWith("--")) throw new Error(`Expected --name value, received ${token}.`);
    const key = token.slice(2).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
    options[key] = value;
    index += 1;
  }
  options.maxAssets = Number(options.maxAssets);
  if (!Number.isInteger(options.maxAssets) || options.maxAssets < 1) throw new Error("--max-assets must be a positive integer.");
  for (const key of ["input", "probe", "output"]) options[key] = path.resolve(PATHS.researchRoot, options[key]);
  return options;
}

function normalizeUrl(value, baseUrl) {
  const raw = String(value || "").trim().replace(/^['"]|['"]$/g, "");
  if (!raw || /^(?:data|blob|about|javascript):/i.test(raw) || raw.startsWith("#")) return null;
  try {
    const url = new URL(raw, baseUrl);
    url.hash = "";
    return /^https?:$/.test(url.protocol) ? url.href : null;
  } catch {
    return null;
  }
}

function cssReferences(css, baseUrl) {
  const found = new Map();
  const add = (raw, role) => {
    const url = normalizeUrl(raw, baseUrl);
    if (url && !found.has(url)) found.set(url, { url, role });
  };
  String(css).replace(/@import\s+(?:url\(\s*)?["']?([^"')\s;]+)["']?\s*\)?[^;]*;/gi, (_, value) => {
    add(value, "stylesheet");
    return _;
  });
  String(css).replace(/url\(\s*["']?([^"')]+)["']?\s*\)/gi, (_, value) => {
    add(value, "asset");
    return _;
  });
  return [...found.values()];
}

function extensionFor(resource) {
  const pathname = (() => { try { return new URL(resource.url).pathname; } catch { return ""; } })();
  const fromPath = path.extname(pathname).toLowerCase().replace(/[^.a-z0-9]/g, "");
  if (fromPath && fromPath.length <= 8) return fromPath;
  const contentType = String(resource.payloadContentType || "").toLowerCase();
  if (resource.role === "stylesheet" || contentType.includes("css")) return ".css";
  if (contentType.includes("woff2")) return ".woff2";
  if (contentType.includes("woff")) return ".woff";
  if (contentType.includes("png")) return ".png";
  if (contentType.includes("jpeg")) return ".jpg";
  if (contentType.includes("gif")) return ".gif";
  if (contentType.includes("svg")) return ".svg";
  if (contentType.includes("webp")) return ".webp";
  return ".bin";
}

function localFilename(resource) {
  const id = crypto.createHash("sha256").update(resource.url).digest("hex").slice(0, 20);
  return `${id}${extensionFor(resource)}`;
}

function cleanCapture(capture) {
  if (!capture) return null;
  const { body, ...metadata } = capture;
  return metadata;
}

async function recoverBracketed(url, targetTimestamp, archive = { captures, fetchCapturePayload }) {
  const indexed = await archive.captures(url);
  const bracket = nearestBracket(indexed, targetTimestamp);
  const beforePayload = bracket.before ? await archive.fetchCapturePayload(bracket.before) : null;
  const before = beforePayload ? { ...beforePayload, payloadSha256: sha256(beforePayload.body) } : null;
  const after = bracket.after?.timestamp === bracket.before?.timestamp ? before
    : bracket.after ? await archive.fetchCapturePayload(bracket.after).then((payload) => ({ ...payload, payloadSha256: sha256(payload.body) })) : null;
  const status = classifyBracket(before, after);
  const selected = ACCEPTED.has(status) ? (before || after) : null;
  return { url, status, indexedCaptures: indexed.length, before, after, selected };
}

function rewriteCss(css, baseUrl, resources, prefix = "./") {
  const replacement = (value) => {
    const url = normalizeUrl(value, baseUrl);
    const resource = url ? resources.get(url) : null;
    return resource?.status === "localized" ? `${prefix}${resource.localFile}` : null;
  };
  let output = String(css).replace(/@import\s+(?:url\(\s*)?["']?([^"')\s;]+)["']?\s*\)?[^;]*;/gi, (rule, value) => {
    if (String(value).startsWith(prefix)) return rule;
    const local = replacement(value);
    return local ? `@import url("${local}");` : `/* Site2JSON omitted unresolved import: ${rule.replace(/\*\//g, "")} */`;
  });
  output = output.replace(/url\(\s*["']?([^"')]+)["']?\s*\)/gi, (rule, value) => {
    if (String(value).startsWith(prefix)) return rule;
    const local = replacement(value);
    if (local) return `url("${local}")`;
    if (!normalizeUrl(value, baseUrl)) return rule;
    return "url(\"data:,\")";
  });
  return output;
}

function htmlAssetReferences(document, sourceUrl) {
  const found = [];
  for (const [selector, attribute, role] of HTML_ASSETS) {
    for (const node of document.querySelectorAll(selector)) {
      const url = normalizeUrl(node.getAttribute(attribute), sourceUrl);
      if (url) found.push({ url, role, node, attribute });
    }
  }
  for (const node of document.querySelectorAll("img[srcset], source[srcset]")) {
    const entries = String(node.getAttribute("srcset") || "").split(",").map((entry) => {
      const [value, ...descriptor] = entry.trim().split(/\s+/);
      return { url: normalizeUrl(value, sourceUrl), descriptor: descriptor.join(" ") };
    }).filter((entry) => entry.url);
    for (const entry of entries) found.push({ ...entry, role: "image", node, attribute: "srcset", srcset: true });
  }
  return found;
}

function disableExternalExecution(document) {
  document.querySelectorAll("script, meta[http-equiv='Content-Security-Policy' i], link[rel~='preload' i], link[rel~='modulepreload' i]").forEach((node) => node.remove());
  let policy = document.querySelector("meta[data-site2json-visual-fixture-policy]");
  if (!policy) {
    policy = document.createElement("meta");
    policy.setAttribute("data-site2json-visual-fixture-policy", "");
    document.head.prepend(policy);
  }
  policy.httpEquiv = "Content-Security-Policy";
  policy.content = "default-src 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; media-src 'self' data:";
  let base = document.querySelector("base");
  if (!base) {
    base = document.createElement("base");
    document.head.prepend(base);
  }
  base.href = "./";
}

async function importCase(caseDirectory, outputDirectory, probeItems, options, archive) {
  const metadata = JSON.parse(fs.readFileSync(path.join(caseDirectory, "metadata.json"), "utf8"));
  const html = fs.readFileSync(path.join(caseDirectory, "page.html"), "utf8");
  const dom = new JSDOM(html, { url: metadata.sourceUrl, virtualConsole: new VirtualConsole() });
  const { document } = dom.window;
  const resources = new Map();
  const queue = [];
  const roots = probeItems.filter((item) => item.reviewId === metadata.reviewId);

  function enqueue(url, role, parent = null, known = null) {
    if (!url || resources.has(url) || resources.size >= options.maxAssets) return;
    const record = { url, role, parent, status: "pending", known };
    resources.set(url, record);
    queue.push(record);
  }

  for (const item of roots) enqueue(item.resourceUrl, "stylesheet", null, item);
  const htmlAssets = htmlAssetReferences(document, metadata.sourceUrl);
  for (const item of htmlAssets) enqueue(item.url, item.role, metadata.sourceUrl);
  for (const style of document.querySelectorAll("style")) {
    for (const reference of cssReferences(style.textContent, metadata.sourceUrl)) enqueue(reference.url, reference.role, metadata.sourceUrl);
  }
  for (const node of document.querySelectorAll("[style]")) {
    for (const reference of cssReferences(node.getAttribute("style"), metadata.sourceUrl)) enqueue(reference.url, reference.role, metadata.sourceUrl);
  }

  while (queue.length) {
    const resource = queue.shift();
    try {
      let recovered;
      if (resource.known) {
        const status = resource.known.status;
        const selectedMetadata = ACCEPTED.has(status) ? (resource.known.before || resource.known.after) : null;
        const selected = selectedMetadata ? await archive.fetchCapturePayload(selectedMetadata) : null;
        if (selected && selectedMetadata.payloadSha256 && sha256(selected.body) !== selectedMetadata.payloadSha256) {
          throw new Error(`Archived payload no longer matches the probed digest for ${resource.url}.`);
        }
        recovered = { status, selected, before: resource.known.before, after: resource.known.after, indexedCaptures: resource.known.indexedCaptures };
      } else {
        recovered = await recoverBracketed(resource.url, roots[0]?.pageTimestamp, archive);
      }
      resource.archiveStatus = recovered.status;
      resource.before = cleanCapture(recovered.before);
      resource.after = cleanCapture(recovered.after);
      resource.indexedCaptures = recovered.indexedCaptures || 0;
      if (!recovered.selected) {
        resource.status = "unresolved";
        continue;
      }
      resource.body = recovered.selected.body;
      resource.payloadContentType = recovered.selected.payloadContentType;
      resource.payloadSha256 = sha256(resource.body);
      resource.localFile = localFilename(resource);
      resource.status = "localized";
      if (resource.role === "stylesheet") {
        const css = resource.body.toString("utf8");
        for (const reference of cssReferences(css, resource.url)) enqueue(reference.url, reference.role, resource.url);
      }
    } catch (error) {
      resource.status = "error";
      resource.error = error.message;
    }
  }

  fs.mkdirSync(path.join(outputDirectory, "assets"), { recursive: true });
  for (const resource of resources.values()) {
    if (resource.status !== "localized") continue;
    const body = resource.role === "stylesheet"
      ? Buffer.from(rewriteCss(resource.body.toString("utf8"), resource.url, resources))
      : resource.body;
    fs.writeFileSync(path.join(outputDirectory, "assets", resource.localFile), body);
    resource.fixtureSha256 = sha256(body);
  }

  for (const link of Array.from(document.querySelectorAll('link[rel~="stylesheet" i][href]'))) {
    const url = normalizeUrl(link.getAttribute("href"), metadata.sourceUrl);
    const resource = resources.get(url);
    if (resource?.status === "localized") link.href = `assets/${resource.localFile}`;
    else link.remove();
  }
  const srcsetNodes = new Set(htmlAssets.filter((item) => item.srcset).map((item) => item.node));
  for (const node of srcsetNodes) {
    const entries = htmlAssets.filter((item) => item.srcset && item.node === node).flatMap((item) => {
      const resource = resources.get(item.url);
      return resource?.status === "localized" ? [`assets/${resource.localFile}${item.descriptor ? ` ${item.descriptor}` : ""}`] : [];
    });
    if (entries.length) node.setAttribute("srcset", entries.join(", "));
    else node.removeAttribute("srcset");
  }
  for (const item of htmlAssets.filter((entry) => !entry.srcset)) {
    const resource = resources.get(item.url);
    if (resource?.status === "localized") item.node.setAttribute(item.attribute, `assets/${resource.localFile}`);
    else {
      item.node.removeAttribute(item.attribute);
      item.node.setAttribute("data-site2json-unresolved-source", item.url);
    }
  }
  for (const style of document.querySelectorAll("style")) style.textContent = rewriteCss(style.textContent, metadata.sourceUrl, resources, "assets/");
  for (const node of document.querySelectorAll("[style]")) node.setAttribute("style", rewriteCss(node.getAttribute("style"), metadata.sourceUrl, resources, "assets/"));
  disableExternalExecution(document);
  fs.mkdirSync(outputDirectory, { recursive: true });
  fs.writeFileSync(path.join(outputDirectory, "page.html"), dom.serialize());
  dom.window.close();

  const manifest = {
    format: "site2json-wdc-visual-fixture",
    version: 1,
    reviewId: metadata.reviewId,
    sourceUrl: metadata.sourceUrl,
    sourcePageSha256: metadata.captureBodySha256,
    observationMode: "historically-corroborated-static-render",
    javascript: "disabled",
    resourceLimit: options.maxAssets,
    resourceLimitReached: resources.size >= options.maxAssets,
    resources: [...resources.values()].map(({ body, known, ...resource }) => resource)
  };
  fs.writeFileSync(path.join(outputDirectory, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
  return manifest;
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  const probe = JSON.parse(fs.readFileSync(options.probe, "utf8"));
  const sourceManifest = JSON.parse(fs.readFileSync(path.join(options.input, "manifest.json"), "utf8"));
  const pages = options.case ? sourceManifest.pages.filter((page) => page.reviewId === options.case) : sourceManifest.pages;
  if (!pages.length) throw new Error(`No validated page matched ${options.case || "the input manifest"}.`);
  const manifests = [];
  for (const [index, page] of pages.entries()) {
    process.stderr.write(`[${index + 1}/${pages.length}] ${page.reviewId}\n`);
    const pageOutput = path.join(options.output, page.reviewId);
    const checkpoint = path.join(pageOutput, "manifest.json");
    const manifest = fs.existsSync(checkpoint) && fs.existsSync(path.join(pageOutput, "page.html"))
      ? JSON.parse(fs.readFileSync(checkpoint, "utf8"))
      : await importCase(path.join(options.input, page.reviewId), pageOutput, probe.items, options, { captures, fetchCapturePayload });
    manifests.push(manifest);
    fs.mkdirSync(options.output, { recursive: true });
    fs.writeFileSync(path.join(options.output, "manifest.json"), `${JSON.stringify({
      format: "site2json-wdc-visual-fixtures",
      version: 1,
      generatedAt: new Date().toISOString(),
      pageCount: pages.length,
      completedCount: manifests.length,
      pages: manifests.map((item) => ({
        reviewId: item.reviewId,
        localized: item.resources.filter((resource) => resource.status === "localized").length,
        unresolved: item.resources.filter((resource) => resource.status !== "localized").length,
        resourceLimitReached: item.resourceLimitReached
      }))
    }, null, 2)}\n`);
  }
  process.stdout.write(`${JSON.stringify({ output: path.relative(PATHS.researchRoot, options.output), completedCount: manifests.length }, null, 2)}\n`);
}

if (require.main === module) main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.stack : String(error)}\n`);
  process.exitCode = 1;
});

module.exports = { cssReferences, disableExternalExecution, importCase, normalizeUrl, recoverBracketed, rewriteCss };
