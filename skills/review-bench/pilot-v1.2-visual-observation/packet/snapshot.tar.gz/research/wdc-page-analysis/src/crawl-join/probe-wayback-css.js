"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { JSDOM, VirtualConsole } = require("jsdom");
const { PATHS } = require("../scaffold");
const { parseWarcResponse } = require("./warc-response");

const BASE = "data/derived/jobposting";
const QUEUE = `${BASE}/part-13-structure-adjudication.json`;
const DECISIONS = `${BASE}/part-13-structure-adjudication-decisions.json`;
const ANALYSIS = `${BASE}/part-13-static-analysis.jsonl`;
const OUTPUT = `${BASE}/wayback-css-bracket-probe.json`;
const USER_AGENT = "site2json-wdc-research/0.1 (bounded CSS provenance probe)";

function sha256(value) {
  return `sha256:${crypto.createHash("sha256").update(value).digest("hex")}`;
}

function timestampValue(timestamp) {
  const value = String(timestamp || "");
  if (!/^\d{14}$/.test(value)) return Number.NaN;
  return Date.UTC(+value.slice(0, 4), +value.slice(4, 6) - 1, +value.slice(6, 8), +value.slice(8, 10), +value.slice(10, 12), +value.slice(12, 14));
}

function nearestBracket(captures, targetTimestamp) {
  const target = timestampValue(targetTimestamp);
  const ordered = captures.filter((capture) => Number.isFinite(timestampValue(capture.timestamp)))
    .sort((left, right) => timestampValue(left.timestamp) - timestampValue(right.timestamp));
  const before = ordered.filter((capture) => timestampValue(capture.timestamp) <= target).at(-1) || null;
  const after = ordered.find((capture) => timestampValue(capture.timestamp) >= target) || null;
  return { before, after };
}

function classifyBracket(before, after) {
  if (!before && !after) return "unavailable";
  if (!before || !after) return "nearest-only";
  if (!before.payloadSha256 || !after.payloadSha256) return "bracket-unverified";
  if (before.timestamp && before.timestamp === after.timestamp) return before.payloadSha256 === after.payloadSha256 ? "exact-capture" : "bracket-unverified";
  return before.payloadSha256 === after.payloadSha256 ? "stable-bracket" : "unstable-bracket";
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

let lastRequestAt = 0;
async function politeFetch(url, options = {}) {
  const spacing = Math.max(0, 3000 - (Date.now() - lastRequestAt));
  if (spacing) await delay(spacing);
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    lastRequestAt = Date.now();
    const response = await fetch(url, { ...options, headers: { "user-agent": USER_AGENT, ...(options.headers || {}) }, signal: AbortSignal.timeout(90000) });
    if (response.ok) return response;
    if ((response.status !== 429 && response.status < 500) || attempt === 4) throw new Error(`${response.status} ${response.statusText} for ${url}`);
    await delay(15000 * attempt);
  }
  throw new Error(`Request attempts exhausted for ${url}`);
}

function cdxUrl(resourceUrl) {
  const target = new URL("https://web.archive.org/cdx/search/cdx");
  target.searchParams.set("url", resourceUrl);
  target.searchParams.set("matchType", "exact");
  target.searchParams.set("output", "json");
  target.searchParams.set("fl", "timestamp,original,mimetype,statuscode,digest,length");
  target.searchParams.append("filter", "statuscode:200");
  target.searchParams.set("from", "2020");
  target.searchParams.set("to", "2026");
  target.searchParams.set("limit", "1000");
  return target;
}

async function captures(resourceUrl) {
  const response = await politeFetch(cdxUrl(resourceUrl));
  const contentType = response.headers.get("content-type") || "";
  const text = await response.text();
  if (!contentType.includes("json")) throw new Error(`Wayback CDX returned ${contentType || "unknown content"}.`);
  const table = JSON.parse(text);
  if (!Array.isArray(table) || !table.length) return [];
  const header = table[0];
  return table.slice(1).map((row) => Object.fromEntries(header.map((name, index) => [name, row[index]])))
    .filter((capture) => capture.original === resourceUrl && capture.statuscode === "200");
}

function looksLikeCss(buffer, contentType) {
  const start = buffer.toString("utf8", 0, Math.min(buffer.length, 2000));
  return !/<(?:!doctype|html|body)(?:\s|>)/i.test(start) && (contentType.includes("css") || /[{;}]/.test(start));
}

async function fetchCapture(capture) {
  if (!capture) return null;
  try {
    const payload = await fetchCapturePayload(capture);
    const { body, ...metadata } = payload;
    return {
      ...metadata,
      payloadLooksCss: looksLikeCss(body, metadata.payloadContentType),
      payloadSha256: looksLikeCss(body, metadata.payloadContentType) ? sha256(body) : null
    };
  } catch (error) {
    const archiveUrl = `https://web.archive.org/web/${capture.timestamp}id_/${capture.original}`;
    return { ...capture, archiveUrl, payloadError: error.message, payloadSha256: null };
  }
}

async function fetchCapturePayload(capture) {
  if (!capture) return null;
  const archiveUrl = `https://web.archive.org/web/${capture.timestamp}id_/${capture.original}`;
  const response = await politeFetch(archiveUrl);
  const body = Buffer.from(await response.arrayBuffer());
  return {
    ...capture,
    archiveUrl,
    deltaSeconds: null,
    payloadBytes: body.length,
    payloadContentType: response.headers.get("content-type") || "",
    payloadSha256: sha256(body),
    body
  };
}

function inputs() {
  const load = (relative) => JSON.parse(fs.readFileSync(path.join(PATHS.researchRoot, relative), "utf8"));
  const queue = load(QUEUE);
  const decisions = load(DECISIONS);
  const analysis = fs.readFileSync(path.join(PATHS.researchRoot, ANALYSIS), "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  const analysisByHash = new Map(analysis.map((page) => [page.sourceUrlSha256, page]));
  const eligible = new Set(decisions.items.filter((item) => item.status === "reviewed" && item.declaredTypeCompatible).map((item) => item.reviewId));
  const found = [];
  for (const item of queue.items.filter((candidate) => eligible.has(candidate.reviewId))) {
    const response = parseWarcResponse(fs.readFileSync(path.join(PATHS.researchRoot, item.snapshot)));
    const dom = new JSDOM(response.text, { url: item.sourceUrl, virtualConsole: new VirtualConsole() });
    const pageTimestamp = analysisByHash.get(item.sourceUrlSha256)?.capture?.timestamp;
    for (const resourceUrl of [...dom.window.document.querySelectorAll('link[rel~="stylesheet" i][href]')].map((node) => node.href)) {
      found.push({ reviewId: item.reviewId, pageTimestamp, resourceUrl });
    }
    dom.window.close();
  }
  return found;
}

function deltaSeconds(capture, targetTimestamp) {
  if (!capture) return null;
  return Math.round(Math.abs(timestampValue(capture.timestamp) - timestampValue(targetTimestamp)) / 1000);
}

async function main() {
  const resources = inputs();
  const items = [];
  const outputPath = path.join(PATHS.researchRoot, OUTPUT);
  for (const [index, input] of resources.entries()) {
    process.stderr.write(`[${index + 1}/${resources.length}] ${input.reviewId} ${input.resourceUrl}\n`);
    try {
      const indexed = await captures(input.resourceUrl);
      const bracket = nearestBracket(indexed, input.pageTimestamp);
      const before = await fetchCapture(bracket.before);
      const after = bracket.after?.timestamp === bracket.before?.timestamp ? before : await fetchCapture(bracket.after);
      if (before) before.deltaSeconds = deltaSeconds(before, input.pageTimestamp);
      if (after) after.deltaSeconds = deltaSeconds(after, input.pageTimestamp);
      items.push({ ...input, indexedCaptures: indexed.length, status: classifyBracket(before, after), before, after });
    } catch (error) {
      items.push({ ...input, status: "query-error", error: error.message });
    }
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    fs.writeFileSync(outputPath, `${JSON.stringify({
      format: "site2json-wayback-css-bracket-probe",
      version: 1,
      generatedAt: new Date().toISOString(),
      targetCount: resources.length,
      completedCount: items.length,
      items
    }, null, 2)}\n`);
  }
  const counts = Object.fromEntries([...new Set(items.map((item) => item.status))].sort().map((status) => [status, items.filter((item) => item.status === status).length]));
  process.stdout.write(`${JSON.stringify({ output: OUTPUT, counts }, null, 2)}\n`);
}

if (require.main === module) main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.stack : String(error)}\n`);
  process.exitCode = 1;
});

module.exports = { captures, classifyBracket, fetchCapturePayload, nearestBracket, sha256, timestampValue };
