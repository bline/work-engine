"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { JSDOM, VirtualConsole } = require("jsdom");
const { PATHS } = require("../scaffold");
const { parseWarcResponse } = require("../crawl-join/warc-response");
const { scalarValues } = require("../declarations/inventory");
const { visibleHaystack } = require("../alignment/dom-evidence");

const ANALYSIS = "data/derived/jobposting/part-13-static-analysis.jsonl";
const WDC = "data/derived/jobposting/part-13-wdc-entities.jsonl";
const JOIN = "data/raw/common-crawl/CC-MAIN-2024-42/jobposting-part-13-host-diverse";
const QUEUE = "data/derived/jobposting/part-13-structure-adjudication.json";
const KEY = "data/derived/jobposting/part-13-structure-adjudication-key.json";

function normalize(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function selectCases(pages) {
  return pages.filter((page) => page.structureAlignment?.uniqueEligibleCandidate);
}

function candidateLabels(sourceUrlSha256) {
  const digit = Number.parseInt(sourceUrlSha256.slice(-1), 16);
  return digit % 2 === 0
    ? { current: "A", eligible: "B" }
    : { current: "B", eligible: "A" };
}

function rootSummary(document, candidate) {
  let roots = [];
  try { roots = Array.from(document.querySelectorAll(candidate.selector)); } catch { /* reported as no roots */ }
  return {
    selector: candidate.selector,
    matchCount: roots.length,
    tags: [...new Set(roots.map((root) => root.tagName.toLowerCase()))],
    snippets: roots.slice(0, 3).map((root) => normalize(visibleHaystack(root)).slice(0, 500)),
    diagnostics: candidate.rootDiagnostics || [],
    matchedPropertyPaths: [...new Set((candidate.assignments || []).flatMap((item) => item.matchedPaths || []))]
  };
}

function declarationSummary(wdcPage) {
  const entities = wdcPage?.entities || [];
  return {
    declaredType: "JobPosting",
    entityCount: entities.length,
    entities: entities.map((entity) => {
      const values = scalarValues(entity.normalized).filter((value) => !String(value.value).startsWith("_:"));
      return {
      propertyPaths: [...new Set(values.map((value) => value.path))].sort(),
      identityValues: values
        .filter((value) => /(?:^|\.)(?:title|name|identifier|url|@id)$/.test(value.path))
        .slice(0, 12)
        .map((value) => ({ path: value.path, value: normalize(value.value).slice(0, 300) }))
      };
    })
  };
}

function buildQueue(pages, joined, wdcPages, readRecord) {
  const byHash = new Map(joined.map((result) => [result.sourceUrlSha256, result]));
  const wdcByHash = new Map(wdcPages.map((page) => [page.sourceUrlSha256, page]));
  const keyItems = [];
  const items = selectCases(pages).map((page, ordinal) => {
    const result = byHash.get(page.sourceUrlSha256);
    if (!result?.files?.decompressed) throw new Error(`Missing recovered record for ${page.sourceUrlSha256}`);
    const response = parseWarcResponse(readRecord(result));
    const dom = new JSDOM(response.text, { url: result.sourceUrl, virtualConsole: new VirtualConsole() });
    const labels = candidateLabels(page.sourceUrlSha256);
    const candidates = {
      [labels.current]: rootSummary(dom.window.document, page.structureAlignment.chosen),
      [labels.eligible]: rootSummary(dom.window.document, page.structureAlignment.uniqueEligibleCandidate)
    };
    const pageTitle = normalize(dom.window.document.title);
    dom.window.close();
    const reviewId = `jobposting-structure-${String(ordinal + 1).padStart(2, "0")}`;
    keyItems.push({
      reviewId,
      sourceUrlSha256: page.sourceUrlSha256,
      candidateRoles: {
        [labels.current]: "current-inference-winner",
        [labels.eligible]: "unique-structure-eligible-alternative"
      },
      currentInference: {
        mode: page.scope.mode,
        confidence: page.scope.confidence,
        margin: page.scope.margin
      }
    });
    return {
      reviewId,
      sourceUrl: result.sourceUrl,
      sourceUrlSha256: page.sourceUrlSha256,
      snapshot: path.join(JOIN, "records", result.files.decompressed),
      page: {
        title: pageTitle,
        observationMode: "common-crawl-static-html"
      },
      declaration: declarationSummary(wdcByHash.get(page.sourceUrlSha256)),
      candidates,
      decision: {
        status: "unreviewed",
        pageRole: null,
        preferredCandidate: null,
        candidatesEquivalent: null,
        declaredTypeCompatible: null,
        notes: "",
        reviewer: null,
        reviewedAt: null
      }
    };
  });
  return {
    queue: {
      format: "site2json-wdc-structure-adjudication",
      version: 1,
      generatedAt: new Date().toISOString(),
      instructions: {
        pageRole: ["primary-detail", "listing", "mixed", "non-job", "ambiguous"],
        preferredCandidate: ["A", "B", "neither"],
        candidatesEquivalent: "Use true when both selectors describe the same useful entity boundary despite different DOM nodes.",
        declaredTypeCompatible: "Judge whether the visible page represents the declared JobPosting type; do not treat the declaration as truth."
      },
      denominators: {
        sourcePages: items.length,
        payLevelDomains: items.length,
        domainCounting: "Subset of a sample containing one page per WDC lookup-defined pay-level domain.",
        declaredEntities: items.reduce((sum, item) => sum + item.declaration.entityCount, 0)
      },
      items
    },
    key: {
      format: "site2json-wdc-structure-adjudication-key",
      version: 1,
      generatedAt: new Date().toISOString(),
      warning: "Keep this mapping separate while reviewing candidate boundaries.",
      items: keyItems
    }
  };
}

function main() {
  const analysisPath = path.join(PATHS.researchRoot, ANALYSIS);
  const joinPath = path.join(PATHS.researchRoot, JOIN);
  const pages = fs.readFileSync(analysisPath, "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  const joined = fs.readFileSync(path.join(joinPath, "results.jsonl"), "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  const wdcPages = fs.readFileSync(path.join(PATHS.researchRoot, WDC), "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  const built = buildQueue(pages, joined, wdcPages, (result) => fs.readFileSync(path.join(joinPath, "records", result.files.decompressed)));
  for (const [relative, value] of [[QUEUE, built.queue], [KEY, built.key]]) {
    const output = path.join(PATHS.researchRoot, relative);
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, `${JSON.stringify(value, null, 2)}\n`);
  }
  process.stdout.write(`${JSON.stringify({ queue: QUEUE, key: KEY, denominators: built.queue.denominators }, null, 2)}\n`);
}

if (require.main === module) main();

module.exports = { buildQueue, candidateLabels, selectCases };
