# Research module boundaries

Research modules should be small, streaming where practical, and independent of extension packaging.

| Directory | Responsibility | Must not do |
|---|---|---|
| `table-corpus/` | Inspect samples/statistics and generate explicitly filtered singleton/detail priors. | Infer collection structure from the listing-filtered corpus. |
| `pave/` | Inspect JSONL, `pid` text anchoring, and bounded offer-identifier linkage. | Treat product attributes as DOM or Schema.org property labels. |
| `crawl-join/` | Resolve raw WDC source records to immutable responses from the matching crawl. | Fetch current live URLs as replacements. |
| `declarations/` | Preserve declarations, apply recorded mechanical normalization, and emit diagnostics. | Apply semantic repairs or become extension runtime code. |
| `alignment/` | Match declared values to structural candidates with confidence and competitors. | Treat value shape or one text match as semantic proof. |
| `evaluation/` | Build domain/temporal splits and denominator-explicit metrics. | Randomly split pages from the same domain across train and test. |
| `review/` | Support bounded human scope/type adjudication. | Store unreviewed raw pages in committed fixtures. |

Imports flow in one direction:

```text
research/wdc-page-analysis -> extension inference modules
extension                  -X-> research/wdc-page-analysis
```

Large-data and network entry points must be explicit commands. Library modules must not download at import time.

