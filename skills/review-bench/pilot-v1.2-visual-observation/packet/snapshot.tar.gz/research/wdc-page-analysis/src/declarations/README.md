# Declaration assessment

Preserve original declarations, apply only recorded mechanical normalization, and emit research diagnostics needed to characterize weak-label quality. This is not a general Schema.org repair engine.

