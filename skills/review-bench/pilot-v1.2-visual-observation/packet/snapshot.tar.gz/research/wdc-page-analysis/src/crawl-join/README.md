# Crawl-join spike

Resolve a small, host-diverse raw WDC sample to immutable responses in the corresponding Common Crawl collection. Record exact snapshot identity and reject current-live-page substitution.

The initial bounded fetch command can consume either WDC N-Quads or a generated JSON page sample. For a complete class chunk, first select one page per lookup-defined pay-level domain:

```sh
npm run sample:jobposting-chunk --prefix research/wdc-page-analysis
```

Then join the resulting sample to the source crawl:

```sh
npm run fetch:jobposting-sample --prefix research/wdc-page-analysis -- \
  --input data/intermediate/jobposting/part_13.gz-host-diverse.json \
  --output data/raw/common-crawl/CC-MAIN-2024-42/jobposting-part-13-host-diverse \
  --collection CC-MAIN-2024-42 \
  --limit 50
```

It queries the named Common Crawl index sequentially and retries bounded transient failures. Only a unique HTTP 200 HTML capture is fetched, using the exact indexed WARC byte range. Missing and ambiguous captures remain explicit result records; the command never substitutes a current live page. Completed results are reused on a resumed probe.

The separate `probe-wayback-css.js` command tests historical stylesheet recovery for the human-validated sample. It keeps one-sided captures distinct from true before/after brackets, compares the fetched raw payloads with local SHA-256 digests, and records unavailable or unstable resources rather than treating all archive hits as equivalent visual evidence.

After the probe completes, build script-disabled, historically corroborated visual fixtures:

```sh
npm run import:jobposting-visual-fixtures --prefix research/wdc-page-analysis
```

Use `-- --case jobposting-structure-03` for one reviewed case or `-- --max-assets 50` to lower the default per-case dependency bound. Completed case directories are reused on subsequent runs.

The importer accepts only exact captures or byte-identical captures bracketing the Common Crawl page timestamp. It localizes accepted stylesheets, recursively follows CSS imports and referenced fonts/images, fetches presentational HTML assets (including `srcset` alternatives), rewrites accepted references to local files, and blocks all remaining network access with a fixture CSP. Every completed case is a resumable checkpoint with a manifest containing archive timestamps, payload and fixture hashes, unresolved resources, and whether the bounded resource limit was reached. Delete a generated case directory to rebuild it. Publisher JavaScript remains removed and disabled; these are historically corroborated static-render fixtures, not complete browser replays.
