"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { JSDOM, VirtualConsole } = require("jsdom");
const { PATHS } = require("../scaffold");
const evidenceScope = require(path.join(PATHS.repositoryRoot, "extension/editor/evidence-scope"));
const { parseWarcResponse } = require("../crawl-join/warc-response");
const { inventory, scalarValues } = require("../declarations/inventory");
const { normalize, visibleHaystack } = require("./dom-evidence");
const { assessCandidate } = require("./entity-root-assignment");

const DEFAULT_JOIN = "data/raw/common-crawl/CC-MAIN-2024-42/jobposting-part-13-host-diverse";
const DEFAULT_OUTPUT = "data/derived/jobposting/part-13-static-analysis.jsonl";
const DEFAULT_WDC = "data/derived/jobposting/part-13-wdc-entities.jsonl";

function parseArgs(argv) {
  const values = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) throw new Error(`Unexpected argument: ${token}`);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for ${token}.`);
    values[token.slice(2)] = value;
    index += 1;
  }
  return {
    join: path.resolve(PATHS.researchRoot, values.join || DEFAULT_JOIN),
    output: path.resolve(PATHS.researchRoot, values.output || DEFAULT_OUTPUT),
    wdc: path.resolve(PATHS.researchRoot, values.wdc || DEFAULT_WDC)
  };
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function usefulValue(item) {
  const value = normalize(item.value);
  if (value.length < 3 || value.length > 500) return false;
  if (/^https?:\/\//.test(value) || /^\S+@\S+$/.test(value)) return false;
  return true;
}

function alignment(entity, document, candidate) {
  const values = entity.values.filter(usefulValue);
  if (!candidate?.selector || !values.length) return { eligibleValues: values.length, matchedValues: 0, matchRatio: 0 };
  let roots;
  try { roots = Array.from(document.querySelectorAll(candidate.selector)); } catch { roots = []; }
  const perRoot = roots.map((root, rootIndex) => {
    const text = visibleHaystack(root);
    const matched = values.filter((item) => text.includes(normalize(item.value)));
    return { rootIndex, matched };
  }).sort((left, right) => right.matched.length - left.matched.length || left.rootIndex - right.rootIndex);
  const best = perRoot[0] || { rootIndex: null, matched: [] };
  return {
    eligibleValues: values.length,
    matchedValues: best.matched.length,
    matchRatio: Math.round((best.matched.length / values.length) * 1000) / 1000,
    bestRootIndex: best.rootIndex,
    rootsWithMatches: perRoot.filter((item) => item.matched.length).length,
    matchedPaths: [...new Set(best.matched.map((item) => item.path))].sort()
  };
}

function allCandidates(scan) {
  const candidates = [];
  const seen = new Set();
  for (const [source, items] of [["primary", scan.candidates], ["detail", scan.detailScopes], ["secondary", scan.secondaryScopes]]) {
    for (const candidate of items || []) {
      if (!candidate?.selector || seen.has(candidate.selector)) continue;
      seen.add(candidate.selector);
      candidates.push({ candidate, source });
    }
  }
  return candidates;
}

function scopeSummary(scan) {
  const candidate = scan.chosen;
  const considered = allCandidates(scan);
  return {
    mode: scan.mode,
    confidence: scan.confidence,
    margin: scan.margin,
    evidenceCount: scan.evidenceCount,
    candidateCount: scan.candidates.length,
    consideredCandidateCount: considered.length,
    candidates: considered.map(({ candidate: item, source }, rank) => ({
      rank: rank + 1,
      source,
      selector: item.selector,
      kind: item.kind,
      score: item.score,
      matchCount: item.matchCount,
      evidenceKinds: item.evidenceKinds,
      reason: item.reason || null
    })),
    chosen: candidate ? {
      selector: candidate.selector,
      kind: candidate.kind,
      score: candidate.score,
      matchCount: candidate.matchCount,
      evidenceKinds: candidate.evidenceKinds,
      reason: candidate.reason || null
    } : null
  };
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  const resultsPath = path.join(options.join, "results.jsonl");
  const results = fs.readFileSync(resultsPath, "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  const unique = results.filter((result) => result.status === "unique-match");
  const wdcPages = fs.readFileSync(options.wdc, "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  const wdcByHash = new Map(wdcPages.map((page) => [page.sourceUrlSha256, page]));
  fs.mkdirSync(path.dirname(options.output), { recursive: true });
  fs.writeFileSync(options.output, "");
  const counts = { pages: unique.length, withStrictJobPosting: 0, withoutStrictJobPosting: 0, strictDeclarationEntities: 0, wdcDeclarationEntities: 0, invalidJsonLdScripts: 0, scopeChosen: 0, highConfidenceScope: 0, structureChosenEligible: 0, structureAnyEligible: 0, structureUniqueEligible: 0, structureChosenUniqueEligible: 0 };
  const formats = {};

  for (const [index, result] of unique.entries()) {
    const warcPath = path.join(options.join, "records", result.files.decompressed);
    const response = parseWarcResponse(fs.readFileSync(warcPath));
    const dom = new JSDOM(response.text, { url: result.sourceUrl, virtualConsole: new VirtualConsole() });
    const declared = inventory(dom.window.document);
    const scan = evidenceScope.find(dom.window.document, { candidateLimit: 8, includeObservations: false });
    const scope = scopeSummary(scan);
    const considered = allCandidates(scan);
    function alignedEntities(sourceEntities) {
      return sourceEntities.map((entity) => ({
      format: entity.format,
      valueCount: entity.values.length,
      alignment: alignment(entity, dom.window.document, scan.chosen),
      candidateAlignments: considered.map(({ candidate, source }, rank) => ({ rank: rank + 1, source, selector: candidate.selector, ...alignment(entity, dom.window.document, candidate) }))
      }));
    }
    const entities = alignedEntities(declared.entities);
    const wdcSource = wdcByHash.get(result.sourceUrlSha256);
    const wdcAssignmentEntities = (wdcSource?.entities || []).map((entity) => ({
      format: "wdc-rdf",
      values: scalarValues(entity.normalized).filter((item) => !String(item.value).startsWith("_:") && !item.path.endsWith("@cycle"))
    }));
    const wdcEntities = alignedEntities(wdcAssignmentEntities);
    const structureCandidates = considered.map(({ candidate, source }, rank) => ({ rank: rank + 1, source, ...assessCandidate(dom.window.document, candidate, wdcAssignmentEntities) }));
    const chosenStructure = scan.chosen ? assessCandidate(dom.window.document, scan.chosen, wdcAssignmentEntities) : null;
    const eligibleStructureCandidates = structureCandidates.filter((candidate) => candidate.eligible);
    const uniqueEligibleStructure = eligibleStructureCandidates.length === 1 ? eligibleStructureCandidates[0] : null;
    const page = {
      format: "site2json-wdc-static-page-analysis",
      version: 1,
      sourceUrlSha256: result.sourceUrlSha256,
      capture: { timestamp: result.capture.timestamp, digest: result.capture.digest },
      observationMode: "common-crawl-static-html",
      response: { bytes: response.body.length, contentType: response.http.values["content-type"] || null, bodySha256: `sha256:${sha256(response.body)}` },
      declarations: {
        jobPostingEntityCount: entities.length,
        formats: declared.formats,
        jsonLdScriptCount: declared.scriptCount,
        findings: declared.findings,
        entities,
        wdc: { jobPostingEntityCount: wdcEntities.length, entities: wdcEntities, representation: "mechanical-rdf-projection", semanticRepairApplied: false }
      },
      scope,
      structureAlignment: {
        policy: "one-to-one-v1",
        labelStatus: "diagnostic-only",
        chosen: chosenStructure,
        candidates: structureCandidates,
        eligibleCandidateCount: eligibleStructureCandidates.length,
        uniqueEligibleCandidate: uniqueEligibleStructure,
        chosenIsUniqueEligible: Boolean(uniqueEligibleStructure && scan.chosen?.selector === uniqueEligibleStructure.selector)
      }
    };
    fs.appendFileSync(options.output, `${JSON.stringify(page)}\n`);
    if (entities.length) counts.withStrictJobPosting += 1;
    else counts.withoutStrictJobPosting += 1;
    counts.strictDeclarationEntities += entities.length;
    counts.wdcDeclarationEntities += wdcEntities.length;
    counts.invalidJsonLdScripts += declared.findings.filter((finding) => finding.code === "invalid-json").length;
    if (scope.chosen) counts.scopeChosen += 1;
    if (scope.chosen && scope.confidence === "high") counts.highConfidenceScope += 1;
    if (chosenStructure?.eligible) counts.structureChosenEligible += 1;
    if (eligibleStructureCandidates.length) counts.structureAnyEligible += 1;
    if (uniqueEligibleStructure) counts.structureUniqueEligible += 1;
    if (uniqueEligibleStructure && scan.chosen?.selector === uniqueEligibleStructure.selector) counts.structureChosenUniqueEligible += 1;
    for (const format of declared.formats) formats[format] = (formats[format] || 0) + 1;
    dom.window.close();
    process.stdout.write(`[${index + 1}/${unique.length}] entities=${entities.length} scope=${scope.mode}/${scope.confidence}\n`);
  }

  const summary = {
    format: "site2json-wdc-static-analysis-summary",
    version: 1,
    generatedAt: new Date().toISOString(),
    input: path.relative(PATHS.researchRoot, resultsPath),
    inputSha256: `sha256:${sha256(fs.readFileSync(resultsPath))}`,
    wdcInput: path.relative(PATHS.researchRoot, options.wdc),
    wdcInputSha256: `sha256:${sha256(fs.readFileSync(options.wdc))}`,
    output: path.relative(PATHS.researchRoot, options.output),
    observationMode: "common-crawl-static-html",
    counts,
    pagesByDeclarationFormat: formats
  };
  fs.writeFileSync(`${options.output}.summary.json`, `${JSON.stringify(summary, null, 2)}\n`);
  process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
}

if (require.main === module) {
  main().catch((error) => {
    process.stderr.write(`${error instanceof Error ? error.stack : String(error)}\n`);
    process.exitCode = 1;
  });
}

module.exports = { alignment, allCandidates, normalize, scopeSummary, usefulValue, visibleHaystack };
