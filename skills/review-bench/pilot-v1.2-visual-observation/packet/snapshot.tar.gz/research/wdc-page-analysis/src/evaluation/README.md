# Evaluation

Measure candidate generation, structural ranking, semantic shortlist, joint ranking, calibration, and automatic-acceptance risk separately. Report entity-, page-, host-, pay-level-domain-, and defensible generator/template-cluster denominators explicitly.

