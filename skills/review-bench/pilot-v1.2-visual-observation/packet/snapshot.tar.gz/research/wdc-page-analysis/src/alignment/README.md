# DOM alignment

Align declared values to Site2JSON structural candidates using independent evidence families, competitor analysis, and versioned confidence policy. One exact text match or compatible value shape is insufficient.

