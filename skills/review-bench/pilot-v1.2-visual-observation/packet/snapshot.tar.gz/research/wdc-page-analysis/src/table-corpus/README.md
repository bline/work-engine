# Table Corpus spike

Inspect class samples and published statistics for property prevalence, nested-value realization, and value shapes. Results are valid only for the Table Corpus's filtered, attribute-rich population and should initially be compared with singleton/detail fixtures.

