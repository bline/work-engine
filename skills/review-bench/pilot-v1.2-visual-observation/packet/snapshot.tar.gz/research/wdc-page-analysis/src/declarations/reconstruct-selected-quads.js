"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { PATHS } = require("../scaffold");

const RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type";
const JOB_POSTING = new Set(["http://schema.org/JobPosting", "https://schema.org/JobPosting"]);
const DEFAULT_INPUT = "data/intermediate/jobposting/part-13-selected.nq";
const DEFAULT_OUTPUT = "data/derived/jobposting/part-13-wdc-entities.jsonl";

function decodeEscapes(value) {
  return value.replace(/\\(?:[tbnrf"'\\]|u[0-9a-fA-F]{4}|U[0-9a-fA-F]{8})/g, (escape) => {
    const code = escape[1];
    if (code === "u" || code === "U") return String.fromCodePoint(Number.parseInt(escape.slice(2), 16));
    return { t: "\t", b: "\b", n: "\n", r: "\r", f: "\f", '"': '"', "'": "'", "\\": "\\" }[code];
  });
}

function parseTerm(line, cursor, role) {
  while (/\s/.test(line[cursor])) cursor += 1;
  if (line[cursor] === "<") {
    const end = line.indexOf(">", cursor + 1);
    if (end === -1) throw new Error(`Unterminated IRI ${role}.`);
    return { term: { kind: "iri", value: decodeEscapes(line.slice(cursor + 1, end)) }, cursor: end + 1 };
  }
  if (line.startsWith("_:", cursor)) {
    const match = line.slice(cursor).match(/^_:[^\s]+/);
    return { term: { kind: "blank", value: match[0] }, cursor: cursor + match[0].length };
  }
  if (role !== "object" || line[cursor] !== '"') throw new Error(`Unsupported ${role} term.`);
  let end = cursor + 1;
  let escaped = false;
  for (; end < line.length; end += 1) {
    const character = line[end];
    if (character === '"' && !escaped) break;
    if (character === "\\" && !escaped) escaped = true;
    else escaped = false;
  }
  if (end === line.length) throw new Error("Unterminated literal.");
  const term = { kind: "literal", value: decodeEscapes(line.slice(cursor + 1, end)) };
  let next = end + 1;
  if (line[next] === "@") {
    const match = line.slice(next + 1).match(/^[a-zA-Z]+(?:-[a-zA-Z0-9]+)*/);
    if (!match) throw new Error("Invalid literal language tag.");
    term.language = match[0].toLowerCase();
    next += match[0].length + 1;
  } else if (line.startsWith("^^", next)) {
    const datatype = parseTerm(line, next + 2, "datatype");
    if (datatype.term.kind !== "iri") throw new Error("Literal datatype must be an IRI.");
    term.datatype = datatype.term.value;
    next = datatype.cursor;
  }
  return { term, cursor: next };
}

function parseQuad(line) {
  let cursor = 0;
  const subject = parseTerm(line, cursor, "subject");
  cursor = subject.cursor;
  const predicate = parseTerm(line, cursor, "predicate");
  cursor = predicate.cursor;
  const object = parseTerm(line, cursor, "object");
  cursor = object.cursor;
  const graph = parseTerm(line, cursor, "graph");
  cursor = graph.cursor;
  if (predicate.term.kind !== "iri" || graph.term.kind !== "iri" || !/^\s*\.\s*$/.test(line.slice(cursor))) throw new Error("Invalid N-Quads statement ending.");
  return { subject: subject.term, predicate: predicate.term, object: object.term, graph: graph.term };
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function localName(iri) {
  const value = iri.split(/[\/#]/).pop();
  return value || iri;
}

function groupProperties(triples) {
  const grouped = new Map();
  for (const triple of triples) {
    const values = grouped.get(triple.predicate.value) || [];
    values.push(triple.object);
    grouped.set(triple.predicate.value, values);
  }
  return [...grouped].map(([predicate, values]) => ({ predicate, normalizedName: localName(predicate), values }));
}

function normalizedNode(subject, bySubject, stack = new Set()) {
  if (stack.has(subject)) return { "@id": subject, "@cycle": true };
  const nextStack = new Set(stack).add(subject);
  const result = { "@id": subject };
  for (const property of groupProperties(bySubject.get(subject) || [])) {
    const values = property.values.map((term) => {
      if (term.kind === "blank") return normalizedNode(term.value, bySubject, nextStack);
      if (term.kind === "iri") return { "@id": term.value };
      return term.datatype || term.language ? { "@value": term.value, ...(term.datatype ? { "@type": term.datatype } : {}), ...(term.language ? { "@language": term.language } : {}) } : term.value;
    });
    const value = values.length === 1 ? values[0] : values;
    if (Object.hasOwn(result, property.normalizedName)) {
      result[property.predicate] = value;
    } else {
      result[property.normalizedName] = value;
    }
  }
  return result;
}

function parseArgs(argv) {
  const values = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) throw new Error(`Unexpected argument: ${token}`);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for ${token}.`);
    values[token.slice(2)] = value;
    index += 1;
  }
  return {
    input: path.resolve(PATHS.researchRoot, values.input || DEFAULT_INPUT),
    output: path.resolve(PATHS.researchRoot, values.output || DEFAULT_OUTPUT)
  };
}

function main() {
  const options = parseArgs(process.argv.slice(2));
  const lines = fs.readFileSync(options.input, "utf8").split(/\r?\n/).filter(Boolean);
  const graphs = new Map();
  for (const [index, line] of lines.entries()) {
    let quad;
    try { quad = parseQuad(line); } catch (error) { throw new Error(`Line ${index + 1}: ${error.message}`); }
    const triples = graphs.get(quad.graph.value) || [];
    triples.push({ subject: quad.subject, predicate: quad.predicate, object: quad.object });
    graphs.set(quad.graph.value, triples);
  }
  fs.mkdirSync(path.dirname(options.output), { recursive: true });
  fs.writeFileSync(options.output, "");
  let entityCount = 0;
  for (const [graph, triples] of graphs) {
    const bySubject = new Map();
    for (const triple of triples) {
      const values = bySubject.get(triple.subject.value) || [];
      values.push(triple);
      bySubject.set(triple.subject.value, values);
    }
    const subjects = [...bySubject].filter(([, values]) => values.some((triple) => triple.predicate.value === RDF_TYPE && triple.object.kind === "iri" && JOB_POSTING.has(triple.object.value))).map(([subject]) => subject);
    const entities = subjects.map((subject) => ({
      subject: bySubject.get(subject)[0].subject,
      declaredProperties: groupProperties(bySubject.get(subject)),
      normalized: normalizedNode(subject, bySubject),
      normalization: { kind: "mechanical-rdf-projection", semanticRepairApplied: false }
    }));
    entityCount += entities.length;
    fs.appendFileSync(options.output, `${JSON.stringify({ sourceUrlSha256: `sha256:${sha256(graph)}`, quadCount: triples.length, jobPostingEntityCount: entities.length, entities })}\n`);
  }
  const summary = {
    format: "site2json-wdc-reconstructed-entities-summary",
    version: 1,
    generatedAt: new Date().toISOString(),
    input: path.relative(PATHS.researchRoot, options.input),
    inputSha256: `sha256:${sha256(fs.readFileSync(options.input))}`,
    output: path.relative(PATHS.researchRoot, options.output),
    pages: graphs.size,
    quads: lines.length,
    jobPostingEntities: entityCount,
    normalization: "mechanical RDF graph projection; no semantic repair"
  };
  fs.writeFileSync(`${options.output}.summary.json`, `${JSON.stringify(summary, null, 2)}\n`);
  process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
}

if (require.main === module) {
  try { main(); } catch (error) {
    process.stderr.write(`${error instanceof Error ? error.stack : String(error)}\n`);
    process.exitCode = 1;
  }
}

module.exports = { decodeEscapes, normalizedNode, parseQuad };
