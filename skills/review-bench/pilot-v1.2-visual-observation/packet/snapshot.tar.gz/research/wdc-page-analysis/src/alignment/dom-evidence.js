"use strict";

function normalize(value) {
  return String(value || "").normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
}

function excluded(node) {
  return Boolean(node?.closest?.('script, style, noscript, template, head, meta, link, [hidden], [aria-hidden="true"]'));
}

function canonicalUrl(value, baseUrl) {
  try {
    const url = new URL(value, baseUrl);
    url.hash = "";
    if (url.pathname !== "/") url.pathname = url.pathname.replace(/\/+$/, "");
    return url.href.toLowerCase();
  } catch {
    return null;
  }
}

function rootEvidence(root) {
  const textValues = [];
  const attributeValues = [];
  const urls = new Set();
  const document = root.ownerDocument;
  const showText = document.defaultView?.NodeFilter?.SHOW_TEXT || 4;
  const walker = document.createTreeWalker(root, showText);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (!excluded(node.parentElement)) textValues.push(node.nodeValue);
  }
  for (const node of [root, ...root.querySelectorAll("[content], [datetime], [value], [href], [src]")]) {
    if (excluded(node) || ["META", "LINK"].includes(node.tagName)) continue;
    for (const name of ["content", "datetime", "value", "href", "src"]) {
      if (!node.hasAttribute?.(name)) continue;
      const value = node.getAttribute(name);
      attributeValues.push(value);
      if (["href", "src"].includes(name)) {
        const url = canonicalUrl(value, document.baseURI);
        if (url) urls.add(url);
      }
    }
  }
  const text = normalize(textValues.join(" "));
  const attributes = normalize(attributeValues.join(" "));
  return { text, attributes, combined: normalize(`${text} ${attributes}`), urls, words: text ? text.split(/\s+/).length : 0 };
}

function visibleHaystack(root) {
  return rootEvidence(root).combined;
}

module.exports = { canonicalUrl, excluded, normalize, rootEvidence, visibleHaystack };
