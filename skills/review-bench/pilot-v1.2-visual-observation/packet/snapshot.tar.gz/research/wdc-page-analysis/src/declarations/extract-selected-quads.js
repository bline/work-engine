"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");
const zlib = require("node:zlib");
const { PATHS } = require("../scaffold");

const DEFAULT_INPUT = "data/raw/wdc-schemaorg-2024/jobposting/part_13.gz";
const DEFAULT_PAGES = "data/intermediate/jobposting/part_13.gz-host-diverse.json";
const DEFAULT_OUTPUT = "data/intermediate/jobposting/part-13-selected.nq";

function parseArgs(argv) {
  const values = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) throw new Error(`Unexpected argument: ${token}`);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for ${token}.`);
    values[token.slice(2)] = value;
    index += 1;
  }
  return {
    input: path.resolve(PATHS.researchRoot, values.input || DEFAULT_INPUT),
    pages: path.resolve(PATHS.researchRoot, values.pages || DEFAULT_PAGES),
    output: path.resolve(PATHS.researchRoot, values.output || DEFAULT_OUTPUT)
  };
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function graphUrl(line) {
  return line.match(/ <(https?:\/\/[^>]+)>\s+\.\s*$/)?.[1] || null;
}

function jobPostingSubject(line) {
  return line.match(/^(\S+) <http:\/\/www\.w3\.org\/1999\/02\/22-rdf-syntax-ns#type> <https?:\/\/schema\.org\/JobPosting> /)?.[1] || null;
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  const pageSample = JSON.parse(fs.readFileSync(options.pages, "utf8"));
  const selected = new Set(pageSample.pages.map((page) => page.sourceUrl));
  const counts = new Map([...selected].map((url) => [url, 0]));
  const jobPostings = new Map([...selected].map((url) => [url, new Set()]));
  fs.mkdirSync(path.dirname(options.output), { recursive: true });
  const writer = fs.createWriteStream(options.output);
  const lines = readline.createInterface({ input: fs.createReadStream(options.input).pipe(zlib.createGunzip()), crlfDelay: Infinity });
  let scannedLines = 0;
  let selectedQuads = 0;
  for await (const line of lines) {
    scannedLines += 1;
    const graph = graphUrl(line);
    if (!graph || !selected.has(graph)) continue;
    if (!writer.write(`${line}\n`)) await new Promise((resolve) => writer.once("drain", resolve));
    counts.set(graph, counts.get(graph) + 1);
    const subject = jobPostingSubject(line);
    if (subject) jobPostings.get(graph).add(subject);
    selectedQuads += 1;
  }
  await new Promise((resolve, reject) => writer.end(resolve).on("error", reject));
  const perPage = [...counts].map(([url, quadCount]) => ({ sourceUrlSha256: `sha256:${sha256(url)}`, quadCount, jobPostingEntityCount: jobPostings.get(url).size }));
  const found = perPage.filter((page) => page.quadCount > 0);
  const summary = {
    format: "site2json-wdc-selected-quads-summary",
    version: 1,
    generatedAt: new Date().toISOString(),
    input: path.relative(PATHS.researchRoot, options.input),
    pageSample: path.relative(PATHS.researchRoot, options.pages),
    output: path.relative(PATHS.researchRoot, options.output),
    scannedLines,
    selectedPages: selected.size,
    pagesWithQuads: found.length,
    pagesWithoutQuads: selected.size - found.length,
    selectedQuads,
    jobPostingEntities: perPage.reduce((total, page) => total + page.jobPostingEntityCount, 0),
    pagesWithJobPostingEntity: perPage.filter((page) => page.jobPostingEntityCount > 0).length,
    quadsPerPage: {
      minimum: found.length ? Math.min(...found.map((page) => page.quadCount)) : 0,
      maximum: found.length ? Math.max(...found.map((page) => page.quadCount)) : 0,
      mean: found.length ? Math.round((selectedQuads / found.length) * 100) / 100 : 0
    },
    pages: perPage
  };
  fs.writeFileSync(`${options.output}.summary.json`, `${JSON.stringify(summary, null, 2)}\n`);
  process.stdout.write(`${JSON.stringify({ ...summary, pages: undefined }, null, 2)}\n`);
}

if (require.main === module) {
  main().catch((error) => {
    process.stderr.write(`${error instanceof Error ? error.stack : String(error)}\n`);
    process.exitCode = 1;
  });
}

module.exports = { graphUrl, jobPostingSubject };
