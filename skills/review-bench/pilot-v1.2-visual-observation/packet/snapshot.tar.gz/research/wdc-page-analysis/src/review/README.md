# Human review

Support bounded adjudication of scope, type, shape, role, declaration compatibility, and alignment confidence. Gold labels require human review and retain their evidence and review provenance.

`build-adjudication.js` packages the nine pages with exactly one structure-eligible candidate into a local queue. Candidate labels are deterministically swapped between A and B, while a separate key records which candidate was the current inference winner. This is reviewer blinding, not a claim that either candidate is correct.

The queue reports source-page, domain, and declared-entity denominators separately. It stays under ignored `data/derived/` because it contains source URLs and publisher content.

`serve-adjudication.js` presents the exact recovered static HTML in a local browser viewer. Candidate A is outlined in magenta and candidate B in cyan; either can be isolated. Publisher scripts are removed, links and forms are inert, and the inference-role key is neither loaded nor served. The viewer is evidence display only—answers are recorded separately so the questioning order can adapt to earlier decisions.

After review, `export-validated-pages.js` creates a local bundle for every type-compatible reviewed case. Each case includes a script-disabled clean page, an A/B overlay, the decoded captured source as non-executable text, and metadata with selectors and the reviewed outcome. Publisher captures remain ignored and local-only; public bug reports should use minimized synthetic reproductions derived from the observed failure classes.
