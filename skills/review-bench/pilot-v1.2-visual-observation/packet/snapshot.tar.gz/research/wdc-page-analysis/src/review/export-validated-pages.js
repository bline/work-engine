"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { PATHS } = require("../scaffold");
const { parseWarcResponse } = require("../crawl-join/warc-response");
const { renderSnapshot } = require("./serve-adjudication");

const BASE = "data/derived/jobposting";
const QUEUE = `${BASE}/part-13-structure-adjudication.json`;
const KEY = `${BASE}/part-13-structure-adjudication-key.json`;
const DECISIONS = `${BASE}/part-13-structure-adjudication-decisions.json`;
const OUTPUT = `${BASE}/validated-static-pages`;

function sha256(value) {
  return `sha256:${crypto.createHash("sha256").update(value).digest("hex")}`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function eligibleDecisions(decisions) {
  return decisions.items.filter((item) => item.status === "reviewed" && item.declaredTypeCompatible === true);
}

function indexHtml(items) {
  const rows = items.map((item) => `<tr><td>${escapeHtml(item.reviewId)}</td><td>${escapeHtml(item.pageTitle)}</td><td>${escapeHtml(item.preferredCandidate)}</td><td><a href="${encodeURIComponent(item.reviewId)}/page.html">clean page</a> · <a href="${encodeURIComponent(item.reviewId)}/candidates.html">candidate overlay</a> · <a href="${encodeURIComponent(item.reviewId)}/metadata.json">metadata</a></td></tr>`).join("\n");
  return `<!doctype html><html><head><meta charset="utf-8"><title>Validated JobPosting pages</title><style>body{font:15px/1.5 system-ui,sans-serif;max-width:1100px;margin:2rem auto;padding:0 1rem;color:#111827}table{border-collapse:collapse;width:100%}th,td{border:1px solid #d1d5db;padding:.5rem;text-align:left}th{background:#f3f4f6}code{background:#f3f4f6;padding:.1rem .25rem}</style></head><body><h1>Validated JobPosting static pages</h1><p>Seven type-compatible pages from the human-reviewed unique-candidate stratum. Publisher scripts are removed from browser-viewable files. Candidate A is magenta and B is cyan. See each <code>metadata.json</code> for the reviewed decision and unblinded inference roles.</p><p>These publisher captures are local research material. Do not commit or attach them to a public bug report; derive a minimized synthetic regression first.</p><table><thead><tr><th>Case</th><th>Captured title</th><th>Preferred</th><th>Files</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
}

function exportPages(queue, key, decisions, readWarc) {
  const queueById = new Map(queue.items.map((item) => [item.reviewId, item]));
  const keyById = new Map(key.items.map((item) => [item.reviewId, item]));
  return eligibleDecisions(decisions).map((decision) => {
    const item = queueById.get(decision.reviewId);
    const keyItem = keyById.get(decision.reviewId);
    if (!item || !keyItem) throw new Error(`Missing queue/key record for ${decision.reviewId}.`);
    const warc = readWarc(item);
    const response = parseWarcResponse(warc);
    return {
      reviewId: decision.reviewId,
      pageTitle: item.page.title,
      sourceUrl: item.sourceUrl,
      sourceUrlSha256: item.sourceUrlSha256,
      captureBodySha256: sha256(response.body),
      cleanHtml: renderSnapshot(item, warc, "none"),
      candidateHtml: renderSnapshot(item, warc, "both"),
      capturedSource: response.text,
      metadata: {
        format: "site2json-wdc-validated-static-page",
        version: 1,
        reviewId: decision.reviewId,
        sourceUrl: item.sourceUrl,
        sourceUrlSha256: item.sourceUrlSha256,
        observationMode: item.page.observationMode,
        captureBodySha256: sha256(response.body),
        declaredType: item.declaration.declaredType,
        candidateRoles: keyItem.candidateRoles,
        candidates: Object.fromEntries(Object.entries(item.candidates).map(([label, candidate]) => [label, {
          selector: candidate.selector,
          matchCount: candidate.matchCount,
          tags: candidate.tags
        }])),
        decision
      }
    };
  });
}

function main() {
  const load = (relative) => JSON.parse(fs.readFileSync(path.join(PATHS.researchRoot, relative), "utf8"));
  const queue = load(QUEUE);
  const key = load(KEY);
  const decisions = load(DECISIONS);
  const pages = exportPages(queue, key, decisions, (item) => fs.readFileSync(path.join(PATHS.researchRoot, item.snapshot)));
  const output = path.join(PATHS.researchRoot, OUTPUT);
  fs.mkdirSync(output, { recursive: true });
  for (const page of pages) {
    const directory = path.join(output, page.reviewId);
    fs.mkdirSync(directory, { recursive: true });
    fs.writeFileSync(path.join(directory, "page.html"), page.cleanHtml);
    fs.writeFileSync(path.join(directory, "candidates.html"), page.candidateHtml);
    fs.writeFileSync(path.join(directory, "captured-source.html.txt"), page.capturedSource);
    fs.writeFileSync(path.join(directory, "metadata.json"), `${JSON.stringify(page.metadata, null, 2)}\n`);
  }
  const manifest = {
    format: "site2json-wdc-validated-static-pages",
    version: 1,
    generatedAt: new Date().toISOString(),
    pageCount: pages.length,
    redistribution: "local-research-only",
    pages: pages.map(({ reviewId, pageTitle, sourceUrlSha256, captureBodySha256 }) => ({ reviewId, pageTitle, sourceUrlSha256, captureBodySha256 }))
  };
  fs.writeFileSync(path.join(output, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
  fs.writeFileSync(path.join(output, "index.html"), indexHtml(pages));
  process.stdout.write(`${JSON.stringify({ output: OUTPUT, pageCount: pages.length, cases: pages.map((page) => page.reviewId) }, null, 2)}\n`);
}

if (require.main === module) main();

module.exports = { eligibleDecisions, exportPages, indexHtml };
