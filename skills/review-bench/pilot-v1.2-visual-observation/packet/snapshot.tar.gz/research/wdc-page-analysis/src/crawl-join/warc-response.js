"use strict";

function separator(buffer, start = 0) {
  const crlf = buffer.indexOf("\r\n\r\n", start, "ascii");
  if (crlf !== -1) return { index: crlf, length: 4 };
  const lf = buffer.indexOf("\n\n", start, "ascii");
  if (lf !== -1) return { index: lf, length: 2 };
  return null;
}

function headers(text) {
  const lines = text.split(/\r?\n/);
  const firstLine = lines.shift() || "";
  const values = {};
  for (const line of lines) {
    const colon = line.indexOf(":");
    if (colon < 1) continue;
    const name = line.slice(0, colon).trim().toLowerCase();
    const value = line.slice(colon + 1).trim();
    values[name] = values[name] ? `${values[name]}, ${value}` : value;
  }
  return { firstLine, values };
}

function decodeBody(body, contentType) {
  const charset = /charset\s*=\s*["']?([^;\s"']+)/i.exec(contentType || "")?.[1] || "utf-8";
  try {
    return new TextDecoder(charset).decode(body);
  } catch {
    return new TextDecoder("utf-8").decode(body);
  }
}

function parseWarcResponse(buffer) {
  const warcBreak = separator(buffer);
  if (!warcBreak) throw new Error("WARC header separator not found.");
  const warc = headers(buffer.subarray(0, warcBreak.index).toString("utf8"));
  if (warc.values["warc-type"] !== "response") throw new Error(`Expected WARC response, found ${warc.values["warc-type"] || "unknown"}.`);

  const httpStart = warcBreak.index + warcBreak.length;
  const httpBreak = separator(buffer, httpStart);
  if (!httpBreak) throw new Error("HTTP header separator not found in WARC response.");
  const http = headers(buffer.subarray(httpStart, httpBreak.index).toString("latin1"));
  if (!/^HTTP\/\d(?:\.\d)?\s+200(?:\s|$)/.test(http.firstLine)) throw new Error(`Expected HTTP 200 response, found ${http.firstLine || "unknown"}.`);
  const body = buffer.subarray(httpBreak.index + httpBreak.length);
  return {
    warc,
    http,
    body,
    text: decodeBody(body, http.values["content-type"])
  };
}

module.exports = { headers, parseWarcResponse };
