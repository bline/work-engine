"use strict";

const JOB_POSTING = /(?:^|[/#:]|\b)JobPosting$/i;

function types(value) {
  return (Array.isArray(value) ? value : [value]).filter((item) => typeof item === "string");
}

function isJobPostingType(value) {
  return types(value).some((type) => JOB_POSTING.test(type));
}

function scalarValues(value, path = "", found = []) {
  if (value === null || value === undefined) return found;
  if (["string", "number", "boolean"].includes(typeof value)) {
    const text = String(value).replace(/\s+/g, " ").trim();
    if (text && !path.endsWith("@context") && !path.endsWith("@type")) found.push({ path, value: text });
    return found;
  }
  if (Array.isArray(value)) {
    value.forEach((item) => scalarValues(item, path, found));
    return found;
  }
  if (typeof value === "object") {
    for (const [key, item] of Object.entries(value)) scalarValues(item, path ? `${path}.${key}` : key, found);
  }
  return found;
}

function jsonLdEntities(value, found = [], seen = new Set()) {
  if (!value || typeof value !== "object" || seen.has(value)) return found;
  seen.add(value);
  if (Array.isArray(value)) {
    value.forEach((item) => jsonLdEntities(item, found, seen));
    return found;
  }
  if (isJobPostingType(value["@type"])) found.push({ format: "json-ld", declared: value, values: scalarValues(value) });
  for (const item of Object.values(value)) jsonLdEntities(item, found, seen);
  return found;
}

function elementValue(element) {
  const attribute = ["content", "datetime", "href", "src", "value"].find((name) => element.hasAttribute(name));
  return String(attribute ? element.getAttribute(attribute) : element.textContent || "").replace(/\s+/g, " ").trim();
}

function domEntity(element, format) {
  const values = [];
  const propertyAttribute = format === "microdata" ? "itemprop" : "property";
  for (const node of element.querySelectorAll(`[${propertyAttribute}]`)) {
    if (format === "microdata") {
      const owner = node.closest("[itemscope]");
      if (owner && owner !== element) continue;
    }
    const value = elementValue(node);
    if (!value) continue;
    for (const property of node.getAttribute(propertyAttribute).split(/\s+/).filter(Boolean)) values.push({ path: property, value });
  }
  return { format, values };
}

function inventory(document) {
  const entities = [];
  const findings = [];
  const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json" i]'));
  for (const [index, script] of scripts.entries()) {
    const text = script.textContent.trim();
    if (!text) {
      findings.push({ format: "json-ld", index, code: "empty-script" });
      continue;
    }
    try {
      jsonLdEntities(JSON.parse(text), entities);
    } catch (error) {
      findings.push({ format: "json-ld", index, code: "invalid-json", message: error instanceof Error ? error.message : String(error) });
    }
  }

  for (const element of document.querySelectorAll("[itemscope][itemtype]")) {
    if (element.getAttribute("itemtype").split(/\s+/).some((type) => isJobPostingType(type))) entities.push(domEntity(element, "microdata"));
  }
  for (const element of document.querySelectorAll("[typeof]")) {
    if (element.getAttribute("typeof").split(/\s+/).some((type) => isJobPostingType(type))) entities.push(domEntity(element, "rdfa"));
  }

  return {
    scriptCount: scripts.length,
    entities,
    findings,
    formats: [...new Set(entities.map((entity) => entity.format))]
  };
}

module.exports = { inventory, isJobPostingType, jsonLdEntities, scalarValues };
