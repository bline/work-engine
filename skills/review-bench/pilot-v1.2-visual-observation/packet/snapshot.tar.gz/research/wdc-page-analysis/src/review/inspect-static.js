"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { JSDOM, VirtualConsole } = require("jsdom");
const { PATHS } = require("../scaffold");
const { parseWarcResponse } = require("../crawl-join/warc-response");
const { inventory } = require("../declarations/inventory");
const { visibleHaystack } = require("../alignment/dom-evidence");

const ANALYSIS = "data/derived/jobposting/part-13-static-analysis.jsonl";
const JOIN = "data/raw/common-crawl/CC-MAIN-2024-42/jobposting-part-13-host-diverse";
const OUTPUT = "data/derived/jobposting/part-13-static-review-sample.json";

function normalize(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function max(values) {
  return values.length ? Math.max(...values) : 0;
}

function measures(page) {
  const entities = page.declarations.wdc?.entities || page.declarations.entities;
  return {
    chosen: max(entities.map((entity) => entity.alignment.matchRatio)),
    generated: max(entities.flatMap((entity) => entity.candidateAlignments.map((alignment) => alignment.matchRatio)))
  };
}

function select(pages) {
  const selected = new Map();
  function take(stratum, predicate, limit) {
    let count = 0;
    for (const [index, page] of pages.entries()) {
      if (count === limit) break;
      if (!predicate(page, measures(page))) continue;
      const current = selected.get(index) || { page, strata: [] };
      current.strata.push(stratum);
      selected.set(index, current);
      count += 1;
    }
  }
  take("strict-parse-failure", (page) => page.declarations.jobPostingEntityCount === 0, 2);
  take("multiple-declared-entities", (page) => page.declarations.jobPostingEntityCount > 1, 2);
  take("candidate-ranking-opportunity", (_page, score) => score.generated - score.chosen >= 0.25, 3);
  take("candidate-generation-weak", (page, score) => page.declarations.jobPostingEntityCount > 0 && score.generated === 0, 2);
  take("strong-chosen-alignment", (_page, score) => score.chosen >= 0.75, 2);
  take("structure-eligible-chosen", (page) => page.structureAlignment?.chosen?.eligible === true, 20);
  take("structure-eligible-alternative", (page) => page.structureAlignment?.chosen?.eligible !== true && page.structureAlignment?.eligibleCandidateCount > 0, 5);
  take("structure-unique-alternative", (page) => page.structureAlignment?.uniqueEligibleCandidate && !page.structureAlignment?.chosenIsUniqueEligible, 20);
  const baseline = pages.map((page, index) => ({ page, index })).filter(({ page }) => page.declarations.jobPostingEntityCount > 0)
    .sort((left, right) => left.page.sourceUrlSha256.localeCompare(right.page.sourceUrlSha256)).slice(0, 5);
  for (const { page, index } of baseline) {
    const current = selected.get(index) || { page, strata: [] };
    current.strata.push("hash-selected-baseline");
    selected.set(index, current);
  }
  return [...selected.entries()].map(([index, value]) => ({ index, ...value }));
}

function roots(document, selector) {
  if (!selector) return [];
  try { return Array.from(document.querySelectorAll(selector)); } catch { return []; }
}

function rootSummary(document, selector) {
  const matches = roots(document, selector);
  return {
    matchCount: matches.length,
    tags: [...new Set(matches.map((root) => root.tagName.toLowerCase()))],
    snippets: matches.slice(0, 3).map((root) => normalize(visibleHaystack(root)).slice(0, 300))
  };
}

function declaredIdentity(entity) {
  return entity.values.filter((item) => /(?:^|\.)(?:title|name|identifier|url|@id)$/.test(item.path)).slice(0, 12);
}

function bestCandidate(page) {
  const entities = page.declarations.wdc?.entities || page.declarations.entities;
  const alignments = entities.flatMap((entity) => entity.candidateAlignments);
  return alignments.sort((left, right) => right.matchRatio - left.matchRatio || left.rank - right.rank)[0] || null;
}

function main() {
  const analysisPath = path.join(PATHS.researchRoot, ANALYSIS);
  const joinPath = path.join(PATHS.researchRoot, JOIN);
  const pages = fs.readFileSync(analysisPath, "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  const joined = fs.readFileSync(path.join(joinPath, "results.jsonl"), "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  const byHash = new Map(joined.map((result) => [result.sourceUrlSha256, result]));
  const review = select(pages).map(({ index, page, strata }) => {
    const result = byHash.get(page.sourceUrlSha256);
    const response = parseWarcResponse(fs.readFileSync(path.join(joinPath, "records", result.files.decompressed)));
    const dom = new JSDOM(response.text, { url: result.sourceUrl, virtualConsole: new VirtualConsole() });
    const declared = inventory(dom.window.document);
    const best = bestCandidate(page);
    const item = {
      index,
      sourceUrlSha256: page.sourceUrlSha256,
      strata,
      page: {
        title: normalize(dom.window.document.title).slice(0, 300),
        headings: Array.from(dom.window.document.querySelectorAll("h1")).slice(0, 5).map((node) => normalize(node.textContent).slice(0, 300))
      },
      declarations: {
        entityCount: declared.entities.length,
        wdcEntityCount: page.declarations.wdc?.jobPostingEntityCount || 0,
        identities: declared.entities.map((entity) => ({ format: entity.format, values: declaredIdentity(entity) }))
      },
      inference: {
        mode: page.scope.mode,
        confidence: page.scope.confidence,
        chosenSelector: page.scope.chosen?.selector || null,
        chosenAlignment: measures(page).chosen,
        chosenRoots: rootSummary(dom.window.document, page.scope.chosen?.selector),
        bestGeneratedSelector: best?.selector || null,
        bestGeneratedSource: best?.source || null,
        bestGeneratedAlignment: best?.matchRatio || 0,
        bestGeneratedRoots: rootSummary(dom.window.document, best?.selector),
        chosenStructure: page.structureAlignment?.chosen || null,
        eligibleStructureCandidates: (page.structureAlignment?.candidates || []).filter((candidate) => candidate.eligible).map((candidate) => ({
          rank: candidate.rank,
          source: candidate.source,
          selector: candidate.selector,
          rootCount: candidate.rootCount,
          score: candidate.score,
          assignments: candidate.assignments
        }))
      }
    };
    dom.window.close();
    return item;
  });
  const output = path.join(PATHS.researchRoot, OUTPUT);
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, `${JSON.stringify({ format: "site2json-wdc-static-review-sample", version: 1, generatedAt: new Date().toISOString(), items: review }, null, 2)}\n`);
  process.stdout.write(`${JSON.stringify(review.map((item) => ({ index: item.index, sourceUrlSha256: item.sourceUrlSha256, strata: item.strata })), null, 2)}\n`);
}

if (require.main === module) main();

module.exports = { measures, select };
