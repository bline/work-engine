"use strict";

const path = require("node:path");

const RESEARCH_ROOT = path.resolve(__dirname, "..");
const REPOSITORY_ROOT = path.resolve(RESEARCH_ROOT, "../..");

const PATHS = Object.freeze({
  researchRoot: RESEARCH_ROOT,
  repositoryRoot: REPOSITORY_ROOT,
  data: path.join(RESEARCH_ROOT, "data"),
  manifests: path.join(RESEARCH_ROOT, "manifests"),
  reports: path.join(RESEARCH_ROOT, "reports"),
  schemas: path.join(RESEARCH_ROOT, "schemas"),
  site2json: Object.freeze({
    evidenceScope: path.join(REPOSITORY_ROOT, "extension/editor/evidence-scope.js"),
    pageAnalysis: path.join(REPOSITORY_ROOT, "extension/authoring/page-analysis.js"),
    semanticRanking: path.join(REPOSITORY_ROOT, "extension/editor/semantic-ranking.js")
  })
});

module.exports = Object.freeze({ PATHS });
