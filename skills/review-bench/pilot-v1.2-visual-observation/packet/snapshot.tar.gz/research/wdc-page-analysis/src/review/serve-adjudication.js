"use strict";

const fs = require("node:fs");
const http = require("node:http");
const path = require("node:path");
const { JSDOM, VirtualConsole } = require("jsdom");
const { PATHS } = require("../scaffold");
const { parseWarcResponse } = require("../crawl-join/warc-response");

const DEFAULT_QUEUE = "data/derived/jobposting/part-13-structure-adjudication.json";

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function parseArgs(argv) {
  const options = { host: "127.0.0.1", port: 4173, queue: DEFAULT_QUEUE };
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    const value = argv[index + 1];
    if (!token.startsWith("--") || !value || value.startsWith("--")) throw new Error(`Expected --name value, received ${token}.`);
    options[token.slice(2)] = value;
    index += 1;
  }
  options.port = Number(options.port);
  if (!Number.isInteger(options.port) || options.port < 1 || options.port > 65535) throw new Error("Port must be an integer from 1 to 65535.");
  options.queue = path.resolve(PATHS.researchRoot, options.queue);
  return options;
}

function applyMarker(document, selector, label) {
  let roots = [];
  try { roots = Array.from(document.querySelectorAll(selector)); } catch { return 0; }
  for (const [index, root] of roots.entries()) {
    root.setAttribute(`data-wdc-review-${label.toLowerCase()}`, String(index + 1));
    const marker = document.createElement("span");
    marker.className = `wdc-review-marker wdc-review-marker-${label.toLowerCase()}`;
    marker.textContent = `${label}${index + 1}`;
    root.insertBefore(marker, root.firstChild);
  }
  return roots.length;
}

function renderSnapshot(item, warcBuffer, show = "both") {
  const response = parseWarcResponse(warcBuffer);
  const dom = new JSDOM(response.text, { url: item.sourceUrl, virtualConsole: new VirtualConsole() });
  const { document } = dom.window;
  document.querySelectorAll("script, meta[http-equiv='Content-Security-Policy' i]").forEach((node) => node.remove());
  let base = document.querySelector("base");
  if (!base) {
    base = document.createElement("base");
    document.head.prepend(base);
  }
  base.href = item.sourceUrl;
  const enabled = show === "both" ? ["A", "B"] : [show.toUpperCase()];
  for (const label of enabled) {
    const candidate = item.candidates[label];
    if (candidate) applyMarker(document, candidate.selector, label);
  }
  const style = document.createElement("style");
  style.textContent = `
    html { scroll-padding-top: 12px !important; }
    body { cursor: default !important; }
    a, button, input, select, textarea, form { pointer-events: none !important; }
    [data-wdc-review-a] { outline: 5px solid #e11d48 !important; outline-offset: -5px !important; }
    [data-wdc-review-b] { box-shadow: inset 0 0 0 5px #0891b2 !important; }
    .wdc-review-marker { all: initial !important; position: sticky !important; top: 4px !important; z-index: 2147483647 !important; display: inline-block !important; padding: 4px 7px !important; color: white !important; font: 700 13px/1.2 ui-monospace, monospace !important; }
    .wdc-review-marker-a { background: #e11d48 !important; }
    .wdc-review-marker-b { background: #0891b2 !important; }
  `;
  document.head.append(style);
  const output = dom.serialize();
  dom.window.close();
  return output;
}

function casePage(queue, index, show) {
  const item = queue.items[index];
  const previous = queue.items[(index - 1 + queue.items.length) % queue.items.length];
  const next = queue.items[(index + 1) % queue.items.length];
  const choice = ["A", "B", "both"].includes(show) ? show : "both";
  const links = ["A", "B", "both"].map((value) => `<a class="${choice === value ? "active" : ""}" href="/case/${encodeURIComponent(item.reviewId)}?show=${value}">${value === "both" ? "Show both" : `Candidate ${value}`}</a>`).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(item.reviewId)} · WDC review</title><style>
    *{box-sizing:border-box}html,body{height:100%;margin:0;font-family:system-ui,sans-serif;background:#111827;color:#f9fafb}body{display:grid;grid-template-rows:auto 1fr}
    header{padding:10px 14px;background:#111827;border-bottom:1px solid #374151;display:flex;align-items:center;gap:12px;flex-wrap:wrap}header strong{font-size:14px}header small{color:#9ca3af;max-width:36rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    nav{display:flex;gap:6px;margin-left:auto}a{color:#e5e7eb;text-decoration:none;border:1px solid #4b5563;border-radius:6px;padding:6px 9px;font-size:13px}a.active{background:#374151}.a{color:#fb7185}.b{color:#22d3ee}.step{color:#9ca3af;font-size:13px}iframe{width:100%;height:100%;border:0;background:white}
  </style></head><body><header><span class="step">${index + 1}/${queue.items.length}</span><strong>${escapeHtml(item.reviewId)}</strong><small title="${escapeHtml(item.page.title)}">${escapeHtml(item.page.title)}</small><span class="a">A = magenta</span><span class="b">B = cyan</span><nav><a href="/case/${encodeURIComponent(previous.reviewId)}?show=${choice}">← Previous</a>${links}<a href="/case/${encodeURIComponent(next.reviewId)}?show=${choice}">Next →</a></nav></header><iframe sandbox="allow-same-origin" src="/snapshot/${encodeURIComponent(item.reviewId)}?show=${choice}" title="Captured page"></iframe></body></html>`;
}

function createServer(queue, queuePath) {
  const byId = new Map(queue.items.map((item, index) => [item.reviewId, { item, index }]));
  return http.createServer((request, response) => {
    const url = new URL(request.url, "http://localhost");
    if (url.pathname === "/") {
      response.writeHead(302, { location: `/case/${encodeURIComponent(queue.items[0].reviewId)}` });
      response.end();
      return;
    }
    const match = url.pathname.match(/^\/(case|snapshot)\/([^/]+)$/);
    const found = match && byId.get(decodeURIComponent(match[2]));
    if (!found) {
      response.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
      response.end("Unknown review case.\n");
      return;
    }
    const show = url.searchParams.get("show") || "both";
    if (match[1] === "case") {
      response.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
      response.end(casePage(queue, found.index, show));
      return;
    }
    const warcPath = path.resolve(PATHS.researchRoot, found.item.snapshot);
    if (!warcPath.startsWith(`${PATHS.researchRoot}${path.sep}`) || !fs.existsSync(warcPath)) {
      response.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
      response.end(`Snapshot unavailable for ${found.item.reviewId}.\n`);
      return;
    }
    response.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
    response.end(renderSnapshot(found.item, fs.readFileSync(warcPath), show));
  });
}

function main() {
  const options = parseArgs(process.argv.slice(2));
  const queue = JSON.parse(fs.readFileSync(options.queue, "utf8"));
  if (!Array.isArray(queue.items) || !queue.items.length) throw new Error("Adjudication queue contains no items.");
  const server = createServer(queue, options.queue);
  server.listen(options.port, options.host, () => {
    process.stdout.write(`WDC adjudication viewer: http://${options.host}:${options.port}/\n`);
    process.stdout.write("The inference-role key is not loaded or served. Press Ctrl+C to stop.\n");
  });
}

if (require.main === module) main();

module.exports = { applyMarker, casePage, createServer, renderSnapshot };
