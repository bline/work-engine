"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const zlib = require("node:zlib");
const { PATHS } = require("../scaffold");

const DEFAULT_COLLECTION = "CC-MAIN-2024-42";
const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 100;
const MAX_REQUEST_ATTEMPTS = 4;
const USER_AGENT = "site2json-wdc-research/0.1 (bounded crawl-join probe)";

function parseArgs(argv) {
  const values = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) throw new Error(`Unexpected argument: ${token}`);
    const name = token.slice(2);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for --${name}.`);
    values[name] = value;
    index += 1;
  }
  const input = path.resolve(PATHS.researchRoot, values.input || "data/raw/wdc-schemaorg-2024/jobposting/JobPosting_sample.txt");
  const output = path.resolve(PATHS.researchRoot, values.output || `data/raw/common-crawl/${DEFAULT_COLLECTION}/jobposting-sample`);
  const collection = values.collection || DEFAULT_COLLECTION;
  const limit = Number(values.limit || DEFAULT_LIMIT);
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > MAX_LIMIT) throw new Error(`--limit must be an integer from 1 to ${MAX_LIMIT}.`);
  if (!/^CC-MAIN-\d{4}-\d{2}$/.test(collection)) throw new Error("--collection must look like CC-MAIN-2024-42.");
  return { input, output, collection, limit };
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function sourceUrls(input, filename) {
  if (path.extname(filename) === ".json") {
    const parsed = JSON.parse(input);
    if (!Array.isArray(parsed.pages)) throw new Error(`JSON input ${filename} must contain a pages array.`);
    return [...new Set(parsed.pages.map((page) => page.sourceUrl).filter((url) => typeof url === "string" && /^https?:\/\//.test(url)))];
  }
  const found = new Set();
  for (const line of input.split(/\r?\n/)) {
    const match = line.match(/ <(https?:\/\/[^>]+)>\s+\.\s*$/);
    if (match) found.add(match[1]);
  }
  return [...found];
}

function indexUrl(collection, sourceUrl) {
  const target = new URL(`https://index.commoncrawl.org/${collection}-index`);
  target.searchParams.set("url", sourceUrl);
  target.searchParams.set("matchType", "exact");
  target.searchParams.set("output", "json");
  target.searchParams.append("filter", "status:200");
  target.searchParams.append("filter", "mime:text/html");
  return target;
}

async function request(url, options = {}) {
  for (let attempt = 1; attempt <= MAX_REQUEST_ATTEMPTS; attempt += 1) {
    const response = await fetch(url, { ...options, headers: { "user-agent": USER_AGENT, ...(options.headers || {}) } });
    if (response.ok) return response;
    const transient = response.status === 429 || response.status >= 500;
    if (!transient || attempt === MAX_REQUEST_ATTEMPTS) throw new Error(`${response.status} ${response.statusText} for ${url}`);
    await new Promise((resolve) => setTimeout(resolve, 500 * (2 ** (attempt - 1))));
  }
  throw new Error(`Request attempts exhausted for ${url}`);
}

async function indexCaptures(collection, sourceUrl) {
  const response = await request(indexUrl(collection, sourceUrl));
  const text = await response.text();
  return text.split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
}

async function fetchWarcRecord(capture) {
  const offset = Number(capture.offset);
  const length = Number(capture.length);
  if (!Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(length) || length < 1) {
    throw new Error("Common Crawl returned an invalid WARC byte range.");
  }
  if (length > 10 * 1024 * 1024) throw new Error(`Refusing an unexpectedly large ${length}-byte WARC record.`);
  const url = `https://data.commoncrawl.org/${capture.filename}`;
  const response = await request(url, { headers: { range: `bytes=${offset}-${offset + length - 1}` } });
  if (response.status !== 206) throw new Error(`Common Crawl did not honor the bounded WARC range request (HTTP ${response.status}).`);
  const compressed = Buffer.from(await response.arrayBuffer());
  if (compressed.length !== length) throw new Error(`Expected ${length} WARC bytes but received ${compressed.length}.`);
  return { compressed, decompressed: zlib.gunzipSync(compressed) };
}

function safeResult(result) {
  return `${JSON.stringify(result)}\n`;
}

function priorResults(filename) {
  if (!fs.existsSync(filename)) return new Map();
  const records = fs.readFileSync(filename, "utf8").split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  return new Map(records.map((record) => [record.sourceUrl, record]));
}

function reusableResult(result, recordsDirectory) {
  if (!result || result.status === "retrieval-failed") return false;
  if (result.status !== "unique-match") return true;
  return result.files && fs.existsSync(path.join(recordsDirectory, result.files.compressed)) && fs.existsSync(path.join(recordsDirectory, result.files.decompressed));
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  const urls = sourceUrls(fs.readFileSync(options.input, "utf8"), options.input).slice(0, options.limit);
  if (!urls.length) throw new Error(`No provenance URLs found in ${options.input}.`);
  const recordsDirectory = path.join(options.output, "records");
  fs.mkdirSync(recordsDirectory, { recursive: true });
  const resultsPath = path.join(options.output, "results.jsonl");
  const previous = priorResults(resultsPath);
  fs.writeFileSync(resultsPath, "");

  const counts = { requested: urls.length, fetched: 0, missing: 0, ambiguous: 0, failed: 0 };
  for (const [index, sourceUrl] of urls.entries()) {
    const urlDigest = sha256(sourceUrl);
    const base = { index, sourceUrl, sourceUrlSha256: `sha256:${urlDigest}`, collection: options.collection };
    let result;
    const prior = previous.get(sourceUrl);
    if (reusableResult(prior, recordsDirectory)) {
      result = { ...prior, index };
      if (result.status === "unique-match") counts.fetched += 1;
      else if (result.status === "no-same-crawl-capture") counts.missing += 1;
      else if (result.status === "multiple-same-crawl-captures") counts.ambiguous += 1;
      fs.appendFileSync(resultsPath, safeResult(result));
      process.stdout.write(`[${index + 1}/${urls.length}] ${result.status} (cached)\n`);
      continue;
    }
    try {
      const captures = await indexCaptures(options.collection, sourceUrl);
      if (!captures.length) {
        counts.missing += 1;
        result = { ...base, status: "no-same-crawl-capture", captureCount: 0 };
      } else if (captures.length !== 1) {
        counts.ambiguous += 1;
        result = {
          ...base,
          status: "multiple-same-crawl-captures",
          captureCount: captures.length,
          captures: captures.map(({ timestamp, digest, filename, offset, length }) => ({ timestamp, digest, filename, offset, length }))
        };
      } else {
        const capture = captures[0];
        const warc = await fetchWarcRecord(capture);
        const compressedName = `${urlDigest}.warc.gz`;
        const decompressedName = `${urlDigest}.warc`;
        fs.writeFileSync(path.join(recordsDirectory, compressedName), warc.compressed);
        fs.writeFileSync(path.join(recordsDirectory, decompressedName), warc.decompressed);
        counts.fetched += 1;
        result = {
          ...base,
          status: "unique-match",
          captureCount: 1,
          capture: {
            timestamp: capture.timestamp,
            digest: capture.digest,
            filename: capture.filename,
            offset: Number(capture.offset),
            length: Number(capture.length)
          },
          files: {
            compressed: compressedName,
            compressedSha256: `sha256:${sha256(warc.compressed)}`,
            decompressed: decompressedName,
            decompressedSha256: `sha256:${sha256(warc.decompressed)}`
          }
        };
      }
    } catch (error) {
      counts.failed += 1;
      result = { ...base, status: "retrieval-failed", error: error instanceof Error ? error.message : String(error) };
    }
    fs.appendFileSync(resultsPath, safeResult(result));
    process.stdout.write(`[${index + 1}/${urls.length}] ${result.status}\n`);
    await new Promise((resolve) => setTimeout(resolve, 100));
  }

  const summary = {
    format: "site2json-wdc-crawl-join-summary",
    version: 1,
    generatedAt: new Date().toISOString(),
    input: path.relative(PATHS.researchRoot, options.input),
    inputSha256: `sha256:${sha256(fs.readFileSync(options.input))}`,
    output: path.relative(PATHS.researchRoot, options.output),
    collection: options.collection,
    counts
  };
  fs.writeFileSync(path.join(options.output, "summary.json"), `${JSON.stringify(summary, null, 2)}\n`);
  process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
});
