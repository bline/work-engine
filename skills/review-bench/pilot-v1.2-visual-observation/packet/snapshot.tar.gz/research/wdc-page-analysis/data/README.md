# Local research data

Everything beside this file is ignored by Git.

Suggested local layout:

```text
raw/             upstream files and immutable response bytes
intermediate/    parsed declarations, recovered HTML, and candidate scans
derived/         aligned examples, partitions, and metric inputs
annotations/     local review work in progress
```

Do not commit raw URLs, HTML, WARC content, annotations, or derived examples without an explicit provenance, privacy, copyright, and redistribution review.

