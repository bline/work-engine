"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { PATHS } = require("../src/scaffold");
const { domainsForPart, payLevelDomain, sourceUrl } = require("../src/crawl-join/sample-chunk");
const { parseWarcResponse } = require("../src/crawl-join/warc-response");
const { classifyBracket, nearestBracket } = require("../src/crawl-join/probe-wayback-css");
const { cssReferences, importCase, recoverBracketed, rewriteCss } = require("../src/crawl-join/import-visual-fixtures");
const { inventory } = require("../src/declarations/inventory");
const { graphUrl, jobPostingSubject } = require("../src/declarations/extract-selected-quads");
const { parseQuad } = require("../src/declarations/reconstruct-selected-quads");
const { alignment } = require("../src/alignment/analyze-recovered");
const { visibleHaystack } = require("../src/alignment/dom-evidence");
const { assessCandidate, family } = require("../src/alignment/entity-root-assignment");
const { candidateLabels, selectCases } = require("../src/review/build-adjudication");
const { renderSnapshot } = require("../src/review/serve-adjudication");
const { eligibleDecisions } = require("../src/review/export-validated-pages");

function json(relativePath) {
  return JSON.parse(fs.readFileSync(path.join(PATHS.researchRoot, relativePath), "utf8"));
}

test("research paths point to the repository's existing inference modules", () => {
  assert.equal(path.basename(PATHS.researchRoot), "wdc-page-analysis");
  for (const target of Object.values(PATHS.site2json)) assert.equal(fs.existsSync(target), true, target);
});

test("source manifest records partial bounded retrieval without claiming untouched sources", () => {
  const manifest = json("manifests/sources.json");
  assert.equal(manifest.format, "site2json-wdc-source-manifest");
  assert.equal(manifest.status, "partial");
  assert.deepEqual(manifest.sources.map((source) => source.id), [
    "wdc-schemaorg-2024",
    "wdc-schemaorg-table-corpus-2023",
    "wdc-pave",
    "common-crawl-index"
  ]);
  assert.equal(manifest.sources.find((source) => source.id === "wdc-schemaorg-2024").retrieval.artifacts.length, 4);
  assert.equal(manifest.sources.find((source) => source.id === "common-crawl-index").retrieval.probes.officialSample.fetched, 31);
  assert.equal(manifest.sources.find((source) => source.id === "common-crawl-index").retrieval.probes.part13HostDiverse.uniqueRecoveryRate, 0.98);
  assert.equal(manifest.sources.find((source) => source.id === "wdc-schemaorg-table-corpus-2023").retrieval, null);
  assert.equal(manifest.sources.find((source) => source.id === "wdc-pave").retrieval, null);
});

test("versioned example contract and synthetic fixture agree on stable identifiers", () => {
  const schema = json("schemas/example-v1.schema.json");
  const fixture = json("tests/fixtures/example-v1.json");
  assert.equal(schema.$schema, "https://json-schema.org/draft/2020-12/schema");
  assert.equal(schema.properties.format.const, fixture.format);
  assert.equal(schema.properties.version.const, fixture.version);
  assert.equal(fixture.declarations.assessment.semanticRepairApplied, false);
  assert.equal(fixture.source.observationMode, "site2json-rendered-fixture");
  assert.equal(fixture.partition.hostKey.startsWith("sha256:"), true);
  assert.equal(fixture.partition.payLevelDomainKey.startsWith("sha256:"), true);
  assert.equal(fixture.labels[0].observedItemCount, 1);
  assert.equal(fixture.labels[0].pageRole, "primary-detail");
  assert.equal(fixture.eligibility.sessionEnrichmentBenchmark, false);
});

test("static alignment experiment keeps diagnostic proxies separate from labels", () => {
  const experiment = json("manifests/experiments/jobposting-static-alignment.json");
  assert.equal(experiment.status, "preliminary");
  assert.equal(experiment.counting.selectedPages, 49);
  assert.equal(experiment.counting.selectedPayLevelDomains, 49);
  assert.equal(experiment.alignmentProxy.labelStatus, "diagnostic-only");
  assert.equal(experiment.structureAssignment.policy, "one-to-one-v1");
  assert.equal(experiment.structureAssignment.uniqueEligibleAlternative, 7);
  assert.equal(experiment.outputs.reviewSamplePages, 26);
  assert.equal(experiment.outputs.adjudicationPages, 9);
  assert.equal(experiment.outputs.adjudicationPayLevelDomains, 9);
  assert.equal(experiment.outputs.adjudicationDeclaredEntities, 9);
  assert.equal(experiment.humanAdjudication.typeCompatiblePages, 7);
  assert.equal(experiment.humanAdjudication.structureEligibleCandidateAcceptable, 7);
  assert.equal(experiment.humanAdjudication.currentWinnerAcceptable, 1);
});

test("local corpus data and generated artifacts are ignored", () => {
  const ignore = fs.readFileSync(path.join(PATHS.researchRoot, ".gitignore"), "utf8");
  for (const expected of ["/data/*", "/artifacts/", "/cache/", "/models/", "/reports/generated/"]) {
    assert.match(ignore, new RegExp(expected.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
  }
});

test("chunk sampling uses the lookup's pay-level domains and N-Quads provenance", () => {
  const domains = domainsForPart("pld,tld,file_lookup\nexample.co.uk,uk,part_13.gz\nother.com,com,part_2.gz\n", "part_13.gz");
  assert.deepEqual([...domains], ["example.co.uk"]);
  assert.equal(payLevelDomain("https://jobs.example.co.uk/role", domains), "example.co.uk");
  assert.equal(payLevelDomain("https://other.com/role", domains), null);
  assert.equal(sourceUrl('<s> <p> <o> <https://jobs.example.co.uk/role> .'), "https://jobs.example.co.uk/role");
  assert.equal(graphUrl('<s> <p> "value" <https://jobs.example.co.uk/role> .'), "https://jobs.example.co.uk/role");
  assert.equal(jobPostingSubject('_:job <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://schema.org/JobPosting> <https://example.test/job> .'), "_:job");
});

test("WARC response parsing separates archival and HTTP envelopes", () => {
  const fixture = Buffer.from("WARC/1.0\r\nWARC-Type: response\r\n\r\nHTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n<h1>Role</h1>");
  const parsed = parseWarcResponse(fixture);
  assert.equal(parsed.warc.values["warc-type"], "response");
  assert.equal(parsed.http.values["content-type"], "text/html; charset=utf-8");
  assert.equal(parsed.text, "<h1>Role</h1>");
});

test("CSS provenance requires matching verified payloads on both sides", () => {
  const bracket = nearestBracket([
    { timestamp: "20240901000000" },
    { timestamp: "20241001000000" },
    { timestamp: "20241101000000" }
  ], "20241015000000");
  assert.equal(bracket.before.timestamp, "20241001000000");
  assert.equal(bracket.after.timestamp, "20241101000000");
  assert.equal(classifyBracket({ payloadSha256: "sha256:a" }, { payloadSha256: "sha256:a" }), "stable-bracket");
  assert.equal(classifyBracket({ payloadSha256: "sha256:a" }, { payloadSha256: "sha256:b" }), "unstable-bracket");
  assert.equal(classifyBracket({ payloadSha256: "sha256:a" }, null), "nearest-only");
  assert.equal(classifyBracket(
    { timestamp: "20241001000000", payloadSha256: "sha256:a" },
    { timestamp: "20241001000000", payloadSha256: "sha256:a" }
  ), "exact-capture");
});

test("visual fixture CSS discovery resolves imports and assets without retaining remote URLs", () => {
  const css = '@import url("./theme.css"); .hero{background:url(../images/hero.png)} .inline{background:url(data:image/png;base64,x)}';
  assert.deepEqual(cssReferences(css, "https://example.test/css/app.css"), [
    { url: "https://example.test/css/theme.css", role: "stylesheet" },
    { url: "https://example.test/images/hero.png", role: "asset" }
  ]);
  const resources = new Map([
    ["https://example.test/css/theme.css", { status: "localized", localFile: "theme.css" }],
    ["https://example.test/images/hero.png", { status: "localized", localFile: "hero.png" }]
  ]);
  const rewritten = rewriteCss(css, "https://example.test/css/app.css", resources);
  assert.match(rewritten, /@import url\("\.\/theme\.css"\)/);
  assert.match(rewritten, /url\("\.\/hero\.png"\)/);
  assert.doesNotMatch(rewritten, /example\.test/);
  assert.match(rewritten, /data:image\/png/);
});

test("visual fixture recovery only accepts byte-identical archive brackets", async () => {
  const archive = {
    captures: async (url) => [
      { timestamp: "20241001000000", original: url },
      { timestamp: "20241101000000", original: url }
    ],
    fetchCapturePayload: async (capture) => ({ ...capture, payloadContentType: "text/css", payloadSha256: "sha256:same", body: Buffer.from("same") })
  };
  const recovered = await recoverBracketed("https://example.test/app.css", "20241015000000", archive);
  assert.equal(recovered.status, "stable-bracket");
  assert.equal(recovered.selected.body.toString(), "same");
});

test("visual fixture import localizes a bounded presentation dependency graph and keeps scripts disabled", async () => {
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), "site2json-visual-fixture-"));
  const input = path.join(temporary, "input");
  const output = path.join(temporary, "output");
  fs.mkdirSync(input, { recursive: true });
  fs.writeFileSync(path.join(input, "page.html"), '<!doctype html><html><head><link rel="stylesheet" href="https://example.test/app.css"><script>danger()</script></head><body><img src="/logo.png"><main>Job</main></body></html>');
  fs.writeFileSync(path.join(input, "metadata.json"), JSON.stringify({
    reviewId: "case-1",
    sourceUrl: "https://example.test/job",
    captureBodySha256: "sha256:page"
  }));
  const bodies = new Map([
    ["https://example.test/app.css", Buffer.from('@import "/theme.css";main{background:url("/hero.png")}')],
    ["https://example.test/theme.css", Buffer.from("main{display:grid}")],
    ["https://example.test/hero.png", Buffer.from([1, 2, 3])],
    ["https://example.test/logo.png", Buffer.from([4, 5, 6])]
  ]);
  const archive = {
    captures: async (url) => [
      { timestamp: "20241001000000", original: url },
      { timestamp: "20241101000000", original: url }
    ],
    fetchCapturePayload: async (capture) => ({
      ...capture,
      payloadContentType: capture.original.endsWith(".css") ? "text/css" : "image/png",
      body: bodies.get(capture.original)
    })
  };
  const probeItems = [{
    reviewId: "case-1",
    pageTimestamp: "20241015000000",
    resourceUrl: "https://example.test/app.css",
    status: "stable-bracket",
    indexedCaptures: 2,
    before: { timestamp: "20241001000000", original: "https://example.test/app.css" },
    after: { timestamp: "20241101000000", original: "https://example.test/app.css" }
  }];
  try {
    const manifest = await importCase(input, output, probeItems, { maxAssets: 20 }, archive);
    assert.equal(manifest.resources.filter((item) => item.status === "localized").length, 4);
    const rendered = fs.readFileSync(path.join(output, "page.html"), "utf8");
    assert.doesNotMatch(rendered, /danger\(\)/);
    assert.doesNotMatch(rendered, /https:\/\/example\.test\/(?:app\.css|logo\.png)/);
    assert.match(rendered, /Content-Security-Policy/);
    assert.match(rendered, /assets\/[a-f0-9]{20}\.css/);
    const cssFiles = fs.readdirSync(path.join(output, "assets")).filter((name) => name.endsWith(".css"));
    assert.equal(cssFiles.length, 2);
    assert.equal(cssFiles.some((name) => /https:\/\//.test(fs.readFileSync(path.join(output, "assets", name), "utf8"))), false);
  } finally {
    fs.rmSync(temporary, { recursive: true, force: true });
  }
});

test("declaration inventory preserves valid JobPosting JSON-LD and reports invalid scripts", () => {
  const { JSDOM } = require("jsdom");
  const dom = new JSDOM(`<script type="application/ld+json">{"@type":"JobPosting","title":"Engineer"}</script><script type="application/ld+json">{broken</script>`);
  const result = inventory(dom.window.document);
  assert.equal(result.entities.length, 1);
  assert.equal(result.entities[0].values.find((item) => item.path === "title").value, "Engineer");
  assert.deepEqual(result.findings.map((finding) => finding.code), ["invalid-json"]);
  dom.window.close();
});

test("alignment excludes declaration scripts and concentrates evidence in one root", () => {
  const { JSDOM } = require("jsdom");
  const dom = new JSDOM(`<div class="item"><script>{"title":"Invisible Role"}</script><h1>Visible Role</h1></div><div class="item"><span>Other</span></div>`);
  const entity = { values: [{ path: "title", value: "Invisible Role" }, { path: "title", value: "Visible Role" }, { path: "name", value: "Other" }] };
  assert.equal(visibleHaystack(dom.window.document.querySelector(".item")).includes("invisible role"), false);
  const result = alignment(entity, dom.window.document, { selector: ".item" });
  assert.equal(result.matchedValues, 1);
  assert.equal(result.rootsWithMatches, 2);
  assert.equal(result.matchRatio, 0.333);
  dom.window.close();
});

test("N-Quads reconstruction preserves RDF term metadata and decoded literals", () => {
  const quad = parseQuad('_:job <http://schema.org/title> "Senior\\nEngineer"@en <https://example.test/job> .');
  assert.deepEqual(quad.subject, { kind: "blank", value: "_:job" });
  assert.deepEqual(quad.object, { kind: "literal", value: "Senior\nEngineer", language: "en" });
  assert.deepEqual(quad.graph, { kind: "iri", value: "https://example.test/job" });
});

test("entity-root assignment requires one coherent root and independent evidence families", () => {
  const { JSDOM } = require("jsdom");
  const dom = new JSDOM(`<main><article class="job"><h1>Senior Engineer</h1><p>Acme Corp</p></article></main>`, { url: "https://example.test/job" });
  const entities = [{ values: [{ path: "title", value: "Senior Engineer" }, { path: "hiringOrganization.name", value: "Acme Corp" }] }];
  const good = assessCandidate(dom.window.document, { selector: ".job" }, entities);
  assert.equal(good.eligible, true);
  assert.deepEqual(good.assignments[0].strongFamilies.sort(), ["organization", "title"]);
  const broad = assessCandidate(dom.window.document, { selector: "body" }, entities);
  assert.equal(broad.eligible, false);
  assert.equal(broad.findings.some((finding) => finding.code === "body-root"), true);
  assert.equal(family("jobLocation.address.addressLocality"), "location");
  dom.window.close();
});

test("adjudication selection is bounded and candidate-role labels are deterministic", () => {
  const pages = [
    { structureAlignment: { uniqueEligibleCandidate: { selector: "main" } } },
    { structureAlignment: { uniqueEligibleCandidate: null } },
    {}
  ];
  assert.equal(selectCases(pages).length, 1);
  assert.deepEqual(candidateLabels("sha256:0"), { current: "A", eligible: "B" });
  assert.deepEqual(candidateLabels("sha256:1"), { current: "B", eligible: "A" });
});

test("adjudication viewer removes scripts and marks candidates without reading the key", () => {
  const warc = Buffer.from("WARC/1.0\r\nWARC-Type: response\r\n\r\nHTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n<main><article>Role</article><script>danger()</script></main>");
  const item = { sourceUrl: "https://example.test/job", candidates: { A: { selector: "article" }, B: { selector: "main" } } };
  const output = renderSnapshot(item, warc, "both");
  assert.doesNotMatch(output, /danger\(\)/);
  assert.match(output, /data-wdc-review-a="1"/);
  assert.match(output, /data-wdc-review-b="1"/);
  assert.match(output, /<base href="https:\/\/example\.test\/job">/);
});

test("validated-page export excludes type-incompatible and unfinished reviews", () => {
  const decisions = { items: [
    { reviewId: "one", status: "reviewed", declaredTypeCompatible: true },
    { reviewId: "two", status: "reviewed-excluded", declaredTypeCompatible: false },
    { reviewId: "three", status: "in-progress", declaredTypeCompatible: true }
  ] };
  assert.deepEqual(eligibleDecisions(decisions).map((item) => item.reviewId), ["one"]);
});
