# WDC Page Analysis research

This directory contains offline research tooling for the [WDC Page Analysis Corpus proposal](../../docs/wdc-page-analysis-corpus.md).

It is intentionally separate from the Chromium extension. Research code may load Site2JSON inference modules from the repository root; production extension code must never import this directory.

## Status

The scaffold now includes a bounded crawl-join feasibility probe and a preliminary static declaration/alignment spike. It can select one page per lookup-defined pay-level domain, retrieve uniquely matched WARC byte ranges, reconstruct selected WDC RDF graphs without semantic repair, run the real Site2JSON scope generator against static HTML, perform diagnostic one-to-one entity/root assignment, build an ignored review sample, and serve blinded captured-page adjudication. The first nine-case structure stratum has been human-reviewed; a general silver-label policy, semantic evaluation, rendered-JavaScript comparison, and modeling are not implemented yet. The package adds no research-specific runtime dependency; it reuses the repository's development `jsdom` dependency.

## Boundaries

- Raw WDC, Common Crawl, PAVE, WARC, HTML, annotations, and derived datasets stay under `data/` and are ignored.
- Generated reports stay under `reports/generated/` until they are reviewed for content, provenance, and redistribution safety.
- Small committed fixtures must be synthetic or explicitly reviewed and scrubbed.
- Every experiment records its source manifest, Site2JSON Git revision, observation mode, filters, counting unit, and weighting policy.
- Research results may produce small regression fixtures or reviewed scoring changes. Corpus machinery must not enter `extension/`.
- Normal root `npm test` and `npm run check` must not download data or run large experiments.

## Layout

```text
data/                 ignored raw, intermediate, and derived local data
manifests/            reviewed upstream source and experiment manifests
reports/              reviewed aggregate reports; generated work is ignored
schemas/              versioned research interchange contracts
src/
  table-corpus/       low-cost statistics and one-item/detail prior spike
  pave/               PAVE format and identifier-linkage spike
  crawl-join/         raw WDC URL to immutable Common Crawl response spike
  declarations/       offline declaration assessment and normalization
  alignment/          declared-value to DOM-candidate alignment
  evaluation/         partitions, metrics, denominators, and reports
  review/             human adjudication support
tests/fixtures/        tiny redistributable examples only
```

The planned module responsibilities are recorded in [`src/README.md`](src/README.md). Empty implementation directories are retained with local README files so their boundaries are reviewable before code is added.

## Local checks

From the repository root:

```sh
npm run check --prefix research/wdc-page-analysis
npm test --prefix research/wdc-page-analysis
```

These checks are offline. Network and large-data commands are explicit and remain outside `test` and `check`.

## Bounded JobPosting join probe

After placing `part_13.gz` and the official `JobPosting_lookup.csv` under `data/raw/wdc-schemaorg-2024/jobposting/`, select 50 pages from distinct pay-level domains:

```sh
npm run sample:jobposting-chunk
```

Then retrieve exact matches from the WDC source crawl only:

```sh
npm run fetch:jobposting-sample -- \
  --input data/intermediate/jobposting/part_13.gz-host-diverse.json \
  --output data/raw/common-crawl/CC-MAIN-2024-42/jobposting-part-13-host-diverse
```

The fetcher caps a probe at 100 pages, retries transient `429`/`5xx` responses with bounded backoff, and reuses completed results when a probe is resumed. It requires HTTP `206` for each bounded WARC range, rejects records over 10 MiB, and records missing or ambiguous matches instead of choosing silently. Raw URLs and page bodies remain in ignored `data/`; only aggregate results belong in reviewed manifests or reports.

Extract and reconstruct the selected pages' WDC quads from the already downloaded class chunk:

```sh
npm run extract:jobposting-quads --prefix research/wdc-page-analysis
npm run reconstruct:jobposting-quads --prefix research/wdc-page-analysis
```

Then analyze the uniquely recovered pages and build a local qualitative review sample:

```sh
npm run analyze:jobposting-static --prefix research/wdc-page-analysis
npm run review:jobposting-static --prefix research/wdc-page-analysis
npm run review:jobposting-adjudication --prefix research/wdc-page-analysis
npm run view:jobposting-adjudication --prefix research/wdc-page-analysis
npm run export:jobposting-validated-pages --prefix research/wdc-page-analysis
```

These commands are offline. The adjudication command creates a nine-page, A/B-labeled review queue plus a separate candidate-role key. The viewer serves the exact recovered HTML at `http://127.0.0.1:4173/`, removes publisher scripts, and does not load the key. Their page-level outputs remain ignored under `data/derived/`; reviewed aggregate conclusions are in [`reports/static-alignment-spike.md`](reports/static-alignment-spike.md).

To test whether Wayback can provide defensible historical presentation evidence for the reviewed pages' external stylesheets, run the explicit network probe:

```sh
npm run probe:jobposting-wayback-css --prefix research/wdc-page-analysis
```

The probe is throttled and checkpointed. It queries exact stylesheet URLs without collapsing CDX rows by digest, retrieves the nearest capture on either side of the Common Crawl HTML timestamp, and verifies fetched payload equality with a local SHA-256 digest. Its URL-level output remains ignored under `data/derived/`; only reviewed aggregate results belong in the report.

## First decision

Run the three bounded ROI spikes before committing to a large corpus:

1. Inspect Table Corpus statistics against one-item/detail use cases.
2. Probe exact raw-WDC-to-Common-Crawl snapshot recovery on a small host-diverse sample.
3. Inspect PAVE `pid` anchoring and identifier linkage before pursuing source HTML.

The raw crawl join is the feasibility gate for the proposed Page Analysis corpus. See the design document for label tiers, metrics, and go/no-go criteria.
