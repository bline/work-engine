use operator_observation::{Observation, Snapshot, collect, digest, terminal_text};
use session_query::{Profile, Query};
use std::{
    fs::{self, OpenOptions},
    io::Write,
    os::unix::fs::OpenOptionsExt,
    path::Path,
    time::Duration,
};

fn publish(path: &str, bytes: &[u8]) -> Result<(), &'static str> {
    let path = Path::new(path);
    if !path.is_absolute() {
        return Err("output_path_must_be_absolute");
    }
    let tmp = path.with_file_name(format!(
        ".{}.{}.tmp",
        path.file_name()
            .and_then(|s| s.to_str())
            .ok_or("invalid_output")?,
        std::process::id()
    ));
    let mut f = OpenOptions::new()
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(&tmp)
        .map_err(|_| "output_unavailable")?;
    let result = (|| {
        f.write_all(bytes)
            .and_then(|_| f.sync_all())
            .map_err(|_| "output_unavailable")?;
        fs::rename(&tmp, path).map_err(|_| "output_unavailable")
    })();
    if result.is_err() {
        let _ = fs::remove_file(tmp);
    }
    result
}
fn human(s: &Snapshot) {
    println!(
        "{} · {} selected sessions · observed {} ms since epoch",
        terminal_text(&s.label),
        s.sessions.len(),
        s.observed_at_ms
    );
    println!("Session activity only; task execution, completion and spend are not established.");
    for session in &s.sessions {
        match &session.observation {
            Observation::Unavailable { code } => {
                println!("{} · unavailable: {}", session.session_id, code)
            }
            Observation::Available {
                host,
                title,
                entries,
            } => {
                println!(
                    "{} · {} · {}",
                    session.session_id,
                    host,
                    terminal_text(title.as_deref().unwrap_or("Untitled session"))
                );
                for e in entries {
                    println!(
                        "  {} {}\n{}",
                        e.role,
                        terminal_text(e.tool.as_deref().unwrap_or("")),
                        terminal_text(&e.text)
                    );
                }
            }
        }
    }
}
fn run() -> Result<(), &'static str> {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.is_empty() || args == ["--help"] {
        println!(
            "work-engine-observe PROFILE --label LABEL --session UUID [--session UUID ...] [--human] [--output /absolute/snapshot.json --interval SECONDS]\nRead-only selected-session observation through the pinned Events compositor. Output is private, atomically replaced JSON. Default is one observation; --interval (2..3600) repeats only with --output. No provider or command operation is available."
        );
        return Ok(());
    }
    let (mut label, mut ids, mut output, mut interval, mut is_human) =
        (String::new(), Vec::new(), None, None, false);
    let mut i = 1;
    while i < args.len() {
        if args[i] == "--human" {
            is_human = true;
            i += 1;
            continue;
        }
        let v = args.get(i + 1).ok_or("invalid_arguments")?;
        match args[i].as_str() {
            "--label" if label.is_empty() => label = v.clone(),
            "--session" => ids.push(v.clone()),
            "--output" if output.is_none() => output = Some(v.clone()),
            "--interval" if interval.is_none() => {
                interval = Some(v.parse::<u64>().map_err(|_| "invalid_interval")?)
            }
            _ => return Err("invalid_arguments"),
        };
        i += 2;
    }
    operator_observation::validate_selection(&label, &ids)?;
    if interval.is_some_and(|n| !(2..=3600).contains(&n))
        || (interval.is_some() && output.is_none())
    {
        return Err("invalid_interval");
    }
    let bytes = session_query::read_file(&args[0], 16384, true)?;
    let profile: Profile = serde_json::from_slice(&bytes).map_err(|_| "invalid_profile")?;
    profile.validate()?;
    if profile.bridge.is_some() {
        return Err("observation_profile_must_have_no_bridge");
    }
    let source_id = digest(&bytes);
    loop {
        let snapshot = collect(&source_id, &label, &ids, |arguments| {
            session_query::query(&profile, &Query::parse("read_session", arguments)?)
        })?;
        let bytes = serde_json::to_vec(&snapshot).map_err(|_| "invalid_snapshot")?;
        Snapshot::parse(&bytes)?;
        if let Some(path) = &output {
            publish(path, &bytes)?;
        }
        if is_human {
            human(&snapshot);
        } else if output.is_none() {
            println!(
                "{}",
                String::from_utf8(bytes).map_err(|_| "invalid_snapshot")?
            );
        }
        match interval {
            Some(n) => std::thread::sleep(Duration::from_secs(n)),
            None => return Ok(()),
        }
    }
}
fn main() {
    if let Err(code) = run() {
        eprintln!("{code}");
        std::process::exit(1);
    }
}
